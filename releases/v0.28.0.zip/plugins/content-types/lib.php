<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/db.php';
require_once __DIR__ . '/../../core/plugins.php';
require_once __DIR__ . '/../../core/pluginSchema.php';
require_once __DIR__ . '/../../core/uploads.php';
require_once __DIR__ . '/../../core/siteRoutes.php';

// Reihenfolge der Einträge eines Typs; vor dem ersten Sortieren haben alle sort_order 0.
const CONTENT_TYPES_ORDER = 'sort_order ASC, id DESC';
// Sortieren (↑/↓): Richtung → Schritt in der Liste.
const CONTENT_TYPES_SORT_STEPS = [INLINE_EDIT_SORT_UP => -1, INLINE_EDIT_SORT_DOWN => 1];
// Klickziele eines Eintrags (actions in der Typ-Definition) mit ihrer Beschriftung im Formular,
// in dieser Reihenfolge; ohne actions gilt CONTENT_TYPES_DEFAULT_ACTIONS.
const CONTENT_TYPES_ACTIONS = ['none' => 'Nichts', 'link' => 'Externer Link', 'page' => 'Eigene Seite', 'modal' => 'Modal'];
const CONTENT_TYPES_DEFAULT_ACTIONS = ['none'];
// Felder, die die Klickziele in den Eintrag bringen (im data-JSON): Name → Beschriftung. Ein Feld
// des Typs mit einem dieser Namen macht die Definition ungültig, sobald das Ziel es braucht.
const CONTENT_TYPES_ACTION_FIELDS = ['action' => 'Beim Klick', 'url' => 'Link', 'slug' => 'Adresse'];
// Ungültige Typ-Definition: Gründe (Typname, dann Wert) für den Hinweis im Backend und das Log.
const CONTENT_TYPES_INVALID_TEXT = [
    'unreadable' => '„%s“: kein gültiger Content-Typ (braucht label und fields).',
    'actions' => '„%s“: actions muss eine Liste aus %s sein.',
    'action' => '„%s“: Unbekanntes Klickziel „%s“ in actions.',
    'duplicate' => '„%s“: Das Klickziel „%s“ steht mehrfach in actions.',
    'defaultAction' => '„%s“: defaultAction „%s“ steht nicht in actions.',
    'page' => '„%s“: Mit dem Ziel page braucht der Typ page mit path, titleField und descriptionField.',
    'pagePath' => '„%s“: page.path „%s“ ist kein gültiger Name (Buchstaben, Ziffern, - und _).',
    'pageTaken' => '„%s“: page.path „%s“ ist schon vergeben (Ordner oder Datei der Website, Adresse des Editors; eine Seite gleichen Namens geht).',
    'pageField' => '„%s“: page.%s muss ein Feld des Typs nennen (erlaubte Arten: %s).',
    'pageShared' => '„%s“: page.path „%s“ nutzt auch der Typ „%s“.',
    'pageSchema' => '„%s“: page.schema muss einer dieser Werte sein: %s.',
    'reserved' => '„%s“: Das Feld „%s“ ist für die Klickziele reserviert.',
    'orderBy' => '„%s“: orderBy braucht field (ein Feld des Typs, erlaubte Arten: %s) und optional direction (asc oder desc).',
    'publishField' => '„%s“: publishField muss ein Feld des Typs nennen (erlaubte Arten: %s).',
    'expireField' => '„%s“: expireField muss ein Feld des Typs nennen (erlaubte Arten: %s).',
    'column' => '„%s“: column von „%s“ muss true oder false sein, und nur diese Arten können Spalte sein: %s.',
    'optionsFrom' => '„%s“: optionsFrom von „%s“ muss einen anderen Content-Typ mit Textfeld nennen.',
    'fallback' => '„%s“: fallback von „%s“ muss ein anderes Feld des Typs ohne eigenes fallback nennen (erlaubte Arten: %s), und nur %s-Felder haben fallback.',
];
// Auswahlfeld mit optionsFrom: Die Werte sind die Titel der Einträge eines anderen Typs (Feld name oder title,
// sonst das erste Textfeld, wie entryTitle im Formular), in dessen Listenreihenfolge. Das Formular bietet
// dazu „+ <Feld> hinzufügen“ an: Es legt über diesen Endpoint einen Eintrag im anderen Typ an.
const CONTENT_TYPES_TITLE_FIELDS = ['name', 'title'];
const CONTENT_TYPES_SAVE_URL = PLUGINS_URL . 'content-types/api/save.php';
// orderBy in der Typ-Definition: Einträge nach einem Feld statt von Hand (↑/↓ entfällt), erlaubte Arten
// und Richtungen. Ohne Wert zählt bei date/datetime das Anlegedatum, sonst stehen solche Einträge am Ende.
const CONTENT_TYPES_ORDER_FIELD_TYPES = ['text', 'number', 'date', 'datetime'];
const CONTENT_TYPES_ORDER_DIRECTIONS = ['asc', 'desc'];
// publishField: Auf der Website erscheint ein Eintrag erst ab diesem Datum (leer: sofort), expireField: nur bis zu
// diesem Datum (ein Tag bis zu seinem Ende, leer: immer); das Backend zeigt alle. Erlaubte Arten für beide.
const CONTENT_TYPES_PUBLISH_FIELD_TYPES = ['date', 'datetime'];
const CONTENT_TYPES_VISIBILITY_KEYS = ['publishField', 'expireField'];
// Stand eines Eintrags auf der Website (content_types_visibility), fürs Backend: noch nicht fällig bzw. abgelaufen.
const CONTENT_TYPES_SCHEDULED = 'scheduled';
const CONTENT_TYPES_EXPIRED = 'expired';
// Spalten der Liste im Backend: Felder mit "column": true in diesen Arten. Ohne solche Felder das erste Bild und das
// Datum aus orderBy, publishField oder expireField (content_types_admin_columns).
const CONTENT_TYPES_COLUMN_FIELD_TYPES = ['text', 'textarea', 'number', 'date', 'datetime', 'select', 'boolean', 'image', 'url'];
// Eintrag in der Seitenleiste des Backends, wenn es ungültige Typen gibt (Gründe in seiner Ansicht).
const CONTENT_TYPES_INVALID_LABEL = 'Ungültige Content-Typen';
// Einträge einer Liste: Vorgabe für data-limit und höchstens so viele.
const CONTENT_TYPES_LIST_LIMIT = 20;
const CONTENT_TYPES_LIST_MAX = 500;
// data-filter="<feld>=<wert>": Trennzeichen zwischen Feld und Wert (das erste zählt).
const CONTENT_TYPES_FILTER_SEPARATOR = '=';
// Art der eigenen Seite für Suchmaschinen (page.schema, schema.org): strukturierte Daten mit Titel, Beschreibung,
// Datum und Bild (content_types_page_json_ld). Ohne page.schema keine.
const CONTENT_TYPES_PAGE_SCHEMAS = ['Article', 'BlogPosting', 'NewsArticle'];
// Erlaubte Arten der Felder, die Titel und Beschreibung der eigenen Seite liefern (page).
const CONTENT_TYPES_PAGE_FIELD_TYPES = ['titleField' => ['text'], 'descriptionField' => ['text', 'textarea', 'richtext', 'blocks']];
// fallback eines Feldes (z. B. Kurzfassung): Arten mit fallback und Arten, aus denen der Ersatz kommt (template.php).
const CONTENT_TYPES_FALLBACK_FIELD_TYPES = ['text', 'textarea'];
const CONTENT_TYPES_FALLBACK_SOURCE_TYPES = ['text', 'textarea', 'richtext', 'blocks'];
// Ausgabe des Shortcodes statt der Liste, wenn der Typ fehlt, ungültig ist oder die Einträge nicht
// laden (Grund nur im Log, nie auf der Website).
const CONTENT_TYPES_RENDER_FAILED = '<!-- content-types: list unavailable -->';
// Modal-Skript und sein CSS (nur Position, Scroll-Sperre, Fokus), eingebunden auf Seiten mit einer Liste
// eines Typs mit modal (content_types_filter_site_html).
const CONTENT_TYPES_MODAL_ASSETS = [
    'style' => PLUGINS_URL . 'content-types/assets/modal.css',
    'script' => PLUGINS_URL . 'content-types/assets/modal.js',
];
// Import (api/import.php): höchstens so viele Einträge und Bytes (Anfrage) auf einmal, Meldungen (Zeile ab 1,
// Feld, Grund ohne Feldnamen; image mit UPLOADS_URL und LE_SITE_FILES_URL, action mit den erlaubten Zielen).
const CONTENT_TYPES_IMPORT_MAX = 500;
const CONTENT_TYPES_IMPORT_MAX_BYTES = 5 * BYTES_PER_MB;
const CONTENT_TYPES_IMPORT_TEXT = [
    'tooLarge' => 'Die Datei ist größer als %d MB.',
    'notList' => 'Die Datei muss eine Liste (JSON-Array) von Einträgen enthalten.',
    'empty' => 'Die Datei enthält keine Einträge.',
    'tooMany' => 'Höchstens %d Einträge auf einmal.',
    'entry' => 'Zeile %d: Kein Eintrag (JSON-Objekt).',
    'line' => 'Zeile %d, %s: %s',
    'action' => 'Dieses Ziel gibt es hier nicht (erlaubt: %s).',
    'image' => 'Nur Bilder, die es schon gibt, unter %s oder %s.',
];

// Einspielen von Plugin-Daten (core/dataSync.php, Hook entry_problem): Gründe, warum ein neuer oder geänderter Eintrag
// so nicht online gehen kann (%s: Typname bzw. Adresse).
const CONTENT_TYPES_DATA_TEXT = [
    'unknownType' => 'Content-Typ „%s“ gibt es online nicht, erst ausrollen (deploy).',
    'slugTaken' => 'Adresse „%s“ gibt es online schon in diesem Typ, lokal ändern und den Diff neu bilden.',
];

// Typen der Website: alle Definitionen in einer Datei, CONTENT_TYPES_FILE (Liste wie presets/*.json, je Typ ein Objekt
// mit name). Daneben je Typ ein Ordner (von außen gesperrt: .htaccess, index.php) mit den Vorlagen (template.php) und
// optional eintraege.json: Startpaket wie beim Import, das content_types_seed() einmal in die Datenbank bringt (Typ
// ohne Einträge) und danach löscht. Die Einträge leben nur in der Datenbank.
const CONTENT_TYPES_TEMPLATE_DIR = LE_SITE_ROOT . '/includes/content-types';
const CONTENT_TYPES_FILE = CONTENT_TYPES_TEMPLATE_DIR . '/typen.json';
const CONTENT_TYPES_SEED_FILE = 'eintraege.json';
// Startpakete, die zuletzt scheiterten (je Zeile ein Typ): Nur Aufrufe mit angemeldeter Editor-Sitzung versuchen sie
// erneut, nie ein Seitenaufruf eines Besuchers (sonst Sperre und Log-Zeile bei jedem Aufruf).
const CONTENT_TYPES_SEED_FAILED_FILE = CACHE_ROOT . '/content-types-seed-failed';
// Frühere Ablage: je Typ content/plugins/content-types/<typ>.json, dazu <typ>/typ.json der Website, die einmal dorthin
// kopiert wurde (übernommene in .website-typen.json). content_types_migrate() fasst sie einmal in CONTENT_TYPES_FILE
// zusammen und löscht sie.
const CONTENT_TYPES_LEGACY_SITE_FILE = 'typ.json';
const CONTENT_TYPES_LEGACY_ADOPTED_FILE = '.website-typen.json';
// Fehler in CONTENT_TYPES_FILE selbst (Hinweis im Backend wie bei ungültigen Typen).
const CONTENT_TYPES_FILE_TEXT = [
    'unreadable' => 'typen.json ist keine Liste von Content-Typen (JSON-Array).',
    'entry' => 'typen.json, Eintrag %d: kein Content-Typ mit gültigem name (Kleinbuchstaben, Ziffern, - und _).',
    'duplicate' => 'typen.json: Den Typ „%s“ gibt es mehrfach.',
    'orphaned' => '„%s“ fehlt in typen.json, seine %d Einträge liegen noch in der Datenbank.',
];

/**
 * Inhalt von CONTENT_TYPES_FILE: ['types' => [Name => Definition, nach Name sortiert], 'problems' => [Text]]
 * (CONTENT_TYPES_FILE_TEXT). Ohne Datei keine Typen. Vorher content_types_prepare(); gelesen wird bei jedem Aufruf,
 * dekodiert nur, wenn sich die Datei geändert hat.
 */
function content_types_file_data(): array
{
    static $cache = [null, null];
    content_types_prepare();
    $json = @file_get_contents(CONTENT_TYPES_FILE);
    if ($json === false) {
        return ['types' => [], 'problems' => []];
    }
    if ($cache[0] === $json) {
        return $cache[1];
    }
    $list = json_decode($json, true);
    $types = [];
    $problems = [];
    if (!is_array($list) || array_values($list) !== $list) {
        $problems[] = CONTENT_TYPES_FILE_TEXT['unreadable'];
        $list = [];
    }
    foreach ($list as $i => $def) {
        $name = is_array($def) ? ($def['name'] ?? null) : null;
        if (!is_string($name) || !content_types_name_valid($name)) {
            $problems[] = sprintf(CONTENT_TYPES_FILE_TEXT['entry'], $i + 1);
        } elseif (isset($types[$name])) {
            $problems[] = sprintf(CONTENT_TYPES_FILE_TEXT['duplicate'], $name);
        } else {
            $types[$name] = $def;
        }
    }
    ksort($types);
    $cache = [$json, ['types' => $types, 'problems' => $problems]];

    return $cache[1];
}

/** Einmal je Request vor dem ersten Lesen der Typen: frühere Ablage zusammenfassen, dann Startpakete einspielen. */
function content_types_prepare(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    // Vor der Arbeit: Import und Prüfung lesen selbst Typen und landen wieder hier.
    $done = true;
    content_types_migrate();
    content_types_seed();
}

/**
 * Fasst die frühere Ablage einmal in CONTENT_TYPES_FILE zusammen, solange es die Datei nicht gibt: Definitionen aus
 * content/plugins/content-types/<typ>.json, dazu <typ>/typ.json der Website, die noch nicht übernommen waren
 * (übernommene ohne Definition unter content/ hatte der Admin gelöscht). Danach sind die alten Dateien weg, ebenso
 * eintraege.json übernommener Typen (deren Einträge sind längst in der Datenbank). Gleiche Dateien ergeben byte-gleich
 * dieselbe typen.json, im Klon wie am Server (deploy führt sie ohne Konflikt zusammen). Unlesbare Definitionen bleiben
 * liegen und fehlen in typen.json (Log). Unter store_lock(), Fehler nur ins Log.
 */
function content_types_migrate(): void
{
    if (is_file(CONTENT_TYPES_FILE)) {
        return;
    }
    $legacyDir = plugin_data_path('content-types');
    $siteFiles = glob(CONTENT_TYPES_TEMPLATE_DIR . '/*/' . CONTENT_TYPES_LEGACY_SITE_FILE) ?: [];
    if ($siteFiles === [] && (glob($legacyDir . '/*.json') ?: []) === []) {
        return;
    }
    $lock = store_lock('content-types-website');
    try {
        if (is_file(CONTENT_TYPES_FILE)) {
            return;
        }
        $adopted = json_decode((string) @file_get_contents($legacyDir . '/' . CONTENT_TYPES_LEGACY_ADOPTED_FILE), true);
        $adopted = is_array($adopted) ? array_values(array_filter($adopted, 'is_string')) : [];
        $sources = [];
        foreach ($siteFiles as $file) {
            $name = basename(dirname($file));
            if (!in_array($name, $adopted, true)) {
                $sources[$name] = $file;
            }
        }
        // Was unter content/ liegt, hat LeBuild bisher genutzt; es gewinnt.
        foreach (glob($legacyDir . '/*.json') ?: [] as $file) {
            $sources[basename($file, '.json')] = $file;
        }
        ksort($sources, SORT_STRING);
        $list = [];
        $done = [];
        foreach ($sources as $name => $file) {
            // Als Objekte dekodiert, damit {} nicht zu [] wird.
            $def = json_decode((string) file_get_contents($file));
            if (!content_types_name_valid((string) $name) || !$def instanceof stdClass || ($def->name ?? null) !== (string) $name) {
                error_log('content-types: ' . le_instance_relative($file) . ' ist kein Content-Typ und bleibt liegen');
                continue;
            }
            $list[] = $def;
            $done[] = $file;
        }
        ensure_dir(CONTENT_TYPES_TEMPLATE_DIR);
        write_file_atomic(CONTENT_TYPES_FILE, json_encode($list, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR) . "\n");
        $remove = [...$done, $legacyDir . '/' . CONTENT_TYPES_LEGACY_ADOPTED_FILE];
        foreach ($siteFiles as $file) {
            $remove[] = $file;
            if (in_array(basename(dirname($file)), $adopted, true)) {
                $remove[] = dirname($file) . '/' . CONTENT_TYPES_SEED_FILE;
            }
        }
        foreach ($remove as $file) {
            if (is_file($file) && !@unlink($file)) {
                error_log('content-types: ' . le_instance_relative($file) . ' lässt sich nicht löschen');
            }
        }
        if (is_dir($legacyDir) && dir_entries($legacyDir) === []) {
            @rmdir($legacyDir);
        }
    } catch (Throwable $e) {
        error_log('content-types: Typen zusammenfassen: ' . $e->getMessage());
    } finally {
        store_unlock($lock);
    }
}

/**
 * Bringt die Startpakete (<typ>/eintraege.json) in die Datenbank, nur bei aktivem Plugin: Hat der Typ noch keine
 * Einträge, kommen sie per content_types_import dazu (ganz oder gar nicht, Bilder müssen existieren); danach ist die
 * Datei weg, auch wenn der Typ schon Einträge hatte. Zwei Durchgänge, weil ein Typ mit optionsFrom die Einträge des
 * anderen braucht. Gescheiterte bleiben liegen und stehen in CONTENT_TYPES_SEED_FAILED_FILE (Log). Ohne Startpakete
 * kostet das nur das Lesen des Ordners. Unter store_lock(), damit gleichzeitige Requests nichts doppelt anlegen.
 */
function content_types_seed(): void
{
    if (content_types_seeds_pending() === [] || !plugin_active('content-types') || !db_available() || db_migration_running()) {
        return;
    }
    // Ohne Anmeldung nie die zuletzt gescheiterten (auch nicht neben einem neuen Startpaket).
    $skip = content_types_seed_retry_allowed() ? [] : content_types_seed_failed();
    if (array_diff(content_types_seeds_pending(), $skip) === []) {
        return;
    }
    // Das Einspielen schreibt Einträge: wie ein schreibender Request die geteilte Sperre halten (ein Umzug wartet).
    if (!db_migration_writer_hold()) {
        return;
    }
    $lock = store_lock('content-types-website');
    try {
        $pending = array_values(array_diff(content_types_seeds_pending(), $skip));
        foreach ([false, true] as $last) {
            $failed = [];
            foreach ($pending as $name) {
                try {
                    content_types_seed_type($name);
                } catch (Throwable $e) {
                    $failed[] = $name;
                    if ($last) {
                        error_log('content-types: Startpaket ' . $name . ': ' . $e->getMessage()
                            . ($e instanceof PluginFieldException ? ' (' . content_types_import_message($e) . ')' : ''));
                    }
                }
            }
            $pending = $failed;
        }
        $stillFailed = array_values(array_unique(array_merge($pending, array_intersect($skip, content_types_seeds_pending()))));
        if ($stillFailed !== []) {
            ensure_dir(dirname(CONTENT_TYPES_SEED_FAILED_FILE));
            write_file_atomic(CONTENT_TYPES_SEED_FAILED_FILE, implode("\n", $stillFailed) . "\n");
        } elseif (is_file(CONTENT_TYPES_SEED_FAILED_FILE)) {
            @unlink(CONTENT_TYPES_SEED_FAILED_FILE);
        }
    } catch (Throwable $e) {
        error_log('content-types: Startpakete: ' . $e->getMessage());
    } finally {
        store_unlock($lock);
    }
}

/** Erneuter Versuch nach einem Fehlschlag: nur mit offener, angemeldeter Editor-Sitzung (nicht der Session der Website). */
function content_types_seed_retry_allowed(): bool
{
    return defined('APP_SESSION_NAME') && session_status() === PHP_SESSION_ACTIVE && session_name() === APP_SESSION_NAME && function_exists('is_logged_in') && is_logged_in();
}

/** Typen der zuletzt gescheiterten Startpakete (CONTENT_TYPES_SEED_FAILED_FILE); ohne Datei keine. */
function content_types_seed_failed(): array
{
    return array_values(array_filter(explode("\n", (string) @file_get_contents(CONTENT_TYPES_SEED_FAILED_FILE))));
}

/** Typen mit Startpaket (<typ>/eintraege.json), sortiert. */
function content_types_seeds_pending(): array
{
    $names = [];
    foreach (dir_entries(CONTENT_TYPES_TEMPLATE_DIR) as $name) {
        if (content_types_name_valid($name) && is_file(CONTENT_TYPES_TEMPLATE_DIR . '/' . $name . '/' . CONTENT_TYPES_SEED_FILE)) {
            $names[] = $name;
        }
    }
    sort($names);

    return $names;
}

/** Spielt das Startpaket eines Typs ein, falls er keine Einträge hat, und löscht es (content_types_seed). */
function content_types_seed_type(string $name): void
{
    $path = CONTENT_TYPES_TEMPLATE_DIR . '/' . $name . '/' . CONTENT_TYPES_SEED_FILE;
    if (content_types_entry_count($name) === 0) {
        content_types_import($name, json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR));
    }
    if (!@unlink($path) && is_file($path)) {
        throw new RuntimeException(CONTENT_TYPES_SEED_FILE . ' lässt sich nicht löschen');
    }
}

/** Anzahl der Einträge eines Typs in der Datenbank. */
function content_types_entry_count(string $name): int
{
    $stmt = db()->prepare('SELECT COUNT(*) FROM content_items WHERE content_type = ?');
    $stmt->execute([$name]);

    return (int) $stmt->fetchColumn();
}

function content_types_name_valid(string $name): bool
{
    return (bool) preg_match('/^[a-z][a-z0-9_-]*$/', $name);
}

/** Namen der Typen in CONTENT_TYPES_FILE, sortiert. */
function content_types_list_names(): array
{
    return array_keys(content_types_file_data()['types']);
}

/**
 * Typ-Definition aus CONTENT_TYPES_FILE mit den Vorgaben für actions und defaultAction, noch ohne deren Prüfung
 * (content_types_definition_problem). Wirft, wenn es den Typ nicht gibt oder er kein Content-Typ ist (label, fields).
 */
function content_types_read(string $name): array
{
    if (!content_types_name_valid($name)) {
        throw new InvalidArgumentException(API_TEXT['invalidType']);
    }
    $data = content_types_file_data()['types'][$name] ?? null;
    if ($data === null) {
        throw new RuntimeException('Content-type not found: ' . $name);
    }
    if (!is_string($data['label'] ?? null) || trim($data['label']) === '') {
        throw new RuntimeException('Content-type missing label: ' . $name);
    }
    if (!is_array($data['fields'] ?? null) || empty($data['fields'])) {
        throw new RuntimeException('Content-type has no fields: ' . $name);
    }

    $data['actions'] ??= CONTENT_TYPES_DEFAULT_ACTIONS;
    $data['defaultAction'] ??= is_array($data['actions']) ? ($data['actions'][0] ?? null) : null;

    return $data;
}

/** Gültige Typ-Definition (content_types_read + content_types_definition_problem); wirft mit dem Grund. */
function content_types_load(string $name): array
{
    $data = content_types_read($name);
    $problem = content_types_definition_problem($data);
    if ($problem !== null) {
        throw new RuntimeException('Invalid content-type: ' . $problem);
    }

    return $data;
}

/**
 * Grund, warum die Klickziele einer Definition (aus content_types_read) ungültig sind, als Text aus
 * CONTENT_TYPES_INVALID_TEXT; null, wenn sie gültig ist.
 */
function content_types_definition_problem(array $def): ?string
{
    $name = (string) $def['name'];
    $show = static fn (mixed $value): string => is_string($value) ? $value : (string) json_encode($value, JSON_UNESCAPED_UNICODE);
    $actions = $def['actions'];
    if (!is_array($actions) || $actions === [] || array_values($actions) !== $actions) {
        return sprintf(CONTENT_TYPES_INVALID_TEXT['actions'], $name, implode(', ', array_keys(CONTENT_TYPES_ACTIONS)));
    }
    foreach ($actions as $action) {
        if (!is_string($action) || !isset(CONTENT_TYPES_ACTIONS[$action])) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['action'], $name, $show($action));
        }
    }
    foreach (array_count_values($actions) as $action => $count) {
        if ($count > 1) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['duplicate'], $name, $action);
        }
    }
    if (!in_array($def['defaultAction'], $actions, true)) {
        return sprintf(CONTENT_TYPES_INVALID_TEXT['defaultAction'], $name, $show($def['defaultAction']));
    }

    // Nur Felder, die es im Formular gibt (Namen wie bei jedem Schema): Ein titleField auf ein Feld mit
    // ungültigem Namen gäbe sonst jeder eigenen Seite einen leeren Titel.
    $fieldTypes = array_column(content_types_schema_columns($def), 'type', 'name');
    $fieldNames = array_keys($fieldTypes);
    if (in_array('page', $actions, true)) {
        $page = $def['page'] ?? null;
        if (!is_array($page) || !is_string($page['path'] ?? null) || !isset($page['titleField'], $page['descriptionField'])) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['page'], $name);
        }
        if (!is_safe_page_name($page['path'])) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['pagePath'], $name, $page['path']);
        }
        if (content_types_page_path_taken($page['path'])) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['pageTaken'], $name, $page['path']);
        }
        $other = array_search($page['path'], content_types_page_paths($name), true);
        if ($other !== false) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['pageShared'], $name, $page['path'], $other);
        }
        foreach (CONTENT_TYPES_PAGE_FIELD_TYPES as $key => $types) {
            if (!is_string($page[$key]) || !in_array($fieldTypes[$page[$key]] ?? null, $types, true)) {
                return sprintf(CONTENT_TYPES_INVALID_TEXT['pageField'], $name, $key, implode(', ', $types));
            }
        }
        if (isset($page['schema']) && !in_array($page['schema'], CONTENT_TYPES_PAGE_SCHEMAS, true)) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['pageSchema'], $name, implode(', ', CONTENT_TYPES_PAGE_SCHEMAS));
        }
    }

    foreach (content_types_action_field_names($actions) as $reserved) {
        if (in_array($reserved, $fieldNames, true)) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['reserved'], $name, $reserved);
        }
    }

    if (array_key_exists('orderBy', $def)) {
        $order = $def['orderBy'];
        if (!is_array($order) || !is_string($order['field'] ?? null)
            || !in_array($fieldTypes[$order['field']] ?? null, CONTENT_TYPES_ORDER_FIELD_TYPES, true)
            || !in_array($order['direction'] ?? 'asc', CONTENT_TYPES_ORDER_DIRECTIONS, true)) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['orderBy'], $name, implode(', ', CONTENT_TYPES_ORDER_FIELD_TYPES));
        }
    }
    foreach (CONTENT_TYPES_VISIBILITY_KEYS as $key) {
        if (array_key_exists($key, $def)
            && (!is_string($def[$key]) || !in_array($fieldTypes[$def[$key]] ?? null, CONTENT_TYPES_PUBLISH_FIELD_TYPES, true))) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT[$key], $name, implode(', ', CONTENT_TYPES_PUBLISH_FIELD_TYPES));
        }
    }
    $fallbacks = array_column(content_types_schema_columns($def), 'fallback', 'name');
    foreach (content_types_schema_columns($def) as $field) {
        if (array_key_exists('column', $field) && (!is_bool($field['column'])
            || ($field['column'] && !in_array($field['type'], CONTENT_TYPES_COLUMN_FIELD_TYPES, true)))) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['column'], $name, $field['name'], implode(', ', CONTENT_TYPES_COLUMN_FIELD_TYPES));
        }
        if ($field['type'] === 'select' && array_key_exists('optionsFrom', $field) && !content_types_options_source_valid($name, $field['optionsFrom'])) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['optionsFrom'], $name, $field['name']);
        }
        $from = $field['fallback'] ?? null;
        if (array_key_exists('fallback', $field) && (!in_array($field['type'], CONTENT_TYPES_FALLBACK_FIELD_TYPES, true)
            || !is_string($from) || $from === $field['name'] || isset($fallbacks[$from])
            || !in_array($fieldTypes[$from] ?? null, CONTENT_TYPES_FALLBACK_SOURCE_TYPES, true))) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['fallback'], $name, $field['name'], implode(', ', CONTENT_TYPES_FALLBACK_SOURCE_TYPES), implode('/', CONTENT_TYPES_FALLBACK_FIELD_TYPES));
        }
    }

    return null;
}

/** Ob $from (optionsFrom eines Feldes des Typs $name) ein anderer lesbarer Typ mit Titelfeld ist (content_types_title_field). */
function content_types_options_source_valid(string $name, mixed $from): bool
{
    if (!is_string($from) || $from === $name || !in_array($from, content_types_list_names(), true)) {
        return false;
    }
    try {
        return content_types_title_field(content_types_read($from)) !== null;
    } catch (Throwable $e) {
        return false;
    }
}

/** Feld, das einen Eintrag benennt: ein Textfeld name oder title, sonst das erste Textfeld; null ohne. */
function content_types_title_field(array $def): ?string
{
    $text = array_values(array_filter(content_types_schema_columns($def), static fn (array $field): bool => $field['type'] === 'text'));
    foreach ($text as $field) {
        if (in_array($field['name'], CONTENT_TYPES_TITLE_FIELDS, true)) {
            return $field['name'];
        }
    }

    return $text[0]['name'] ?? null;
}

/**
 * Auswahlfeld mit optionsFrom fürs Formular und Speichern: options sind die Titel der Einträge des anderen Typs
 * (ohne leere und doppelte), optionsCreate sagt dem Formular, wie es dort einen neuen anlegt. Ein Wert $current,
 * den es dort nicht mehr gibt (gelöscht; Umbenennen zieht content_types_rename_option mit), bleibt als Option, damit der Eintrag ihn behält.
 */
function content_types_options_from(array $field, mixed $current): array
{
    $source = content_types_load((string) $field['optionsFrom']);
    $title = (string) content_types_title_field($source);
    $options = [];
    foreach (content_types_fetch_list($source['name'], null, null, $source) as $row) {
        $value = $row[$title] ?? null;
        if (is_string($value) && $value !== '' && !in_array($value, $options, true)) {
            $options[] = $value;
        }
    }
    if (is_string($current) && $current !== '' && !in_array($current, $options, true)) {
        $options[] = $current;
    }
    unset($field['optionLabels']);

    return ['options' => $options, 'optionsCreate' => ['url' => CONTENT_TYPES_SAVE_URL, 'type' => $source['name'], 'field' => $title]] + $field;
}

/**
 * Ob page.path $path schon vergeben ist (le_site_path_taken). Eine Seite gleichen Namens ist erlaubt: /aktuelles
 * bleibt die Seite (etwa mit der Liste), /aktuelles/<slug> sind die Einträge, weil index.php Plugins erst ohne Datei
 * fragt. Ein Ordner oder eine Datei ohne Endung gleichen Namens und reservierte Adressen bleiben vergeben.
 */
function content_types_page_path_taken(string $path): bool
{
    if (!le_site_path_taken($path)) {
        return false;
    }
    $name = strtolower($path);
    if (in_array($name, array_map('strtolower', le_site_reserved_names()), true)) {
        return true;
    }
    $page = false;
    foreach (scandir(LE_SITE_ROOT) ?: [] as $entry) {
        if (strtolower($entry) === $name) {
            return true;
        }
        $page = $page || (le_site_is_document($entry) && strtolower(pathinfo($entry, PATHINFO_FILENAME)) === $name);
    }

    return !$page;
}

/** page.path der übrigen lesbaren Typen mit dem Ziel page (Typname → path), ohne $except. */
function content_types_page_paths(string $except): array
{
    $paths = [];
    foreach (content_types_list_names() as $name) {
        if ($name === $except) {
            continue;
        }
        try {
            $def = content_types_read($name);
        } catch (Throwable $e) {
            continue;
        }
        if (is_array($def['actions']) && in_array('page', $def['actions'], true) && is_string($def['page']['path'] ?? null)) {
            $paths[$name] = $def['page']['path'];
        }
    }

    return $paths;
}

/** Felder, die die Klickziele $actions brauchen: action ab zwei Zielen, url bei link, slug bei page. */
function content_types_action_field_names(array $actions): array
{
    $names = [];
    if (count($actions) > 1) {
        $names[] = 'action';
    }
    if (in_array('link', $actions, true)) {
        $names[] = 'url';
    }
    if (in_array('page', $actions, true)) {
        $names[] = 'slug';
    }

    return $names;
}

/**
 * Klickziel eines Eintrags: sein action, wenn der Typ es erlaubt, sonst defaultAction (Einträge ohne
 * Angabe, ältere oder importierte, und Ziele, die der Typ nicht mehr erlaubt). $def aus content_types_load.
 */
function content_types_item_action(array $def, array $item): string
{
    $action = $item['action'] ?? null;

    return content_types_action_allowed($def, $action) ? $action : $def['defaultAction'];
}

/** Ob $action ein Klickziel ist, das der Typ ($def aus content_types_load) erlaubt. */
function content_types_action_allowed(array $def, mixed $action): bool
{
    return is_string($action) && in_array($action, $def['actions'], true);
}

/**
 * Seitenleiste des Backends: je gültigem Typ ein Eintrag; gibt es ungültige oder unlesbare, steht
 * vorn ein Eintrag CONTENT_TYPES_INVALID_LABEL mit den Gründen (problems), die auch ins Log gehen.
 */
function content_types_admin_sidebar_entries(): array
{
    $entries = [];
    $problems = [...content_types_file_data()['problems'], ...content_types_orphaned_problems()];
    foreach (content_types_list_names() as $name) {
        try {
            $def = content_types_read($name);
        } catch (Throwable $e) {
            error_log('content-types: ' . $e->getMessage());
            $problems[] = sprintf(CONTENT_TYPES_INVALID_TEXT['unreadable'], $name);
            continue;
        }
        $problem = content_types_definition_problem($def);
        if ($problem !== null) {
            error_log('content-types: ' . $problem);
            $problems[] = $problem;
            continue;
        }
        $entries[] = [
            'name' => 'content-types',
            'route' => 'content-types/' . $name,
            'label' => (string) $def['label'],
            'hasAdminModule' => true,
            'hasSchema' => true,
            'type' => $name,
        ];
    }
    if ($problems !== []) {
        array_unshift($entries, [
            'name' => 'content-types',
            'route' => 'content-types',
            'label' => CONTENT_TYPES_INVALID_LABEL,
            'hasAdminModule' => true,
            'problems' => $problems,
        ]);
    }

    return $entries;
}

/** Hinweise auf Typen, die in typen.json fehlen, aber noch Einträge haben (CONTENT_TYPES_FILE_TEXT['orphaned']). */
function content_types_orphaned_problems(): array
{
    if (!db_available() || db_migration_running()) {
        return [];
    }
    $problems = [];
    try {
        $rows = db()->query('SELECT content_type, COUNT(*) AS n FROM content_items GROUP BY content_type ORDER BY content_type')->fetchAll();
    } catch (Throwable $e) {
        return [];
    }
    $names = content_types_list_names();
    foreach ($rows as $row) {
        if (!in_array($row['content_type'], $names, true)) {
            $problems[] = sprintf(CONTENT_TYPES_FILE_TEXT['orphaned'], $row['content_type'], (int) $row['n']);
        }
    }

    return $problems;
}

/** Felder des Typs ($def aus content_types_read), ohne die Klickziel-Felder; gültig wie bei jedem Schema (plugin_schema_columns). */
function content_types_schema_columns(array $def): array
{
    return plugin_schema_columns(['schema' => ['fields' => $def['fields']]]);
}

/**
 * Felder des Formulars (Backend und Website) und fürs Speichern: vor denen des Typs die Klickziel-Felder
 * (content_types_action_field_names). „Beim Klick“ bietet nur die erlaubten Ziele, vorausgewählt
 * defaultAction; Link und Adresse erscheinen nur beim passenden Ziel (showWhen), bei genau einem
 * Ziel immer. Auswahlfelder mit optionsFrom bekommen ihre Werte (content_types_options_from; $stored ist
 * der gespeicherte Eintrag beim Bearbeiten). Die Ausgabe auf der Website nutzt content_types_schema_columns.
 */
function content_types_form_columns(array $def, ?array $stored = null): array
{
    $actions = array_values(array_intersect(array_keys(CONTENT_TYPES_ACTIONS), $def['actions']));
    $choice = count($actions) > 1;
    $when = static fn (string $action): array => $choice ? ['showWhen' => ['field' => 'action', 'value' => $action]] : [];
    $fields = [
        'action' => [
            'type' => 'select',
            'required' => true,
            'options' => $actions,
            'optionLabels' => array_intersect_key(CONTENT_TYPES_ACTIONS, array_flip($actions)),
            'default' => $def['defaultAction'],
        ],
        'url' => ['type' => 'url'] + ($choice ? $when('link') : ['required' => true]),
        // prefix: Anfang der Adresse, den das Formular vor den Slug schreibt (/aktuelles/).
        'slug' => ['type' => 'slug', 'from' => $def['page']['titleField'] ?? null, 'prefix' => isset($def['page']['path']) ? '/' . $def['page']['path'] . '/' : ''] + $when('page'),
    ];

    $columns = [];
    foreach (content_types_action_field_names($def['actions']) as $name) {
        $columns[] = ['name' => $name, 'label' => CONTENT_TYPES_ACTION_FIELDS[$name]] + $fields[$name];
    }

    foreach (content_types_schema_columns($def) as $field) {
        $columns[] = $field['type'] === 'select' && isset($field['optionsFrom'])
            ? content_types_options_from($field, $stored[$field['name']] ?? null)
            : $field;
    }

    return $columns;
}

/**
 * Klickziel-Werte nach plugin_schema_values: Ein Link, der nur beim Ziel link erscheint (showWhen), ist
 * dann Pflicht (Meldung wie ein Pflichtfeld; bei genau einem Ziel ist er schon im Schema required);
 * mit dem Ziel page bekommt jeder Eintrag eine Adresse (slug, sonst aus titleField), eindeutig im Typ.
 */
function content_types_action_values(array $def, array $columns, array $values, ?int $id): array
{
    $byName = array_column($columns, null, 'name');
    $url = $byName['url'] ?? null;
    if (isset($url['showWhen']) && content_types_item_action($def, $values) === 'link' && plugin_schema_blank($url, $values['url'] ?? '')) {
        throw plugin_schema_required_error($url);
    }
    if (isset($byName['slug'])) {
        $slug = $values['slug'] ?? plugin_schema_normalize_value($byName['slug'], '', $values);
        $used = content_types_slugs_in_use((string) $def['name'], $id);
        $values['slug'] = plugin_unique_slug_with($slug, static fn (string $candidate): bool => in_array($candidate, $used, true));
    }

    return $values;
}

/** Adressen (slug) der übrigen Einträge eines Typs; die Einträge stehen als JSON in data, daher in PHP gelesen. */
function content_types_slugs_in_use(string $type, ?int $id): array
{
    $stmt = db()->prepare('SELECT id, data FROM content_items WHERE content_type = ? AND id <> ?');
    $stmt->execute([$type, $id ?? 0]);
    $slugs = [];
    foreach ($stmt->fetchAll() as $row) {
        $slug = content_types_expand_row($row)['slug'] ?? null;
        if (is_string($slug)) {
            $slugs[] = $slug;
        }
    }

    return $slugs;
}

/**
 * Einträge eines Typs in Listenreihenfolge, höchstens $limit (1 bis CONTENT_TYPES_LIST_MAX; null: alle, z. B.
 * fürs Backend, das jeden Eintrag zeigt, auch nach mehreren Importen). $filter [feld, wert]
 * (content_types_list_filter) behält nur Einträge, deren gespeicherter Wert gleich ist; verglichen wird in
 * PHP, weil die Werte als JSON in data stehen (JSON-SQL unterscheidet sich zwischen SQLite und MySQL). Dafür
 * wird der Typ ohne LIMIT gelesen, bis $limit Treffer da sind. $def (content_types_load) mit orderBy sortiert
 * nach dem Feld (dafür alle Einträge gelesen), $public lässt mit publishField/expireField die noch nicht fälligen
 * und abgelaufenen weg.
 */
function content_types_fetch_list(string $type, ?int $limit = 100, ?array $filter = null, ?array $def = null, bool $public = false): array
{
    if (!content_types_name_valid($type)) {
        return [];
    }
    $limit = $limit === null ? null : max(1, min(CONTENT_TYPES_LIST_MAX, $limit));
    $ordered = isset($def['orderBy']);
    $hidden = $public && (isset($def['publishField']) || isset($def['expireField']));
    $stmt = db()->prepare(
        "SELECT id, data, sort_order, created_at, updated_at
         FROM content_items
         WHERE content_type = ?
         ORDER BY " . CONTENT_TYPES_ORDER .
        ($filter === null && !$ordered && !$hidden && $limit !== null ? " LIMIT {$limit}" : '')
    );
    $stmt->execute([$type]);
    $rows = [];
    $now = db_now();
    while (($ordered || $limit === null || count($rows) < $limit) && ($row = $stmt->fetch()) !== false) {
        $row = content_types_expand_row($row);
        if ($filter !== null && (!is_scalar($row[$filter[0]] ?? '') || (string) ($row[$filter[0]] ?? '') !== $filter[1])) {
            continue;
        }
        if ($hidden && !content_types_published($def, $row, $now)) {
            continue;
        }
        $rows[] = $row;
    }
    $stmt->closeCursor();
    if ($ordered) {
        $rows = content_types_sort_rows($def, $rows);
    }

    return $limit === null ? $rows : array_slice($rows, 0, $limit);
}

/** Ob ein Eintrag auf der Website erscheint (content_types_visibility ohne Einschränkung). */
function content_types_published(array $def, array $row, ?string $now = null): bool
{
    return content_types_visibility($def, $row, $now) === null;
}

/**
 * Warum ein Eintrag auf der Website fehlt: CONTENT_TYPES_SCHEDULED, solange das Datum in publishField noch nicht
 * erreicht ist, CONTENT_TYPES_EXPIRED, wenn das in expireField vorbei ist, sonst null (leer zählt nie). $now wie
 * db_now(); ein Tag „2026-11-02“ ist ab Mitternacht fällig, weil er als Text davor sortiert, und bleibt bis zu
 * seinem Ende, weil nur der Tag von $now verglichen wird.
 */
function content_types_visibility(array $def, array $row, ?string $now = null): ?string
{
    $now ??= db_now();
    $from = isset($def['publishField']) ? ($row[$def['publishField']] ?? null) : null;
    $until = isset($def['expireField']) ? ($row[$def['expireField']] ?? null) : null;
    if (is_string($from) && $from !== '' && $from > $now) {
        return CONTENT_TYPES_SCHEDULED;
    }
    if (is_string($until) && $until !== '' && $until < substr($now, 0, strlen($until))) {
        return CONTENT_TYPES_EXPIRED;
    }
    return null;
}

/**
 * Felder, die die Liste im Backend als Spalten zeigt (Namen, in der Reihenfolge des Typs): die mit "column": true,
 * ohne solche das erste Bild und das erste Datum aus orderBy, publishField, expireField.
 */
function content_types_admin_columns(array $def): array
{
    $fields = content_types_schema_columns($def);
    $chosen = array_column(array_filter($fields, static fn (array $field): bool => ($field['column'] ?? false) === true), 'name');
    if ($chosen !== []) {
        return $chosen;
    }
    $types = array_column($fields, 'type', 'name');
    $image = array_search('image', $types, true);
    $date = null;
    foreach ([$def['orderBy']['field'] ?? null, $def['publishField'] ?? null, $def['expireField'] ?? null] as $name) {
        if (is_string($name) && in_array($types[$name] ?? null, CONTENT_TYPES_PUBLISH_FIELD_TYPES, true)) {
            $date = $name;
            break;
        }
    }
    return array_values(array_filter(array_keys($types), static fn (string $name): bool => $name === $image || $name === $date));
}

/**
 * Einträge nach orderBy ($def aus content_types_load): Zahlen als Zahl, sonst als Text; ohne Wert gilt bei
 * date/datetime das Anlegedatum, sonst steht der Eintrag am Ende. Gleiche Werte behalten die Listenreihenfolge.
 */
function content_types_sort_rows(array $def, array $rows): array
{
    $field = (string) $def['orderBy']['field'];
    $type = array_column(content_types_schema_columns($def), 'type', 'name')[$field] ?? 'text';
    $desc = ($def['orderBy']['direction'] ?? 'asc') === 'desc';
    $key = static function (array $row) use ($field, $type): mixed {
        $value = $row[$field] ?? null;
        if ($value === null || $value === '') {
            return in_array($type, ['date', 'datetime'], true) ? (string) $row['created_at'] : null;
        }
        return $type === 'number' ? (float) $value : (string) $value;
    };
    $keyed = array_map(static fn (array $row, int $index): array => [$key($row), $index, $row], $rows, array_keys($rows));
    usort($keyed, static function (array $a, array $b) use ($desc): int {
        if ($a[0] === null || $b[0] === null) {
            return ($a[0] === null) <=> ($b[0] === null) ?: $a[1] <=> $b[1];
        }
        $cmp = is_string($a[0]) ? strcmp($a[0], $b[0]) : $a[0] <=> $b[0];
        return ($desc ? -$cmp : $cmp) ?: $a[1] <=> $b[1];
    });

    return array_column($keyed, 2);
}

/**
 * data-filter einer Liste als [feld, wert]; null ohne Attribut. Wirft, wenn das Trennzeichen fehlt oder
 * das Feld kein einfaches Feld des Typs ist ($schema aus content_types_schema_columns, list zählt nicht).
 */
function content_types_list_filter(array $schema, ?string $raw): ?array
{
    if ($raw === null) {
        return null;
    }
    $parts = explode(CONTENT_TYPES_FILTER_SEPARATOR, $raw, 2);
    $fields = array_column($schema, 'type', 'name');
    if (count($parts) !== 2 || !isset($fields[$parts[0]]) || in_array($fields[$parts[0]], ['list', 'blocks'], true)) {
        throw new InvalidArgumentException('unknown filter field: ' . $parts[0]);
    }

    return $parts;
}

/** data-limit einer Liste: ganze Zahl ab 1, sonst CONTENT_TYPES_LIST_LIMIT; höchstens CONTENT_TYPES_LIST_MAX. */
function content_types_list_limit(?string $raw): int
{
    $limit = filter_var($raw, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);

    return $limit === false ? CONTENT_TYPES_LIST_LIMIT : min($limit, CONTENT_TYPES_LIST_MAX);
}

function content_types_fetch_by_id(string $type, int $id): ?array
{
    if (!content_types_name_valid($type) || $id <= 0) {
        return null;
    }
    $stmt = db()->prepare(
        'SELECT id, data, sort_order, created_at, updated_at
         FROM content_items WHERE content_type = ? AND id = ? LIMIT 1'
    );
    $stmt->execute([$type, $id]);
    $row = $stmt->fetch();

    return $row ? content_types_expand_row($row) : null;
}

/** Stand eines Eintrags für die Konfliktprüfung (plugin_entry_version); die Reihenfolge zählt nicht mit. */
function content_types_entry_version(array $row): string
{
    return plugin_entry_version($row, ['sort_order']);
}

/** Eintrag eines Typs mit der Adresse (slug) $slug; data ist JSON, daher in PHP verglichen. */
function content_types_fetch_by_slug(string $type, string $slug): ?array
{
    if (!content_types_name_valid($type)) {
        return null;
    }
    $stmt = db()->prepare(
        'SELECT id, data, sort_order, created_at, updated_at
         FROM content_items WHERE content_type = ? ORDER BY ' . CONTENT_TYPES_ORDER
    );
    $stmt->execute([$type]);
    foreach ($stmt->fetchAll() as $row) {
        $item = content_types_expand_row($row);
        if (($item['slug'] ?? null) === $slug) {
            return $item;
        }
    }

    return null;
}

/** Gültiger Typ mit dem Ziel page, dessen page.path $path ist; null ohne. Ungültige Typen zählen nicht. */
function content_types_page_type(string $path): ?array
{
    foreach (content_types_list_names() as $name) {
        try {
            $def = content_types_load($name);
        } catch (Throwable $e) {
            continue;
        }
        if (in_array('page', $def['actions'], true) && $def['page']['path'] === $path) {
            return $def;
        }
    }

    return null;
}

/**
 * Hook site_page: eigene Seite eines Eintrags unter /<page.path>/<slug>. Adressen unter page.path eines
 * gültigen Typs gehören dem Plugin; ohne passenden Eintrag mit Ziel page → PLUGIN_SITE_PAGE_NOT_FOUND.
 */
function content_types_site_page(string $path): ?array
{
    if (!preg_match('#^/([^/]+)(?:/([^/]*))?/?$#', $path, $m)) {
        return null;
    }
    $def = content_types_page_type($m[1]);
    if ($def === null) {
        return null;
    }
    require_once __DIR__ . '/template.php';
    $slug = $m[2] ?? '';
    $row = preg_match(PLUGIN_SLUG_PATTERN, $slug) ? content_types_fetch_by_slug($def['name'], $slug) : null;
    // Noch nicht fällig (publishField) oder abgelaufen (expireField): wie ein fehlender Eintrag.
    if ($row !== null && !content_types_published($def, $row)) {
        $row = null;
    }

    return ($row === null ? null : content_types_page($def, $row)) ?? PLUGIN_SITE_PAGE_NOT_FOUND;
}

/**
 * Hook sitemap_urls: eigene Seiten aller veröffentlichten Einträge mit Ziel page (gültige Typen), zuletzt geändert
 * am updated_at des Eintrags.
 */
function content_types_sitemap_urls(): array
{
    require_once __DIR__ . '/template.php';
    $urls = [];
    foreach (content_types_list_names() as $name) {
        try {
            $def = content_types_load($name);
        } catch (Throwable $e) {
            continue;
        }
        if (!in_array('page', $def['actions'], true)) {
            continue;
        }
        foreach (content_types_fetch_list($name, null, null, $def, true) as $row) {
            $target = content_types_item_target(content_types_template_item($def, $row));
            if ($target['action'] === 'page') {
                $urls[] = ['path' => $target['href'], 'lastmod' => (string) ($row['updated_at'] ?? '')];
            }
        }
    }

    return $urls;
}

/**
 * Hook filter_site_html: Seiten mit einer Liste eines Typs mit modal (CONTENT_TYPES_MODAL_LIST_ATTR, vom
 * Renderer gesetzt) bekommen einmal Modal-Skript und -CSS vor das letzte </body>; sonst unverändert.
 */
function content_types_filter_site_html(string $html): string
{
    require_once __DIR__ . '/template.php';
    $pos = strripos($html, '</body>');
    if ($pos === false || !str_contains($html, ' ' . CONTENT_TYPES_MODAL_LIST_ATTR) || str_contains($html, CONTENT_TYPES_MODAL_ASSETS['script'])) {
        return $html;
    }
    $tags = '<link rel="stylesheet" href="' . CONTENT_TYPES_MODAL_ASSETS['style'] . '">'
        . '<script src="' . CONTENT_TYPES_MODAL_ASSETS['script'] . '" defer></script>';

    return substr_replace($html, $tags, $pos, 0);
}

function content_types_expand_row(array $row): array
{
    $data = json_decode((string) ($row['data'] ?? '{}'), true);
    if (!is_array($data)) {
        $data = [];
    }
    unset($row['data']);
    return $row + $data;
}

/**
 * Speichert einen Eintrag (neu ohne $id, am Ende der Liste). Beim Bearbeiten werden danach Bilder gelöscht,
 * die der Eintrag nicht mehr nutzt (ersetzt, Zeile entfernt), sofern sie sonst nirgends verwendet werden.
 * Liefert die id; 0, wenn es den Eintrag $id dieses Typs nicht (mehr) gibt (api/save.php antwortet dann 404).
 */
function content_types_save(string $type, array $rawValues, ?int $id = null): int
{
    if (!content_types_name_valid($type)) {
        throw new InvalidArgumentException(API_TEXT['invalidType']);
    }
    $def = content_types_load($type);
    if ($id === null || $id <= 0) {
        return content_types_insert($type, content_types_values($def, $rawValues, null));
    }
    $stored = content_types_fetch_by_id($type, $id);
    if ($stored === null) {
        return 0;
    }
    $values = content_types_values($def, $rawValues, $id);

    $fields = content_types_schema_columns($def);
    $before = plugin_schema_image_values($fields, $stored);
    $title = content_types_title_field($def);
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('UPDATE content_items SET data = ?, updated_at = ? WHERE content_type = ? AND id = ?');
        $stmt->execute([plugin_schema_json($values), db_now(), $type, $id]);
        if ($title !== null) {
            content_types_rename_option($type, $id, $stored[$title] ?? null, $values[$title] ?? null);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    delete_unused_uploads(array_diff($before, plugin_schema_image_values($fields, $values)));

    return $id;
}

/**
 * Geprüfte Werte eines Eintrags ($def aus content_types_load) wie beim Speichern: Klickziel (ohne erlaubtes
 * gilt defaultAction), Felder nach Schema, Link und Adresse; $id beim Bearbeiten, sonst null. Wirft
 * InvalidArgumentException (PluginFieldException mit Feld) bei ungültigen Werten.
 */
function content_types_values(array $def, array $rawValues, ?int $id): array
{
    $type = (string) $def['name'];
    if (count($def['actions']) > 1) {
        // Ohne erlaubtes Ziel (ältere Einträge, importierte ohne action) gilt defaultAction.
        $rawValues['action'] = content_types_item_action($def, $rawValues);
    }

    $stored = $id !== null && $id > 0 ? content_types_fetch_by_id($type, $id) : null;
    $columns = content_types_form_columns($def, $stored);
    // Versteckte Felder (showWhen passt nicht zum Ziel: Link, Adresse) zählen nicht und blockieren nie:
    // Es bleibt der gespeicherte Wert, ohne ihn entfällt das Feld (die Adresse kommt dann aus titleField).
    foreach ($columns as $column) {
        $when = $column['showWhen'] ?? null;
        if ($when !== null && ($rawValues[$when['field']] ?? null) !== $when['value']) {
            unset($rawValues[$column['name']]);
            if (isset($stored[$column['name']])) {
                $rawValues[$column['name']] = $stored[$column['name']];
            }
        }
    }

    return content_types_action_values($def, $columns, plugin_schema_values($columns, $rawValues, $stored ?? []), $id);
}

/**
 * Umbenannter Eintrag $id des Typs $type, dessen Titel ein Auswahlwert anderer Typen ist (optionsFrom): Deren
 * Einträge mit dem alten Titel $old bekommen den neuen $new. Nicht, solange ein anderer Eintrag des Typs den alten
 * Titel noch trägt (doppelte Werte zählen in der Auswahl einmal). Läuft in der Transaktion des Speicherns.
 */
function content_types_rename_option(string $type, int $id, mixed $old, mixed $new): void
{
    if (!is_string($old) || !is_string($new) || $old === '' || $new === '' || $old === $new) {
        return;
    }
    $targets = [];
    foreach (content_types_list_names() as $name) {
        try {
            $def = content_types_read($name);
        } catch (Throwable $e) {
            continue;
        }
        foreach (content_types_schema_columns($def) as $field) {
            if ($field['type'] === 'select' && ($field['optionsFrom'] ?? null) === $type) {
                $targets[$name][] = $field['name'];
            }
        }
    }
    if ($targets === []) {
        return;
    }
    $title = (string) content_types_title_field(content_types_read($type));
    foreach (content_types_fetch_list($type, null) as $row) {
        if ((int) $row['id'] !== $id && ($row[$title] ?? null) === $old) {
            return;
        }
    }
    $select = db()->prepare('SELECT id, data FROM content_items WHERE content_type = ?');
    $update = db()->prepare('UPDATE content_items SET data = ?, updated_at = ? WHERE id = ?');
    $now = db_now();
    foreach ($targets as $name => $names) {
        $select->execute([$name]);
        foreach ($select->fetchAll() as $row) {
            $data = json_decode((string) $row['data'], true);
            if (!is_array($data)) {
                continue;
            }
            $changed = false;
            foreach ($names as $field) {
                if (($data[$field] ?? null) === $old) {
                    $data[$field] = $new;
                    $changed = true;
                }
            }
            if ($changed) {
                $update->execute([plugin_schema_json($data), $now, $row['id']]);
            }
        }
    }
}

/** Legt einen Eintrag mit geprüften Werten (content_types_values) am Ende der Liste an; liefert die id. */
function content_types_insert(string $type, array $values): int
{
    $stmt = db()->prepare('SELECT MAX(sort_order) FROM content_items WHERE content_type = ?');
    $stmt->execute([$type]);
    $max = $stmt->fetchColumn();
    $sortOrder = $max === null ? 0 : (int) $max + 1;

    $now = db_now();
    $stmt = db()->prepare('INSERT INTO content_items (content_type, data, sort_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$type, plugin_schema_json($values), $sortOrder, $now, $now]);
    return (int) db()->lastInsertId();
}

/**
 * Importiert $entries (Liste von Einträgen, höchstens CONTENT_TYPES_IMPORT_MAX) ganz oder gar nicht: jeder
 * wird wie beim Speichern geprüft (content_types_values), ein action muss der Typ erlauben (ohne gilt
 * defaultAction), Bilder müssen vorhandene Dateien sein (upload_image_exists). Neue Einträge kommen in
 * dieser Reihenfolge ans Ende; Adressen (slug) sind eindeutig, auch untereinander, weil jeder Eintrag in
 * derselben Transaktion eingefügt ist, bevor der nächste geprüft wird. Liefert die Anzahl.
 * Wirft InvalidArgumentException (Liste, Anzahl, kein Objekt) bzw. PluginFieldException mit entry.
 */
function content_types_import(string $type, mixed $entries): int
{
    if (!content_types_name_valid($type)) {
        throw new InvalidArgumentException(API_TEXT['invalidType']);
    }
    if (!is_array($entries) || array_values($entries) !== $entries) {
        throw new InvalidArgumentException(CONTENT_TYPES_IMPORT_TEXT['notList']);
    }
    if ($entries === []) {
        throw new InvalidArgumentException(CONTENT_TYPES_IMPORT_TEXT['empty']);
    }
    if (count($entries) > CONTENT_TYPES_IMPORT_MAX) {
        throw new InvalidArgumentException(sprintf(CONTENT_TYPES_IMPORT_TEXT['tooMany'], CONTENT_TYPES_IMPORT_MAX));
    }
    $def = content_types_load($type);
    $fields = content_types_schema_columns($def);

    $pdo = db();
    $pdo->beginTransaction();
    try {
        foreach ($entries as $index => $entry) {
            if (!is_array($entry) || ($entry !== [] && array_values($entry) === $entry)) {
                throw new InvalidArgumentException(sprintf(CONTENT_TYPES_IMPORT_TEXT['entry'], $index + 1));
            }
            try {
                content_types_insert($type, content_types_import_values($def, $fields, $entry));
            } catch (PluginFieldException $e) {
                $e->entry = $index + 1;
                throw $e;
            }
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }

    return count($entries);
}

/**
 * Werte eines importierten Eintrags: content_types_values, dazu nur erlaubte Ziele (außer action ist ein
 * eigenes Feld des Typs, bei genau einem Ziel erlaubt) und vorhandene Bilder ($fields: content_types_schema_columns).
 * Bilder zählen wie angegeben und bereinigt: Ein Wert, den die Bereinigung leert (data:, ftp: …), wird abgelehnt.
 * Die angegebenen prüft es vor content_types_values: Fehlt ein Upload, gilt diese Meldung, nicht die des Speicherns.
 */
function content_types_import_values(array $def, array $fields, array $entry): array
{
    $ownAction = in_array('action', array_column($fields, 'name'), true);
    if (!$ownAction && array_key_exists('action', $entry) && !content_types_action_allowed($def, $entry['action'])) {
        $message = sprintf(CONTENT_TYPES_IMPORT_TEXT['action'], implode(', ', $def['actions']));
        throw plugin_schema_field_error('action', CONTENT_TYPES_ACTION_FIELDS['action'], $message);
    }
    $requireImages = static function (array $values) use ($fields): void {
        foreach ($fields as $field) {
            foreach (plugin_schema_image_values([$field], $values) as $url) {
                if (trim($url) !== '' && !upload_image_exists(trim($url))) {
                    $message = sprintf(CONTENT_TYPES_IMPORT_TEXT['image'], UPLOADS_URL, LE_SITE_FILES_URL);
                    throw plugin_schema_field_error($field['name'], plugin_schema_field_label($field), $message);
                }
            }
        }
    };
    $requireImages($entry);
    $values = content_types_values($def, $entry, null);
    $requireImages($values);

    return $values;
}

/** Meldung zu einem ungültigen importierten Eintrag: „Zeile 3, Titel: Pflichtfeld ist leer.“ */
function content_types_import_message(PluginFieldException $e): string
{
    return sprintf(CONTENT_TYPES_IMPORT_TEXT['line'], $e->entry, $e->label, $e->reason);
}

/**
 * Tauscht einen Eintrag mit seinem Nachbarn ($step -1 = nach oben, 1 = nach unten) bzw. mit dem
 * Eintrag $with (sichtbarer Nachbar in einer gefilterten oder gekürzten Liste; die übrigen bleiben,
 * wo sie sind) und nummeriert den Typ dabei durch. Liefert false, wenn es einen der Einträge nicht
 * gibt, er schon am Rand steht oder der Typ nach einem Feld sortiert (orderBy).
 */
function content_types_move(string $type, int $id, int $step, ?int $with = null): bool
{
    if (!content_types_name_valid($type) || $id <= 0) {
        return false;
    }
    // Mit orderBy bestimmt das Feld die Reihenfolge, von Hand verschieben gibt es nicht.
    if (isset(content_types_load($type)['orderBy'])) {
        return false;
    }
    $stmt = db()->prepare('SELECT id FROM content_items WHERE content_type = ? ORDER BY ' . CONTENT_TYPES_ORDER);
    $stmt->execute([$type]);
    $ids = array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));

    $pos = array_search($id, $ids, true);
    $target = $pos === false ? false : ($with === null ? $pos + $step : array_search($with, $ids, true));
    if ($target === false || $target === $pos || $target < 0 || $target >= count($ids)) {
        return false;
    }
    [$ids[$pos], $ids[$target]] = [$ids[$target], $ids[$pos]];

    $pdo = db();
    $update = $pdo->prepare('UPDATE content_items SET sort_order = ? WHERE content_type = ? AND id = ?');
    $pdo->beginTransaction();
    try {
        foreach ($ids as $index => $itemId) {
            $update->execute([$index, $type, $itemId]);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }

    return true;
}

/** Löscht den Eintrag samt seinen Bildern, sofern sie sonst nirgends verwendet werden (core/uploads.php). */
function content_types_delete(string $type, int $id): void
{
    if (!content_types_name_valid($type) || $id <= 0) {
        return;
    }
    plugin_delete_entry('content-types', $id, ['content_type' => $type]);
}

/**
 * Hook image_values (core/uploads.php): Bildwerte einer Zeile aus content_items laut Typ-Definition.
 * Für die Felder reicht content_types_read: Auch ein bei den Klickzielen ungültiger Typ verliert beim
 * Löschen eines Eintrags seine Bilder.
 */
function content_types_image_values(array $row): array
{
    return plugin_schema_image_values(content_types_schema_columns(content_types_read((string) $row['content_type'])), content_types_expand_row($row));
}

/** Hook upload_in_use (core/uploads.php): verweist ein Eintrag irgendeines Typs auf die Upload-Datei? */
function content_types_upload_in_use(string $file): bool
{
    $stmt = db()->prepare('SELECT 1 FROM content_items WHERE INSTR(data, ?) > 0 LIMIT 1');
    $stmt->execute([$file]);

    return $stmt->fetchColumn() !== false;
}

/** Hook entry_label (core/plugins.php): Titel eines Eintrags (content_types_title_field), sonst seine Adresse; '' ohne. */
function content_types_entry_label(string $table, array $row): string
{
    if ($table !== 'content_items') {
        return '';
    }
    $item = content_types_expand_row($row);
    try {
        $title = content_types_title_field(content_types_read((string) $row['content_type']));
    } catch (Throwable $e) {
        $title = null; // Typ unbekannt: dann die Adresse
    }
    // Ohne Typ-Definition die üblichen Titelfelder.
    foreach ([$title, ...CONTENT_TYPES_TITLE_FIELDS, 'slug'] as $field) {
        if ($field !== null && is_string($item[$field] ?? null) && $item[$field] !== '') {
            return $item[$field];
        }
    }

    return '';
}

/**
 * Hook entry_problem (core/plugins.php): Ein eingespielter Eintrag braucht einen Typ, den es online gibt, und eine
 * Adresse (slug), die kein anderer Eintrag des Typs hat. Sieht den neuen Stand, auch die übrigen eingespielten Einträge.
 */
function content_types_entry_problem(string $table, array $row): ?string
{
    if ($table !== 'content_items') {
        return null;
    }
    $type = (string) $row['content_type'];
    if (!in_array($type, content_types_list_names(), true)) {
        return sprintf(CONTENT_TYPES_DATA_TEXT['unknownType'], $type);
    }
    $slug = content_types_expand_row($row)['slug'] ?? null;
    if (is_string($slug) && $slug !== '' && in_array($slug, content_types_slugs_in_use($type, (int) $row['id']), true)) {
        return sprintf(CONTENT_TYPES_DATA_TEXT['slugTaken'], $slug);
    }

    return null;
}

/** Hook action_entry_updated (core/plugins.php): Umbenannter Eintrag → Auswahlwerte anderer Typen ziehen nach (content_types_rename_option). */
function content_types_action_entry_updated(string $table, array $before, array $after): void
{
    $type = (string) ($after['content_type'] ?? '');
    // Unbekannten Typ meldet content_types_entry_problem.
    if ($table !== 'content_items' || $before['content_type'] !== $type || !in_array($type, content_types_list_names(), true)) {
        return;
    }
    $title = content_types_title_field(content_types_read($type));
    if ($title !== null) {
        content_types_rename_option($type, (int) $after['id'], content_types_expand_row($before)[$title] ?? null, content_types_expand_row($after)[$title] ?? null);
    }
}
