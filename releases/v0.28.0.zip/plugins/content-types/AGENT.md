# Content-Types Plugin — Anleitung für KI-Agenten

Dieses Plugin verwaltet kundenspezifische Content-Typen. Wenn der User dich bittet, einen neuen Content-Typ anzulegen, folge dieser Anleitung exakt.

## Was du tust

Du ergänzt **ein Objekt** in der Liste `public/site/includes/content-types/typen.json` (alle Typen der Website in einer Datei; fehlt sie, legst du sie als JSON-Array an). Sonst nichts.

**Du fasst NICHT an:**

- `plugins/content-types/lib.php` oder andere PHP-Dateien
- `plugins/content-types/install.sql`, `install.sqlite.sql` (und die uninstall-Dateien)
- Die DB direkt
- Andere Plugins

## Workflow

1. User nennt dir Typ-Namen + gewünschte Felder
2. Schau in `plugins/content-types/presets/` nach einer passenden Vorlage
3. Wenn eine passt: übernimm sie in `typen.json` und passe sie an
4. Wenn keine passt: ergänze ein neues Objekt nach unten stehendem Schema

## Datei-Schema

```json
{
  "name": "<typname>",
  "label": "<Lesbarer Name>",
  "fields": [
    { "name": "<feldname>", "label": "<Label>", "type": "<typ>", "required": <true|false> }
  ]
}
```

### Regeln für `name`

- **Datei-Name** = `<name>.json` — beide müssen exakt gleich sein
- Erlaubte Zeichen: kleinbuchstaben, Ziffern, `-`, `_`
- Muss mit einem Buchstaben anfangen
- Beispiele: `referenzen`, `leistungen`, `fakten`, `case-studies`

### Regeln für `fields[].name`

- Erlaubte Zeichen: kleinbuchstaben, Ziffern, `_` (KEIN Bindestrich)
- Muss mit einem Buchstaben anfangen
- Beispiele: `title`, `kunde`, `logo_url`, `published_at`

### Verfügbare Feld-Typen

| Type | Verwendung | Input-Render |
|------|------------|--------------|
| `text` | Kurzer reiner Text, wörtlich gespeichert (`<` bleibt), Ausgabe mit `ct_text` | `<input type="text">` |
| `textarea` | Mehrzeiliger reiner Text ohne Formatierung, wörtlich gespeichert (Umbrüche bleiben), Ausgabe mit `ct_lines` | `<textarea>` |
| `richtext` | HTML-Editor (eingeschränkt, sicher) | `<textarea>` |
| `image` | Pfad zu einem Bild in `/public/site/uploads/...` | `<input type="text">` mit Placeholder |
| `datetime` | Datum + Uhrzeit | `<input type="datetime-local">` |
| `date` | Kalendertag (`YYYY-MM-DD`) | `<input type="date">` |
| `number` | Zahl | `<input type="number">` |
| `boolean` | Ja/Nein | `<input type="checkbox">` |
| `slug` | URL-Slug, aus anderem Feld generiert via `from` | `<input type="text">` |
| `select` | Auswahl aus festen Werten (`options: [...]`) oder aus den Einträgen eines anderen Typs (`optionsFrom: "<typ>"`, siehe README) | `<select>`, mit `optionsFrom` dazu „+ <Label> hinzufügen“ |
| `icon` | Name eines Icons aus dem Satz des Seiten-Editors (Lucide), Ausgabe mit `ct_icon` | Raster aller Icons mit Suche wie im Seiten-Editor |
| `url` | Link: `https://`, `http://`, `mailto:`, `tel:` oder Pfad ab `/` bzw. `#` (anderes lehnt der Server ab) | `<input type="text" inputmode="url">` |
| `list` | Wiederholbare Zeilen mit Unterfeldern (`fields`), optional `itemLabel` (Singular), `min` (Vorgabe 0), `max` (Vorgabe 50) | je Zeile eine Karte, „+ <itemLabel> hinzufügen“ |
| `blocks` | Kleiner Builder: Blöcke aus `text`, `bild`, `galerie`, `zitat`, `downloads` in beliebiger Reihenfolge, optional `blocks: [...]` (erlaubte Arten, Vorgabe alle), Ausgabe mit `ct_blocks` (README, „blocks“) | Karten mit „+ Text“, „+ Bild“ …, Ziehen zum Sortieren |

### Unterfelder von `list`

- Erlaubt: `text`, `textarea`, `richtext`, `image`, `url`, `number`, `boolean`, `select`, `icon`. Kein `list`, `slug` oder `datetime` (solche Unterfelder fallen weg).
- Namen wie bei `fields[].name`; `required` gilt nur für Zeilen mit Inhalt (leere Zeilen fallen weg).
- `min`/`max` als ganze Zahl (min ab 0, max ab 1, max nicht unter min), sonst gelten 0/50.
- `itemLabel` ist das Wort für eine Zeile im Singular („Punkt“), `label` der Plural („Punkte“).

```json
{ "name": "features", "label": "Punkte", "itemLabel": "Punkt", "type": "list", "max": 12,
  "fields": [
    { "name": "title", "label": "Überschrift", "type": "text", "required": true },
    { "name": "text", "label": "Text", "type": "text" }
  ] }
```

### `column: true`

Optional an Feldern der Arten `text`, `textarea`, `number`, `date`, `datetime`, `select`, `boolean`, `image`, `url`: Das Feld erscheint in der Liste im Backend als Spalte. Nur die zwei, drei Felder markieren, an denen der Kunde Einträge erkennt (Datum, Ort, Kategorie). Ohne Angabe zeigt die Liste das erste Bild und das Datum aus `orderBy`/`publishField`/`expireField`.

### `fallback: "<feld>"`

Optional an `text`/`textarea` (nicht in `list`). Leer zeigt das Feld auf der Website den Anfang des genannten Feldes (`text`, `textarea` oder `richtext`, ohne eigenes `fallback`) als Klartext, höchstens 200 Zeichen. Für Kurzfassungen: `{ "name": "kurz", "label": "Kurzfassung (leer: Anfang des Beitrags)", "type": "textarea", "fallback": "text" }`, dann ohne `required`. Gilt in Vorlagen und für `descriptionField`; gespeichert bleibt das Feld leer.

### `required: true`

Optional. Wenn `true`, blockiert das Speichern wenn der Wert leer ist.

### Klickziele (`actions`, `defaultAction`, `page`)

Nur angeben, wenn ein Eintrag beim Klick etwas tun soll; ohne `actions` gilt `["none"]`.

- `actions`: Liste aus `none`, `link`, `page`, `modal`, jedes Ziel höchstens einmal.
- `defaultAction`: Vorgabe für neue Einträge, muss in `actions` stehen (fehlt er: erstes Ziel).
- `page` (Pflicht mit `page` in `actions`): `{ "path": "leistungen", "titleField": "title", "descriptionField": "tagline" }`. `path` nur Buchstaben, Ziffern, `-`, `_` und nicht der Name einer vorhandenen Seite oder Datei der Website (auch nicht `admin`, `login`, `api`, `plugins` …) und nicht der `path` eines anderen Typs; `titleField` muss ein `text`-Feld des Typs sein, `descriptionField` ein `text`-, `textarea`- oder `richtext`-Feld.
- Keine eigenen Felder namens `action` (ab zwei Zielen), `url` (mit `link`) oder `slug` (mit `page`): Die legt das Plugin selbst an.
- Ist etwas davon falsch, erscheint der Typ nicht; der Grund steht im Backend unter „Ungültige Content-Typen“.

### Reihenfolge und Veröffentlichung (`orderBy`, `publishField`, `expireField`)

Nur angeben, wenn Einträge nicht von Hand sortiert werden sollen bzw. erst ab einem Datum erscheinen (Blog, News, Termine):

- `orderBy`: `{ "field": "<feld>", "direction": "asc" | "desc" }`, Feld der Art `text`, `number`, `date` oder `datetime`. ↑/↓ entfällt dann.
- `publishField`: `"<feld>"` der Art `date` oder `datetime`; leer heißt sofort sichtbar, das Backend zeigt immer alle.
- `expireField`: `"<feld>"` der Art `date` oder `datetime`; danach fehlt der Eintrag auf der Website (bei `date` ab dem Folgetag), leer heißt immer sichtbar.
- Veranstaltungen: `orderBy` aufs Datum aufsteigend und `expireField` aufs selbe Feld, bei mehrtägigen auf ein eigenes Feld `bis`.
- Ein Blog ist ein Typ mit `actions: ["page"]`, `orderBy` auf das Datum absteigend und `publishField` aufs selbe Feld (Vorlage: Typ `blog` in der `typen.json` der Testseite).

## Beispiel: Neuen Typ "Standorte" anlegen

User sagt: "Leg mir einen Content-Typ 'Standorte' an, mit Stadt, Adresse, Telefonnummer und einem Bild."

Du ergänzt in `typen.json`:

```json
{
  "name": "standorte",
  "label": "Standorte",
  "fields": [
    { "name": "city", "label": "Stadt", "type": "text", "required": true },
    { "name": "address", "label": "Adresse", "type": "text" },
    { "name": "phone", "label": "Telefon", "type": "text" },
    { "name": "image", "label": "Bild", "type": "image" }
  ]
}
```

Mehr brauchst du nicht. Beim nächsten Admin-Login erscheint "Standorte" als Sidebar-Eintrag und der Kunde kann Einträge anlegen.

## Aktivierung im Frontend

**Via Shortcode** (Standard-Rendering, kein PHP nötig):

```html
<div data-plugin="content-types" data-view="list" data-type="standorte" data-limit="20"></div>
```

Mit `data-filter="<feld>=<wert>"` nur Einträge mit diesem gespeicherten Wert. Eigenes Markup je Eintrag: Vorlage `public/site/includes/content-types/<typ>/card.php` (bei Ziel `modal` oder `page` auch `detail.php`, für die eigene Seite optional `page.php` mit `<?= ct_detail() ?>`), Werte nur über `ct_text`, `ct_lines` (textarea mit `<br>`), `ct_rich`, `ct_blocks` (Feld `blocks`, eigene Vorlagen je Art unter `_blocks/<art>.php`), `ct_image`, `ct_icon`, `ct_rows`, `ct_url_attrs` (Links aus `url`-Feldern, extern mit `target`/`rel`), `ct_tag`, `ct_action_attrs` (README, „Vorlagen“). Nach Includes der Website (`header.php`) `ct_item()`/`ct_type()` statt `$item`/`$type`, weil Includes diese Variablen überschreiben können. Die Vorlage gibt genau ein Element aus; Klassen der Website (Grid) kommen an das Element des Shortcodes. Ziel `modal`: Das Plugin bindet sein Modal-Skript selbst ein; das Aussehen kommt aus dem CSS der Website (`.ct-modal`, `.ct-modal__dialog`, `.ct-modal__close`), eigene Schließen-Elemente in `detail.php` bekommen `data-ct-close`, Links auf ein Modal lauten `#<typ>-<slug|id>` (README, „Modal“).

**Via PHP-Direktzugriff** (eigenes Rendering, volle Datenkontrolle):

```php
$eintraege = content_types_public_list('standorte', 20);
$einzeln   = content_types_public_get('standorte', $id);
```

`public.php` ist sicher require_once-bar — gibt `[]` / `null` zurück wenn das Plugin inaktiv ist, statt zu crashen. Nur verwenden wenn eigenes Markup oder eigene Datenverarbeitung nötig ist; sonst Shortcode bevorzugen.

Das macht der User selber oder du, wenn er dich explizit darum bittet. Eigene Seiten je Eintrag gibt es nur über das Ziel `page` (Adresse `/<page.path>/<slug>`, README „Eigene Seite“); Anker und Links in `detail.php` mit vollem Pfad (`/kontakt#formular`), weil die Seite `<base href="/">` bekommt.

## Wenn der User vorhandene Inhalte übernehmen will

Inhalte einer bestehenden Website (z. B. ein Objekt im JavaScript der Seite) nicht abtippen, sondern als JSON-Datei für den Import schreiben: eine Liste von Einträgen mit den Feldnamen des Typs, optional `action` (sonst `defaultAction`) und `url`/`slug`. Der Admin lädt sie im Backend unter „Importieren“ hoch (README, „Einträge importieren“).

- Höchstens 500 Einträge; ein Fehler → nichts importiert, Meldung nennt Zeile und Feld.
- Bilder nur als vorhandene Pfade unter `/public/site/uploads/` oder `/public/site/` (Dateien vorher dort ablegen), keine fremden URLs.
- Importiert wird angehängt; vorhandene Einträge werden nicht ersetzt.

## Beispiel-Einträge mitliefern

Erste Einträge kommen als Startpaket nach `public/site/includes/content-types/<typ>/eintraege.json` (Format wie beim Import). Das Plugin spielt sie beim ersten Zugriff in die Datenbank, wenn der Typ noch leer ist, und löscht die Datei danach (README, „Typen und Startpakete“). Später geänderte Einträge gehören in die Datenbank (Admin, `tools/data.php`), nie in eine neue `eintraege.json`.

## Wenn der User ein Preset will

Wenn der User sagt "nimm das Standard-Leistungen-Preset", dann:

1. Lies `plugins/content-types/presets/leistungen.json`
2. Übernimm den Inhalt unverändert als Objekt in `typen.json`
3. Frag NICHT nach — der User hat schon "Standard" gesagt

Wenn der User Abweichungen will ("Leistungen, aber mit zusätzlichem Feld 'Preis'"), dann lade das Preset, pass die `fields`-Liste an und speichere.

## Fehlervermeidung

- `name` gibt es in `typen.json` nur einmal (Kleinbuchstaben, Ziffern, `-`, `_`); er ist auch der Ordnername der Vorlagen
- `fields` darf nicht leer sein
- `defaultAction` muss in `actions` stehen, `page.path` darf keine vorhandene Seite sein
- `orderBy.field`, `publishField` und `expireField` müssen Felder des Typs mit passender Art nennen
- JSON muss valide sein — kein trailing comma, korrekte Quotes
- Wenn du dir unsicher bist welche Feldtypen passen, frag den User
- `content_types_save()` liefert 0, wenn es die `id` nicht mehr gibt; `api/save.php` antwortet dann 404 statt „gespeichert“
- Eingespielte Plugin-Daten (`core/dataSync.php`) prüft das Plugin über `content_types_entry_problem` (Typ muss es online geben, Adresse im Typ frei) und zieht Umbenennungen über `content_types_action_entry_updated` nach; neue Regeln fürs Speichern dort mitdenken
- Im Listen-Renderer nie `$e->getMessage()` in die Seite schreiben, nur den festen Kommentar `CONTENT_TYPES_RENDER_FAILED` (`<!-- content-types: list unavailable -->`); Details per `error_log`
