<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/db.php';
require_once __DIR__ . '/../../core/plugins.php';
require_once __DIR__ . '/../../core/pluginSchema.php';
require_once __DIR__ . '/../../core/uploads.php';

// Zwei Arten von Einträgen in einer Tabelle (Spalte kind), zugleich der Typ im data-le-list:
// Bereiche mit Wochenzeiten (Geschäft, Küche, Werkstatt) und Ausnahmen (Urlaub, Feiertag, Sonderzeiten).
const OPENING_HOURS_AREAS = 'bereiche';
const OPENING_HOURS_EXCEPTIONS = 'ausnahmen';
const OPENING_HOURS_KINDS = [OPENING_HOURS_AREAS, OPENING_HOURS_EXCEPTIONS];
// Wochentage in der Reihenfolge von date('N') (1 = Montag), zugleich die Feldnamen im Formular.
const OPENING_HOURS_DAYS = ['mo' => 'Montag', 'di' => 'Dienstag', 'mi' => 'Mittwoch', 'do' => 'Donnerstag', 'fr' => 'Freitag', 'sa' => 'Samstag', 'so' => 'Sonntag'];
const OPENING_HOURS_DAYS_SHORT = ['mo' => 'Mo', 'di' => 'Di', 'mi' => 'Mi', 'do' => 'Do', 'fr' => 'Fr', 'sa' => 'Sa', 'so' => 'So'];
// Auswahl „Gilt für“ einer Ausnahme: alle Bereiche (gespeichert als area 0) oder die ID eines Bereichs.
// „Gilt für“: je Bereich ein Häkchen bereich_<ID>; alle angehakt = alle Bereiche, auch später angelegte.
const OPENING_HOURS_AREA_FIELD = 'bereich_';
// Eingabe der Zeiten eines Tages: Zeiträume wie „8–12, 14:30–18 (warme Küche)“, getrennt durch Komma, Strichpunkt,
// „/“ oder „und“ vor einer Ziffer; leer oder ein Wort aus CLOSED heißt geschlossen, eines aus ALL_DAY rund um die Uhr.
const OPENING_HOURS_SPLIT_PATTERN = '~\s*(?:[,;/]|\bund\b)\s*(?=\d)~iu';
const OPENING_HOURS_SLOT_PATTERN = '~^(\d{1,2})(?:[:.](\d{2}))?\s*(?:uhr)?\s*(?:-|–|—|bis)\s*(\d{1,2})(?:[:.](\d{2}))?\s*(?:uhr)?(.*)$~iu';
const OPENING_HOURS_CLOSED_WORDS = ['geschlossen', 'zu', 'ruhetag', '-', '–'];
const OPENING_HOURS_ALL_DAY_WORDS = ['24h', '24 h', '24 stunden', 'rund um die uhr', 'durchgehend'];
const OPENING_HOURS_NOTE_MAX = 120;
// Ausnahmen: höchstens so viele Tage am Stück; Status: so weit voraus wird die nächste Öffnung gesucht.
const OPENING_HOURS_EXCEPTION_MAX_DAYS = 366;
const OPENING_HOURS_LOOKAHEAD_DAYS = 400;
// „Schließt bald“ bzw. „Öffnet bald“ so viele Minuten vorher.
const OPENING_HOURS_SOON_MINUTES = 60;
const OPENING_HOURS_TIME_FORMAT = 'H:i';
const OPENING_HOURS_DATE_FORMAT = 'd.m.';
const OPENING_HOURS_DATE_YEAR_FORMAT = 'd.m.Y';
// Markierung der Ausgabe (Seiten mit Öffnungszeiten bekommen das CSS, opening_hours_filter_site_html).
const OPENING_HOURS_MARK_ATTR = 'data-oh';
const OPENING_HOURS_STYLE = PLUGINS_URL . 'opening-hours/assets/opening-hours.css';
// Ausgabe eines Shortcodes, wenn die Einträge nicht laden (Grund nur im Log, nie auf der Website).
const OPENING_HOURS_RENDER_FAILED = '<!-- opening-hours: unavailable -->';
const OPENING_HOURS_TEXT = [
    'areasLabel' => 'Öffnungszeiten',
    'exceptionsLabel' => 'Urlaub und Sonderzeiten',
    'editLabel' => 'Öffnungszeiten bearbeiten',
    'appliesTo' => 'Gilt für %s',
    'open' => 'Geöffnet',
    'closed' => 'Geschlossen',
    'closesSoon' => 'Schließt bald',
    'opensSoon' => 'Öffnet bald',
    'closesAt' => 'schließt %s',
    'opensAt' => 'öffnet %s',
    'allDay' => 'rund um die Uhr',
    'at' => 'um %s',
    'tomorrowAt' => 'morgen um %s',
    'dayAt' => '%s um %s',
    'dateAt' => 'am %s um %s',
    'slot' => '%s–%s',
    'range' => '%s – %s',
    'separator' => ' · ',
    'empty' => 'Noch keine Öffnungszeiten eingetragen.',
    // Meldungen beim Speichern (ohne Feldnamen, die nennt PluginFieldException).
    'invalidSlot' => '„%s“ ist keine Zeit wie 8–12 oder 14:30–18:00.',
    'invalidTime' => '„%s“ ist keine Uhrzeit.',
    'sameTime' => '„%s“ beginnt und endet zur selben Zeit.',
    'overlap' => 'Die Zeiten überschneiden sich.',
    'dateOrder' => 'Das Ende liegt vor dem Beginn.',
    'tooLong' => 'Höchstens ' . OPENING_HOURS_EXCEPTION_MAX_DAYS . ' Tage am Stück.',
    'noArea' => 'Bitte mindestens einen Bereich anhaken.',
    'noteTooLong' => 'Der Hinweis ist zu lang (höchstens ' . OPENING_HOURS_NOTE_MAX . ' Zeichen).',
];
const OPENING_HOURS_PLACEHOLDER = [
    'day' => 'z. B. 8–12, 14–18 (leer: geschlossen)',
    'area' => 'z. B. Geschäft, Küche, Werkstatt',
    'occasion' => 'z. B. Betriebsurlaub, Weihnachten',
    'exceptionTimes' => 'leer: geschlossen, sonst z. B. 9–12',
];

function opening_hours_kind_valid(string $kind): bool
{
    return in_array($kind, OPENING_HOURS_KINDS, true);
}

/** Beschriftung einer Liste in der Leiste des Seiten-Editors und im Backend. */
function opening_hours_label(string $kind): string
{
    return $kind === OPENING_HOURS_AREAS ? OPENING_HOURS_TEXT['areasLabel'] : OPENING_HOURS_TEXT['exceptionsLabel'];
}

/**
 * Formularfelder einer Art. Bei Ausnahmen kommt „Gilt für“ nur mit mehr als einem Bereich, als Häkchen je
 * Bereich (bereich_<ID>, neu alle angehakt).
 */
function opening_hours_schema(string $kind, ?array $areas = null): array
{
    if ($kind === OPENING_HOURS_AREAS) {
        $fields = [['name' => 'name', 'label' => 'Bezeichnung', 'type' => 'text', 'required' => true, 'default' => OPENING_HOURS_TEXT['areasLabel'], 'placeholder' => OPENING_HOURS_PLACEHOLDER['area']]];
        foreach (OPENING_HOURS_DAYS as $key => $label) {
            $fields[] = ['name' => $key, 'label' => $label, 'type' => 'text', 'placeholder' => OPENING_HOURS_PLACEHOLDER['day']];
        }
        $fields[] = ['name' => 'hinweis', 'label' => 'Hinweis unter den Zeiten', 'type' => 'text'];
        return $fields;
    }

    $fields = [
        ['name' => 'anlass', 'label' => 'Anlass', 'type' => 'text', 'required' => true, 'placeholder' => OPENING_HOURS_PLACEHOLDER['occasion']],
        ['name' => 'von', 'label' => 'Von', 'type' => 'date', 'required' => true],
        ['name' => 'bis', 'label' => 'Bis (leer: nur dieser Tag)', 'type' => 'date'],
    ];
    $areas ??= opening_hours_fetch(OPENING_HOURS_AREAS);
    if (count($areas) > 1) {
        foreach ($areas as $area) {
            $fields[] = ['name' => OPENING_HOURS_AREA_FIELD . $area['id'], 'label' => sprintf(OPENING_HOURS_TEXT['appliesTo'], $area['name']), 'type' => 'boolean', 'default' => '1'];
        }
    }
    $fields[] = ['name' => 'zeiten', 'label' => 'Geöffnet', 'type' => 'text', 'placeholder' => OPENING_HOURS_PLACEHOLDER['exceptionTimes']];
    $fields[] = ['name' => 'hinweis', 'label' => 'Hinweis', 'type' => 'text'];
    return $fields;
}

/** Einträge einer Art als Daten mit id; Ausnahmen nach Beginn sortiert, Bereiche in der Reihenfolge des Anlegens. */
function opening_hours_fetch(string $kind): array
{
    $stmt = db()->prepare('SELECT id, data FROM opening_hours WHERE kind = ? ORDER BY id ASC');
    $stmt->execute([$kind]);
    $rows = [];
    foreach ($stmt->fetchAll() as $row) {
        $data = json_decode((string) $row['data'], true);
        $rows[] = ['id' => (int) $row['id']] + opening_hours_clean($kind, is_array($data) ? $data : []);
    }
    if ($kind === OPENING_HOURS_EXCEPTIONS) {
        usort($rows, static fn (array $a, array $b): int => [$a['from'], $a['id']] <=> [$b['from'], $b['id']]);
    }

    return $rows;
}

function opening_hours_fetch_one(string $kind, int $id): ?array
{
    foreach (opening_hours_fetch($kind) as $row) {
        if ($row['id'] === $id) {
            return $row;
        }
    }

    return null;
}

/** Gespeicherte Daten mit allen Schlüsseln (ältere oder von Hand geänderte Zeilen brechen die Ausgabe nicht). */
function opening_hours_clean(string $kind, array $data): array
{
    $slots = static fn (mixed $list): array => array_values(array_filter(is_array($list) ? $list : [], static fn (mixed $slot): bool => is_array($slot) && is_string($slot['from'] ?? null) && is_string($slot['to'] ?? null)));
    if ($kind === OPENING_HOURS_AREAS) {
        $days = [];
        foreach (array_keys(OPENING_HOURS_DAYS) as $key) {
            $days[$key] = $slots($data['days'][$key] ?? []);
        }
        return ['name' => (string) ($data['name'] ?? ''), 'note' => (string) ($data['note'] ?? ''), 'days' => $days];
    }
    $from = (string) ($data['from'] ?? '');
    // areas: IDs der Bereiche, leer = alle; ältere Zeilen haben area (eine ID, 0 = alle).
    $areas = is_array($data['areas'] ?? null) ? $data['areas'] : [(int) ($data['area'] ?? 0)];

    return [
        'title' => (string) ($data['title'] ?? ''),
        'from' => $from,
        'to' => (string) ($data['to'] ?? '') !== '' ? (string) $data['to'] : $from,
        'areas' => array_values(array_unique(array_filter(array_map('intval', $areas), static fn (int $id): bool => $id > 0))),
        'slots' => $slots($data['slots'] ?? []),
        'note' => (string) ($data['note'] ?? ''),
    ];
}

/** Eintrag so, wie das Formular ihn zeigt (Zeiten als Text, Ausnahme mit Datum und je Bereich ein Häkchen). */
function opening_hours_form_row(string $kind, array $entry, ?array $areas = null): array
{
    if ($kind === OPENING_HOURS_AREAS) {
        $row = ['id' => $entry['id'], 'name' => $entry['name']];
        foreach (array_keys(OPENING_HOURS_DAYS) as $key) {
            $row[$key] = opening_hours_slots_text($entry['days'][$key]);
        }
        return $row + ['hinweis' => $entry['note']];
    }

    $row = [
        'id' => $entry['id'],
        'anlass' => $entry['title'],
        'von' => $entry['from'],
        'bis' => $entry['to'] !== $entry['from'] ? $entry['to'] : '',
    ];
    foreach ($areas ?? opening_hours_fetch(OPENING_HOURS_AREAS) as $area) {
        $row[OPENING_HOURS_AREA_FIELD . $area['id']] = opening_hours_applies_to($entry, $area['id']) ? '1' : '0';
    }

    return $row + ['zeiten' => opening_hours_slots_text($entry['slots']), 'hinweis' => $entry['note']];
}

/** Zeiten eines Tages als Text fürs Formular: „08:00–12:00, 14:00–18:00 (warme Küche)“, geschlossen leer. */
function opening_hours_slots_text(array $slots): string
{
    return implode(', ', array_map(static function (array $slot): string {
        $text = sprintf(OPENING_HOURS_TEXT['slot'], $slot['from'], $slot['to']);
        return ($slot['note'] ?? '') !== '' ? $text . ' (' . $slot['note'] . ')' : $text;
    }, $slots));
}

/**
 * Zeiten eines Tages aus dem Text: Liste von ['from' => 'HH:MM', 'to' => 'HH:MM', 'note' => …], nach Beginn
 * sortiert. Ende vor Beginn heißt über Mitternacht (18–2), „24“ als Ende bis Mitternacht. Wirft
 * InvalidArgumentException mit dem Grund (ohne Feldnamen).
 */
function opening_hours_parse_slots(string $text): array
{
    $text = trim(preg_replace('/\s+/u', ' ', $text) ?? $text);
    $lower = mb_strtolower($text, 'UTF-8');
    if ($text === '' || in_array($lower, OPENING_HOURS_CLOSED_WORDS, true)) {
        return [];
    }
    if (in_array($lower, OPENING_HOURS_ALL_DAY_WORDS, true)) {
        return [['from' => '00:00', 'to' => '24:00', 'note' => '']];
    }

    $slots = [];
    foreach (preg_split(OPENING_HOURS_SPLIT_PATTERN, $text) ?: [] as $part) {
        if (!preg_match(OPENING_HOURS_SLOT_PATTERN, trim($part), $m)) {
            throw new InvalidArgumentException(sprintf(OPENING_HOURS_TEXT['invalidSlot'], trim($part)));
        }
        $from = opening_hours_time((int) $m[1], $m[2] === '' ? 0 : (int) $m[2], false, trim($part));
        $to = opening_hours_time((int) $m[3], ($m[4] ?? '') === '' ? 0 : (int) $m[4], true, trim($part));
        if ($from === $to) {
            throw new InvalidArgumentException(sprintf(OPENING_HOURS_TEXT['sameTime'], trim($part)));
        }
        $note = trim((string) ($m[5] ?? ''), " \t-–·:,");
        if (str_starts_with($note, '(') && str_ends_with($note, ')')) {
            $note = trim(substr($note, 1, -1));
        }
        if (mb_strlen($note, 'UTF-8') > OPENING_HOURS_NOTE_MAX) {
            throw new InvalidArgumentException(OPENING_HOURS_TEXT['noteTooLong']);
        }
        $slots[] = ['from' => $from, 'to' => $to, 'note' => $note];
    }
    usort($slots, static fn (array $a, array $b): int => $a['from'] <=> $b['from']);
    for ($i = 1; $i < count($slots); $i++) {
        [$start] = opening_hours_minutes($slots[$i]);
        [, $end] = opening_hours_minutes($slots[$i - 1]);
        if ($start < $end) {
            throw new InvalidArgumentException(OPENING_HOURS_TEXT['overlap']);
        }
    }

    return $slots;
}

/** Uhrzeit „HH:MM“; 24:00 nur als Ende. */
function opening_hours_time(int $hour, int $minute, bool $end, string $part): string
{
    if ($minute > 59 || $hour > 24 || ($hour === 24 && ($minute > 0 || !$end))) {
        throw new InvalidArgumentException(sprintf(OPENING_HOURS_TEXT['invalidTime'], $part));
    }

    return sprintf('%02d:%02d', $hour, $minute);
}

/** Beginn und Ende eines Zeitraums in Minuten ab Mitternacht des Tages; über Mitternacht endet er nach 1440. */
function opening_hours_minutes(array $slot): array
{
    $minutes = static fn (string $time): int => (int) substr($time, 0, 2) * 60 + (int) substr($time, 3, 2);
    $start = $minutes($slot['from']);
    $end = $minutes($slot['to']);

    return [$start, $end <= $start ? $end + 1440 : $end];
}

/** Speichert einen Eintrag (neu ohne $id) aus den Formularwerten; wirft PluginFieldException mit deutscher Meldung. */
function opening_hours_save(string $kind, array $raw, ?int $id = null): int
{
    $areas = opening_hours_fetch(OPENING_HOURS_AREAS);
    $fields = opening_hours_schema($kind, $areas);
    $values = plugin_schema_values($fields, $raw + array_fill_keys(array_column($fields, 'name'), ''));
    $labels = array_column($fields, 'label', 'name');
    $parse = static function (string $name) use ($values, $labels): array {
        try {
            return opening_hours_parse_slots((string) $values[$name]);
        } catch (PluginFieldException $e) {
            throw $e;
        } catch (InvalidArgumentException $e) {
            throw plugin_schema_field_error($name, $labels[$name], $e->getMessage());
        }
    };

    if ($kind === OPENING_HOURS_AREAS) {
        $days = [];
        foreach (array_keys(OPENING_HOURS_DAYS) as $key) {
            $days[$key] = $parse($key);
        }
        $data = ['name' => $values['name'], 'note' => $values['hinweis'], 'days' => $days];
    } else {
        $from = (string) $values['von'];
        $to = (string) ($values['bis'] ?? '') !== '' ? (string) $values['bis'] : $from;
        if ($to < $from) {
            throw plugin_schema_field_error('bis', $labels['bis'], OPENING_HOURS_TEXT['dateOrder']);
        }
        if ((new DateTimeImmutable($from))->diff(new DateTimeImmutable($to))->days >= OPENING_HOURS_EXCEPTION_MAX_DAYS) {
            throw plugin_schema_field_error('bis', $labels['bis'], OPENING_HOURS_TEXT['tooLong']);
        }
        // Ohne Häkchen in der Anfrage (ein Bereich, alte Aufrufer) gilt die Ausnahme für alle.
        $areaFields = array_values(array_filter($fields, static fn (array $field): bool => str_starts_with($field['name'], OPENING_HOURS_AREA_FIELD)));
        $chosen = [];
        foreach ($areaFields as $field) {
            if (($values[$field['name']] ?? '0') === '1') {
                $chosen[] = (int) substr($field['name'], strlen(OPENING_HOURS_AREA_FIELD));
            }
        }
        $sent = array_intersect_key($raw, array_column($areaFields, null, 'name')) !== [];
        if ($sent && $chosen === []) {
            throw plugin_schema_field_error($areaFields[0]['name'], $areaFields[0]['label'], OPENING_HOURS_TEXT['noArea']);
        }
        $data = [
            'title' => $values['anlass'],
            'from' => $from,
            'to' => $to,
            'areas' => count($chosen) < count($areaFields) ? $chosen : [],
            'slots' => $parse('zeiten'),
            'note' => $values['hinweis'],
        ];
    }

    $json = plugin_schema_json($data);
    $now = db_now();
    if ($id !== null && $id > 0) {
        $stmt = db()->prepare('UPDATE opening_hours SET data = ?, updated_at = ? WHERE id = ? AND kind = ?');
        $stmt->execute([$json, $now, $id, $kind]);
        if ($stmt->rowCount() === 0 && opening_hours_fetch_one($kind, $id) === null) {
            throw new InvalidArgumentException(API_TEXT['notFound']);
        }
        return $id;
    }
    $stmt = db()->prepare('INSERT INTO opening_hours (kind, data, created_at, updated_at) VALUES (?, ?, ?, ?)');
    $stmt->execute([$kind, $json, $now, $now]);

    return (int) db()->lastInsertId();
}

/** Löscht einen Eintrag; mit einem Bereich gehen auch die Ausnahmen, die nur für ihn galten, die übrigen verlieren ihn. */
function opening_hours_delete(string $kind, int $id): bool
{
    if (!plugin_delete_entry('opening-hours', $id, ['kind' => $kind])) {
        return false;
    }
    if ($kind === OPENING_HOURS_AREAS) {
        foreach (opening_hours_fetch(OPENING_HOURS_EXCEPTIONS) as $exception) {
            if (!in_array($id, $exception['areas'], true)) {
                continue;
            }
            $rest = array_values(array_diff($exception['areas'], [$id]));
            if ($rest === []) {
                plugin_delete_entry('opening-hours', $exception['id'], ['kind' => OPENING_HOURS_EXCEPTIONS]);
                continue;
            }
            $data = ['areas' => $rest] + array_diff_key($exception, ['id' => 1]);
            $stmt = db()->prepare('UPDATE opening_hours SET data = ?, updated_at = ? WHERE id = ? AND kind = ?');
            $stmt->execute([plugin_schema_json($data), db_now(), $exception['id'], OPENING_HOURS_EXCEPTIONS]);
        }
    }

    return true;
}

// ---------------------------------------------------------------------------
// Berechnung: Was gilt an einem Tag, ist gerade offen, wann öffnet es wieder.

/** Aktuelle Zeit in der Zeitzone der Installation (APP_TIMEZONE, sofern der Hoster keine setzt). */
function opening_hours_now(): DateTimeImmutable
{
    return new DateTimeImmutable('now');
}

/**
 * Bereich zu einer Angabe am Shortcode: ID oder Bezeichnung (ohne Groß/klein); leer = der erste Bereich.
 * null, wenn es keinen passenden gibt.
 */
function opening_hours_find_area(array $areas, string $wanted): ?array
{
    $wanted = trim($wanted);
    foreach ($areas as $area) {
        if ($wanted === '' || $wanted === (string) $area['id'] || mb_strtolower($wanted, 'UTF-8') === mb_strtolower($area['name'], 'UTF-8')) {
            return $area;
        }
    }

    return null;
}

/** Gilt die Ausnahme für den Bereich mit dieser ID (leere Liste = alle Bereiche)? */
function opening_hours_applies_to(array $exception, int $areaId): bool
{
    return $exception['areas'] === [] || in_array($areaId, $exception['areas'], true);
}

/**
 * Ausnahme, die an $date für $area gilt, sonst null. Liegen mehrere übereinander, gewinnt die kürzere
 * (der Feiertag im Urlaub), dann die für weniger Bereiche, dann die zuletzt angelegte.
 */
function opening_hours_exception_on(array $area, array $exceptions, DateTimeImmutable $date): ?array
{
    $day = $date->format('Y-m-d');
    $best = null;
    $rank = null;
    foreach ($exceptions as $exception) {
        if ($exception['from'] > $day || $exception['to'] < $day || !opening_hours_applies_to($exception, $area['id'])) {
            continue;
        }
        $candidate = [-(new DateTimeImmutable($exception['from']))->diff(new DateTimeImmutable($exception['to']))->days, $exception['areas'] === [] ? PHP_INT_MIN : -count($exception['areas']), $exception['id']];
        if ($rank === null || $candidate > $rank) {
            [$best, $rank] = [$exception, $candidate];
        }
    }

    return $best;
}

/** Zeiten, die an $date gelten: ['slots' => …, 'exception' => Ausnahme oder null]. */
function opening_hours_day(array $area, array $exceptions, DateTimeImmutable $date): array
{
    $exception = opening_hours_exception_on($area, $exceptions, $date);
    $key = array_keys(OPENING_HOURS_DAYS)[(int) $date->format('N') - 1];

    return ['slots' => $exception !== null ? $exception['slots'] : $area['days'][$key], 'exception' => $exception];
}

/**
 * Zeilen der Wochentabelle in der Reihenfolge Mo–So: je Wochentag sein nächster Termin ab heute (heute und
 * die sechs Tage danach, wie bei Google), mit Ausnahme, falls eine gilt. Am Samstag ist die Montag-Zeile
 * also der kommende Montag. Je Zeile ['key', 'date', 'today', 'slots', 'exception'].
 */
function opening_hours_week(array $area, array $exceptions, DateTimeImmutable $now): array
{
    $today = $now->setTime(0, 0);
    $todayIndex = (int) $today->format('N') - 1;
    $rows = [];
    foreach (array_keys(OPENING_HOURS_DAYS) as $index => $key) {
        $ahead = ($index - $todayIndex + 7) % 7;
        $date = $today->modify("+{$ahead} days");
        $rows[] = ['key' => $key, 'date' => $date, 'today' => $ahead === 0] + opening_hours_day($area, $exceptions, $date);
    }

    return $rows;
}

/** Zeiträume, die an $date beginnen, als ['start' => DateTimeImmutable, 'end' => …, 'note' => …] (setTime: richtig auch am Tag der Zeitumstellung). */
function opening_hours_intervals(array $area, array $exceptions, DateTimeImmutable $date): array
{
    $midnight = $date->setTime(0, 0);
    $next = $midnight->modify('+1 day');
    $out = [];
    foreach (opening_hours_day($area, $exceptions, $midnight)['slots'] as $slot) {
        [$start, $end] = opening_hours_minutes($slot);
        $endDay = $end >= 1440 ? $next : $midnight;
        $out[] = [
            'start' => $midnight->setTime(intdiv($start, 60), $start % 60),
            'end' => $endDay->setTime(intdiv($end % 1440, 60), $end % 60),
            'note' => (string) ($slot['note'] ?? ''),
        ];
    }

    return $out;
}

/**
 * Stand zum Zeitpunkt $now: ['open' => bool, 'until' => Ende (null: kein Ende in Sicht), 'next' => nächste Öffnung
 * (null: keine), 'note' => Hinweis des laufenden Zeitraums, 'exception' => Ausnahme von heute]. Aneinander
 * anschließende Zeiträume (über Mitternacht, 0–24 an mehreren Tagen) zählen als einer.
 */
function opening_hours_status(array $area, array $exceptions, DateTimeImmutable $now): array
{
    $today = $now->setTime(0, 0);
    $status = ['open' => false, 'until' => null, 'next' => null, 'note' => '', 'exception' => opening_hours_day($area, $exceptions, $today)['exception']];
    $current = null;
    for ($offset = -1; $offset <= OPENING_HOURS_LOOKAHEAD_DAYS; $offset++) {
        foreach (opening_hours_intervals($area, $exceptions, $today->modify("{$offset} days")) as $interval) {
            if ($current !== null) {
                if ($interval['start'] > $current['end']) {
                    break;
                }
                $current['end'] = max($current['end'], $interval['end']);
            } elseif ($interval['start'] <= $now && $now < $interval['end']) {
                $current = $interval;
            } elseif ($interval['start'] > $now) {
                return ['next' => $interval['start']] + $status;
            }
        }
        // Der nächste Tag kann nur anschließen, wenn der Zeitraum bis Mitternacht reicht.
        if ($current !== null && $current['end'] < $today->modify(($offset + 1) . ' days')) {
            return ['open' => true, 'until' => $current['end'], 'note' => $current['note']] + $status;
        }
    }

    return $current !== null ? ['open' => true, 'note' => $current['note']] + $status : $status;
}

/** „um 18:00“, „morgen um 08:00“, „Mo um 08:00“ (innerhalb einer Woche), sonst „am 07.01. um 08:00“. */
function opening_hours_when(DateTimeImmutable $at, DateTimeImmutable $now): string
{
    $time = $at->format(OPENING_HOURS_TIME_FORMAT);
    $days = (int) $now->setTime(0, 0)->diff($at->setTime(0, 0))->format('%r%a');
    if ($at->format('H:i') === '00:00' && $days > 0) {
        // Ende um Mitternacht heißt für Besucher „um 24:00“ des Vortags.
        [$time, $days, $at] = ['24:00', $days - 1, $at->modify('-1 day')];
    }
    if ($days === 0) {
        return sprintf(OPENING_HOURS_TEXT['at'], $time);
    }
    if ($days === 1) {
        return sprintf(OPENING_HOURS_TEXT['tomorrowAt'], $time);
    }
    if ($days < 7) {
        return sprintf(OPENING_HOURS_TEXT['dayAt'], array_values(OPENING_HOURS_DAYS_SHORT)[(int) $at->format('N') - 1], $time);
    }

    return sprintf(OPENING_HOURS_TEXT['dateAt'], $at->format(OPENING_HOURS_DATE_FORMAT), $time);
}

/**
 * Anzeige des Stands: ['state' => open|soon|closed|opening, 'label' => „Geöffnet“ …, 'details' => [„schließt um 18:00“, …]].
 * Wie bei Google: kurz vor dem Schließen „Schließt bald · um 18:00“, kurz vor dem Öffnen „Öffnet bald · um 08:00“; der Hinweis des
 * Zeitraums („warme Küche“) bzw. der Anlass einer Schließung steht dabei.
 */
function opening_hours_status_text(array $status, DateTimeImmutable $now): array
{
    $soon = static fn (DateTimeImmutable $at): bool => $at->getTimestamp() - $now->getTimestamp() <= OPENING_HOURS_SOON_MINUTES * 60;
    if ($status['open']) {
        $closing = $status['until'] !== null && $soon($status['until']);
        $details = [$status['until'] === null ? OPENING_HOURS_TEXT['allDay'] : ($closing ? opening_hours_when($status['until'], $now) : sprintf(OPENING_HOURS_TEXT['closesAt'], opening_hours_when($status['until'], $now)))];
        if ($status['note'] !== '') {
            $details[] = $status['note'];
        }
        return ['state' => $closing ? 'soon' : 'open', 'label' => OPENING_HOURS_TEXT[$closing ? 'closesSoon' : 'open'], 'details' => $details];
    }
    $details = [];
    if ($status['exception'] !== null && $status['exception']['slots'] === []) {
        $details[] = $status['exception']['title'];
    }
    $opening = $status['next'] !== null && $soon($status['next']);
    if ($status['next'] !== null) {
        $details[] = $opening ? opening_hours_when($status['next'], $now) : sprintf(OPENING_HOURS_TEXT['opensAt'], opening_hours_when($status['next'], $now));
    }

    return ['state' => $opening ? 'opening' : 'closed', 'label' => OPENING_HOURS_TEXT[$opening ? 'opensSoon' : 'closed'], 'details' => $details];
}

/** Zeitraum einer Ausnahme für Besucher: „24.12.“ bzw. „24.12.2026 – 06.01.2027“ (Jahr nur über den Jahreswechsel). */
function opening_hours_range_text(array $exception): string
{
    $from = new DateTimeImmutable($exception['from']);
    $to = new DateTimeImmutable($exception['to']);
    if ($exception['from'] === $exception['to']) {
        return $from->format(OPENING_HOURS_DATE_YEAR_FORMAT);
    }
    $format = $from->format('Y') === $to->format('Y') ? OPENING_HOURS_DATE_FORMAT : OPENING_HOURS_DATE_YEAR_FORMAT;

    return sprintf(OPENING_HOURS_TEXT['range'], $from->format($format), $to->format(OPENING_HOURS_DATE_YEAR_FORMAT));
}

/** Ausnahmen, die heute noch gelten oder später kommen; $days > 0: nur die, die in so vielen Tagen beginnen. */
function opening_hours_upcoming(array $exceptions, DateTimeImmutable $now, int $days = 0): array
{
    $today = $now->format('Y-m-d');
    $last = $days > 0 ? $now->modify("+{$days} days")->format('Y-m-d') : null;

    return array_values(array_filter($exceptions, static fn (array $e): bool => $e['to'] >= $today && ($last === null || $e['from'] <= $last)));
}

/** Hook filter_site_html: Seiten mit Öffnungszeiten bekommen einmal das CSS vor </head>. */
function opening_hours_filter_site_html(string $html): string
{
    $pos = stripos($html, '</head>');
    if ($pos === false || !str_contains($html, ' ' . OPENING_HOURS_MARK_ATTR) || str_contains($html, OPENING_HOURS_STYLE)) {
        return $html;
    }

    return substr_replace($html, '<link rel="stylesheet" href="' . OPENING_HOURS_STYLE . '">', $pos, 0);
}

// ---------------------------------------------------------------------------
// Ausgabe (render/*.php): escaped, Klassen oh-*, markiert für den Seiten-Editor.

/** Zeiten eines Tages als HTML: je Zeitraum eine Zeile mit Hinweis, ohne Zeiten „Geschlossen“. */
function opening_hours_slots_html(array $slots): string
{
    if ($slots === []) {
        return '<span class="oh-closed">' . htmlspecialchars(OPENING_HOURS_TEXT['closed']) . '</span>';
    }

    return implode('', array_map(static function (array $slot): string {
        $html = '<span class="oh-slot">' . ($slot['from'] === '00:00' && $slot['to'] === '24:00'
            ? htmlspecialchars(OPENING_HOURS_TEXT['allDay'])
            : htmlspecialchars(sprintf(OPENING_HOURS_TEXT['slot'], $slot['from'], $slot['to'])));
        if (($slot['note'] ?? '') !== '') {
            $html .= ' <span class="oh-note">' . htmlspecialchars($slot['note']) . '</span>';
        }
        return $html . '</span>';
    }, $slots));
}

/** Liste der Ausnahmen (markiert als Liste „ausnahmen“, auch leer, damit Angemeldete eine anlegen können). */
function opening_hours_notices_html(array $exceptions, array $areas): string
{
    $names = count($areas) > 1 ? array_column($areas, 'name', 'id') : [];
    $html = '<ul class="oh-notices" ' . OPENING_HOURS_MARK_ATTR . ' ' . le_list_attrs('opening-hours', OPENING_HOURS_EXCEPTIONS) . '>';
    foreach ($exceptions as $exception) {
        $title = $exception['title'];
        $only = array_values(array_intersect_key($names, array_flip($exception['areas'])));
        if ($only !== []) {
            $title = implode(', ', $only) . ': ' . $title;
        }
        $html .= '<li class="oh-notice" ' . le_item_attrs($exception['id']) . '>'
            . '<strong class="oh-notice__title">' . htmlspecialchars($title) . '</strong> '
            . '<span class="oh-notice__date">' . htmlspecialchars(opening_hours_range_text($exception)) . '</span> '
            . '<span class="oh-notice__hours">' . opening_hours_slots_html($exception['slots']) . '</span>'
            . ($exception['note'] !== '' ? ' <span class="oh-notice__note">' . htmlspecialchars($exception['note']) . '</span>' : '')
            . '</li>';
    }

    return $html . '</ul>';
}
