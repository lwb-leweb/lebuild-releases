let outletEl = null;
let ctxRef = null;
// Je Art (bereiche, ausnahmen) das Schema aus dem letzten Abruf, fürs Formular „Neu“.
const schemas = {};

const API = '/plugins/opening-hours/api/';
const KINDS = [
  { type: 'bereiche', title: 'Bereiche', add: 'Neuer Bereich', empty: 'Noch kein Bereich. Lege zuerst die üblichen Öffnungszeiten an.' },
  { type: 'ausnahmen', title: 'Urlaub und Sonderzeiten', add: 'Neue Ausnahme', empty: 'Keine kommenden Ausnahmen.' }
];
// Einbinden auf der Website (README: Shortcodes); je Bereich kommen Wochenzeiten und Stand mit data-area dazu.
const SNIPPETS = [
  { text: 'Wochenzeiten aller Bereiche, darunter Urlaub und Sonderzeiten:', code: '<div data-plugin="opening-hours" data-view="week"></div>' },
  { text: 'Wochenzeiten ohne Urlaub und Sonderzeiten darunter:', code: '<div data-plugin="opening-hours" data-view="week" data-notices="no"></div>' },
  { text: '„Jetzt geöffnet“ für den ersten Bereich:', code: '<span data-plugin="opening-hours" data-view="status"></span>' },
  { text: 'Nur Urlaub und Sonderzeiten:', code: '<div data-plugin="opening-hours" data-view="notices"></div>' },
  { text: 'Nur Urlaub und Sonderzeiten, die in den nächsten 14 Tagen beginnen:', code: '<div data-plugin="opening-hours" data-view="notices" data-days="14"></div>' }
];

const openingHoursModule = {
  id: 'opening-hours',
  mount(outlet, ctx) {
    outletEl = outlet;
    ctxRef = ctx;
    renderShell();
    KINDS.forEach(loadList);
  },
  unmount() {
    if (ctxRef && ctxRef.ui && ctxRef.ui.closeModal) ctxRef.ui.closeModal();
    outletEl = null;
    ctxRef = null;
  }
};

export default openingHoursModule;

function renderShell() {
  outletEl.innerHTML = `
    <section class="view-area opening-hours-admin">
      ${KINDS.map(function (kind, index) {
        return `
          <div class="view-card span-12">
            <div class="topbar">
              <strong>${escapeHtml(kind.title)}</strong>
              <button type="button" data-add="${escapeHtml(kind.type)}">${escapeHtml(kind.add)}</button>
            </div>
            ${index === 0 ? '<p id="ohMsg" class="message"></p>' : ''}
            <div data-list="${escapeHtml(kind.type)}" class="generic-list"></div>
          </div>
        `;
      }).join('')}
      <div class="view-card span-12">
        <div class="topbar"><strong>Auf der Website einbinden</strong></div>
        <div data-snippets>${snippetsHtml(SNIPPETS)}</div>
      </div>
    </section>
  `;
  outletEl.querySelectorAll('[data-add]').forEach(function (button) {
    button.addEventListener('click', function () { openForm(button.dataset.add, null); });
  });
}

function loadList(kind) {
  ctxRef.api(API + 'list.php?type=' + encodeURIComponent(kind.type))
    .then(function (data) {
      schemas[kind.type] = data.schema || [];
      renderList(kind, data.rows || []);
      if (kind.type === 'bereiche') renderSnippets(data.rows || []);
    })
    .catch(showError);
}

function reloadAll() {
  if (ctxRef) KINDS.forEach(loadList);
}

function renderList(kind, rows) {
  const list = outletEl && outletEl.querySelector('[data-list="' + kind.type + '"]');
  if (!list) return;
  if (!rows.length) {
    list.innerHTML = `<p class="message">${escapeHtml(kind.empty)}</p>`;
    return;
  }
  list.innerHTML = '<ul>' + rows.map(function (row) {
    return `
      <li class="generic-list__row" data-id="${Number(row.id)}">
        <span class="generic-list__title">
          <strong>${escapeHtml(ctxRef.ui.entryTitle(schemas[kind.type], row))}</strong>
          <small>${escapeHtml(summary(kind.type, row))}</small>
        </span>
        <div class="generic-list__actions">
          <button type="button" data-action="edit">Bearbeiten</button>
          <button type="button" data-action="delete" class="secondary">Löschen</button>
        </div>
      </li>
    `;
  }).join('') + '</ul>';

  list.querySelectorAll('.generic-list__row').forEach(function (item) {
    const id = parseInt(item.dataset.id, 10);
    const row = rows.find(function (entry) { return Number(entry.id) === id; });
    item.querySelector('[data-action="edit"]').addEventListener('click', function () {
      ctxRef.api(API + 'get.php?type=' + encodeURIComponent(kind.type) + '&id=' + id)
        .then(function (data) {
          schemas[kind.type] = data.schema || schemas[kind.type];
          openForm(kind.type, data.row);
        })
        .catch(showError);
    });
    item.querySelector('[data-action="delete"]').addEventListener('click', function () {
      if (!ctxRef.confirm(ctxRef.ui.deleteQuestion(schemas[kind.type], row))) return;
      post('delete.php', { type: kind.type, id: id }).then(reloadAll).catch(showError);
    });
  });
}

// Schnipsel zum Einbinden, je Bereich Wochenzeiten und Stand über die ID (bleibt beim Umbenennen gültig).
function renderSnippets(areas) {
  const box = outletEl && outletEl.querySelector('[data-snippets]');
  if (!box) return;
  const perArea = areas.flatMap(function (area) {
    const id = Number(area.id);
    return [
      { text: 'Wochenzeiten nur für „' + area.name + '“:', code: '<div data-plugin="opening-hours" data-view="week" data-area="' + id + '"></div>' },
      { text: '„Jetzt geöffnet“ für „' + area.name + '“:', code: '<span data-plugin="opening-hours" data-view="status" data-area="' + id + '"></span>' }
    ];
  });
  box.innerHTML = snippetsHtml(SNIPPETS.concat(perArea));
}

function snippetsHtml(snippets) {
  return snippets.map(function (snippet) {
    return `<p>${escapeHtml(snippet.text)}</p><pre><code>${escapeHtml(snippet.code)}</code></pre>`;
  }).join('');
}

// Zweite Zeile in der Liste: Montag bis Sonntag kurz bzw. Zeitraum der Ausnahme.
function summary(type, row) {
  if (type === 'ausnahmen') {
    const range = row.bis ? formatDate(row.von) + ' – ' + formatDate(row.bis) : formatDate(row.von);
    return range + ' · ' + (row.zeiten || 'geschlossen');
  }
  return ['mo', 'di', 'mi', 'do', 'fr', 'sa', 'so'].map(function (day) {
    return day.charAt(0).toUpperCase() + day.charAt(1) + ' ' + (row[day] || '–');
  }).join(' · ');
}

function formatDate(value) {
  const parts = String(value || '').split('-');
  return parts.length === 3 ? parts[2] + '.' + parts[1] + '.' + parts[0] : String(value || '');
}

// Formular aus dem Schema der Art, wie auf der Website.
function openForm(type, row) {
  ctxRef.ui.openEntryForm({
    schema: schemas[type] || [],
    row: row,
    save: function (data) {
      const body = { type: type, data: data };
      if (row && row.id) body.id = row.id;
      return post('save.php', body);
    },
    onSaved: reloadAll
  });
}

function post(file, body) {
  return ctxRef.api(API + file, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
}

function showError(error) {
  const message = outletEl && outletEl.querySelector('#ohMsg');
  if (message) message.textContent = error.message || String(error);
}

function escapeHtml(value) {
  return String(value == null ? '' : value).replace(/[&<>"']/g, function (char) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
  });
}
