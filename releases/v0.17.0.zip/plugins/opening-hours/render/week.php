<?php
require_once __DIR__ . '/../lib.php';

// Wochenzeiten Mo–So je Bereich (area: ID oder Bezeichnung, sonst alle), heute hervorgehoben. Jede Zeile zeigt den
// nächsten Termin ihres Wochentags ab heute, also heute und die sechs Tage danach, mit Ausnahme statt Wochenzeit,
// falls eine gilt (wie bei Google; opening_hours_week()). Darunter die Ausnahmen (notices="no": ohne).
try {
    $ohAreas = opening_hours_fetch(OPENING_HOURS_AREAS);
    $ohExceptions = opening_hours_fetch(OPENING_HOURS_EXCEPTIONS);
} catch (Throwable $e) {
    error_log('opening-hours week: ' . $e->getMessage());
    echo OPENING_HOURS_RENDER_FAILED;
    return;
}
$ohWanted = trim((string) ($attrs['area'] ?? ''));
$ohShown = $ohWanted === '' ? $ohAreas : array_values(array_filter([opening_hours_find_area($ohAreas, $ohWanted)]));
$ohNow = opening_hours_now();
?>
<div class="oh-week" <?= OPENING_HOURS_MARK_ATTR ?> <?= le_list_attrs('opening-hours', OPENING_HOURS_AREAS) ?>>
  <?php if ($ohShown === []): ?>
    <p class="oh-empty"><?= htmlspecialchars(OPENING_HOURS_TEXT['empty']) ?></p>
  <?php endif ?>
  <?php foreach ($ohShown as $ohArea): ?>
    <div class="oh-area" <?= le_item_attrs($ohArea['id']) ?>>
      <?php if (count($ohShown) > 1): ?>
        <h3 class="oh-area__title"><?= htmlspecialchars($ohArea['name']) ?></h3>
      <?php endif ?>
      <table class="oh-table">
        <tbody>
          <?php foreach (opening_hours_week($ohArea, $ohExceptions, $ohNow) as $ohDay): ?>
            <tr class="oh-day<?= $ohDay['today'] ? ' oh-day--today' : '' ?><?= $ohDay['exception'] !== null ? ' oh-day--special' : '' ?>">
              <th scope="row"><?= htmlspecialchars(OPENING_HOURS_DAYS[$ohDay['key']]) ?></th>
              <td>
                <?= opening_hours_slots_html($ohDay['slots']) ?>
                <?php if ($ohDay['exception'] !== null): ?>
                  <span class="oh-special"><?= htmlspecialchars($ohDay['exception']['title'] . ', ' . $ohDay['date']->format(OPENING_HOURS_DATE_FORMAT)) ?></span>
                <?php endif ?>
              </td>
            </tr>
          <?php endforeach ?>
        </tbody>
      </table>
      <?php if ($ohArea['note'] !== ''): ?>
        <p class="oh-area__note"><?= htmlspecialchars($ohArea['note']) ?></p>
      <?php endif ?>
    </div>
  <?php endforeach ?>
</div>
<?php if (($attrs['notices'] ?? '') !== 'no'): ?>
  <?= opening_hours_notices_html(opening_hours_upcoming($ohExceptions, $ohNow), $ohAreas) ?>
<?php endif ?>
