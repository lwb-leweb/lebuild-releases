<?php
require_once __DIR__ . '/../lib.php';

// „Geöffnet · schließt um 18:00“ für einen Bereich (area: ID oder Bezeichnung, sonst der erste), zum Zeitpunkt des Aufrufs.
try {
    $ohAreas = opening_hours_fetch(OPENING_HOURS_AREAS);
    $ohArea = opening_hours_find_area($ohAreas, (string) ($attrs['area'] ?? ''));
    $ohExceptions = $ohArea !== null ? opening_hours_fetch(OPENING_HOURS_EXCEPTIONS) : [];
} catch (Throwable $e) {
    error_log('opening-hours status: ' . $e->getMessage());
    echo OPENING_HOURS_RENDER_FAILED;
    return;
}
if ($ohArea === null) {
    // Ohne Bereich: leere, markierte Liste, damit Angemeldete die Zeiten hier anlegen können.
    echo '<span class="oh-status" ' . OPENING_HOURS_MARK_ATTR . ' ' . le_list_attrs('opening-hours', OPENING_HOURS_AREAS) . '></span>';
    return;
}
$ohNow = opening_hours_now();
$ohText = opening_hours_status_text(opening_hours_status($ohArea, $ohExceptions, $ohNow), $ohNow);
?>
<span class="oh-status oh-status--<?= htmlspecialchars($ohText['state']) ?>" <?= OPENING_HOURS_MARK_ATTR ?> <?= le_single_attrs('opening-hours', OPENING_HOURS_AREAS, $ohArea['id'], OPENING_HOURS_TEXT['editLabel']) ?>>
  <span class="oh-status__label"><?= htmlspecialchars($ohText['label']) ?></span><?php foreach ($ohText['details'] as $ohDetail): ?><span class="oh-status__detail"><?= htmlspecialchars(OPENING_HOURS_TEXT['separator'] . $ohDetail) ?></span><?php endforeach ?>
</span>
