<?php
require_once __DIR__ . '/../lib.php';

// Urlaub und Sonderzeiten, die noch gelten oder kommen (days: nur die, die in so vielen Tagen beginnen).
try {
    $ohAreas = opening_hours_fetch(OPENING_HOURS_AREAS);
    $ohExceptions = opening_hours_upcoming(opening_hours_fetch(OPENING_HOURS_EXCEPTIONS), opening_hours_now(), max(0, (int) ($attrs['days'] ?? 0)));
} catch (Throwable $e) {
    error_log('opening-hours notices: ' . $e->getMessage());
    echo OPENING_HOURS_RENDER_FAILED;
    return;
}
echo opening_hours_notices_html($ohExceptions, $ohAreas);
