# Öffnungszeiten Plugin

Öffnungszeiten nach dem Vorbild des Google-Unternehmensprofils: übliche Wochenzeiten je Bereich, geteilte Zeiten mit Hinweis, Urlaub und Sonderzeiten. Daraus zeigt die Website die Woche, „Jetzt geöffnet“ und kommende Ausnahmen.

## Aktivierung

Admin → Plugins → „Öffnungszeiten“ aktivieren. Legt die Tabelle `opening_hours` an und den Sidebar-Eintrag „Öffnungszeiten“. Danach die Shortcodes in eine Seite einbauen.

## Was es kann

- Mehrere Bereiche (Geschäft, Küche, Werkstatt …), jeder mit eigenen Wochenzeiten
- Je Tag beliebig viele Zeiträume, mit Hinweis („warme Küche“), über Mitternacht (18–2) oder rund um die Uhr
- Ausnahmen für einen Tag oder Zeitraum (Urlaub, Betriebsurlaub, Feiertag): geschlossen oder mit anderen Zeiten, für alle oder einen Bereich
- „Jetzt geöffnet“ wie bei Google: „Geöffnet · schließt um 18:00“, „Schließt bald · um 18:00“, „Geschlossen · Betriebsurlaub · öffnet am 07.01. um 08:00“
- Bearbeiten auf der Website für Redakteure (Listenleiste unter Wochenzeiten und Ausnahmen, Knopf „Öffnungszeiten bearbeiten“ am Stand)

## Im Admin verwenden

- **Zeiten eingeben:** je Tag als Text, z. B. `8–12, 14–18` oder `11–14 (warme Küche), 17–23`. Leer oder „geschlossen“ heißt geschlossen, `24h` rund um die Uhr. Der Server prüft die Eingabe und schreibt sie einheitlich zurück (`08:00–12:00`).
- **Ausnahme:** Anlass, Von, Bis (leer: ein Tag), „Gilt für“ (erst ab zwei Bereichen, ein Häkchen je Bereich, neu alle angehakt), Zeiten (leer: geschlossen), Hinweis.
- Liegen Ausnahmen übereinander, gilt die kürzere (Heiliger Abend im Betriebsurlaub), dann die für weniger Bereiche, dann die zuletzt angelegte.
- Einen Bereich löschen löscht auch die Ausnahmen, die nur für ihn galten; bei Ausnahmen für mehrere fällt er heraus.

## API-Endpoints

Alle unter `/plugins/opening-hours/api/`, Auth: Anmeldung (Editor oder Admin), schreibend zusätzlich CSRF. `type` ist `bereiche` oder `ausnahmen`.

| Endpoint | Methode | Parameter | Response |
|---|---|---|---|
| `list.php` | GET | `?type=` | `{ok, type, label, schema, rows[]}`; Ausnahmen nur laufende und kommende |
| `get.php` | GET | `?type=&id=` | `{ok, type, schema, row}` oder 404 |
| `save.php` | POST | `{type, data, id?}` | `{ok, id}`, ungültige Eingabe 400 `{ok:false, error}` („Dienstag: Die Zeiten überschneiden sich.“) |
| `delete.php` | POST | `{type, id}` | `{ok}`, 404 bei falscher Art oder ID |

Formularwerte (`row`, `data`): Bereich `name`, `mo` … `so` (Text), `hinweis`; Ausnahme `anlass`, `von`, `bis` (`YYYY-MM-DD`), `bereich_<ID>` (`1`/`0` je Bereich; ohne diese Felder gilt die Ausnahme für alle), `zeiten`, `hinweis`.

## Shortcodes

| Shortcode | Attribute | Ausgabe |
|---|---|---|
| `<div data-plugin="opening-hours" data-view="week"></div>` | `data-area` (ID oder Bezeichnung, sonst alle), `data-notices="no"` (ohne Ausnahmen darunter) | `.oh-week` mit `.oh-area` je Bereich (Titel ab zwei Bereichen), `.oh-table` Mo–So, jede Zeile der nächste Termin dieses Wochentags ab heute (heute und die sechs Tage danach, am Samstag also der kommende Montag), `.oh-day--today`, `.oh-day--special` (an diesem Termin gilt eine Ausnahme), `.oh-slot`, `.oh-note`, `.oh-closed`; darunter `.oh-notices` |
| `<span data-plugin="opening-hours" data-view="status"></span>` | `data-area` (sonst der erste Bereich) | `.oh-status--open|soon|closed|opening` mit `.oh-status__label` und `.oh-status__detail` |
| `<div data-plugin="opening-hours" data-view="notices"></div>` | `data-days` (nur Ausnahmen, die in so vielen Tagen beginnen) | `.oh-notices` mit `.oh-notice` (`__title`, `__date`, `__hours`, `__note`) |

Seiten mit Öffnungszeiten bekommen `assets/opening-hours.css` (Grundform, Farben nur für den Punkt am Stand); die Website kann alles überschreiben.

## Datenbank

`opening_hours`: `id`, `kind` (`bereiche`/`ausnahmen`), `data` (JSON), `created_at`, `updated_at`.

- Bereich: `{"name", "note", "days": {"mo": [{"from": "08:00", "to": "12:00", "note": ""}], …}}`
- Ausnahme: `{"title", "from", "to", "areas" (IDs, leer = alle; ältere Zeilen haben "area", 0 = alle), "slots": [...], "note"}`

## Bekannte Einschränkungen

- Der Stand gilt zum Zeitpunkt des Seitenabrufs; eine lange offene Seite aktualisiert ihn nicht.
- Keine Feiertage von selbst, kein Abgleich mit Google und keine strukturierten Daten (schema.org) – kommen bei Bedarf.
- Bereiche haben keine Reihenfolge außer der des Anlegens; der erste ist der für `status` ohne `data-area`.

## Changelog

- **2026-10-29** — „Gilt für“ ist eine Mehrfachauswahl: Urlaub und Sonderzeiten gelten für beliebig viele Bereiche (Häkchen je Bereich, alle angehakt = alle, auch später angelegte). Ältere Einträge mit einem Bereich werden weiter gelesen.
- **2026-10-29** — Das Backend zeigt alle Shortcodes samt Attributen, dazu je Bereich Wochenzeiten und „Jetzt geöffnet“ mit `data-area` (ID, bleibt beim Umbenennen gültig).
- **2026-10-28** — Die Wochentabelle bleibt Mo–So, zeigt aber je Wochentag seinen nächsten Termin ab heute samt Ausnahme. Bisher zeigte sie die laufende Woche, ein Feiertag am kommenden Montag fehlte am Samstag.
- **2026-10-28** — Laden die Einträge nicht, steht nur `<!-- opening-hours: unavailable -->` in der Seite, der Grund im Fehlerprotokoll. Texte (Bereich, Anlass, Hinweis) werden wörtlich gespeichert („<3“ bleibt) und bei der Ausgabe escaped.
- **2026-10-26 — v1.0.0** — Erste Fassung: Bereiche mit Wochenzeiten, Ausnahmen, Wochenansicht, Stand, Hinweise, Bearbeiten auf der Website.
