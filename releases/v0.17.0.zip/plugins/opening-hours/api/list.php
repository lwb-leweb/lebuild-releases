<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../lib.php';

require_auth();
require_plugin_active('opening-hours');

$kind = (string) ($_GET['type'] ?? '');
if (!opening_hours_kind_valid($kind)) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidType']], 400);
}

try {
    $areas = opening_hours_fetch(OPENING_HOURS_AREAS);
    // Vergangene Ausnahmen zeigt niemand mehr an; die Zahl in der Leiste passt so zur Liste auf der Seite.
    $entries = $kind === OPENING_HOURS_AREAS ? $areas : opening_hours_upcoming(opening_hours_fetch($kind), opening_hours_now());
} catch (Throwable $e) {
    plugin_failure_response('load', $e);
}

json_response([
    'ok' => true,
    'type' => $kind,
    'label' => opening_hours_label($kind),
    'schema' => opening_hours_schema($kind, $areas),
    'rows' => array_map(static fn (array $entry): array => opening_hours_form_row($kind, $entry, $areas), $entries),
]);
