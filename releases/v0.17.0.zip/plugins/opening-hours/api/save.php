<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../lib.php';

require_auth();
require_plugin_active('opening-hours');
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$kind = (string) ($body['type'] ?? '');
if (!opening_hours_kind_valid($kind)) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidType']], 400);
}

try {
    $id = opening_hours_save($kind, is_array($body['data'] ?? null) ? $body['data'] : [], isset($body['id']) ? (int) $body['id'] : null);
} catch (InvalidArgumentException $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 400);
} catch (Throwable $e) {
    plugin_failure_response('save', $e);
}
le_activity_log((int) ($body['id'] ?? 0) > 0 ? 'plugin_entry_updated' : 'plugin_entry_created', le_activity_plugin_target('opening-hours', (int) $id));

json_response(['ok' => true, 'id' => $id]);
