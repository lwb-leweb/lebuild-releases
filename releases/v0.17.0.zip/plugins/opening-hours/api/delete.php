<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../lib.php';

require_auth();
require_plugin_active('opening-hours');
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$kind = (string) ($body['type'] ?? '');
$id = (int) ($body['id'] ?? 0);
if (!opening_hours_kind_valid($kind)) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidType']], 400);
}
if ($id <= 0) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidId']], 400);
}

try {
    $deleted = opening_hours_delete($kind, $id);
} catch (Throwable $e) {
    plugin_failure_response('delete', $e);
}
if (!$deleted) {
    json_response(['ok' => false, 'error' => API_TEXT['notFound']], 404);
}
le_activity_log('plugin_entry_deleted', le_activity_plugin_target('opening-hours', $id));

json_response(['ok' => true]);
