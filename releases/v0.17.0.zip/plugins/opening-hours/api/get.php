<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../lib.php';

require_auth();
require_plugin_active('opening-hours');

$kind = (string) ($_GET['type'] ?? '');
$id = (int) ($_GET['id'] ?? 0);
if (!opening_hours_kind_valid($kind)) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidType']], 400);
}

try {
    $entry = $id > 0 ? opening_hours_fetch_one($kind, $id) : null;
    $areas = opening_hours_fetch(OPENING_HOURS_AREAS);
    $schema = opening_hours_schema($kind, $areas);
} catch (Throwable $e) {
    plugin_failure_response('load', $e);
}
if ($entry === null) {
    json_response(['ok' => false, 'error' => API_TEXT['notFound']], 404);
}

json_response(['ok' => true, 'type' => $kind, 'schema' => $schema, 'row' => opening_hours_form_row($kind, $entry, $areas)]);
