DROP TABLE IF EXISTS opening_hours;
