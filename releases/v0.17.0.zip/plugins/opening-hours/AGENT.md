# Öffnungszeiten Plugin — Anleitung für KI-Agenten

## Was das Plugin tut

Öffnungszeiten wie im Google-Unternehmensprofil: Bereiche mit Wochenzeiten, Ausnahmen (Urlaub, Feiertag, Sonderzeiten) und daraus Wochenansicht, „Jetzt geöffnet“ und Hinweise auf der Website. Bedienung und Shortcodes: `README.md`.

## Was du als KI tun darfst

- Texte und Formate anpassen (`OPENING_HOURS_TEXT`, `OPENING_HOURS_PLACEHOLDER`, `*_FORMAT` in `lib.php`).
- Neue Wörter für „geschlossen“ bzw. „rund um die Uhr“ ergänzen (`OPENING_HOURS_CLOSED_WORDS`, `OPENING_HOURS_ALL_DAY_WORDS`).
- Ausgabe der Renderer und die Grundform in `assets/opening-hours.css` ändern; Klassen `oh-*` bleiben, Websites stylen darauf.
- Einträge für eine Website per `save.php` anlegen (Formularwerte wie in der README).

## Was du NICHT anfassen darfst

- Die Arten `bereiche`/`ausnahmen` nicht umbenennen: Sie stehen in der Spalte `kind` und im `data-le-list` der Seiten.
- Das JSON in `data` nur abwärtskompatibel ändern; `opening_hours_clean()` füllt fehlende Schlüssel auf.
- Kein eigenes Formular bauen: Formulare kommen aus `opening_hours_schema()` über `entry-form.js` (Website und Backend).

## Dateistruktur

- `plugin.json` — Manifest, Shortcodes `week`, `status`, `notices`, `inlineEdit`
- `lib.php` — Schema je Art, Einlesen der Zeiten, Speichern, Löschen, Berechnung des Stands, Ausgabe-Helfer, Hook `filter_site_html` (CSS)
- `api/list.php`, `get.php`, `save.php`, `delete.php` — Endpoints für Backend und Seiten-Editor
- `render/week.php`, `status.php`, `notices.php` — Shortcodes
- `admin/module.js`, `admin/icon.svg` — Backend: beide Listen, Formulare, Einbinde-Schnipsel
- `assets/opening-hours.css` — Grundform auf der Website
- `install*.sql`, `uninstall*.sql` — Tabelle `opening_hours`

## Datenbank

Eine Tabelle `opening_hours` (`id`, `kind`, `data` JSON, `created_at`, `updated_at`). Formularwerte (Zeiten als Text) und gespeicherte Daten (Zeiträume als `{from, to, note}`) sind verschieden: `opening_hours_form_row()` und `opening_hours_save()` übersetzen. Schema in der README.

## Häufige Anpassungen — wie geht das?

**Neues Feld für Bereiche:** in `opening_hours_schema()` ergänzen, in `opening_hours_save()` ins JSON schreiben, in `opening_hours_clean()` mit Vorgabe lesen, in `opening_hours_form_row()` zurückgeben, Renderer und README anpassen.

**Neue Anzeige:** Renderer `render/<name>.php`, Shortcode in `plugin.json`, Wurzelelement mit `OPENING_HOURS_MARK_ATTR` (sonst fehlt das CSS) und `le_list_attrs`/`le_single_attrs`, damit Angemeldete dort bearbeiten können.

**Andere Eingabe der Zeiten:** `opening_hours_parse_slots()` und die Muster `OPENING_HOURS_SPLIT_PATTERN`/`OPENING_HOURS_SLOT_PATTERN`; die Tests in `tests/run.php` (Abschnitt „Öffnungszeiten“) zeigen, was gelten muss.

## Fehlervermeidung

- Zeiten mit `setTime()` bilden, nicht mit `modify('+n minutes')` ab Mitternacht: am Tag der Zeitumstellung lägen sie sonst eine Stunde daneben.
- Ende vor Beginn heißt über Mitternacht; `24:00` gibt es nur als Ende. Überschneidungen lehnt das Speichern ab.
- „Gilt für“ gibt es im Schema erst ab zwei Bereichen, als Häkchen `bereich_<ID>` je Bereich; ohne diese Felder oder mit allen angehakt gilt eine Ausnahme für alle (`areas` leer). Ob eine Ausnahme für einen Bereich gilt, immer über `opening_hours_applies_to()`.
- Die Wochentabelle zeigt nicht die laufende Woche, sondern je Wochentag (Reihenfolge Mo–So) den nächsten Termin ab heute; Datum und Ausnahme rechnet `opening_hours_week()`, der Renderer nur aus.
- Die Liste der Ausnahmen (`list.php`, Renderer) zeigt nur laufende und kommende, damit die Zahl in der Leiste zur Seite passt.
- Laden die Einträge nicht, geben die Renderer nur `OPENING_HOURS_RENDER_FAILED` aus, der Grund geht per `error_log` ins Log (nie `$e->getMessage()` in die Seite).
