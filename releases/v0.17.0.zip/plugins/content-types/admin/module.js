let outletEl = null;
let ctxRef = null;
let currentType = '';
let currentLabel = '';
let currentSchema = [];

// Texte der Ansicht; die Gründe ungültiger Typen und Fehler beim Import kommen vom Server
// (CONTENT_TYPES_INVALID_TEXT, CONTENT_TYPES_IMPORT_TEXT).
const CT_TEXT = {
  noType: 'Kein Content-Typ ausgewählt.',
  invalid: 'Diese Content-Typen sind ungültig und erscheinen weder hier noch auf der Website:',
  importButton: 'Importieren',
  importInvalid: 'Die Datei enthält kein gültiges JSON.',
  imported: '%s Einträge importiert.',
  importedOne: '1 Eintrag importiert.'
};
// Dateiauswahl beim Import: JSON-Datei mit einer Liste von Einträgen (api/import.php).
const IMPORT_ACCEPT = '.json,application/json';

const contentTypesModule = {
  id: 'content-types',
  mount(outlet, ctx) {
    outletEl = outlet;
    ctxRef = ctx;
    currentType = ctx.subRoute || '';
    if (!currentType) {
      renderProblems(ctx.info && Array.isArray(ctx.info.problems) ? ctx.info.problems : []);
      return;
    }
    renderShell();
    loadList();
  },
  unmount() {
    if (ctxRef && ctxRef.ui && ctxRef.ui.closeModal) ctxRef.ui.closeModal();
    outletEl = null;
    ctxRef = null;
    currentType = '';
    currentLabel = '';
    currentSchema = [];
  }
};

export default contentTypesModule;

// Ohne Typ: Hinweis auf ungültige Typ-Definitionen (Eintrag CONTENT_TYPES_INVALID_LABEL der Seitenleiste).
function renderProblems(problems) {
  const text = problems.length ? CT_TEXT.invalid : CT_TEXT.noType;
  outletEl.innerHTML = '<section class="view-area"><div class="view-card"><p class="message">' + escapeHtml(text) + '</p>'
    + (problems.length ? '<ul>' + problems.map(function (problem) { return '<li>' + escapeHtml(problem) + '</li>'; }).join('') + '</ul>' : '')
    + '</div></section>';
}

function renderShell() {
  outletEl.innerHTML = `
    <section class="view-area content-types-admin">
      <div class="view-card span-12">
        <div class="topbar">
          <strong id="ctTitle">${escapeHtml(currentType)}</strong>
          <div class="form-actions">
            <button type="button" id="ctImportBtn" class="secondary">${CT_TEXT.importButton}</button>
            <input type="file" id="ctImportFile" accept="${IMPORT_ACCEPT}" hidden>
            <button type="button" id="ctNewBtn">Neuer Eintrag</button>
          </div>
        </div>
        <p id="ctMsg" class="message"></p>
        <div id="ctList" class="generic-list"></div>
      </div>
    </section>
  `;
  outletEl.querySelector('#ctNewBtn').addEventListener('click', function () {
    openForm(null);
  });
  const fileInput = outletEl.querySelector('#ctImportFile');
  outletEl.querySelector('#ctImportBtn').addEventListener('click', function () {
    fileInput.click();
  });
  fileInput.addEventListener('change', function () {
    const file = fileInput.files && fileInput.files[0];
    fileInput.value = '';
    if (file) importFile(file);
  });
}

// Import (nur Admins, prüft der Server): Datei lesen, Einträge schicken; ganz oder gar nicht, Meldung
// mit Zeile und Feld vom Server. Danach lädt die Liste neu. Bis zur Antwort ist der Knopf gesperrt,
// damit dieselbe Datei nicht doppelt angehängt wird.
function importFile(file) {
  const button = document.getElementById('ctImportBtn');
  button.disabled = true;
  file.text().then(function (text) {
    let entries;
    try {
      entries = JSON.parse(text);
    } catch (e) {
      throw new Error(CT_TEXT.importInvalid);
    }
    return ctxRef.api('/plugins/content-types/api/import.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: currentType, entries: entries })
    });
  }).then(function (data) {
    showMessage(data.imported === 1 ? CT_TEXT.importedOne : CT_TEXT.imported.replace('%s', data.imported), true);
    loadList();
  }).catch(showError).finally(function () {
    button.disabled = false;
  });
}

function loadList() {
  ctxRef.api('/plugins/content-types/api/list.php?type=' + encodeURIComponent(currentType))
    .then(function (data) {
      currentLabel = data.label || currentType;
      currentSchema = data.schema || [];
      const titleEl = document.getElementById('ctTitle');
      if (titleEl) titleEl.textContent = currentLabel;
      renderList(data.rows || []);
    })
    .catch(showError);
}

function renderList(rows) {
  const list = document.getElementById('ctList');
  if (!list) return;

  if (!rows.length) {
    list.innerHTML = '<p class="message">Noch keine Einträge.</p>';
    return;
  }

  list.innerHTML = '<ul>' + rows.map(function (row) {
    const title = ctxRef.ui.entryTitle(currentSchema, row);
    return `
      <li class="generic-list__row" data-id="${row.id}">
        <span class="generic-list__title">${escapeHtml(title)}</span>
        <div class="generic-list__actions">
          <button type="button" data-action="edit" data-id="${row.id}">Bearbeiten</button>
          <button type="button" data-action="delete" data-id="${row.id}" class="secondary">Löschen</button>
        </div>
      </li>
    `;
  }).join('') + '</ul>';

  list.querySelectorAll('button[data-action="edit"]').forEach(function (button) {
    button.addEventListener('click', function () {
      openFormFromServer(parseInt(button.dataset.id, 10));
    });
  });
  list.querySelectorAll('button[data-action="delete"]').forEach(function (button) {
    button.addEventListener('click', function () {
      const id = parseInt(button.dataset.id, 10);
      const row = rows.find(function (entry) { return Number(entry.id) === id; });
      if (!ctxRef.confirm(ctxRef.ui.deleteQuestion(currentSchema, row))) return;
      ctxRef.api('/plugins/content-types/api/delete.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: currentType, id: id })
      }).then(loadList).catch(showError);
    });
  });
}

function openFormFromServer(id) {
  ctxRef.api('/plugins/content-types/api/get.php?type=' + encodeURIComponent(currentType) + '&id=' + id)
    .then(function (data) {
      currentSchema = data.schema || currentSchema;
      openForm(data.row || null);
    })
    .catch(showError);
}

function openForm(row) {
  ctxRef.ui.openEntryForm({
    schema: currentSchema,
    row: row,
    save: function (data) {
      const body = { type: currentType, data: data };
      if (row && row.id) body.id = row.id;
      return ctxRef.api('/plugins/content-types/api/save.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
    },
    onSaved: loadList
  });
}

function showError(error) {
  showMessage(error.message || String(error), false);
}

function showMessage(text, ok) {
  const msg = document.getElementById('ctMsg');
  if (!msg) return;
  msg.textContent = text;
  msg.classList.toggle('ok', ok);
}

function escapeHtml(value) {
  return String(value || '').replace(/[&<>"']/g, function (char) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
  });
}
