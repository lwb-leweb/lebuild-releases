<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../lib.php';

// Einträge aus einer JSON-Datei anhängen (nur Admins), ganz oder gar nicht: content_types_import.
require_auth();
require_csrf();
require_admin();
require_plugin_active('content-types');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

// Grenze vor dem Einlesen (read_json_body liest den ganzen Body).
if ((int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > CONTENT_TYPES_IMPORT_MAX_BYTES) {
    json_response(['ok' => false, 'error' => sprintf(CONTENT_TYPES_IMPORT_TEXT['tooLarge'], CONTENT_TYPES_IMPORT_MAX_BYTES / BYTES_PER_MB), 'fields' => []], 413);
}

$body = read_json_body();
$type = (string) ($body['type'] ?? '');
if (!content_types_name_valid($type)) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidType']], 400);
}

// Ungültige Einträge wie beim Speichern einer Seite: 422 mit Meldung und fields (Zeile, Feld, Grund).
try {
    // Nacheinander mit dem Erledigen offener Uploads (le_open_uploads_hold): kein Bild verschwindet mitten im Import.
    $imported = le_open_uploads_hold(static fn (): int => content_types_import($type, $body['entries'] ?? null));
} catch (PluginFieldException $e) {
    $field = ['line' => $e->entry, 'id' => $e->field, 'label' => $e->label, 'reason' => $e->reason];
    json_response(['ok' => false, 'error' => content_types_import_message($e), 'fields' => [$field]], 422);
} catch (InvalidArgumentException $e) {
    json_response(['ok' => false, 'error' => $e->getMessage(), 'fields' => []], 422);
} catch (Throwable $e) {
    plugin_failure_response('import', $e);
}
le_activity_log('plugin_entries_imported', $type . ' (' . $imported . ')');

json_response(['ok' => true, 'imported' => $imported]);
