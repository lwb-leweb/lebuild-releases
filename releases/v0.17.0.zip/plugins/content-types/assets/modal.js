// Modal der Content-Typen auf der Website (eingebunden von content_types_filter_site_html, nur auf Seiten
// mit einer Liste eines Typs mit modal). Eine Karte mit data-ct-open="<id>" öffnet per Klick, Enter oder
// Leertaste den versteckten Inhalt data-ct-detail="<id>" (detail.php) in einem Dialog. Der Inhalt wird
// verschoben, nicht geklont: IDs darin stehen nie doppelt im DOM, Skripte der Website am Inhalt bleiben
// verbunden; beim Schließen wandert er zurück. Kein showModal(): Die Top-Layer-Ebene läge über der Leiste
// des Seiten-Editors. Adresse #<typ>-<slug|id> (data-ct-hash): Öffnen legt sie in den Verlauf, Zurück
// schließt, Laden mit ihr öffnet direkt. Enter und Leertaste lösen einen Klick auf die Karte aus, damit
// der Seiten-Editor beim Bearbeiten Maus und Tastatur gleich abfängt (dann öffnet das Formular).
// Elemente mit data-ct-close im Inhalt schließen wie der Schließen-Knopf; ein Link damit schließt und
// folgt dann seinem Ziel.

(function () {
  'use strict';

  const MODAL_TEXT = {
    close: 'Schließen',
    closeSymbol: '×'
  };
  const ATTR = {
    open: 'data-ct-open',
    detail: 'data-ct-detail',
    hash: 'data-ct-hash',
    close: 'data-ct-close'
  };
  const CLASS = {
    modal: 'ct-modal',
    dialog: 'ct-modal__dialog',
    close: 'ct-modal__close',
    // an <html>, solange ein Modal offen ist (Scroll-Sperre in modal.css)
    open: 'ct-modal-open'
  };
  // Ereignisse mit dem Seiten-Editor (core/plugins.php LE_ITEM_DIALOG_EVENT, LE_LIST_RELOADED_EVENT).
  const EVENTS = {
    itemDialog: 'le-item-dialog',
    listReloaded: 'le-list-reloaded'
  };
  const FOCUSABLE = 'a[href], area[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), iframe, summary, [contenteditable="true"], [tabindex]:not([tabindex="-1"])';
  const HEADING = 'h1, h2, h3, h4, h5, h6';

  // Offenes Modal: { root, dialog, source (Hülle data-ct-detail), nodes (verschobener Inhalt), opener (Karte,
  // auf die der Fokus zurückgeht), id, hash }.
  let current = null;
  // Adresse, die dieses Skript beim Öffnen in den Verlauf gelegt hat: Schließen geht dann zurück.
  let pushedHash = null;
  // Klick auf den Hintergrund zählt nur, wenn er dort auch begann (nicht Ziehen aus dem Dialog).
  let pressedOnBackdrop = false;
  // Scrollposition beim Schließen über Zurück: Der Browser stellt nach popstate die des früheren
  // Verlaufseintrags her; danach setzen wir sie zurück.
  let keepScroll = null;

  function byAttr(attr, value) {
    return '[' + attr + '="' + CSS.escape(value) + '"]';
  }

  function detailByHash(hash) {
    return hash === '' ? null : document.querySelector('[' + ATTR.detail + ']' + byAttr(ATTR.hash, hash));
  }

  // Nächstes Element zu selector, gesucht von start aus in immer größeren Vorfahren: Karte und Hülle derselben
  // Liste, auch wenn derselbe Eintrag in einer zweiten Liste der Seite steht.
  function nearest(start, selector) {
    for (let el = start.parentElement; el; el = el.parentElement) {
      const found = el.querySelector(selector);
      if (found) return found;
    }
    return null;
  }

  function focusables() {
    return Array.prototype.filter.call(current.dialog.querySelectorAll(FOCUSABLE), function (el) {
      return el.getClientRects().length > 0;
    });
  }

  // Erstes sichtbares fokussierbares Element (meist Schließen); blendet die Website alles aus, der Dialog.
  function focusFirst() {
    (focusables()[0] || current.dialog).focus();
  }

  // Adresse ohne #; kaputte Kodierung gilt als unbekannt.
  function currentHash() {
    try {
      return decodeURIComponent(window.location.hash.slice(1));
    } catch (e) {
      return '';
    }
  }

  // Immer mit Pfad: Ein <base href> (eigene Seiten der Content-Typen) löste „#…“ sonst gegen die Startseite auf.
  function setHash(hash, push) {
    const url = window.location.pathname + window.location.search + (hash === '' ? '' : '#' + encodeURIComponent(hash));
    if (push) window.history.pushState(null, '', url);
    else window.history.replaceState(window.history.state, '', url);
  }

  // Meldet dem Seiten-Editor den Eintrag im Dialog (Karte) bzw. null nach dem Schließen.
  function announce() {
    const item = current ? current.opener : null;
    document.dispatchEvent(new CustomEvent(EVENTS.itemDialog, { detail: { item: item } }));
  }

  function build() {
    const root = document.createElement('div');
    root.className = CLASS.modal;
    root.setAttribute('role', 'dialog');
    root.setAttribute('aria-modal', 'true');
    const dialog = document.createElement('div');
    dialog.className = CLASS.dialog;
    dialog.tabIndex = -1;
    const close = document.createElement('button');
    close.type = 'button';
    close.className = CLASS.close;
    close.setAttribute('aria-label', MODAL_TEXT.close);
    close.textContent = MODAL_TEXT.closeSymbol;
    close.addEventListener('click', closeByUser);
    root.addEventListener('pointerdown', function (event) {
      pressedOnBackdrop = event.target === root;
    });
    root.addEventListener('click', function (event) {
      const closer = event.target instanceof Element ? event.target.closest('[' + ATTR.close + ']') : null;
      if (closer && dialog.contains(closer) && !event.defaultPrevented) {
        if (!closer.matches('a[href]')) {
          event.preventDefault();
          closeByUser();
        } else if (!event.ctrlKey && !event.metaKey && !event.shiftKey) {
          closeQuietly();
        }
      } else if (event.target === root && pressedOnBackdrop) {
        closeByUser();
      }
      pressedOnBackdrop = false;
    });
    dialog.append(close);
    root.append(dialog);
    document.body.append(root);
    document.documentElement.classList.add(CLASS.open);
    current = { root: root, dialog: dialog, source: null, nodes: [], opener: null, id: '', hash: '' };
  }

  // Inhalt zurück in seine Hülle; ist sie weg (Liste neu geladen), fällt er weg.
  function restore() {
    if (current.source && current.source.isConnected) current.source.append.apply(current.source, current.nodes);
    else current.nodes.forEach(function (node) { node.remove(); });
    current.nodes = [];
  }

  // Zeigt den Inhalt von detail (öffnet oder tauscht). opener: angeklickte Karte (sonst die der Hülle
  // nächste); history: 'push', 'replace' oder null (Adresse stimmt schon); focus: Fokus in den Dialog
  // (sonst nur, wenn er verloren ist).
  function show(detail, opener, history, focus) {
    if (current && current.source === detail) return;
    const before = current ? current.hash : null;
    if (current) restore();
    else build();
    current.source = detail;
    current.opener = opener || nearest(detail, byAttr(ATTR.open, detail.getAttribute(ATTR.detail)));
    current.id = detail.getAttribute(ATTR.detail);
    current.hash = detail.getAttribute(ATTR.hash) || '';
    current.nodes = Array.prototype.slice.call(detail.childNodes);
    current.dialog.append.apply(current.dialog, current.nodes);
    const heading = current.dialog.querySelector(HEADING);
    if (heading) current.root.setAttribute('aria-label', heading.textContent.trim());
    else current.root.removeAttribute('aria-label');
    if (history && currentHash() !== current.hash) setHash(current.hash, history === 'push');
    // Getauscht statt neu geöffnet: der eigene Verlaufseintrag trägt jetzt die neue Adresse.
    if (history === 'push') pushedHash = current.hash;
    else if (history === 'replace' && before !== null && pushedHash === before) pushedHash = current.hash;
    const active = document.activeElement;
    if (focus || !active || active === document.body) focusFirst();
    announce();
  }

  function closeNow(focusBack) {
    if (!current) return;
    const opener = current.opener;
    restore();
    current.root.remove();
    document.documentElement.classList.remove(CLASS.open);
    current = null;
    announce();
    if (focusBack && opener && opener.isConnected) opener.focus();
  }

  // Schließen über Knopf, Esc oder Hintergrund: hat das Skript die Adresse in den Verlauf gelegt, geht es
  // zurück; sonst (Laden mit Adresse) wird sie ersetzt, damit Schließen nie die Seite verlässt.
  function closeByUser() {
    if (!current) return;
    const hash = current.hash;
    const back = pushedHash === hash && currentHash() === hash;
    pushedHash = null;
    closeNow(true);
    if (back) {
      keepScroll = { left: window.scrollX, top: window.scrollY };
      window.history.back();
    }
    else if (currentHash() === hash) setHash('', false);
  }

  // Schließen, ohne den Verlauf zu bewegen und ohne Fokus auf die Karte: Link im Inhalt, der gleich
  // navigiert (data-ct-close), oder Eintrag nach dem Neuladen der Liste nicht mehr da.
  function closeQuietly() {
    const hash = current.hash;
    pushedHash = null;
    closeNow(false);
    if (currentHash() === hash) setHash('', false);
  }

  // Adresse → Modal: bekannte öffnet, sonst schließt ein offenes (ohne Fokus auf die Karte, wenn die
  // Adresse auf etwas anderes der Seite zeigt).
  function sync() {
    if (keepScroll) {
      const position = keepScroll;
      keepScroll = null;
      window.setTimeout(function () { window.scrollTo(position); }, 0);
    }
    const hash = currentHash();
    const detail = detailByHash(hash);
    if (detail) {
      show(detail, null, null, true);
      return;
    }
    if (current) {
      pushedHash = null;
      closeNow(hash === '');
    }
  }

  // Fokus bleibt im Dialog: Tab vom letzten Element zum ersten (Schließen) und umgekehrt, ohne
  // fokussierbare Elemente auf dem Dialog. Nur über Tab, nicht über focusin: Leiste und Formular des
  // Seiten-Editors müssen den Fokus bekommen können.
  function trapTab(event) {
    const items = focusables();
    const first = items[0];
    const last = items[items.length - 1];
    const active = document.activeElement;
    if (!first) {
      event.preventDefault();
      current.dialog.focus();
    } else if (!current.root.contains(active)) {
      event.preventDefault();
      first.focus();
    } else if (event.shiftKey && (active === first || active === current.dialog)) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && active === last) {
      event.preventDefault();
      first.focus();
    }
  }

  document.addEventListener('click', function (event) {
    if (event.defaultPrevented || !(event.target instanceof Element)) return;
    const opener = event.target.closest('[' + ATTR.open + ']');
    const detail = opener ? nearest(opener, byAttr(ATTR.detail, opener.getAttribute(ATTR.open))) : null;
    if (!detail) return;
    event.preventDefault();
    show(detail, opener, current ? 'replace' : 'push', true);
  });

  document.addEventListener('keydown', function (event) {
    if (event.defaultPrevented) return;
    if (current && event.key === 'Escape') {
      event.preventDefault();
      closeByUser();
    } else if (current && event.key === 'Tab') {
      trapTab(event);
    } else if ((event.key === 'Enter' || event.key === ' ') && !event.repeat && event.target instanceof Element && event.target.matches('[' + ATTR.open + ']')) {
      event.preventDefault();
      event.target.click();
    }
  });

  // Der Seiten-Editor hat eine Liste neu geladen (nach Speichern, Löschen, Sortieren). War es die Liste
  // des offenen Modals (seine Hülle ist weg): Inhalt aus der neuen Hülle; gibt es den Eintrag dort nicht
  // mehr (gelöscht, Ziel geändert), schließen.
  document.addEventListener(EVENTS.listReloaded, function (event) {
    if (!current || current.source.isConnected) return;
    const detail = event.target instanceof Element ? event.target.querySelector(byAttr(ATTR.detail, current.id)) : null;
    if (!detail) {
      closeQuietly();
      return;
    }
    // Neue Adresse (Slug geändert) ersetzt die alte, ohne neuen Verlaufseintrag.
    show(detail, null, 'replace', false);
  });

  window.addEventListener('popstate', sync);
  window.addEventListener('hashchange', sync);
  // Adresse beim Laden erst bei DOMContentLoaded: Das Skript läuft mit defer (readyState schon
  // „interactive“), der Seiten-Editor als Modul danach; zu DOMContentLoaded hört er schon zu.
  if (document.readyState === 'complete') sync();
  else document.addEventListener('DOMContentLoaded', sync);
}());
