<?php
/**
 * Banner-HTML. Wird von cookie_banner_inject_banner() vor </body> eingesetzt.
 * Erwartet: $bannerConfig (Array).
 */
$bannerCategories = $bannerConfig['categories'] ?? [];
$bannerTexts = $bannerConfig['texts'] ?? [];
$bannerVersion = (int) ($bannerConfig['version'] ?? 1);
$bannerPolicyUrl = (string) ($bannerConfig['policyUrl'] ?? '');

$bannerClientConfig = [
    'v' => $bannerVersion,
    'categories' => array_map(static function (array $cat): array {
        return [
            'id' => (string) ($cat['id'] ?? ''),
            'label' => (string) ($cat['label'] ?? ''),
            'required' => !empty($cat['required']),
        ];
    }, $bannerCategories),
];

$bannerConfigJson = json_encode($bannerClientConfig, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
if (!is_string($bannerConfigJson)) {
    $bannerConfigJson = '{}';
}
$bannerConfigJson = str_replace(['</', '<!--', '-->'], ['<\/', '<\!--', '--\>'], $bannerConfigJson);
?>
<div id="ccBannerRoot" data-cc-banner-root data-cc-version="<?= htmlspecialchars((string) $bannerVersion, ENT_QUOTES) ?>" hidden>
  <style>
    .cc-placeholder{position:relative;display:block;background:#f4f4f5;border:1px dashed #c4c4c8;border-radius:8px;padding:1rem;margin:1rem 0;min-height:160px;text-align:center;}
    .cc-placeholder iframe{display:none !important;}
    .cc-placeholder--loaded{padding:0;border:0;background:transparent;min-height:0;}
    .cc-placeholder--loaded iframe{display:block !important;width:100%;}
    .cc-placeholder--loaded .cc-placeholder__body{display:none;}
    .cc-placeholder__body{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.75rem;}
    .cc-placeholder__text{margin:0;font-size:.95rem;color:#3a3a40;}
    .cc-placeholder__btn{cursor:pointer;background:#222;color:#fff;border:0;padding:.6rem 1rem;border-radius:6px;font-size:.9rem;}
    .cc-placeholder__btn:hover{background:#000;}

    .cc-banner{position:fixed;left:0;right:0;bottom:0;z-index:2147483600;background:#fff;color:#1a1a1a;font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;font-size:14px;line-height:1.5;box-shadow:0 -10px 30px rgba(0,0,0,.15);border-top:1px solid #e3e3e6;}
    .cc-banner__inner{max-width:1100px;margin:0 auto;padding:1.25rem 1.25rem 1.5rem;display:grid;grid-template-columns:1fr auto;gap:1rem;align-items:start;}
    .cc-banner__title{margin:0 0 .35rem;font-size:1.05rem;font-weight:600;}
    .cc-banner__intro{margin:0;color:#3a3a40;}
    .cc-banner__intro a{color:#1f6feb;text-decoration:underline;}
    .cc-banner__actions{display:flex;flex-wrap:wrap;gap:.5rem;align-items:center;justify-content:flex-end;}
    .cc-btn{appearance:none;cursor:pointer;font:inherit;padding:.6rem 1rem;border-radius:6px;border:1px solid transparent;background:#fff;color:#222;}
    .cc-btn--reject{border-color:#222;background:#fff;color:#222;}
    .cc-btn--settings{border-color:#bcbcc1;background:#fff;color:#222;}
    .cc-btn--accept{background:#222;color:#fff;border-color:#222;}
    .cc-btn:hover{filter:brightness(.95);}
    .cc-banner__settings{display:none;margin-top:1rem;padding-top:1rem;border-top:1px solid #e3e3e6;grid-column:1 / -1;}
    .cc-banner--open .cc-banner__settings{display:block;}
    .cc-cat{display:flex;gap:.75rem;align-items:flex-start;padding:.55rem 0;border-bottom:1px solid #f0f0f3;}
    .cc-cat:last-child{border-bottom:0;}
    .cc-cat__input{margin-top:.25rem;}
    .cc-cat__label{font-weight:600;}
    .cc-cat__hint{display:block;font-size:.85rem;color:#666;}
    .cc-cat__save{margin-top:.75rem;text-align:right;}
    @media (max-width: 720px){
      .cc-banner__inner{grid-template-columns:1fr;}
      .cc-banner__actions{justify-content:stretch;}
      .cc-btn{flex:1 1 auto;}
    }
  </style>

  <aside class="cc-banner" role="dialog" aria-modal="false" aria-labelledby="ccBannerTitle">
    <div class="cc-banner__inner">
      <div class="cc-banner__copy">
        <h2 class="cc-banner__title" id="ccBannerTitle"><?= htmlspecialchars((string) ($bannerTexts['title'] ?? '')) ?></h2>
        <p class="cc-banner__intro">
          <?= htmlspecialchars((string) ($bannerTexts['intro'] ?? '')) ?>
          <?php if ($bannerPolicyUrl !== ''): ?>
            <a href="<?= htmlspecialchars($bannerPolicyUrl, ENT_QUOTES) ?>"><?= htmlspecialchars((string) ($bannerTexts['policyLink'] ?? 'Datenschutzerklärung')) ?></a>
          <?php endif ?>
        </p>
      </div>
      <div class="cc-banner__actions">
        <button type="button" class="cc-btn cc-btn--reject" data-cc-action="reject"><?= htmlspecialchars((string) ($bannerTexts['reject'] ?? 'Ablehnen')) ?></button>
        <button type="button" class="cc-btn cc-btn--settings" data-cc-action="settings"><?= htmlspecialchars((string) ($bannerTexts['settings'] ?? 'Einstellungen')) ?></button>
        <button type="button" class="cc-btn cc-btn--accept" data-cc-action="accept"><?= htmlspecialchars((string) ($bannerTexts['accept'] ?? 'Alle akzeptieren')) ?></button>
      </div>

      <div class="cc-banner__settings" data-cc-settings>
        <?php foreach ($bannerCategories as $cat): ?>
          <?php
            $catId = (string) ($cat['id'] ?? '');
            $catLabel = (string) ($cat['label'] ?? $catId);
            $catRequired = !empty($cat['required']);
          ?>
          <label class="cc-cat">
            <input class="cc-cat__input" type="checkbox" data-cc-cat="<?= htmlspecialchars($catId, ENT_QUOTES) ?>"<?= $catRequired ? ' checked disabled' : '' ?>>
            <span>
              <span class="cc-cat__label"><?= htmlspecialchars($catLabel) ?><?= $catRequired ? ' (immer aktiv)' : '' ?></span>
            </span>
          </label>
        <?php endforeach ?>
        <div class="cc-cat__save">
          <button type="button" class="cc-btn cc-btn--accept" data-cc-action="save"><?= htmlspecialchars((string) ($bannerTexts['save'] ?? 'Auswahl speichern')) ?></button>
        </div>
      </div>
    </div>
  </aside>

  <script>
  (function(){
    var CFG = <?= $bannerConfigJson ?>;
    var STORAGE_KEY = 'cc_consent';
    var root = document.getElementById('ccBannerRoot');
    if (!root) return;
    var banner = root.querySelector('.cc-banner');

    function readConsent(){
      try {
        var raw = window.localStorage.getItem(STORAGE_KEY);
        if (!raw) return null;
        var parsed = JSON.parse(raw);
        if (!parsed || typeof parsed !== 'object') return null;
        if (parsed.v !== CFG.v) return null;
        if (!parsed.categories || typeof parsed.categories !== 'object') return null;
        return parsed;
      } catch (e) { return null; }
    }
    function writeConsent(categories){
      var data = { v: CFG.v, ts: Math.floor(Date.now()/1000), categories: categories };
      try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); } catch (e) {}
      return data;
    }
    function defaultsAllFalse(){
      var out = {};
      CFG.categories.forEach(function(c){ out[c.id] = !!c.required; });
      return out;
    }
    function defaultsAllTrue(){
      var out = {};
      CFG.categories.forEach(function(c){ out[c.id] = true; });
      return out;
    }
    function readFromForm(){
      var out = defaultsAllFalse();
      banner.querySelectorAll('[data-cc-cat]').forEach(function(box){
        var id = box.getAttribute('data-cc-cat');
        if (box.disabled) { out[id] = true; return; }
        out[id] = !!box.checked;
      });
      return out;
    }
    function fillForm(categories){
      banner.querySelectorAll('[data-cc-cat]').forEach(function(box){
        var id = box.getAttribute('data-cc-cat');
        if (box.disabled) { box.checked = true; return; }
        box.checked = !!(categories && categories[id]);
      });
    }
    function showBanner(open){
      root.removeAttribute('hidden');
      banner.classList.toggle('cc-banner--open', !!open);
    }
    function hideBanner(){
      root.setAttribute('hidden', '');
      banner.classList.remove('cc-banner--open');
    }
    function dispatchConsent(categories){
      try {
        window.dispatchEvent(new CustomEvent('cc:consent', { detail: { categories: categories } }));
      } catch (e) {
        var ev = document.createEvent('CustomEvent');
        ev.initCustomEvent('cc:consent', false, false, { categories: categories });
        window.dispatchEvent(ev);
      }
    }
    function applyConsent(categories){
      // Unblock iframes
      document.querySelectorAll('iframe[data-cc]').forEach(function(frame){
        var cat = frame.getAttribute('data-cc');
        if (categories[cat]) {
          var src = frame.getAttribute('data-cc-src');
          if (src && frame.getAttribute('src') !== src) {
            frame.setAttribute('src', src);
          }
          var placeholder = frame.closest('.cc-placeholder');
          if (placeholder) placeholder.classList.add('cc-placeholder--loaded');
        }
      });
      // Unblock scripts (clone with type=text/javascript); schon geladene nicht noch einmal
      document.querySelectorAll('script[type="text/plain"][data-cc]:not([data-cc-loaded])').forEach(function(script){
        var cat = script.getAttribute('data-cc');
        if (!categories[cat]) return;
        var clone = document.createElement('script');
        for (var i = 0; i < script.attributes.length; i++) {
          var attr = script.attributes[i];
          if (attr.name === 'type' || attr.name === 'data-cc' || attr.name === 'data-cc-src' || attr.name === 'data-cc-service') continue;
          clone.setAttribute(attr.name, attr.value);
        }
        var src = script.getAttribute('data-cc-src');
        if (src) {
          clone.src = src;
        } else if (script.textContent) {
          clone.textContent = script.textContent;
        }
        script.parentNode.insertBefore(clone, script);
        script.setAttribute('data-cc-loaded', '1');
      });
    }
    function save(categories){
      writeConsent(categories);
      hideBanner();
      applyConsent(categories);
      dispatchConsent(categories);
    }
    function openSettings(){
      var existing = readConsent();
      fillForm(existing ? existing.categories : defaultsAllFalse());
      showBanner(true);
    }
    function loadOne(placeholder){
      var frame = placeholder.querySelector('iframe[data-cc]');
      if (!frame) return;
      var src = frame.getAttribute('data-cc-src');
      if (src) frame.setAttribute('src', src);
      placeholder.classList.add('cc-placeholder--loaded');
    }

    // Wire up buttons
    banner.addEventListener('click', function(ev){
      var btn = ev.target.closest('[data-cc-action]');
      if (!btn) return;
      var action = btn.getAttribute('data-cc-action');
      if (action === 'accept') save(defaultsAllTrue());
      else if (action === 'reject') save(defaultsAllFalse());
      else if (action === 'save') save(readFromForm());
      else if (action === 'settings') {
        banner.classList.toggle('cc-banner--open');
        fillForm((readConsent() && readConsent().categories) || defaultsAllFalse());
      }
    });

    // Granular: per-placeholder load
    document.addEventListener('click', function(ev){
      var loadBtn = ev.target.closest('[data-cc-load]');
      if (!loadBtn) return;
      var ph = loadBtn.closest('.cc-placeholder');
      if (ph) loadOne(ph);
    });

    // Settings-link shortcode
    document.addEventListener('click', function(ev){
      var link = ev.target.closest('[data-cc-settings-link]');
      if (!link) return;
      ev.preventDefault();
      openSettings();
    });

    // Init
    var existing = readConsent();
    if (existing) {
      applyConsent(existing.categories);
      dispatchConsent(existing.categories);
    } else {
      fillForm(defaultsAllFalse());
      showBanner(false);
    }

    // Public hook for granular re-open
    window.cookieBanner = {
      open: openSettings,
      consent: function(){ return readConsent(); }
    };
  })();
  </script>
</div>
