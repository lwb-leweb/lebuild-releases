<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/utils.php';
require_once __DIR__ . '/../../core/plugins.php';

// Wert eines Attributs: in doppelten oder einfachen Anführungszeichen oder ohne (minifiziert, <iframe src=https://…>),
// je eine Gruppe, die beiden anderen bleiben leer.
const COOKIE_BANNER_ATTR_VALUE = '(?:"([^"]*)"|\'([^\']*)\'|([^\s"\'=<>`]+))';

// Meldungen an den Admin (save.php).
const COOKIE_BANNER_TEXT = [
    'invalidPolicyUrl' => 'Die Datenschutz-URL muss ein Pfad (z. B. /datenschutz) oder eine http(s)-Adresse sein.',
    'saveFailed' => 'Die Einstellungen ließen sich nicht speichern.',
];

// Kategorien, die die Admin-UI nicht entfernen und deren ID sie nicht ändern kann (nur den Namen).
// Die Dienste in services.php hängen an statistics und marketing.
const COOKIE_BANNER_FIXED_CATEGORIES = ['necessary', 'statistics', 'marketing'];

function cookie_banner_config_path(): string
{
    return plugin_data_path('cookie-banner') . '/config.json';
}

function cookie_banner_default_config(): array
{
    return [
        'enabled' => true,
        'version' => 1,
        'categories' => [
            ['id' => 'necessary',  'label' => 'Notwendig',  'required' => true],
            ['id' => 'statistics', 'label' => 'Statistik',  'required' => false],
            ['id' => 'marketing',  'label' => 'Marketing',  'required' => false],
        ],
        'texts' => [
            'title' => 'Wir respektieren Ihre Privatsphäre',
            'intro' => 'Wir nutzen Cookies und externe Dienste, um die Funktion der Website zu sichern und – sofern Sie zustimmen – die Nutzung zu analysieren. Sie entscheiden selbst, was geladen wird.',
            'accept' => 'Alle akzeptieren',
            'reject' => 'Ablehnen',
            'settings' => 'Einstellungen',
            'save' => 'Auswahl speichern',
            'policyLink' => 'Datenschutzerklärung',
        ],
        'policyUrl' => '/datenschutz',
        'placeholder' => [
            'youtube' => 'Video laden? Es werden Daten an YouTube übertragen.',
            'maps' => 'Karte laden? Es werden Daten an Google übertragen.',
            'default' => 'Externer Inhalt blockiert. Klicken, um zu laden.',
        ],
    ];
}

function cookie_banner_load_config(): array
{
    $path = cookie_banner_config_path();
    $defaults = cookie_banner_default_config();
    if (!is_file($path)) {
        return $defaults;
    }
    $raw = json_decode((string) file_get_contents($path), true);
    if (!is_array($raw)) {
        return $defaults;
    }
    return cookie_banner_merge_config($defaults, $raw);
}

function cookie_banner_merge_config(array $defaults, array $given): array
{
    $out = $defaults;
    if (array_key_exists('enabled', $given)) {
        $out['enabled'] = (bool) $given['enabled'];
    }
    if (isset($given['version']) && is_numeric($given['version'])) {
        $out['version'] = max(1, (int) $given['version']);
    }
    if (isset($given['policyUrl']) && is_string($given['policyUrl'])) {
        // Ungültige Werte (z. B. javascript:) nie ausgeben, auch nicht aus einer alten config.json.
        $policyUrl = trim($given['policyUrl']);
        $out['policyUrl'] = cookie_banner_policy_url_valid($policyUrl) ? $policyUrl : '';
    }
    if (isset($given['texts']) && is_array($given['texts'])) {
        foreach ($defaults['texts'] as $key => $fallback) {
            if (isset($given['texts'][$key]) && is_string($given['texts'][$key])) {
                $value = trim($given['texts'][$key]);
                if ($value !== '') {
                    $out['texts'][$key] = $value;
                }
            }
        }
    }
    if (isset($given['categories']) && is_array($given['categories'])) {
        $cats = [];
        $seen = [];
        foreach ($given['categories'] as $cat) {
            if (!is_array($cat)) {
                continue;
            }
            $id = isset($cat['id']) && is_string($cat['id']) ? trim($cat['id']) : '';
            if ($id === '' || !preg_match('/^[a-z][a-z0-9_-]*$/', $id) || isset($seen[$id])) {
                continue;
            }
            $label = isset($cat['label']) && is_string($cat['label']) ? trim($cat['label']) : '';
            if ($label === '') {
                $label = $id;
            }
            $required = !empty($cat['required']);
            if ($id === 'necessary') {
                $required = true;
            }
            $seen[$id] = true;
            $cats[] = ['id' => $id, 'label' => $label, 'required' => $required];
        }
        // Feste Kategorien fehlen nie: die Registry ordnet ihre Dienste diesen IDs zu, ohne sie
        // laden YouTube, Maps, Pixel usw. auch nach „Alle akzeptieren“ nie. Eine fehlende kommt
        // mit Standardnamen hinter die vorige feste (necessary an den Anfang).
        $insertAt = 0;
        foreach ($defaults['categories'] as $fixed) {
            if (!in_array($fixed['id'], COOKIE_BANNER_FIXED_CATEGORIES, true)) {
                continue;
            }
            $pos = array_search($fixed['id'], array_column($cats, 'id'), true);
            if ($pos === false) {
                array_splice($cats, $insertAt, 0, [$fixed]);
                $pos = $insertAt;
            }
            $insertAt = max($insertAt, $pos + 1);
        }
        if (!empty($cats)) {
            $out['categories'] = $cats;
        }
    }
    if (isset($given['placeholder']) && is_array($given['placeholder'])) {
        foreach ($given['placeholder'] as $key => $text) {
            if (is_string($key) && is_string($text) && trim($text) !== '') {
                $out['placeholder'][$key] = trim($text);
            }
        }
    }
    return $out;
}

/**
 * Datenschutz-Link: leer, ein Pfad/relativer Verweis ohne Schema oder http(s). Steuerzeichen
 * fallen weg, weil Browser Tab und Zeilenumbruch im Schema überlesen („java\tscript:“).
 */
function cookie_banner_policy_url_valid(string $url): bool
{
    if (preg_match('/[\x00-\x1f\x7f]/', $url)) {
        return false;
    }
    if (!preg_match('/^([a-z][a-z0-9+.\-]*):/i', $url, $scheme)) {
        return true;
    }
    return in_array(strtolower($scheme[1]), ['http', 'https'], true);
}

function cookie_banner_save_config(array $config): void
{
    $defaults = cookie_banner_default_config();
    $merged = cookie_banner_merge_config($defaults, $config);
    $json = json_encode($merged, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        throw new RuntimeException('Cannot encode cookie-banner config');
    }
    write_file_atomic(cookie_banner_config_path(), $json . "\n");
}

function cookie_banner_services(): array
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    $services = require __DIR__ . '/services.php';
    $cache = is_array($services) ? $services : [];
    return $cache;
}

function cookie_banner_match_service(string $url): ?array
{
    $url = trim($url);
    if ($url === '' || str_starts_with($url, 'about:') || str_starts_with($url, 'data:') || str_starts_with($url, 'javascript:')) {
        return null;
    }
    if (str_starts_with($url, '//')) {
        $url = 'https:' . $url;
    }
    if (preg_match('#^/[^/]#', $url) || str_starts_with($url, '#')) {
        return null;
    }
    $parts = @parse_url($url);
    if (!is_array($parts) || empty($parts['host'])) {
        return null;
    }
    $host = strtolower($parts['host']);
    $path = isset($parts['path']) ? strtolower($parts['path']) : '';
    $hostPath = $host . $path;
    foreach (cookie_banner_services() as $key => $service) {
        foreach ($service['hosts'] as $needle) {
            $needle = strtolower($needle);
            if (str_contains($needle, '/')) {
                if (str_contains($hostPath, $needle)) {
                    return ['key' => $key] + $service;
                }
            } elseif ($host === $needle || str_ends_with($host, '.' . $needle)) {
                return ['key' => $key] + $service;
            }
        }
    }
    return null;
}

function cookie_banner_filter_site_html(string $html): string
{
    if ($html === '' || stripos($html, '<') === false) {
        return $html;
    }
    $config = cookie_banner_load_config();
    if (empty($config['enabled'])) {
        return $html;
    }
    $html = cookie_banner_rewrite_html($html, $config);
    $html = cookie_banner_inject_banner($html, $config);
    return $html;
}

function cookie_banner_rewrite_html(string $html, array $config): string
{
    $services = cookie_banner_services();
    if (empty($services)) {
        return $html;
    }

    $html = preg_replace_callback(
        '#<iframe\b([^>]*)>(.*?)</iframe\s*>#is',
        static function (array $match) use ($config): string {
            return cookie_banner_rewrite_iframe_tag($match[0], $match[1], $config);
        },
        $html
    ) ?? $html;

    $html = preg_replace_callback(
        '#<script\b([^>]*)\bsrc\s*=\s*' . COOKIE_BANNER_ATTR_VALUE . '([^>]*)>#i',
        static function (array $match) use ($config): string {
            return cookie_banner_rewrite_script_tag($match[0], $match[2] . $match[3] . $match[4], $config);
        },
        $html
    ) ?? $html;

    // Inline-Loader (Meta-Pixel, Hotjar, GTM) laden ihr Script selbst nach: Scripts ohne src,
    // deren Code einen Host eines Script-Dienstes nennt, laufen erst nach der Einwilligung.
    $html = preg_replace_callback(
        '#<script\b([^>]*)>(.*?)</script\s*>#is',
        static function (array $match): string {
            return cookie_banner_rewrite_inline_script($match[0], $match[1], $match[2]);
        },
        $html
    ) ?? $html;

    return $html;
}

/** Dienst vom Typ script, dessen Host (oder eine Subdomain davon) im Code eines Inline-Scripts steht. */
function cookie_banner_match_inline_service(string $code): ?array
{
    foreach (cookie_banner_services() as $key => $service) {
        if (($service['type'] ?? '') !== 'script') {
            continue;
        }
        foreach ($service['hosts'] as $needle) {
            $pattern = '#(?<![a-z0-9.-])(?:[a-z0-9-]+\.)*' . preg_quote(strtolower($needle), '#') . '(?![a-z0-9-]|\.[a-z0-9])#i';
            if (preg_match($pattern, $code)) {
                return ['key' => $key] + $service;
            }
        }
    }
    return null;
}

function cookie_banner_rewrite_inline_script(string $fullTag, string $attrs, string $code): string
{
    if (stripos($attrs, 'data-cc') !== false || preg_match('#(?<![\w-])src\s*=#i', $attrs)) {
        return $fullTag;
    }
    // Nur ausführbare Scripts (ohne type oder mit JavaScript-type), keine JSON-Blöcke und Module.
    $typePattern = '#(?<![\w-])type\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))#i';
    if (preg_match($typePattern, $attrs, $typeMatch)) {
        $type = strtolower(trim($typeMatch[1] . ($typeMatch[2] ?? '') . ($typeMatch[3] ?? '')));
        if (!in_array($type, ['', 'text/javascript', 'application/javascript'], true)) {
            return $fullTag;
        }
    }
    $service = cookie_banner_match_inline_service($code);
    if ($service === null) {
        return $fullTag;
    }
    $rest = trim((string) preg_replace($typePattern, '', $attrs));
    return '<script type="text/plain"'
        . ' data-cc="' . htmlspecialchars($service['category'], ENT_QUOTES) . '"'
        . ' data-cc-service="' . htmlspecialchars($service['key'], ENT_QUOTES) . '"'
        . ($rest !== '' ? ' ' . $rest : '') . '>'
        . $code . '</script>';
}

function cookie_banner_rewrite_iframe_tag(string $fullTag, string $attrs, array $config): string
{
    if (stripos($attrs, 'data-cc') !== false) {
        return $fullTag;
    }
    if (!preg_match('#\bsrc\s*=\s*' . COOKIE_BANNER_ATTR_VALUE . '#i', $attrs, $srcMatch)) {
        return $fullTag;
    }
    $src = $srcMatch[1] . ($srcMatch[2] ?? '') . ($srcMatch[3] ?? '');
    $src = html_entity_decode($src, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $service = cookie_banner_match_service($src);
    if ($service === null) {
        return $fullTag;
    }
    $newAttrs = preg_replace('#\bsrc\s*=\s*' . COOKIE_BANNER_ATTR_VALUE . '#i', 'src="about:blank"', $attrs, 1);
    $newAttrs .= ' data-cc="' . htmlspecialchars($service['category'], ENT_QUOTES) . '"'
        . ' data-cc-src="' . htmlspecialchars($src, ENT_QUOTES) . '"'
        . ' data-cc-service="' . htmlspecialchars($service['key'], ENT_QUOTES) . '"';
    $iframe = '<iframe' . $newAttrs . '></iframe>';

    $placeholderKey = $service['placeholder'] ?? 'default';
    $text = $config['placeholder'][$placeholderKey] ?? $config['placeholder']['default'];
    $serviceLabel = ucfirst($service['key']);
    $buttonText = $config['placeholder']['button'] ?? ('Inhalt laden');

    return '<div class="cc-placeholder" data-cc-placeholder="' . htmlspecialchars($service['category'], ENT_QUOTES) . '"'
        . ' data-cc-service="' . htmlspecialchars($service['key'], ENT_QUOTES) . '">'
        . '<div class="cc-placeholder__body">'
        . '<p class="cc-placeholder__text">' . htmlspecialchars($text) . '</p>'
        . '<button type="button" class="cc-placeholder__btn" data-cc-load>'
        . htmlspecialchars($buttonText) . ' (' . htmlspecialchars($serviceLabel) . ')'
        . '</button>'
        . '</div>'
        . $iframe
        . '</div>';
}

function cookie_banner_rewrite_script_tag(string $fullTag, string $src, array $config): string
{
    if (stripos($fullTag, 'data-cc') !== false) {
        return $fullTag;
    }
    if (preg_match('#\btype\s*=\s*["\']?text/plain["\'\s>]#i', $fullTag)) {
        return $fullTag;
    }
    $decoded = html_entity_decode($src, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $service = cookie_banner_match_service($decoded);
    if ($service === null) {
        return $fullTag;
    }
    $attrs = (string) preg_replace('#\bsrc\s*=\s*' . COOKIE_BANNER_ATTR_VALUE . '#i', '', substr($fullTag, strlen('<script')), 1);
    $attrs = (string) preg_replace('#\btype\s*=\s*' . COOKIE_BANNER_ATTR_VALUE . '#i', '', $attrs);
    $attrs = rtrim(rtrim($attrs), '>');
    return '<script type="text/plain"'
        . ' data-cc="' . htmlspecialchars($service['category'], ENT_QUOTES) . '"'
        . ' data-cc-src="' . htmlspecialchars($decoded, ENT_QUOTES) . '"'
        . ' data-cc-service="' . htmlspecialchars($service['key'], ENT_QUOTES) . '"'
        . ' ' . trim($attrs) . '>';
}

function cookie_banner_inject_banner(string $html, array $config): string
{
    if (stripos($html, 'data-cc-banner-root') !== false) {
        return $html;
    }
    if (stripos($html, '</body>') === false) {
        return $html;
    }
    ob_start();
    $bannerConfig = $config;
    include __DIR__ . '/render/banner.php';
    $banner = (string) ob_get_clean();
    return preg_replace('#</body>#i', $banner . '</body>', $html, 1) ?? $html;
}
