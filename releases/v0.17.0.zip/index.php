<?php declare(strict_types=1);

// Universal front controller. Übernimmt das gesamte HTTP-Routing für
// - klassisches Apache-Shared-Hosting (siehe .htaccess: ein Rewrite leitet
//   alles ohne reale Datei hier her),
// - PHP's eingebauten Server (`php -S 127.0.0.1:8000 index.php`),
// - Nginx (`try_files $uri /index.php?$query_string;`).
//
// Vorteil: ein Router, eine Wahrheit. Keine Hoster-spezifischen Direktiven
// wie `%{DOCUMENT_ROOT}` oder Per-Dir-`.htaccess` mit `RewriteBase`, die auf
// günstigen Apaches (z.B. IONOS) regelmäßig 500s produzieren.

// Nicht parse_url: Es liest bei //content/x „content“ als Host und schneidet es ab.
$path = explode('?', (string) ($_SERVER['REQUEST_URI'] ?? '/'), 2)[0];
if ($path === '') {
    $path = '/';
}

$projectRoot = __DIR__;
$isCliServer = PHP_SAPI === 'cli-server';

require_once $projectRoot . '/core/auth.php';
require_once $projectRoot . '/core/siteRoutes.php';

// Browser raten den Typ nie, sondern nehmen den Content-Type ernst.
header('X-Content-Type-Options: nosniff');

// Alle Sperren und Zuordnungen unten gelten für die kanonische Schreibweise (le_site_canonical_path), damit
// /./content/x oder /public//site/includes/x nicht an ihnen vorbeikommen; „..“ gibt es nie.
$path = le_site_canonical_path($path);
if ($path === null) {
    return le_respond_not_found();
}
// Versteckte Dateien (.git, .env, .htaccess …) gibt es nicht, außer .well-known. Kodierte Segmente
// (..%2Fx) sind keine Datei auf der Platte, sie prüft die Seitenauflösung (404-Seite der Website).
foreach (explode('/', $path) as $segment) {
    if ($segment !== '' && $segment[0] === '.' && $segment !== '.well-known' && !str_contains($segment, '%')) {
        return le_respond_not_found();
    }
}

// 1. Private Ordner nie ausliefern (Defense in Depth zusätzlich zu den
//    .htaccess in diesen Ordnern, die auf eingeschränkten Hostern manchmal
//    ignoriert werden).
if (preg_match('#^/(' . implode('|', LE_SITE_PRIVATE_DIRS) . ')(/|$)#', $path)) {
    return le_respond_not_found();
}
// 1b. Ebenso config.php mit dem Zugang des ersten Admins und ihre Vorlage, auch mit PATH_INFO.
if (preg_match('#^/(' . implode('|', array_map('preg_quote', LE_SITE_PRIVATE_FILES)) . ')(/|$)#i', $path)) {
    return le_respond_not_found();
}

// 2. /public/site/includes/* sind Partials, keine Standalone-Dokumente. le_site_request_file sperrt auch
//    /includes/*; diese Prüfung kommt vor Schritt 5, der echte Dateien auf dem Dev-Server ausliefert.
if (preg_match('#^/public/site/' . LE_SITE_INCLUDES_DIR . '(/|$)#i', $path)) {
    return le_respond_not_found();
}

// 2b. Uploads, wenn sie hier landen (Dev-Server, Mehrfachbetrieb): nie ausführen, SVGs nur in der Sandbox
//     (UPLOADS_SVG_CSP) – wie public/uploads/.htaccess, aber ohne mod_headers.
$uploadFile = UPLOADS_ROOT . '/' . substr($path, strlen(UPLOADS_URL));
if (preg_match('#^/public/uploads/[A-Za-z0-9][A-Za-z0-9._-]*$#', $path) && is_file($uploadFile)) {
    if (str_ends_with(strtolower($path), '.svg')) {
        header('Content-Security-Policy: ' . UPLOADS_SVG_CSP);
    }
    return le_serve_static_file($uploadFile);
}

// 3. Login-Seite (eigene schlanke Seite, kein Admin-SPA). Wer schon angemeldet
//    ist, geht gleich zum Ziel aus ?next= weiter; die Seite lädt nach dem Login
//    neu und landet so ebenfalls hier. Ohne ?next= gilt die Seite dieser Website,
//    von der der Besucher kam (Referer); sie kommt in die Adresse, damit sie das
//    Neuladen nach dem Login übersteht.
if (rtrim($path, '/') === LOGIN_URL) {
    $next = $_GET['next'] ?? referer_path();
    if (signed_in_user() !== null) {
        return le_respond_redirect(safe_redirect_path($next));
    }
    if (!isset($_GET['next']) && $next !== null) {
        return le_respond_redirect(LOGIN_URL . '?next=' . rawurlencode($next));
    }
    header('Cache-Control: no-store');
    le_deny_foreign_framing();
    // Weder Benutzer noch ein brauchbares config.php: Hinweis statt Formular.
    return le_setup_missing()
        ? le_respond_login_setup($projectRoot . '/public/admin/login.html')
        : le_serve_static_file($projectRoot . '/public/admin/login.html');
}

// 4. Admin-SPA: /admin und /admin/* zeigen auf /public/admin/ (gleiches gilt
//    für den kanonischen /public/admin/-Pfad, damit alte Bookmarks und der
//    direkte Dev-Aufruf weiter funktionieren). Existiert die angefragte
//    Ressource dort als Datei (CSS, JS, Bild, Modul, Seiten-Editor), liefern wir
//    sie ohne Anmeldung aus; sonst fällt der Request auf die SPA-Shell
//    `index.html` zurück, damit Deep-Links wie /admin/settings nach Reload
//    weiter funktionieren. Die Shell bekommen nur Admins.
if (preg_match('#^(?:/public)?' . LE_ADMIN_PATH . '(?:/(.*))?$#', $path, $m)) {
    $rel = isset($m[1]) ? trim($m[1], '/') : '';
    $shell = $projectRoot . '/public/admin/index.html';

    if ($rel !== '') {
        if (str_contains($rel, '..') || !preg_match(LE_SITE_PATH_PATTERN, $rel)) {
            return le_respond_not_found();
        }
        $asset = $projectRoot . '/public/admin/' . $rel;
        if (is_file($asset) && realpath($asset) !== realpath($shell)) {
            return le_serve_static_file($asset);
        }
    }

    // Ohne Anmeldung zur Login-Seite (danach zurück), Editoren auf die Website.
    if (signed_in_user() === null) {
        return le_respond_redirect(LOGIN_URL . '?next=' . $path);
    }
    if (!is_admin()) {
        return le_respond_redirect(LE_SITE_HOME_URL);
    }
    header('Cache-Control: no-store');
    le_deny_foreign_framing();
    return is_file($shell) ? le_serve_static_file($shell) : le_respond_not_found();
}

// 5. Dev-Server (php -S): reale Dateien außerhalb von /public/site/*.html|php
//    soll PHP selbst ausliefern. `return false` signalisiert genau das. Site-
//    Dokumente lassen wir absichtlich durch den Renderer unten laufen, damit
//    Shortcodes und Plugin-Filter greifen.
//    Der Front-Controller selbst nicht: php -S führte ihn sonst ein zweites Mal im selben
//    Prozess aus (Fatal: Funktionen doppelt); /index.php gilt wie auf Apache als Startseite.
//    Mit eigenem Kundenordner (le_instance_is_multi) liegen Website und Uploads nicht im Code-Ordner, den
//    php -S ausliefert: Die Datei dort wäre die falsche, sie kommen aus Schritt 2b bzw. 6.
$instanceFile = le_instance_is_multi() && (str_starts_with($path, LE_SITE_FILES_URL) || str_starts_with($path, UPLOADS_URL));
if ($isCliServer && $path !== '/' && !$instanceFile && is_file($projectRoot . $path) && realpath($projectRoot . $path) !== __FILE__) {
    $isSiteDoc = str_starts_with($path, LE_SITE_FILES_URL) && le_site_is_document($path);
    if (!$isSiteDoc) {
        return false;
    }
}

// 6. Site-Dokumente und Site-Assets. URL wird auf /public/site/ gemappt (le_site_request_file):
//    - /                          → /public/site/index.{php,html}
//    - /imprint                   → /public/site/imprint.{php,html} oder .../index.{php,html}
//    - /styles.min.css            → /public/site/styles.min.css
//    - /assets/logos/favicon.png  → /public/site/assets/logos/favicon.png
//    - /public/site/foo.html      → /public/site/foo.html (kanonisch)
//    Ohne Datei fragt index.php die Plugins (Hook site_page, z. B. /<pfad>/<slug> von Content-Typen).
//    Seiten brauchen Shortcodes, Plugins und den Editor; Site-PHP nutzt Core-Funktionen
//    (z. B. load_plugins_state in includes/header.php).
require_once $projectRoot . '/core/shortcodes.php';
require_once $projectRoot . '/core/plugins.php';
require_once $projectRoot . '/core/siteEditor.php';

$file = le_site_request_file($path);

// Seiten haben Adressen ohne Endung: /impressum.php, /public/site/impressum.html → 301 auf /impressum (mit
// Query). Nur GET/HEAD, damit Formulare, die an eine .php posten, weiter ankommen.
$cleanPath = $file !== null && in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', ['GET', 'HEAD'], true) ? le_site_clean_path($path, $file) : null;
if ($cleanPath !== null) {
    $query = (string) ($_SERVER['QUERY_STRING'] ?? '');
    header('Location: ' . $cleanPath . ($query !== '' ? '?' . $query : ''), true, 301);
    return true;
}

if ($file === null) {
    $siteDocument = plugin_site_page($path);
    if ($siteDocument === PLUGIN_SITE_PAGE_NOT_FOUND) {
        $siteDocument = le_site_not_found_document();
    }
    if ($siteDocument === null) {
        return le_respond_not_found();
    }
} elseif (le_site_is_document($file)) {
    $siteDocument = le_site_document($file);
} else {
    return le_serve_static_file($file);
}

// Die Seite wird hier auf oberster Ebene eingebunden, nicht in einer Funktion: Site-PHP sieht ihre
// Variablen global wie gewohnt (Funktionen mit `global $x` aus einem Include). Der Status kommt vorher,
// damit eine Seite ihn selbst ändern kann (eigenes 404, Weiterleitung mit Location). Wirft die Seite eines
// Plugins (z. B. page.php) oder ihr finish, kommt einmal die 404-Seite der Website (le_site_document,
// le_site_not_found_document).
for (;;) {
    extract($siteDocument['vars'], EXTR_SKIP);
    http_response_code($siteDocument['status']);
    $siteBufferLevel = ob_get_level();
    ob_start();
    try {
        if ($siteDocument['file'] !== null) {
            if (strtolower(pathinfo($siteDocument['file'], PATHINFO_EXTENSION)) === 'php') {
                require $siteDocument['file'];
            } else {
                readfile($siteDocument['file']);
            }
        }
        $siteHtml = (string) ob_get_clean();
        if ($siteDocument['finish'] !== null) {
            $siteHtml = ($siteDocument['finish'])($siteHtml);
        }
        break;
    } catch (Throwable $e) {
        if ($siteDocument['finish'] === null) {
            throw $e;
        }
        while (ob_get_level() > $siteBufferLevel) {
            ob_end_clean();
        }
        header_remove('Location');
        error_log('site_page ' . $path . ': ' . $e->getMessage());
        $siteDocument = le_site_not_found_document();
        if ($siteDocument === null) {
            return le_respond_not_found();
        }
    }
}
return le_respond_site_html($siteHtml, $siteDocument['editor']);


function le_respond_not_found(): bool
{
    http_response_code(404);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Not Found';
    return true;
}

/**
 * Seite der Website ausliefern: Shortcodes, Plugin-Filter, für Angemeldete der Seiten-Editor.
 * $html: gerendertes Dokument; $file: seine Datei (Editor: welche Seite bearbeitet wird).
 */
function le_respond_site_html(string $html, string $file): bool
{
    $html = render_shortcodes_in_html($html);
    $html = filter_site_html($html);

    header('Content-Type: text/html; charset=utf-8');
    // Mit Session-Cookie sieht die Seite anders aus (Editor): Caches des Hosters dürfen
    // Besuchern und Angemeldeten nicht dieselbe Fassung geben.
    header('Vary: Cookie');
    // Angemeldet: Seiten-Editor einhängen; die Antwort ist dann persönlich und darf in keinen Cache.
    $editorUser = signed_in_user();
    $withEditor = $editorUser !== null ? inject_site_editor($html, $editorUser, $file) : null;
    if ($withEditor !== null) {
        $html = $withEditor;
        header('Cache-Control: no-store');
        le_deny_foreign_framing();
    }
    echo $html;
    return true;
}

/**
 * Login-Seite mit dem Hinweis API_TEXT['setupMissing'] an Stelle der Formulare (zwischen
 * LE_LOGIN_FORMS_START und LE_LOGIN_FORMS_END); ohne die Markierungen nur der Hinweis.
 */
function le_respond_login_setup(string $file): bool
{
    $html = (string) file_get_contents($file);
    $hint = '<div class="panel"><h1>LeBuild</h1><p>'
        . htmlspecialchars(sprintf(API_TEXT['setupMissing'], PASSWORD_MIN_LENGTH), ENT_QUOTES, 'UTF-8') . '</p></div>';
    $start = strpos($html, LE_LOGIN_FORMS_START);
    $end = strpos($html, LE_LOGIN_FORMS_END);
    $html = $start !== false && $end !== false && $end > $start
        ? substr($html, 0, $start) . $hint . substr($html, $end + strlen(LE_LOGIN_FORMS_END))
        : $hint;

    header('Content-Type: text/html; charset=utf-8');
    echo $html;
    return true;
}

/**
 * Login, Verwaltung und Seiten mit Editor nur von dieser Website einbetten lassen (Clickjacking);
 * die Seitenansicht der Verwaltung zeigt die Website im iframe desselben Origins.
 * Öffentliche Seiten ohne Editor bleiben einbettbar.
 */
function le_deny_foreign_framing(): void
{
    header("Content-Security-Policy: frame-ancestors 'self'");
    header('X-Frame-Options: SAMEORIGIN');
}

function le_respond_redirect(string $location): bool
{
    header('Cache-Control: no-store');
    header('Location: ' . $location, true, 302);
    return true;
}

function le_serve_static_file(string $file): bool
{
    static $mime = [
        'html'  => 'text/html; charset=utf-8',
        'css'   => 'text/css; charset=utf-8',
        'js'    => 'application/javascript; charset=utf-8',
        'mjs'   => 'application/javascript; charset=utf-8',
        'map'   => 'application/json; charset=utf-8',
        'json'  => 'application/json; charset=utf-8',
        'xml'   => 'application/xml; charset=utf-8',
        'txt'   => 'text/plain; charset=utf-8',
        'svg'   => 'image/svg+xml',
        'png'   => 'image/png',
        'jpg'   => 'image/jpeg',
        'jpeg'  => 'image/jpeg',
        'gif'   => 'image/gif',
        'webp'  => 'image/webp',
        'ico'   => 'image/x-icon',
        'woff'  => 'font/woff',
        'woff2' => 'font/woff2',
        'ttf'   => 'font/ttf',
        'eot'   => 'application/vnd.ms-fontobject',
        'otf'   => 'font/otf',
        'pdf'   => 'application/pdf',
        'mp4'   => 'video/mp4',
        'webm'  => 'video/webm',
    ];

    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    $type = $mime[$ext] ?? 'application/octet-stream';

    header('Content-Type: ' . $type);
    header('Content-Length: ' . (string) filesize($file));
    readfile($file);
    return true;
}
