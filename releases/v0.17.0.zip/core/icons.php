<?php
declare(strict_types=1);

require_once __DIR__ . '/markup.php';
require_once __DIR__ . '/iconSet.php';

// Feldart „Icon“: ein <svg> der Seite, getauscht gegen ein Icon aus LE_ICON_SET. Wert ist der
// Name des Icons; ein SVG, das keinem Icon des Satzes gleicht, hat den Wert '' und bleibt beim
// Speichern stehen, bis jemand ein Icon wählt.

// Als Icon gilt ein <svg>, dessen width und height höchstens so groß sind (Zahl, ohne Einheit oder px) …
const LE_ICON_MAX_SIZE = 64;
// … oder dessen Klasse bzw. die des Elternelements dieses Wort enthält (feature-card__icon, icon-lg).
const LE_ICON_CLASS_WORD = 'icon';
// Klasse, an der Lucide-SVGs ihr Icon nennen (lucide-zap), wenn die Pfade aus einer anderen Version stammen.
const LE_ICON_LUCIDE_CLASS = 'lucide-';
// Attribute, die ein Tausch am <svg> setzt (die Icons sind Striche im 24er Raster) …
const LE_ICON_SVG_ATTRS = ['viewBox' => '0 0 24 24', 'fill' => 'none', 'stroke' => 'currentColor'];
// … und diese nur, wenn sie fehlen (eine eigene Strichstärke der Website bleibt).
const LE_ICON_SVG_DEFAULTS = ['stroke-width' => '2', 'stroke-linecap' => 'round', 'stroke-linejoin' => 'round'];

/** Name eines Icons aus dem Satz, sonst '' (Bereinigung der Feldart icon). */
function le_icon_name(string $value): string
{
    $value = trim($value);
    return isset(LE_ICON_SET[$value]) ? $value : '';
}

/** Icons für den Seiten-Editor (api/icons.php): [{name, svg (Inhalt), words}]. */
function le_icon_list(): array
{
    $list = [];
    foreach (LE_ICON_SET as $name => [$svg, $words]) {
        $list[] = ['name' => $name, 'svg' => $svg, 'words' => $words];
    }
    return $list;
}

/**
 * Ist das <svg> an $index ein Icon (Import)? Ohne PHP, mit Innenbereich, klein (LE_ICON_MAX_SIZE)
 * oder mit LE_ICON_CLASS_WORD in der eigenen Klasse oder der des Elternelements.
 */
function le_icon_svg(array $doc, int $index): bool
{
    $node = $doc['nodes'][$index];
    if ($node['tag'] !== 'svg' || $node['self_closing'] || $node['has_php'] || markup_inner_has_php($doc, $index)) {
        return false;
    }
    foreach ($node['attrs'] as $attr) {
        if ($attr['has_php']) {
            return false;
        }
    }
    $size = static function (string $name) use ($node): ?float {
        return preg_match('/^\s*(\d+(?:\.\d+)?)\s*(?:px)?\s*$/i', markup_attr_text($node, $name), $m) ? (float) $m[1] : null;
    };
    $width = $size('width');
    $height = $size('height');
    if ($width !== null && $height !== null && $width <= LE_ICON_MAX_SIZE && $height <= LE_ICON_MAX_SIZE) {
        return true;
    }
    $parent = $node['parent'] === null ? null : $doc['nodes'][$node['parent']];
    foreach ([$node, $parent] as $element) {
        if ($element !== null && !(markup_attr($element, 'class')['has_php'] ?? false)
            && str_contains(strtolower(markup_attr_text($element, 'class')), LE_ICON_CLASS_WORD)) {
            return true;
        }
    }
    return false;
}

/**
 * Name des Icons, das das <svg> an $index zeigt: gleiche Elemente und Attribute wie im Satz
 * (Leerraum und <path></path> statt <path/> zählen nicht), sonst die Lucide-Klasse; '' ohne Treffer.
 */
function le_icon_from_svg(array $doc, int $index): string
{
    static $byMarkup = null;
    if ($byMarkup === null) {
        $byMarkup = [];
        foreach (LE_ICON_SET as $name => [$svg]) {
            $set = markup_parse($svg);
            $byMarkup[le_icon_canonical($set, $set['roots'])] = $name;
        }
    }
    $canonical = le_icon_canonical($doc, $doc['nodes'][$index]['children']);
    if ($canonical !== null && isset($byMarkup[$canonical])) {
        return $byMarkup[$canonical];
    }
    foreach (preg_split('/\s+/', markup_attr_text($doc['nodes'][$index], 'class')) ?: [] as $class) {
        if (str_starts_with($class, LE_ICON_LUCIDE_CLASS) && isset(LE_ICON_SET[substr($class, strlen(LE_ICON_LUCIDE_CLASS))])) {
            return substr($class, strlen(LE_ICON_LUCIDE_CLASS));
        }
    }
    return '';
}

/** Vergleichsform der Knoten: Elemente ohne Kinder als <tag a="v"/>; null bei Text, Kindern oder anderem. */
function le_icon_canonical(array $doc, array $indices): ?string
{
    $out = '';
    foreach ($indices as $index) {
        $node = $doc['nodes'][$index];
        if ($node['type'] === 'text' && trim(substr($doc['source'], $node['start'], $node['end'] - $node['start'])) === '') {
            continue;
        }
        if ($node['type'] !== 'element' || $node['children'] !== []) {
            return null;
        }
        $out .= '<' . $node['tag'];
        foreach ($node['attrs'] as $attr) {
            $out .= ' ' . $attr['name'] . '="' . markup_attr_text($node, $attr['name']) . '"';
        }
        $out .= '/>';
    }
    return $out;
}

/** Ersetzungen für den Tausch des <svg> an $index gegen das Icon $name: Innenbereich und Attribute (LE_ICON_SVG_ATTRS, LE_ICON_SVG_DEFAULTS). */
function le_icon_replacements(array $doc, int $index, string $name): array
{
    $node = $doc['nodes'][$index];
    $replacements = [markup_set_inner($doc, $index, LE_ICON_SET[$name][0])];
    foreach (LE_ICON_SVG_ATTRS + LE_ICON_SVG_DEFAULTS as $attr => $value) {
        $current = markup_attr($node, strtolower($attr));
        if ($current === null || (isset(LE_ICON_SVG_ATTRS[$attr]) && markup_attr_text($node, strtolower($attr)) !== $value)) {
            $replacements[] = markup_set_attr($doc, $index, $current === null ? $attr : $current['name'], $value);
        }
    }
    return $replacements;
}
