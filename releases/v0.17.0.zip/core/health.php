<?php
declare(strict_types=1);

// Health-Check für Uptime-Monitore (api/health.php): Kann die Installation ihre Arbeit tun?
// Geprüft wird Echtes in klein: content/ lesen und schreiben, die Startseite rendern wie
// index.php, die Plugin-Datenbank abfragen. Öffentlich nur status und checkedAt, die
// Einzelprüfungen nur mit dem Token (LEBUILD_HEALTH_TOKEN bzw. health.config.php).

require_once __DIR__ . '/plugins.php';
require_once __DIR__ . '/shortcodes.php';
require_once __DIR__ . '/users.php';

const HEALTH_TOKEN_ENV = 'LEBUILD_HEALTH_TOKEN';
const HEALTH_CONFIG_FILE = 'health.config.php';
// So lange gilt ein Ergebnis; Monitore fragen seltener, eine Abfrage-Flut kostet so nur einen Lauf.
const HEALTH_CACHE_SECONDS = 10;
const HEALTH_CACHE_FILE = 'health.json';
const HEALTH_LOCK_FILE = 'health.lock';
// Meldungen der Einzelprüfungen (nur mit Token sichtbar): nie Pfade oder Texte von Exceptions.
const HEALTH_TEXT = [
    'content' => 'content/ lässt sich nicht lesen oder beschreiben.',
    'users' => 'content/users.json ist nicht lesbar, niemand kann sich anmelden.',
    'render' => 'Die Startseite lässt sich nicht rendern.',
    'database' => 'Die Plugin-Datenbank antwortet nicht.',
    'failed' => 'Prüfung fehlgeschlagen.',
];

/** Prüfungen nach Name: jede liefert null (in Ordnung) oder eine Meldung aus HEALTH_TEXT. */
function health_checks(): array
{
    $checks = [
        'content' => 'health_check_content',
        'render' => 'health_check_render',
    ];
    // Die Datenbank nur, wenn ein aktives Plugin Tabellen hat; sonst braucht sie niemand.
    $table = health_database_table();
    if ($table !== null) {
        $checks['database'] = static fn (): ?string => health_check_database($table);
    }
    return $checks;
}

/** content/ schreiben und zurücklesen (Wegwerf-Datei im Cache), users.json muss für users_load() taugen. */
function health_check_content(): ?string
{
    ensure_dir(CACHE_ROOT);
    $probe = CACHE_ROOT . '/health-probe-' . bin2hex(random_bytes(4)) . '.tmp';
    $value = bin2hex(random_bytes(8));
    $written = @file_put_contents($probe, $value, LOCK_EX) === strlen($value);
    $read = $written ? @file_get_contents($probe) : false;
    @unlink($probe);
    if ($read !== $value) {
        return HEALTH_TEXT['content'];
    }
    if (!empty(users_load()['broken'])) {
        return HEALTH_TEXT['users'];
    }
    return null;
}

/** Startseite wie index.php (Seite, Shortcodes, Plugin-Filter); das Ergebnis muss ein HTML-Dokument sein. */
function health_check_render(): ?string
{
    $file = is_file(LE_SITE_ROOT . '/index.php') ? LE_SITE_ROOT . '/index.php' : LE_SITE_ROOT . '/index.html';
    if (!is_file($file)) {
        return HEALTH_TEXT['render'];
    }
    if (str_ends_with($file, '.php')) {
        $level = ob_get_level();
        ob_start();
        try {
            (static function (string $__file): void {
                require $__file;
            })($file);
            // Puffer, die die Seite selbst geöffnet hat, gehören zur Ausgabe.
            while (ob_get_level() > $level + 1) {
                ob_end_flush();
            }
            $html = (string) ob_get_clean();
        } finally {
            while (ob_get_level() > $level) {
                ob_end_clean();
            }
            // Was die Seite an Headern gesetzt hat (Cookies, Weiterleitung, Status), gehört nicht in die Antwort.
            header_remove();
            http_response_code(200);
        }
    } else {
        $html = (string) file_get_contents($file);
    }
    $html = filter_site_html(render_shortcodes_in_html($html));
    return preg_match('/<(html|body)[\s>]/i', $html) === 1 ? null : HEALTH_TEXT['render'];
}

/** Erste Tabelle eines aktiven Plugins (laut plugins.json), null ohne solche Plugins. */
function health_database_table(): ?string
{
    $state = load_plugins_state();
    foreach ($state['active'] as $name) {
        $tables = $state['installed'][$name]['tables'] ?? [];
        if ($tables !== []) {
            return $tables[0];
        }
    }
    return null;
}

/** SELECT 1 und eine Abfrage auf eine Tabelle, die ein Plugin wirklich nutzt. */
function health_check_database(string $table): ?string
{
    if (!plugin_table_name_valid($table)) {
        return HEALTH_TEXT['database'];
    }
    $pdo = db();
    if ((int) $pdo->query('SELECT 1')->fetchColumn() !== 1) {
        return HEALTH_TEXT['database'];
    }
    $pdo->query('SELECT 1 FROM ' . $table . ' LIMIT 1')->fetchAll();
    return null;
}

/**
 * Führt die Prüfungen aus: status ok/error, je Prüfung name, ok, ggf. error, durationMs.
 * Beendet eine Prüfung den Prozess (exit der Startseite, z. B. Sprachweiche per Location, oder ein
 * Fatal Error), läuft nichts danach und kein finally. Dann übernimmt die Shutdown-Funktion: Sie
 * verwirft Ausgabe und Header der Seite, zählt die Prüfung als Fehler, führt die übrigen aus und
 * gibt den Bericht an $onExit (antwortet mit JSON), sonst bekäme der Monitor HTML oder 302.
 */
function health_run(array $checks, ?callable $onExit = null): array
{
    $state = ['results' => [], 'current' => null, 'started' => 0.0, 'done' => false];
    $level = ob_get_level();
    register_shutdown_function(static function () use (&$state, $checks, $level, $onExit): void {
        if ($state['done'] || $state['current'] === null) {
            return;
        }
        while (ob_get_level() > $level) {
            ob_end_clean();
        }
        if (!headers_sent()) {
            header_remove();
            // Nach einem Fatal Error steht schon „500“ als Statuszeile; die räumt nur header() mit Code weg,
            // http_response_code() allein nicht.
            header('Cache-Control: no-store', true, 200);
        }
        $name = $state['current'];
        error_log('health ' . $name . ' ended the request (exit or fatal error)');
        $state['results'][] = health_result($name, HEALTH_TEXT[$name] ?? HEALTH_TEXT['failed'], $state['started']);
        $rest = array_slice($checks, array_search($name, array_keys($checks), true) + 1, null, true);
        $report = health_finish([...$state['results'], ...health_run($rest)['checks']]);
        if ($onExit !== null) {
            $onExit($report);
        }
    });
    foreach ($checks as $name => $check) {
        $state['current'] = (string) $name;
        $state['started'] = microtime(true);
        try {
            $error = $check();
        } catch (Throwable $e) {
            error_log('health ' . $name . ' failed: ' . $e->getMessage());
            $error = HEALTH_TEXT[$name] ?? HEALTH_TEXT['failed'];
        }
        $state['results'][] = health_result((string) $name, $error, $state['started']);
    }
    $state['done'] = true;
    return health_finish($state['results']);
}

function health_result(string $name, ?string $error, float $started): array
{
    $result = ['name' => $name, 'ok' => $error === null];
    if ($error !== null) {
        $result['error'] = $error;
    }
    $result['durationMs'] = (int) round((microtime(true) - $started) * 1000);
    return $result;
}

function health_finish(array $results): array
{
    $failed = array_filter($results, static fn (array $r): bool => !$r['ok']);
    return ['status' => $failed ? 'error' : 'ok', 'checks' => $results, 'checkedAt' => current_iso_time(), 'ageMs' => 0];
}

/**
 * Bericht, höchstens HEALTH_CACHE_SECONDS alt. Gleichzeitige Abfragen warten auf einen Lauf
 * (Sperre) statt je einen zu starten. $checks ersetzt die Prüfliste (Tests) und umgeht den Cache.
 * $onExit bekommt den Bericht, wenn eine Prüfung den Prozess beendet hat (health_run).
 */
function health_report(?array $checks = null, ?callable $onExit = null): array
{
    if ($checks !== null) {
        return health_run($checks, $onExit);
    }
    $cacheFile = CACHE_ROOT . '/' . HEALTH_CACHE_FILE;
    $cached = health_cached_report($cacheFile);
    if ($cached !== null) {
        return $cached;
    }
    $lock = is_dir(CACHE_ROOT) ? @fopen(CACHE_ROOT . '/' . HEALTH_LOCK_FILE, 'c') : false;
    if ($lock !== false) {
        flock($lock, LOCK_EX);
    }
    try {
        // Wer auf die Sperre gewartet hat, nimmt das Ergebnis des Laufs davor.
        $report = health_cached_report($cacheFile);
        if ($report !== null) {
            return $report;
        }
        $report = health_run(health_checks(), static function (array $report) use ($cacheFile, $onExit): void {
            health_store_report($cacheFile, $report);
            if ($onExit !== null) {
                $onExit($report);
            }
        });
        health_store_report($cacheFile, $report);
    } finally {
        if ($lock !== false) {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }
    return $report;
}

function health_store_report(string $cacheFile, array $report): void
{
    // tempnam legt die Datei mit 0600 an, aber nur in einem beschreibbaren Ordner (sonst im Temp-Ordner des Systems).
    if (is_dir(CACHE_ROOT) && is_writable(CACHE_ROOT) && ($tmp = @tempnam(CACHE_ROOT, 'health-'))) {
        if (@file_put_contents($tmp, json_encode($report)) === false || !@rename($tmp, $cacheFile)) {
            @unlink($tmp);
        }
    }
}

function health_cached_report(string $cacheFile): ?array
{
    $mtime = is_file($cacheFile) ? @filemtime($cacheFile) : false;
    if ($mtime === false || time() - $mtime >= HEALTH_CACHE_SECONDS) {
        return null;
    }
    $report = json_decode((string) @file_get_contents($cacheFile), true);
    if (!is_array($report) || !isset($report['status'], $report['checks'], $report['checkedAt'])) {
        return null;
    }
    $report['ageMs'] = (time() - $mtime) * 1000;
    return $report;
}

/** Token für die Einzelprüfungen: Env-Variable, sonst content/config/health.config.php (['token' => …]). */
function health_token(): ?string
{
    $token = getenv(HEALTH_TOKEN_ENV);
    if (!is_string($token) || trim($token) === '') {
        $path = CONFIG_ROOT . '/' . HEALTH_CONFIG_FILE;
        $config = is_file($path) ? require $path : null;
        $token = is_array($config) ? (string) ($config['token'] ?? '') : '';
    }
    // Getrimmt, damit ein Zeilenende aus Datei oder Panel das Token nicht unbrauchbar macht.
    $token = trim($token);
    return $token !== '' ? $token : null;
}

/** „Authorization: Bearer …“ passt zum Token? Beide Seiten gehasht, damit auch die Länge nicht durchsickert. */
function health_authorized(?string $header, ?string $token): bool
{
    if ($token === null || $header === null || !preg_match('/^Bearer\s+(\S+)\s*$/i', $header, $m)) {
        return false;
    }
    return hash_equals(hash('sha256', $token), hash('sha256', $m[1]));
}

/** Öffentlich nur status und checkedAt; mit Token der ganze Bericht. */
function health_view(array $report, bool $authorized): array
{
    return $authorized ? $report : ['status' => $report['status'], 'checkedAt' => $report['checkedAt']];
}

/** Antwort von api/health.php: 503 bei status error, für alle Aufrufer gleich. */
function health_respond(?array $checks = null): void
{
    health_send(health_report($checks, 'health_send'));
}

function health_send(array $report): void
{
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? null;
    if ($header === null && function_exists('getallheaders')) {
        foreach (getallheaders() as $name => $value) {
            if (strcasecmp((string) $name, 'Authorization') === 0) {
                $header = (string) $value;
            }
        }
    }
    header('Cache-Control: no-store');
    json_response(health_view($report, health_authorized($header, health_token())), $report['status'] === 'error' ? 503 : 200);
}
