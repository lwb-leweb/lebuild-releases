<?php
declare(strict_types=1);

require_once __DIR__ . '/utils.php';
require_once __DIR__ . '/updater.php';

// Meldungen der Prüfung beim Speichern der Mail-Einstellungen (core_mail_validate_config), wie der
// Browser sie zeigt (api/saveMailConfig.php, 400).
const MAIL_CONFIG_TEXT = [
    'host' => 'SMTP-Host ist ungültig.',
    'fromEmail' => 'Absender-E-Mail ist ungültig.',
    'defaultRecipient' => 'Standard-Empfänger ist ungültig.',
    'password' => 'SMTP-Passwort ist erforderlich, wenn ein Benutzer gesetzt ist.',
];

function core_mail_config_path(): string
{
    return updater_config_path('mail.config.php');
}

function core_mail_config_exists(): bool
{
    return is_file(core_mail_config_path());
}

function core_mail_load_config(): ?array
{
    if (!core_mail_config_exists()) {
        return null;
    }

    $config = require core_mail_config_path();
    if (!is_array($config)) {
        return null;
    }

    return core_mail_normalize_config($config);
}

function core_mail_default_recipient(): string
{
    $config = core_mail_load_config();
    $recipient = is_array($config) ? (string) ($config['defaultRecipient'] ?? '') : '';
    if (filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
        return $recipient;
    }

    // Nur eine gespeicherte Adresse, nie die neutrale Vorgabe (übernimmt das erste Speichern der Einstellungen).
    $email = (string) (le_site_config()['email'] ?? '');

    return filter_var($email, FILTER_VALIDATE_EMAIL) && $email !== LE_SITE_CONFIG_DEFAULTS['email'] ? $email : '';
}

function core_mail_public_config(): array
{
    $config = core_mail_load_config() ?? [];

    return [
        'host' => (string) ($config['host'] ?? ''),
        'port' => (int) ($config['port'] ?? 587),
        'encryption' => (string) ($config['encryption'] ?? 'tls'),
        'username' => (string) ($config['username'] ?? ''),
        'passwordSet' => isset($config['password']) && (string) $config['password'] !== '',
        'fromEmail' => (string) ($config['fromEmail'] ?? ''),
        'fromName' => (string) ($config['fromName'] ?? ''),
        'defaultRecipient' => (string) ($config['defaultRecipient'] ?? ''),
        'resolvedRecipient' => core_mail_default_recipient(),
    ];
}

function core_mail_status(): array
{
    $config = core_mail_load_config();
    $smtpConfigured = core_mail_smtp_configured($config);
    $mailFunction = function_exists('mail');
    $mailFallback = core_mail_php_mail_available();

    return [
        'configured' => $smtpConfigured,
        'mailFunction' => $mailFunction,
        'mailFallback' => $mailFallback,
        'available' => $smtpConfigured || $mailFallback,
        'transport' => $smtpConfigured ? 'smtp' : ($mailFallback ? 'mail' : 'none'),
    ];
}

function core_mail_available(): bool
{
    $status = core_mail_status();
    return !empty($status['available']);
}

function core_mail_save_config(array $input, ?array $existing = null): array
{
    $existing = $existing ?? core_mail_load_config() ?? [];
    $config = core_mail_normalize_config([
        'host' => $input['host'] ?? '',
        'port' => $input['port'] ?? 587,
        'encryption' => $input['encryption'] ?? 'tls',
        'username' => $input['username'] ?? '',
        'password' => array_key_exists('password', $input) && (string) $input['password'] !== ''
            ? (string) $input['password']
            : (string) ($existing['password'] ?? ''),
        'fromEmail' => $input['fromEmail'] ?? '',
        'fromName' => $input['fromName'] ?? '',
        'defaultRecipient' => $input['defaultRecipient'] ?? '',
    ]);

    $errors = core_mail_validate_config($config);
    if ($errors !== []) {
        throw new InvalidArgumentException(implode(' ', $errors));
    }

    write_private_file(core_mail_config_path(), "<?php\nreturn " . var_export($config, true) . ";\n");

    return $config;
}

function core_mail_delete_config(): void
{
    $path = core_mail_config_path();
    if (is_file($path) && !@unlink($path)) {
        throw new RuntimeException('Cannot delete mail.config.php');
    }
}

function core_mail_send(array $message): array
{
    $to = trim((string) ($message['to'] ?? ''));
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
        throw new InvalidArgumentException('Invalid recipient address.');
    }

    $subject = core_mail_clean_header((string) ($message['subject'] ?? ''));
    if ($subject === '') {
        throw new InvalidArgumentException('Missing mail subject.');
    }

    $text = (string) ($message['text'] ?? $message['body'] ?? '');
    if (trim($text) === '') {
        throw new InvalidArgumentException('Missing mail body.');
    }

    $replyTo = trim((string) ($message['replyTo'] ?? ''));
    if ($replyTo !== '' && !filter_var($replyTo, FILTER_VALIDATE_EMAIL)) {
        throw new InvalidArgumentException('Invalid reply-to address.');
    }

    $mail = [
        'to' => $to,
        'subject' => $subject,
        'text' => $text,
        'replyTo' => $replyTo,
    ];

    $config = core_mail_load_config();
    if (core_mail_smtp_configured($config)) {
        return core_mail_send_smtp($config, $mail);
    }

    if (core_mail_php_mail_available()) {
        return core_mail_send_php_mail($config ?? [], $mail);
    }

    throw new RuntimeException('No mail transport configured.');
}

function core_mail_php_mail_available(): bool
{
    if (!function_exists('mail')) {
        return false;
    }
    if (PHP_OS_FAMILY === 'Windows') {
        return true;
    }

    $sendmailPath = trim((string) ini_get('sendmail_path'));
    if ($sendmailPath === '') {
        return true;
    }

    $binary = preg_split('/\s+/', $sendmailPath)[0] ?? '';
    if ($binary === '' || $binary[0] !== '/') {
        return true;
    }

    return is_executable($binary);
}

function core_mail_normalize_config(array $input): array
{
    $encryption = strtolower(trim((string) ($input['encryption'] ?? 'tls')));
    if (!in_array($encryption, ['tls', 'ssl', 'none'], true)) {
        $encryption = 'tls';
    }
    $host = trim((string) ($input['host'] ?? ''));
    $password = trim((string) ($input['password'] ?? ''));
    $passwordWithoutSpaces = preg_replace('/\s+/', '', $password) ?? $password;
    if (strcasecmp($host, 'smtp.gmail.com') === 0 && preg_match('/^[a-zA-Z0-9]{16}$/', $passwordWithoutSpaces)) {
        $password = $passwordWithoutSpaces;
    }

    return [
        'host' => $host,
        'port' => max(1, min(65535, (int) ($input['port'] ?? 587))),
        'encryption' => $encryption,
        'username' => trim((string) ($input['username'] ?? '')),
        'password' => $password,
        'fromEmail' => trim((string) ($input['fromEmail'] ?? '')),
        'fromName' => core_mail_clean_header((string) ($input['fromName'] ?? '')),
        'defaultRecipient' => trim((string) ($input['defaultRecipient'] ?? '')),
    ];
}

function core_mail_validate_config(array $config): array
{
    $errors = [];
    $host = (string) ($config['host'] ?? '');

    if ($host === '' || preg_match('/[\s\/\\\\]/', $host)) {
        $errors[] = MAIL_CONFIG_TEXT['host'];
    }
    if (!filter_var((string) ($config['fromEmail'] ?? ''), FILTER_VALIDATE_EMAIL)) {
        $errors[] = MAIL_CONFIG_TEXT['fromEmail'];
    }
    if ((string) ($config['defaultRecipient'] ?? '') !== ''
        && !filter_var((string) $config['defaultRecipient'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = MAIL_CONFIG_TEXT['defaultRecipient'];
    }
    if ((string) ($config['username'] ?? '') !== '' && (string) ($config['password'] ?? '') === '') {
        $errors[] = MAIL_CONFIG_TEXT['password'];
    }

    return $errors;
}

function core_mail_smtp_configured(?array $config): bool
{
    if (!is_array($config)) {
        return false;
    }

    return core_mail_validate_config($config) === [];
}

function core_mail_send_php_mail(array $config, array $mail): array
{
    $fromEmail = filter_var((string) ($config['fromEmail'] ?? ''), FILTER_VALIDATE_EMAIL)
        ? (string) $config['fromEmail']
        : core_mail_fallback_sender();
    $fromName = core_mail_clean_header((string) ($config['fromName'] ?? ''));

    $headers = core_mail_headers($mail, $fromEmail, $fromName, true);
    $sent = mail(
        (string) $mail['to'],
        core_mail_encode_header((string) $mail['subject']),
        core_mail_encode_body((string) $mail['text']),
        implode("\r\n", $headers)
    );

    if (!$sent) {
        throw new RuntimeException('PHP mail() failed.');
    }

    return ['ok' => true, 'transport' => 'mail'];
}

function core_mail_send_smtp(array $config, array $mail): array
{
    $host = (string) $config['host'];
    $port = (int) $config['port'];
    $remote = ($config['encryption'] === 'ssl' ? 'ssl://' : '') . $host . ':' . $port;
    $timeout = 15;
    $context = stream_context_create([
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
            'allow_self_signed' => false,
            'peer_name' => $host,
            'SNI_enabled' => true,
        ],
    ]);

    $socket = @stream_socket_client($remote, $errno, $errstr, $timeout, STREAM_CLIENT_CONNECT, $context);
    if (!is_resource($socket)) {
        throw new RuntimeException('SMTP connection failed: ' . ($errstr ?: (string) $errno));
    }
    stream_set_timeout($socket, $timeout);

    try {
        core_mail_smtp_expect($socket, [220]);
        core_mail_smtp_ehlo($socket);

        if ($config['encryption'] === 'tls') {
            core_mail_smtp_command($socket, 'STARTTLS', [220]);
            if (!stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                throw new RuntimeException('SMTP STARTTLS failed.');
            }
            core_mail_smtp_ehlo($socket);
        }

        if ((string) $config['username'] !== '') {
            core_mail_smtp_command($socket, 'AUTH LOGIN', [334]);
            core_mail_smtp_command($socket, base64_encode((string) $config['username']), [334]);
            core_mail_smtp_command($socket, base64_encode((string) $config['password']), [235]);
        }

        $fromEmail = (string) $config['fromEmail'];
        core_mail_smtp_command($socket, 'MAIL FROM:<' . $fromEmail . '>', [250]);
        core_mail_smtp_command($socket, 'RCPT TO:<' . (string) $mail['to'] . '>', [250, 251]);
        core_mail_smtp_command($socket, 'DATA', [354]);

        $headers = core_mail_headers($mail, $fromEmail, (string) $config['fromName']);
        core_mail_smtp_command($socket, core_mail_smtp_data($headers, (string) $mail['text']), [250]);
        core_mail_smtp_command($socket, 'QUIT', [221]);
    } finally {
        fclose($socket);
    }

    return ['ok' => true, 'transport' => 'smtp'];
}

function core_mail_smtp_ehlo($socket): void
{
    $host = preg_replace('/[^a-zA-Z0-9.-]/', '', (string) ($_SERVER['HTTP_HOST'] ?? 'localhost')) ?: 'localhost';
    try {
        core_mail_smtp_command($socket, 'EHLO ' . $host, [250]);
    } catch (RuntimeException $e) {
        core_mail_smtp_command($socket, 'HELO ' . $host, [250]);
    }
}

function core_mail_smtp_command($socket, string $command, array $expectedCodes): array
{
    if (fwrite($socket, $command . "\r\n") === false) {
        throw new RuntimeException('SMTP write failed.');
    }

    return core_mail_smtp_expect($socket, $expectedCodes);
}

function core_mail_smtp_expect($socket, array $expectedCodes): array
{
    $response = core_mail_smtp_read_response($socket);
    if (!in_array($response['code'], $expectedCodes, true)) {
        throw new RuntimeException('SMTP unexpected response: ' . implode(' ', $response['lines']));
    }

    return $response;
}

function core_mail_smtp_read_response($socket): array
{
    $lines = [];
    $code = 0;

    while (($line = fgets($socket, 515)) !== false) {
        $line = rtrim($line, "\r\n");
        $lines[] = $line;
        if (preg_match('/^(\d{3})(\s|-)/', $line, $match)) {
            $code = (int) $match[1];
            if ($match[2] === ' ') {
                break;
            }
        } else {
            break;
        }
    }

    if ($lines === []) {
        $meta = stream_get_meta_data($socket);
        throw new RuntimeException(!empty($meta['timed_out']) ? 'SMTP response timeout.' : 'SMTP closed the connection.');
    }

    return ['code' => $code, 'lines' => $lines];
}

/** $forPhpMail: ohne To und Subject, die schreibt mail() selbst aus seinen Argumenten (sonst stehen sie doppelt). */
function core_mail_headers(array $mail, string $fromEmail, string $fromName = '', bool $forPhpMail = false): array
{
    $headers = [
        'Date: ' . date(DATE_RFC2822),
        'From: ' . core_mail_format_address($fromEmail, $fromName),
        'MIME-Version: 1.0',
        'Content-Type: text/plain; charset=UTF-8',
        'Content-Transfer-Encoding: quoted-printable',
    ];

    if (!$forPhpMail) {
        array_splice($headers, 2, 0, ['To: ' . (string) $mail['to'], 'Subject: ' . core_mail_encode_header((string) $mail['subject'])]);
    }

    if ((string) ($mail['replyTo'] ?? '') !== '') {
        $headers[] = 'Reply-To: ' . (string) $mail['replyTo'];
    }

    return $headers;
}

function core_mail_format_address(string $email, string $name = ''): string
{
    $name = core_mail_clean_header($name);
    if ($name === '') {
        return $email;
    }
    // Namen mit Umlauten ganz kodieren, reines ASCII mit Sonderzeichen (z. B. „Meier, Wien“)
    // als quoted-string; sonst liest der Empfänger am Komma zwei Adressen.
    if (preg_match('/[^\x20-\x7E]/', $name)) {
        $name = core_mail_encode_phrase($name);
    } elseif (preg_match('/[()<>\[\]:;@\\\\,."]/', $name)) {
        $name = '"' . addcslashes($name, '"\\') . '"';
    }

    return $name . ' <' . $email . '>';
}

/** Anzeigename ganz als Encoded-Words (RFC 2047); mb_encode_mimeheader ließe ASCII-Teile samt Komma roh stehen. */
function core_mail_encode_phrase(string $name): string
{
    $words = [];
    $chunk = '';
    // Höchstens 45 Byte je Wort, damit ein Encoded-Word unter 75 Zeichen bleibt; nie mitten im Zeichen teilen.
    foreach (preg_split('//u', $name, -1, PREG_SPLIT_NO_EMPTY) ?: [$name] as $char) {
        if ($chunk !== '' && strlen($chunk . $char) > 45) {
            $words[] = '=?UTF-8?B?' . base64_encode($chunk) . '?=';
            $chunk = '';
        }
        $chunk .= $char;
    }
    $words[] = '=?UTF-8?B?' . base64_encode($chunk) . '?=';

    return implode("\r\n ", $words);
}

function core_mail_encode_header(string $value): string
{
    $value = core_mail_clean_header($value);
    if ($value === '') {
        return '';
    }
    if (function_exists('mb_encode_mimeheader')) {
        return mb_encode_mimeheader($value, 'UTF-8', 'B', "\r\n");
    }
    if (preg_match('/[^\x20-\x7E]/', $value)) {
        return '=?UTF-8?B?' . base64_encode($value) . '?=';
    }

    return $value;
}

/** Einzeiliger reiner Text (Betreff, Name, Zusatzfelder): wörtlich, „<3“ bleibt; Umbrüche und Steuerzeichen als Leerzeichen (keine Header-Injection). */
function core_mail_clean_header(string $value): string
{
    return trim(preg_replace('/[\x00-\x1F\x7F]+/', ' ', $value) ?? '');
}

function core_mail_crlf(string $value): string
{
    $value = str_replace(["\r\n", "\r"], "\n", $value);
    return str_replace("\n", "\r\n", $value);
}

/** Text als quoted-printable: Zeilen höchstens 76 Zeichen (RFC 5322 erlaubt 998 Byte), für SMTP und mail() gleich. */
function core_mail_encode_body(string $text): string
{
    $encoded = quoted_printable_encode(core_mail_crlf($text));

    // Punkt am Zeilenanfang kodieren: eine Zeile „.“ beendet sonst beim sendmail ohne -i die Nachricht.
    return preg_replace('/^\./m', '=2E', $encoded) ?? $encoded;
}

/** Inhalt nach DATA: Header, Leerzeile, kodierter Text, Abschlusspunkt. */
function core_mail_smtp_data(array $headers, string $text): string
{
    return implode("\r\n", $headers)
        . "\r\n\r\n"
        . core_mail_dot_stuff(core_mail_encode_body($text))
        . "\r\n.";
}

function core_mail_dot_stuff(string $value): string
{
    return preg_replace('/^\./m', '..', $value) ?? $value;
}

function core_mail_fallback_sender(): string
{
    $host = preg_replace('/[^a-zA-Z0-9.-]/', '', (string) ($_SERVER['HTTP_HOST'] ?? 'localhost')) ?: 'localhost';
    if ($host === 'localhost') {
        return 'noreply@localhost.local';
    }

    return 'noreply@' . $host;
}
