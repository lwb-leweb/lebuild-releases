<?php
declare(strict_types=1);

// LE_PROJECT_ROOT (Code) und LE_INSTANCE_ROOT (Daten dieser Website); in einer Einzelinstallation derselbe Ordner.
require_once __DIR__ . '/instance.php';
// public/ der Website: Seiten und Uploads. Das Backend (public/admin/) ist Code und liegt immer unter LE_PROJECT_ROOT.
define('PUBLIC_ROOT', LE_INSTANCE_ROOT . '/public');
define('LE_SITE_ROOT', PUBLIC_ROOT . '/site');
// Alte Namen für das PHP der Website (public/site/includes/header.php, Vorlagen der Content-Typen
// und Kundenseiten, die daraus entstanden sind) und tools/; der Kern selbst nutzt LE_PROJECT_ROOT und
// LE_SITE_ROOT. Nicht entfernen, solange Seiten sie nutzen.
define('PROJECT_ROOT', LE_PROJECT_ROOT);
define('SITE_ROOT', LE_SITE_ROOT);
define('CONTENT_ROOT', LE_INSTANCE_ROOT . '/content');
// Persistente Konfiguration bleibt direkt unter content/ (users.json,
// plugins.json, config.json, content-types/, labels/). Alles, was sich aus
// public/site/ + dem Importer rekonstruieren lässt — Seiten-JSON, Backups,
// Originale, Import-Status, Updater-Runtime-State — landet unter
// content/cache/ und ist gefahrlos wegwerfbar.
define('CACHE_ROOT', CONTENT_ROOT . '/cache');
define('PAGES_ROOT', CACHE_ROOT . '/pages');
define('BACKUPS_ROOT', CACHE_ROOT . '/backups');
define('ORIGINALS_ROOT', CACHE_ROOT . '/originals');
// Einstellungen der Website (Backend → Einstellungen: name, url, email …); lesen über le_site_config().
const LE_SITE_CONFIG_FILE = CONTENT_ROOT . '/config.json';
define('UPLOADS_ROOT', PUBLIC_ROOT . '/uploads');
// URL-Pfad, unter dem api/upload.php hochgeladene Dateien ausliefert (Bildfelder speichern ihn so).
const UPLOADS_URL = '/public/uploads/';
// Kanonischer URL-Pfad der Website-Dateien unter LE_SITE_ROOT (le_site_request_file). Präfix LE_: Der Kern läuft im
// selben Prozess wie das PHP der Website, die eigene Namen wie SITE_URL definiert (public/site/includes/config.php).
const LE_SITE_FILES_URL = '/public/site/';
// Erlaubte Endungen für Uploads (siehe AGENTS.md, Upload-Whitelist) mit den MIME-Typen, die der
// Inhalt dazu haben muss (sonst landet z. B. ein SVG als .jpg an der Skript-Prüfung vorbei).
const UPLOAD_MIME_TYPES = [
    'jpg' => ['image/jpeg'],
    'jpeg' => ['image/jpeg'],
    'png' => ['image/png'],
    'webp' => ['image/webp'],
    'svg' => ['image/svg+xml', 'text/xml', 'application/xml'],
];
// Eigene Obergrenze für Uploads; wirksam ist das Minimum mit der PHP-Konfiguration (upload_max_bytes()).
const UPLOAD_MAX_BYTES = 5 * 1024 * 1024;
// Meldungen von api/upload.php (auch im Browser: upload_config()).
const UPLOAD_TEXT = [
    'noFile' => 'Es wurde keine Datei hochgeladen.',
    'failed' => 'Das Hochladen ist fehlgeschlagen.',
    'tooLarge' => 'Das Bild ist größer als %s MB.',
    'type' => 'Dieser Dateityp ist nicht erlaubt (erlaubt: %s).',
    'content' => 'Der Inhalt der Datei passt nicht zu ihrer Endung.',
    'svg' => 'SVG enthält Skripte oder externe Verweise und wurde abgelehnt.',
    'store' => 'Das Bild konnte nicht gespeichert werden.',
    // Beim Speichern (Seite, Plugin-Eintrag): Bild aus den Uploads gibt es nicht mehr (z. B. nach der Frist offener Uploads).
    'missing' => 'Bilddatei fehlt, bitte neu auswählen',
];
const BYTES_PER_MB = 1024 * 1024;
// Meldungen der API-Endpoints und des Kerns (json_response 'error'), wie der Browser sie zeigt.
// %s: Datei bzw. Fehler der Gegenstelle, nie ein Serverpfad.
const API_TEXT = [
    'method' => 'Diese Anfrage-Methode ist hier nicht erlaubt.',
    'invalidRequest' => 'Ungültige Anfrage.',
    'invalidJson' => 'Die Anfrage enthält kein gültiges JSON.',
    'invalidPageName' => 'Ungültiger Seitenname.',
    'invalidContent' => 'Ungültige Inhalte.',
    'invalidType' => 'Unbekannter Typ.',
    'invalidId' => 'Ungültige ID.',
    'invalidTarget' => 'Ungültiges Ziel.',
    'notFound' => 'Nicht gefunden.',
    'notAuthenticated' => 'Du bist nicht mehr angemeldet. Bitte melde dich neu an.',
    'passwordChange' => 'Bitte lege zuerst ein neues Passwort fest.',
    'forbidden' => 'Dafür fehlen dir die Rechte.',
    'csrf' => 'Die Anmeldung wurde erneuert. Bitte lade die Seite neu.',
    'invalidCredentials' => 'Benutzername oder Passwort ist falsch.',
    // Login-Seite ohne Benutzer und ohne brauchbares config.php (le_setup_missing); %d: PASSWORD_MIN_LENGTH.
    'setupMissing' => 'Noch kein Zugang eingerichtet. Im Hauptordner config.sample.php nach config.php kopieren und Benutzername und Passwort (mindestens %d Zeichen) des ersten Admins eintragen.',
    'userNotFound' => 'Benutzer nicht gefunden.',
    'usernameTaken' => 'Dieser Benutzername ist schon vergeben.',
    'userIdRequired' => 'Benutzer-ID fehlt.',
    'wrongPassword' => 'Das aktuelle Passwort stimmt nicht.',
    'lastAdminDemote' => 'Der letzte Administrator kann nicht herabgestuft werden.',
    'lastAdminDelete' => 'Der letzte Administrator kann nicht gelöscht werden.',
    'deleteSelf' => 'Das eigene Konto kann nicht gelöscht werden.',
    'pageNotFound' => 'Seite nicht gefunden.',
    'pageInvalid' => 'Die gespeicherten Inhalte dieser Seite sind beschädigt.',
    'invalidBackup' => 'Ungültiger Name eines gespeicherten Stands.',
    'backupNotFound' => 'Diesen gespeicherten Stand gibt es nicht mehr.',
    'backupInvalid' => 'Dieser gespeicherte Stand ist beschädigt.',
    'backupFailed' => 'Der bisherige Stand ließ sich nicht sichern.',
    // Abgleich einer direkt geänderten Datei gescheitert (le_sync_request): getPage, Speichern und
    // Wiederherstellen antworten 422; %s = „Name: Grund“ je Datei, dazu contactSupport.
    'syncFailed' => 'Die Seite lässt sich gerade nicht bearbeiten: Eine direkte Änderung lässt sich nicht übernehmen (%s).',
    // Dasselbe für Kopf- oder Fußzeile: getPage und Wiederherstellen laufen weiter und melden es als message.
    'syncSkipped' => 'Eine direkte Änderung lässt sich gerade nicht übernehmen (%s), dieser Teil bleibt beim alten Stand.',
    // Server lässt nicht schreiben (write_failed_message): vorab erkannt mit den betroffenen Namen
    // (writeFailedNames), mittendrin ohne; dazu, wer helfen kann (contactSupport).
    'writeFailed' => 'Nichts gespeichert: Der Server lässt keine Änderung zu%s.',
    'writeFailedNames' => ' (%s)',
    'contactSupport' => 'Bitte gib LEWEB Bescheid.',
    'lockFailed' => 'Die Seite ließ sich nicht sperren.',
    'encodeFailed' => 'Die Inhalte ließen sich nicht speichern.',
    'importStatusFailed' => 'Der Import-Status ließ sich nicht speichern.',
    'discardUploadsFailed' => 'Verworfene Bilder ließen sich nicht aufräumen.',
    // Sperre der offenen Uploads (le_open_uploads_hold) zu lange belegt.
    'uploadsBusy' => 'Gerade wird anderswo gespeichert oder ein Bild bearbeitet. Bitte gleich noch einmal versuchen.',
    'invalidPlugin' => 'Ungültiger Plugin-Name.',
    'pluginNotFound' => 'Plugin nicht gefunden.',
    'pluginNotInstalled' => 'Das Plugin ist nicht installiert.',
    'pluginNotActive' => 'Das Plugin ist nicht aktiv.',
    'noMainTable' => 'Das Plugin hat keine Haupttabelle.',
    'noValidFields' => 'Keine gültigen Felder.',
    'uninstallFailed' => 'Deinstallieren fehlgeschlagen.',
    'pluginInvalid' => 'Die Beschreibung des Plugins (plugin.json) ist ungültig.',
    'pluginStateFailed' => 'Der Plugin-Status ließ sich nicht speichern.',
    // %s: SQL-Datei des Plugins (Fehler der Datenbank nur ins Log, installSqlFailed).
    'pluginInstallFailed' => 'Die Tabellen des Plugins ließen sich nicht anlegen (%s).',
    'uploadsUnwritable' => 'Uploads-Verzeichnis nicht beschreibbar.',
    'mailUnavailable' => 'Kein Mailversand verfügbar. Bitte SMTP in den Einstellungen konfigurieren.',
    'dbFieldsRequired' => 'Host, Datenbankname und Benutzer sind Pflicht.',
    'connectionFailed' => 'Verbindung fehlgeschlagen: %s',
    // Nur fürs Server-Log: %1$s: SQL-Datei des Plugins, %2$s: Fehler der Datenbank.
    'installSqlFailed' => '%1$s ist fehlgeschlagen: %2$s',
    'testRecipient' => 'Gültige Test-Empfänger-Adresse erforderlich.',
    'testMailFailed' => 'Die Testmail ließ sich nicht senden. Bitte die Mail-Einstellungen prüfen.',
    'mailSaveFailed' => 'Die Mail-Einstellungen ließen sich nicht speichern.',
    'mailDeleteFailed' => 'Die Mail-Einstellungen ließen sich nicht löschen.',
    'siteBackupKeyFailed' => 'Der Backup-Schlüssel ließ sich nicht speichern.',
    'updateFailed' => 'Update fehlgeschlagen.',
    'rollbackFailed' => 'Rollback fehlgeschlagen.',
    // Prüfung von Benutzername, Passwort und Rolle (users_validate_*); %d: Grenze in Zeichen.
    'usernameRequired' => 'Bitte einen Benutzernamen angeben.',
    'usernameShort' => 'Der Benutzername braucht mindestens %d Zeichen.',
    'usernameLong' => 'Der Benutzername darf höchstens %d Zeichen haben.',
    'usernameChars' => 'Der Benutzername darf nur Buchstaben, Ziffern, Punkt, Unterstrich und Bindestrich enthalten.',
    'passwordShort' => 'Das Passwort braucht mindestens %d Zeichen.',
    'passwordLong' => 'Das Passwort darf höchstens %d Zeichen haben.',
    'invalidRole' => 'Unbekannte Rolle.',
    'samePassword' => 'Bitte ein anderes Passwort wählen.',
    'invalidEmail' => 'Bitte eine gültige E-Mail-Adresse eingeben.',
    'invalidUrl' => 'Bitte eine gültige Adresse der Website eingeben, z. B. https://www.beispiel.at.',
];
// Zugangsdaten (db.config.php, mail.config.php): unter content/, damit Backups
// sie erfassen und Updates sie nicht anfassen.
define('CONFIG_ROOT', CONTENT_ROOT . '/config');
// Plugin-Daten in SQLite (Standard, solange keine MySQL-Config existiert).
define('DATA_ROOT', CONTENT_ROOT . '/data');
// Altdaten nach einem Treiber-Umzug (nicht im Cache, damit sie im Backup landen).
define('DB_ARCHIVE_ROOT', CONTENT_ROOT . '/db-archiv');
// Schlüssel der Installation (app_secret), Benutzer (users_path), Stand der Sicherung (site_backup_state_path).
const LE_SECRET_FILE = CONTENT_ROOT . '/secret.key';
const LE_USERS_FILE = CONTENT_ROOT . '/users.json';
const LE_BACKUP_STATE_FILE = CONTENT_ROOT . '/backup.json';
// Daten mit Geheimnissen, die der Kern nur für den Eigentümer schreibt (write_private_file, SQLite per chmod);
// Ordner mit allem darunter. Einzige Liste dafür: Das Einspielen einer Sicherung setzt genau hier PRIVATE_FILE_MODE
// (le_private_data), alles andere bekommt die Rechte neuer Dateien. Das Aktivitäts-Log und content/cache/ sind nicht in
// der Sicherung.
const LE_PRIVATE_DATA = [LE_SECRET_FILE, LE_USERS_FILE, LE_BACKUP_STATE_FILE, CONFIG_ROOT, DATA_ROOT, DB_ARCHIVE_ROOT];
// Zeitzone für Veröffentlichungszeiten und Zeitstempel, falls der Hoster im
// php.ini keine setzt. PHP < 8.4 meldet dann '', ab 8.4 den Standard 'UTC' –
// beides gilt als „nicht gesetzt“.
const APP_TIMEZONE = 'Europe/Vienna';
// Rechte für Dateien mit Geheimnissen (Zugangsdaten, Schlüssel, Benutzer, SQLite).
const PRIVATE_FILE_MODE = 0600;
if (in_array((string) ini_get('date.timezone'), ['', 'UTC'], true)) {
    date_default_timezone_set(APP_TIMEZONE);
}
// Zeitangaben für Menschen (day_time_label): Kalendertag als heute, gestern oder Datum, dazu die Uhrzeit.
const DAY_LABEL_TODAY = 'heute';
const DAY_LABEL_YESTERDAY = 'gestern';
const DAY_LABEL_DATE_FORMAT = 'd.m.Y';
const DAY_LABEL_TIME_FORMAT = 'H:i';

/** „heute, 03:12“, „gestern, 03:12“ oder „12.10.2026, 03:12“ – Kalendertage in der App-Zeitzone. */
function day_time_label(int $ts, int $now): string
{
    $zone = new DateTimeZone(date_default_timezone_get());
    $time = (new DateTimeImmutable('@' . $ts))->setTimezone($zone);
    $today = (new DateTimeImmutable('@' . $now))->setTimezone($zone);
    $day = $time->format('Y-m-d');
    if ($day === $today->format('Y-m-d')) {
        $label = DAY_LABEL_TODAY;
    } elseif ($day === $today->modify('-1 day')->format('Y-m-d')) {
        $label = DAY_LABEL_YESTERDAY;
    } else {
        $label = $time->format(DAY_LABEL_DATE_FORMAT);
    }
    return $label . ', ' . $time->format(DAY_LABEL_TIME_FORMAT);
}

/** Größe aus der php.ini („2M“, „512K“, „1G“, Bytes) in Bytes; null ohne Grenze („0“, leer). */
function ini_size_bytes(string $value): ?int
{
    $value = trim($value);
    $factors = ['k' => 1024, 'm' => 1024 ** 2, 'g' => 1024 ** 3];
    $bytes = (int) $value * ($factors[strtolower(substr($value, -1))] ?? 1);
    return $bytes > 0 ? $bytes : null;
}

/** Größte Datei, die tatsächlich ankommt: UPLOAD_MAX_BYTES, upload_max_filesize und post_max_size. */
function upload_max_bytes(): int
{
    $limits = [UPLOAD_MAX_BYTES];
    foreach (['upload_max_filesize', 'post_max_size'] as $setting) {
        $bytes = ini_size_bytes((string) ini_get($setting));
        if ($bytes !== null) {
            $limits[] = $bytes;
        }
    }
    return min($limits);
}

/** „Das Bild ist größer als 2 MB.“ mit der wirksamen Grenze (eine Nachkommastelle, deutsches Komma). */
function upload_too_large_message(): string
{
    $megabytes = rtrim(rtrim(number_format(upload_max_bytes() / BYTES_PER_MB, 1, ',', ''), '0'), ',');
    return sprintf(UPLOAD_TEXT['tooLarge'], $megabytes);
}

/** Für die Dateiauswahl im Browser: accept, Größenprüfung vor dem Upload und ihre Meldung. */
function upload_config(): array
{
    return [
        'extensions' => array_keys(UPLOAD_MIME_TYPES),
        'maxBytes' => upload_max_bytes(),
        'tooLarge' => upload_too_large_message(),
    ];
}

function ensure_dir(string $path): void
{
    if (!is_dir($path) && !mkdir($path, 0775, true) && !is_dir($path)) {
        throw new RuntimeException('Cannot create directory: ' . $path);
    }
}

/**
 * Nach dem Schreiben einer Datei: OPcache vergisst ihre übersetzte Fassung, damit der nächste Aufruf
 * die neue ausführt. Seiten, Kopf-/Fußzeile und Konfigurationen sind PHP; Hoster prüfen die
 * Zeitstempel oft selten oder nie (opcache.validate_timestamps=0). Ohne OPcache tut es nichts.
 */
function forget_compiled_file(string $path): void
{
    if (function_exists('opcache_invalidate')) {
        @opcache_invalidate($path, true);
    }
}

/** forget_compiled_file für eine Datei bzw. alle PHP-Dateien eines Ordners (Auto-Update tauscht ganze Ordner). */
function forget_compiled_tree(string $path): void
{
    if (!is_dir($path)) {
        forget_compiled_file($path);
        return;
    }
    foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS)) as $file) {
        if ($file->isFile() && strtolower($file->getExtension()) === 'php') {
            forget_compiled_file($file->getPathname());
        }
    }
}

/** Ist $path einer der Pfade $dirs oder liegt darunter? Ganze Segmente: „content/configx“ liegt nicht in „content/config“. */
function le_path_in(string $path, array $dirs): bool
{
    foreach ($dirs as $dir) {
        if ($path === $dir || str_starts_with($path, $dir . '/')) {
            return true;
        }
    }
    return false;
}

/** Gehört $path (absolut) zu LE_PRIVATE_DATA, ist also nur für den Eigentümer lesbar? */
function le_private_data(string $path): bool
{
    return le_path_in($path, LE_PRIVATE_DATA);
}

/** Rechte einer neuen, nicht privaten Datei: wie von file_put_contents, 0666 ohne umask (write_file_atomic, Einspielen einer Sicherung). */
function le_new_file_mode(): int
{
    return 0666 & ~umask();
}

// Temp-Datei von write_file_atomic: <name>.tmp.<zufall> neben dem Ziel (nie ins Repo eines Kundenordners, tools/sites.php).
const LE_ATOMIC_TMP_INFIX = '.tmp.';

/**
 * Schreibt atomar: Temp-Datei mit eindeutigem Namen im selben Ordner, dann rename. Gleichzeitige
 * Schreiber kommen sich so nie in die Quere, Leser sehen den alten oder den neuen Stand. Eine
 * vorhandene Datei behält ihre Rechte, eine neue bekommt le_new_file_mode() (tempnam legt 0600 an,
 * das sperrte z. B. Git als anderer Benutzer der Gruppe aus); $private oder ein Pfad aus
 * LE_PRIVATE_DATA (le_private_data, dieselbe Liste wie beim Einspielen einer Sicherung): immer
 * PRIVATE_FILE_MODE, der Inhalt ist nie mit anderen Rechten lesbar. Scheitert es, bleibt die Datei, wie sie war, und
 * es fliegt eine RuntimeException (nur mit dem Dateinamen). Für Lesen → Ändern → Schreiben hält
 * der Aufrufer dazu store_lock(). Ist $path ein Symlink (z. B. core/mail.config.php aus dem Webroot
 * heraus), wird atomar ins Ziel geschrieben und der Link bleibt.
 */
function write_file_atomic(string $path, string $content, bool $private = false): void
{
    $private = $private || le_private_data($path);
    $link = null;
    if (is_link($path) && ($real = realpath($path)) !== false) {
        [$link, $path] = [$path, $real];
    }
    $dir = dirname($path);
    ensure_dir($dir);

    // tempnam weicht ohne Schreibrecht auf den System-Temp-Ordner aus; es liefert den aufgelösten
    // Pfad, deshalb realpath (Ablage oder Website hinter einem Symlink).
    $tmp = @tempnam($dir, basename($path) . LE_ATOMIC_TMP_INFIX);
    $written = $tmp !== false && realpath(dirname($tmp)) === realpath($dir)
        && (!$private || @chmod($tmp, PRIVATE_FILE_MODE))
        && @file_put_contents($tmp, $content, LOCK_EX) !== false;
    if ($written && !$private) {
        @chmod($tmp, is_file($path) ? fileperms($path) & 0777 : le_new_file_mode());
    }
    if (!$written || !@rename($tmp, $path)) {
        if ($tmp !== false) {
            @unlink($tmp);
        }
        throw new RuntimeException('Cannot write ' . basename($link ?? $path));
    }
    forget_compiled_file($path);
    if ($link !== null) {
        forget_compiled_file($link);
    }
}

/**
 * Schreibt eine Datei atomar und nur für den Eigentümer lesbar (PRIVATE_FILE_MODE). Unter content/ außerhalb von
 * LE_PRIVATE_DATA nur, was nicht in die Sicherung kommt (content/cache/, Aktivitäts-Log): Das Einspielen einer
 * Sicherung gäbe einer solchen Datei die Rechte neuer Dateien. Pfade aus der Liste schreibt write_file_atomic
 * ohnehin privat.
 */
function write_private_file(string $path, string $content): void
{
    write_file_atomic($path, $content, true);
}

/**
 * Sperre für Lesen → Ändern → Schreiben einer kleinen Datei (users.json, config.json,
 * active-plugins.json, …): flock auf content/cache/<name>.lock, wartet auf laufende. Frei mit
 * store_unlock(), spätestens am Ende des Requests. Nie verschachtelt für denselben Namen.
 * $dir statt content/cache/: Sperre außerhalb einer Website (tools/sites.php, domains.json).
 */
function store_lock(string $name, ?string $dir = null)
{
    $dir ??= CACHE_ROOT;
    ensure_dir($dir);
    $handle = @fopen($dir . '/' . $name . '.lock', 'c');
    if ($handle === false || !flock($handle, LOCK_EX)) {
        throw new RuntimeException('Cannot lock ' . $name);
    }
    return $handle;
}

function store_unlock($handle): void
{
    flock($handle, LOCK_UN);
    fclose($handle);
}

/** Namen der Einträge eines Ordners (ohne . und ..); leer, wenn es ihn nicht gibt. */
function dir_entries(string $dir): array
{
    return is_dir($dir) ? array_values(array_diff(scandir($dir) ?: [], ['.', '..'])) : [];
}

/** Darf ein ZIP-Eintrag so entpackt werden (kein Ausbruch aus dem Zielordner)? */
function zip_entry_name_safe(string $name): bool
{
    if ($name === '' || str_contains($name, '\\') || str_contains($name, ':')) {
        return false;
    }
    // Nur ganze Pfad-Segmente zählen: „wien..jpg“ ist ein gültiger Dateiname.
    // Ein Schrägstrich am Ende kennzeichnet einen Ordner-Eintrag.
    return !array_intersect(explode('/', rtrim($name, '/')), ['..', '.', '']);
}

function json_response(array $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function read_json_body(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return [];
    }

    $data = json_decode($raw, true);
    if (!is_array($data)) {
        json_response(['ok' => false, 'error' => API_TEXT['invalidJson']], 400);
    }

    return $data;
}

// Vorgaben, solange nichts gespeichert ist: neutral wie in public/site/includes/config.php, nie die Daten
// des Anbieters (sonst übernimmt sie das erste Speichern der Einstellungen).
const LE_SITE_CONFIG_DEFAULTS = [
    'name' => 'LeBuild',
    'tagline' => 'Die Website-Revolution',
    'url' => 'https://example.com',
    'email' => 'office@example.com',
    'owner' => 'Dein Name',
    'locale' => 'de_AT',
];

/** Einstellungen der Website (LE_SITE_CONFIG_FILE); [] ohne Datei oder bei kaputtem JSON. */
function le_site_config(): array
{
    $config = is_file(LE_SITE_CONFIG_FILE) ? json_decode((string) file_get_contents(LE_SITE_CONFIG_FILE), true) : null;

    return is_array($config) ? $config : [];
}

/** le_site_config() über den Vorgaben (LE_SITE_CONFIG_DEFAULTS), für die Einstellungen im Backend. */
function le_site_config_with_defaults(): array
{
    return array_merge(LE_SITE_CONFIG_DEFAULTS, le_site_config());
}

/** Seitenname nach der Whitelist (Buchstaben, Ziffern, _ und -), ohne die Anfrage abzubrechen. */
function is_safe_page_name(string $page): bool
{
    return preg_match('/^[a-zA-Z0-9_-]+$/', $page) === 1;
}

function safe_page_name(string $page): string
{
    $page = trim($page);
    if (!is_safe_page_name($page)) {
        json_response(['ok' => false, 'error' => API_TEXT['invalidPageName']], 400);
    }

    return $page;
}

function sanitize_text_value(mixed $value): string
{
    if (!is_scalar($value)) {
        return '';
    }

    $clean = strip_tags((string) $value, '<br>');
    // strip_tags keeps attributes on allowed tags — normalize <br foo="…"> to plain <br>
    $clean = preg_replace('/<br\b[^>]*>/i', '<br>', $clean) ?? $clean;
    return trim($clean);
}

function flatten_content(array $content, string $prefix = ''): array
{
    $flat = [];
    foreach ($content as $key => $value) {
        $path = $prefix === '' ? (string) $key : $prefix . '.' . $key;
        if (is_array($value)) {
            $flat += flatten_content($value, $path);
        } else {
            $flat[$path] = $value;
        }
    }

    return $flat;
}

/** Gegenstück zu flatten_content: Pfad → Wert wird wieder ein Baum. */
function unflatten_content(array $flat): array
{
    $tree = [];
    foreach ($flat as $path => $value) {
        set_nested_value($tree, (string) $path, $value);
    }
    return $tree;
}

function set_nested_value(array &$target, string $path, mixed $value): void
{
    $parts = explode('.', $path);
    $cursor = &$target;
    foreach ($parts as $index => $part) {
        if ($index === count($parts) - 1) {
            $cursor[$part] = $value;
            return;
        }

        if (!isset($cursor[$part]) || !is_array($cursor[$part])) {
            $cursor[$part] = [];
        }
        $cursor = &$cursor[$part];
    }
}

// So oft (je APP_SECRET_WAIT_US) wartet app_secret auf den Schlüssel, den ein gleichzeitiger Request gerade anlegt.
const APP_SECRET_WAIT_ATTEMPTS = 40;
const APP_SECRET_WAIT_US = 25000;

/**
 * Zufälliger Schlüssel pro Installation (HMAC für Formular-Signaturen,
 * Rate-Limit-Dateinamen). Wird beim ersten Aufruf erzeugt und liegt in
 * content/, das weder ausgeliefert noch vom Update angefasst wird.
 * Nur ein Request legt ihn an (fopen 'x', zunächst leer), der Inhalt kommt
 * über write_private_file (nie mit Standardrechten lesbar); gleichzeitige
 * Requests warten auf diesen Schlüssel statt einen eigenen zu schreiben.
 */
function app_secret(): string
{
    static $secret = null;
    if ($secret !== null) {
        return $secret;
    }

    $path = LE_SECRET_FILE;
    ensure_dir(CONTENT_ROOT);
    for ($attempt = 0; $attempt < APP_SECRET_WAIT_ATTEMPTS; $attempt++) {
        $existing = is_file($path) ? trim((string) @file_get_contents($path)) : '';
        if (strlen($existing) >= 64) {
            return $secret = $existing;
        }
        $claim = @fopen($path, 'x');
        if ($claim !== false) {
            fclose($claim);
            return $secret = app_secret_write($path);
        }
        usleep(APP_SECRET_WAIT_US);
    }
    // Die Datei ist da, aber ohne gültigen Schlüssel (beschädigt, abgebrochenes Anlegen): neu.
    return $secret = app_secret_write($path);
}

function app_secret_write(string $path): string
{
    $new = bin2hex(random_bytes(32));
    try {
        write_private_file($path, $new);
    } catch (RuntimeException $e) {
        // Keine leere Datei zurücklassen, auf die spätere Requests warten würden.
        if (is_file($path) && filesize($path) === 0) {
            @unlink($path);
        }
        throw $e;
    }
    return $new;
}

function current_iso_time(): string
{
    return gmdate('Y-m-d\TH:i:s\Z');
}

// Namen der Komponenten für Kunden (Nachfrage beim Wiederherstellen im Verlauf).
const COMPONENT_LABELS = ['header' => 'Kopfzeile', 'footer' => 'Fußzeile'];

function shared_components(): array
{
    return [
        'header' => LE_SITE_ROOT . '/includes/navigation.php',
        'footer' => LE_SITE_ROOT . '/includes/footer.php',
    ];
}

/**
 * SVG darf nur rein, wenn es nichts Ausführbares enthält. Lieber zu streng
 * als zu lax: abgelehnt wird, was nicht nach reiner Grafik aussieht.
 */
function svg_is_safe(string $svg): bool
{
    // Nur UTF-8: In UTF-16 o. Ä. fände die Suche nach DOCTYPE/ENTITY nichts, libxml liest die Datei trotzdem.
    if (!preg_match('//u', $svg) || str_contains($svg, "\0")) {
        return false;
    }
    if (stripos($svg, '<!ENTITY') !== false || stripos($svg, '<!DOCTYPE') !== false) {
        return false;
    }

    $doc = new DOMDocument();
    $previous = libxml_use_internal_errors(true);
    $loaded = $doc->loadXML($svg, LIBXML_NONET);
    libxml_clear_errors();
    libxml_use_internal_errors($previous);
    if (!$loaded || $doc->documentElement === null || strtolower($doc->documentElement->localName) !== 'svg') {
        return false;
    }
    // Was libxml tatsächlich gelesen hat: keine andere Kodierung, kein DOCTYPE, keine Entity-Referenz
    // (die Prüfung unten sieht nicht hinein, Browser setzen interne Entities aber ein).
    if (($doc->xmlEncoding !== null && strtolower($doc->xmlEncoding) !== 'utf-8') || $doc->doctype !== null || svg_has_entity_reference($doc)) {
        return false;
    }

    $forbiddenElements = ['script', 'foreignobject', 'iframe', 'embed', 'object', 'handler', 'listener'];
    foreach ($doc->getElementsByTagName('*') as $element) {
        $name = strtolower($element->localName);
        if (in_array($name, $forbiddenElements, true)) {
            return false;
        }
        foreach ($element->attributes as $attr) {
            $attrName = strtolower($attr->localName);
            $value = strtolower((string) preg_replace('/[\s\x00-\x1f]+/', '', $attr->value));
            if (str_starts_with($attrName, 'on')) {
                return false;
            }
            if (str_contains($value, 'javascript:') || str_contains($value, 'data:text') || str_contains($value, 'data:image/svg')) {
                return false;
            }
            // Verweise nur innerhalb der Datei (#id) oder auf eingebettete Rastergrafiken.
            if ($attrName === 'href' && $value !== '' && !str_starts_with($value, '#') && !preg_match('#^data:image/(png|jpe?g|gif|webp);#', $value)) {
                return false;
            }
            // <animate attributeName="href" …> könnte einen Link nachträglich umbiegen.
            if ($attrName === 'attributename' && str_contains($value, 'href')) {
                return false;
            }
        }
    }

    return true;
}

/** Steckt irgendwo im Dokument ein Entity-Referenz-Knoten? */
function svg_has_entity_reference(DOMNode $node): bool
{
    foreach ($node->childNodes as $child) {
        if ($child->nodeType === XML_ENTITY_REF_NODE || svg_has_entity_reference($child)) {
            return true;
        }
    }
    if ($node instanceof DOMElement) {
        foreach ($node->attributes as $attr) {
            if (svg_has_entity_reference($attr)) {
                return true;
            }
        }
    }
    return false;
}

// Sandbox für hochgeladene SVGs, wenn jemand sie direkt öffnet: Skripte laufen nicht, auch ohne
// mod_headers (index.php setzt sie selbst, für Nginx steht sie in der README).
const UPLOADS_SVG_CSP = "default-src 'none'; img-src data:; style-src 'unsafe-inline'; sandbox";

const UPLOADS_HTACCESS = <<<'HTACCESS'
# Von LeBuild angelegt. Uploads sind reine Dateien: nichts ausführen,
# SVGs ohne Skripte ausliefern.
<IfModule mod_headers.c>
  Header set X-Content-Type-Options "nosniff"
  <FilesMatch "(?i)\.svg$">
    Header set Content-Security-Policy "default-src 'none'; img-src data:; style-src 'unsafe-inline'; sandbox"
  </FilesMatch>
</IfModule>
<FilesMatch "(?i)\.(php[0-9]?|phtml|phar|cgi|pl|py|sh)$">
  <IfModule mod_authz_core.c>
    Require all denied
  </IfModule>
  <IfModule !mod_authz_core.c>
    Order deny,allow
    Deny from all
  </IfModule>
</FilesMatch>

HTACCESS;

