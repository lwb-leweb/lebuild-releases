<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/markup.php';

// Adressen, die index.php selbst belegt: private Ordner (nie ausgeliefert, zusätzlich zu ihren
// .htaccess) und das Backend (auch unter /public/admin). Die Login-Seite ist LOGIN_URL.
const LE_SITE_PRIVATE_DIRS = ['content', 'core', 'tests', 'tools'];
// Dateien im Hauptordner, die index.php nie ausliefert oder ausführen lässt (Zugang des ersten Admins, LE_SETUP_CONFIG_FILE).
const LE_SITE_PRIVATE_FILES = ['config.php', 'config.sample.php'];
const LE_ADMIN_PATH = '/admin';
// Erlaubte Zeichen einer angefragten Datei unter public/site bzw. public/admin; „..“ ist zusätzlich verboten.
const LE_SITE_PATH_PATTERN = '#^[A-Za-z0-9_./@\-]+$#';
// Dateien, die index.php als Seite rendert (Shortcodes, Plugin-Filter, Editor); alles andere geht unverändert raus.
const LE_SITE_DOCUMENT_EXTENSIONS = ['php', 'html', 'htm'];
// Adresse der 404-Seite der Website (404.php oder 404.html über le_site_request_file).
const LE_SITE_NOT_FOUND_PAGE = '/404';
// Website-Adresse aus den Einstellungen (le_site_config, Schlüssel url): http(s), Host, optional Port und Pfad.
const LE_SITE_BASE_URL_PATTERN = '#^https?://[A-Za-z0-9.-]+(?::\d+)?(?:/[A-Za-z0-9._~/-]*)?$#';
// Ordner unter public/site mit Teilen der Website (Kopf, Fuß, Vorlagen der Plugins): nie als eigene Adresse.
const LE_SITE_INCLUDES_DIR = 'includes';

/**
 * Adresse in einer Schreibweise, gegen die index.php alle Sperren prüft: Mehrfach-Slashes und „.“-Stücke
 * fallen weg (/./content//x → /content/x), ein Schrägstrich am Ende bleibt. null bei „..“-Stücken.
 */
function le_site_canonical_path(string $path): ?string
{
    $segments = [];
    foreach (explode('/', $path) as $part) {
        if ($part === '..') {
            return null;
        }
        if ($part !== '' && $part !== '.') {
            $segments[] = $part;
        }
    }
    $canonical = '/' . implode('/', $segments);

    return $segments !== [] && str_ends_with($path, '/') ? $canonical . '/' : $canonical;
}

/**
 * Datei unter public/site für die Adresse $path, wie index.php sie ausliefert, null ohne:
 *   /                → index.{php,html}
 *   /imprint         → imprint, imprint.{php,html} oder imprint/index.{php,html}
 *   /public/site/x   → x (kanonisch)
 */
function le_site_request_file(string $path): ?string
{
    $path = le_site_canonical_path($path);
    if ($path === null) {
        return null;
    }
    if (str_starts_with($path, LE_SITE_FILES_URL)) {
        $relative = substr($path, strlen(LE_SITE_FILES_URL));
    } elseif ($path === '/') {
        $relative = '';
    } else {
        $relative = ltrim($path, '/');
    }
    $relative = rtrim($relative, '/');

    if ($relative !== '' && (str_contains($relative, '..') || !preg_match(LE_SITE_PATH_PATTERN, $relative))) {
        return null;
    }
    // Teile der Website sind keine Adresse (/includes/…, /public/site/includes/…, groß/klein egal).
    if (strtolower(explode('/', $relative)[0]) === LE_SITE_INCLUDES_DIR) {
        return null;
    }

    $candidates = [];
    if ($relative === '') {
        $candidates[] = LE_SITE_ROOT . '/index.php';
        $candidates[] = LE_SITE_ROOT . '/index.html';
    } else {
        $candidates[] = LE_SITE_ROOT . '/' . $relative;
        if (!le_site_is_document($relative)) {
            $candidates[] = LE_SITE_ROOT . '/' . $relative . '.php';
            $candidates[] = LE_SITE_ROOT . '/' . $relative . '.html';
            $candidates[] = LE_SITE_ROOT . '/' . $relative . '/index.php';
            $candidates[] = LE_SITE_ROOT . '/' . $relative . '/index.html';
        }
    }

    foreach ($candidates as $candidate) {
        if (is_file($candidate)) {
            return $candidate;
        }
    }

    return null;
}

/**
 * Ob die Adresse /$name schon vergeben ist: eine Datei, Seite oder ein Ordner der Website (le_site_request_file;
 * Adressen darunter gehören der Website), eine Adresse von index.php (private Ordner, Backend, Login) oder
 * ein Eintrag im Projektordner (api, plugins …). Groß/klein zählt nicht: Auf Hostern, deren Dateisystem sie
 * nicht unterscheidet, wäre /Content dasselbe wie /content und /Impressum dieselbe Seite wie /impressum.
 */
function le_site_path_taken(string $name): bool
{
    if (le_site_request_file('/' . $name) !== null) {
        return true;
    }
    $taken = le_site_reserved_names();
    foreach (scandir(LE_SITE_ROOT) ?: [] as $entry) {
        $taken[] = $entry;
        if (le_site_is_document($entry)) {
            $taken[] = pathinfo($entry, PATHINFO_FILENAME);
        }
    }

    return in_array(strtolower($name), array_map('strtolower', $taken), true);
}

/** Erste Adress-Segmente, die nicht der Website gehören: private Ordner, Backend, Login, Includes, Projektordner. */
function le_site_reserved_names(): array
{
    return array_merge(LE_SITE_PRIVATE_DIRS, [ltrim(LE_ADMIN_PATH, '/'), ltrim(LOGIN_URL, '/'), LE_SITE_INCLUDES_DIR], scandir(LE_PROJECT_ROOT) ?: []);
}

/** Ob $file (Datei oder Adresse) ein Dokument der Website ist (LE_SITE_DOCUMENT_EXTENSIONS). */
function le_site_is_document(string $file): bool
{
    return in_array(strtolower(pathinfo($file, PATHINFO_EXTENSION)), LE_SITE_DOCUMENT_EXTENSIONS, true);
}

/**
 * Adresse ohne Endung für eine Seite, die mit Endung oder über /public/site/ aufgerufen wurde ($path kanonisch,
 * $file aus le_site_request_file): /impressum.php → /impressum, /public/site/index.html → /, /a/index.php → /a/.
 * null, wenn $path schon so heißt, die Datei kein Dokument ist, mit „_“ beginnt (Hilfs-Endpoints der Website)
 * oder die Adresse ohne Endung eine andere Datei liefern würde (z. B. a.php neben a.html) bzw. index.php sie
 * vorher selbst beantwortet (/login, /admin, Projektordner: le_site_reserved_names).
 */
function le_site_clean_path(string $path, string $file): ?string
{
    $name = basename($file);
    $asked = le_site_is_document($path) || str_starts_with($path, LE_SITE_FILES_URL);
    if (!$asked || !le_site_is_document($file) || str_starts_with($name, '_')) {
        return null;
    }
    $relative = substr($file, strlen(LE_SITE_ROOT) + 1);
    $dir = dirname($relative) === '.' ? '' : dirname($relative) . '/';
    $stem = pathinfo($name, PATHINFO_FILENAME);
    $clean = '/' . $dir . ($stem === 'index' ? '' : $stem);
    $first = strtolower(explode('/', ltrim($clean, '/'))[0]);
    if ($first !== '' && in_array($first, array_map('strtolower', le_site_reserved_names()), true)) {
        return null;
    }
    if ($clean === $path || realpath((string) le_site_request_file($clean)) !== realpath($file)) {
        return null;
    }

    return $clean;
}

/**
 * Was index.php für eine Adresse ausliefert (auf oberster Ebene eingebunden, siehe dort):
 *   file   – Seitendatei (PHP oder HTML), null ohne (dann leeres HTML für finish)
 *   status – HTTP-Status
 *   vars   – Variablen, die die Seite sieht (z. B. $item in page.php von Content-Typen)
 *   finish – null oder Closure(string $html): string, bekommt das gerenderte HTML vor Shortcodes und Filtern
 *   editor – Datei, deren Seite der Seiten-Editor bearbeitet (site_editor_page)
 * Plugins liefern dieselbe Form über den Hook site_page.
 */
function le_site_document(?string $file, int $status = 200, array $vars = [], ?Closure $finish = null, ?string $editor = null): array
{
    return ['file' => $file, 'status' => $status, 'vars' => $vars, 'finish' => $finish, 'editor' => $editor ?? (string) $file];
}

/** 404-Seite der Website (LE_SITE_NOT_FOUND_PAGE: 404.php oder 404.html) mit Status 404; null ohne. */
function le_site_not_found_document(): ?array
{
    $file = le_site_request_file(LE_SITE_NOT_FOUND_PAGE);

    return $file !== null && le_site_is_document($file) ? le_site_document($file, 404) : null;
}

/**
 * Website-Adresse aus den Einstellungen („Website-URL“) ohne „/“ am Ende, z. B. für canonical; null, wenn
 * keine oder keine gültige eingetragen ist. Nie aus der Anfrage (Host-Header ist vom Besucher).
 */
function le_site_base_url(): ?string
{
    $url = le_site_config()['url'] ?? null;
    $url = is_string($url) ? trim($url) : '';

    return preg_match(LE_SITE_BASE_URL_PATTERN, $url) ? rtrim($url, '/') : null;
}

/**
 * Setzt im <head> von $html Titel, Beschreibung und canonical ($head: title, description als Klartext,
 * canonical als Adresse): das erste vorhandene Tag bekommt den Wert, weitere gleiche fallen weg, fehlende
 * kommen ans Ende des Kopfes; og:title, og:description, og:url, twitter:title und twitter:description nur,
 * wenn es sie gibt (property oder name). Namen wie der Browser ohne Groß/klein („Description“). $head['base'] kommt als <base href> an den
 * Anfang des Kopfes, wenn es keinen gibt. Ohne <head> bleibt $html unverändert.
 */
function le_site_html_set_head(string $html, array $head): string
{
    $doc = markup_parse($html);
    $headIndex = markup_find_tag($doc, 'head');
    if ($headIndex === null) {
        return $html;
    }
    // Tags des Kopfes je Schlüssel (title, base, link:canonical, meta:<Name>), getrennt nach Tag-Art: ein
    // <meta name="title"> ist kein <title>. Nur Kinder des Kopfes, ein <title> in einem SVG im Body zählt nicht.
    $byKey = [];
    foreach ($doc['nodes'][$headIndex]['children'] as $i) {
        $node = $doc['nodes'][$i];
        if ($node['type'] !== 'element') {
            continue;
        }
        $key = match ($node['tag']) {
            'title', 'base' => $node['tag'],
            'meta' => 'meta:' . strtolower(trim(markup_attr_text($node, 'property') ?: markup_attr_text($node, 'name'))),
            'link' => in_array('canonical', preg_split('/\s+/', strtolower(markup_attr_text($node, 'rel'))) ?: [], true) ? 'link:canonical' : '',
            default => '',
        };
        if ($key !== '') {
            $byKey[$key][] = $i;
        }
    }

    // [Schlüssel, Inhalt, einfügen, wenn es fehlt]
    $tags = [
        ['title', $head['title'], true],
        ['meta:description', $head['description'], true],
        ['link:canonical', $head['canonical'], true],
        ['meta:og:title', $head['title'], false],
        ['meta:og:description', $head['description'], false],
        ['meta:og:url', $head['canonical'], false],
        ['meta:twitter:title', $head['title'], false],
        ['meta:twitter:description', $head['description'], false],
    ];
    $edits = [];
    $append = '';
    foreach ($tags as [$key, $value, $insert]) {
        $value = markup_attr_escape($value);
        $found = $byKey[$key] ?? [];
        if ($found === []) {
            $append .= !$insert ? '' : match ($key) {
                'title' => '<title>' . $value . '</title>',
                'link:canonical' => '<link rel="canonical" href="' . $value . '">',
                default => '<meta name="' . substr($key, strlen('meta:')) . '" content="' . $value . '">',
            };
            continue;
        }
        $first = array_shift($found);
        $edits[] = match ($key) {
            'title' => markup_set_inner($doc, $first, $value),
            'link:canonical' => markup_set_attr($doc, $first, 'href', $value),
            default => markup_set_attr($doc, $first, 'content', $value),
        };
        foreach ($found as $extra) {
            $edits[] = markup_remove_node($doc, $extra);
        }
    }

    $node = $doc['nodes'][$headIndex];
    if (isset($head['base']) && !isset($byKey['base'])) {
        // Vor allen relativen Adressen im Kopf (Stylesheets), damit sie schon danach aufgelöst werden.
        $edits[] = ['start' => $node['inner_start'], 'end' => $node['inner_start'], 'text' => '<base href="' . markup_attr_escape($head['base']) . '">'];
    }
    if ($append !== '') {
        $edits[] = ['start' => $node['inner_end'], 'end' => $node['inner_end'], 'text' => $append];
    }

    return markup_apply($html, $edits);
}
