<?php
declare(strict_types=1);

require_once __DIR__ . '/utils.php';

const USER_ROLE_EDITOR = 'editor';
const USER_ROLE_ADMIN = 'admin';
const USERS_STORE_VERSION = 1;
// Grenzen für Benutzername und Passwort (users_validate_*), in Bytes wie strlen().
const USERNAME_MIN_LENGTH = 3;
const USERNAME_MAX_LENGTH = 64;
const PASSWORD_MIN_LENGTH = 8;
const PASSWORD_MAX_LENGTH = 512;

function users_path(): string
{
    return LE_USERS_FILE;
}

function users_empty_store(): array
{
    return ['version' => USERS_STORE_VERSION, 'users' => []];
}

/**
 * Benutzer aus users.json. Ohne Datei ein leerer Store (Erst-Setup, auth_bootstrap_admin). Ist sie
 * da, aber unlesbar oder kein gültiger Store, ist der Store 'broken': niemand meldet sich an und
 * users_save überschreibt sie nie. Einträge, die nicht gelten (unbekannte Rolle, Pflichtfeld fehlt),
 * landen in 'unusable': Sie melden sich nicht an, bleiben beim Speichern aber erhalten.
 */
function users_load(): array
{
    $path = users_path();
    if (!is_file($path)) {
        return users_empty_store();
    }

    $raw = @file_get_contents($path);
    $data = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($data) || !isset($data['users']) || !is_array($data['users'])) {
        users_log_once('users.json is unreadable or invalid; login refused, file left untouched');
        return users_empty_store() + ['broken' => true];
    }

    $store = [
        'version' => is_int($data['version'] ?? null) ? $data['version'] : USERS_STORE_VERSION,
        'users' => [],
    ];

    foreach ($data['users'] as $user) {
        $valid = is_array($user) && !empty($user['id']) && !empty($user['username']) && !empty($user['passwordHash']) && !empty($user['role']);
        if (!$valid || !in_array($user['role'], [USER_ROLE_EDITOR, USER_ROLE_ADMIN], true)) {
            users_log_once('users.json has entries with unknown role or missing fields; they cannot log in but are kept');
            $store['unusable'][] = $user;
            continue;
        }
        $entry = [
            'id' => (string) $user['id'],
            'username' => (string) $user['username'],
            'passwordHash' => (string) $user['passwordHash'],
            'role' => (string) $user['role'],
            'createdAt' => (string) ($user['createdAt'] ?? current_iso_time()),
            'updatedAt' => (string) ($user['updatedAt'] ?? current_iso_time()),
        ];
        if (!empty($user['mustChangePassword'])) {
            $entry['mustChangePassword'] = true;
        }
        if (users_session_version($user) > 0) {
            $entry['sessionVersion'] = users_session_version($user);
        }
        $store['users'][] = $entry;
    }

    return $store;
}

/**
 * Stand der Anmeldungen eines Benutzers: Jede Passwortänderung zählt ihn hoch, Sessions mit einem
 * älteren Stand gelten nicht mehr (current_user). Ohne Eintrag 0.
 */
function users_session_version(array $user): int
{
    return max(0, (int) ($user['sessionVersion'] ?? 0));
}

/** Fehler zu users.json einmal je Request ins Fehlerprotokoll (users_load läuft je Request oft). */
function users_log_once(string $message): void
{
    static $logged = [];
    if (!isset($logged[$message])) {
        $logged[$message] = true;
        error_log('lebuild: ' . $message);
    }
}

function users_save(array $store): void
{
    // Nie einen Store aus einer kaputten Datei schreiben: Sie bleibt, wie sie ist, zum Reparieren.
    if (!empty($store['broken'])) {
        throw new RuntimeException('users.json is unreadable, not overwritten');
    }
    $store['version'] = USERS_STORE_VERSION;
    if (!isset($store['users']) || !is_array($store['users'])) {
        $store['users'] = [];
    }
    $store['users'] = array_merge($store['users'], $store['unusable'] ?? []);
    unset($store['unusable']);

    $encoded = json_encode($store, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if ($encoded === false) {
        throw new RuntimeException('Failed to encode users store');
    }

    write_private_file(users_path(), $encoded);
}

/**
 * Lesen → Ändern → Schreiben von users.json unter store_lock('users'): $change bekommt den Store
 * per Referenz, sein Ergebnis kommt zurück. So geht bei gleichzeitigen Änderungen (zwei Admins)
 * keine verloren. Bricht $change die Anfrage ab (json_response), wird nichts geschrieben.
 */
function users_update(callable $change): mixed
{
    $lock = store_lock('users');
    try {
        $store = users_load();
        $result = $change($store);
        users_save($store);
        return $result;
    } finally {
        store_unlock($lock);
    }
}

function users_find_by_username(string $username): ?array
{
    $username = trim($username);
    if ($username === '') {
        return null;
    }
    $store = users_load();
    foreach ($store['users'] as $user) {
        if (strcasecmp($user['username'], $username) === 0) {
            return $user;
        }
    }

    return null;
}

function users_find_by_id(string $id): ?array
{
    if ($id === '') {
        return null;
    }
    $store = users_load();
    foreach ($store['users'] as $user) {
        if ($user['id'] === $id) {
            return $user;
        }
    }

    return null;
}

function users_verify_password(array $user, string $password): bool
{
    if (empty($user['passwordHash']) || !is_string($user['passwordHash'])) {
        return false;
    }

    return password_verify($password, $user['passwordHash']);
}

function users_needs_rehash(array $user): bool
{
    if (empty($user['passwordHash']) || !is_string($user['passwordHash'])) {
        return false;
    }

    return password_needs_rehash($user['passwordHash'], PASSWORD_BCRYPT);
}

function users_generate_id(): string
{
    return 'u_' . bin2hex(random_bytes(6));
}

function users_validate_username(string $username): ?string
{
    $username = trim($username);
    if ($username === '') {
        return API_TEXT['usernameRequired'];
    }
    if (strlen($username) < USERNAME_MIN_LENGTH) {
        return sprintf(API_TEXT['usernameShort'], USERNAME_MIN_LENGTH);
    }
    if (strlen($username) > USERNAME_MAX_LENGTH) {
        return sprintf(API_TEXT['usernameLong'], USERNAME_MAX_LENGTH);
    }
    if (!preg_match('/^[a-zA-Z0-9._-]+$/', $username)) {
        return API_TEXT['usernameChars'];
    }

    return null;
}

function users_validate_password(string $password): ?string
{
    if (strlen($password) < PASSWORD_MIN_LENGTH) {
        return sprintf(API_TEXT['passwordShort'], PASSWORD_MIN_LENGTH);
    }
    if (strlen($password) > PASSWORD_MAX_LENGTH) {
        return sprintf(API_TEXT['passwordLong'], PASSWORD_MAX_LENGTH);
    }

    return null;
}

function users_validate_role(string $role): ?string
{
    if (!in_array($role, [USER_ROLE_EDITOR, USER_ROLE_ADMIN], true)) {
        return API_TEXT['invalidRole'];
    }

    return null;
}

function users_count_admins(?string $excludeId = null): int
{
    $store = users_load();
    $count = 0;
    foreach ($store['users'] as $user) {
        if (($user['role'] ?? null) !== USER_ROLE_ADMIN) {
            continue;
        }
        if ($excludeId !== null && $user['id'] === $excludeId) {
            continue;
        }
        $count++;
    }

    return $count;
}

function users_public_view(array $user): array
{
    return [
        'id' => $user['id'],
        'username' => $user['username'],
        'role' => $user['role'],
        'createdAt' => $user['createdAt'] ?? null,
        'updatedAt' => $user['updatedAt'] ?? null,
    ];
}
