<?php
declare(strict_types=1);

require_once __DIR__ . '/markup.php';
require_once __DIR__ . '/labels.php';
require_once __DIR__ . '/icons.php';

// Feldarten und ihre Bereinigung. Textwerte sind bereinigte HTML-Fragmente
// (kanonisch: Tags klein, nur erlaubte Tags, nur href und TEXT_ALLOWED_ATTRS in fester
// Reihenfolge, Text und Attributwerte als &amp; &lt; &gt; &quot;, <br> ohne Slash). Die Listen sind die einzige
// Quelle; der Browser bekommt sie im JSON-Block des Seiten-Editors (text_markup_config).

// Erlaubte Tags in Textwerten; zugleich die Inline-Elemente, die der Import als Teil des
// Elterntextes nimmt (core/importer.php), damit Import und Speichern dieselbe Form kennen.
const TEXT_ALLOWED_TAGS = ['strong', 'b', 'em', 'i', 'span', 'a', 'br', 'small', 'sub', 'sup', 'code', 'mark', 'abbr', 'cite', 'q', 'kbd', 's', 'time'];
// Attribute, die an erlaubten Tags bleiben (Wert escaped, leer fällt weg), damit Klassen der Website ein
// Speichern überstehen; alle anderen (style, on*, id, data-* …) fallen weg. An Links dazu target und rel
// nur mit festen Werten: target aus TEXT_LINK_TARGETS, rel nur mit Wörtern aus TEXT_LINK_RELS.
const TEXT_ALLOWED_ATTRS = ['class', 'title', 'lang', 'datetime'];
const TEXT_LINK_TARGETS = ['_blank', '_self', '_parent', '_top'];
const TEXT_LINK_RELS = ['noopener', 'noreferrer', 'nofollow', 'ugc', 'sponsored', 'external'];
// Fallen samt Inhalt weg; alle anderen fremden Tags werden ausgepackt.
const TEXT_DROP_TAGS = ['script', 'style', 'svg', 'template', 'noscript', 'iframe', 'object', 'textarea'];
// Ausgepackte Blöcke stehen zwischen <br>, damit Absätze aus Zwischenablage oder Dialog nicht zusammenlaufen.
const TEXT_BLOCK_TAGS = ['p', 'div', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'blockquote', 'pre', 'dt', 'dd', 'tr', 'td', 'th', 'figcaption', 'section', 'article', 'header', 'footer'];
// Fallen an Anfang und Ende eines Textwerts weg (Leerraum, geschütztes Leerzeichen, Umbruch).
const TEXT_TRIM_EDGES = [' ', "\t", "\n", "\r", "\f", "\v", "\u{A0}", '<br>'];
// Erlaubte Schemata für Links bzw. Bild-URLs; relative Pfade sind immer erlaubt.
const TEXT_LINK_SCHEMES = ['http', 'https', 'mailto', 'tel'];
const IMAGE_URL_SCHEMES = ['http', 'https'];
// Schema am Anfang einer URL (le_url_scheme, le_url_host).
const LE_URL_SCHEME_PATTERN = '/^([a-z][a-z0-9+.\-]*):/i';
// Schemata, deren Adressen auf einen Host führen (le_url_host); mailto: und tel: haben keinen.
const LE_URL_HOST_SCHEMES = ['http', 'https'];
// target/rel für Links auf einen anderen Host (le_url_link_attrs): neuer Tab ohne Zugriff auf diese Seite.
const LE_URL_EXTERNAL_ATTRS = ['target' => '_blank', 'rel' => 'noopener'];
// Zeichen am Ende eines gekürzten Textes (text_excerpt).
const LE_TEXT_EXCERPT_MARK = '…';

/**
 * Feldart nach dem letzten ID-Segment: text | url | image | alt | background | icon. Gilt für Felder
 * ohne Markierung in der Datei; sonst entscheidet die Markierung (field_target_kind, dazu linktext
 * und plain).
 */
function field_kind(string $id): string
{
    $field = edit_field_from_id($id);
    if (str_ends_with($field, '_alt')) {
        return 'alt';
    }
    return in_array($field, ['url', 'image', 'background', 'icon'], true) ? $field : 'text';
}

/** Bereinigung je Feldart (die eine Stelle für JSON und Seitendatei). */
function sanitize_field_value(string $kind, string $value): string
{
    return match ($kind) {
        'url' => sanitize_url($value, TEXT_LINK_SCHEMES),
        'image' => sanitize_url($value, IMAGE_URL_SCHEMES),
        'background' => sanitize_css_url(sanitize_url($value, IMAGE_URL_SCHEMES)),
        'alt', 'plain' => sanitize_plain_text($value),
        'icon' => le_icon_name($value),
        'linktext' => sanitize_text_markup($value, true),
        default => sanitize_text_markup($value),
    };
}

/**
 * Wert eines Feldes als Klartext für Anzeigen (Seitenliste, Verlauf): Textwerte ohne Auszeichnung,
 * Klartext-Arten (Alt-Text, Rohtext wie der Seitentitel) und URLs so, wie sie sind – dort ist
 * „<b>“ Text, keine Auszeichnung.
 */
function field_plain_text(string $kind, string $value): string
{
    return in_array($kind, ['text', 'linktext'], true) ? text_markup_plain($value) : $value;
}

/**
 * Reiner Text für ein Attribut (Alt-Text) oder ein Rohtext-Element (Seitentitel): wird nicht als HTML gelesen, < und & bleiben Zeichen;
 * Steuerzeichen (auch Zeilenumbrüche) werden zu Leerzeichen, Ränder getrimmt.
 */
function sanitize_plain_text(string $value): string
{
    return trim(preg_replace('/[\x00-\x1F\x7F]/u', ' ', $value) ?? '');
}

/**
 * URL, wie Browser sie lesen (WHATWG): Steuerzeichen und Leerzeichen an den Rändern weg, Tab und
 * Zeilenumbruch auch mittendrin, Backslash als Slash; andere Leerzeichen bleiben Teil des Pfades.
 */
function le_url_probe(string $url): string
{
    return str_replace('\\', '/', preg_replace('/[\t\n\r]+/', '', trim($url, "\x00..\x20")) ?? '');
}

/**
 * Schema einer URL in Kleinbuchstaben, null für Pfade und relative Adressen. Strenger als der Browser:
 * Steuerzeichen und Leerraum werden überall übersprungen, damit kein verstecktes Schema durchrutscht.
 */
function le_url_scheme(string $url): ?string
{
    return preg_match(LE_URL_SCHEME_PATTERN, preg_replace('/[\x00-\x20]+/', '', $url) ?? '', $m) ? strtolower($m[1]) : null;
}

/** URL mit erlaubtem Schema oder relativ; sonst leer. */
function sanitize_url(string $url, array $schemes): string
{
    $url = trim($url);
    $scheme = le_url_scheme($url);
    if ($scheme !== null && !in_array($scheme, $schemes, true)) {
        return '';
    }
    return $url;
}

/**
 * Host, auf den eine URL führt, in Kleinbuchstaben, gelesen wie im Browser (le_url_probe): bei http(s) und
 * ab zwei Slashes („//host“, „///host“, „/\host“); null für Pfade, Anker, mailto:, tel: und Adressen
 * ohne erkennbaren Host.
 */
function le_url_host(string $url): ?string
{
    $probe = le_url_probe($url);
    if (preg_match(LE_URL_SCHEME_PATTERN, $probe, $m)) {
        if (!in_array(strtolower($m[1]), LE_URL_HOST_SCHEMES, true)) {
            return null;
        }
        $probe = substr($probe, strlen($m[0]));
    } elseif (!str_starts_with($probe, '//')) {
        return null;
    }
    $host = parse_url('http://' . ltrim($probe, '/'), PHP_URL_HOST);

    return is_string($host) && $host !== '' ? strtolower($host) : null;
}

/**
 * target/rel eines Links: LE_URL_EXTERNAL_ATTRS, wenn er auf einen anderen Host führt als $ownHost
 * (Vorgabe: Host der Anfrage; beide le_host_normalize), sonst leer.
 */
function le_url_link_attrs(string $url, ?string $ownHost = null): array
{
    $host = le_url_host($url);
    $host = $host !== null ? le_host_normalize($host) : null;
    $own = le_host_normalize($ownHost ?? (string) ($_SERVER['HTTP_HOST'] ?? ''));

    return $host !== null && $host !== $own ? LE_URL_EXTERNAL_ATTRS : [];
}

/**
 * URL für url(…) in CSS: Leerraum, Klammern, Anführungszeichen und Backslash prozent-kodiert,
 * damit der Wert weder aus url(…) noch aus dem style-Attribut ausbricht und gleich zurückgelesen wird.
 */
function sanitize_css_url(string $url): string
{
    return preg_replace_callback('/[\s()\'"\\\\]/', static fn (array $m): string => rawurlencode($m[0]), $url) ?? '';
}

/**
 * Bereinigtes, kanonisches Fragment eines Textwerts (Klartext, Altwerte und Fragmente gleichermaßen).
 * $inLink: Text eines Links (Feldart linktext), eigene Links werden ausgepackt.
 */
function sanitize_text_markup(string $value, bool $inLink = false): string
{
    $doc = markup_parse($value);
    return text_markup_trim(text_markup_render($doc, $doc['roots'], $inLink));
}

/** Bereinigtes Fragment ohne TEXT_ALLOWED_ATTRS, target und rel: die Form, die Textwerte vor dem Erhalt der Attribute hatten (Backups). */
function text_markup_without_attrs(string $value): string
{
    $doc = markup_parse($value);
    return text_markup_trim(text_markup_render($doc, $doc['roots'], false, false));
}

/** TEXT_TRIM_EDGES an beiden Enden entfernen; linear, ohne Regex (lange Ränder brechen sonst ab). */
function text_markup_trim(string $html): string
{
    $start = 0;
    $end = strlen($html);
    do {
        $moved = false;
        foreach (TEXT_TRIM_EDGES as $edge) {
            $len = strlen($edge);
            while ($end - $start >= $len && substr_compare($html, $edge, $start, $len) === 0) {
                $start += $len;
                $moved = true;
            }
            while ($end - $start >= $len && substr_compare($html, $edge, $end - $len, $len) === 0) {
                $end -= $len;
                $moved = true;
            }
        }
    } while ($moved);
    return substr($html, $start, $end - $start);
}

/** Blockgrenze: <br> anhängen, außer am Anfang oder direkt nach einem Umbruch (auch mit Leerraum dazwischen). */
function text_markup_break(string $out): string
{
    $end = rtrim($out);
    return $end === '' || str_ends_with($end, '<br>') ? $out : $out . '<br>';
}

/**
 * Kanonische Ausgabe der Knoten; PHP-Blöcke, Kommentare und Deklarationen fallen weg.
 * Ein Link in einem Link wird ausgepackt ($inLink). $attrs: TEXT_ALLOWED_ATTRS, target und rel behalten.
 */
function text_markup_render(array $doc, array $indices, bool $inLink = false, bool $attrs = true): string
{
    $out = '';
    foreach ($indices as $index) {
        $node = $doc['nodes'][$index];
        if ($node['type'] === 'text') {
            $raw = substr($doc['source'], $node['start'], $node['end'] - $node['start']);
            $out .= text_markup_escape(html_entity_decode($raw, ENT_HTML5 | ENT_QUOTES, 'UTF-8'));
            continue;
        }
        if ($node['type'] !== 'element' || in_array($node['tag'], TEXT_DROP_TAGS, true)) {
            continue;
        }
        $tag = $node['tag'];
        $inner = text_markup_render($doc, $node['children'], $inLink || $tag === 'a', $attrs);
        if (!in_array($tag, TEXT_ALLOWED_TAGS, true)) {
            $block = in_array($tag, TEXT_BLOCK_TAGS, true);
            $out = ($block ? text_markup_break($out) : $out) . $inner;
            $out = $block ? text_markup_break($out) : $out;
            continue;
        }
        if ($tag === 'br') {
            $out .= '<br>';
            continue;
        }
        if ($inner === '') {
            continue;
        }
        if ($tag === 'a') {
            $href = markup_attr($node, 'href');
            $url = $inLink || $href === null || $href['has_php'] ? '' : sanitize_url(markup_attr_text($node, 'href'), TEXT_LINK_SCHEMES);
            $out .= $url === '' ? $inner : '<a href="' . text_markup_escape($url) . '"' . ($attrs ? text_markup_attrs($node, true) : '') . '>' . $inner . '</a>';
            continue;
        }
        $out .= '<' . $tag . ($attrs ? text_markup_attrs($node, false) : '') . '>' . $inner . '</' . $tag . '>';
    }
    return $out;
}

/**
 * Erlaubte Attribute eines Elements als ' name="wert"' in fester Reihenfolge: TEXT_ALLOWED_ATTRS, an Links
 * ($link) dazu target (nur TEXT_LINK_TARGETS) und rel (nur Wörter aus TEXT_LINK_RELS). Leere Werte und
 * Werte mit PHP fallen weg.
 */
function text_markup_attrs(array $node, bool $link): string
{
    $values = [];
    foreach (TEXT_ALLOWED_ATTRS as $name) {
        $values[$name] = (markup_attr($node, $name)['has_php'] ?? true) ? '' : markup_attr_text($node, $name);
    }
    if ($link) {
        $target = strtolower(markup_attr_text($node, 'target'));
        $values['target'] = in_array($target, TEXT_LINK_TARGETS, true) ? $target : '';
        $rel = preg_split('/[\t\n\f\r ]+/', strtolower(markup_attr_text($node, 'rel'))) ?: [];
        $values['rel'] = implode(' ', array_values(array_unique(array_intersect($rel, TEXT_LINK_RELS))));
    }
    $out = '';
    foreach ($values as $name => $value) {
        $out .= $value === '' ? '' : ' ' . $name . '="' . text_markup_escape($value) . '"';
    }
    return $out;
}

/** Text für Fragment und href: & < > " als Entities. */
function text_markup_escape(string $text): string
{
    return htmlspecialchars($text, ENT_COMPAT | ENT_HTML5 | ENT_SUBSTITUTE, 'UTF-8');
}

/** Mehrzeiliger Klartext (Feldart textarea) als HTML: escaped, Zeilenumbrüche als <br>. */
function le_text_lines(string $text): string
{
    return nl2br(markup_attr_escape($text), false);
}

/** Reiner Text eines (ungeprüften) Fragments: ohne Tags, Entities aufgelöst (Seitentitel, Klartextvergleich). */
function text_markup_plain(string $value): string
{
    $fragment = str_replace('<br>', ' ', sanitize_text_markup($value));
    return trim(html_entity_decode(strip_tags($fragment), ENT_HTML5 | ENT_QUOTES, 'UTF-8'));
}

/**
 * Klartext gekürzt: Leerraum zusammengezogen, höchstens $max Zeichen, sonst mit „…“ (Feldnamen, Verlauf).
 * $markInMax: „…“ zählt zu den $max Zeichen (feste Höchstlänge, z. B. Meta-Beschreibung).
 */
function text_excerpt(string $text, int $max, bool $markInMax = false): string
{
    $text = trim(preg_replace('/[\s\x{A0}]+/u', ' ', $text) ?? '');
    return mb_strlen($text) > $max ? rtrim(mb_substr($text, 0, $markInMax ? $max - mb_strlen(LE_TEXT_EXCERPT_MARK) : $max)) . LE_TEXT_EXCERPT_MARK : $text;
}

/** Trägt ein Textwert Auszeichnung, also ein Element außer <br>? Alter Klartext hat höchstens Umbrüche. */
function text_markup_has_formatting(string $value): bool
{
    foreach (markup_parse($value)['nodes'] as $node) {
        if ($node['type'] === 'element' && $node['tag'] !== 'br') {
            return true;
        }
    }
    return false;
}

/** Listen für den Browser (JSON-Block des Seiten-Editors, core/siteEditor.php → public/admin/site-editor/text-markup.js). */
function text_markup_config(): array
{
    return [
        'tags' => TEXT_ALLOWED_TAGS,
        'dropTags' => TEXT_DROP_TAGS,
        'blockTags' => TEXT_BLOCK_TAGS,
        'trimEdges' => TEXT_TRIM_EDGES,
        'linkSchemes' => TEXT_LINK_SCHEMES,
        'attrs' => TEXT_ALLOWED_ATTRS,
        'linkTargets' => TEXT_LINK_TARGETS,
        'linkRels' => TEXT_LINK_RELS,
    ];
}
