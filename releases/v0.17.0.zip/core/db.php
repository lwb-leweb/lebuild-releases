<?php
declare(strict_types=1);

require_once __DIR__ . '/utils.php';
require_once __DIR__ . '/updater.php';

function db_config_path(): string
{
    return updater_config_path('db.config.php');
}

function db_config_exists(): bool
{
    return is_file(db_config_path());
}

function db_load_config(): ?array
{
    if (!db_config_exists()) {
        return null;
    }
    $config = require db_config_path();
    if (!is_array($config)) {
        return null;
    }
    return $config;
}

/** $path nur fürs Archiv (Zugangsdaten samt Tabellenliste nach einem Umzug). */
function db_save_config(array $config, ?string $path = null): void
{
    $required = ['host', 'port', 'name', 'user', 'password'];
    foreach ($required as $key) {
        if (!isset($config[$key])) {
            throw new InvalidArgumentException("Missing db config key: {$key}");
        }
    }
    $config['charset'] = $config['charset'] ?? 'utf8mb4';

    write_private_file($path ?? db_config_path(), "<?php\nreturn " . var_export($config, true) . ";\n");
}

function db_dsn(array $config): string
{
    return sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=%s',
        $config['host'],
        (int) $config['port'],
        $config['name'],
        $config['charset']
    );
}

const DB_DRIVER_MYSQL = 'mysql';
const DB_DRIVER_SQLITE = 'sqlite';
const DB_SQLITE_FILE = 'site.sqlite';
const DB_SQLITE_PRAGMAS = [
    'journal_mode' => 'WAL',
    'foreign_keys' => 'ON',
    'busy_timeout' => 5000,
];
const DB_DATETIME_FORMAT = 'Y-m-d H:i:s';
// Einziger Text für fehlendes pdo_sqlite (Systemprüfung, Plugin-Liste, Aktivierung, Umzug).
const DB_SQLITE_MISSING_MESSAGE = 'pdo_sqlite – ohne sie laufen Plugins mit Datenbank nur mit MySQL-Zugangsdaten.';
// Plugin-Liste und Aktivierung: derselbe Text mit dem Kern vorneweg.
const DB_UNAVAILABLE_MESSAGE = 'Keine Datenbank verfügbar. ' . DB_SQLITE_MISSING_MESSAGE;
// Meldungen von DB-Test, DB-Einrichtung und Datenumzug an den Browser (ohne Punkt am Ende, sie stehen
// auch mitten im Satz). Texte von PDO und anderen Exceptions gehen nur ins Fehlerprotokoll.
const DB_TEXT = [
    'connection' => 'der MySQL-Server meldet einen Fehler (Details im Fehlerprotokoll)',
    'accessDenied' => 'Benutzer oder Passwort falsch, oder der Benutzer darf nicht auf diese Datenbank zugreifen',
    'unknownDatabase' => 'die Datenbank gibt es auf dem Server nicht',
    'unreachable' => 'der Server ist nicht erreichbar, Host und Port prüfen',
    'failed' => 'Fehler der Datenbank oder beim Schreiben (Details im Fehlerprotokoll)',
    // %s: Pfad der Sperrdatei relativ zur Installation.
    'lock' => 'die Sperrdatei %s lässt sich nicht anlegen oder schreiben',
];
// MySQL-Fehlernummern beim Verbindungsaufbau → Schlüssel in DB_TEXT (db_connection_error_text).
const DB_CONNECT_ERRORS = [
    1044 => 'accessDenied',
    1045 => 'accessDenied',
    1049 => 'unknownDatabase',
    2002 => 'unreachable',
    2003 => 'unreachable',
    2005 => 'unreachable',
    2006 => 'unreachable',
];

/** Fehler mit einer Meldung aus den Konstanten von db.php/dbMigration.php, die so an den Browser darf. */
final class DbMigrationException extends RuntimeException
{
}

// Sekunden bis ein MySQL-Verbindungsaufbau aufgibt (sonst wartet ein
// unerreichbarer Host bis zum Timeout des Betriebssystems, oft 30 s und mehr).
const DB_MYSQL_CONNECT_TIMEOUT = 5;

/** MySQL, sobald eine MySQL-Config existiert, sonst SQLite. */
function db_driver(): string
{
    return db_config_exists() ? DB_DRIVER_MYSQL : DB_DRIVER_SQLITE;
}

function db_sqlite_path(): string
{
    return DATA_ROOT . '/' . DB_SQLITE_FILE;
}

/** Kann der aktive Treiber eine Verbindung aufbauen (Config bzw. Erweiterung da)? */
function db_available(): bool
{
    return db_driver() === DB_DRIVER_MYSQL || extension_loaded('pdo_sqlite');
}

/** Aktuelle Zeit aus PHP für Zeitvergleiche und created_at/updated_at. */
function db_now(): string
{
    return date(DB_DATETIME_FORMAT);
}

// Funktion statt Konstante: db.php bleibt ladbar, auch wenn PDO fehlt.
function db_pdo_options(): array
{
    return [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
}

function db_connect_mysql(array $config): PDO
{
    return new PDO(db_dsn($config), $config['user'], $config['password'], db_pdo_options() + [PDO::ATTR_TIMEOUT => DB_MYSQL_CONNECT_TIMEOUT]);
}

function db_connect_sqlite(string $path): PDO
{
    ensure_dir(dirname($path));
    $isNew = !is_file($path);
    $pdo = new PDO('sqlite:' . $path, null, null, db_pdo_options());
    foreach (DB_SQLITE_PRAGMAS as $name => $value) {
        $pdo->exec("PRAGMA {$name} = {$value}");
    }
    // Wie die Zugangsdaten nur für den Eigentümer; -wal/-shm übernehmen die Rechte.
    if ($isNew) {
        @chmod($path, PRIVATE_FILE_MODE);
    }
    return $pdo;
}

$DB_CONNECTION = null;

function db(): PDO
{
    global $DB_CONNECTION;
    if ($DB_CONNECTION instanceof PDO) {
        return $DB_CONNECTION;
    }
    if (db_driver() === DB_DRIVER_SQLITE) {
        $DB_CONNECTION = db_connect_sqlite(db_sqlite_path());
    } else {
        $config = db_load_config();
        if ($config === null) {
            throw new RuntimeException('Database not configured. Activate a database-required plugin first.');
        }
        $DB_CONNECTION = db_connect_mysql($config);
    }
    // Ohne plugins.php (reine Kern-Requests) gibt es nichts zu reparieren.
    if (function_exists('plugin_restore_missing_tables')) {
        plugin_restore_missing_tables($DB_CONNECTION);
    }
    return $DB_CONNECTION;
}

/** Spaltennamen einer Tabelle (Name vorher mit plugin_table_name_valid() prüfen). */
function db_table_columns(string $table): array
{
    static $cache = [];
    if (!isset($cache[$table])) {
        $cache[$table] = db_pdo_columns(db(), $table);
    }
    return $cache[$table];
}

/** Spaltennamen einer Tabelle auf einer beliebigen Verbindung, dialektfrei. */
function db_pdo_columns(PDO $pdo, string $table): array
{
    $stmt = $pdo->query("SELECT * FROM `{$table}` LIMIT 0");
    $columns = [];
    for ($i = 0; $i < $stmt->columnCount(); $i++) {
        $columns[] = (string) $stmt->getColumnMeta($i)['name'];
    }
    return $columns;
}

/** Gemeinsame Verbindung schließen (vor Checkpoint/Archivieren, nach Treiberwechsel). */
function db_disconnect(): void
{
    global $DB_CONNECTION;
    $DB_CONNECTION = null;
}

/** SQLite-Datei samt -wal/-shm entfernen. */
function db_sqlite_remove(string $path): void
{
    foreach (['', '-wal', '-shm'] as $suffix) {
        if (is_file($path . $suffix)) {
            @unlink($path . $suffix);
        }
    }
}

/** MySQL-Zugangsdaten aus einem Request-Body; fehlen Pflichtfelder → 400. */
function db_config_from_body(array $body): array
{
    $config = [
        'host'     => trim((string) ($body['host'] ?? '')),
        'port'     => (int) ($body['port'] ?? 3306),
        'name'     => trim((string) ($body['name'] ?? '')),
        'user'     => (string) ($body['user'] ?? ''),
        'password' => (string) ($body['password'] ?? ''),
        'charset'  => 'utf8mb4',
    ];
    if ($config['host'] === '' || $config['name'] === '' || $config['user'] === '') {
        json_response(['ok' => false, 'error' => API_TEXT['dbFieldsRequired']], 400);
    }
    return $config;
}

// Umzug-Lock: Der laufende Umzug hält flock auf der Datei; ist der flock frei,
// läuft keiner (auch nach einem abgebrochenen Prozess). Der Inhalt vermerkt
// Richtung und was der Lauf angelegt hat, damit der nächste Lauf ein
// halbfertiges Ziel wegräumen kann. Die Datei bleibt liegen (leer = sauber).
const DB_MIGRATION_RUNNING_MESSAGE = 'Datenumzug läuft';
const DB_MIGRATION_ERROR_STATUS = [
    'already_active'     => 409,
    'database_required'  => 409,
    'schema_missing'     => 409,
    'target_not_empty'   => 409,
    'migration_required' => 409,
    'archive_db_failed'  => 409,
    'not_found'          => 404,
    'connection_failed'  => 400,
    'migration_running'  => 503,
];

$DB_MIGRATION_LOCK = null;

function db_migration_error(string $error, string $message): array
{
    return ['ok' => false, 'error' => $error, 'message' => $message];
}

function db_migration_lock_path(): string
{
    return CACHE_ROOT . '/db-migration.lock';
}

function db_migration_running(): bool
{
    $fh = @fopen(db_migration_lock_path(), 'r');
    if (!$fh) {
        return false;
    }
    $free = flock($fh, LOCK_SH | LOCK_NB);
    fclose($fh);
    return !$free;
}

/**
 * Lock für einen Umzug holen und bis zur Freigabe halten. null: ein anderer
 * Umzug läuft. Sonst die Reste abgebrochener Läufe (Liste ihrer Notizen, leer
 * ohne Reste). Die Reste bleiben als 'stale' in der Notiz, bis der Lauf sie
 * weggeräumt hat; scheitert er vorher, reicht die Freigabe sie weiter.
 * Lässt sich die Sperrdatei nicht anlegen: DbMigrationException.
 */
function db_migration_lock_acquire(string $target): ?array
{
    global $DB_MIGRATION_LOCK;
    $path = db_migration_lock_path();
    ensure_dir(CACHE_ROOT);
    if (!is_writable(is_file($path) ? $path : CACHE_ROOT)) {
        throw new DbMigrationException(sprintf(DB_TEXT['lock'], le_instance_relative($path)));
    }
    $fh = updater_acquire_lock($path);
    if (!$fh) {
        return null;
    }
    $DB_MIGRATION_LOCK = $fh;
    $previous = db_migration_lock_read();
    $own = $previous;
    unset($own['stale'], $own['target']);
    // Eine Notiz, die nur die Richtung nennt, hat nichts angelegt.
    $stale = array_merge($previous['stale'] ?? [], $own ? [array_diff_key($previous, ['stale' => true])] : []);
    db_migration_lock_write(['target' => $target] + ($stale ? ['stale' => $stale] : []));
    return $stale;
}

function db_migration_lock_read(): array
{
    global $DB_MIGRATION_LOCK;
    $data = json_decode((string) stream_get_contents($DB_MIGRATION_LOCK, -1, 0), true);
    return is_array($data) ? $data : [];
}

function db_migration_lock_write(array $data): void
{
    global $DB_MIGRATION_LOCK;
    ftruncate($DB_MIGRATION_LOCK, 0);
    rewind($DB_MIGRATION_LOCK);
    fwrite($DB_MIGRATION_LOCK, $data ? (string) json_encode($data) : '');
    fflush($DB_MIGRATION_LOCK);
}

/** Im Lock festhalten, was der laufende Umzug angelegt hat. */
function db_migration_lock_note(array $data): void
{
    global $DB_MIGRATION_LOCK;
    if (!$DB_MIGRATION_LOCK) {
        return;
    }
    db_migration_lock_write(array_merge(db_migration_lock_read(), $data));
}

/** Reste, die dieser Lauf nicht wegräumen konnte, weiter vermerken. */
function db_migration_lock_keep_stale(array $remaining): void
{
    $note = db_migration_lock_read();
    unset($note['stale']);
    db_migration_lock_write($note + ($remaining ? ['stale' => $remaining] : []));
}

/** Nach dem Treiberwechsel gehört das Angelegte zum aktiven Treiber: nicht mehr aufräumen. */
function db_migration_lock_forget_created(): void
{
    $note = db_migration_lock_read();
    db_migration_lock_write(array_intersect_key($note, ['target' => true, 'stale' => true]));
}

/** Ende: nur noch nicht weggeräumte Reste bleiben in der Notiz, flock frei (Datei bleibt). */
function db_migration_lock_release(): void
{
    global $DB_MIGRATION_LOCK;
    $stale = db_migration_lock_read()['stale'] ?? [];
    db_migration_lock_write($stale ? ['stale' => $stale] : []);
    updater_release_lock($DB_MIGRATION_LOCK);
    $DB_MIGRATION_LOCK = null;
}

function require_no_db_migration(): void
{
    if (db_migration_running()) {
        json_response(db_migration_error('migration_running', DB_MIGRATION_RUNNING_MESSAGE), DB_MIGRATION_ERROR_STATUS['migration_running']);
    }
}

/** Tabellen droppen (Namen vorher mit plugin_valid_tables() prüfen). */
function db_drop_tables(PDO $pdo, array $tables): void
{
    foreach ($tables as $table) {
        $pdo->exec("DROP TABLE IF EXISTS `{$table}`");
    }
}

/** Verbindungstest; error ist ein Text aus DB_TEXT, der Text von PDO steht im Fehlerprotokoll. */
function db_test_connection(array $config): array
{
    try {
        db_connect_mysql($config)->query('SELECT 1');
        return ['ok' => true];
    } catch (Throwable $e) {
        return ['ok' => false, 'error' => db_connection_error_text($e)];
    }
}

/** Meldung zu einem Verbindungsfehler: bekannte MySQL-Fehlernummern einzeln, sonst allgemein; Rohtext ins Fehlerprotokoll. */
function db_connection_error_text(Throwable $e): string
{
    error_log('database connection failed: ' . $e->getMessage());
    $code = preg_match('/\[(\d{4})\]/', $e->getMessage(), $m) ? (int) $m[1] : 0;
    return DB_TEXT[DB_CONNECT_ERRORS[$code] ?? 'connection'];
}

/** Meldung zu $e: DbMigrationException mit ihrem Text, sonst DB_TEXT['failed'] und der Rohtext ins Fehlerprotokoll. */
function db_error_text(string $where, Throwable $e): string
{
    if ($e instanceof DbMigrationException) {
        return $e->getMessage();
    }
    error_log($where . ': ' . $e->getMessage());
    return DB_TEXT['failed'];
}

/**
 * Existiert die Tabelle (Name vorher mit plugin_table_name_valid() prüfen)?
 * Nur „Tabelle fehlt“ gilt als nein; andere Fehler (Rechte, Verbindung) werden
 * weitergeworfen, damit niemand eine vorhandene Tabelle für neu hält.
 */
function db_table_exists(PDO $pdo, string $table): bool
{
    try {
        $pdo->query("SELECT 1 FROM `{$table}` LIMIT 0");
        return true;
    } catch (PDOException $e) {
        $missing = ($e->errorInfo[0] ?? '') === '42S02' // MySQL
            || str_contains($e->getMessage(), 'no such table: ' . $table); // SQLite
        if (!$missing) {
            throw $e;
        }
        return false;
    }
}

/**
 * Führt eine Schema-Datei aus. Scheitert sie, bleibt keine der in diesem Lauf
 * angelegten Tabellen zurück: SQLite rollt die Transaktion zurück, MySQL
 * committet DDL sofort, dort werden die neuen Tabellen aus $tables gedroppt.
 */
function db_run_schema(PDO $pdo, string $driver, string $sql, array $tables): void
{
    if ($driver === DB_DRIVER_SQLITE) {
        $pdo->beginTransaction();
        try {
            $pdo->exec($sql);
            $pdo->commit();
        } catch (Throwable $e) {
            // Ein COMMIT in der Datei oder ein Abbruch durch SQLite beendet die
            // Transaktion schon; rollBack() darf den eigentlichen Fehler nicht verdecken.
            try {
                $pdo->rollBack();
            } catch (Throwable $ignored) {
            }
            throw $e;
        }
        return;
    }

    $existing = array_filter($tables, static fn (string $table): bool => db_table_exists($pdo, $table));
    try {
        $pdo->exec($sql);
    } catch (Throwable $e) {
        db_drop_tables($pdo, array_diff($tables, $existing));
        throw $e;
    }
}
