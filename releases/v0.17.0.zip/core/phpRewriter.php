<?php
declare(strict_types=1);

require_once __DIR__ . '/fileStore.php';
require_once __DIR__ . '/markup.php';
require_once __DIR__ . '/labels.php';
require_once __DIR__ . '/icons.php';

// Markierungen, über die ein Feld sein Element in der Datei findet, und was dort ersetzt wird:
// 'inner' = Innenbereich, 'background' = URL im style-Attribut, 'icon' = ganzes <svg> (core/icons.php), sonst das genannte Attribut;
// null = bei data-edit-id entscheidet der Tag (EDIT_ATTR_BY_TAG).
const EDIT_MARKERS = ['data-edit-id' => null, 'data-edit-text-id' => 'inner', 'data-edit-alt-id' => 'alt', 'data-edit-bg-id' => 'background'];
// Bei data-edit-id entscheidet der Tag, was ersetzt wird; ohne Eintrag der Innenbereich.
// <meta>: der Wert im content-Attribut (Seitenbeschreibung); <svg>: das Icon.
const EDIT_ATTR_BY_TAG = ['a' => 'href', 'img' => 'src', 'meta' => 'content', 'svg' => 'icon'];
// Hintergrundbild im style-Attribut (background-image oder background-Kurzform), roh oder mit
// Entity-Anführungszeichen; Gruppe 2 ist die URL, leer bei url() bzw. url("") (geleertes Feld).
const BACKGROUND_URL_PATTERN = '/(?<![\w-])background(?:-image)?\s*:[^;]*?url\(\s*(&quot;|&#0*39;|&apos;|[\'"]|)([^\'")]*?)\1\s*\)/i';
// Fallen beim Tausch von src weg, sonst zeigten Browser weiter das alte Bild daraus.
const IMAGE_VARIANT_ATTRS = ['srcset', 'sizes'];
// In <picture> fallen beim Tausch von src auch die <source>-Geschwister weg.
const PICTURE_TAG = 'picture';
const PICTURE_SOURCE_TAG = 'source';
// Ziel in der Datei → Feldart für die Bereinigung (sanitize_field_value); Text in einem Link
// wird zu 'linktext', der Innenbereich von PLAIN_TEXT_TAGS zu 'plain' (field_target_kind).
// Das content-Attribut von <meta> ist reiner Text wie der Seitentitel ('plain').
// Elemente, deren Inhalt der Browser als Text mit Entities liest (<title>, <textarea>): reiner Text
// ohne Auszeichnung, gelesen dekodiert, geschrieben kodiert. <script>/<style> gehören nicht dazu
// (dort gelten keine Entities); der Import markiert sie nicht.
const PLAIN_TEXT_TAGS = ['title', 'textarea'];
const EDIT_KIND_BY_TARGET = ['inner' => 'text', 'href' => 'url', 'src' => 'image', 'alt' => 'alt', 'background' => 'background', 'content' => 'plain', 'icon' => 'icon'];
// Gründe, warum ein Feld nicht zurückgeschrieben werden kann.
const REWRITE_REASONS = [
    'missing' => 'nicht gefunden',
    'duplicate' => 'mehrfach vorhanden',
    'php' => 'enthält PHP',
    'nested' => 'enthält ein anderes Feld',
    'void' => 'hat keinen Innenbereich',
    'no_file' => 'Quelldatei fehlt',
    // Beim Schreiben (plan_write_errors): Seitendatei bzw. Ablage unter content/cache.
    'file_locked' => 'Datei nicht beschreibbar',
    'store_locked' => 'Ablage nicht beschreibbar',
    'conflict' => 'inzwischen von jemand anderem geändert',
    'image_missing' => UPLOAD_TEXT['missing'],
];
// Feldarten mit einem Bild als Wert: Beim Speichern muss ein neuer Wert aus den Uploads eine vorhandene Datei sein (le_upload_missing).
const LE_REWRITE_IMAGE_KINDS = ['image', 'background'];
// Name der Seite in Meldungen zu Schreibfehlern (plan_label, write_failed_message) statt ihres Dateinamens.
const SAVE_WRITE_TEXT = [
    'page' => 'diese Seite',
];
// Zusätze zur Meldung bei Konflikten beim Speichern (save_conflict_message).
const SAVE_CONFLICT_TEXT = [
    'saved' => 'Alle anderen Änderungen sind gespeichert.',
    'reload' => 'Zum Ansehen des neuen Stands die Seite neu laden (die eigene Änderung daran geht dabei verloren).',
];

/**
 * Snapshot a source file to /content/originals/<base>.<timestamp>.<ext>
 * before any rewrite, so a half-written PHP file can be recovered.
 * $prune false: alte Snapshots räumt der Aufrufer erst nach Erfolg weg (prune_file_snapshots).
 */
function snapshot_original_file(string $file, bool $prune = true): void
{
    if (!is_file($file)) {
        return;
    }
    ensure_dir(ORIGINALS_ROOT);
    [$base, $ext] = snapshot_name_parts($file);
    $snapshot = ORIGINALS_ROOT . '/' . $base . '.' . gmdate('YmdHis') . $ext;
    @copy($file, $snapshot);
    if ($prune) {
        prune_original_snapshots($base, $ext);
    }
}

/** Name und Endung (mit Punkt) der Snapshots einer Datei. */
function snapshot_name_parts(string $file): array
{
    $info = pathinfo($file);
    return [$info['filename'] ?? basename($file), isset($info['extension']) && $info['extension'] !== '' ? '.' . $info['extension'] : ''];
}

function prune_file_snapshots(string $file): void
{
    prune_original_snapshots(...snapshot_name_parts($file));
}

function prune_original_snapshots(string $base, string $ext, int $keep = BACKUP_RETENTION): void
{
    $pattern = ORIGINALS_ROOT . '/' . $base . '.*' . $ext;
    $files = glob($pattern) ?: [];
    $stamped = [];
    foreach ($files as $f) {
        if (preg_match('/\.\d{14}' . preg_quote($ext, '/') . '$/', $f)) {
            $stamped[] = $f;
        }
    }
    if (count($stamped) <= $keep) {
        return;
    }
    rsort($stamped);
    foreach (array_slice($stamped, $keep) as $old) {
        @unlink($old);
    }
}

/**
 * Element eines Feldes im Baum: [Knotenindex, Ziel ('inner' oder Attributname)]
 * oder der Fehlerschlüssel aus REWRITE_REASONS.
 */
function find_field_element(array $doc, string $id): array|string
{
    $hits = [];
    foreach (array_keys(EDIT_MARKERS) as $marker) {
        foreach (markup_find_by_attr($doc, $marker, $id) as $index) {
            $hits[] = [$marker, $index];
        }
    }
    if ($hits === []) {
        return 'missing';
    }
    if (count($hits) > 1) {
        return 'duplicate';
    }
    [$marker, $index] = $hits[0];
    $node = $doc['nodes'][$index];
    $target = edit_marker_target($marker, $node);
    if (($target === 'inner' || $target === 'icon') && $node['self_closing']) {
        return 'void';
    }
    if ($target !== 'inner' && edit_target_problem($node, $target) === 'missing') {
        return 'missing';
    }
    return [$index, $target];
}

/**
 * Warum ein Ziel außer 'inner' am Element nicht lesbar und zurückschreibbar ist (Schlüssel aus
 * REWRITE_REASONS), sonst null – die eine Regel für Import und Speichern: Hintergrund ohne url(…)
 * im style gilt als nicht gefunden, ein PHP-Block im Attribut als 'php' (beim Icon irgendwo im
 * Start-Tag; PHP im Innenbereich prüft der Aufrufer). Ein fehlendes Attribut ist kein Hindernis
 * (markup_set_attr fügt es ein).
 */
function edit_target_problem(array $node, string $target): ?string
{
    if ($target === 'icon') {
        return $node['has_php'] || in_array(true, array_column($node['attrs'], 'has_php'), true) ? 'php' : null;
    }
    $attr = markup_attr($node, edit_target_attr($target));
    if ($target === 'background' && background_url_match($attr['value'] ?? '') === null) {
        return 'missing';
    }
    return ($attr['has_php'] ?? false) ? 'php' : null;
}

/** Was eine Markierung am Element ersetzt: 'inner', 'background' oder ein Attributname (EDIT_MARKERS). */
function edit_marker_target(string $marker, array $node): string
{
    return EDIT_MARKERS[$marker] ?? EDIT_ATTR_BY_TAG[$node['tag']] ?? 'inner';
}

/** Attribut, in dem ein Ziel außer 'inner' steht: die Hintergrund-URL im style, sonst das Ziel selbst. */
function edit_target_attr(string $target): string
{
    return $target === 'background' ? 'style' : $target;
}

/**
 * Feldart eines Feldes in der Datei – die eine Quelle für Datei, JSON und Admin: Ziel der
 * Markierung (EDIT_KIND_BY_TARGET); Text an oder in einem Link ist Linktext (ohne eigene Links).
 */
function field_target_kind(array $doc, int $index, string $target): string
{
    if ($target === 'inner' && in_array($doc['nodes'][$index]['tag'], PLAIN_TEXT_TAGS, true)) {
        return 'plain';
    }
    $kind = EDIT_KIND_BY_TARGET[$target];
    for ($i = $index; $kind === 'text' && $i !== null; $i = $doc['nodes'][$i]['parent']) {
        if ($doc['nodes'][$i]['tag'] === 'a') {
            $kind = 'linktext';
        }
    }
    return $kind;
}

/** Feldart einer ID: aus der Markierung, wenn das Feld in der Datei eindeutig steht, sonst nach der ID. */
function field_kind_in_doc(array $doc, string $id): string
{
    $found = find_field_element($doc, $id);
    return is_array($found) ? field_target_kind($doc, $found[0], $found[1]) : field_kind($id);
}

/**
 * Feldarten aller Felder eines Inhalts und aller in der Datei markierten (auch nicht importierten)
 * Felder (Pfad wie im Inhalt → Art) im Baum $doc der Seite oder Komponente $name
 * (page_source_doc, beim Import der Baum der neuen Quelle).
 */
function page_field_kinds(array $doc, string $name, array $content): array
{
    $prefix = field_id_prefix($name);
    $ids = array_map('strval', array_keys(flatten_content($content)));
    foreach (array_keys(EDIT_MARKERS) as $marker) {
        foreach (array_keys($doc['by_attr'][$marker] ?? []) as $id) {
            if (str_starts_with((string) $id, $prefix)) {
                $ids[] = substr((string) $id, strlen($prefix));
            }
        }
    }
    $kinds = [];
    foreach (array_unique($ids) as $id) {
        $kinds[$id] = field_kind_in_doc($doc, $prefix . $id);
    }
    return $kinds;
}

/**
 * Teilt einen Inhalt (altes Backup) nach dem Baum $doc der Seite oder Komponente $name
 * (page_source_doc): ['content' => Felder, deren ID dort markiert ist, 'skipped' => Zahl der
 * übrigen]. Ohne Datei ist kein Feld bekannt.
 */
function known_source_fields(array $doc, string $name, array $content): array
{
    $prefix = field_id_prefix($name);
    $known = [];
    $skipped = 0;
    foreach (flatten_content($content) as $id => $value) {
        if (find_field_element($doc, $prefix . $id) === 'missing') {
            $skipped++;
            continue;
        }
        set_nested_value($known, (string) $id, $value);
    }
    return ['content' => $known, 'skipped' => $skipped];
}

/** Treffer von BACKGROUND_URL_PATTERN im rohen style-Wert: ['url' => roh, 'start' => Offset, 'end' => Offset] oder null. */
function background_url_match(string $style): ?array
{
    if (!preg_match(BACKGROUND_URL_PATTERN, $style, $m, PREG_OFFSET_CAPTURE)) {
        return null;
    }
    return ['url' => $m[2][0], 'start' => $m[2][1], 'end' => $m[2][1] + strlen($m[2][0])];
}

/**
 * Ersetzung „nur die URL in url(…) des style-Attributs“; Anführungszeichen bleiben wie vorgefunden.
 * $url ist der bereinigte Feldwert und landet unverändert in url(…), nur fürs Attribut
 * HTML-kodiert; Leerraum, Klammern und Anführungszeichen kodiert die Bereinigung des Feldwerts.
 */
function markup_set_background_url(array $doc, int $index, string $url): array
{
    $attr = markup_attr($doc['nodes'][$index], 'style');
    $match = background_url_match($attr['value']);
    return ['start' => $attr['value_start'] + $match['start'], 'end' => $attr['value_start'] + $match['end'], 'text' => markup_attr_escape($url)];
}

/** Regel für image_variant_removals an den Browser (api/bootstrap.php), die Vorschau tauscht Bilder genauso. */
function image_variant_config(): array
{
    return ['attrs' => IMAGE_VARIANT_ATTRS, 'picture' => PICTURE_TAG, 'source' => PICTURE_SOURCE_TAG];
}

/**
 * Ersetzungen, die beim Tausch von src mitgehen: srcset/sizes am Bild und, liegt es in
 * <picture>, dessen <source>-Kinder. PHP darin ist kein Hindernis, der Block liegt
 * vollständig im entfernten Span.
 */
function image_variant_removals(array $doc, int $index): array
{
    $removals = [];
    foreach (IMAGE_VARIANT_ATTRS as $name) {
        $removal = markup_remove_attr($doc, $index, $name);
        if ($removal !== null) {
            $removals[] = $removal;
        }
    }
    $parent = $doc['nodes'][$index]['parent'];
    if ($parent !== null && $doc['nodes'][$parent]['tag'] === PICTURE_TAG) {
        foreach ($doc['nodes'][$parent]['children'] as $child) {
            if ($doc['nodes'][$child]['type'] === 'element' && $doc['nodes'][$child]['tag'] === PICTURE_SOURCE_TAG) {
                $removals[] = markup_remove_node($doc, $child);
            }
        }
    }
    return $removals;
}

/**
 * Berechnet die neue Datei für Feldwerte (ID → Wert, IDs wie in der Datei).
 * ['source' => neuer Inhalt oder null, wenn nichts zu ändern ist,
 *  'errors' => [['id' => …, 'reason' => Schlüssel aus REWRITE_REASONS]],
 *  'kinds' => [ID => Feldart aus der Markierung] für die JSON-Bereinigung]
 * Mit $checkUploads (Speichern, nicht Wiederherstellen) ist ein geändertes Bild aus den Uploads, dessen Datei fehlt,
 * ein Fehler (image_missing, le_upload_missing). Unverändert heißt wie bei Plugin-Einträgen: steht schon in einem Bildfeld
 * der Datei (auch einem anderen).
 */
function rewrite_source(string $source, array $flat, bool $checkUploads = false): array
{
    if ($checkUploads) {
        // Erst hier: Öffentliche Seiten binden diese Datei ein (core/siteEditor.php), brauchen die Uploads aber nicht.
        require_once __DIR__ . '/uploads.php';
    }
    $doc = markup_parse($source);
    $replacements = [];
    $errors = [];
    $kinds = [];
    // Bildwerte in der Datei und geänderte Bilder (ID → Wert), geprüft nach der Schleife gegen alle gespeicherten.
    $storedImages = [];
    $newImages = [];
    foreach ($flat as $id => $value) {
        if (!is_string($value)) {
            continue;
        }
        $id = (string) $id;
        $found = find_field_element($doc, $id);
        if (is_string($found)) {
            $errors[] = ['id' => $id, 'reason' => $found];
            continue;
        }
        [$index, $target] = $found;
        $problem = $target === 'inner' ? null : edit_target_problem($doc['nodes'][$index], $target);
        if (($target === 'inner' || $target === 'icon') && markup_inner_has_php($doc, $index)) {
            $problem = 'php';
        }
        if ($problem !== null) {
            $errors[] = ['id' => $id, 'reason' => $problem];
            continue;
        }
        // Die Datei bekommt denselben bereinigten Wert wie das JSON (sanitize_content_tree mit 'kinds').
        $kinds[$id] = field_target_kind($doc, $index, $target);
        $value = sanitize_field_value($kinds[$id], $value);
        // Unverändert = gleiche bereinigte Form wie in der Datei; dann bleibt die Datei, auch innere Felder.
        $stored = source_field_value($doc, $index, $target);
        $isImage = $checkUploads && in_array($kinds[$id], LE_REWRITE_IMAGE_KINDS, true);
        if ($isImage) {
            $storedImages[] = $stored;
        }
        if ($stored === $value) {
            continue;
        }
        if ($isImage) {
            $newImages[$id] = $value;
        }
        if ($target === 'background') {
            $replacements[] = markup_set_background_url($doc, $index, $value);
            continue;
        }
        if ($target === 'icon') {
            // Ohne Icon aus dem Satz (fremdes SVG, Backup davon) bleibt das SVG, wie es ist.
            if ($value !== '') {
                array_push($replacements, ...le_icon_replacements($doc, $index, $value));
            }
            continue;
        }
        if ($target !== 'inner') {
            $replacements[] = markup_set_attr($doc, $index, $target, markup_attr_escape($value));
            if ($target === 'src') {
                array_push($replacements, ...image_variant_removals($doc, $index));
            }
            continue;
        }
        if (inner_has_field($doc, $index)) {
            $errors[] = ['id' => $id, 'reason' => 'nested'];
            continue;
        }
        // Reiner Text kommt kodiert in den Rohtext (& < > als Entities), Auszeichnung so, wie sie ist.
        $replacements[] = markup_set_inner($doc, $index, $kinds[$id] === 'plain' ? text_markup_escape($value) : $value);
    }
    // Ein Fehler hier bricht das Speichern ganz ab, die Ersetzung dieser Felder wird nie geschrieben.
    foreach ($newImages as $id => $value) {
        if (le_upload_missing($value, $storedImages)) {
            $errors[] = ['id' => $id, 'reason' => 'image_missing'];
        }
    }

    return [
        'source' => $replacements === [] ? null : markup_apply($source, $replacements),
        'errors' => $errors,
        'kinds' => $kinds,
    ];
}

/** Bereinigter Wert eines Feldes in der Datei ($target wie aus find_field_element). */
function source_field_value(array $doc, int $index, string $target): string
{
    $node = $doc['nodes'][$index];
    $kind = field_target_kind($doc, $index, $target);
    $raw = match ($target) {
        'inner' => $kind === 'plain' ? html_entity_decode(markup_inner_html($doc, $index), ENT_HTML5 | ENT_QUOTES, 'UTF-8') : markup_inner_html($doc, $index),
        'background' => html_entity_decode(background_url_match(markup_attr($node, 'style')['value'])['url'], ENT_HTML5 | ENT_QUOTES, 'UTF-8'),
        'icon' => le_icon_from_svg($doc, $index),
        default => markup_attr_text($node, $target),
    };
    return sanitize_field_value($kind, $raw);
}

/** Liegt im Innenbereich ein weiteres markiertes Element (sein Marker ginge beim Ersetzen verloren)? */
function inner_has_field(array $doc, int $index): bool
{
    foreach ($doc['nodes'][$index]['children'] ?? [] as $child) {
        $node = $doc['nodes'][$child];
        foreach (array_keys(EDIT_MARKERS) as $marker) {
            if ($node['type'] === 'element' && markup_attr($node, $marker) !== null) {
                return true;
            }
        }
        if (inner_has_field($doc, $child)) {
            return true;
        }
    }
    return false;
}

/** IDs in der Datei tragen bei Komponenten (header/footer) den Namen als Präfix. */
function field_id_prefix(string $name): string
{
    return isset(shared_components()[$name]) ? $name . '.' : '';
}

/**
 * Komponente, deren Präfix die ID trägt (header.…, footer.…), sonst null. Das Präfix ordnet ein
 * Feld der Komponente zu (getPage, savePage); Seiten-IDs tragen deshalb keins (Import).
 */
function id_component(string $id): ?string
{
    $first = strstr($id, '.', true);
    return $first !== false && isset(shared_components()[$first]) ? $first : null;
}

/**
 * Altbestand angleichen (api/getPage.php, api/restore.php; $doc aus page_source_doc): Hat ein
 * Textfeld denselben Klartext wie die Datei, aber eine andere Form (alter Klartext mit &, <br>
 * ohne Fettung …), gilt das bereinigte Fragment der Datei – so verliert der erste Save nach
 * dem Update keine Fettung. $plainOnly (Restore): nur Werte ohne Auszeichnung angleichen, ein
 * Backup mit anderer Fettung oder anderem Link stellt diese wieder her; eines, das sich nur durch
 * fehlende Attribute unterscheidet (Stand vor text_markup_attrs), behält die Klassen der Datei.
 */
function align_text_with_source(array $doc, string $name, array $content, bool $plainOnly = false): array
{
    $prefix = field_id_prefix($name);
    foreach (flatten_content($content) as $id => $value) {
        if (!is_string($value)) {
            continue;
        }
        $found = find_field_element($doc, $prefix . $id);
        if (is_string($found) || $found[1] !== 'inner' || markup_inner_has_php($doc, $found[0])) {
            continue;
        }
        $fromFile = source_field_value($doc, $found[0], 'inner');
        if ($fromFile === $value || text_markup_plain($fromFile) !== text_markup_plain($value)) {
            continue;
        }
        if (!$plainOnly || !text_markup_has_formatting($value) || text_markup_without_attrs($fromFile) === $value) {
            set_nested_value($content, (string) $id, $fromFile);
        }
    }
    return $content;
}

/**
 * Inhalt einer Seite für den Seiten-Editor (api/getPage.php) und als Stand jetzt beim Speichern
 * (merge_save_content): ['content' => Felder der Seite samt Komponenten, 'fieldKinds' => Pfad →
 * Feldart, 'docs' => Name → Baum der Quelldatei für die Feldnamen]. Altbestand ohne Auszeichnung
 * bekommt die Form der Datei (align_text_with_source); Seitenfelder mit Komponenten-Präfix (ältere
 * Importe) stehen neben den Feldern der Komponente und gehen vor (split_page_content).
 */
function page_editor_content(string $page): array
{
    $docs = [$page => page_source_doc($page)];
    $content = align_text_with_source($docs[$page], $page, load_page_content($page));
    $fieldKinds = page_field_kinds($docs[$page], $page, $content);
    foreach (array_keys(shared_components()) as $componentName) {
        $componentContent = load_component_content($componentName);
        if ($componentContent !== null) {
            $docs[$componentName] = page_source_doc($componentName);
            $componentContent = align_text_with_source($docs[$componentName], $componentName, $componentContent);
            foreach (page_field_kinds($docs[$componentName], $componentName, $componentContent) as $id => $kind) {
                $fieldKinds[$componentName . '.' . $id] ??= $kind;
            }
            $content[$componentName] = array_replace_recursive($componentContent, is_array($content[$componentName] ?? null) ? $content[$componentName] : []);
        }
    }
    return ['content' => $content, 'fieldKinds' => $fieldKinds, 'docs' => $docs];
}

/**
 * Speichern gegen den Stand beim Laden (api/savePage.php): $content = Inhalt im Editor, $base =
 * derselbe Inhalt beim Laden (getPage), $current = Stand jetzt (page_editor_content), alles samt
 * Komponenten. Je Feld: gleicht der Editor-Wert $base, hat der Editor es nicht geändert und es gilt
 * der Stand jetzt (eine länger offene Seite überschreibt nichts Neueres). Ein geändertes Feld wird
 * übernommen, wenn es seit dem Laden gleich blieb (oder schon den neuen Wert hat), sonst hat es
 * jemand anderes geändert: Es bleibt, wie es ist, und kommt in 'conflicts'.
 * Liefert ['content' => Inhalt zum Speichern, 'saved' => IDs übernommener Änderungen, 'conflicts' => IDs].
 */
function merge_save_content(array $current, array $content, array $base): array
{
    $merged = flatten_content($current);
    $loaded = flatten_content($base);
    $saved = [];
    $conflicts = [];
    foreach (flatten_content($content) as $id => $value) {
        $id = (string) $id;
        $before = $loaded[$id] ?? null;
        $now = $merged[$id] ?? null;
        if ($value === $before || $value === $now) {
            continue;
        }
        if ($now === $before) {
            $merged[$id] = $value;
            $saved[] = $id;
        } else {
            $conflicts[] = $id;
        }
    }
    return ['content' => unflatten_content($merged), 'saved' => $saved, 'conflicts' => $conflicts];
}

/** Konflikte als Felder wie in der 422-Antwort ([['id', 'label', 'reason']]), Namen wie im Editor ($docs aus page_editor_content). */
function save_conflict_fields(array $ids, array $docs): array
{
    $labels = build_labels_for_content(unflatten_content(array_fill_keys($ids, '')), $docs);
    return array_map(static fn (string $id): array => ['id' => $id, 'label' => $labels[$id], 'reason' => REWRITE_REASONS['conflict']], $ids);
}

/** Meldung zu Konflikten beim Speichern; $saved: die übrigen Änderungen sind gespeichert. */
function save_conflict_message(array $fields, bool $saved): string
{
    return rewrite_error_message($fields) . ($saved ? ' ' . SAVE_CONFLICT_TEXT['saved'] : '') . ' ' . SAVE_CONFLICT_TEXT['reload'];
}

/**
 * Plan für das Zurückschreiben einer Seite oder Komponente (header/footer):
 * ['file' => Pfad|null, 'source' => neuer Inhalt|null, 'errors' => [['id', 'label', 'reason' (deutsch)]],
 *  'kinds' => [Pfad wie im Inhalt => Feldart] für save_page_content].
 * Schreibt nichts; das macht write_source_rewrite() nach der Fehlerprüfung. $checkUploads wie bei rewrite_source.
 */
function plan_source_rewrite(string $name, array $content, bool $checkUploads = false): array
{
    $file = page_source_path($name);
    if ($file === null) {
        return ['file' => null, 'source' => null, 'errors' => [['id' => $name, 'label' => $name, 'reason' => REWRITE_REASONS['no_file']]], 'kinds' => []];
    }
    $prefix = field_id_prefix($name);
    $flat = [];
    foreach (flatten_content($content) as $id => $value) {
        $flat[$prefix . $id] = $value;
    }
    $result = rewrite_source((string) file_get_contents($file), $flat, $checkUploads);
    $errors = [];
    $table = $result['errors'] === [] ? [] : page_label_table($name, page_source_doc($name));
    foreach ($result['errors'] as $error) {
        $errors[] = ['id' => $error['id'], 'label' => label_for_id($table, $error['id'], $name), 'reason' => REWRITE_REASONS[$error['reason']]];
    }

    $kinds = [];
    foreach ($result['kinds'] as $id => $kind) {
        $kinds[substr((string) $id, strlen($prefix))] = $kind;
    }

    return ['file' => $file, 'source' => $result['source'], 'errors' => $errors, 'kinds' => $kinds];
}

/** Schreibt einen fehlerfreien Plan atomar (mit Snapshot); nichts zu tun, wenn sich nichts ändert. */
function write_source_rewrite(array $plan): void
{
    if ($plan['source'] === null) {
        return;
    }
    snapshot_original_file($plan['file'], false);
    atomic_write($plan['file'], $plan['source']);
}

/**
 * Teilt den Inhalt einer Seite samt Komponenten (api/savePage.php) in Name → Inhalt. Unter dem
 * Schlüssel einer Komponente stehen ihre Felder; Felder, die in der Seitendatei markiert sind
 * (Seiten-IDs mit Komponenten-Präfix aus älteren Importen, z. B. header.eigen), gehören der Seite,
 * so fällt beim Speichern kein Seitenfeld aus ihrem JSON. Gibt es eine solche ID auch in der
 * Komponente, behält die Komponente ihren gespeicherten Wert. Eine Komponente ohne eigene Felder
 * bekommt keinen Plan. Gegenstück: page_editor_content legt diese Seitenfelder zu den Feldern der
 * Komponente.
 */
function split_page_content(string $page, array $content): array
{
    $pageDoc = null;
    $plans = [];
    foreach (array_keys(shared_components()) as $name) {
        if (!isset($content[$name]) || !is_array($content[$name])) {
            continue;
        }
        $component = [];
        $own = [];
        $stored = null;
        foreach (flatten_content($content[$name]) as $id => $value) {
            $id = (string) $id;
            $pageDoc ??= page_source_doc($page);
            if (find_field_element($pageDoc, $name . '.' . $id) === 'missing') {
                $component[$id] = $value;
                continue;
            }
            $own[$id] = $value;
            $stored ??= flatten_content(load_component_content($name) ?? []);
            if (array_key_exists($id, $stored)) {
                $component[$id] = $stored[$id];
            }
        }
        // Nur mit Feldern der Komponente ein Plan: sonst bliebe ihr JSON leer bzw. scheiterte eine
        // Site ohne Komponenten-Datei an „Quelldatei fehlt“, obwohl alle Felder der Seite gehören.
        if (array_diff_key($component, $own) !== []) {
            $plans[$name] = unflatten_content($component);
        }
        if ($own === []) {
            unset($content[$name]);
        } else {
            $content[$name] = unflatten_content($own);
        }
    }
    $plans[$page] = $content;
    return $plans;
}

/**
 * Schreibt fehlerfreie Pläne einer Seite samt Komponenten (Name → plan_source_rewrite plus
 * 'content') als ein Speichern: erst alle JSON samt Backups (save_page_group), dann alle Dateien;
 * „zuletzt gespeichert“ rückt vor, wenn sich etwas geändert hat. Ganz oder gar nicht auch beim
 * Schreiben: Lässt sich eine Datei oder Ablage nicht schreiben, antwortet es vorher mit 422 wie
 * bei Feldfehlern (plan_write_errors). Scheitert danach doch ein Schreiben (Platte voll), stellt
 * plans_restore_point den Stand davor her, bevor der Request endet; alte Backups und Snapshots räumt erst ein
 * gelungenes Speichern weg. Der Aufrufer hält lock_pages.
 */
function write_page_plans(string $page, array $plans, bool $restored = false): void
{
    $errors = plan_write_errors($plans);
    if ($errors !== []) {
        json_response(['ok' => false, 'error' => write_failed_message(array_column($errors, 'label')), 'fields' => $errors], 422);
    }
    $restore = plans_restore_point($plans);
    $done = false;
    register_shutdown_function(static function () use (&$done, $restore): void {
        if (!$done) {
            $restore();
        }
    });
    $changed = save_page_group($page, $plans, $restored);
    foreach ($plans as $plan) {
        $changed = $changed || $plan['source'] !== null;
        write_source_rewrite($plan);
    }
    $done = true;
    foreach ($plans as $name => $plan) {
        prune_backups((string) $name);
        if ($plan['source'] !== null) {
            prune_file_snapshots($plan['file']);
        }
    }
    if ($changed) {
        mark_page_updated($page);
    }
}

/** Name eines Plans in Meldungen: Kopf-/Fußzeile (COMPONENT_LABELS), sonst „diese Seite“, nie eine Datei. */
function plan_label(string $name): string
{
    return COMPONENT_LABELS[$name] ?? SAVE_WRITE_TEXT['page'];
}

/** Lässt sich die Datei anlegen bzw. ersetzen (Ordner und eine vorhandene Datei beschreibbar)? */
function path_writable(string $path): bool
{
    clearstatcache(true, $path);
    return is_writable(dirname($path)) && (!file_exists($path) || is_writable($path));
}

/**
 * Fehler wie aus plan_source_rewrite für alles, was das Speichern der Pläne schreiben würde und
 * nicht kann: geänderte Quelldatei (schreibgeschützt oder Ordner ohne Schreibrecht), JSON und
 * Backup-Ordner unter content/cache. Eine Komponente, an der sich nichts ändert (save_page_content
 * schreibt sie nicht), zählt nicht. Leer, wenn alles geht.
 */
function plan_write_errors(array $plans): array
{
    $errors = [];
    foreach ($plans as $name => $plan) {
        $name = (string) $name;
        $json = page_json_path($name);
        $unchanged = isset(COMPONENT_LABELS[$name]) && $plan['source'] === null && is_file($json)
            && file_get_contents($json) === page_json_text(sanitize_content_tree($plan['content'], $plan['kinds']), le_plan_source_hash($plan));
        $reason = match (true) {
            $unchanged => null,
            $plan['source'] !== null && !path_writable($plan['file']) => REWRITE_REASONS['file_locked'],
            !path_writable($json), !is_writable(BACKUPS_ROOT . '/' . safe_page_name($name)) => REWRITE_REASONS['store_locked'],
            default => null,
        };
        if ($reason !== null) {
            $errors[] = ['id' => $name, 'label' => plan_label($name), 'reason' => $reason];
        }
    }
    return $errors;
}

/**
 * Stand vor dem Schreiben der Pläne: Inhalt der JSON und der geänderten Quelldateien, Dateien in
 * den Backup-Ordnern und unter ORIGINALS_ROOT. Liefert die Funktion, die ihn wiederherstellt
 * (Dateien zurück, neu angelegte Backups, Kurzinfos und Snapshots weg). Unter ORIGINALS_ROOT nur
 * die Snapshots der eigenen Quelldateien: Snapshots einer gleichzeitig gespeicherten anderen Seite bleiben.
 */
function plans_restore_point(array $plans): Closure
{
    $files = [];
    $dirs = [];
    $snapshots = [];
    foreach ($plans as $name => $plan) {
        $json = page_json_path((string) $name);
        $files[$json] = is_file($json) ? (string) file_get_contents($json) : null;
        if ($plan['source'] !== null) {
            $files[$plan['file']] = (string) file_get_contents($plan['file']);
            [$base, $ext] = snapshot_name_parts($plan['file']);
            $snapshots[] = '/^' . preg_quote($base, '/') . '\.\d{14}' . preg_quote($ext, '/') . '$/';
        }
        $dir = BACKUPS_ROOT . '/' . safe_page_name((string) $name);
        $dirs[$dir] = dir_entries($dir);
    }
    $originals = dir_entries(ORIGINALS_ROOT);
    return static function () use ($files, $dirs, $originals, $snapshots): void {
        foreach ($files as $file => $content) {
            if ($content === null) {
                @unlink($file);
            } elseif (@file_get_contents($file) !== $content) {
                // Atomar wie beim Speichern (Rechte der Datei bleiben): Scheitert es, bleibt die neue Fassung ganz statt halb.
                try {
                    write_file_atomic($file, $content);
                } catch (RuntimeException $e) {
                    error_log('save rollback: ' . $e->getMessage());
                }
            }
            forget_compiled_file($file);
        }
        foreach ($dirs as $dir => $before) {
            foreach (array_diff(dir_entries($dir), $before) as $added) {
                @unlink($dir . '/' . $added);
            }
        }
        foreach (array_diff(dir_entries(ORIGINALS_ROOT), $originals) as $added) {
            foreach ($snapshots as $pattern) {
                if (preg_match($pattern, $added) === 1) {
                    @unlink(ORIGINALS_ROOT . '/' . $added);
                    break;
                }
            }
        }
    };
}

/** Meldung für die 422-Antwort: „‚Name‘ (Grund) konnte nicht gespeichert werden.“ */
function rewrite_error_message(array $errors): string
{
    $names = array_map(static fn (array $e): string => '‚' . $e['label'] . '‘ (' . $e['reason'] . ')', $errors);
    return implode(', ', $names) . (count($errors) === 1 ? ' konnte' : ' konnten') . ' nicht gespeichert werden.';
}
