<?php
declare(strict_types=1);

// Bildoptimierung beim Upload (api/upload.php): JPG und PNG werden auf höchstens LE_IMAGE_MAX_WIDTH Pixel Breite
// verkleinert und als WebP gespeichert, das Original nicht aufbewahrt. Alles andere (WebP, SVG) bleibt, wie es ist.
// Ohne GD mit WebP, bei zu wenig Speicher oder einem Fehler von GD wird das Bild unverändert gespeichert.

require_once __DIR__ . '/utils.php';

const LE_IMAGE_MAX_WIDTH = 1920;
const LE_IMAGE_WEBP_QUALITY = 82;
// Speicher je Pixel einer Bitmap in GD (4 Bytes plus Zeilenzeiger und Puffer der Decoder), für die Schätzung vor dem Laden.
const LE_IMAGE_BYTES_PER_PIXEL = 5;
// Feste Obergrenze, die immer gilt, auch ohne memory_limit (-1): Größere Bilder werden unverändert gespeichert.
const LE_IMAGE_MAX_PIXELS = 50_000_000;
// Endungen, die optimiert werden, mit dem Bildtyp, den getimagesize dazu liefern muss.
const LE_IMAGE_OPTIMIZE_TYPES = ['jpg' => IMAGETYPE_JPEG, 'jpeg' => IMAGETYPE_JPEG, 'png' => IMAGETYPE_PNG];

/** Ob GD WebP schreiben kann; sonst werden Bilder unverändert gespeichert (Systemprüfung: gd). */
function le_image_webp_supported(): bool
{
    return function_exists('imagewebp') && function_exists('gd_info') && !empty(gd_info()['WebP Support']);
}

/**
 * WebP-Fassung des hochgeladenen Bildes $path mit der Endung $extension, verkleinert auf LE_IMAGE_MAX_WIDTH und nach
 * der EXIF-Orientierung gedreht (WebP verwirft EXIF; ohne exif-Erweiterung dreht nichts). null heißt: unverändert
 * speichern, weil es kein JPG/PNG ist, GD kein WebP kann, das Bild mehr als LE_IMAGE_MAX_PIXELS hat oder der Speicher
 * nach getimagesize nicht reicht, GD scheitert
 * (Eintrag im Fehlerprotokoll), ein animiertes PNG oder, ohne Verkleinern, das WebP nicht kleiner wäre.
 * $webp und $memoryLimit (Bytes, null: memory_limit) vorgeben nur für Tests.
 */
function le_image_optimized(string $path, string $extension, ?bool $webp = null, ?int $memoryLimit = null): ?string
{
    $type = LE_IMAGE_OPTIMIZE_TYPES[strtolower($extension)] ?? null;
    if ($type === null || !($webp ?? le_image_webp_supported())) {
        return null;
    }
    $info = @getimagesize($path);
    if ($info === false || $info[2] !== $type || $info[0] < 1 || $info[1] < 1) {
        error_log('image optimize: cannot read ' . basename($path));
        return null;
    }
    // Animiertes PNG: GD läse nur das erste Bild.
    if ($type === IMAGETYPE_PNG && le_image_png_animated($path)) {
        return null;
    }
    [$width, $height] = $info;
    if ($width * $height > LE_IMAGE_MAX_PIXELS) {
        error_log('image optimize: ' . $width . 'x' . $height . ' above ' . LE_IMAGE_MAX_PIXELS . ' pixels, stored unchanged');
        return null;
    }
    $orientation = $type === IMAGETYPE_JPEG ? le_image_exif_orientation($path) : 1;
    $turned = $orientation >= 5;
    // Verkleinert wird nach der Breite, wie das Bild gedreht erscheint; gedreht wird erst danach (kleineres Bild).
    $scale = min(1, LE_IMAGE_MAX_WIDTH / ($turned ? $height : $width));
    $newWidth = max(1, (int) round($width * $scale));
    $newHeight = max(1, (int) round($height * $scale));
    $resize = $scale < 1;
    $rotate = in_array($orientation, [3, 5, 6, 7, 8], true);

    $limit = $memoryLimit ?? ini_size_bytes((string) ini_get('memory_limit'));
    $pixels = $width * $height + $newWidth * $newHeight * ((int) $resize + (int) $rotate);
    if ($limit !== null && memory_get_usage() + $pixels * LE_IMAGE_BYTES_PER_PIXEL > $limit) {
        error_log('image optimize: ' . $width . 'x' . $height . ' too large for memory_limit, stored unchanged');
        return null;
    }

    try {
        $image = $type === IMAGETYPE_JPEG ? @imagecreatefromjpeg($path) : @imagecreatefrompng($path);
        if ($image === false) {
            throw new RuntimeException('cannot decode');
        }
        if (!imageistruecolor($image) && !imagepalettetotruecolor($image)) {
            throw new RuntimeException('cannot convert palette');
        }
        if ($resize) {
            $image = le_image_resampled($image, $newWidth, $newHeight);
        }
        $image = le_image_oriented($image, $orientation);
        imagesavealpha($image, true);
        ob_start();
        $written = imagewebp($image, null, LE_IMAGE_WEBP_QUALITY);
        $data = (string) ob_get_clean();
        if (!$written || $data === '') {
            throw new RuntimeException('cannot encode webp');
        }
    } catch (Throwable $e) {
        error_log('image optimize failed for ' . basename($path) . ': ' . $e->getMessage());
        return null;
    }

    return $resize || strlen($data) < (int) @filesize($path) ? $data : null;
}

/** $image auf $width × $height verkleinert, mit Alphakanal (transparente PNG bleiben transparent). */
function le_image_resampled(GdImage $image, int $width, int $height): GdImage
{
    $target = imagecreatetruecolor($width, $height);
    if ($target === false) {
        throw new RuntimeException('cannot allocate');
    }
    imagealphablending($target, false);
    imagesavealpha($target, true);
    imagefill($target, 0, 0, imagecolorallocatealpha($target, 0, 0, 0, 127));
    if (!imagecopyresampled($target, $image, 0, 0, 0, 0, $width, $height, imagesx($image), imagesy($image))) {
        throw new RuntimeException('cannot resample');
    }

    return $target;
}

/** EXIF-Orientierung 1–8 eines JPG; 1 ohne exif-Erweiterung, ohne Angabe oder bei einem Lesefehler. */
function le_image_exif_orientation(string $path): int
{
    if (!function_exists('exif_read_data')) {
        return 1;
    }
    $exif = @exif_read_data($path);
    $orientation = is_array($exif) ? (int) ($exif['Orientation'] ?? 1) : 1;

    return $orientation >= 1 && $orientation <= 8 ? $orientation : 1;
}

/** $image so gespiegelt und gedreht, wie die EXIF-Orientierung es verlangt (imagerotate dreht gegen den Uhrzeigersinn). */
function le_image_oriented(GdImage $image, int $orientation): GdImage
{
    if (in_array($orientation, [2, 7], true)) {
        imageflip($image, IMG_FLIP_HORIZONTAL);
    }
    if (in_array($orientation, [4, 5], true)) {
        imageflip($image, IMG_FLIP_VERTICAL);
    }
    $angle = [3 => 180, 5 => -90, 6 => -90, 7 => -90, 8 => 90][$orientation] ?? 0;
    if ($angle === 0) {
        return $image;
    }
    $rotated = imagerotate($image, $angle, 0);
    if ($rotated === false) {
        throw new RuntimeException('cannot rotate');
    }

    return $rotated;
}

/** Ob das PNG $path animiert ist (APNG: acTL-Block vor den Bilddaten). */
function le_image_png_animated(string $path): bool
{
    $head = (string) @file_get_contents($path, false, null, 0, 4096);
    $actl = strpos($head, 'acTL');
    $idat = strpos($head, 'IDAT');

    return $actl !== false && ($idat === false || $actl < $idat);
}

/** Schreibt das WebP atomar, lesbar wie eine mit move_uploaded_file abgelegte Datei (write_file_atomic). */
function le_image_write_webp(string $path, string $content): bool
{
    try {
        write_file_atomic($path, $content);
    } catch (RuntimeException $e) {
        error_log('image write failed: ' . $e->getMessage());
        return false;
    }

    return true;
}
