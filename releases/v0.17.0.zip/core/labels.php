<?php
declare(strict_types=1);

require_once __DIR__ . '/fileStore.php';
require_once __DIR__ . '/markup.php';
require_once __DIR__ . '/phpRewriter.php';

const LABELS_ROOT = CONTENT_ROOT . '/labels';
// Feldnamen aus Überschriften („Über uns – Absatz 2“): Überschrift gekürzt, Arten einheitlich benannt.
// Die Feldarten (field_kind, EDIT_KIND_BY_TARGET) sind zugleich Schlüssel.
const LABEL_HEADING_MAX = 40;
// Wörter, die in Abschnitten von Kopf-/Fußzeile neben ihrem Namen nichts unterscheiden (site-header,
// page_footer); sie fallen mit dem Namen der Komponente aus dem Feldnamen (label_from_id).
const LABEL_COMPONENT_FILLER = ['site', 'page'];
// 'description' ist die Seitenbeschreibung (<meta name="description">, IMPORT_META_FIELDS),
// 'pageTitle' der Seitentitel (<title>, IMPORT_TITLE_KIND).
const LABEL_KINDS = ['heading' => 'Überschrift', 'paragraph' => 'Absatz', 'item' => 'Listenpunkt', 'text' => 'Text', 'url' => 'Link', 'image' => 'Bild', 'alt' => 'Alt-Text', 'background' => 'Hintergrundbild', 'icon' => 'Icon', 'description' => 'Seitenbeschreibung', 'pageTitle' => 'Seitentitel'];

function labels_path(string $page): string
{
    return LABELS_ROOT . '/' . safe_page_name($page) . '.json';
}

function load_label_overrides(string $page): array
{
    $path = labels_path($page);
    if (!is_file($path)) {
        return [];
    }
    $data = json_decode((string) file_get_contents($path), true);
    return is_array($data) ? $data : [];
}

function label_humanize(string $value): string
{
    $value = preg_replace('/[._]+/', ' ', $value) ?? $value;
    $words = preg_split('/\s+/', trim($value)) ?: [];
    $words = array_map(static function (string $w): string {
        if ($w === '') return '';
        return mb_strtoupper(mb_substr($w, 0, 1)) . mb_substr($w, 1);
    }, $words);
    return implode(' ', $words);
}

/** Feldname einer ID ohne Nummer: hero.url_2 → url. */
function edit_field_from_id(string $id): string
{
    $field = substr(strrchr('.' . $id, '.'), 1);
    return preg_replace('/_\d+$/', '', $field) ?? $field;
}

/** Name aus der ID; $inComponent: die ID gehört Kopf- oder Fußzeile (nicht einer Seite mit Präfix-ID aus älteren Importen). */
function label_from_id(string $id, bool $inComponent = true): string
{
    $parts = explode('.', $id);
    if (count($parts) < 2) {
        return label_humanize($id);
    }
    $last = array_pop($parts);
    $group = implode('.', $parts);
    $field = edit_field_from_id($id);
    // Nummer hinter dem Feldnamen (text_2 → 2), sonst leer.
    $fieldIndex = substr($last, strlen($field) + 1);

    // Ein Wort je Art (field_kind), dasselbe wie in Namen aus Überschriften; title ist Text,
    // heißt aber Überschrift, andere Textfelder heißen wie ihr Feldname.
    $kind = field_kind($id);
    $fieldLabel = match (true) {
        $field === 'title' => LABEL_KINDS['heading'],
        $kind !== 'text' || $field === 'text' => LABEL_KINDS[$kind],
        default => label_humanize($field),
    };

    // Felder von Kopf- und Fußzeile heißen nach ihr („Kopfzeile Logo: Alt-Text“), nicht nach dem Präfix.
    // In ihren Abschnitten fallen nur ihr Name und LABEL_COMPONENT_FILLER weg (header_logo → „Logo“,
    // site_header → „Kopfzeile: Text“); bleibt nichts, steht eine Nummer beim Feld („Kopfzeile: Text 2“).
    $component = $inComponent ? id_component($id) : null;
    $rest = $group;
    if ($component !== null) {
        $drop = [$component, ...LABEL_COMPONENT_FILLER];
        $words = preg_split('/[._]+/', substr($group, strlen($component)), -1, PREG_SPLIT_NO_EMPTY) ?: [];
        $rest = implode(' ', array_filter($words, static fn (string $word): bool => !in_array($word, $drop, true)));
    }
    $groupLabel = trim(($component === null ? '' : COMPONENT_LABELS[$component]) . ' ' . label_humanize($rest));

    if ($fieldIndex !== '' && $component !== null && $rest === '') {
        $fieldLabel .= ' ' . $fieldIndex;
    } elseif ($fieldIndex !== '') {
        $groupLabel = trim($groupLabel . ' ' . $fieldIndex);
    }

    if ($groupLabel === '') {
        return $fieldLabel;
    }
    return $groupLabel . ': ' . $fieldLabel;
}

/** Überschriftstext für Feldnamen: ohne Tags, Leerraum zusammengezogen, gekürzt. */
function label_heading_text(string $html): string
{
    return text_excerpt(html_entity_decode(strip_tags($html), ENT_HTML5 | ENT_QUOTES, 'UTF-8'), LABEL_HEADING_MAX);
}

/** „<Überschrift> – <Art>[ Nr]“, $kind aus LABEL_KINDS, Nummer 0 = ohne. */
function label_for_heading(string $heading, string $kind, int $number = 0): string
{
    return $heading . ' – ' . LABEL_KINDS[$kind] . ($number > 0 ? ' ' . $number : '');
}

/** Baum der Quelldatei einer Seite oder Komponente; ohne Datei ein leerer Baum (kein Feld gefunden). */
function page_source_doc(string $name): array
{
    $file = page_source_path($name);
    return markup_parse($file === null ? '' : (string) file_get_contents($file));
}

/**
 * data-edit-label aus dem Baum der Seitendatei (page_source_doc; die Datei ist die Quelle).
 * Gilt für die data-edit-id des Elements; Linktext, Alt-Text und Hintergrund desselben
 * Elements (die übrigen EDIT_MARKERS) erben den Namen mit Zusatz ihrer Art, ein reines
 * Hintergrund-Element trägt ihn direkt.
 */
function file_labels(array $doc): array
{
    $labels = [];
    foreach ($doc['nodes'] as $node) {
        if ($node['type'] !== 'element' || markup_attr($node, 'data-edit-label') === null) {
            continue;
        }
        $label = markup_attr_text($node, 'data-edit-label');
        $id = markup_attr($node, 'data-edit-id')['value'] ?? '';
        if ($id !== '') {
            $labels[$id] = $label;
        }
        foreach (EDIT_MARKERS as $marker => $target) {
            $subId = $target === null ? '' : markup_attr($node, $marker)['value'] ?? '';
            if ($subId !== '') {
                $labels[$subId] = $id === '' ? $label : $label . ' (' . LABEL_KINDS[EDIT_KIND_BY_TARGET[$target]] . ')';
            }
        }
    }
    return $labels;
}

/** Bekannte Namen einer Seite oder Komponente ($doc: Baum ihrer Datei): Overrides vor Datei. IDs wie in der Datei. */
function page_label_table(string $name, array $doc): array
{
    return load_label_overrides($name) + file_labels($doc);
}

/**
 * Name eines Feldes aus einer Tabelle von page_label_table(), sonst aus der ID. $owner: Seite oder
 * Komponente, deren Datei das Feld trägt (null = nach der ID); nur Felder einer Komponente heißen nach ihr.
 */
function label_for_id(array $table, string $id, ?string $owner = null): string
{
    return $table[$id] ?? label_from_id($id, $owner === null || id_component($id) === $owner);
}

/** Namen der Felder eines Inhalts; $docs: Seite bzw. Komponente → Baum ihrer Datei (schon gelesen). */
function build_labels_for_content(array $content, array $docs): array
{
    $table = [];
    foreach ($docs as $name => $doc) {
        $table += page_label_table((string) $name, $doc);
    }

    // Seitenfelder mit Komponenten-Präfix (ältere Importe) stehen in der Datei der Seite.
    $page = array_key_first(array_diff_key($docs, shared_components()));
    $labels = [];
    foreach (array_keys(flatten_content($content)) as $id) {
        $id = (string) $id;
        $owner = $page !== null && id_component($id) !== null && find_field_element($docs[$page], $id) !== 'missing' ? (string) $page : null;
        $labels[$id] = label_for_id($table, $id, $owner);
    }
    return $labels;
}
