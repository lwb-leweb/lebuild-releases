<?php
declare(strict_types=1);

// Zerlegt HTML- und PHP-Seitendateien byte-genau in einen leichten Baum.
// PHP-Blöcke (von „<?“ bis zum schließenden Fragezeichen-Klammer-Paar)
// bleiben undurchsichtig, auch in Tags und Attributen. Jeder Knoten kennt seine Byte-Spans; Änderungen werden als
// Ersetzungen gesammelt und mit markup_apply() in einem Rutsch angewendet,
// der Rest der Datei bleibt Byte für Byte gleich. Werte sind roh (wie in der
// Datei); Encoding ist Sache des Aufrufers.
// Grenzen: Ein PHP-Block endet beim ersten schließenden Tag, auch wenn es in
// einem PHP-String steht (wie die frühere Regex); dahinter stimmen die
// Positionen dann nicht mehr. In Rohtext-Elementen (MARKUP_RAW_TEXT_ELEMENTS)
// werden PHP-Blöcke nicht als eigene Knoten erkannt; markup_inner_has_php()
// sucht dort im Text nach „<?“.

// Elemente ohne Innenbereich und ohne End-Tag.
const MARKUP_VOID_ELEMENTS = ['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'];
// Inhalt wird nicht als Markup gelesen, sondern bis zum passenden End-Tag als Text.
const MARKUP_RAW_TEXT_ELEMENTS = ['script', 'style', 'textarea', 'title'];
// Offenes Element → Start-Tags, die es ohne End-Tag schließen (HTML-Spec, Alltagsfälle).
const MARKUP_IMPLICIT_CLOSE = [
    'p' => ['address', 'article', 'aside', 'blockquote', 'details', 'div', 'dl', 'fieldset', 'figcaption', 'figure', 'footer', 'form', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'header', 'hr', 'main', 'nav', 'ol', 'p', 'pre', 'section', 'table', 'ul'],
    'li' => ['li'],
    'dt' => ['dt', 'dd'],
    'dd' => ['dt', 'dd'],
    'tr' => ['tr', 'tbody', 'tfoot'],
    'td' => ['td', 'th', 'tr', 'tbody', 'tfoot'],
    'th' => ['td', 'th', 'tr', 'tbody', 'tfoot'],
    'option' => ['option', 'optgroup'],
];

/**
 * Baum einer Datei: ['source' => string, 'nodes' => Knoten[], 'roots' => int[], 'by_attr' => Index].
 * Knoten: type (element|text|php|comment|declaration), start, end, parent.
 * Elemente zusätzlich: tag (klein), attrs, tag_end (nach dem Start-Tag),
 * inner_start, inner_end, self_closing, has_php (PHP-Block an Attribut-Position
 * im Start-Tag), attrs_end (Einfügestelle für neue Attribute: Ende des letzten
 * Attributs vor dem ersten PHP-Block im Tag, sonst Ende des Tag-Namens – nie in
 * oder hinter einem PHP-Block, z. B. einer Bedingung), children (Indizes).
 * Attribut: name (klein), value (roh, null ohne Wert), quote ('"', "'" oder ''),
 * has_php (Wert enthält einen PHP-Block), start/end (Name bis Wertende),
 * ws_start (Leerraum davor, zum Entfernen), value_start/value_end (nur der Wert, zum Ersetzen).
 * by_attr: Name → roher Wert → Element-Indizes (erstes Vorkommen je Element), für markup_find_by_attr().
 */
function markup_parse(string $source): array
{
    $nodes = [];
    $roots = [];
    $byAttr = [];
    $stack = [];
    $len = strlen($source);
    $pos = 0;
    $textStart = 0;

    $add = static function (array $node) use (&$nodes, &$roots, &$stack): int {
        $index = count($nodes);
        $parent = $stack === [] ? null : $stack[count($stack) - 1];
        $node['parent'] = $parent;
        $nodes[$index] = $node;
        if ($parent === null) {
            $roots[] = $index;
        } else {
            $nodes[$parent]['children'][] = $index;
        }
        return $index;
    };
    $flushText = static function (int $upTo) use (&$textStart, $add): void {
        if ($upTo > $textStart) {
            $add(['type' => 'text', 'start' => $textStart, 'end' => $upTo]);
        }
    };
    // Schließt die obersten Elemente bis einschließlich Stapelposition $down.
    $closeTo = static function (int $down, int $innerEnd, int $end) use (&$nodes, &$stack): void {
        while (count($stack) > $down) {
            $index = array_pop($stack);
            $nodes[$index]['inner_end'] = $innerEnd;
            $nodes[$index]['end'] = $end;
        }
    };

    while ($pos < $len) {
        $lt = strpos($source, '<', $pos);
        if ($lt === false) {
            break;
        }
        $next = $source[$lt + 1] ?? '';

        if ($next === '?') {
            $flushText($lt);
            $end = markup_php_end($source, $lt);
            $add(['type' => 'php', 'start' => $lt, 'end' => $end]);
            $pos = $textStart = $end;
            continue;
        }
        if ($next === '!') {
            $flushText($lt);
            if (substr($source, $lt, 4) === '<!--') {
                $close = strpos($source, '-->', $lt + 4);
                $end = $close === false ? $len : $close + 3;
                $add(['type' => 'comment', 'start' => $lt, 'end' => $end]);
            } else {
                $close = strpos($source, '>', $lt);
                $end = $close === false ? $len : $close + 1;
                $add(['type' => 'declaration', 'start' => $lt, 'end' => $end]);
            }
            $pos = $textStart = $end;
            continue;
        }
        if ($next === '/' && ctype_alpha($source[$lt + 2] ?? '')) {
            $flushText($lt);
            $nameEnd = $lt + 2;
            while ($nameEnd < $len && !ctype_space($source[$nameEnd]) && $source[$nameEnd] !== '>') {
                $nameEnd++;
            }
            $tag = strtolower(substr($source, $lt + 2, $nameEnd - $lt - 2));
            $close = strpos($source, '>', $nameEnd);
            $end = $close === false ? $len : $close + 1;
            // Offene Elemente über dem passenden schließen implizit; ein End-Tag
            // ohne offenes Element wird übergangen.
            for ($i = count($stack) - 1; $i >= 0; $i--) {
                if ($nodes[$stack[$i]]['tag'] === $tag) {
                    $closeTo($i + 1, $lt, $lt);
                    $closeTo($i, $lt, $end);
                    break;
                }
            }
            $pos = $textStart = $end;
            continue;
        }
        if (!ctype_alpha($next)) {
            // Einzelnes „<“ im Text.
            $pos = $lt + 1;
            continue;
        }

        $flushText($lt);
        $tagInfo = markup_parse_start_tag($source, $lt);
        $tag = $tagInfo['tag'];

        // Implizit schließen: nächstes passendes Element von oben, solange nur
        // implizit schließbare Elemente darüber liegen.
        for ($i = count($stack) - 1; $i >= 0; $i--) {
            $openTag = $nodes[$stack[$i]]['tag'];
            if (!isset(MARKUP_IMPLICIT_CLOSE[$openTag])) {
                break;
            }
            if (in_array($tag, MARKUP_IMPLICIT_CLOSE[$openTag], true)) {
                $closeTo($i, $lt, $lt);
                break;
            }
        }

        $isVoid = in_array($tag, MARKUP_VOID_ELEMENTS, true) || $tagInfo['self_closing'];
        $index = $add([
            'type' => 'element',
            'tag' => $tag,
            'start' => $lt,
            'tag_end' => $tagInfo['end'],
            'inner_start' => $tagInfo['end'],
            'inner_end' => $tagInfo['end'],
            'end' => $tagInfo['end'],
            'attrs' => $tagInfo['attrs'],
            'self_closing' => $isVoid,
            'has_php' => $tagInfo['has_php'],
            'attrs_end' => $tagInfo['attrs_end'],
            'children' => [],
        ]);
        $seen = [];
        foreach ($tagInfo['attrs'] as $attr) {
            if (!isset($seen[$attr['name']]) && $attr['value'] !== null) {
                $byAttr[$attr['name']][$attr['value']][] = $index;
            }
            $seen[$attr['name']] = true;
        }
        $pos = $textStart = $tagInfo['end'];
        if ($isVoid) {
            continue;
        }
        $stack[] = $index;

        if (in_array($tag, MARKUP_RAW_TEXT_ELEMENTS, true)) {
            [$innerEnd, $end] = markup_raw_text_end($source, $tag, $pos);
            $flushText($innerEnd);
            $closeTo(count($stack) - 1, $innerEnd, $end);
            $pos = $textStart = $end;
        }
    }

    $flushText($len);
    $closeTo(0, $len, $len);

    return ['source' => $source, 'nodes' => $nodes, 'roots' => $roots, 'by_attr' => $byAttr];
}

/** Ende eines PHP-Blocks ab $start (nach dem schließenden Tag oder Dateiende). */
function markup_php_end(string $source, int $start): int
{
    $close = strpos($source, '?>', $start + 2);
    return $close === false ? strlen($source) : $close + 2;
}

/** Ende eines Rohtext-Elements: [Inner-Ende, Ende nach dem End-Tag]. */
function markup_raw_text_end(string $source, string $tag, int $from): array
{
    $len = strlen($source);
    $needle = '</' . $tag;
    $search = $from;
    while (($at = stripos($source, $needle, $search)) !== false) {
        $after = $source[$at + strlen($needle)] ?? '>';
        if ($after === '>' || ctype_space($after)) {
            $close = strpos($source, '>', $at);
            return [$at, $close === false ? $len : $close + 1];
        }
        $search = $at + 1;
    }
    return [$len, $len];
}

/** Start-Tag ab $lt lesen: ['tag', 'attrs', 'end', 'self_closing', 'has_php', 'attrs_end']. */
function markup_parse_start_tag(string $source, int $lt): array
{
    $len = strlen($source);
    $p = $lt + 1;
    while ($p < $len && !ctype_space($source[$p]) && $source[$p] !== '>' && $source[$p] !== '/'
        && !($source[$p] === '<' && ($source[$p + 1] ?? '') === '?')) {
        $p++;
    }
    $tag = strtolower(substr($source, $lt + 1, $p - $lt - 1));
    $attrs = [];
    $selfClosing = false;
    $hasPhp = false;
    $attrsEnd = $p;

    while (true) {
        $wsStart = $p;
        while ($p < $len && ctype_space($source[$p])) {
            $p++;
        }
        if ($p >= $len) {
            break;
        }
        $c = $source[$p];
        if ($c === '>') {
            $p++;
            break;
        }
        if ($c === '/') {
            if (($source[$p + 1] ?? '') === '>') {
                $selfClosing = true;
                $p += 2;
                break;
            }
            $p++;
            continue;
        }
        if ($c === '<' && ($source[$p + 1] ?? '') === '?') {
            $hasPhp = true;
            $p = markup_php_end($source, $p);
            continue;
        }

        $nameStart = $p;
        while ($p < $len && !ctype_space($source[$p]) && $source[$p] !== '=' && $source[$p] !== '>' && $source[$p] !== '/'
            && !($source[$p] === '<' && ($source[$p + 1] ?? '') === '?')) {
            $p++;
        }
        if ($p === $nameStart) {
            $p++;
            continue;
        }
        $attr = [
            'name' => strtolower(substr($source, $nameStart, $p - $nameStart)),
            'value' => null,
            'quote' => '',
            'has_php' => false,
            'ws_start' => $wsStart,
            'start' => $nameStart,
            'end' => $p,
            'value_start' => $p,
            'value_end' => $p,
        ];

        $q = $p;
        while ($q < $len && ctype_space($source[$q])) {
            $q++;
        }
        if (($source[$q] ?? '') === '=') {
            $q++;
            while ($q < $len && ctype_space($source[$q])) {
                $q++;
            }
            $quote = $source[$q] ?? '';
            if ($quote === '"' || $quote === "'") {
                $valueStart = $q + 1;
                $v = $valueStart;
                while ($v < $len && $source[$v] !== $quote) {
                    if ($source[$v] === '<' && ($source[$v + 1] ?? '') === '?') {
                        $attr['has_php'] = true;
                        $v = markup_php_end($source, $v);
                    } else {
                        $v++;
                    }
                }
                $attr['quote'] = $quote;
                $attr['value_start'] = $valueStart;
                $attr['value_end'] = $v;
                $attr['end'] = min($v + 1, $len);
            } else {
                $valueStart = $q;
                $v = $valueStart;
                while ($v < $len && !ctype_space($source[$v]) && $source[$v] !== '>') {
                    if ($source[$v] === '<' && ($source[$v + 1] ?? '') === '?') {
                        $attr['has_php'] = true;
                        $v = markup_php_end($source, $v);
                    } else {
                        $v++;
                    }
                }
                $attr['value_start'] = $valueStart;
                $attr['value_end'] = $v;
                $attr['end'] = $v;
            }
            $attr['value'] = substr($source, $attr['value_start'], $attr['value_end'] - $attr['value_start']);
            $p = $attr['end'];
        }
        $attrs[] = $attr;
        if (!$hasPhp) {
            $attrsEnd = $attr['end'];
        }
    }

    return ['tag' => $tag, 'attrs' => $attrs, 'end' => $p, 'self_closing' => $selfClosing, 'has_php' => $hasPhp, 'attrs_end' => $attrsEnd];
}

/** Indizes aller Elemente, deren Attribut $name genau $value (roh) enthält; ohne Durchlauf (by_attr). */
function markup_find_by_attr(array $doc, string $name, string $value): array
{
    return $doc['by_attr'][$name][$value] ?? [];
}

/** Index des ersten Elements mit dem Tag $tag (klein), null ohne. */
function markup_find_tag(array $doc, string $tag): ?int
{
    foreach ($doc['nodes'] as $index => $node) {
        if ($node['type'] === 'element' && $node['tag'] === $tag) {
            return $index;
        }
    }
    return null;
}

/** Attribut eines Elements (erstes Vorkommen) oder null. */
function markup_attr(array $node, string $name): ?array
{
    foreach ($node['attrs'] ?? [] as $attr) {
        if ($attr['name'] === $name) {
            return $attr;
        }
    }
    return null;
}

/** Attributwert mit aufgelösten Entities; '' ohne Attribut. */
function markup_attr_text(array $node, string $name): string
{
    return html_entity_decode((string) (markup_attr($node, $name)['value'] ?? ''), ENT_HTML5 | ENT_QUOTES, 'UTF-8');
}

/** Roher Innenbereich eines Elements. */
function markup_inner_html(array $doc, int $index): string
{
    $node = $doc['nodes'][$index];
    return substr($doc['source'], $node['inner_start'], $node['inner_end'] - $node['inner_start']);
}

/** Enthält der Innenbereich (rekursiv) einen PHP-Block – als Knoten, im Start-Tag oder Attribut eines Kindes, im Rohtext oder Kommentar? */
function markup_inner_has_php(array $doc, int $index): bool
{
    foreach ($doc['nodes'][$index]['children'] ?? [] as $child) {
        $node = $doc['nodes'][$child];
        if ($node['type'] === 'php' || ($node['has_php'] ?? false) || markup_inner_has_php($doc, $child)) {
            return true;
        }
        if (in_array($node['type'], ['text', 'comment'], true) && str_contains(substr($doc['source'], $node['start'], $node['end'] - $node['start']), '<?')) {
            return true;
        }
        foreach ($node['attrs'] ?? [] as $attr) {
            if ($attr['has_php']) {
                return true;
            }
        }
    }
    return false;
}

/** Ersetzung „Innenbereich setzen“ ($html fertig encodiert). */
function markup_set_inner(array $doc, int $index, string $html): array
{
    $node = $doc['nodes'][$index];
    if ($node['self_closing']) {
        throw new RuntimeException('Element <' . $node['tag'] . '> hat keinen Innenbereich');
    }
    return ['start' => $node['inner_start'], 'end' => $node['inner_end'], 'text' => $html];
}

/**
 * Ersetzung „Attribut setzen“ ($value roh, fertig encodiert).
 * Fehlt das Attribut, wird es als „ name="…"“ an der Einfügestelle attrs_end eingefügt (hinter
 * dem letzten Attribut vor einem PHP-Block, sonst hinter dem Tag-Namen): Leerraum vor „>“/„/>“
 * bleibt, mehrere Einfügungen an derselben Stelle reihen sich, und markup_remove_attr() stellt
 * das Original byte-genau wieder her.
 */
function markup_set_attr(array $doc, int $index, string $name, string $value): array
{
    $node = $doc['nodes'][$index];
    $attr = markup_attr($node, $name);
    if ($attr === null) {
        return ['start' => $node['attrs_end'], 'end' => $node['attrs_end'], 'text' => ' ' . $name . '="' . $value . '"'];
    }
    if ($attr['quote'] === '') {
        return ['start' => $attr['start'], 'end' => $attr['end'], 'text' => $name . '="' . $value . '"'];
    }
    return ['start' => $attr['value_start'], 'end' => $attr['value_end'], 'text' => $value];
}

/** Wert für ein Attribut kodieren (alle Anführungszeichen, passt zu markup_set_attr). */
function markup_attr_escape(string $value): string
{
    return htmlspecialchars($value, ENT_HTML5 | ENT_QUOTES, 'UTF-8');
}

/** Ersetzung „Attribut entfernen“ samt Leerraum davor; null, wenn es fehlt. */
function markup_remove_attr(array $doc, int $index, string $name): ?array
{
    $attr = markup_attr($doc['nodes'][$index], $name);
    if ($attr === null) {
        return null;
    }
    return ['start' => $attr['ws_start'], 'end' => $attr['end'], 'text' => ''];
}

/**
 * Ersetzung „Knoten entfernen“ samt Leerraum direkt davor (Zeilenumbruch,
 * Einrückung): endet der vorige Geschwister-Textknoten am Knoten, geht sein
 * abschließender Leerraum mit weg. Gegenstück zu markup_remove_attr().
 */
function markup_remove_node(array $doc, int $index): array
{
    $node = $doc['nodes'][$index];
    $start = $node['start'];
    $siblings = $node['parent'] === null ? $doc['roots'] : $doc['nodes'][$node['parent']]['children'];
    $at = array_search($index, $siblings, true);
    $prev = $at > 0 ? $doc['nodes'][$siblings[$at - 1]] : null;
    if ($prev !== null && $prev['type'] === 'text' && $prev['end'] === $start) {
        $text = substr($doc['source'], $prev['start'], $prev['end'] - $prev['start']);
        $start -= strlen($text) - strlen(rtrim($text));
    }
    return ['start' => $start, 'end' => $node['end'], 'text' => ''];
}

/** Wendet Ersetzungen ([start, end, text]) an; sie dürfen sich nicht überlappen. */
function markup_apply(string $source, array $replacements): string
{
    usort($replacements, static fn (array $a, array $b): int => $a['start'] <=> $b['start'] ?: $a['end'] <=> $b['end']);
    $out = '';
    $pos = 0;
    foreach ($replacements as $r) {
        if ($r['start'] < $pos || $r['end'] < $r['start'] || $r['end'] > strlen($source)) {
            throw new RuntimeException('Überlappende Ersetzungen');
        }
        $out .= substr($source, $pos, $r['start'] - $pos) . $r['text'];
        $pos = $r['end'];
    }
    return $out . substr($source, $pos);
}
