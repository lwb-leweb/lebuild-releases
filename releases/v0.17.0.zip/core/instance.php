<?php
declare(strict_types=1);

// Welche Website dieser Prozess bedient. Der Code (api/, core/, plugins/, public/admin/) liegt in LE_PROJECT_ROOT,
// die Daten der Website (config.php, content/, public/site/, public/uploads/) in LE_INSTANCE_ROOT. In einer
// Einzelinstallation ist das derselbe Ordner. Mehrere Websites auf einem Server: ein Checkout für alle, je Kunde
// ein Kundenordner unter LEBUILD_SITES (knowledgebase/architecture.md, „Mehrere Websites“).
// core/utils.php bindet die Datei als Erstes ein; so läuft sie auch für Website-PHP, Plugin-Endpoints und tools/.

// __DIR__ ist schon aufgelöst (PHP folgt Symlinks), wie LE_INSTANCE_ROOT per realpath: le_instance_is_multi vergleicht so
// auch unter Symlinks richtig.
define('LE_PROJECT_ROOT', dirname(__DIR__));

// Ordner mit den Kundenordnern und LE_INSTANCE_DOMAINS_FILE; der Host der Anfrage wählt den Kundenordner.
const LE_INSTANCE_SITES_ENV = 'LEBUILD_SITES';
// Domain der Vorschau-Adressen <kurzname>.<domain>, z. B. vorschau.leweb.at.
const LE_INSTANCE_PREVIEW_ENV = 'LEBUILD_PREVIEW_DOMAIN';
// Genau ein Kundenordner (Kommandozeile, Tests, Dev-Server). Hat Vorrang vor LEBUILD_SITES, der Host zählt dann nicht.
const LE_INSTANCE_SITE_ENV = 'LEBUILD_SITE';
// Kurzname eines Kunden: Name seines Ordners, seiner Vorschau-Adresse und seines Repos; höchstens 40 Zeichen, „-“ wie
// im Hostnamen nicht am Rand (sonst wäre die Vorschau-Adresse kein Hostname).
const LE_INSTANCE_NAME_PATTERN = '/^[a-z0-9]([a-z0-9-]{0,38}[a-z0-9])?$/';
// Hostname: Teile aus Buchstaben, Ziffern und „-“ (nicht am Rand), durch Punkte getrennt, höchstens 253 Zeichen.
const LE_INSTANCE_HOST_PATTERN = '/^(?=.{1,253}$)[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$/';
// Hauptdomain → Kurzname ({"leweb.at": "leweb"}), gepflegt von tools/sites.php.
const LE_INSTANCE_DOMAINS_FILE = 'domains.json';
// Gegenform einer Hauptdomain, die per 301 auf sie weiterleitet (leweb.at ↔ www.leweb.at).
const LE_INSTANCE_WWW_PREFIX = 'www.';
// Vorschau-Adressen nimmt keine Suchmaschine auf, nur die echte Domain.
const LE_INSTANCE_PREVIEW_ROBOTS = 'noindex, nofollow';
// Meldungen beim Start (Kommandozeile bzw. Fehlerprotokoll des Servers); %s: Wert von LEBUILD_SITE.
const LE_INSTANCE_TEXT = [
    'cliSite' => LE_INSTANCE_SITES_ENV . ' ist gesetzt: Auf der Kommandozeile mit ' . LE_INSTANCE_SITE_ENV . ' den Kundenordner angeben.',
    'siteMissing' => LE_INSTANCE_SITE_ENV . ' zeigt auf keinen Ordner: %s',
    // Fehlerprotokoll; %s: Pfad, der weder unter LE_INSTANCE_ROOT noch unter LE_PROJECT_ROOT liegt.
    'foreignPath' => 'Pfad liegt außerhalb der Website (LE_INSTANCE_ROOT): %s',
];

/** Host (HTTP_HOST, Caddys ?domain=) in vergleichbarer Form: klein, ohne Port und Punkt am Ende (auch für eigene Links, le_url_link_attrs). */
function le_host_normalize(string $host): string
{
    $host = (string) preg_replace('/:\d*$/', '', strtolower(trim($host)));

    return str_ends_with($host, '.') ? substr($host, 0, -1) : $host;
}

/** Liegt der Host $host unter der Domain $domain (x.vorschau.leweb.at unter vorschau.leweb.at, nicht sie selbst)? */
function le_host_under(string $host, string $domain): bool
{
    return str_ends_with($host, '.' . $domain);
}

/** Host wie die Auflösung ihn vergleicht (le_host_normalize); null, wenn er kein Hostname ist. */
function le_instance_host(string $host): ?string
{
    $host = le_host_normalize($host);

    return preg_match(LE_INSTANCE_HOST_PATTERN, $host) ? $host : null;
}

/** Kundenordner $name unter $sites, null bei ungültigem Kurznamen oder ohne Ordner. */
function le_instance_site_dir(string $sites, string $name): ?string
{
    if (!preg_match(LE_INSTANCE_NAME_PATTERN, $name)) {
        return null;
    }
    $dir = realpath($sites . '/' . $name);

    return $dir !== false && is_dir($dir) ? $dir : null;
}

/** Inhalt von domains.json unter $sites: [Domain => Kurzname], leer ohne lesbare Datei. */
function le_instance_domains(string $sites): array
{
    $domains = json_decode((string) @file_get_contents($sites . '/' . LE_INSTANCE_DOMAINS_FILE), true);

    return is_array($domains) ? array_filter($domains, 'is_string') : [];
}

/** www-Gegenform eines Hosts: leweb.at ↔ www.leweb.at (Weiterleitung; tools/sites.php vergibt beide nur an einen Kunden). */
function le_instance_www_counterpart(string $host): string
{
    return str_starts_with($host, LE_INSTANCE_WWW_PREFIX) ? substr($host, strlen(LE_INSTANCE_WWW_PREFIX)) : LE_INSTANCE_WWW_PREFIX . $host;
}

/**
 * Kundenordner für den Host $host unter $sites, in dieser Reihenfolge: Vorschau-Adresse <kurzname>.$previewDomain
 * mit vorhandenem Ordner, Domain aus domains.json, die www-Gegenform einer eingetragenen Domain (Weiterleitung).
 * ['dir' => Ordner|null, 'preview' => bool, 'redirect' => Domain|null]; dir und redirect null: unbekannt (404).
 * Einzige Rechenweise für die Anfrage (le_instance_boot) und Caddys Zertifikats-Frage (tools/tls-ask.php).
 */
function le_instance_resolve(string $host, string $sites, string $previewDomain): array
{
    $none = ['dir' => null, 'preview' => false, 'redirect' => null];
    $host = le_instance_host($host);
    if ($host === null) {
        return $none;
    }
    $preview = le_instance_host($previewDomain);
    if ($preview !== null && le_host_under($host, $preview)) {
        $dir = le_instance_site_dir($sites, substr($host, 0, -strlen($preview) - 1));
        if ($dir !== null) {
            return ['dir' => $dir, 'preview' => true, 'redirect' => null];
        }
    }
    $domains = le_instance_domains($sites);
    $dir = le_instance_site_dir($sites, $domains[$host] ?? '');
    if ($dir !== null) {
        return ['dir' => $dir, 'preview' => false, 'redirect' => null];
    }
    $other = le_instance_www_counterpart($host);
    if (le_instance_site_dir($sites, $domains[$other] ?? '') !== null) {
        return ['dir' => null, 'preview' => false, 'redirect' => $other];
    }

    return $none;
}

/**
 * Ordner der Website dieses Prozesses (LE_INSTANCE_ROOT): LEBUILD_SITE, sonst im Mehrfachbetrieb (LEBUILD_SITES)
 * der Kundenordner zum Host, sonst LE_PROJECT_ROOT. Antwortet selbst, wo es keinen Ordner gibt: 301 auf die
 * eingetragene Form der Domain, 404 ohne Inhalt. Vorschau-Antworten bekommen X-Robots-Tag. Auf der Kommandozeile
 * gibt es keinen Host: Mit LEBUILD_SITES, aber ohne LEBUILD_SITE bricht sie ab, statt still im Code-Ordner zu schreiben.
 */
function le_instance_boot(): string
{
    $site = (string) getenv(LE_INSTANCE_SITE_ENV);
    if ($site !== '') {
        $dir = realpath($site);
        if ($dir === false || !is_dir($dir)) {
            le_instance_stop(sprintf(LE_INSTANCE_TEXT['siteMissing'], $site));
        }
        return $dir;
    }
    $sites = (string) getenv(LE_INSTANCE_SITES_ENV);
    if ($sites === '') {
        return LE_PROJECT_ROOT;
    }
    if (PHP_SAPI === 'cli') {
        le_instance_stop(LE_INSTANCE_TEXT['cliSite']);
    }

    $found = le_instance_resolve((string) ($_SERVER['HTTP_HOST'] ?? ''), $sites, (string) getenv(LE_INSTANCE_PREVIEW_ENV));
    if ($found['redirect'] !== null) {
        header('Location: https://' . $found['redirect'] . ($_SERVER['REQUEST_URI'] ?? '/'), true, 301);
        exit;
    }
    if ($found['dir'] === null) {
        http_response_code(404);
        exit;
    }
    if ($found['preview']) {
        header('X-Robots-Tag: ' . LE_INSTANCE_PREVIEW_ROBOTS);
    }

    return $found['dir'];
}

/** Abbruch beim Start: Meldung auf STDERR mit Exit-Code 1, im Webserver 500 und Eintrag im Fehlerprotokoll. */
function le_instance_stop(string $message): void
{
    if (PHP_SAPI === 'cli') {
        fwrite(STDERR, $message . "\n");
        exit(1);
    }
    error_log($message);
    http_response_code(500);
    exit;
}

/** Ob dieser Prozess die Website eines Kundenordners bedient (Mehrfachbetrieb oder LEBUILD_SITE), nicht die des Code-Ordners. */
function le_instance_is_multi(): bool
{
    return LE_INSTANCE_ROOT !== LE_PROJECT_ROOT;
}

/**
 * $path relativ zum Ordner der Website (content/cache/x), wie Meldungen, Systemprüfung und Sicherung ihn zeigen. In der
 * Einzelinstallation gehört plugins/ dazu; mit eigenem Kundenordner ist ein Code-Pfad (auch plugins/) so ein Fehler im
 * Aufrufer wie jeder andere Pfad außerhalb: LogicException statt still abgeschnittener Zeichen oder Code unter dem
 * Namen von Kundendaten.
 */
function le_instance_relative(string $path): string
{
    if ($path === LE_INSTANCE_ROOT || !le_path_in($path, [LE_INSTANCE_ROOT])) {
        throw new LogicException(sprintf(LE_INSTANCE_TEXT['foreignPath'], $path));
    }
    return substr($path, strlen(LE_INSTANCE_ROOT) + 1);
}

// LE_INSTANCE_LOOKUP_ONLY: Der Prozess bedient selbst keine Website und schreibt keine Daten einer Website, auch wenn
// LEBUILD_SITES gesetzt ist: tools/tls-ask.php (Caddy fragt über 127.0.0.1 nach einer anderen Domain), der
// Elternprozess von tools/sites.php und tools/backup-pull.php. LE_INSTANCE_ROOT ist dann der Code-Ordner, damit
// core/utils.php lädt; solche Prozesse nutzen nur Helfer mit ausdrücklichem Pfad, nie CONTENT_ROOT & Co.
define('LE_INSTANCE_ROOT', defined('LE_INSTANCE_LOOKUP_ONLY') ? LE_PROJECT_ROOT : le_instance_boot());
