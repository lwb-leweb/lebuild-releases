// Auswahl in einem bearbeitbaren Bereich, auch im Shadow-DOM des Seiten-Editors (text-markup.js,
// richtext.js).

// Auswahl, in der node liegt. Im Shadow-DOM (Panel „Alle Texte“) liefert Chrome sie über die
// ShadowRoot; sonst gilt die des Fensters.
export function selectionOf(node) {
  const root = node.getRootNode();
  return typeof root.getSelection === 'function' ? root.getSelection() : window.getSelection();
}

// Markierter Bereich als Range (null ohne Auswahl). Browser ohne ShadowRoot.getSelection melden
// eine Auswahl im Shadow-DOM nur über getComposedRanges mit seiner Wurzel.
export function selectedRange(area) {
  const selection = selectionOf(area);
  if (!selection.rangeCount) return null;
  const root = area.getRootNode();
  if (root === document || typeof root.getSelection === 'function' || !selection.getComposedRanges) {
    return selection.getRangeAt(0).cloneRange();
  }
  const composed = selection.getComposedRanges({ shadowRoots: [root] })[0];
  if (!composed) return null;
  const range = document.createRange();
  range.setStart(composed.startContainer, composed.startOffset);
  range.setEnd(composed.endContainer, composed.endOffset);
  return range;
}
