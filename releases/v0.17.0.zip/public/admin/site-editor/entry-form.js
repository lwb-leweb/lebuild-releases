import { imagePicker, imageDropArea, uploadPending, uploadForm } from './upload.js';
import { editorButton } from './buttons.js';
import { richTextEditor } from './richtext.js';

// Formular für einen Plugin-Eintrag aus dem Schema seines Typs (schema.fields bzw. Typ-JSON der
// Content-Typen). Die eine Quelle für Seiten-Editor (Panel im Shadow-DOM, plugin-lists.js) und
// Backend (Modal: generische Plugin-Ansicht, Plugins über ctx.ui.openEntryForm). Gebaut wird per
// DOM (textContent, value), Eintragswerte und Feldnamen können kein Markup einschleusen.

export const ENTRY_TEXT = {
  add: 'Neu',
  edit: 'Bearbeiten',
  save: 'Speichern',
  cancel: 'Abbrechen',
  untitled: '(ohne Titel)',
  emptyOption: '—',
  deleteQuestion: '‚{name}‘ löschen?',
  otherImage: 'Anderes Bild',
  remove: 'Entfernen',
  richtextRequired: '„{name}“ bitte ausfüllen.',
  addRow: '+ {name} hinzufügen',
  addRowFallback: '+ Zeile hinzufügen',
  rowUp: '↑',
  rowDown: '↓',
  rowUpLabel: 'Nach oben',
  rowDownLabel: 'Nach unten'
};
// Felder, die einen Eintrag benennen (vor dem ersten Textfeld).
const TITLE_FIELDS = ['name', 'title'];
const TITLE_FALLBACK_TYPE = 'text';
// Feldart → type des <input>; alle übrigen Arten (text, slug, …) sind Textfelder.
const INPUT_TYPES = {
  number: 'number',
  datetime: 'datetime-local',
  date: 'date'
};
const INPUT_TYPE_TEXT = 'text';
// Eingabefelder, die focus() bzw. eine neue Zeile in list zuerst anspricht.
const FOCUS_TARGET = 'input:not([type="file"]):not([type="hidden"]):not([hidden]), select, textarea:not([hidden]), [contenteditable="true"]';
// Feldart → inputmode (Tastatur am Handy); geprüft wird die Adresse auf dem Server.
const INPUT_MODES = {
  url: 'url'
};
// Klassen im Backend-Modal (styles.css).
const BACKEND_LOOK = {
  form: 'settings-form entry-form',
  field: 'field',
  labelTag: 'small',
  label: '',
  checkbox: 'field field--checkbox',
  picker: 'entry-form__picker',
  image: 'entry-form__image',
  imageEmpty: 'entry-form__image-empty',
  imageDrop: 'entry-form__drop',
  imageDropActive: 'entry-form__drop--active',
  imageActions: 'entry-form__image-actions',
  list: 'entry-form__list',
  listRow: 'entry-form__row',
  listRowActions: 'entry-form__row-actions'
};

// Beschriftung eines Feldes: label aus dem Schema, sonst sein Name.
export function fieldLabel(field) {
  return field.label ? field.label : field.name;
}

// Feld, das einen Eintrag benennt: name oder title, sonst das erste Textfeld (null ohne).
export function titleField(schema) {
  const named = schema.find(function (field) { return TITLE_FIELDS.indexOf(field.name) !== -1; });
  if (named) return named.name;
  const text = schema.find(function (field) { return field.type === TITLE_FALLBACK_TYPE; });
  return text ? text.name : null;
}

// Anzeigename eines Eintrags (Listen im Backend, Nachfrage beim Löschen).
export function entryTitle(schema, row) {
  const name = titleField(schema);
  if (!name) return '#' + row.id;
  return row[name] ? String(row[name]) : ENTRY_TEXT.untitled;
}

// „‚Max Muster‘ löschen?“ – als Text für confirm(), nie als HTML.
export function deleteQuestion(schema, row) {
  // Ersatz als Funktion: „$&“ o. Ä. im Namen bleibt wörtlich stehen.
  const title = entryTitle(schema, row);
  return ENTRY_TEXT.deleteQuestion.replace('{name}', function () { return title; });
}

// Wert für das Eingabefeld: Datum aus der Datenbank („2026-10-15 09:30:00“) für datetime-local.
function formatInputValue(field, value) {
  if (field.type === 'datetime' && value) {
    return String(value).replace(' ', 'T').slice(0, 16);
  }
  return value == null ? '' : String(value);
}

function fieldBox(look, field, tag) {
  const box = document.createElement(tag);
  box.className = look.field;
  const label = document.createElement(look.labelTag);
  if (look.label) label.className = look.label;
  label.textContent = fieldLabel(field);
  box.appendChild(label);
  return box;
}

// Auswahl: Wert ist die Option, angezeigt wird ihre Beschriftung aus optionLabels, sonst die Option selbst.
function selectInput(field, value) {
  const select = document.createElement('select');
  if (!field.required) select.add(new Option(ENTRY_TEXT.emptyOption, ''));
  const labels = field.optionLabels && typeof field.optionLabels === 'object' ? field.optionLabels : {};
  (Array.isArray(field.options) ? field.options : []).forEach(function (option) {
    if (typeof option !== 'string') return;
    select.add(new Option(Object.prototype.hasOwnProperty.call(labels, option) ? labels[option] : option, option));
  });
  select.value = value;
  return select;
}

// Bildfeld: Ablagefläche mit Vorschau (ohne Bild der Hinweis zum Hineinziehen), Dateiauswahl mit
// sofortigem Upload und „Entfernen“. Die URL steht im versteckten Eingabefeld; Änderungen melden
// sich als input am Formular (ungespeicherte Eingaben). Hochgeladen wird für das Formular uploads.
function imageField(look, field, input, notify, uploads) {
  const box = fieldBox(look, field, 'div');
  input.type = 'hidden';
  const set = function (url) {
    input.value = url;
    show();
    input.dispatchEvent(new Event('input', { bubbles: true }));
  };
  const picker = imagePicker(set, notify, look.picker, uploads);
  const area = imageDropArea(picker, { drop: look.imageDrop, active: look.imageDropActive, image: look.image, empty: look.imageEmpty });
  const remove = editorButton(ENTRY_TEXT.remove, look.picker, function () { set(''); });
  const chooseText = picker.element.firstChild.nodeValue;
  const show = function () {
    area.show(input.value);
    remove.hidden = !input.value;
    picker.element.firstChild.nodeValue = input.value ? ENTRY_TEXT.otherImage : chooseText;
  };
  show();
  const actions = document.createElement('div');
  actions.className = look.imageActions;
  actions.append(picker.element, remove);
  box.append(input, area.element, actions);
  return box;
}

// Ein Feld des Formulars aus dem Schema: { box, input, read() }; read() = Wert (boolean '1'/'0', list
// die Zeilen). ctx: { look, notify, uploads, editors, beforeCheck, row }; Texteditoren kommen mit ctx.row (Zeile
// eines list-Feldes, sonst undefined) nach ctx.editors (Pflicht prüft check()).
function buildField(field, rawValue, ctx) {
  if (field.type === 'list') return listField(field, rawValue, ctx);
  const look = ctx.look;
  const value = formatInputValue(field, rawValue);
  let input;
  let box;
  if (field.type === 'boolean') {
    input = document.createElement('input');
    input.type = 'checkbox';
    input.checked = value !== '' && value !== '0';
    box = document.createElement('label');
    box.className = look.checkbox;
    const line = document.createElement('span');
    line.append(input, ' ' + fieldLabel(field));
    box.appendChild(line);
  } else if (field.type === 'richtext' || field.type === 'textarea') {
    input = document.createElement('textarea');
    input.value = value;
  } else if (field.type === 'select') {
    input = selectInput(field, value);
  } else {
    input = document.createElement('input');
    input.type = Object.prototype.hasOwnProperty.call(INPUT_TYPES, field.type) ? INPUT_TYPES[field.type] : INPUT_TYPE_TEXT;
    if (Object.prototype.hasOwnProperty.call(INPUT_MODES, field.type)) input.inputMode = INPUT_MODES[field.type];
    input.value = value;
  }
  // Beispiel im leeren Feld (placeholder aus dem Schema, z. B. „z. B. 8–12, 14–18“).
  if (field.placeholder && (input.tagName === 'INPUT' || input.tagName === 'TEXTAREA')) input.placeholder = field.placeholder;
  input.name = field.name;
  // Ein verstecktes Pflichtfeld kann der Browser nicht melden; das prüft check().
  if (field.required && field.type !== 'richtext') input.required = true;
  if (field.type === 'image') {
    box = imageField(look, field, input, ctx.notify, ctx.uploads);
  } else if (field.type === 'richtext') {
    const editor = richTextEditor(input);
    ctx.editors.push({ field: field, input: input, editor: editor, row: ctx.row });
    box = fieldBox(look, field, 'div');
    box.appendChild(editor.element);
  } else if (!box) {
    box = fieldBox(look, field, 'label');
    box.appendChild(input);
  }
  return {
    box: box,
    input: input,
    read: function () { return field.type === 'boolean' ? (input.checked ? '1' : '0') : input.value; }
  };
}

// Leerer Wert einer Zeile wie auf dem Server (plugin_schema_list_values): leer oder leeres Kästchen.
function emptyRowValue(field, value) {
  return value === '' || (field.type === 'boolean' && value === '0');
}

// Erstes Eingabefeld in element fokussieren; liefert, ob es eines gab.
function focusFirst(element) {
  const first = element.querySelector(FOCUS_TARGET);
  if (first) first.focus();
  return Boolean(first);
}

// Knopf einer Zeile mit Zeichen statt Text (↑/↓); label für Screenreader und Tooltip.
function rowButton(text, label, className, onClick) {
  const button = editorButton(text, className, onClick);
  button.title = label;
  button.setAttribute('aria-label', label);
  return button;
}

// Feld der Art list: je Zeile eine Karte mit den Unterfeldern, ↑/↓ (am Rand ausgeblendet) und
// Entfernen, darunter „+ <itemLabel> hinzufügen“. Leere Zeilen fallen wie auf dem Server weg, ihre
// Pflicht-Unterfelder gelten nicht (ctx.beforeCheck, check()); min/max prüft der Server. Änderungen
// melden sich als input am Formular (ungespeicherte Eingaben). read() = Zeilen in der angezeigten Reihenfolge.
function listField(field, value, ctx) {
  const look = ctx.look;
  const box = fieldBox(look, field, 'div');
  const list = document.createElement('div');
  list.className = look.list;
  const rows = [];
  const changed = function () { list.dispatchEvent(new Event('input', { bubbles: true })); };
  const refresh = function () {
    rows.forEach(function (row, index) {
      row.up.hidden = index === 0;
      row.down.hidden = index === rows.length - 1;
    });
  };
  const addRow = function (values) {
    const card = document.createElement('div');
    card.className = look.listRow;
    const row = { card: card };
    const rowCtx = Object.assign({}, ctx, { row: row });
    const fields = (Array.isArray(field.fields) ? field.fields : []).map(function (sub) {
      const built = buildField(sub, values && values[sub.name] != null ? values[sub.name] : '', rowCtx);
      card.appendChild(built.box);
      return { field: sub, built: built };
    });
    row.read = function () {
      const data = {};
      fields.forEach(function (sub) { data[sub.field.name] = sub.built.read(); });
      return data;
    };
    row.empty = function () {
      return fields.every(function (sub) { return emptyRowValue(sub.field, sub.built.read()); });
    };
    // Pflicht nur für Zeilen mit Inhalt; Texteditoren prüft check() über row.empty().
    row.require = function () {
      const filled = !row.empty();
      fields.forEach(function (sub) {
        if (sub.field.required && sub.field.type !== 'richtext') sub.built.input.required = filled;
      });
    };
    const move = function (step, button, other) {
      const from = rows.indexOf(row);
      const to = from + step;
      if (to < 0 || to >= rows.length) return;
      rows.splice(from, 1);
      rows.splice(to, 0, row);
      list.insertBefore(card, step < 0 ? rows[to + 1].card : rows[to - 1].card.nextSibling);
      refresh();
      (button.hidden ? other : button).focus();
      changed();
    };
    const remove = function () {
      const index = rows.indexOf(row);
      rows.splice(index, 1);
      card.remove();
      refresh();
      const next = rows[index] || rows[index - 1];
      if (!next || !focusFirst(next.card)) add.focus();
      changed();
    };
    const actions = document.createElement('div');
    actions.className = look.listRowActions;
    row.up = rowButton(ENTRY_TEXT.rowUp, ENTRY_TEXT.rowUpLabel, look.picker, function () { move(-1, row.up, row.down); });
    row.down = rowButton(ENTRY_TEXT.rowDown, ENTRY_TEXT.rowDownLabel, look.picker, function () { move(1, row.down, row.up); });
    actions.append(row.up, row.down, editorButton(ENTRY_TEXT.remove, look.picker, remove));
    card.appendChild(actions);
    rows.push(row);
    list.appendChild(card);
    refresh();
    return card;
  };
  const name = field.itemLabel;
  const add = editorButton(name ? ENTRY_TEXT.addRow.replace('{name}', function () { return name; }) : ENTRY_TEXT.addRowFallback, look.picker, function () {
    focusFirst(addRow(null));
    changed();
  });
  (Array.isArray(value) ? value : []).forEach(addRow);
  ctx.beforeCheck.push(function () { rows.forEach(function (row) { row.require(); }); });
  box.append(list, add);
  return {
    box: box,
    input: null,
    read: function () { return rows.map(function (row) { return row.read(); }); }
  };
}

// Feld nur sichtbar, solange ein anderes Feld einen bestimmten Wert hat (showWhen: { field, value }; nur
// Link und Adresse der Content-Typen je nach „Beim Klick“, aus Schemas entfernt der Server es). Versteckte
// Felder gehen trotzdem mit, damit beim Umschalten nichts verloren geht; ob er sie übernimmt, entscheidet der Server.
function applyShowWhen(schema, fields) {
  schema.forEach(function (field) {
    const when = field.showWhen;
    const source = when ? fields[when.field] : null;
    if (!source) return;
    const box = fields[field.name].box;
    const update = function () { box.hidden = source.read() !== when.value; };
    source.box.addEventListener('change', update);
    update();
  });
}

// Baut das Formular. options: { look (Klassen, siehe BACKEND_LOOK), notify (Hinweise beim Upload),
// onSubmit() (Enter in einem Feld) }. Felder ohne Wert im Eintrag (neu, ältere Einträge) starten mit
// default aus dem Schema, sofern angegeben. Liefert { form, check(), values(), focus(), close() }:
// check() = Pflichtfelder gefüllt (sonst zeigt der Browser die Meldung am Feld; in list nur in Zeilen
// mit Inhalt) und kein Upload läuft (sonst Hinweis über notify), values() = { feldname: wert }
// (boolean '1'/'0', list als Array von { unterfeld: wert }), close() = Formular ist fertig (gespeichert
// oder verworfen): hochgeladene Bilder, die nicht gespeichert sind, löscht der Server (upload.js, uploadForm).
export function buildEntryForm(schema, row, options) {
  const ctx = { look: options.look, notify: options.notify, uploads: uploadForm(), editors: [], beforeCheck: [] };
  const fields = {};
  const form = document.createElement('form');
  form.className = ctx.look.form;

  schema.forEach(function (field) {
    const value = row && row[field.name] != null ? row[field.name] : field.default;
    fields[field.name] = buildField(field, value != null ? value : '', ctx);
    form.appendChild(fields[field.name].box);
  });
  applyShowWhen(schema, fields);

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    options.onSubmit();
  });
  // Enter in einem einzeiligen Feld speichert (ohne Absenden-Knopf im Formular tut der Browser das nicht).
  form.addEventListener('keydown', function (event) {
    if (event.key !== 'Enter' || event.target.tagName !== 'INPUT' || event.target.type === 'file') return;
    event.preventDefault();
    options.onSubmit();
  });

  return {
    form: form,
    values: function () {
      const data = {};
      Object.keys(fields).forEach(function (name) { data[name] = fields[name].read(); });
      return data;
    },
    check: function () {
      if (uploadPending(options.notify)) return false;
      ctx.beforeCheck.forEach(function (prepare) { prepare(); });
      if (!form.reportValidity()) return false;
      // Texteditoren entfernter oder leerer Zeilen zählen nicht.
      const empty = ctx.editors.find(function (entry) {
        return entry.field.required && form.contains(entry.input) && !(entry.row && entry.row.empty()) && entry.input.value === '';
      });
      if (!empty) return true;
      options.notify(ENTRY_TEXT.richtextRequired.replace('{name}', function () { return fieldLabel(empty.field); }));
      empty.editor.focus();
      return false;
    },
    focus: function () {
      focusFirst(form);
    },
    close: function () {
      ctx.uploads.close();
    }
  };
}

// Formular im Backend-Modal (ui-modal.js). options: { schema, row, save(data) → Promise,
// onSaved(), notify }. Titel „Neu“/„Bearbeiten“, Fehler des Servers stehen im Modal. Wie auch immer
// das Modal zugeht (onClose), danach schließt sich das Formular (entry.close), bei laufendem Speichern
// erst, wenn es fertig ist (sonst fehlte dem Eintrag sein neues Bild).
export function openEntryModal(openModal, options) {
  let modal = null;
  let saving = false;
  const submit = function () { modal.submitButton.click(); };
  const entry = buildEntryForm(options.schema, options.row, { look: BACKEND_LOOK, notify: options.notify, onSubmit: submit });
  modal = openModal({
    title: options.row ? ENTRY_TEXT.edit : ENTRY_TEXT.add,
    bodyHtml: '',
    submitLabel: ENTRY_TEXT.save,
    cancelLabel: ENTRY_TEXT.cancel,
    onClose: function () { if (!saving) entry.close(); },
    onSubmit: function (ctx) {
      if (!entry.check()) return;
      saving = true;
      ctx.setBusy(true);
      options.save(entry.values()).then(function () {
        saving = false;
        if (ctx.isOpen()) ctx.close('submit');
        else entry.close();
        options.onSaved();
      }).catch(function (error) {
        saving = false;
        if (!ctx.isOpen()) entry.close();
        ctx.setBusy(false);
        ctx.setMessage(error.message || String(error), false);
      });
    }
  });
  modal.body.appendChild(entry.form);
  entry.focus();
  return modal;
}
