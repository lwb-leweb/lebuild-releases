// Knopf-Bausteine des Seiten-Editors, ohne Abhängigkeiten (auch für richtext.js im Backend);
// bar.js gibt sie weiter.

// Knopf des Editors (Leiste, Dialoge, Panels, Knöpfe am Element); className aus bar.css/edit.css.
export function editorButton(label, className, onClick) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = className;
  button.textContent = label;
  button.addEventListener('click', onClick);
  return button;
}

// Knopf, der beim Drücken die Auswahl in einem gerade bearbeiteten Text stehen lässt (Mini-Leiste, Knöpfe am Element).
export function keepSelection(button) {
  button.addEventListener('mousedown', function (event) { event.preventDefault(); });
  return button;
}
