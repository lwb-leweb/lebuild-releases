// Strg+S bzw. ⌘S speichert, im Seiten-Editor (main.js) und in der Verwaltung (modules/save-key.js).
// Den Dialog „Seite speichern unter“ des Browsers gibt es dort nie, auch wenn es nichts zu speichern
// gibt; was gespeichert wird (und ob überhaupt), entscheidet fn. Ein Speichern, das schon läuft,
// fängt fn ab (Knopf gesperrt bzw. eigener Merker); gehaltene Tasten zählen nur einmal.
// Capture am window: Der Zuhörer kommt vor allen anderen dran, auch bei Tasten aus dem Shadow-DOM, aus
// einem Text in Bearbeitung oder dem Texteditor (interact.js stoppt dort nur die Weitergabe an die
// Seite, nicht weitere Zuhörer am window).
export function onSaveKey(fn) {
  window.addEventListener('keydown', function (event) {
    if (!isSaveKey(event)) return;
    event.preventDefault();
    if (!event.repeat) fn();
  }, true);
}

// Nur Strg/⌘ mit S: Alt (auch AltGr) und Umschalt bleiben beim Browser.
function isSaveKey(event) {
  return (event.ctrlKey || event.metaKey) && !event.altKey && !event.shiftKey && typeof event.key === 'string' && event.key.toLowerCase() === 's';
}
