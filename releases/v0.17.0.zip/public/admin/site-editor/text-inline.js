import { state } from '../modules/core.js';
import { attachTextEditing, sanitizeTextMarkup, cleanLinkTarget, linkTargetMessage, placeCaret } from './text-markup.js';
import { fieldRect, fieldValue, FIELD_KIND } from './page-sync.js';
import { beginEdit, endEdit, record, resync, editChanged } from './session.js';
import { overlayLayer, track, untrack, placeNear, showActive } from './overlay.js';
import { notify } from './bar.js';

// Text und Links direkt am Element: Text wird contenteditable, die Mini-Leiste (Fett, Kursiv,
// Link bzw. Link-Ziel) liegt im Shadow-DOM über dem Element. Klick daneben übernimmt, Esc verwirft.

// Klassen der Mini-Leiste (edit.css).
const INLINE_CLASSES = {
  toolbar: 'le-toolbar__buttons',
  linkRow: 'le-toolbar__row',
  button: 'le-btn le-btn--small',
  secondary: 'le-btn--secondary',
  hidden: 'le-hidden'
};
const INLINE_TEXT = {
  target: 'Link-Ziel'
};

// options: { textPath, urlPath, x, y }. textPath: Text oder Linktext am Element (contenteditable),
// urlPath: Link-Ziel (Feld in der Mini-Leiste). Ein Link mit Text und Ziel ist eine Änderung.
export function editInline(el, options) {
  const textPath = options.textPath;
  const urlPath = options.urlPath;
  const inLink = state.fieldKinds[textPath] === FIELD_KIND.linktext;
  const box = document.createElement('div');
  box.className = 'le-toolbar';

  let editing = null;
  let before = '';
  const editableBefore = el.getAttribute('contenteditable');
  if (textPath) {
    before = el.innerHTML;
    el.setAttribute('contenteditable', 'true');
    editing = attachTextEditing(el, { inLink: inLink, classes: INLINE_CLASSES, onInput: editChanged, onMessage: notify });
    box.appendChild(editing.toolbar);
    if (!inLink) box.appendChild(editing.linkRow);
  }

  let targetInput = null;
  let targetBefore = '';
  if (urlPath) {
    targetBefore = fieldValue(urlPath);
    const row = document.createElement('label');
    row.className = 'le-toolbar__row le-field';
    row.appendChild(document.createElement('span')).textContent = INLINE_TEXT.target;
    targetInput = document.createElement('input');
    targetInput.type = 'text';
    targetInput.inputMode = 'url';
    targetInput.value = targetBefore;
    targetInput.addEventListener('input', editChanged);
    targetInput.addEventListener('keydown', function (event) {
      if (event.key === 'Enter') {
        event.preventDefault();
        endEdit(true);
      }
    });
    row.appendChild(targetInput);
    box.appendChild(row);
  }

  overlayLayer().appendChild(box);
  const position = function () {
    placeNear(box, fieldRect(el), true);
  };
  track(position, box);
  showActive(el);

  if (textPath) {
    el.focus({ preventScroll: true });
    placeCaret(el, options.x, options.y);
  } else {
    targetInput.focus();
  }

  beginEdit({
    contains: function (node) { return el.contains(node); },
    handlers: editing ? editing.handlers : null,
    // Esc schließt zuerst eine offene Link-Zeile, erst das nächste verwirft die Bearbeitung.
    escape: function () { return editing !== null && editing.closeLinkRow(); },
    isDirty: function () {
      return (textPath && el.innerHTML !== before) || (urlPath && targetInput.value !== targetBefore);
    },
    commit: function () {
      const values = [];
      // Ein unverändertes Ziel bleibt, auch wenn sein Schema nicht bearbeitbar ist (sms:, ftp:).
      if (urlPath && targetInput.value !== targetBefore) {
        const href = cleanLinkTarget(targetInput.value);
        if (href === '') {
          notify(linkTargetMessage());
          targetInput.focus();
          return false;
        }
        values.push({ path: urlPath, before: targetBefore, after: href });
      }
      if (textPath) {
        values.push({ path: textPath, before: fieldValue(textPath), after: sanitizeTextMarkup(el.innerHTML, inLink) });
      }
      record(values);
      return true;
    },
    cancel: function () {
      if (textPath) el.innerHTML = before;
    },
    close: function () {
      untrack(position);
      box.remove();
      showActive(null);
      if (textPath) {
        if (editableBefore === null) el.removeAttribute('contenteditable');
        else el.setAttribute('contenteditable', editableBefore);
      }
      // Sichtbar ist danach, was gespeichert wird (bereinigte Form bzw. Stand wie geladen).
      resync();
    }
  });
}
