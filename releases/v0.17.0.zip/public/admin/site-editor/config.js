// Daten, die index.php für angemeldete Benutzer vor </body> einhängt (core/siteEditor.php):
// CSRF-Token im <meta> und JSON-Block mit Name, Rolle, Seite und Listen. Auch die Backend-
// Seitenansicht liest daraus, welche Seite ihr iframe gerade zeigt.

// Namen wie SITE_EDITOR_CSRF_META und SITE_EDITOR_CONFIG_ID in core/siteEditor.php.
const CSRF_META = 'le-csrf-token';
const CONFIG_ID = 'le-site-editor-config';

// JSON-Block eines Dokuments; null ohne (Besucher, fremde Antwort).
export function readEditorConfig(doc) {
  const block = doc.getElementById(CONFIG_ID);
  return block ? JSON.parse(block.textContent) : null;
}

// Token aus dem <meta>; leer ohne (nicht angemeldet).
export function readCsrfToken(doc) {
  const meta = doc.querySelector('meta[name="' + CSRF_META + '"]');
  return meta ? meta.content : '';
}

