import { state } from '../modules/core.js';
import { addMenuButton, notifyError, editorButton } from './bar.js';
import { editorApi, editorPost } from './request.js';
import { openPanel, closePanel, isPanelOpen } from './panel.js';
import { hasUnsavedChanges, reloadWithNote } from './session.js';
import { askConfirm } from './confirm.js';

// „Verlauf“ in der Leiste: gespeicherte Stände der Seite in Menschensprache. Die Zeilen formuliert
// der Server (page_history in core/fileStore.php, api/listBackups.php); hier werden sie nur gezeigt.
// „Diesen Stand wiederherstellen“ geht über api/restore.php, danach lädt die Seite neu.

const HISTORY_KEY = 'history';
const HISTORY_TEXT = {
  button: 'Frühere Versionen',
  buttonNote: 'Einen gespeicherten Stand zurückholen',
  eyebrow: 'Diese Seite',
  title: 'Frühere Versionen',
  loading: 'Wird geladen …',
  empty: 'Noch keine gespeicherten Stände.',
  current: 'Aktueller Stand',
  restore: 'Diesen Stand wiederherstellen',
  confirmUnsaved: 'Ungespeicherte Änderungen gehen dabei verloren.',
  // %s: Namen der Komponenten vom Server („Fußzeile“, „Kopfzeile und Fußzeile“).
  confirmComponent: '%s wird auf allen Seiten zurückgesetzt.',
  confirmComponents: '%s werden auf allen Seiten zurückgesetzt.',
  componentJoin: ' und ',
  confirmQuestion: 'Diesen Stand wiederherstellen?',
  confirmButton: 'Wiederherstellen',
  restored: 'Wiederhergestellt',
  nothingRestored: 'Nichts wiederhergestellt',
  skippedField: 'Feld übersprungen',
  skippedFields: 'Felder übersprungen'
};

// „Wiederhergestellt, 2 Felder übersprungen.“ aus der Antwort von restore.php, dazu ihr Hinweis (message,
// z. B. Fußzeile mit gescheitertem Abgleich).
function restoreNote(data) {
  const n = data.skipped;
  const note = n ? ', ' + n + ' ' + (n === 1 ? HISTORY_TEXT.skippedField : HISTORY_TEXT.skippedFields) : '';
  return (data.restored ? HISTORY_TEXT.restored : HISTORY_TEXT.nothingRestored) + note + '.' + (data.message ? ' ' + data.message : '');
}

// Nachfrage vor dem Wiederherstellen: bei ungespeicherten Änderungen und wenn der Eintrag auch
// Kopf- oder Fußzeile zurücksetzt (entry.components, wirkt auf allen Seiten); sonst keine.
// Promise mit true, wenn es weitergeht.
function confirmRestore(entry) {
  const notes = [];
  if (hasUnsavedChanges()) notes.push(HISTORY_TEXT.confirmUnsaved);
  const names = entry.components || [];
  if (names.length) {
    const text = names.length === 1 ? HISTORY_TEXT.confirmComponent : HISTORY_TEXT.confirmComponents;
    notes.push(text.replace('%s', names.join(HISTORY_TEXT.componentJoin)));
  }
  if (!notes.length) return Promise.resolve(true);
  return askConfirm({ title: HISTORY_TEXT.confirmQuestion, text: notes.join(' '), confirm: HISTORY_TEXT.confirmButton });
}

function restore(entry, button) {
  confirmRestore(entry).then(function (yes) {
    if (!yes) return;
    button.disabled = true;
    editorPost('/api/restore.php', { page: state.currentPage, backup: entry.backup })
      .then(function (data) { reloadWithNote(restoreNote(data)); })
      .catch(function (error) {
        button.disabled = false;
        notifyError(error);
      });
  });
}

function message(text) {
  const p = document.createElement('p');
  p.className = 'le-panel__note';
  p.textContent = text;
  return p;
}

// Eine Zeile je Eintrag; der neueste ist der aktuelle Stand (backup null).
function renderEntries(body, entries) {
  body.textContent = '';
  if (!entries.length) {
    body.appendChild(message(HISTORY_TEXT.empty));
    return;
  }
  const list = document.createElement('ol');
  list.className = 'le-history';
  entries.forEach(function (entry) {
    const item = document.createElement('li');
    item.className = 'le-history__entry';
    const text = document.createElement('p');
    text.textContent = entry.text;
    item.appendChild(text);
    if (entry.backup === null) {
      const current = document.createElement('span');
      current.className = 'le-history__current';
      current.textContent = HISTORY_TEXT.current;
      item.appendChild(current);
    } else {
      const button = editorButton(HISTORY_TEXT.restore, 'le-btn le-btn--small le-btn--secondary', function () { restore(entry, button); });
      item.appendChild(button);
    }
    list.appendChild(item);
  });
  body.appendChild(list);
}

function openHistory() {
  openPanel({ key: HISTORY_KEY, eyebrow: HISTORY_TEXT.eyebrow, title: HISTORY_TEXT.title }).then(function (body) {
    if (!body) return;
    body.appendChild(message(HISTORY_TEXT.loading));
    editorApi('/api/listBackups.php?page=' + encodeURIComponent(state.currentPage))
      .then(function (data) {
        if (isPanelOpen(HISTORY_KEY)) renderEntries(body, data.backups);
      })
      .catch(function (error) {
        if (isPanelOpen(HISTORY_KEY)) closePanel();
        notifyError(error);
      });
  });
}

export function mountHistory() {
  addMenuButton('history', HISTORY_TEXT.button, HISTORY_TEXT.buttonNote, function () {
    if (isPanelOpen(HISTORY_KEY)) closePanel();
    else openHistory();
  });
}
