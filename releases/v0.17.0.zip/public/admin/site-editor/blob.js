// Fläche hinter der eingeklappten Leiste: ein Tropfen, dessen Rand weich wabert. Der Radius ist eine
// Summe langsamer Wellen mit krummen Tempi, so beult er sich mal hier, mal dort aus und wiederholt sich
// kaum; der Rand ist eine geschlossene Kurve durch viele Punkte, ohne Ecken. Läuft nur eingeklappt und
// läuft aus dem Kreis heraus sanft an (RAMP_MS).
// Will der Browser wenig Bewegung, bleibt der Tropfen als Kreis stehen.

const SVG_NS = 'http://www.w3.org/2000/svg';
// Radius im viewBox von -1 bis 1; bar.css macht die Fläche so groß, dass der kleinste Radius die Leiste
// noch ganz deckt.
const RADIUS = 0.82;
// Wellen: Anzahl Beulen ringsum, Höhe relativ zum Radius, Tempo (rad/s), Versatz. Klein gehalten,
// damit er rund bleibt und nur leicht schwappt.
const WAVES = [
  [2, 0.027, 0.53, 0.0],
  [3, 0.018, -0.71, 1.7],
  [4, 0.009, 0.97, 4.1],
];
const POINTS = 32;
const RAMP_MS = 900;

let path = null;
let frame = 0;

export function buildBlob() {
  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.setAttribute('class', 'le-bar__blob');
  svg.setAttribute('viewBox', '-1 -1 2 2');
  svg.setAttribute('aria-hidden', 'true');
  path = document.createElementNS(SVG_NS, 'path');
  svg.appendChild(path);
  draw(0);
  return svg;
}

// still: ohne Bewegung (prefers-reduced-motion), dann einmal als Kreis.
export function runBlob(on, still) {
  window.cancelAnimationFrame(frame);
  frame = 0;
  if (!on || still) {
    draw(0, true);
    return;
  }
  const start = window.performance.now();
  const tick = function (now) {
    const ramp = Math.min(1, Math.max(0, (now - start) / RAMP_MS));
    draw(now / 1000, false, ramp * ramp * (3 - 2 * ramp));
    frame = window.requestAnimationFrame(tick);
  };
  frame = window.requestAnimationFrame(tick);
}

function radius(angle, time, strength) {
  let r = 1;
  for (const [count, height, speed, shift] of WAVES) r += strength * height * Math.sin(count * angle + speed * time + shift);
  return RADIUS * r;
}

// Geschlossene Catmull-Rom-Kurve durch die Punkte, als kubische Bézier-Stücke.
// strength: Höhe der Wellen von 0 (Kreis) bis 1.
function draw(time, round, strength = 1) {
  const pts = [];
  for (let i = 0; i < POINTS; i++) {
    const angle = (i / POINTS) * Math.PI * 2;
    const r = round ? RADIUS : radius(angle, time, strength);
    pts.push([r * Math.cos(angle), r * Math.sin(angle)]);
  }
  let d = 'M' + fixed(pts[0]);
  for (let i = 0; i < POINTS; i++) {
    const p0 = pts[(i - 1 + POINTS) % POINTS];
    const p1 = pts[i];
    const p2 = pts[(i + 1) % POINTS];
    const p3 = pts[(i + 2) % POINTS];
    const c1 = [p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6];
    const c2 = [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6];
    d += 'C' + fixed(c1) + ' ' + fixed(c2) + ' ' + fixed(p2);
  }
  path.setAttribute('d', d + 'Z');
}

function fixed(point) {
  return point[0].toFixed(4) + ' ' + point[1].toFixed(4);
}
