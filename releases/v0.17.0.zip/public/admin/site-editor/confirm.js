import { editorRoot, editorButton } from './bar.js';

// Rückfrage in der Mitte der Seite statt window.confirm (Löschen, Wiederherstellen): Titel, ein
// Satz Erklärung, Abbrechen und die Aktion. Esc und Klick daneben brechen ab.

const CONFIRM_TEXT = {
  cancel: 'Abbrechen'
};

// options: { title, text (optional), confirm (Beschriftung der Aktion), danger (rote Aktion) }.
// Liefert ein Promise mit true (bestätigt) oder false.
export function askConfirm(options) {
  return new Promise(function (resolve) {
    const scrim = document.createElement('div');
    scrim.className = 'le-scrim';
    const box = document.createElement('div');
    box.className = 'le-dialog';
    box.setAttribute('role', 'alertdialog');
    box.setAttribute('aria-modal', 'true');
    box.tabIndex = -1;
    const title = document.createElement('div');
    title.className = 'le-dialog__title';
    title.textContent = options.title;
    box.setAttribute('aria-label', options.title);
    box.appendChild(title);
    if (options.text) {
      const text = document.createElement('p');
      text.textContent = options.text;
      box.appendChild(text);
    }
    const done = function (result) {
      scrim.remove();
      box.remove();
      resolve(result);
    };
    const actions = document.createElement('div');
    actions.className = 'le-dialog__actions';
    const ok = editorButton(options.confirm, options.danger ? 'le-btn le-btn--danger' : 'le-btn', function () { done(true); });
    actions.append(editorButton(CONFIRM_TEXT.cancel, 'le-btn le-btn--secondary', function () { done(false); }), ok);
    box.appendChild(actions);
    box.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') {
        event.stopPropagation();
        done(false);
      }
    });
    scrim.addEventListener('click', function () { done(false); });
    editorRoot().append(scrim, box);
    ok.focus({ preventScroll: true });
  });
}
