import { state, getContentPath } from '../modules/core.js';
import { sanitizeTextMarkup, sanitizeUrl } from './text-markup.js';
import { editorApi } from './request.js';

// Abgleich der Seite mit state.content: zeigt die Werte so, wie das Speichern sie in die Datei
// schreibt (Seiten-Editor, auch in der Backend-Seitenansicht).

// Markierungen aus dem Import: Feld des Elements (Text, Link-Ziel, Bild), Linktext, Alt-Text, Hintergrund.
export const EDIT_ATTR = {
  id: 'data-edit-id',
  text: 'data-edit-text-id',
  alt: 'data-edit-alt-id',
  bg: 'data-edit-bg-id'
};
// Feldarten aus getPage (EDIT_KIND_BY_TARGET und linktext im Server).
export const FIELD_KIND = {
  text: 'text',
  linktext: 'linktext',
  url: 'url',
  image: 'image',
  alt: 'alt',
  background: 'background',
  // Reiner Text in einem Rohtext-Element (<title>) oder in <meta content> (Seitenbeschreibung):
  // ohne Auszeichnung, als Text gesetzt.
  plain: 'plain',
  // <svg>, Wert ist der Name eines Icons aus dem Satz (core/icons.php).
  icon: 'icon'
};
// Feldarten mit Auszeichnung (Fett, Kursiv, Link), bearbeitet als contenteditable.
export const TEXT_KINDS = [FIELD_KIND.text, FIELD_KIND.linktext];

function attrSelector(name) {
  return '[' + name + ']';
}

// Elemente, die ein Feld tragen (Text, Link, Bild, Hintergrund).
export const EDIT_TARGET_SELECTOR = [EDIT_ATTR.id, EDIT_ATTR.text, EDIT_ATTR.bg].map(attrSelector).join(',');
export const BACKGROUND_SELECTOR = attrSelector(EDIT_ATTR.bg);
// Ein Text mit einem weiteren Feld darin (Altformat) lässt sich nicht speichern (Grund „nested“).
const NESTED_FIELD_SELECTOR = [EDIT_ATTR.id, EDIT_ATTR.text].map(attrSelector).join(',');

// Wert eines Feldes als Text; fehlt er (Feld ohne Wert in getPage), ist er leer, nie „undefined“.
export function fieldValue(path) {
  const value = getContentPath(path);
  return typeof value === 'string' ? value : '';
}

// Hat das Feld einen Wert? Nur solche Felder lassen sich bearbeiten (sonst fehlte der alte Wert).
export function hasFieldValue(path) {
  return typeof getContentPath(path) === 'string';
}

export function hasNestedField(el) {
  return el.querySelector(NESTED_FIELD_SELECTOR) !== null;
}

// Feld eines Elements nach Attribut: data-edit-id (Bild, Link, Text), sonst die Text-ID
// (Link ohne speicherbares Ziel), sonst das Hintergrundbild. Was bearbeitet wird, bestimmt die
// Feldart vom Server (state.fieldKinds). Trägt ein Text oder Link zusätzlich einen Hintergrund,
// steht er in bgPath; textPath ist der Linktext eines Link-Ziels, altPath der Alt-Text eines Bildes.
export function editableField(target) {
  const id = target.getAttribute(EDIT_ATTR.id);
  const textId = target.getAttribute(EDIT_ATTR.text);
  const bgId = target.getAttribute(EDIT_ATTR.bg) || '';
  if (id) {
    return { path: id, textPath: textId || '', altPath: target.getAttribute(EDIT_ATTR.alt) || '', bgPath: bgId };
  }
  if (textId) return { path: textId, textPath: '', altPath: '', bgPath: bgId };
  return { path: bgId, textPath: '', altPath: '', bgPath: '' };
}

// Fläche eines Elements in Ansichtskoordinaten, bei Text samt Zeilen, die aus ihm herausragen.
export function fieldRect(target) {
  const elementRect = target.getBoundingClientRect();
  const doc = target.ownerDocument;
  if (target.tagName.toLowerCase() === 'img' || target instanceof SVGElement || !doc.createRange) {
    return { left: elementRect.left, top: elementRect.top, width: elementRect.width, height: elementRect.height };
  }
  const range = doc.createRange();
  range.selectNodeContents(target);
  const rects = Array.prototype.slice.call(range.getClientRects()).filter(function (part) {
    return part.width > 0 && part.height > 0;
  });
  if (!rects.length) {
    return { left: elementRect.left, top: elementRect.top, width: elementRect.width, height: elementRect.height };
  }
  const box = rects.reduce(function (acc, part) {
    return {
      left: Math.min(acc.left, part.left),
      top: Math.min(acc.top, part.top),
      right: Math.max(acc.right, part.right),
      bottom: Math.max(acc.bottom, part.bottom)
    };
  }, { left: elementRect.left, top: elementRect.top, right: elementRect.right, bottom: elementRect.bottom });
  return { left: box.left, top: box.top, width: box.right - box.left, height: box.bottom - box.top };
}

// Innenbereich der Textfelder wie geladen (mit Klassen und Attributen an Inline-Kindern).
const loadedTexts = new WeakMap();

// Text wird als bereinigtes Fragment gesetzt, Linktext ohne eigene Links (Feldart aus getPage).
// Ein Element mit einem weiteren Feld darin (Altformat) bleibt stehen, wie beim Speichern
// (Grund „nested“). Entspricht der Wert der bereinigten Form beim Laden, gilt wieder der
// geladene Innenbereich – so behalten unveränderte Felder ihre Klassen, auch nach Abbrechen.
export function setTextMarkup(el, path) {
  const value = getContentPath(path);
  if (typeof value !== 'string' || hasNestedField(el)) return;
  if (!loadedTexts.has(el)) loadedTexts.set(el, el.innerHTML);
  const loaded = loadedTexts.get(el);
  const inLink = state.fieldKinds[path] === FIELD_KIND.linktext;
  const html = sanitizeTextMarkup(value, inLink);
  const next = sanitizeTextMarkup(loaded, inLink) === html ? loaded : html;
  if (el.innerHTML !== next) el.innerHTML = next;
}

function syncElementValue(el, path) {
  const value = getContentPath(path);
  if (typeof value !== 'string') return;
  const tag = el.tagName.toLowerCase();
  if (tag === 'img') { setImageSource(el, value); return; }
  if (state.fieldKinds[path] === FIELD_KIND.icon) { setIcon(el, value); return; }
  // Link-Ziel nach derselben Schemaregel wie Textlinks, auch wenn die ID nicht auf .url endet.
  if (tag === 'a') { el.href = sanitizeUrl(value, state.textMarkup.linkSchemes); return; }
  // Seitenbeschreibung: Wert im content-Attribut (EDIT_ATTR_BY_TAG im Server).
  if (tag === 'meta') { el.setAttribute('content', value); return; }
  if (state.fieldKinds[path] === FIELD_KIND.plain) { el.textContent = value; return; }
  setTextMarkup(el, path);
}

// Bilder und Hintergründe beim ersten Abgleich nach dem Laden: Feldwert und src bzw. Ebenen.
// Solange der Feldwert gleich bleibt, bleibt das Element wie geladen, wie die Datei beim Speichern
// (auch bei nicht kanonischen Werten wie data:-Platzhaltern mit srcset).
const loadedImages = new WeakMap();
const loadedBackgrounds = new WeakMap();

function loadedState(map, el, value, snapshot) {
  if (!map.has(el)) map.set(el, Object.assign({ value: value }, snapshot));
  return map.get(el);
}

// Neuer src wie beim Speichern (image_variant_removals): srcset/sizes und in <picture> die
// <source>-Geschwister fallen weg, sonst zeigte der Browser weiter das alte Bild daraus.
// Zurück auf den geladenen Wert (Abbrechen) kommen sie wieder, wie auf der Live-Seite.
export function setImageSource(el, value) {
  const loaded = loadedState(loadedImages, el, value, { src: el.getAttribute('src'), removed: null });
  if (value === loaded.value) {
    if (loaded.removed) restoreImageVariants(el, loaded.removed);
    loaded.removed = null;
    if (loaded.src !== null && el.getAttribute('src') !== loaded.src) el.setAttribute('src', loaded.src);
    return;
  }
  if (!loaded.removed) loaded.removed = removeImageVariants(el);
  el.src = value;
}

// Entfernt die Varianten und liefert, was zum Wiedereinsetzen nötig ist.
function removeImageVariants(el) {
  const variants = state.imageVariants;
  const removed = { attrs: [], nodes: [] };
  variants.attrs.forEach(function (name) {
    if (!el.hasAttribute(name)) return;
    removed.attrs.push([name, el.getAttribute(name)]);
    el.removeAttribute(name);
  });
  const parent = el.parentElement;
  if (parent && parent.tagName.toLowerCase() === variants.picture) {
    Array.prototype.slice.call(parent.children).forEach(function (child) {
      if (child.tagName.toLowerCase() !== variants.source) return;
      removed.nodes.push({ node: child, parent: parent, next: child.nextSibling });
      child.remove();
    });
  }
  return removed;
}

// Rückwärts einsetzen, damit jeder Knoten vor seinem damaligen Nachbarn landet.
function restoreImageVariants(el, removed) {
  removed.nodes.slice().reverse().forEach(function (entry) {
    entry.parent.insertBefore(entry.node, entry.next);
  });
  removed.attrs.forEach(function (attr) { el.setAttribute(attr[0], attr[1]); });
}

// Icons (api/icons.php), einmal geladen: { list: [{ name, svg, words }], byName, attrs, defaults }.
let iconSet = null;
let iconSetLoading = null;
const loadedIcons = new WeakMap();

export function loadIconSet() {
  if (!iconSetLoading) {
    iconSetLoading = editorApi('/api/icons.php').then(function (data) {
      const byName = {};
      data.icons.forEach(function (entry) { byName[entry.name] = entry.svg; });
      iconSet = { list: data.icons, byName: byName, attrs: data.attrs, defaults: data.defaults };
      return iconSet;
    }, function (error) {
      iconSetLoading = null;
      throw error;
    });
  }
  return iconSetLoading;
}

// Icon wie beim Speichern (le_icon_replacements): Inhalt aus dem Satz, attrs immer, defaults nur,
// wenn sie fehlen. Zurück auf den geladenen Wert (Abbrechen, Rückgängig) gilt wieder das SVG wie
// geladen; ein leerer Wert (SVG, das keinem Icon gleicht) ändert nichts.
export function setIcon(el, value) {
  const names = iconSet ? Object.keys(iconSet.attrs).concat(Object.keys(iconSet.defaults)) : [];
  const loaded = loadedState(loadedIcons, el, value, { html: el.innerHTML, attrs: {} });
  names.forEach(function (name) {
    if (!(name in loaded.attrs)) loaded.attrs[name] = el.getAttribute(name);
  });
  if (value === loaded.value) {
    if (el.innerHTML !== loaded.html) el.innerHTML = loaded.html;
    names.forEach(function (name) {
      if (loaded.attrs[name] === null) el.removeAttribute(name);
      else el.setAttribute(name, loaded.attrs[name]);
    });
    return;
  }
  if (!iconSet || !iconSet.byName[value]) return;
  el.innerHTML = iconSet.byName[value];
  Object.keys(iconSet.attrs).forEach(function (name) { el.setAttribute(name, iconSet.attrs[name]); });
  Object.keys(iconSet.defaults).forEach(function (name) {
    if (loaded.attrs[name] === null) el.setAttribute(name, iconSet.defaults[name]);
  });
}

// Erstes url(…) in style.backgroundImage, wie Browser es serialisieren (url("…") mit \-Escapes);
// andere Ebenen wie Verläufe bleiben.
const BACKGROUND_URL_PATTERN = /url\("(?:[^"\\]|\\.)*"\)/;

// CSS-String wie CSSOM ihn serialisiert: " und \ mit Backslash, Steuerzeichen als Hex-Escape.
function cssString(value) {
  return '"' + value.replace(/[\x00-\x1f\x7f"\\]/g, function (ch) {
    return ch === '"' || ch === '\\' ? '\\' + ch : '\\' + ch.charCodeAt(0).toString(16) + ' ';
  }) + '"';
}

// Leerer Wert = Ebene „none“ (url("") fragte die Seite selbst als Bild an).
export function setBackgroundImage(el, value) {
  if (typeof value !== 'string') return;
  const loaded = loadedState(loadedBackgrounds, el, value, { layers: el.style.backgroundImage });
  if (value === loaded.value) {
    el.style.backgroundImage = loaded.layers;
    return;
  }
  const layer = value === '' ? 'none' : 'url(' + cssString(value) + ')';
  el.style.backgroundImage = BACKGROUND_URL_PATTERN.test(loaded.layers)
    ? loaded.layers.replace(BACKGROUND_URL_PATTERN, function () { return layer; })
    : layer;
}

// Alle Felder eines Dokuments auf state.content setzen. Linktexte kommen nur über ihre
// Markierung (data-edit-text-id), ein Link mit Icon hat keine. Der erste Aufruf nach dem
// Laden merkt sich den geladenen Zustand (siehe oben), muss also vor dem Bearbeiten laufen.
export function syncDocument(doc) {
  const each = function (attr, fn) {
    Array.prototype.forEach.call(doc.querySelectorAll(attrSelector(attr)), function (el) {
      fn(el, el.getAttribute(attr));
    });
  };
  each(EDIT_ATTR.alt, function (el, path) {
    if (hasFieldValue(path)) el.alt = getContentPath(path);
  });
  each(EDIT_ATTR.bg, function (el, path) { setBackgroundImage(el, getContentPath(path)); });
  each(EDIT_ATTR.id, syncElementValue);
  each(EDIT_ATTR.text, setTextMarkup);
}
