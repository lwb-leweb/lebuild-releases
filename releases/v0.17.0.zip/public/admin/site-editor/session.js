import { state, applyPageContent, updateContentPath, registerPageSync, setNested, logout } from '../modules/core.js';
import { editorApi, editorPost } from './request.js';
import { syncDocument } from './page-sync.js';
import { addBarButton, setBarStatus, iconButton, notify, notifyError, BAR_TEXT } from './bar.js';
import { uploadPending, uploadForm } from './upload.js';
import { isPanelDirty } from './panel.js';
import { askConfirm } from './confirm.js';

// Bearbeitungs-Kern des Seiten-Editors: Inhalte der Seite, Liste der ungespeicherten Änderungen
// (Rückgängig), die eine laufende Bearbeitung, Speichern aller Änderungen auf einmal und die
// Warnung beim Verlassen (auch beim Abmelden).

export const SESSION_TEXT = {
  save: 'Speichern',
  undo: 'Rückgängig',
  saved: 'Gespeichert – die Änderungen sind jetzt online.',
  // getPage hat eine direkt geänderte Datei abgeglichen (refreshed): neu laden, damit neue Bereiche bearbeitbar sind.
  refreshed: 'Die Seite wurde inzwischen direkt geändert und neu geladen.',
  logoutTitle: 'Abmelden und Änderungen verwerfen?',
  logoutText: 'Was du geändert hast, ist noch nicht gespeichert.'
};
// Hinweis über das Neuladen hinweg (nach Speichern und Wiederherstellen), erscheint danach.
const NOTE_KEY = 'le-site-editor-note';
// Rückgängig ist Nebenaktion neben Speichern (bar.css: runder Knopf nur mit Symbol).
const UNDO_CLASS = 'le-icon-btn';
const SAVE_CLASS = 'le-icon-btn le-bar__save';

// Je Eintrag eine Aktion (Text übernehmen, Link, Bild mit Alt-Text, Hintergrund):
// [{ path, before, after }, …]. Rückgängig nimmt den letzten Eintrag zurück.
const changes = [];
// Laufende Bearbeitung: { contains(node), handlers, escape() → bool (Esc selbst behandelt),
// isDirty(), commit() → bool, cancel(), close() }.
let active = null;
// Inhalt beim Laden, nach einem Speichern mit Konflikten samt der gespeicherten Werte: Gegen ihn
// prüft der Server je Feld, ob es seitdem jemand anderes geändert hat (merge_save_content).
let base = null;
let saving = false;
// Abmelden ist bestätigt: Das Neuladen danach warnt nicht noch einmal.
let leaving = false;
let saveButton = null;
let undoButton = null;
// Wer wissen muss, dass sich Werte geändert haben (Übernehmen, Rückgängig): „Alle Texte“.
const changeListeners = [];
// Alle Bild-Uploads dieser Seite (Dialog am Bild, „Alle Texte“, Ablegen auf der Seite) sind ein Formular:
// Es schließt sich beim Verlassen bzw. Neuladen (auch nach dem Speichern), dann löscht der Server, was
// nicht gespeichert ist; Uploads aus einem abgebrochenen Dialog erledigt der Dialog gleich selbst.
export const pageUploads = uploadForm();

// Speichern-Request: ganzer Inhalt der Seite samt Komponenten und der Stand beim Laden. Scheitert
// er (auch an abgelaufener Anmeldung, request.js), bleiben die Änderungen in der Liste.
function postPage() {
  return editorPost('/api/savePage.php', { page: state.currentPage, content: state.content, base: base });
}

// Alle Felder der Seite auf state.content setzen.
export function resync() {
  syncDocument(document);
}

function render() {
  const count = changes.length;
  const dirty = active !== null && active.isDirty();
  setBarStatus(count, dirty, saving);
  saveButton.disabled = saving || (!count && !dirty);
  undoButton.disabled = saving || (!count && !dirty);
}

// Läuft ein Speichern? Solange nimmt die Seite keine Eingaben an (interact.js); nach Erfolg lädt sie
// neu, bei Fehler oder Konflikten ist sie gleich wieder frei, und die Änderungen bleiben.
export function isSaving() {
  return saving;
}

// Knöpfe neu bewerten, wenn sich eine laufende Bearbeitung ändert (Tippen, Upload, Alt-Text).
export function editChanged() {
  render();
}

// Übernimmt die geänderten Werte einer Aktion als einen Eintrag; ohne Unterschied keiner.
export function record(values) {
  const changed = values.filter(function (value) { return value.before !== value.after; });
  if (!changed.length) return;
  changed.forEach(function (value) { updateContentPath(value.path, value.after); });
  changes.push(changed);
  render();
  notifyChange();
}

export function onContentChange(fn) {
  changeListeners.push(fn);
}

function notifyChange() {
  changeListeners.forEach(function (fn) { fn(); });
}

// Gibt es etwas, das beim Verlassen oder Neuladen verloren ginge (auch ein laufender Upload oder ein
// geändertes Eintragsformular im Panel)?
export function hasUnsavedChanges() {
  return changes.length > 0 || (active !== null && active.isDirty()) || uploadPending(null) || isPanelDirty();
}

export function activeEdit() {
  return active;
}

// Neue Bearbeitung; eine laufende muss vorher beendet sein (endEdit).
export function beginEdit(editor) {
  active = editor;
  render();
}

// Laufende Bearbeitung übernehmen (commit) oder verwerfen. false, wenn das Übernehmen
// scheitert (z. B. unerlaubtes Link-Ziel): dann bleibt sie offen.
export function endEdit(commit) {
  if (!active) return true;
  if (commit) {
    if (active.commit() === false) return false;
  } else {
    active.cancel();
  }
  const editor = active;
  active = null;
  editor.close();
  render();
  return true;
}

// Während einer geänderten Bearbeitung verwirft Rückgängig nur diese; eine unveränderte schließt
// es und nimmt gleich die letzte Änderung zurück.
function undo() {
  if (active) {
    const dirty = active.isDirty();
    endEdit(false);
    if (dirty) return;
  }
  const last = changes.pop();
  if (!last) return;
  last.slice().reverse().forEach(function (value) { updateContentPath(value.path, value.before); });
  render();
  notifyChange();
}

// Strg+S (save-key.js): wie der Knopf Speichern; ohne Änderungen oder während eines Speicherns nichts.
export function savePage() {
  save();
}

function save() {
  if (saving || uploadPending(notify) || !endEdit(true) || !changes.length) return;
  saving = true;
  render();
  postPage()
    .then(function (data) {
      if (data.conflicts.length) {
        keepConflicts(data);
        return;
      }
      reloadWithNote(SESSION_TEXT.saved);
    })
    .catch(function (error) {
      saving = false;
      render();
      notifyError(error);
    });
}

// Gespeichert bis auf Felder, die inzwischen jemand anderes geändert hat: Die gespeicherten Werte
// (in der Form, wie getPage sie liefert) werden Stand beim Laden, in der Änderungsliste bleiben nur
// die Konflikte. Die Seite lädt nicht neu, sonst gingen sie verloren; die Meldung rät dazu.
function keepConflicts(data) {
  const open = data.conflicts.map(function (field) { return field.id; });
  Object.keys(data.saved).forEach(function (path) {
    setNested(base, path, data.saved[path]);
    updateContentPath(path, data.saved[path]);
  });
  const left = changes.map(function (values) {
    return values.filter(function (value) { return open.indexOf(value.path) !== -1; });
  }).filter(function (values) { return values.length > 0; });
  changes.splice(0, changes.length, ...left);
  saving = false;
  render();
  notifyChange();
  notify(data.message);
}

// Lädt die Seite neu (sie zeigt dann, was in der Datei steht) und zeigt danach message.
// Ungespeichertes verwirft es ohne Warnung; wer fragen muss, fragt vorher (hasUnsavedChanges).
export function reloadWithNote(message) {
  endEdit(false);
  changes.length = 0;
  try { window.sessionStorage.setItem(NOTE_KEY, message); } catch (e) { /* ohne Speicher kein Hinweis */ }
  window.location.reload();
}

// Hinweis von vor dem Neuladen (reloadWithNote) und der von getPage (extra, z. B. Fußzeile mit gescheitertem
// Abgleich), einmal zusammen; steht extra schon im ersten (Hinweis von restore), nicht doppelt.
function showNote(extra) {
  let message = null;
  try {
    message = window.sessionStorage.getItem(NOTE_KEY);
    window.sessionStorage.removeItem(NOTE_KEY);
  } catch (e) { /* ohne Speicher nur extra */ }
  if (extra && !(message || '').includes(extra)) message = message ? message + ' ' + extra : extra;
  if (message) notify(message);
}

function warnOnLeave(event) {
  if (leaving || !hasUnsavedChanges()) return;
  event.preventDefault();
  event.returnValue = '';
}

// Warnung beim Verlassen, auch ohne Inhalte der Seite (Eintragsformular einer Plugin-Liste).
export function watchLeaving() {
  window.addEventListener('beforeunload', warnOnLeave);
}

// „Abmelden“ in der Leiste: Bei Ungespeichertem erst nachfragen wie beim Verlassen; bestätigt, warnt
// das Neuladen danach nicht noch einmal. Scheitert das Abmelden, gilt die Warnung wieder.
export function logoutChecked() {
  const ask = hasUnsavedChanges()
    ? askConfirm({ title: SESSION_TEXT.logoutTitle, text: SESSION_TEXT.logoutText, confirm: BAR_TEXT.logout, danger: true })
    : Promise.resolve(true);
  return ask.then(function (yes) {
    if (!yes) return null;
    leaving = true;
    return logout().catch(function (error) {
      leaving = false;
      throw error;
    });
  });
}

// Lädt die Felder der Seite, gleicht die Seite einmal ab (merkt den geladenen Stand) und hängt
// Speichern und Rückgängig in die Leiste.
export function startSession(page) {
  return editorApi('/api/getPage.php?page=' + encodeURIComponent(page)).then(function (data) {
    if (data.refreshed) {
      reloadWithNote(SESSION_TEXT.refreshed);
      return;
    }
    applyPageContent(page, data);
    base = structuredClone(data.content);
    registerPageSync(resync);
    resync();
    undoButton = addBarButton(iconButton('undo', SESSION_TEXT.undo, UNDO_CLASS, undo));
    saveButton = addBarButton(iconButton('save', SESSION_TEXT.save, SAVE_CLASS, save));
    render();
    showNote(data.message);
  });
}
