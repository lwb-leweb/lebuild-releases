// Kurzer Hinweis unten (Backend: document.body, Seiten-Editor: sein Shadow-DOM), Stil in toast.css.
// Eine Meldung je Oberfläche, eine neue ersetzt die alte.
// Mindestens TOAST_MS, längere Meldungen (z. B. Konflikt beim Speichern) je Zeichen länger.
const TOAST_MS = 3000;
const TOAST_MS_PER_CHAR = 60;
const TOAST_CLASS = 'le-toast';
const TOAST_VISIBLE_CLASS = 'le-toast--visible';
const timers = new WeakMap();

// Mit Knopf (action, z. B. „Neu anmelden“) bleibt der Hinweis länger stehen, damit man ihn erreicht.
const TOAST_ACTION_MS = 12000;

// action (optional): fertiger Knopf, der hinter dem Text steht.
export function showToast(message, parent, action) {
  let host = Array.prototype.find.call(parent.children, function (el) { return el.classList.contains(TOAST_CLASS); });
  if (!host) {
    host = document.createElement('div');
    host.className = TOAST_CLASS;
    host.setAttribute('role', 'status');
    host.setAttribute('aria-live', 'polite');
    parent.appendChild(host);
  }
  host.textContent = message;
  if (action) host.append(' ', action);
  host.classList.add(TOAST_VISIBLE_CLASS);
  clearTimeout(timers.get(host));
  timers.set(host, setTimeout(function () {
    host.classList.remove(TOAST_VISIBLE_CLASS);
  }, Math.max(action ? TOAST_ACTION_MS : TOAST_MS, message.length * TOAST_MS_PER_CHAR)));
}
