import { state, isAdmin, ADMIN_URL, pageRoute } from '../modules/core.js';
import { showToast } from './toast.js';
import { errorNotice } from './request.js';
import { icon } from './icons.js';
import { buildBlob, runBlob } from './blob.js';
import { ENTRY_TEXT } from './entry-form.js';
import { editorButton, keepSelection } from './buttons.js';

export { editorButton, keepSelection };

// Leiste auf der Website: eine schwebende Pille nur mit Symbolen – Logo (Klick klappt sie ein bis aufs
// Logo, Ziehen verschiebt sie über den ganzen Bildschirm), Schalter Bearbeiten (an/aus = Ansehen),
// Rückgängig, Speichern und „Mehr“ (Verlauf, „Alle Texte“, Hilfe, Verwaltung, Abmelden). Was ein
// Symbol tut, sagt ein Tooltip mittig darüber; ist etwas offen, hängt der Stand („2 ungespeichert“)
// als Lasche an der Leiste. Lage und Einklappen merkt sich der
// Browser. Alles lebt in einem Shadow-DOM, damit Kunden-CSS und Editor-CSS sich nicht gegenseitig
// verändern; alle Klassen tragen das Präfix le-. Beim ersten Besuch erklärt ein Hinweis, wie es geht.
const BAR_TAG = 'le-site-editor';
// Token des Design Systems (core/siteEditor.php SITE_EDITOR_TOKENS, dort auch im Dokument für die Schrift).
const TOKENS_STYLE = new URL('../design/tokens.css', import.meta.url).href;
const BAR_STYLE = new URL('bar.css', import.meta.url).href;
const TOAST_STYLE = new URL('toast.css', import.meta.url).href;
// Klasse am <html>, solange die Leiste da ist; page.css hält damit unten Platz frei.
const PAGE_CLASS = 'le-editing';
// Klasse am <html>, wenn die Leiste nicht unten steht: page.css gibt den Platz unten wieder frei.
const FREE_CLASS = 'le-bar-free';
// Klasse an <html> und am Host in der Ansicht „Ansehen“: die Seite wie Besucher sie sehen.
const PREVIEW_CLASS = 'le-preview';
// Klassen am Host: eingeklappt (nur Logo), Leiste in der oberen Hälfte (Tooltip, Menü und Hinweis
// darunter statt darüber), gerade gezogen.
const COLLAPSED_CLASS = 'le-collapsed';
const TOP_CLASS = 'le-bar-top';
const DRAGGING_CLASS = 'le-dragging';
// Klasse am Host, solange die Leiste zum Kreis zusammengeht oder wieder aufgeht (foldBar).
const FOLDING_CLASS = 'le-folding';
const FOLD_MS = 320;
const FOLD_EASING = 'cubic-bezier(0.3, 0.9, 0.3, 1)';
// Will der Browser wenig Bewegung, steht der Tropfen hinter der eingeklappten Leiste still (blob.js).
const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
// Klasse am Host, wenn der Browser wenig Bewegung will: Lasche und Punkt des Stands stehen still.
const STILL_CLASS = 'le-still';
export const BAR_TEXT = {
  label: 'Website bearbeiten',
  // Platzhalter, bis Name und Logo feststehen.
  product: 'LeBuild',
  logoMark: 'LE',
  collapseNote: 'Klicken: einklappen · Ziehen: verschieben',
  expandNote: 'Klicken: ausklappen · Ziehen: verschieben',
  edit: ENTRY_TEXT.edit,
  editOn: 'Bearbeiten ist an',
  editOnNote: 'Klicken, um die Seite wie Besucher anzusehen',
  editOff: 'Ansehen wie Besucher',
  editOffNote: 'Klicken, um wieder zu bearbeiten',
  admin: 'Verwaltung',
  adminHint: 'Benutzer, Einstellungen, Plugins',
  logout: 'Abmelden',
  logoutHint: 'Angemeldet als ',
  help: 'Hilfe',
  helpHint: 'Die kurze Anleitung noch einmal zeigen',
  more: 'Mehr',
  editing: 'Wird bearbeitet',
  unsaved: 'ungespeichert',
  saving: 'Speichert…',
  hintTitle: 'So einfach geht’s',
  hintMouse: 'Fahre mit der Maus über die Seite: Alles, was grün aufleuchtet, kannst du anklicken und ändern. Danach auf „Speichern“ – dann ist es sofort online.',
  hintTouch: 'Tippe auf einen Text oder ein Bild: Es leuchtet grün auf, ein zweites Antippen ändert es. Danach auf „Speichern“ – dann ist es sofort online.',
  hintOk: 'Verstanden'
};
// Hinweis beim ersten Besuch: einmal je Browser (localStorage), über „Hilfe“ wieder.
const HINT_KEY = 'le-site-editor-hint-seen';
// „Ansehen“ gilt im Tab weiter, auch über Seitenwechsel (sessionStorage).
const PREVIEW_KEY = 'le-site-editor-preview';
// Lage der Leiste ({x, y}: linke Kante als Anteil der Breite, Oberkante als Anteil des Platzes
// darüber, damit „unten“ auch im größeren Fenster unten bleibt) und Eingeklappt, je Browser.
const POSITION_KEY = 'le-site-editor-bar-position';
const COLLAPSED_KEY = 'le-site-editor-bar-collapsed';
// Ab so vielen Pixeln Bewegung ist ein Druck aufs Logo Ziehen statt Klick.
const DRAG_START = 4;
// Bis zu dieser Breite (Handy) zeigt der Stand nur Punkt und Zahl, und Dialoge und Seitenpanel gehen
// über die ganze Breite (overlay.js). Die einzige Stelle für die Grenze: bar.css und edit.css
// richten sich nach der Klasse am Host (:host(.le-narrow)), nicht nach einer eigenen Media Query.
const NARROW_MAX = 480;
const NARROW_CLASS = 'le-narrow';
const narrowQuery = window.matchMedia('(max-width: ' + NARROW_MAX + 'px)');
const touchQuery = window.matchMedia('(hover: none)');

export function isNarrow() {
  return narrowQuery.matches;
}

let bar = null;
let logo = null;
let actions = null;
let menu = null;
// Trenner vor Verwaltung und Abmelden; Einträge über addMenuButton kommen davor (ohne ihn ans Ende).
let menuFixed = null;
let more = null;
let help = null;
let status = null;
let hint = null;
let tip = null;
let tipTarget = null;
let modeButton = null;
let host = null;
let root = null;
let preview = false;
let collapsed = false;
// Gespeicherte Lage oder null (unten in der Mitte).
let position = null;
// Laufendes Ziehen am Logo: { id, x, y, left, top, moved }.
let drag = null;
let swallowClick = false;
// Laufendes Ein- oder Ausklappen: { bar, parts } (Animationen), sonst null.
let fold = null;
// Wer beim Wechsel Bearbeiten/Ansehen etwas tun muss (interact.js): fn(preview) → false hält den Wechsel auf.
const modeListeners = [];

// Knopf nur mit Symbol; label als aria-label und Tooltip.
export function iconButton(name, label, className, onClick) {
  const button = editorButton('', className, onClick);
  button.append(icon(name));
  button.setAttribute('aria-label', label);
  button.title = label;
  return button;
}

// Knopf mit Symbol vor dem Text.
export function labeledButton(name, label, className, onClick) {
  const button = editorButton('', className, onClick);
  const text = document.createElement('span');
  text.textContent = label;
  button.append(icon(name), text);
  return button;
}

// In der Backend-Seitenansicht (iframe in einer Seite derselben Website) haben Verwaltung und
// Abmelden ihren Platz im Backend; Abmelden lüde dort nur den iframe neu.
function inBackendFrame() {
  try {
    return window.top !== window && window.top.location.origin === window.location.origin;
  } catch (e) {
    return false;
  }
}


function link(href, className) {
  const el = document.createElement('link');
  el.rel = 'stylesheet';
  el.href = href;
  if (className) el.className = className;
  return el;
}

// Eintrag im Menü „Mehr“: Symbol, Titel, eine Zeile Erklärung darunter.
function menuEntry(name, label, note, tag) {
  const entry = document.createElement(tag || 'button');
  entry.className = 'le-menu__entry';
  if (entry.tagName === 'BUTTON') entry.type = 'button';
  const text = document.createElement('span');
  text.className = 'le-menu__text';
  const title = document.createElement('span');
  title.append(label);
  text.appendChild(title);
  if (note) {
    const small = document.createElement('small');
    small.textContent = note;
    text.appendChild(small);
  }
  entry.append(icon(name), text);
  return entry;
}

function storedHintSeen() {
  try {
    return window.localStorage.getItem(HINT_KEY) === '1';
  } catch (e) {
    return false;
  }
}

function storedPreview() {
  try {
    return window.sessionStorage.getItem(PREVIEW_KEY) === '1';
  } catch (e) {
    return false;
  }
}

function storePreview(value) {
  try {
    if (value) window.sessionStorage.setItem(PREVIEW_KEY, '1');
    else window.sessionStorage.removeItem(PREVIEW_KEY);
  } catch (e) { /* ohne Speicher beginnt jede Seite mit Bearbeiten */ }
}

function buildHint() {
  const box = document.createElement('div');
  box.className = 'le-hint';
  box.setAttribute('role', 'note');
  const badge = document.createElement('span');
  badge.className = 'le-hint__icon';
  badge.appendChild(icon('pointer'));
  const text = document.createElement('div');
  const title = document.createElement('strong');
  title.textContent = BAR_TEXT.hintTitle;
  const body = document.createElement('p');
  body.textContent = touchQuery.matches ? BAR_TEXT.hintTouch : BAR_TEXT.hintMouse;
  const ok = editorButton(BAR_TEXT.hintOk, 'le-btn le-btn--secondary le-btn--small', hideHint);
  text.append(title, body, ok);
  box.append(badge, text);
  box.hidden = true;
  return box;
}

export function showHint() {
  closeMenu();
  hint.hidden = false;
  placeNear(hint, false);
}

function hideHint() {
  hint.hidden = true;
  try { window.localStorage.setItem(HINT_KEY, '1'); } catch (e) { /* ohne Speicher kommt er beim nächsten Mal wieder */ }
}

// Bearbeiten/Ansehen; ein Zuhörer kann den Wechsel aufhalten (Bearbeitung lässt sich nicht übernehmen).
function setPreview(value) {
  if (value === preview) return;
  if (modeListeners.some(function (fn) { return fn(value) === false; })) return;
  storePreview(value);
  applyPreview(value);
  closeMenu();
  if (value) hint.hidden = true;
}

function applyPreview(value) {
  preview = value;
  host.classList.toggle(PREVIEW_CLASS, value);
  document.documentElement.classList.toggle(PREVIEW_CLASS, value);
  showModeState();
}

export function isPreview() {
  return preview;
}

export function onModeChange(fn) {
  modeListeners.push(fn);
}

// Schalter Bearbeiten: Stift (an) oder Auge (aus, also „Ansehen“), der Tooltip sagt beides.
function showModeState() {
  modeButton.setAttribute('aria-checked', String(!preview));
  modeButton.dataset.leTip = preview ? BAR_TEXT.editOff : BAR_TEXT.editOn;
  modeButton.dataset.leNote = preview ? BAR_TEXT.editOffNote : BAR_TEXT.editOnNote;
  modeButton.firstChild.replaceWith(icon(preview ? 'eye' : 'pencil'));
  refreshTip(modeButton);
}

function buildModeSwitch() {
  modeButton = editorButton('', 'le-mode', function () { setPreview(!preview); });
  modeButton.setAttribute('role', 'switch');
  modeButton.setAttribute('aria-label', BAR_TEXT.edit);
  modeButton.appendChild(document.createElement('span'));
  showModeState();
  return modeButton;
}

// Tooltip über dem Symbol unter Maus oder Tastaturfokus: Titel aus data-le-tip oder aria-label,
// darunter optional eine Zeile aus data-le-note. Steht die Leiste oben, kommt er darunter.
function buildTip() {
  const box = document.createElement('div');
  box.className = 'le-tip';
  box.setAttribute('role', 'tooltip');
  box.append(document.createElement('strong'), document.createElement('span'));
  return box;
}

function tipText(target) {
  return target.dataset.leTip || target.getAttribute('aria-label') || '';
}

function showTip(target) {
  if (drag && drag.moved) return;
  const title = tipText(target);
  if (!title) return;
  tipTarget = target;
  tip.firstChild.textContent = title;
  tip.lastChild.textContent = target.dataset.leNote || '';
  tip.lastChild.hidden = !target.dataset.leNote;
  const box = target.getBoundingClientRect();
  const size = tip.getBoundingClientRect();
  const edge = cssPx('--le-bar-offset');
  const gap = cssPx('--le-space-2');
  const center = box.left + box.width / 2;
  const left = clamp(center - size.width / 2, edge, viewWidth() - size.width - edge);
  const below = host.classList.contains(TOP_CLASS);
  tip.style.left = left + 'px';
  tip.style.top = (below ? box.bottom + gap : box.top - gap - size.height) + 'px';
  tip.style.setProperty('--le-tip-arrow', (center - left) + 'px');
  tip.classList.add('le-tip--visible');
}

function hideTip() {
  tipTarget = null;
  tip.classList.remove('le-tip--visible');
}

// Text eines Knopfs hat sich geändert, während sein Tooltip offen ist.
function refreshTip(target) {
  if (tipTarget === target) showTip(target);
}

function tipTargetOf(event) {
  const target = event.target.closest('button, a');
  return target && bar.contains(target) ? target : null;
}

function attachTips() {
  bar.addEventListener('pointerover', function (event) {
    if (event.pointerType === 'touch') return;
    const target = tipTargetOf(event);
    if (target && target !== tipTarget) showTip(target);
  });
  bar.addEventListener('pointerout', function (event) {
    if (tipTarget && !(event.relatedTarget && tipTarget.contains(event.relatedTarget))) hideTip();
  });
  bar.addEventListener('focusin', function (event) {
    const target = tipTargetOf(event);
    if (target && target.matches(':focus-visible')) showTip(target);
  });
  bar.addEventListener('focusout', hideTip);
  bar.addEventListener('pointerdown', hideTip);
}

// Breite ohne Scrollleiste, sonst läge die Leiste rechts darunter.
function viewWidth() {
  return document.documentElement.clientWidth || window.innerWidth;
}

function cssPx(name) {
  return parseFloat(window.getComputedStyle(host).getPropertyValue(name)) || 0;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(value, max));
}

function storedPosition() {
  try {
    const value = JSON.parse(window.localStorage.getItem(POSITION_KEY));
    return value && Number.isFinite(value.x) && Number.isFinite(value.y) ? { x: value.x, y: value.y } : null;
  } catch (e) {
    return null;
  }
}

function storeState() {
  try {
    window.localStorage.setItem(POSITION_KEY, JSON.stringify(position));
    if (collapsed) window.localStorage.setItem(COLLAPSED_KEY, '1');
    else window.localStorage.removeItem(COLLAPSED_KEY);
  } catch (e) { /* ohne Speicher beginnt jede Seite unten in der Mitte und ausgeklappt */ }
}

function storedCollapsed() {
  try {
    return window.localStorage.getItem(COLLAPSED_KEY) === '1';
  } catch (e) {
    return false;
  }
}

// Setzt die Leiste an ihre Lage (ohne gespeicherte unten in der Mitte), immer ganz im Fenster, und
// richtet Stand, Menü und Hinweis an ihr aus.
function placeBar() {
  const width = bar.offsetWidth;
  const height = bar.offsetHeight;
  const fullWidth = viewWidth();
  const viewHeight = window.innerHeight;
  const edge = cssPx('--le-bar-offset');
  let left = (fullWidth - width) / 2;
  let top = viewHeight - height - edge;
  if (position) {
    left = position.x * fullWidth;
    top = position.y * (viewHeight - height);
  }
  left = clamp(left, edge, fullWidth - width - edge);
  top = clamp(top, edge, viewHeight - height - edge);
  bar.style.left = left + 'px';
  bar.style.top = top + 'px';
  host.classList.toggle(TOP_CLASS, top + height / 2 < viewHeight / 2);
  // Beim Ziehen nicht, sonst springt die Seite unter dem Finger.
  if (!drag) document.documentElement.classList.toggle(FREE_CLASS, top + height < viewHeight - cssPx('--le-bar-space'));
  placeStatus();
  if (!menu.hidden) placeNear(menu, true);
  if (!hint.hidden) placeNear(hint, false);
}

// Stand als Lasche rechts auf der geraden Kante der Leiste (nicht in deren Rundung, mit Platz für die
// Kehlen der Lasche), über ihrem Rand; unter ihr, wenn sie oben steht und darüber kein Platz ist.
function placeStatus() {
  const box = bar.getBoundingClientRect();
  const width = status.offsetWidth;
  const height = status.offsetHeight;
  const edge = cssPx('--le-bar-offset');
  const line = cssPx('--le-line');
  const corner = cssPx('--le-radius-lg');
  const left = clamp(box.right - 2 * corner - cssPx('--le-space-2') - width, edge + corner, viewWidth() - width - edge - corner);
  const below = box.top - height < edge;
  status.classList.toggle('le-status--below', below);
  status.style.left = left + 'px';
  status.style.top = (below ? box.bottom - line : box.top - height + line) + 'px';
}

// Menü (end: so breit wie die Leiste, bündig) oder Hinweis (mittig) über der Leiste, steht sie oben, darunter.
function placeNear(el, end) {
  const box = bar.getBoundingClientRect();
  if (end) el.style.width = box.width + 'px';
  const width = el.offsetWidth;
  const edge = cssPx('--le-bar-offset');
  const gap = cssPx('--le-space-2');
  const left = end ? box.right - width : box.left + (box.width - width) / 2;
  el.style.left = clamp(left, edge, viewWidth() - width - edge) + 'px';
  el.style.top = (host.classList.contains(TOP_CLASS) ? box.bottom + gap : box.top - gap - el.offsetHeight) + 'px';
}

// animate: beim Klick aufs Logo; beim Laden steht die Leiste gleich richtig da.
function setCollapsed(value, animate) {
  const from = bar.offsetWidth;
  collapsed = value;
  stopFold();
  host.classList.toggle(COLLAPSED_CLASS, value);
  if (animate && !motionQuery.matches) foldBar(from);
  else runBlob(value, motionQuery.matches);
  logo.setAttribute('aria-expanded', String(!value));
  logo.dataset.leNote = value ? BAR_TEXT.expandNote : BAR_TEXT.collapseNote;
  if (value) {
    closeMenu();
    hint.hidden = true;
  }
  placeBar();
  refreshTip(logo);
}

// Ein- und Ausklappen als Bewegung: Die Leiste behält während der Animation ihre Pillenform und wird
// von der alten zur neuen Breite enger oder weiter, die Knöpfe blenden aus oder ein. Erst danach
// übernimmt eingeklappt der wabernde Tropfen (blob.js), der sanft anläuft.
function foldBar(from) {
  const to = bar.offsetWidth;
  const height = bar.offsetHeight;
  const round = height / 2 + 'px';
  const corner = cssPx('--le-radius-lg') + 'px';
  const shut = collapsed;
  host.classList.remove(COLLAPSED_CLASS);
  host.classList.add(FOLDING_CLASS);
  runBlob(false, true);
  const parts = Array.from(bar.children).filter(function (child) {
    return !child.classList.contains('le-bar__logo') && !child.classList.contains('le-bar__blob');
  });
  const timing = { duration: FOLD_MS, easing: FOLD_EASING };
  const shape = bar.animate([
    { width: from + 'px', borderRadius: shut ? corner : round },
    { width: to + 'px', borderRadius: shut ? round : corner },
  ], timing);
  fold = {
    bar: shape,
    parts: parts.map(function (part) {
      return part.animate([{ opacity: shut ? 1 : 0 }, { opacity: shut ? 0 : 1 }], {
        duration: FOLD_MS * 0.6,
        delay: shut ? 0 : FOLD_MS * 0.4,
        easing: 'ease',
        fill: 'both',
      });
    }),
  };
  shape.onfinish = function () {
    stopFold();
    host.classList.toggle(COLLAPSED_CLASS, collapsed);
    runBlob(collapsed, false);
    placeBar();
  };
}

function stopFold() {
  if (!fold) return;
  fold.bar.onfinish = null;
  fold.bar.cancel();
  fold.parts.forEach(function (part) { part.cancel(); });
  fold = null;
  host.classList.remove(FOLDING_CLASS);
}

// Logo: Klick klappt ein und aus, Ziehen (mit Maus wie Finger) verschiebt die Leiste.
function buildLogo() {
  logo = editorButton('', 'le-bar__logo', function () {
    if (swallowClick) {
      swallowClick = false;
      return;
    }
    setCollapsed(!collapsed, true);
    storeState();
  });
  logo.setAttribute('aria-label', BAR_TEXT.product);
  const mark = document.createElement('span');
  mark.className = 'le-bar__mark';
  mark.textContent = BAR_TEXT.logoMark;
  logo.appendChild(mark);
  logo.addEventListener('pointerdown', function (event) {
    swallowClick = false;
    if (event.button !== 0) return;
    const box = bar.getBoundingClientRect();
    drag = { id: event.pointerId, x: event.clientX, y: event.clientY, left: box.left, top: box.top, moved: false };
    logo.setPointerCapture(event.pointerId);
  });
  logo.addEventListener('pointermove', function (event) {
    if (!drag || event.pointerId !== drag.id) return;
    const dx = event.clientX - drag.x;
    const dy = event.clientY - drag.y;
    if (!drag.moved && Math.hypot(dx, dy) < DRAG_START) return;
    if (!drag.moved) {
      drag.moved = true;
      hideTip();
      closeMenu();
      host.classList.add(DRAGGING_CLASS);
    }
    const free = Math.max(1, window.innerHeight - bar.offsetHeight);
    position = { x: (drag.left + dx) / viewWidth(), y: (drag.top + dy) / free };
    placeBar();
  });
  const endDrag = function (event) {
    if (!drag || event.pointerId !== drag.id) return;
    const moved = drag.moved;
    drag = null;
    if (!moved) return;
    swallowClick = true;
    host.classList.remove(DRAGGING_CLASS);
    placeBar();
    storeState();
  };
  logo.addEventListener('pointerup', endDrag);
  logo.addEventListener('pointercancel', endDrag);
  return logo;
}

// page: Seite dieser Datei (null ohne); „Verwaltung“ öffnet sie im Backend. onLogout: „Abmelden“
// (logoutChecked in session.js: fragt bei Ungespeichertem nach), Promise; Fehler zeigt die Leiste.
export function mountBar(page, onLogout) {
  host = document.createElement(BAR_TAG);
  root = host.attachShadow({ mode: 'open' });

  bar = document.createElement('div');
  bar.className = 'le-bar';
  bar.setAttribute('role', 'toolbar');
  bar.setAttribute('aria-label', BAR_TEXT.label);

  status = document.createElement('div');
  status.className = 'le-status';
  status.setAttribute('role', 'status');

  actions = document.createElement('div');
  actions.className = 'le-bar__actions';

  menu = document.createElement('div');
  menu.className = 'le-menu';
  menu.hidden = true;
  if (!inBackendFrame()) {
    menuFixed = menu.appendChild(document.createElement('hr'));
    if (isAdmin()) {
      const admin = menuEntry('settings', BAR_TEXT.admin, BAR_TEXT.adminHint, 'a');
      admin.href = page === null ? ADMIN_URL : ADMIN_URL + '/' + pageRoute(encodeURIComponent(page));
      menu.appendChild(admin);
    }
    const out = menuEntry('logout', BAR_TEXT.logout, BAR_TEXT.logoutHint + state.username);
    out.addEventListener('click', function () {
      closeMenu();
      onLogout().catch(function (error) { notify(error.message); });
    });
    menu.appendChild(out);
  }

  more = withTip(iconButton('more', BAR_TEXT.more, 'le-icon-btn le-bar__more', function () {
    if (menu.hidden) {
      menu.hidden = false;
      hint.hidden = true;
      more.setAttribute('aria-expanded', 'true');
      placeNear(menu, true);
    } else {
      closeMenu();
    }
  }));
  more.setAttribute('aria-expanded', 'false');
  // Hilfe: vorerst der Hinweis vom ersten Besuch, ein zweiter Klick schließt ihn.
  help = withTip(iconButton('help', BAR_TEXT.help, 'le-icon-btn', function () {
    if (hint.hidden) showHint();
    else hideHint();
  }));
  help.dataset.leNote = BAR_TEXT.helpHint;
  hint = buildHint();
  tip = buildTip();

  const applyWidth = function () {
    host.classList.toggle(NARROW_CLASS, isNarrow());
    closeMenu();
  };
  const applyMotion = function () { host.classList.toggle(STILL_CLASS, motionQuery.matches); };
  motionQuery.addEventListener('change', function () {
    applyMotion();
    runBlob(collapsed, motionQuery.matches);
  });
  applyMotion();
  narrowQuery.addEventListener('change', applyWidth);
  // Tipp oder Klick daneben schließt das Menü.
  window.addEventListener('pointerdown', function (event) {
    const path = event.composedPath();
    if (path.indexOf(more) === -1 && path.indexOf(menu) === -1) closeMenu();
  }, true);
  window.addEventListener('resize', placeBar);
  applyWidth();

  const divider = document.createElement('span');
  divider.className = 'le-bar__divider';
  bar.append(buildBlob(), buildLogo(), divider, buildModeSwitch(), actions, help, more);
  attachTips();
  root.append(link(TOKENS_STYLE), link(BAR_STYLE), link(TOAST_STYLE), hint, menu, status, bar, tip);
  document.body.appendChild(host);
  document.documentElement.classList.add(PAGE_CLASS);
  setBarStatus(0, false);
  position = storedPosition();
  setCollapsed(storedCollapsed());
  // Knöpfe kommen später dazu (Speichern, Eintrag im Dialog), die Schrift lädt nach.
  new ResizeObserver(placeBar).observe(bar);
  new ResizeObserver(placeStatus).observe(status);
  // Beim Laden läuft noch keine Bearbeitung, die Zuhörer haben nichts zu tun.
  if (storedPreview()) applyPreview(true);
  else if (!storedHintSeen() && !collapsed) showHint();
}

function closeMenu() {
  menu.hidden = true;
  more.setAttribute('aria-expanded', 'false');
}

// Knopf der Leiste: der Tooltip ersetzt den des Browsers (title).
function withTip(button) {
  button.removeAttribute('title');
  return button;
}

// Stand als Lasche an der Leiste, nur solange etwas offen ist (nach dem Speichern meldet das ein Hinweis):
// count gespeicherte Änderungen, editing eine laufende geänderte Bearbeitung, saving ein laufendes
// Speichern („Speichert…“, auch am Handy ganz); eingeklappt zeigt ein Punkt am Logo, dass etwas offen ist.
export function setBarStatus(count, editing, saving) {
  status.textContent = '';
  const clean = !count && !editing && !saving;
  status.hidden = clean;
  logo.classList.toggle('le-bar__logo--dirty', !clean);
  if (clean) return;
  const dot = document.createElement('span');
  dot.className = 'le-status__dot';
  const text = document.createElement('span');
  const word = document.createElement('span');
  word.className = 'le-bar__wide';
  if (saving) {
    text.textContent = BAR_TEXT.saving;
    status.append(dot, text);
    return;
  }
  if (count) {
    text.append(String(count) + ' ');
    word.textContent = BAR_TEXT.unsaved;
  } else {
    word.textContent = BAR_TEXT.editing;
  }
  text.append(word);
  status.append(dot, text);
}

// Knopf hinten in der Leiste (Rückgängig, Speichern, Eintrag im Dialog), nur mit Symbol und
// aria-label, das der Tooltip zeigt; className aus bar.css.
export function addBarButton(button) {
  return actions.appendChild(withTip(button));
}

// Eintrag im Menü „Mehr“ vor Hilfe, Verwaltung und Abmelden (Verlauf, „Alle Texte“); schließt das
// Menü beim Klick. name: Symbol (icons.js), note: eine Zeile Erklärung.
export function addMenuButton(name, label, note, onClick) {
  const entry = menuEntry(name, label, note);
  entry.addEventListener('click', function () {
    closeMenu();
    onClick();
  });
  menu.insertBefore(entry, menuFixed);
  return entry;
}

// Kommt das Ereignis aus der Leiste, ihrem Menü oder dem Hinweis darüber? Die bleiben bedienbar,
// während ein Speichern die Eingaben sperrt (interact.js).
export function fromBar(event) {
  const path = event.composedPath();
  return path.indexOf(bar) !== -1 || path.indexOf(menu) !== -1 || path.indexOf(hint) !== -1;
}

// Element der Seite, in dem der Editor lebt (Ereignisse daraus gehören nicht zur Website).
export function editorHost() {
  return host;
}

// Shadow-DOM für Rahmen, Mini-Leisten und Dialoge des Editors.
export function editorRoot() {
  return root;
}

// Weiteres Stylesheet im Shadow-DOM (URL relativ zum aufrufenden Modul auflösen), vor dem Hinweis.
export function addEditorStyle(href) {
  root.insertBefore(link(href), hint);
}

// Hinweis unten über der Leiste; ohne Text keiner. action (optional): { label, onClick } als Knopf darin.
export function notify(message, action) {
  if (message) showToast(message, root, action ? editorButton(action.label, 'le-btn le-btn--small', action.onClick) : null);
}

// Hinweis zu einem Fehler eines Aufrufs (errorNotice: bei abgelaufener Anmeldung mit „Neu anmelden“).
export function notifyError(error) {
  const notice = errorNotice(error);
  notify(notice.message, notice.action);
}
