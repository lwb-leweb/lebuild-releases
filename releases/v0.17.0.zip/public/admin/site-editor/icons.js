// Strich-Symbole des Seiten-Editors (24er Raster, Farbe aus currentColor, Größe aus edit.css/bar.css
// über .le-icon). Nur Pfade, kein HTML: icon() baut das SVG mit createElementNS.

const SVG_NS = 'http://www.w3.org/2000/svg';

const PATHS = {
  pencil: ['M12 20h9', 'M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z'],
  image: ['M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z', 'M9 7a2 2 0 1 0 0 4 2 2 0 1 0 0-4', 'm21 15-3.1-3.1a2 2 0 0 0-2.8 0L6 21'],
  link: ['M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7', 'M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7'],
  undo: ['M9 14 4 9l5-5', 'M4 9h11a5 5 0 0 1 0 10h-3'],
  eye: ['M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z', 'M12 9a3 3 0 1 0 0 6 3 3 0 1 0 0-6'],
  save: ['M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2Z', 'M17 21v-8H7v8', 'M7 3v5h8'],
  plus: ['M12 5v14', 'M5 12h14'],
  trash: ['M3 6h18', 'M8 6V4h8v2', 'M19 6l-1 14H6L5 6'],
  moveUp: ['m18 15-6-6-6 6'],
  moveDown: ['m6 9 6 6 6-6'],
  more: ['M5 12h.01', 'M12 12h.01', 'M19 12h.01'],
  history: ['M3 12a9 9 0 1 0 3-6.7L3 8', 'M3 3v5h5', 'M12 7v5l3 2'],
  list: ['M4 6h16', 'M4 12h16', 'M4 18h10'],
  help: ['M12 2a10 10 0 1 0 0 20 10 10 0 1 0 0-20', 'M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3', 'M12 17h.01'],
  settings: ['M4 21v-7', 'M4 10V3', 'M12 21v-9', 'M12 8V3', 'M20 21v-5', 'M20 12V3', 'M1 14h6', 'M9 8h6', 'M17 16h6'],
  logout: ['M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4', 'm16 17 5-5-5-5', 'M21 12H9'],
  items: ['M3 5h7v6H3Z', 'M14 5h7v6h-7Z', 'M3 15h7v4H3Z', 'M14 15h7v4h-7Z'],
  close: ['M18 6 6 18', 'M6 6l12 12'],
  listBullets: ['M9 6h11', 'M9 12h11', 'M9 18h11', 'M4 6h.01', 'M4 12h.01', 'M4 18h.01'],
  listNumbers: ['M10 6h10', 'M10 12h10', 'M10 18h10', 'M4 4h1v4', 'M4 8h2', 'M4 14h2l-2 3h2'],
  quote: ['M7 7H4v6h4v-1c0 2-1 4-3 5', 'M17 7h-3v6h4v-1c0 2-1 4-3 5'],
  star: ['M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4l-5.9 3.1 1.2-6.5-4.8-4.6 6.6-.9Z'],
  pointer: ['m9 9 5 12 1.8-5.2L21 14Z', 'M7.2 2.2 8 5.1', 'm5.1 8-2.9-.8', 'M14 4.1 12 6', 'm6 12-1.9 2']
};

// Symbol als SVG-Element; die Bedeutung trägt der Text oder das aria-label daneben.
export function icon(name) {
  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', name === 'more' ? '3' : '2');
  svg.setAttribute('stroke-linecap', 'round');
  svg.setAttribute('stroke-linejoin', 'round');
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('class', 'le-icon');
  PATHS[name].forEach(function (d) {
    const path = document.createElementNS(SVG_NS, 'path');
    path.setAttribute('d', d);
    svg.appendChild(path);
  });
  return svg;
}
