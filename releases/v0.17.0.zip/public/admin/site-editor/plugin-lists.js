import { notify, notifyError, editorButton, labeledButton, iconButton, addBarButton, onModeChange } from './bar.js';
import { editorApi, editorPost } from './request.js';
import { SESSION_TEXT } from './session.js';
import { showHover, pin, CHIP_PLACE } from './overlay.js';
import { addChipSource } from './interact.js';
import { askConfirm } from './confirm.js';
import { icon } from './icons.js';
import { openPanel, closePanel, panelFooter, isPanelOpen } from './panel.js';
import { buildEntryForm, deleteQuestion, entryTitle, ENTRY_TEXT } from './entry-form.js';
import { PICKER_CLASS } from './field-editors.js';

// Plugin-Listen auf der Seite: Renderer markieren Liste, Eintrag und Einzelansicht
// (le_list_attrs/le_item_attrs/le_single_attrs, Namen aus dem JSON-Block). Für Plugins mit
// inlineEdit in plugin.json steht unter jeder Liste beim Bearbeiten immer ihre Leiste
// („Mitarbeiter · 5 Einträge“, „+ Neuer Eintrag“; page.css hält dort Platz frei). Ein Klick auf
// einen Eintrag öffnet sein Formular, beim Überfahren (Handy: erstes Antippen) zeigt er seine
// Knöpfe (Bearbeiten, ↑/↓ mit sort-Endpoint und ohne attrs.fixedOrder an der Liste, Löschen). Einträge speichern sofort über ihr Formular
// (entry-form.js) und gehören nicht zu Speichern/Rückgängig der Seite; danach werden nur die Listen
// dieses Typs aus der neu abgerufenen Seite getauscht, Ungespeichertes auf der Seite bleibt; am neuen Element kommt
// dann das Ereignis listReloaded (Skripte der Website, z. B. das Modal der Content-Typen). Listen mit
// itemForm (Content-Typen-Karten) öffnen beim Klick immer das Formular, auch wenn ein Eintrag ein Link
// ist (formOnly, interact.js). Zeigt ein Skript der Website einen Eintrag in einem Dialog (Ereignis
// itemDialog), bietet die Leiste den Knopf der Einzelansicht (Text vom Plugin), die Leisten unter den
// Listen sind solange weg; der Wechsel von „Ansehen“ auf „Bearbeiten“ öffnet dann gleich sein Formular.

const LIST_TEXT = {
  add: 'Neuer Eintrag',
  entryEyebrow: 'Eintrag',
  edit: ENTRY_TEXT.edit,
  remove: 'Löschen',
  removeNote: 'Das lässt sich nicht rückgängig machen.',
  up: 'Nach vorne',
  down: 'Nach hinten',
  entry: 'Eintrag',
  entries: 'Einträge',
  saved: SESSION_TEXT.saved,
  deleted: 'Gelöscht.',
  hidden: SESSION_TEXT.saved + ' Der Eintrag ist in dieser Liste nicht zu sehen.',
  singleGone: SESSION_TEXT.saved + ' Der Eintrag ist unter dieser Adresse nicht mehr zu sehen.',
  reloadFailed: 'Die Liste lässt sich nicht neu laden. Bitte die Seite neu laden.'
};
// Panel-Schlüssel des Formulars (panel.js).
const FORM_KEY = 'entry';
// Platz unter Listen (page.css): eigener Abstand der Website unter der Liste (hier gemessen) und
// Klasse an <html>, die die Abstandsregel zum Messen aussetzt.
const LIST_SPACE = {
  ownMarginVar: '--le-list-own-margin',
  measuringClass: 'le-list-measuring'
};
// Klassen des Formulars im Shadow-DOM (edit.css).
const PAGE_LOOK = {
  form: 'le-form',
  field: 'le-field le-field--panel',
  labelTag: 'span',
  label: 'le-field__label',
  checkbox: 'le-field le-field--checkbox',
  picker: PICKER_CLASS,
  image: 'le-field__image',
  imageEmpty: 'le-field__image-empty',
  imageDrop: 'le-field__drop',
  imageDropActive: 'le-field__drop--active',
  imageActions: 'le-field__image-actions',
  list: 'le-field__list',
  listRow: 'le-field__row',
  listRowActions: 'le-field__row-actions'
};

// plugin_lists_config() (core/plugins.php): { endpoints je Plugin, attrs, separator, directions, singleLabel, events }.
let lists = null;
let attrs = null;
let events = null;
// Ein Abruf (Laden, Löschen, Sortieren) zur Zeit.
let busy = false;
// Name der Liste je Schlüssel („Mitarbeiter“), aus dem list-Endpoint; null, solange unbekannt.
const listLabels = new Map();
// Lösen der Leisten unter den Listen (overlay.js pin).
let unpinBars = [];
// Eintrag, den ein Skript der Website gerade in einem Dialog zeigt (Element mit attrs.item), sonst null;
// Knopf dafür in der Leiste.
let dialogItem = null;
let dialogButton = null;

function attrSelector(attr, value) {
  return value === undefined ? '[' + attr + ']' : '[' + attr + '="' + CSS.escape(value) + '"]';
}

function withQuery(url, params) {
  const target = new URL(url, window.location.origin);
  Object.keys(params).forEach(function (name) { target.searchParams.set(name, params[name]); });
  return target.pathname + target.search;
}

// Liste oder Einzelansicht mit Plugin, Typ und Endpoints; null, wenn das Plugin nicht mitmacht.
function placeOf(container) {
  const single = container.hasAttribute(attrs.single);
  const key = container.getAttribute(single ? attrs.single : attrs.list);
  const cut = key.indexOf(lists.separator);
  const plugin = cut > 0 ? key.slice(0, cut) : '';
  if (!plugin || !Object.prototype.hasOwnProperty.call(lists.endpoints, plugin)) return null;
  return { container: container, single: single, key: key, type: key.slice(cut + lists.separator.length), urls: lists.endpoints[plugin] };
}

// Beschriftung für „diesen Eintrag bearbeiten“ (Einzelansicht, Eintrag im Dialog): vom Plugin am
// Element, sonst die Vorgabe des Kerns.
function singleLabelOf(container) {
  return container.getAttribute(attrs.singleLabel) || lists.singleLabel;
}

function containerOf(item) {
  return item.closest(attrSelector(attrs.list) + ',' + attrSelector(attrs.single));
}

function idOf(item) {
  return parseInt(item.getAttribute(attrs.item), 10);
}

// Einträge genau dieser Liste (nicht die einer Liste darin).
function itemsOf(place) {
  return Array.prototype.filter.call(place.container.querySelectorAll(attrSelector(attrs.item)), function (item) {
    return containerOf(item) === place.container;
  });
}

// Listen mitmachender Plugins auf der Seite.
function listsOnPage() {
  return Array.prototype.filter.call(document.querySelectorAll(attrSelector(attrs.list)), function (list) {
    return placeOf(list) !== null;
  });
}

// Eigenen Abstand der Website unter jeder Liste messen (ohne die Regel aus page.css) und an der
// Liste ablegen: page.css nimmt den größeren davon und den Platz für „+ Hinzufügen“. Neu nach dem
// Neuladen einer Liste und bei Größenänderung (Media Queries der Website).
function measureListSpace() {
  const found = document.querySelectorAll(attrSelector(attrs.list));
  const root = document.documentElement;
  const scrollX = window.scrollX;
  const scrollY = window.scrollY;
  root.classList.add(LIST_SPACE.measuringClass);
  const margins = Array.prototype.map.call(found, function (list) { return window.getComputedStyle(list).marginBottom; });
  root.classList.remove(LIST_SPACE.measuringClass);
  Array.prototype.forEach.call(found, function (list, index) { list.style.setProperty(LIST_SPACE.ownMarginVar, margins[index]); });
  // Ohne die Regel ist die Seite kurz kürzer; der Browser kann dabei die Scrollposition kappen.
  if (window.scrollX !== scrollX || window.scrollY !== scrollY) window.scrollTo({ left: scrollX, top: scrollY, behavior: 'instant' });
}

function run(task) {
  if (busy) return;
  busy = true;
  task()
    .catch(notifyError)
    .finally(function () { busy = false; });
}

// Holt die Seite neu und tauscht die Liste bzw. Einzelansicht samt allen Listen desselben Typs auf der
// Seite (z. B. eine zweite mit data-filter), jede per Reihenfolge unter den gleichen. Ein Weg für
// Speichern, Hinzufügen, Löschen und Sortieren. listReloaded kommt erst, wenn alle getauscht sind, und
// zuerst an place (das Modal sucht seinen Inhalt in der ersten neuen Liste ohne seine alte Hülle).
// id: gespeicherter Eintrag, der danach in place zu sehen sein sollte (null ohne).
function reload(place, id, message) {
  const listSelector = attrSelector(attrs.list, place.key);
  const others = Array.prototype.filter.call(document.querySelectorAll(listSelector), function (list) { return list !== place.container; });
  const spots = [place.container].concat(others).map(function (container) {
    const selector = container.hasAttribute(attrs.single)
      ? attrSelector(attrs.single, place.key) + attrSelector(attrs.item, String(idOf(container)))
      : listSelector;
    return { container: container, selector: selector, index: Array.prototype.indexOf.call(document.querySelectorAll(selector), container) };
  });
  return fetch(window.location.href, { credentials: 'same-origin', cache: 'no-store' })
    .then(function (response) {
      if (!response.ok) throw new Error(LIST_TEXT.reloadFailed);
      return response.text();
    })
    .then(function (html) {
      const fresh = new DOMParser().parseFromString(html, 'text/html');
      const nodes = spots.map(function (spot) {
        const found = spot.index === -1 ? null : fresh.querySelectorAll(spot.selector)[spot.index];
        if (!found) return null;
        const node = document.importNode(found, true);
        spot.container.replaceWith(node);
        return node;
      });
      measureListSpace();
      nodes.forEach(function (node) {
        if (node) node.dispatchEvent(new CustomEvent(events.listReloaded, { bubbles: true }));
      });
      mountListBars();
      showHover(null, []);
      const node = nodes[0];
      if (!node) {
        notify(place.single ? LIST_TEXT.singleGone : LIST_TEXT.reloadFailed);
        return;
      }
      if (nodes.indexOf(null) !== -1) {
        notify(LIST_TEXT.reloadFailed);
        return;
      }
      const shown = id === null || node.matches(attrSelector(attrs.item, String(id))) || node.querySelector(attrSelector(attrs.item, String(id))) !== null;
      if (message) notify(shown ? message : LIST_TEXT.hidden);
    })
    .catch(function () { notify(LIST_TEXT.reloadFailed); });
}

// Formular im Seitenpanel (panel.js); Speichern (Knopf, Enter, Strg+S) schließt es und lädt die Liste
// neu. Ein geändertes Formular zählt als ungespeichert (Nachfrage vor dem Ersetzen, beim Verlassen der
// Seite). Wie auch immer das Panel zugeht, danach schließt sich das Formular (entry.close: nicht
// gespeicherte Uploads weg), bei laufendem Speichern erst, wenn es fertig ist (sonst fehlte dem Eintrag
// sein neues Bild).
function openForm(place, schema, row) {
  let dirty = false;
  let saving = false;
  let saveButton = null;
  let body = null;
  const submit = function () {
    if (saving || !entry.check()) return;
    saving = true;
    saveButton.disabled = true;
    const payload = { type: place.type, data: entry.values() };
    if (row) payload.id = row.id;
    editorPost(place.urls.save, payload)
      .then(function (data) {
        saving = false;
        if (body.isConnected) closePanel();
        else entry.close();
        return reload(place, Number(data.id), LIST_TEXT.saved);
      }, function (error) {
        saving = false;
        saveButton.disabled = false;
        if (!body.isConnected) entry.close();
        notifyError(error);
      });
  };
  const entry = buildEntryForm(schema, row, { look: PAGE_LOOK, notify: notify, onSubmit: submit });
  openPanel({
    key: FORM_KEY,
    eyebrow: listLabels.get(place.key) || LIST_TEXT.entryEyebrow,
    title: row ? entryTitle(schema, row) : LIST_TEXT.add,
    dim: true,
    isDirty: function () { return dirty; },
    onSave: submit,
    onClose: function () { if (!saving) entry.close(); }
  }).then(function (panelBody) {
    // Abgelehnt (anderes Formular mit Eingaben bleibt offen): dieses Formular ist nie aufgegangen.
    if (!panelBody) {
      entry.close();
      return;
    }
    body = panelBody;
    // Bild-Upload und Texteditor melden Änderungen ebenfalls über input.
    entry.form.addEventListener('input', function () { dirty = true; });
    entry.form.addEventListener('change', function () { dirty = true; });
    saveButton = editorButton(ENTRY_TEXT.save, 'le-btn le-panel__primary', submit);
    panelFooter().append(saveButton, editorButton(ENTRY_TEXT.cancel, 'le-btn le-btn--secondary', closePanel));
    body.append(entry.form);
    entry.focus();
  });
}

// Schema und Name der Liste brauchen keine Einträge: Liste nur mit einem Eintrag holen, sonst lädt
// jede angemeldete Seitenansicht alle Einträge des Typs.
const SCHEMA_ONLY_LIMIT = 1;

function add(place) {
  run(function () {
    return editorApi(withQuery(place.urls.list, { type: place.type, limit: SCHEMA_ONLY_LIMIT })).then(function (data) {
      openForm(place, data.schema, null);
    });
  });
}

function loadEntry(place, id) {
  return editorApi(withQuery(place.urls.get, { type: place.type, id: id }));
}

function edit(place, id) {
  run(function () {
    return loadEntry(place, id).then(function (data) {
      openForm(place, data.schema, data.row);
    });
  });
}

// Fragt einmal nach („‚Max Muster‘ löschen?“), der Server entfernt auch ungenutzte Bilder.
function remove(place, id) {
  run(function () {
    return loadEntry(place, id).then(function (data) {
      return askConfirm({ title: deleteQuestion(data.schema, data.row), text: LIST_TEXT.removeNote, confirm: LIST_TEXT.remove, danger: true });
    }).then(function (yes) {
      if (!yes) return null;
      return editorPost(place.urls.delete, { type: place.type, id: id }).then(function () {
        return reload(place, null, LIST_TEXT.deleted);
      });
    });
  });
}

// target: sichtbarer Nachbar in dieser Liste, mit dem getauscht wird (in einer gefilterten oder
// gekürzten Liste nicht unbedingt der in der Gesamtreihenfolge); ein sort-Endpoint ohne target nimmt
// den Nachbarn in direction.
function move(place, id, direction, target) {
  run(function () {
    return editorPost(place.urls.sort, { type: place.type, id: id, direction: direction, target: target }).then(function () {
      return reload(place, null, null);
    });
  });
}

// Knopf-Quelle für interact.js: Eintrag (bzw. Einzelansicht) oder Liste eines mitmachenden Plugins.
const entrySource = {
  anchorFor: function (el) {
    const item = el.closest(attrSelector(attrs.item));
    const container = item ? containerOf(item) : el.closest(attrSelector(attrs.list));
    return container && placeOf(container) ? item || container : null;
  },
  chips: function (anchor) {
    if (!anchor.hasAttribute(attrs.item)) return [];
    const place = placeOf(containerOf(anchor));
    const id = idOf(anchor);
    if (place.single) {
      return [{ anchor: anchor, place: CHIP_PLACE.corner, label: singleLabelOf(place.container), icon: 'pencil', tone: 'primary', onClick: function () { edit(place, id); } }];
    }
    return itemChips(place, anchor);
  },
  // Klick auf einen Eintrag (nicht auf die Liste daneben) öffnet sein Formular.
  activate: function (anchor) {
    if (!anchor.hasAttribute(attrs.item)) return null;
    const place = placeOf(containerOf(anchor));
    const id = idOf(anchor);
    return function () { edit(place, id); };
  },
  // Eintrag einer Liste mit attrs.itemForm: auch als Link öffnet der Klick das Formular, keine Link-Knöpfe.
  formOnly: function (anchor) {
    return anchor.hasAttribute(attrs.item) && containerOf(anchor).hasAttribute(attrs.itemForm);
  }
};

function itemChips(place, item) {
  const id = idOf(item);
  const chip = function (label, name, onClick, extra) {
    return Object.assign({ anchor: item, place: CHIP_PLACE.corner, label: label, icon: name, iconOnly: true, onClick: onClick }, extra);
  };
  const chips = [chip(LIST_TEXT.edit, 'pencil', function () { edit(place, id); }, { iconOnly: false, tone: 'primary' })];
  if (place.urls.sort && !place.container.hasAttribute(attrs.fixedOrder)) {
    const items = itemsOf(place);
    const index = items.indexOf(item);
    if (index > 0) chips.push(chip(LIST_TEXT.up, 'moveUp', function () { move(place, id, lists.directions.up, idOf(items[index - 1])); }));
    if (index < items.length - 1) chips.push(chip(LIST_TEXT.down, 'moveDown', function () { move(place, id, lists.directions.down, idOf(items[index + 1])); }));
  }
  chips.push(chip(LIST_TEXT.remove, 'trash', function () { remove(place, id); }, { tone: 'danger' }));
  return chips;
}

function countText(n) {
  return n + ' ' + (n === 1 ? LIST_TEXT.entry : LIST_TEXT.entries);
}

// Leiste unter einer Liste: Name (sobald bekannt), Zahl der Einträge, „+ Neuer Eintrag“.
function listBar(place) {
  const bar = document.createElement('div');
  bar.className = 'le-listbar';
  const label = document.createElement('span');
  label.className = 'le-listbar__label';
  const name = document.createElement('strong');
  const count = document.createElement('span');
  const fill = function () {
    const known = listLabels.get(place.key);
    name.textContent = known ? known + ' · ' : '';
    count.textContent = countText(itemsOf(place).length);
  };
  fill();
  label.append(name, count);
  bar.append(icon('items'), label, labeledButton('plus', LIST_TEXT.add, 'le-btn le-btn--small', function () { add(place); }));
  if (!listLabels.has(place.key)) {
    listLabels.set(place.key, null);
    editorApi(withQuery(place.urls.list, { type: place.type, limit: SCHEMA_ONLY_LIMIT })).then(function (data) {
      listLabels.set(place.key, typeof data.label === 'string' ? data.label : null);
      mountListBars();
    }, function () { /* ohne Namen bleibt die Zahl */ });
  }
  return bar;
}

// Leisten unter allen Listen neu anheften (beim Start und nachdem eine Liste neu geladen wurde); bei
// offenem Dialog lägen sie über ihm und bleiben weg.
function mountListBars() {
  unpinBars.forEach(function (unpin) { unpin(); });
  unpinBars = dialogItem ? [] : listsOnPage().map(function (list) {
    return pin(list, listBar(placeOf(list)));
  });
}

// itemDialog: detail.item ist ein Element im gezeigten Eintrag oder null (Dialog zu). Nur Einträge
// mitmachender Listen bekommen den Knopf in der Leiste.
function onItemDialog(event) {
  const shown = event.detail && event.detail.item instanceof Element ? event.detail.item.closest(attrSelector(attrs.item)) : null;
  const container = shown ? containerOf(shown) : null;
  dialogItem = container && placeOf(container) ? shown : null;
  dialogButton.hidden = !dialogItem;
  if (dialogItem) {
    const label = singleLabelOf(container);
    dialogButton.setAttribute('aria-label', label);
  }
  mountListBars();
}

function editDialogItem() {
  if (dialogItem && dialogItem.isConnected) edit(placeOf(containerOf(dialogItem)), idOf(dialogItem));
}

// Wechsel auf „Bearbeiten“ (bar.js onModeChange, hält ihn nie auf): Im Dialog ist nichts anklickbar,
// also gleich das Formular seines Eintrags; ohne Dialog nichts, ein schon offenes Formular bleibt.
function onModeSwitch(preview) {
  if (!preview && !isPanelOpen(FORM_KEY)) editDialogItem();
}

// Knopf in der Leiste für den Eintrag im Dialog, nur mit Symbol (aria-label und Tooltip setzt onItemDialog).
function buildDialogButton() {
  const button = iconButton('items', '', 'le-icon-btn', editDialogItem);
  button.hidden = true;
  return addBarButton(button);
}

export function mountPluginLists(config) {
  lists = config.pluginLists;
  attrs = lists.attrs;
  events = lists.events;
  addChipSource(entrySource);
  dialogButton = buildDialogButton();
  document.addEventListener(events.itemDialog, onItemDialog);
  onModeChange(onModeSwitch);
  measureListSpace();
  mountListBars();
  let scheduled = false;
  window.addEventListener('resize', function () {
    if (scheduled) return;
    scheduled = true;
    window.requestAnimationFrame(function () {
      scheduled = false;
      measureListSpace();
    });
  });
}
