import { state, dom, api, UPDATE_TEXT, versionStep } from './core.js';
import { showToast } from '../site-editor/toast.js';

const updateSubscribers = [];

export function onUpdateStatusChange(fn) {
  updateSubscribers.push(fn);
}

function notifyChange() {
  updateSubscribers.forEach(function (fn) {
    try { fn(state.updateStatus); } catch (e) {}
  });
}

export function setUpdateStatus(status) {
  state.updateStatus = status || null;
  renderBanner();
  notifyChange();
}

function setBannerHeightVar() {
  const shell = document.querySelector('.editor-shell');
  if (!shell) return;
  const h = dom.updateBanner && !dom.updateBanner.classList.contains('hidden')
    ? dom.updateBanner.offsetHeight
    : 0;
  shell.style.setProperty('--banner-height', h + 'px');
}

function clearBanner() {
  if (!dom.updateBanner) return;
  dom.updateBanner.classList.add('hidden');
  dom.updateBanner.textContent = '';
  setBannerHeightVar();
}

// So lange steht „Update installiert“ im Banner.
const INSTALLED_BANNER_MS = 12000;

// Banner „Update braucht Bestätigung“ fällig (renderBanner zeigt es).
function confirmationDue() {
  const status = state.updateStatus;
  return !!(status && status.hasUpdate && status.requiresConfirmation && !state.updateDismissed);
}

// „Update installiert“ im Banner. Steht dort ein Banner „Update braucht Bestätigung“, bleibt es, und
// die Meldung kommt als Hinweis (showToast); nach dem Schließen oder der Frist zeigt renderBanner den
// aktuellen Stand, aber nur, wenn das Banner noch diese Meldung zeigt.
export function showInstalledToast(previousVersion, newVersion) {
  if (!dom.updateBanner) return;
  if (confirmationDue()) {
    showToast(UPDATE_TEXT.installed + ' ' + versionStep(previousVersion, newVersion), document.body);
    return;
  }
  dom.updateBanner.className = 'update-banner info';
  dom.updateBanner.innerHTML = '';

  const text = document.createElement('div');
  text.className = 'update-banner__text';
  const strong = document.createElement('strong');
  strong.textContent = UPDATE_TEXT.installed;
  text.appendChild(strong);
  text.appendChild(document.createTextNode(versionStep(previousVersion, newVersion)));

  const actions = document.createElement('div');
  actions.className = 'update-banner__actions';
  const dismiss = document.createElement('button');
  dismiss.type = 'button';
  dismiss.className = 'secondary';
  dismiss.textContent = 'OK';
  dismiss.addEventListener('click', renderBanner);
  actions.appendChild(dismiss);

  dom.updateBanner.appendChild(text);
  dom.updateBanner.appendChild(actions);
  setBannerHeightVar();

  setTimeout(function () {
    if (dom.updateBanner.contains(text)) renderBanner();
  }, INSTALLED_BANNER_MS);
}

export function renderBanner() {
  if (!dom.updateBanner) return;
  const status = state.updateStatus;
  if (!status || !status.hasUpdate || !status.requiresConfirmation || state.updateDismissed) {
    clearBanner();
    return;
  }

  dom.updateBanner.className = 'update-banner';
  dom.updateBanner.innerHTML = '';

  const text = document.createElement('div');
  text.className = 'update-banner__text';
  const strong = document.createElement('strong');
  strong.textContent = 'Update ' + status.latestVersion + ' verfügbar';
  text.appendChild(strong);
  if (status.notes) {
    const notes = String(status.notes).split('\n')[0].slice(0, 180);
    text.appendChild(document.createTextNode(notes));
  } else {
    text.appendChild(document.createTextNode('Diese Version muss bestätigt werden.'));
  }

  const actions = document.createElement('div');
  actions.className = 'update-banner__actions';

  const install = document.createElement('button');
  install.type = 'button';
  install.textContent = 'Jetzt installieren';
  install.addEventListener('click', function () { triggerInstall(install); });

  const later = document.createElement('button');
  later.type = 'button';
  later.className = 'secondary';
  later.textContent = 'Später';
  later.addEventListener('click', function () {
    state.updateDismissed = true;
    clearBanner();
  });

  actions.appendChild(install);
  actions.appendChild(later);

  dom.updateBanner.appendChild(text);
  dom.updateBanner.appendChild(actions);
  dom.updateBanner.classList.remove('hidden');
  setBannerHeightVar();
}

// Update einspielen (Banner und Einstellungen); der neue Stand geht über setUpdateStatus an
// Banner und Ansichten.
export function installUpdate() {
  return api('/api/installUpdate.php', { method: 'POST' })
    .then(function (data) {
      setUpdateStatus(data.status || null);
      return data;
    });
}

function triggerInstall(button) {
  button.disabled = true;
  const original = button.textContent;
  button.textContent = 'Installiere…';
  installUpdate()
    .then(function (data) {
      showInstalledToast(data.previousVersion, data.newVersion);
    })
    .catch(function (error) {
      button.disabled = false;
      button.textContent = original;
      alert('Update fehlgeschlagen: ' + error.message);
    });
}

export function forceRemoteCheck() {
  return api('/api/checkUpdate.php', { method: 'POST' })
    .then(function (data) {
      setUpdateStatus(data.status || null);
      return data.status;
    });
}

export function rollback() {
  return api('/api/rollbackUpdate.php', { method: 'POST' })
    .then(function (data) {
      setUpdateStatus(data.status || null);
      return data;
    });
}
