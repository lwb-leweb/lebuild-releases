// MySQL-Zugangsdaten: gemeinsame Felder für die DB-Einrichtung beim
// Aktivieren eines Plugins und den Umzug unter Einstellungen → Datenbank.

export const DB_FORM_FIELDS = `
  <label class="field"><small>Host</small><input name="host" value="127.0.0.1" required></label>
  <label class="field"><small>Port</small><input name="port" type="number" value="3306" min="1" max="65535" required></label>
  <label class="field"><small>Datenbank</small><input name="name" required></label>
  <label class="field"><small>Benutzer</small><input name="user" required></label>
  <label class="field"><small>Passwort</small><input name="password" type="password" autocomplete="new-password"></label>
`;

export function readDbForm(form) {
  const fields = form.elements;
  return {
    host: fields.host.value,
    port: parseInt(fields.port.value, 10),
    name: fields.name.value,
    user: fields.user.value,
    password: fields.password.value
  };
}
