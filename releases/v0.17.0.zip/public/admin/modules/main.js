import { state, dom, api, applyEditLists, isAdmin, logout, pageRoute, ADMIN_URL, LOGIN_URL, SITE_HOME_URL } from './core.js';
import { renderPages, firstOpenablePage, applyPageFilter } from './pages.js';
import { navigate, initRouter, showToast } from './router.js';
import { setUpdateStatus, showInstalledToast } from './update.js';
import { attachSaveKey } from './save-key.js';

// Texte zu Import und „Markierungen aktualisieren“ (als Hinweis, showToast); den Grund für eine
// übersprungene Datei liefert der Server (IMPORT_SKIP_REASONS).
const IMPORT_TEXT = {
  refreshConfirm: 'Markierungen aktualisieren liest alle Seiten und Komponenten neu aus den Dateien unter public/site: Markierungen werden nach den aktuellen Regeln gesetzt, bestehende IDs bleiben, Inhalte im Editor kommen aus den Dateien. Sicherungen werden vorher angelegt. Fortfahren?',
  imported: 'Import abgeschlossen.',
  refreshed: 'Markierungen aktualisiert.',
  skippedFiles: 'Übersprungen'
};

function showEditor(data) {
  state.pages = data.pages || [];
  state.pageInfo = data.pages || [];
  state.csrfToken = data.csrfToken || state.csrfToken;
  state.activePlugins = data.activePlugins || [];
  state.systemProblems = data.systemProblems || [];
  state.dbArchiveReminder = data.dbArchiveReminder || null;
  state.siteBackup = data.siteBackup || null;
  state.username = data.username || null;
  dom.editorView.classList.remove('hidden');
  dom.importNotice.classList.toggle('hidden', !!data.importStatus);
  // Seitenliste startet eingeklappt, außer der Import-Hinweis muss sichtbar sein.
  document.getElementById('pagesGroup').classList.toggle('open', !data.importStatus);
  renderPages();
  renderPluginNav(state.activePlugins);
  initRouter();
  setUpdateStatus(data.updateStatus || null);
  if (data.updateInstalled) {
    showInstalledToast(data.updateInstalled.previousVersion, data.updateInstalled.newVersion);
  }
}

// Ergebnis als Hinweis: der Knopf sitzt in der Seitenleiste.
function runImport(force) {
  api('/api/import.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ force: !!force })
  })
    .then(function (data) {
      state.pages = data.pages || [];
      state.pageInfo = data.pages || [];
      dom.importNotice.classList.add('hidden');
      renderPages();
      const first = firstOpenablePage();
      if (first !== null) {
        state.currentPage = '';
        navigate(pageRoute(first));
      }
      showToast((force ? IMPORT_TEXT.refreshed : IMPORT_TEXT.imported) + skippedFilesNote(data.status.skippedFiles));
    })
    .catch(function (error) {
      showToast(error.message);
    });
}

// „ Übersprungen (nicht UTF-8): a.html, b.php.“ je Grund; leer, wenn keine Datei übersprungen wurde.
function skippedFilesNote(files) {
  const byReason = {};
  files.forEach(function (f) {
    (byReason[f.reason] = byReason[f.reason] || []).push(f.file);
  });
  return Object.keys(byReason).map(function (reason) {
    return ' ' + IMPORT_TEXT.skippedFiles + ' (' + reason + '): ' + byReason[reason].join(', ') + '.';
  }).join('');
}

dom.settingsButton.addEventListener('click', function () { navigate('settings'); });
if (dom.usersButton) {
  dom.usersButton.addEventListener('click', function () { navigate('users'); });
}
dom.activityButton.addEventListener('click', function () { navigate('activity'); });
dom.dashboardButton.addEventListener('click', function () { navigate('dashboard'); });
dom.importButton.addEventListener('click', function () { runImport(false); });
dom.refreshMarkersButton.addEventListener('click', function () {
  const ok = window.confirm(IMPORT_TEXT.refreshConfirm);
  if (!ok) return;
  runImport(true);
});
dom.extensionsNavToggle.addEventListener('click', function () {
  dom.extensionsGroup.classList.toggle('open');
});
dom.pluginsManageButton.addEventListener('click', function () {
  navigate('plugins');
});
dom.pageSearch.addEventListener('input', applyPageFilter);
// „Zur Website“: die Seite, die gerade in der Seitenansicht steht, sonst die Startseite.
dom.siteLink.addEventListener('click', function () {
  const frame = dom.previewFrame;
  let path = SITE_HOME_URL;
  try {
    if (frame && frame.isConnected) path = frame.contentWindow.location.pathname + frame.contentWindow.location.search;
  } catch (e) { /* fremde Adresse im iframe: Startseite */ }
  if (path === 'blank' || path.indexOf(ADMIN_URL) === 0) path = SITE_HOME_URL;
  dom.siteLink.href = path;
});
dom.logoutButton.addEventListener('click', function () {
  logout().catch(function (error) { showToast(error.message); });
});

const sidebarEl = document.querySelector('.sidebar');
const sidebarCollapseBtn = document.getElementById('sidebarCollapse');
if (sidebarCollapseBtn && sidebarEl) {
  sidebarCollapseBtn.addEventListener('click', function () {
    sidebarEl.classList.toggle('collapsed');
  });
}

const pagesGroup = document.getElementById('pagesGroup');
const pagesNavToggle = document.getElementById('pagesNavToggle');
if (pagesNavToggle && pagesGroup) {
  pagesNavToggle.addEventListener('click', function () {
    pagesGroup.classList.toggle('open');
  });
}

function renderPluginNav(plugins) {
  if (!dom.pluginsActiveList || !dom.pluginsEmptyHint) return;

  dom.pluginsActiveList.textContent = '';
  if (!plugins || plugins.length === 0) {
    dom.pluginsEmptyHint.classList.remove('hidden');
    return;
  }

  dom.pluginsEmptyHint.classList.add('hidden');
  plugins.forEach(function (plugin) {
    const route = plugin.route || plugin.name;
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'page-entry plugin-entry';
    button.dataset.plugin = plugin.name;
    button.dataset.route = route;

    const title = document.createElement('strong');
    title.textContent = plugin.label || plugin.name;
    const meta = document.createElement('span');
    meta.textContent = plugin.hasAdminModule ? 'Modul' : 'Schema';

    button.appendChild(title);
    button.appendChild(meta);
    button.addEventListener('click', function () {
      navigate('plugin/' + route);
    });
    dom.pluginsActiveList.appendChild(button);
  });
}

// Die Shell bekommen nur angemeldete Admins (index.php). Ist die Session inzwischen abgelaufen
// (oder liefert ein Server wie Nginx die Shell direkt aus), geht es zur Login-Seite und danach zurück,
// Editoren gehen wie bei index.php auf die Website.
function boot() {
  api('/api/bootstrap.php')
    .then(function (data) {
      applyEditLists(data);
      if (!data.authenticated) {
        window.location.replace(LOGIN_URL + '?next=' + encodeURIComponent(window.location.pathname));
        return;
      }
      state.role = data.role || null;
      if (!isAdmin()) {
        window.location.replace(SITE_HOME_URL);
        return;
      }
      state.csrfToken = data.csrfToken || '';
      showEditor(data);
      applyPageFilter();
    })
    .catch(function (error) {
      showToast(error.message);
    });
}

// Strg+S: Speichern-Knopf des sichtbaren Formulars, nie der Speichern-Dialog des Browsers.
attachSaveKey();
boot();
