import { api, postJson, setMessage, escapeHtml } from '../core.js';
import { openModal, closeModal } from '../ui-modal.js';
import { showToast } from '../router.js';
import { openEntryModal, entryTitle, deleteQuestion } from '../../site-editor/entry-form.js';

let pluginName = null;
// Name im Kopf wie in der Seitenleiste (Label aus dem Manifest), sonst der Slug.
let pluginLabel = '';
let outletEl = null;
let currentSchema = [];
// Zählt Mount und Unmount mit; eine Antwort, die zu einem früheren Mount gehört (schneller Wechsel
// von Plugin A zu B), wird verworfen und zeigt weder Zeilen noch Formular von A.
let mountToken = 0;

const genericPluginView = {
  id: '__generic__',
  mount(outlet, ctx) {
    mountToken++;
    pluginName = ctx.pluginName;
    pluginLabel = (ctx.info && ctx.info.label) || ctx.pluginName;
    outletEl = outlet;
    renderShell();
    loadList();
  },
  unmount() {
    mountToken++;
    closeModal();
    pluginName = null;
    pluginLabel = '';
    outletEl = null;
    currentSchema = [];
  }
};

export default genericPluginView;

function renderShell() {
  outletEl.innerHTML = `
    <section class="view-area generic-plugin-view">
      <div class="view-card span-12">
        <div class="topbar">
          <strong>${escapeHtml(pluginLabel)}</strong>
          <button type="button" id="newItemBtn">Neu</button>
        </div>
        <p id="genericMsg" class="message"></p>
        <div id="genericList" class="generic-list"></div>
      </div>
    </section>
  `;
  outletEl.querySelector('#newItemBtn').addEventListener('click', function () {
    openForm(null, currentSchema);
  });
}

// Hängt an eine Antwort: verwirft sie, wenn die Ansicht seit dem Aufruf neu gemountet wurde.
function current(handler) {
  const token = mountToken;
  return function (value) {
    if (token === mountToken) handler(value);
  };
}

function loadList() {
  api('/api/plugins/generic/list.php?plugin=' + encodeURIComponent(pluginName))
    .then(current(function (data) {
      currentSchema = data.schema || [];
      renderList(data.rows || [], currentSchema);
    }))
    .catch(current(showError));
}

function renderList(rows, schema) {
  const list = document.getElementById('genericList');
  if (!list) return;

  if (!rows.length) {
    list.innerHTML = '<p class="message">Noch keine Einträge.</p>';
    return;
  }

  list.innerHTML = '<ul>' + rows.map(function (row) {
    const title = entryTitle(schema, row);
    return `
      <li class="generic-list__row" data-id="${row.id}">
        <span class="generic-list__title">${escapeHtml(title)}</span>
        <div class="generic-list__actions">
          <button type="button" data-action="edit" data-id="${row.id}">Bearbeiten</button>
          <button type="button" data-action="delete" data-id="${row.id}" class="secondary">Löschen</button>
        </div>
      </li>
    `;
  }).join('') + '</ul>';

  list.querySelectorAll('button[data-action="edit"]').forEach(function (button) {
    button.addEventListener('click', function () {
      openFormFromServer(parseInt(button.dataset.id, 10));
    });
  });
  list.querySelectorAll('button[data-action="delete"]').forEach(function (button) {
    button.addEventListener('click', function () {
      const id = parseInt(button.dataset.id, 10);
      const row = rows.find(function (entry) { return Number(entry.id) === id; });
      if (!window.confirm(deleteQuestion(schema, row))) return;
      postJson('/api/plugins/generic/delete.php', { plugin: pluginName, id: id }).then(current(loadList)).catch(current(showError));
    });
  });
}

function openFormFromServer(id) {
  api('/api/plugins/generic/get.php?plugin=' + encodeURIComponent(pluginName) + '&id=' + id)
    .then(current(function (data) {
      currentSchema = data.schema || currentSchema;
      openForm(data.row || null, currentSchema);
    }))
    .catch(current(showError));
}

function openForm(row, schema) {
  const name = pluginName;
  openEntryModal(openModal, {
    schema: schema,
    row: row,
    notify: showToast,
    save: function (data) {
      const body = { plugin: name, data: data };
      if (row && row.id) body.id = row.id;
      return postJson('/api/plugins/generic/save.php', body);
    },
    onSaved: current(loadList)
  });
}

function showError(error) {
  const msg = document.getElementById('genericMsg');
  if (msg) setMessage(msg, error.message || String(error), false);
}
