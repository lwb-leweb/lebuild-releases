import { state, dom, updateDom } from '../core.js';
import { loadPage, syncPageFromFrame, showInFrame } from '../pages.js';
import { readEditorConfig } from '../../site-editor/config.js';

const BLANK_URL = 'about:blank';

// Seitenansicht: die Website im iframe mit dem Seiten-Editor (Leiste, Bearbeiten, Verlauf,
// „Alle Texte dieser Seite“); das Backend selbst bearbeitet nichts.
const TEMPLATE = `
  <div class="page-view">
    <section class="preview view-area">
      <div class="card-grid">
        <iframe id="previewFrame" class="span-12" title="Live Preview"></iframe>
      </div>
    </section>
  </div>
`;

export function mount(outlet, pageKey) {
  outlet.innerHTML = TEMPLATE;

  const root = outlet.querySelector('.page-view');
  updateDom({
    previewFrame: root.querySelector('#previewFrame')
  });

  dom.previewFrame.addEventListener('load', onFrameLoad);

  if (pageKey) {
    loadPage(pageKey);
  } else if (state.currentPage) {
    loadPage(state.currentPage);
  }
}

export function update(pageKey) {
  if (pageKey && pageKey !== state.currentPage) {
    loadPage(pageKey);
  }
}

export function unmount() {
  pendingLeave = null;
}

// Zeigt das Dokument im iframe den Seiten-Editor?
function frameHasEditor() {
  try {
    return readEditorConfig(dom.previewFrame.contentDocument) !== null;
  } catch (e) {
    return false;
  }
}

// Wechsel in eine andere Backend-Ansicht (Router): Mit dem Seiten-Editor im iframe wird dieser
// erst geleert. Das löst dieselbe Warnung beim Verlassen aus wie ein Seitenwechsel (beforeunload
// in session.js); erst wenn das leere Dokument geladen ist, läuft retry. Lehnt man ab, bleibt alles.
let pendingLeave = null;
export function leave(retry) {
  if (!dom.previewFrame || !frameHasEditor()) return true;
  pendingLeave = retry;
  showInFrame(BLANK_URL);
  return false;
}

function onFrameLoad() {
  if (pendingLeave && dom.previewFrame.contentWindow.location.href === BLANK_URL) {
    const retry = pendingLeave;
    pendingLeave = null;
    retry();
    return;
  }
  syncPageFromFrame();
}
