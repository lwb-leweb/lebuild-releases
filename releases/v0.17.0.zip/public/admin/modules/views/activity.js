import { api } from '../core.js';

// Verwaltung → Aktivität (nur Admins): Aktivitäts-Log aus api/activity.php, neueste zuerst, filterbar nach Benutzer.
const ACTIVITY_TEXT = {
  title: 'Aktivität',
  user: 'Benutzer',
  allUsers: 'Alle Benutzer',
  loading: 'Lade…',
  empty: 'Noch keine Einträge.',
  more: 'Weitere laden',
  hint: 'Einträge werden nach 90 Tagen gelöscht. IP-Adressen werden nicht gespeichert.',
  none: '–'
};
const ACTIVITY_PAGE_SIZE = 50;
const TIME_FORMAT = { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' };

const TEMPLATE = `
  <section class="view-area">
    <div class="card-grid">
      <div class="view-card span-12">
        <div class="topbar">
          <strong>${ACTIVITY_TEXT.title}</strong>
          <p id="activityMessage" class="message"></p>
          <label class="activity-filter">${ACTIVITY_TEXT.user}
            <select id="activityUser"><option value="">${ACTIVITY_TEXT.allUsers}</option></select>
          </label>
        </div>
        <div class="users-table-wrap">
          <table class="users-table">
            <thead>
              <tr>
                <th>Zeit</th>
                <th>Benutzer</th>
                <th>Aktion</th>
                <th>Objekt</th>
              </tr>
            </thead>
            <tbody id="activityTbody">
              <tr><td colspan="4" class="message">${ACTIVITY_TEXT.loading}</td></tr>
            </tbody>
          </table>
        </div>
        <div class="form-actions">
          <button id="activityMore" type="button" class="secondary hidden">${ACTIVITY_TEXT.more}</button>
        </div>
        <p class="activity-hint">${ACTIVITY_TEXT.hint}</p>
      </div>
    </div>
  </section>
`;

let outletRef = null;
let loaded = 0;
// Zählt jede Anfrage; eine Antwort, die nicht mehr die neueste ist (Filter gewechselt), fällt weg.
let requestToken = 0;

export function mount(outlet) {
  outletRef = outlet;
  outlet.innerHTML = TEMPLATE;
  outlet.querySelector('#activityUser').addEventListener('change', function () { load(true); });
  outlet.querySelector('#activityMore').addEventListener('click', function () { load(false); });
  load(true);
}

export function unmount() {
  requestToken++;
  outletRef = null;
}

function load(reset) {
  if (!outletRef) return;
  const select = outletRef.querySelector('#activityUser');
  const more = outletRef.querySelector('#activityMore');
  const tbody = outletRef.querySelector('#activityTbody');
  const message = outletRef.querySelector('#activityMessage');
  const token = ++requestToken;
  if (reset) loaded = 0;
  more.disabled = true;
  const query = new URLSearchParams({ user: select.value, offset: String(loaded), limit: String(ACTIVITY_PAGE_SIZE) });
  api('/api/activity.php?' + query.toString())
    .then(function (data) {
      if (token !== requestToken) return;
      message.textContent = '';
      if (reset) {
        tbody.textContent = '';
        fillUsers(select, data.users || []);
      }
      const entries = data.entries || [];
      entries.forEach(function (entry) { tbody.appendChild(row(entry)); });
      loaded += entries.length;
      if (!loaded) {
        tbody.innerHTML = '<tr><td colspan="4" class="message">' + ACTIVITY_TEXT.empty + '</td></tr>';
      }
      more.disabled = false;
      more.classList.toggle('hidden', loaded >= (data.total || 0));
    })
    .catch(function (error) {
      if (token !== requestToken) return;
      more.disabled = false;
      message.textContent = error.message;
      if (reset) tbody.textContent = '';
    });
}

function fillUsers(select, users) {
  const current = select.value;
  select.length = 1;
  users.forEach(function (name) {
    const option = document.createElement('option');
    option.value = name;
    option.textContent = name;
    select.appendChild(option);
  });
  // Ein gefilterter Benutzer ohne eigene Einträge (nur fehlgeschlagene Logins) bleibt wählbar.
  if (current && users.indexOf(current) === -1) {
    const option = document.createElement('option');
    option.value = current;
    option.textContent = current;
    select.appendChild(option);
  }
  select.value = current;
}

function row(entry) {
  const tr = document.createElement('tr');
  [formatTime(entry.time), entry.user, entry.label, entry.target].forEach(function (text) {
    const td = document.createElement('td');
    td.textContent = text || ACTIVITY_TEXT.none;
    tr.appendChild(td);
  });
  return tr;
}

function formatTime(iso) {
  const d = new Date(iso);
  return isNaN(d.getTime()) ? iso : d.toLocaleString('de-DE', TIME_FORMAT);
}
