import { api, setMessage, escapeHtml } from '../core.js';
import { DB_FORM_FIELDS, readDbForm } from '../dbForm.js';
import { openModal, closeModal } from '../ui-modal.js';

let container = null;

export function mount(outlet) {
  container = outlet;
  container.innerHTML = `
    <section class="view-area plugins-view">
      <div class="view-card span-12">
        <div class="topbar">
          <strong>Plugins verwalten</strong>
          <button type="button" id="pluginsRefreshButton" class="secondary">Aktualisieren</button>
        </div>
        <p class="message" id="pluginsViewMessage"></p>
        <div id="pluginsViewList" class="plugins-list"></div>
      </div>
    </section>
  `;
  container.querySelector('#pluginsRefreshButton').addEventListener('click', load);
  load();
}

export function unmount() {
  closeModal();
  container = null;
}

function load() {
  api('/api/plugins/list.php')
    .then(function (data) {
      render(data.plugins || [], data.dbMessage || '');
    })
    .catch(showError);
}

function render(plugins, dbMessage) {
  const list = document.getElementById('pluginsViewList');
  const message = document.getElementById('pluginsViewMessage');
  if (!list) return;

  if (message) {
    setMessage(
      message,
      dbMessage,
      true
    );
  }

  if (!plugins.length) {
    list.innerHTML = '<p class="message">Keine Plugins gefunden.</p>';
    return;
  }

  list.innerHTML = plugins.map(pluginCard).join('');
  list.querySelectorAll('button[data-action]').forEach(function (button) {
    button.addEventListener('click', function () {
      handleAction(button.dataset.action, button.dataset.name);
    });
  });
}

function pluginCard(plugin) {
  if (plugin.error) {
    return `
      <article class="plugin-card">
        <div class="plugin-card__head">
          <h3>${escapeHtml(plugin.name)}</h3>
          <span class="status status--inactive">Fehler</span>
        </div>
        <p class="plugin-card__desc">${escapeHtml(plugin.error)}</p>
      </article>
    `;
  }

  const badges = [];
  if (plugin.requires && plugin.requires.database) badges.push('<span class="badge">DB</span>');
  if (plugin.requires && plugin.requires.mail) badges.push('<span class="badge">Mail</span>');
  if (plugin.requires && plugin.requires.uploads) badges.push('<span class="badge">Uploads</span>');

  const statusText = plugin.active ? 'Aktiv' : (plugin.installed ? 'Installiert, inaktiv' : 'Inaktiv');
  const statusClass = plugin.active ? 'active' : (plugin.installed ? 'installed' : 'inactive');
  const toggleAction = plugin.active ? 'deactivate' : 'activate';
  const toggleLabel = plugin.active ? 'Deaktivieren' : 'Aktivieren';
  const uninstallButton = plugin.installed
    ? `<button type="button" class="secondary" data-action="uninstall" data-name="${escapeHtml(plugin.name)}">Deinstallieren</button>`
    : '';

  return `
    <article class="plugin-card" data-name="${escapeHtml(plugin.name)}">
      <div class="plugin-card__head">
        <h3>${escapeHtml(plugin.label || plugin.name)}</h3>
        <span class="badges">${badges.join('')}</span>
        <span class="status status--${statusClass}">${statusText}</span>
      </div>
      <p class="plugin-card__desc">${escapeHtml(plugin.description || '')}</p>
      <footer>
        <small>v${escapeHtml(plugin.version || '0.0.0')}</small>
        <div class="plugin-card__actions">
          <button type="button" data-action="${toggleAction}" data-name="${escapeHtml(plugin.name)}">${toggleLabel}</button>
          ${uninstallButton}
        </div>
      </footer>
    </article>
  `;
}

function handleAction(action, name) {
  if (!action || !name) return;

  if (action === 'uninstall') {
    if (!window.confirm('Plugin "' + name + '" deinstallieren? Dabei werden alle Plugin-Daten und Tabellen gelöscht.')) {
      return;
    }
    api('/api/plugins/uninstall.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: name })
    }).then(reloadShell).catch(showError);
    return;
  }

  const endpoint = action === 'activate'
    ? '/api/plugins/activate.php'
    : '/api/plugins/deactivate.php';

  api(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: name })
  }).then(reloadShell).catch(function (error) {
    if (error.code === 'database_required') {
      showError(error);
      showDbSetupDialog(name);
      return;
    }
    showError(error);
  });
}

function reloadShell() {
  window.location.reload();
}

// Plugin braucht MySQL/MariaDB (database_required): Zugangsdaten im Dialog, testen und speichern,
// danach das Plugin erneut aktivieren. Fehler bleiben im Dialog.
function showDbSetupDialog(pluginName) {
  if (!container) return;
  const modal = openModal({
    title: 'Datenbank-Verbindung einrichten',
    bodyHtml: `<p>Das Plugin "${escapeHtml(pluginName)}" benötigt eine MySQL/MariaDB-Verbindung.</p>
      <form id="dbSetupForm" class="settings-form">${DB_FORM_FIELDS}</form>`,
    submitLabel: 'Verbindung testen & speichern',
    onSubmit(modalCtx) {
      const form = modalCtx.body.querySelector('#dbSetupForm');
      if (!form.reportValidity()) return;
      modalCtx.setBusy(true);
      modalCtx.setMessage('', false);
      api('/api/plugins/dbConfig.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(readDbForm(form))
      }).then(function () {
        modalCtx.close('submit');
        handleAction('activate', pluginName);
      }).catch(function (error) {
        modalCtx.setBusy(false);
        modalCtx.setMessage(error.message, false);
      });
    }
  });
  // Enter schickt ab wie in einem Formular mit Absende-Knopf: Das Formular hat keinen eigenen
  // (der Knopf sitzt in der Leiste des Dialogs), bei mehreren Feldern schickt der Browser es sonst nicht ab.
  modal.body.querySelector('#dbSetupForm').addEventListener('keydown', function (event) {
    if (event.key !== 'Enter' || event.target.tagName !== 'INPUT') return;
    event.preventDefault();
    modal.submitButton.click();
  });
}

function showError(error) {
  const message = document.getElementById('pluginsViewMessage');
  if (message) setMessage(message, error.message || String(error), false);
}
