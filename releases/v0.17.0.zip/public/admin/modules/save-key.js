import { onSaveKey } from '../site-editor/save-key.js';

// Strg+S in der Verwaltung: klickt den Speichern-Knopf des gerade sichtbaren Formulars, einmal für
// alle Ansichten und Plugin-Seiten. Speichern-Knöpfe sind solche mit SAVE_KEY_ATTR (Einstellungen,
// das Modal mit „Speichern“, ui-modal.js) und Absenden-Knöpfe in einem <form>. Ist ein Modal offen,
// zählt nur seins. Von mehreren gewinnt der in derselben Karte bzw. demselben Formular wie der Fokus,
// sonst der erste im sichtbaren Bereich. Ein gesperrter Knopf (Speichern läuft) tut nichts, ebenso
// eine Ansicht ohne Speichern-Knopf; den Dialog des Browsers gibt es nie (save-key.js).
// Die Seitenansicht hat ihren Seiten-Editor im iframe mit eigenem Strg+S.

export const SAVE_KEY_ATTR = 'data-save-key';
const SAVE_SELECTOR = '[' + SAVE_KEY_ATTR + '], form button[type="submit"]';
const OPEN_MODAL_SELECTOR = '.admin-modal:not(.hidden)';
const GROUP_SELECTOR = 'form, .view-card';

function usable(button) {
  return !button.disabled && button.getClientRects().length > 0;
}

function inView(button) {
  const rect = button.getBoundingClientRect();
  return rect.bottom > 0 && rect.top < window.innerHeight;
}

function saveButton() {
  const scope = document.querySelector(OPEN_MODAL_SELECTOR) || document;
  const buttons = Array.from(scope.querySelectorAll(SAVE_SELECTOR)).filter(usable);
  const focus = document.activeElement;
  const near = buttons.find(function (button) {
    const group = button.closest(GROUP_SELECTOR);
    return group !== null && group.contains(focus);
  });
  return near || buttons.find(inView) || null;
}

export function attachSaveKey() {
  onSaveKey(function () {
    const button = saveButton();
    if (button) button.click();
  });
}
