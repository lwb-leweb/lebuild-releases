// LEWEB · main.js
// Schlanke Interaktionen: Mobile-Navigation, Scroll-Header, helles/dunkles Design.

(function () {
    'use strict';

    const onReady = (fn) => {
        if (document.readyState !== 'loading') fn();
        else document.addEventListener('DOMContentLoaded', fn);
    };

    onReady(() => {
        initNavToggle();
        initHeaderShadow();
        initThemeToggle();
        document.querySelectorAll('[data-tabs]').forEach(initTabs);
    });

    // Die Wahl merkt sich der Browser; header.php setzt sie vor dem ersten Zeichnen.
    function initThemeToggle() {
        const toggle = document.querySelector('[data-theme-toggle]');
        if (!toggle) return;
        toggle.addEventListener('click', () => {
            const root = document.documentElement;
            const dark = root.dataset.theme !== 'dark';
            if (dark) root.dataset.theme = 'dark';
            else delete root.dataset.theme;
            try { localStorage.setItem('theme', dark ? 'dark' : 'light'); } catch (e) {}
        });
    }

    function initNavToggle() {
        const toggle = document.querySelector('[data-nav-toggle]');
        const nav = document.querySelector('[data-nav]');
        if (!toggle || !nav) return;

        const close = () => {
            nav.classList.remove('is-open');
            toggle.setAttribute('aria-expanded', 'false');
        };

        toggle.addEventListener('click', () => {
            const isOpen = nav.classList.toggle('is-open');
            toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        // Beim Wechsel auf Desktop-Breite Menü zurücksetzen
        const mq = window.matchMedia('(min-width: 960px)');
        mq.addEventListener('change', (e) => { if (e.matches) close(); });

        // ESC schließt das Menü
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') close();
        });

        // Klick außerhalb schließt das Menü (nur mobile)
        document.addEventListener('click', (e) => {
            if (!nav.classList.contains('is-open')) return;
            if (e.target.closest('[data-nav]') || e.target.closest('[data-nav-toggle]')) return;
            close();
        });
    }

    // Tabs (z. B. Bereiche der Öffnungszeiten): Klick oder Pfeiltasten wählen, nur das zugehörige Panel ist sichtbar.
    function initTabs(box) {
        const tabs = Array.from(box.querySelectorAll('[role="tab"]'));
        const select = (tab) => {
            tabs.forEach((t) => {
                const on = t === tab;
                t.setAttribute('aria-selected', on ? 'true' : 'false');
                t.tabIndex = on ? 0 : -1;
                const panel = document.getElementById(t.getAttribute('aria-controls'));
                if (panel) panel.hidden = !on;
            });
        };
        tabs.forEach((tab, i) => {
            tab.addEventListener('click', () => select(tab));
            tab.addEventListener('keydown', (e) => {
                const step = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[e.key];
                if (!step) return;
                e.preventDefault();
                const next = tabs[(i + step + tabs.length) % tabs.length];
                next.focus();
                select(next);
            });
        });
    }

    function initHeaderShadow() {
        const header = document.querySelector('[data-header]');
        if (!header) return;
        const update = () => {
            header.classList.toggle('is-scrolled', window.scrollY > 4);
        };
        update();
        window.addEventListener('scroll', update, { passive: true });
    }
})();
