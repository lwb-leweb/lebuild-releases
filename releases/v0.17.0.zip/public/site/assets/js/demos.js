// LEWEB · demos.js
// Vorführungen im Hero der Startseite: je Folie eine Bäckerei-Seite, auf der ein Zeiger zeigt, wie
// der Editor funktioniert (Markup in includes/demos/). Wer hineinklickt, probiert es selbst.

(function () {
    'use strict';

    const onReady = (fn) => {
        if (document.readyState !== 'loading') fn();
        else document.addEventListener('DOMContentLoaded', fn);
    };

    onReady(() => {
        initSlides([initDemo(), initDemo2(), initDemo3()]);
    });

    // Gemeinsame Werkzeuge der Vorführungen: Zeiger, grünes Leuchten mit Schild, Hinweis unten,
    // Warten mit Abbruch. Jeder Lauf hat eine Nummer (run); wartet ein älterer Lauf noch, bricht er ab.
    function demoKit(root) {
        const pick = (selector) => root.querySelector(selector);
        const win = pick('.demo__window');
        const cursor = pick('[data-demo-cursor]');
        const glow = pick('[data-demo-glow]');
        const tag = pick('[data-demo-tag]');
        const toast = pick('[data-demo-toast]');
        const STOP = {};
        const kit = {
            pick: pick,
            win: win,
            run: 0,
            toastText: toast.textContent,
            next: () => ++kit.run,
            stop: () => { kit.run++; },
            isLive: () => root.classList.contains('is-live'),
            wait: (ms, id) => new Promise((resolve, reject) => {
                setTimeout(() => (id === kit.run ? resolve() : reject(STOP)), ms);
            }),
            // Lage im Fenster in CSS-Pixeln; die Bühne kann verkleinert sein (zoom, initSlides),
            // getBoundingClientRect liefert dann sichtbare Pixel.
            box: (el) => {
                const outer = win.getBoundingClientRect();
                const rect = el.getBoundingClientRect();
                const z = outer.width / win.offsetWidth || 1;
                return { x: (rect.left - outer.left) / z, y: (rect.top - outer.top) / z, w: rect.width / z, h: rect.height / z };
            },
            jumpTo: (x, y) => {
                cursor.style.transition = 'none';
                cursor.style.transform = 'translate(' + x + 'px,' + y + 'px)';
                cursor.getBoundingClientRect();
                cursor.style.transition = '';
            },
            // Zeiger an den Rand des Fensters, unten in der Mitte.
            park: () => {
                const b = kit.box(win);
                kit.jumpTo(b.w * 0.6, b.h * 0.95);
            },
            moveTo: (el, fx, fy) => {
                const b = kit.box(el);
                cursor.style.transform = 'translate(' + (b.x + b.w * fx) + 'px,' + (b.y + b.h * fy) + 'px)';
            },
            showGlow: (el, text) => {
                const b = kit.box(el);
                glow.style.cssText = 'left:' + (b.x - 6) + 'px;top:' + (b.y - 6) + 'px;width:' + (b.w + 12) + 'px;height:' + (b.h + 12) + 'px';
                tag.textContent = text;
                glow.classList.add('is-on');
            },
            hideGlow: () => glow.classList.remove('is-on'),
            click: (button) => {
                cursor.classList.add('is-click');
                if (button) button.classList.add('is-press');
                setTimeout(() => {
                    cursor.classList.remove('is-click');
                    if (button) button.classList.remove('is-press');
                }, 220);
            },
            popToast: (text) => {
                toast.textContent = text || kit.toastText;
                toast.classList.add('is-on');
                setTimeout(() => toast.classList.remove('is-on'), 2600);
            },
            hideToast: () => toast.classList.remove('is-on'),
            // Leiste box über das Element target setzen (passt sie nicht darüber, darunter).
            placeAbove: (el, target) => {
                const b = kit.box(target);
                const max = kit.box(win).w - el.offsetWidth - 8;
                const above = b.y - el.offsetHeight - 10;
                el.style.left = Math.max(8, Math.min(b.x, max)) + 'px';
                el.style.top = (above > 8 ? above : b.y + b.h + 10) + 'px';
            },
            typeValue: async (input, text, id, ms) => {
                for (const ch of text) {
                    input.value += ch;
                    await kit.wait(ms, id);
                }
            },
            retype: async (el, text, id) => {
                while (el.textContent.length) {
                    el.textContent = el.textContent.slice(0, -1);
                    await kit.wait(22, id);
                }
                for (const ch of text) {
                    el.textContent += ch;
                    await kit.wait(60, id);
                }
            }
        };
        return kit;
    }

    // Vorführung „Texte, Bilder, Buttons“, wie im echten Editor: Überschrift neu tippen; im Absatz
    // ein Wort markieren, fett machen und verlinken (Mini-Leiste); das Bild tauschen (Dialog mit
    // Ablagefläche und Alt-Text); den Button über „Bearbeiten“ umbenennen und sein Link-Ziel ändern;
    // Speichern. In Schleife (gestartet von initSlides). Ein Klick in die Vorschau beendet das
    // Abspielen; dann lässt sich dort selbst tippen, formatieren und ein eigenes Bild wählen (bleibt
    // nur im Browser).
    function initDemo() {
        const root = document.querySelector('[data-demo]');
        const template = root && root.querySelector('[data-demo-template]');
        if (!template) return;
        root.appendChild(template.content.cloneNode(true));

        const kit = demoKit(root);
        const pick = kit.pick;
        const title = pick('[data-demo-target="title"]');
        const lead = pick('[data-demo-target="lead"]');
        let word = pick('[data-demo-word]');
        const button = pick('[data-demo-target="button"]');
        const image = pick('[data-demo-target="image"]');
        const imageNew = pick('.demo__img--b');
        const save = pick('[data-demo-target="save"]');
        const file = pick('[data-demo-file]');
        const status = pick('[data-demo-status]');
        const count = pick('[data-demo-count]');
        const undo = pick('[data-demo-undo]');
        const popover = pick('[data-demo-popover]');
        const drop = pick('[data-demo-drop]');
        const dropImg = pick('[data-demo-drop-img]');
        const fileInput = drop.querySelector('input');
        const picker = pick('[data-demo-picker]');
        const alt = pick('[data-demo-alt]');
        const apply = pick('[data-demo-apply]');
        const cancel = pick('[data-demo-cancel]');
        const mini = pick('[data-demo-mini]');
        const miniButton = (name) => mini.querySelector('[data-mini="' + name + '"]');
        const miniInput = pick('[data-mini-input]');
        const miniTarget = pick('[data-mini-target]');
        const chips = pick('[data-demo-chips]');
        const chipEdit = chips.querySelector('[data-chip="edit"]');

        const TEXT = {
            editText: 'Text ändern',
            editHeading: 'Überschrift ändern',
            editLink: 'Link ändern',
            swapImage: 'Bild tauschen'
        };
        const original = {
            title: title.textContent,
            lead: lead.innerHTML,
            button: button.textContent,
            href: button.dataset.demoHref,
            alt: alt.value,
            image: dropImg.getAttribute('src'),
            next: imageNew.getAttribute('src')
        };
        const SAMPLE = {
            title: title.dataset.demoNew,
            link: '/unser-mehl',
            alt: 'Erdbeertorte mit frischen Erdbeeren',
            button: button.dataset.demoNew,
            href: button.dataset.demoNewHref
        };

        let changes = 0;
        let swapped = false;
        let href = original.href;

        const setChanges = (n) => {
            changes = n;
            count.textContent = n;
            status.hidden = !n;
            undo.classList.toggle('is-ready', n > 0);
            save.classList.toggle('is-ready', n > 0);
        };

        // Bild auf der Seite und in der Ablagefläche; null zeigt wieder das ursprüngliche.
        function showImage(src) {
            if (src) imageNew.src = src;
            image.classList.toggle('is-swapped', Boolean(src));
            dropImg.src = src || original.image;
        }

        // Dialog neben das Bild, sonst über das Bild (schmales Fenster).
        function openPopover() {
            const b = kit.box(image);
            const w = popover.offsetWidth;
            const h = popover.offsetHeight;
            let left = b.x - w - 16;
            if (left < 12) left = Math.max(12, b.x + (b.w - w) / 2);
            const top = Math.min(Math.max(12, b.y + (b.h - h) / 2), kit.box(kit.win).h - h - 12);
            popover.style.left = left + 'px';
            popover.style.top = top + 'px';
            popover.classList.add('is-open');
            image.classList.add('is-active');
            popover.dataset.before = swapped ? imageNew.src : '';
            popover.dataset.alt = alt.value;
        }
        function closePopover(keep) {
            popover.classList.remove('is-open');
            image.classList.remove('is-active');
            drop.classList.remove('is-over');
            if (keep) {
                if (image.classList.contains('is-swapped') !== swapped || alt.value !== popover.dataset.alt) setChanges(changes + 1);
                swapped = image.classList.contains('is-swapped');
            } else {
                showImage(popover.dataset.before || null);
                alt.value = popover.dataset.alt;
            }
        }

        // Mini-Leiste: 'text' (Fett, Kursiv, Link) über dem Absatz, 'target' (Link-Ziel) über dem Button.
        function openMini(mode, target) {
            mini.classList.toggle('is-target', mode === 'target');
            mini.classList.remove('is-linking');
            mini.classList.add('is-open');
            kit.placeAbove(mini, target);
        }
        function closeMini() {
            mini.classList.remove('is-open', 'is-linking');
            mini.querySelectorAll('.is-on').forEach((node) => node.classList.remove('is-on'));
        }

        // Klick daneben: offene Bearbeitung von Absatz oder Button abschließen.
        function finishEditing() {
            if (lead.classList.contains('is-active')) {
                lead.classList.remove('is-active');
                lead.removeAttribute('contenteditable');
                word.classList.remove('is-selected');
            }
            if (button.classList.contains('is-active')) {
                button.classList.remove('is-active', 'is-editing');
                button.removeAttribute('contenteditable');
                href = miniTarget.value;
            }
            closeMini();
            chips.classList.remove('is-open');
        }

        function reset() {
            title.textContent = original.title;
            lead.innerHTML = original.lead;
            word = pick('[data-demo-word]');
            lead.classList.remove('is-active');
            button.textContent = original.button;
            button.classList.remove('is-active', 'is-editing');
            href = original.href;
            title.classList.remove('is-editing');
            imageNew.src = original.next;
            showImage(null);
            swapped = false;
            alt.value = original.alt;
            popover.classList.remove('is-open');
            image.classList.remove('is-active');
            closeMini();
            chips.classList.remove('is-open');
            file.classList.remove('is-on');
            kit.hideToast();
            kit.hideGlow();
            setChanges(0);
            kit.park();
        }

        async function play(id) {
            const wait = (ms) => kit.wait(ms, id);
            reset();
            await wait(700);
            // 1. Überschrift neu tippen
            kit.moveTo(title, 0.35, 0.6);
            await wait(900);
            kit.showGlow(title, TEXT.editHeading);
            await wait(700);
            kit.click();
            title.classList.add('is-editing');
            await wait(300);
            await kit.retype(title, SAMPLE.title, id);
            setChanges(1);
            await wait(500);
            title.classList.remove('is-editing');
            kit.hideGlow();
            // 2. Wort markieren, fett, Link
            kit.moveTo(lead, 0.6, 0.5);
            await wait(800);
            kit.showGlow(lead, TEXT.editText);
            await wait(600);
            kit.click();
            kit.hideGlow();
            lead.classList.add('is-active');
            openMini('text', lead);
            await wait(500);
            kit.moveTo(word, 0, 0.6);
            await wait(700);
            kit.moveTo(word, 1, 0.6);
            word.classList.add('is-selected');
            await wait(700);
            kit.moveTo(miniButton('bold'), 0.5, 0.6);
            await wait(700);
            kit.click(miniButton('bold'));
            word.classList.add('is-bold');
            miniButton('bold').classList.add('is-on');
            setChanges(2);
            await wait(600);
            kit.moveTo(miniButton('link'), 0.5, 0.6);
            await wait(600);
            kit.click(miniButton('link'));
            mini.classList.add('is-linking');
            kit.placeAbove(mini, lead);
            miniInput.value = '';
            await wait(400);
            await kit.typeValue(miniInput, SAMPLE.link, id, 60);
            await wait(300);
            kit.moveTo(miniButton('apply'), 0.5, 0.6);
            await wait(700);
            kit.click(miniButton('apply'));
            word.classList.add('is-link');
            mini.classList.remove('is-linking');
            await wait(600);
            finishEditing();
            // 3. Bild tauschen
            kit.moveTo(image, 0.5, 0.45);
            await wait(900);
            kit.showGlow(image, TEXT.swapImage);
            await wait(800);
            kit.click();
            kit.hideGlow();
            openPopover();
            await wait(800);
            const b = kit.box(kit.win);
            kit.jumpTo(b.w + 10, b.h * 0.55);
            file.classList.add('is-on');
            await wait(150);
            kit.moveTo(drop, 0.5, 0.5);
            await wait(800);
            drop.classList.add('is-over');
            await wait(500);
            file.classList.remove('is-on');
            drop.classList.remove('is-over');
            showImage(original.next);
            await wait(800);
            kit.moveTo(alt, 0.5, 0.6);
            await wait(600);
            kit.click();
            alt.value = '';
            await kit.typeValue(alt, SAMPLE.alt, id, 35);
            await wait(300);
            kit.moveTo(apply, 0.5, 0.6);
            await wait(700);
            kit.click(apply);
            closePopover(true);
            await wait(600);
            // 4. Button: Bearbeiten, Text und Link-Ziel
            kit.moveTo(button, 0.5, 0.55);
            await wait(800);
            kit.showGlow(button, TEXT.editLink);
            await wait(700);
            kit.click();
            kit.hideGlow();
            button.classList.add('is-active');
            chips.classList.add('is-open');
            kit.placeAbove(chips, button);
            await wait(700);
            kit.moveTo(chipEdit, 0.5, 0.6);
            await wait(700);
            kit.click(chipEdit);
            chips.classList.remove('is-open');
            miniTarget.value = href;
            openMini('target', button);
            button.classList.add('is-editing');
            await wait(300);
            await kit.retype(button, SAMPLE.button, id);
            button.classList.remove('is-editing');
            await wait(300);
            kit.moveTo(miniTarget, 0.8, 0.6);
            await wait(700);
            kit.click();
            miniTarget.value = '';
            await kit.typeValue(miniTarget, SAMPLE.href, id, 70);
            setChanges(changes + 1);
            await wait(500);
            finishEditing();
            // 5. Speichern
            kit.moveTo(save, 0.5, 0.55);
            await wait(900);
            kit.click(save);
            setChanges(0);
            kit.popToast();
            await wait(3600);
            root.dispatchEvent(new CustomEvent('demo:cycle', { bubbles: true }));
            if (id === kit.run) play(id).catch(() => {});
        }

        function start() {
            root.classList.remove('is-live');
            title.removeAttribute('contenteditable');
            lead.removeAttribute('contenteditable');
            button.removeAttribute('contenteditable');
            play(kit.next()).catch(() => {});
        }

        // Selbst ausprobieren: Abspielen stoppen, Texte bearbeitbar, Bild über den Dialog tauschen.
        function goLive() {
            if (kit.isLive()) return;
            kit.stop();
            kit.hideGlow();
            file.classList.remove('is-on');
            title.classList.remove('is-editing');
            button.classList.remove('is-editing');
            if (popover.classList.contains('is-open')) closePopover(false);
            finishEditing();
            root.classList.add('is-live');
            title.setAttribute('contenteditable', 'true');
            root.dispatchEvent(new CustomEvent('demo:live', { bubbles: true }));
        }

        // Eigenes Bild: auswählen oder hineinziehen, nur als Vorschau im Browser.
        function useFile(f) {
            if (!f || !f.type.startsWith('image/')) return;
            const reader = new FileReader();
            reader.onload = () => showImage(String(reader.result));
            reader.readAsDataURL(f);
        }

        // Markierung im Absatz fett, kursiv oder verlinkt (nur im Browser).
        function format(command) {
            if (command === 'link') {
                mini.classList.add('is-linking');
                kit.placeAbove(mini, lead);
                miniInput.value = '';
                miniInput.focus();
                return;
            }
            document.execCommand(command);
            setChanges(Math.max(changes, 1));
        }

        root.addEventListener('pointerdown', goLive);
        root.addEventListener('click', (e) => {
            if (!kit.isLive()) return;
            const inUi = e.target.closest('[data-demo-mini], [data-demo-chips], [data-demo-popover]');
            if (inUi) return;
            if (lead.contains(e.target)) {
                if (!lead.classList.contains('is-active')) {
                    finishEditing();
                    lead.classList.add('is-active');
                    lead.setAttribute('contenteditable', 'true');
                    openMini('text', lead);
                }
                return;
            }
            if (button.contains(e.target)) {
                if (!button.classList.contains('is-active')) {
                    finishEditing();
                    button.classList.add('is-active');
                    chips.classList.add('is-open');
                    kit.placeAbove(chips, button);
                }
                return;
            }
            finishEditing();
        });
        mini.addEventListener('mousedown', (e) => { if (e.target.tagName === 'BUTTON') e.preventDefault(); });
        mini.addEventListener('click', (e) => {
            const tool = e.target.closest('[data-mini]');
            if (!tool || !kit.isLive()) return;
            if (tool.dataset.mini === 'apply') {
                const target = miniInput.value.trim();
                lead.focus();
                if (target) document.execCommand('createLink', false, target);
                mini.classList.remove('is-linking');
                setChanges(Math.max(changes, 1));
            } else {
                format(tool.dataset.mini === 'bold' ? 'bold' : tool.dataset.mini === 'italic' ? 'italic' : 'link');
            }
        });
        chips.addEventListener('click', (e) => {
            const chip = e.target.closest('[data-chip]');
            if (!chip || !kit.isLive()) return;
            chips.classList.remove('is-open');
            if (chip.dataset.chip === 'edit') {
                miniTarget.value = href;
                openMini('target', button);
                button.setAttribute('contenteditable', 'true');
                button.focus();
            } else {
                finishEditing();
            }
        });
        root.addEventListener('input', (e) => {
            if (e.target === alt || e.target === miniInput) return;
            setChanges(Math.max(changes, 1));
        });
        root.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && e.target === alt) { e.preventDefault(); closePopover(true); return; }
            if (e.key === 'Enter' && e.target === miniInput) { e.preventDefault(); miniButton('apply').click(); return; }
            if (e.key === 'Enter') { e.preventDefault(); e.target.blur(); finishEditing(); }
            if (e.key === 'Escape') {
                if (popover.classList.contains('is-open')) closePopover(false);
                finishEditing();
            }
        });
        image.addEventListener('click', () => {
            if (!kit.isLive() || popover.classList.contains('is-open')) return;
            finishEditing();
            openPopover();
        });
        drop.addEventListener('click', (e) => { if (!kit.isLive()) e.preventDefault(); });
        picker.addEventListener('click', () => { if (kit.isLive()) fileInput.click(); });
        fileInput.addEventListener('change', () => useFile(fileInput.files[0]));
        drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('is-over'); });
        drop.addEventListener('dragleave', () => drop.classList.remove('is-over'));
        drop.addEventListener('drop', (e) => {
            e.preventDefault();
            drop.classList.remove('is-over');
            useFile(e.dataTransfer.files[0]);
        });
        apply.addEventListener('click', () => { if (kit.isLive()) closePopover(true); });
        cancel.addEventListener('click', () => { if (kit.isLive()) closePopover(false); });
        save.addEventListener('click', () => {
            if (!kit.isLive() || !changes) return;
            finishEditing();
            setChanges(0);
            kit.popToast();
        });

        const still = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        return { start: still ? goLive : start, stop: kit.stop };
    }

    // Vorführung „Einträge verwalten“, wie im echten Editor: „+ Neuer Eintrag“ unter der Liste,
    // Foto hineinziehen, Felder ausfüllen, Hinzufügen; danach an einem Eintrag „Löschen“ mit
    // Rückfrage. In Schleife (gestartet von initSlides). Ein Klick hinein beendet das Abspielen;
    // dann lassen sich Einträge anlegen, bearbeiten, verschieben und löschen (nur im Browser).
    function initDemo2() {
        const root = document.querySelector('[data-demo2]');
        const template = root && root.querySelector('[data-demo2-template]');
        if (!template) return;
        root.appendChild(template.content.cloneNode(true));

        const kit = demoKit(root);
        const pick = kit.pick;
        const { box, jumpTo, moveTo, showGlow, hideGlow, click, popToast, isLive } = kit;
        const win = kit.win;
        const add = pick('[data-demo2-add]');
        const grid = pick('[data-demo2-grid]');
        const count = pick('[data-demo2-count]');
        const panel = pick('[data-demo2-panel]');
        const panelTitle = pick('.demo2__panel-title');
        const fields = panel.elements;
        const drop = pick('[data-demo2-drop]');
        const preview = pick('[data-demo2-preview]');
        const submit = pick('.demo2__submit');
        const confirmBox = pick('[data-demo2-confirm]');
        const confirmTitle = pick('[data-demo2-confirm-title]');
        const confirmYes = pick('[data-demo2-confirm-yes]');
        const confirmNo = pick('[data-demo2-confirm-no]');
        const file = pick('[data-demo2-file]');

        const SAMPLE = {
            photo: 'assets/img/demo/team-lisa.jpg',
            name: 'Lisa Berger',
            role: 'Konditorin',
            since: '2025',
            about: 'Macht die beste Sachertorte im Ort.'
        };
        const TEXT = {
            added: kit.toastText,
            saved: (name) => 'Gespeichert – ' + name.split(/\s+/)[0] + ' ist jetzt im Team.',
            deleted: 'Gelöscht.',
            question: (name) => '‚' + name + '‘ löschen?',
            count: (n) => n === 1 ? '1 Eintrag' : n + ' Einträge',
            newTitle: panelTitle.textContent,
            editTitle: 'Teammitglied bearbeiten',
            submit: submit.textContent,
            update: 'Speichern',
            tools: [['edit', 'Bearbeiten'], ['up', '↑'], ['down', '↓'], ['delete', 'Löschen']]
        };
        const COLORS = [['#f9d0e0', '#e0709b'], ['#d9d0f9', '#8a70e0'], ['#fde2b8', '#e0a040']];
        const MAX_NEW = 3;

        let added = 0;
        let photo = '';
        let editing = null;
        let answer = null;
        const wait = kit.wait;
        const initials = (name) => name.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join('');
        const el = (tagName, className, text) => {
            const node = document.createElement(tagName);
            node.className = className;
            if (text) node.textContent = text;
            return node;
        };
        const cards = () => Array.from(grid.querySelectorAll('.demo2__card:not([data-removed])'));

        function updateCount() {
            count.textContent = TEXT.count(cards().length);
        }

        function withTools(card) {
            const tools = el('div', 'demo2__tools');
            TEXT.tools.forEach(([act, label]) => {
                const button = el('button', act === 'delete' ? 'is-danger' : '', label);
                button.type = 'button';
                button.dataset.act = act;
                tools.appendChild(button);
            });
            card.appendChild(tools);
            return card;
        }

        // Inhalt eines Eintrags aus der Karte (für Bearbeiten).
        function readCard(card) {
            const img = card.querySelector('img.demo2__photo');
            const since = card.querySelector('.demo2__since');
            const about = card.querySelector('.demo2__about');
            return {
                photo: img ? img.getAttribute('src') : '',
                name: card.querySelector('b').textContent,
                role: card.querySelector('small').textContent,
                since: since ? since.textContent.replace(/\D/g, '') : '',
                about: about ? about.textContent.replace(/^„|“$/g, '') : ''
            };
        }

        // Inhalt einer Karte aus einem Eintrag, Werkzeuge dazu (neue Karten und Bearbeiten an Ort und Stelle).
        function fillCard(card, entry) {
            card.textContent = '';
            let pic;
            if (entry.photo) {
                pic = el('img', 'demo2__photo');
                pic.src = entry.photo;
                pic.alt = '';
            } else {
                const [a, b] = COLORS[added % COLORS.length];
                pic = el('span', 'demo2__photo', initials(entry.name));
                pic.style.cssText = '--a:' + a + ';--b:' + b;
            }
            added++;
            card.append(pic, el('b', '', entry.name), el('small', '', entry.role));
            if (entry.since) card.append(el('span', 'demo2__since', 'Im Team seit ' + entry.since));
            if (entry.about) card.append(el('span', 'demo2__about', '„' + entry.about + '“'));
            return withTools(card);
        }

        function buildCard(entry) {
            const card = el('div', 'demo2__card is-new');
            card.dataset.new = '';
            grid.querySelectorAll('.is-new').forEach((node) => node.classList.remove('is-new'));
            return fillCard(card, entry);
        }

        function addCard(entry) {
            grid.appendChild(buildCard(entry));
            const extra = grid.querySelectorAll('[data-new]');
            if (extra.length > MAX_NEW) extra[0].remove();
            updateCount();
        }

        function removeCard(card) {
            card.classList.remove('is-hover');
            card.classList.add('is-removing');
            setTimeout(() => {
                card.dataset.removed = '';
                updateCount();
            }, 350);
        }

        function setPhoto(src) {
            photo = src;
            preview.hidden = !src;
            if (src) preview.src = src;
            else preview.removeAttribute('src');
        }

        function openForm(entry) {
            panel.reset();
            setPhoto(entry ? entry.photo : '');
            if (entry) {
                fields.name.value = entry.name;
                fields.role.value = entry.role;
                fields.since.value = entry.since;
                fields.about.value = entry.about;
            }
            panelTitle.textContent = entry ? TEXT.editTitle : TEXT.newTitle;
            submit.textContent = entry ? TEXT.update : TEXT.submit;
            panel.classList.add('is-open');
        }

        function closeForm() {
            panel.classList.remove('is-open');
            drop.classList.remove('is-over');
            editing = null;
        }

        function openConfirm(card) {
            confirmTitle.textContent = TEXT.question(card.querySelector('b').textContent);
            confirmBox.classList.add('is-open');
        }

        // Neustart: neue Karten weg, die ursprünglichen in alter Reihenfolge und mit altem Inhalt zurück.
        function reset() {
            grid.querySelectorAll('[data-new]').forEach((node) => node.remove());
            originals.forEach((card) => {
                if (edited.has(card)) card.innerHTML = edited.get(card);
                delete card.dataset.removed;
                card.classList.remove('is-removing', 'is-hover');
                grid.appendChild(card);
            });
            edited.clear();
            closeForm();
            panel.reset();
            setPhoto('');
            confirmBox.classList.remove('is-open');
            file.classList.remove('is-on');
            kit.hideToast();
            hideGlow();
            updateCount();
            const b = box(win);
            jumpTo(b.w * 0.5, b.h * 0.95);
        }

        async function type(input, text, id, ms) {
            for (const ch of text) {
                input.value += ch;
                await wait(ms, id);
            }
        }

        async function fill(input, text, id, ms) {
            moveTo(input, 0.3, 0.6);
            await wait(650, id);
            click();
            await type(input, text, id, ms);
            await wait(250, id);
        }

        async function play(id) {
            reset();
            await wait(800, id);
            // Neuer Eintrag
            moveTo(add, 0.5, 0.6);
            await wait(900, id);
            showGlow(add, 'Eintrag hinzufügen');
            await wait(700, id);
            click();
            hideGlow();
            openForm(null);
            await wait(700, id);
            const b = box(win);
            jumpTo(b.w + 10, b.h * 0.5);
            file.classList.add('is-on');
            await wait(150, id);
            moveTo(drop, 0.5, 0.5);
            await wait(700, id);
            showGlow(drop, 'Foto hier ablegen');
            await wait(700, id);
            file.classList.remove('is-on');
            setPhoto(SAMPLE.photo);
            await wait(500, id);
            hideGlow();
            await fill(fields.name, SAMPLE.name, id, 65);
            await fill(fields.role, SAMPLE.role, id, 65);
            await fill(fields.since, SAMPLE.since, id, 90);
            await fill(fields.about, SAMPLE.about, id, 40);
            moveTo(submit, 0.5, 0.6);
            await wait(900, id);
            click();
            closeForm();
            addCard(SAMPLE);
            popToast(TEXT.added);
            await wait(2600, id);
            // Eintrag löschen
            const target = cards()[2];
            moveTo(target, 0.5, 0.35);
            await wait(900, id);
            target.classList.add('is-hover');
            await wait(700, id);
            const del = target.querySelector('[data-act="delete"]');
            moveTo(del, 0.5, 0.6);
            await wait(800, id);
            click(del);
            await wait(300, id);
            openConfirm(target);
            await wait(1100, id);
            moveTo(confirmYes, 0.5, 0.6);
            await wait(800, id);
            click(confirmYes);
            await wait(200, id);
            confirmBox.classList.remove('is-open');
            removeCard(target);
            popToast(TEXT.deleted);
            await wait(3200, id);
            root.dispatchEvent(new CustomEvent('demo:cycle', { bubbles: true }));
            if (id === kit.run) play(id).catch(() => {});
        }

        function start() {
            root.classList.remove('is-live');
            play(kit.next()).catch(() => {});
        }

        function goLive() {
            if (isLive()) return;
            kit.stop();
            hideGlow();
            file.classList.remove('is-on');
            closeForm();
            confirmBox.classList.remove('is-open');
            grid.querySelectorAll('.is-hover').forEach((card) => card.classList.remove('is-hover'));
            root.classList.add('is-live');
            root.dispatchEvent(new CustomEvent('demo:live', { bubbles: true }));
        }

        // Eigenes Foto: auswählen oder hineinziehen, nur als Vorschau im Browser.
        function usePhoto(f) {
            if (!f || !f.type.startsWith('image/')) return;
            const reader = new FileReader();
            reader.onload = () => setPhoto(String(reader.result));
            reader.readAsDataURL(f);
        }

        const originals = Array.from(grid.querySelectorAll('.demo2__card'));
        originals.forEach(withTools);
        // Ursprünglicher Inhalt bearbeiteter Karten, für den Neustart.
        const edited = new Map();
        updateCount();

        root.addEventListener('pointerdown', goLive);
        add.addEventListener('click', () => {
            if (!isLive()) return;
            editing = null;
            openForm(null);
            fields.name.focus();
        });
        grid.addEventListener('click', (e) => {
            const button = e.target.closest('[data-act]');
            if (!button || !isLive()) return;
            const card = button.closest('.demo2__card');
            const act = button.dataset.act;
            if (act === 'edit') {
                editing = card;
                openForm(readCard(card));
                fields.name.focus();
            } else if (act === 'delete') {
                answer = card;
                openConfirm(card);
            } else {
                const list = cards();
                const i = list.indexOf(card);
                const other = list[act === 'up' ? i - 1 : i + 1];
                if (other) {
                    if (act === 'up') other.before(card);
                    else other.after(card);
                }
            }
        });
        confirmYes.addEventListener('click', () => {
            confirmBox.classList.remove('is-open');
            if (answer) removeCard(answer);
            answer = null;
            popToast(TEXT.deleted);
        });
        confirmNo.addEventListener('click', () => {
            confirmBox.classList.remove('is-open');
            answer = null;
        });
        fields.photo.addEventListener('change', () => usePhoto(fields.photo.files[0]));
        drop.addEventListener('click', (e) => { if (!isLive()) e.preventDefault(); });
        drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('is-over'); });
        drop.addEventListener('dragleave', () => drop.classList.remove('is-over'));
        drop.addEventListener('drop', (e) => {
            e.preventDefault();
            drop.classList.remove('is-over');
            goLive();
            usePhoto(e.dataTransfer.files[0]);
        });
        panel.addEventListener('submit', (e) => {
            e.preventDefault();
            if (!isLive()) return;
            const name = fields.name.value.trim();
            if (!name) { fields.name.focus(); return; }
            const entry = {
                photo: photo,
                name: name,
                role: fields.role.value.trim(),
                since: fields.since.value.trim(),
                about: fields.about.value.trim()
            };
            if (editing) {
                if (originals.includes(editing) && !edited.has(editing)) edited.set(editing, editing.innerHTML);
                fillCard(editing, entry);
            } else {
                addCard(entry);
            }
            closeForm();
            popToast(TEXT.saved(name));
        });
        root.addEventListener('keydown', (e) => {
            if (e.key !== 'Escape') return;
            closeForm();
            confirmBox.classList.remove('is-open');
        });

        const still = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        return { start: still ? goLive : start, stop: kit.stop };
    }

    // Vorführung „Öffnungszeiten ändern“: Klick auf den Block öffnet das Formular (je Tag Schalter
    // und von–bis, dazu ein Hinweis über den Zeiten); der Zeiger öffnet den Sonntag, trägt die Zeiten
    // und einen Hinweis ein und speichert. In Schleife (gestartet von initSlides). Ein Klick hinein
    // beendet das Abspielen; dann lässt sich das Formular selbst ausfüllen (nur im Browser).
    function initDemo3() {
        const root = document.querySelector('[data-demo3]');
        const template = root && root.querySelector('[data-demo3-template]');
        if (!template) return;
        root.appendChild(template.content.cloneNode(true));

        const kit = demoKit(root);
        const pick = kit.pick;
        const hours = pick('[data-demo3-hours]');
        const rows = pick('[data-demo3-rows]');
        const notice = pick('[data-demo3-notice]');
        const panel = pick('[data-demo3-panel]');
        const submit = panel.querySelector('.demo2__submit');
        const days = Array.from(panel.querySelectorAll('[data-day]'));
        const SAMPLE = { day: 'So', from: '07:00', to: '11:00', note: 'Betriebsurlaub vom 4. bis 18. August' };
        const CLOSED = 'geschlossen';

        const dayParts = (row) => ({
            name: row.dataset.day,
            toggle: row.querySelector('.demo3__switch'),
            from: row.querySelectorAll('input')[0],
            to: row.querySelectorAll('input')[1]
        });
        const original = days.map((row) => {
            const d = dayParts(row);
            return { open: d.toggle.classList.contains('is-on'), from: d.from.value, to: d.to.value };
        });
        const short = (time) => time.replace(/^0/, '').replace(/:00$/, '');

        // Zeiten der Seite aus dem Formular; gleiche Nachbartage zusammen („Mo–Fr“).
        function render(highlight) {
            const groups = [];
            days.forEach((row) => {
                const d = dayParts(row);
                const open = d.toggle.classList.contains('is-on') && d.from.value && d.to.value;
                const text = open ? short(d.from.value) + '–' + short(d.to.value) + ' Uhr' : CLOSED;
                const last = groups[groups.length - 1];
                if (last && last.text === text) last.end = d.name;
                else groups.push({ start: d.name, end: d.name, text: text, open: Boolean(open) });
            });
            rows.textContent = '';
            groups.forEach((g) => {
                const row = document.createElement('div');
                row.className = 'demo3__row' + (g.open ? '' : ' is-closed') + (highlight && g.end === highlight ? ' is-new' : '');
                const label = document.createElement('span');
                label.textContent = g.start === g.end ? g.start : g.start + '–' + g.end;
                const value = document.createElement('span');
                value.textContent = g.text;
                row.append(label, value);
                rows.appendChild(row);
            });
            const note = panel.elements.note.value.trim();
            notice.textContent = note;
            notice.classList.toggle('is-on', Boolean(note));
        }

        function reset() {
            days.forEach((row, i) => {
                const d = dayParts(row);
                d.toggle.classList.toggle('is-on', original[i].open);
                d.from.value = original[i].from;
                d.to.value = original[i].to;
            });
            panel.elements.note.value = '';
            panel.classList.remove('is-open');
            hours.classList.remove('is-active');
            kit.hideToast();
            kit.hideGlow();
            render(null);
            kit.park();
        }

        async function play(id) {
            const wait = (ms) => kit.wait(ms, id);
            reset();
            await wait(800);
            kit.moveTo(hours, 0.5, 0.4);
            await wait(900);
            kit.showGlow(hours, 'Öffnungszeiten ändern');
            await wait(800);
            kit.click();
            kit.hideGlow();
            hours.classList.add('is-active');
            panel.classList.add('is-open');
            await wait(800);
            const sunday = dayParts(days.find((row) => row.dataset.day === SAMPLE.day));
            kit.moveTo(sunday.toggle, 0.5, 0.6);
            await wait(900);
            kit.click(sunday.toggle);
            sunday.toggle.classList.add('is-on');
            await wait(500);
            kit.moveTo(sunday.from, 0.5, 0.6);
            await wait(600);
            kit.click();
            await kit.typeValue(sunday.from, SAMPLE.from, id, 90);
            kit.moveTo(sunday.to, 0.5, 0.6);
            await wait(600);
            kit.click();
            await kit.typeValue(sunday.to, SAMPLE.to, id, 90);
            await wait(300);
            kit.moveTo(panel.elements.note, 0.3, 0.6);
            await wait(700);
            kit.click();
            await kit.typeValue(panel.elements.note, SAMPLE.note, id, 40);
            await wait(400);
            kit.moveTo(submit, 0.5, 0.6);
            await wait(800);
            kit.click(submit);
            panel.classList.remove('is-open');
            hours.classList.remove('is-active');
            render(SAMPLE.day);
            kit.popToast();
            await wait(4200);
            root.dispatchEvent(new CustomEvent('demo:cycle', { bubbles: true }));
            if (id === kit.run) play(id).catch(() => {});
        }

        function start() {
            root.classList.remove('is-live');
            play(kit.next()).catch(() => {});
        }

        function goLive() {
            if (kit.isLive()) return;
            kit.stop();
            kit.hideGlow();
            panel.classList.remove('is-open');
            hours.classList.remove('is-active');
            root.classList.add('is-live');
            root.dispatchEvent(new CustomEvent('demo:live', { bubbles: true }));
        }

        root.addEventListener('pointerdown', goLive);
        hours.addEventListener('click', () => {
            if (!kit.isLive()) return;
            panel.classList.add('is-open');
        });
        panel.addEventListener('click', (e) => {
            const toggle = e.target.closest('.demo3__switch');
            if (toggle && kit.isLive()) toggle.classList.toggle('is-on');
        });
        panel.addEventListener('submit', (e) => {
            e.preventDefault();
            if (!kit.isLive()) return;
            panel.classList.remove('is-open');
            render(null);
            kit.popToast();
        });
        root.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') panel.classList.remove('is-open');
        });

        render(null);
        const still = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        return { start: still ? goLive : start, stop: kit.stop };
    }

    // Beispiele im Hero: eine Vorführung je Folie, Reiter darunter. Nach jedem Durchlauf schiebt
    // sich die nächste herein; wer in eine Vorführung klickt, bleibt dort.
    function initSlides(demos) {
        const root = document.querySelector('[data-slides]');
        if (!root) return;
        const slides = Array.from(root.querySelectorAll('[data-slide]'));
        const tabs = Array.from(root.querySelectorAll('[data-slide-tab]'));
        const hints = Array.from(document.querySelectorAll('[data-slide-hint]'));
        let current = 0;
        let auto = true;

        function show(n) {
            demos.forEach((demo) => demo && demo.stop());
            current = (n + slides.length) % slides.length;
            slides.forEach((slide, i) => slide.classList.toggle('is-active', i === current));
            tabs.forEach((tab, i) => {
                tab.classList.toggle('is-active', i === current);
                tab.setAttribute('aria-pressed', i === current ? 'true' : 'false');
            });
            hints.forEach((hint, i) => hint.classList.toggle('is-current', i === current));
            if (demos[current]) demos[current].start();
        }

        // Bühne samt Reitern und Satz soll auf den Bildschirm passen: sonst maßstabsgetreu verkleinern.
        const stage = root.querySelector('.slides__stage');
        const header = document.querySelector('[data-header]');
        // Mit zoom allein würde die Bühne innen breiter (weniger Umbruch); darum schrumpft die Breite
        // im selben Maß mit, innen bleibt alles wie in voller Größe.
        const fit = () => {
            stage.style.zoom = '';
            root.style.maxWidth = '';
            if (window.innerWidth < 760) return;
            const extra = root.offsetHeight - stage.offsetHeight + 110 + (header ? header.offsetHeight : 0);
            const scale = Math.max(0.6, Math.min(1, (window.innerHeight - extra) / stage.offsetHeight));
            if (scale === 1) return;
            root.style.maxWidth = Math.floor(root.offsetWidth * scale) + 'px';
            stage.style.zoom = String(scale);
        };
        fit();
        // Bilder ändern die Höhe noch, wenn sie geladen sind.
        window.addEventListener('load', fit);
        window.addEventListener('resize', fit);

        root.addEventListener('demo:cycle', () => { if (auto) show(current + 1); });
        root.addEventListener('demo:live', () => { auto = false; });
        tabs.forEach((tab, i) => tab.addEventListener('click', () => show(i)));
        show(0);
    }
})();
