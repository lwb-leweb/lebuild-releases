<?php
$page = [
    'title'       => 'Für Entwickler',
    'description' => 'Wie LeBuild technisch funktioniert: Import, Marker, JSON, Backups, jeder PHP-Hoster.',
    'slug'        => 'entwickler',
];
require __DIR__ . '/includes/header.php';
?>

<section class="section section--soft">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text_4">Für Entwickler</span>
            <h1 data-edit-id="section_header.title_3" data-edit-label="So funktioniert LeBuild unter der Haube. – Überschrift">So funktioniert LeBuild unter der Haube.</h1>
            <p class="section__lead" data-edit-id="section_header.text_5" data-edit-label="So funktioniert LeBuild unter der Haube. – Absatz">Statische Website rein, Marker drauf, Inhalte in JSON. Ohne Datenbank, auf jedem PHP-Hoster.</p>
        </header>
    </div>
</section>

<section class="section">
    <div class="container about">
        <div class="prose">
        <h2 data-edit-id="container.title" data-edit-label="Was ist LeBuild? – Überschrift">Was ist LeBuild?</h2>
        <p data-edit-id="container.text" data-edit-label="Was ist LeBuild? – Absatz 1">Ein schlankes PHP-Tool, das bestehende statische Websites in editierbare Websites
            verwandelt – ohne sie zu zerstören. Ein einmaliger Import ergänzt die HTML-Elemente
            um data-edit-id-Marker und lagert die Inhalte in JSON aus.</p>
        <p data-edit-id="container.text_2" data-edit-label="Was ist LeBuild? – Absatz 2">Ab da pflegst du Inhalte über einen passwortgeschützten Editor: Texte, Links, Bilder
            ändern sich live, Backups werden automatisch angelegt, das Original bleibt vorhanden.</p>
        <blockquote data-edit-id="container.text_3" data-edit-label="Was ist LeBuild? – Text">
            Gedacht für Agenturen, Freelancer und Hobbyisten, die schnelle, individuelle Websites
            für Kunden bauen und dann eine einfache Pflegelösung übergeben möchten.
        </blockquote>
        </div>
        <figure class="about__media">
            <img src="assets/img/editor.svg" alt="Website im Browser, deren Überschrift gerade bearbeitet wird" width="640" height="520" loading="lazy" data-edit-id="about_media.image" data-edit-alt-id="about_media.image_alt">
        </figure>
    </div>
</section>

<section id="how" class="section section--soft">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text">In drei Schritten</span>
            <h2 data-edit-id="section_header.title" data-edit-label="So funktioniert&apos;s – Überschrift">So funktioniert&apos;s</h2>
            <p class="section__lead" data-edit-id="section_header.text_2" data-edit-label="So funktioniert&apos;s – Absatz">Von der statischen Datei zur pflegbaren Website – ohne deinen Code zu zerstören.</p>
        </header>

        <div class="card-grid card-grid--3">
            <article class="step">
                <span class="step__number" data-edit-id="step.text">1</span>
                <span class="step__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="step_icon.icon" data-edit-label="HTML oder PHP ablegen – Icon"><path d="M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z"/><path d="M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12"/><path d="M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17"/></svg></span>
                <h3 data-edit-id="step.title" data-edit-label="HTML oder PHP ablegen – Überschrift">HTML oder PHP ablegen</h3>
                <p data-edit-id="step.text_2" data-edit-label="HTML oder PHP ablegen – Absatz">Lege deine statischen Dateien in public/site/ ab – so wie sie sind, mit deinem CSS, JS und Assets.</p>
            </article>

            <article class="step">
                <span class="step__number" data-edit-id="step.text_3">2</span>
                <span class="step__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="step_icon.icon_2" data-edit-label="Einmaliger Import – Icon"><path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/></svg></span>
                <h3 data-edit-id="step.title_2" data-edit-label="Einmaliger Import – Überschrift">Einmaliger Import</h3>
                <p data-edit-id="step.text_4" data-edit-label="Einmaliger Import – Absatz">Beim ersten Login erkennt das System die Seiten, ergänzt data-edit-id-Marker und legt Inhalte in JSON ab.</p>
            </article>

            <article class="step">
                <span class="step__number" data-edit-id="step.text_5">3</span>
                <span class="step__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="step_icon.icon_3" data-edit-label="Inhalte pflegen – Icon"><path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/></svg></span>
                <h3 data-edit-id="step.title_3" data-edit-label="Inhalte pflegen – Überschrift">Inhalte pflegen</h3>
                <p data-edit-id="step.text_6" data-edit-label="Inhalte pflegen – Absatz">Im Admin Texte, Links und Bilder ändern. Save schreibt JSON, erstellt ein Backup und ist sofort live.</p>
            </article>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text_3">Eigenschaften</span>
            <h2 data-edit-id="section_header.title_2" data-edit-label="Was LeBuild besonders macht – Überschrift">Was LeBuild besonders macht</h2>
        </header>

        <div class="card-grid card-grid--2">
            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon" data-edit-label="Keine Datenbank – Icon"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5V19A9 3 0 0 0 21 19V5"/><path d="M3 12A9 3 0 0 0 21 12"/></svg></span>
                <h3 data-edit-id="feature_card.title" data-edit-label="Keine Datenbank – Überschrift">Keine Datenbank</h3>
                <p data-edit-id="feature_card.text" data-edit-label="Keine Datenbank – Absatz">Inhalte liegen als JSON-Dateien im Repository. Versionierbar mit Git, portabel zwischen Hostern, sicher gegen SQL-Probleme.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_2" data-edit-label="Läuft auf jedem PHP-Hoster – Icon"><rect width="20" height="8" x="2" y="2" rx="2" ry="2"/><rect width="20" height="8" x="2" y="14" rx="2" ry="2"/><line x1="6" x2="6.01" y1="6" y2="6"/><line x1="6" x2="6.01" y1="18" y2="18"/></svg></span>
                <h3 data-edit-id="feature_card.title_2" data-edit-label="Läuft auf jedem PHP-Hoster – Überschrift">Läuft auf jedem PHP-Hoster</h3>
                <p data-edit-id="feature_card.text_2" data-edit-label="Läuft auf jedem PHP-Hoster – Absatz">PHP ≥ 8.0 genügt. Kein Composer-Zwang, kein Node, keine Build-Pipeline. Hochladen, Login, fertig.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_3" data-edit-label="Automatische Backups – Icon"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/></svg></span>
                <h3 data-edit-id="feature_card.title_3" data-edit-label="Automatische Backups – Überschrift">Automatische Backups</h3>
                <p data-edit-id="feature_card.text_3" data-edit-label="Automatische Backups – Absatz">Vor jedem Speichern wird die alte JSON-Version weggesichert. Restore per Klick aus dem Admin.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_4" data-edit-label="HTML bleibt HTML – Icon"><rect width="18" height="7" x="3" y="3" rx="1"/><rect width="9" height="7" x="3" y="14" rx="1"/><rect width="5" height="7" x="16" y="14" rx="1"/></svg></span>
                <h3 data-edit-id="feature_card.title_4" data-edit-label="HTML bleibt HTML – Überschrift">HTML bleibt HTML</h3>
                <p data-edit-id="feature_card.text_4" data-edit-label="HTML bleibt HTML – Absatz">Dein Code wird einmalig um data-edit-id ergänzt – keine Templates, keine Shortcodes, kein Lock-in.</p>
            </article>
        </div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
