<div class="demo2" data-demo2>
    <template data-demo2-template>
        <div class="demo__window demo2__window">
            <div class="demo__chrome">
                <span class="demo__dots"><i></i><i></i><i></i></span>
                <span class="demo__url">www.baeckerei-huber.at/team</span>
            </div>
            <div class="demo__page demo2__page">
                <div class="demo__nav">
                    <span class="demo__logo">huber<b>.</b></span>
                    <span class="demo__links"><i>Sortiment</i><i>Café</i><i class="is-current">Über uns</i></span>
                    <span class="demo__order">Bestellen</span>
                </div>
                <div class="demo2__intro">
                    <div>
                        <small class="demo2__eyebrow">Über uns</small>
                        <span class="demo2__headline">Seit 1962 backen wir mit Liebe.</span>
                        <span class="demo2__text">Drei Generationen, ein Rezept: Zeit, gutes Mehl und frühes Aufstehen.</span>
                    </div>
                    <img class="demo2__img" src="assets/img/demo/brote.jpg" alt="" width="480" height="320">
                </div>
                <span class="demo2__title">Unser Team</span>
                <div class="demo2__grid" data-demo2-grid>
                    <div class="demo2__card"><img class="demo2__photo" src="assets/img/demo/team-martin.jpg" alt="" width="320" height="320"><b>Martin Huber</b><small>Bäckermeister</small><span class="demo2__since">Im Team seit 1998</span><span class="demo2__about">„Mein Sauerteig ist älter als unser Lehrling.“</span></div>
                    <div class="demo2__card"><img class="demo2__photo" src="assets/img/demo/team-anna.jpg" alt="" width="320" height="320"><b>Anna Huber</b><small>Chefin im Café</small><span class="demo2__since">Im Team seit 2005</span><span class="demo2__about">„Kennt jeden Stammgast beim Namen.“</span></div>
                    <div class="demo2__card"><img class="demo2__photo" src="assets/img/demo/team-tobias.jpg" alt="" width="320" height="320"><b>Tobias Leitner</b><small>Lehrling</small><span class="demo2__since">Im Team seit 2024</span><span class="demo2__about">„Steht als Erster in der Backstube.“</span></div>
                </div>
                <div class="demo2__listbar">
                    <span><b>Team</b> · <span data-demo2-count>3 Einträge</span></span>
                    <button class="demo2__add" type="button" data-demo2-add>+ Neuer Eintrag</button>
                </div>
            </div>
            <?php require __DIR__ . '/leiste.php'; ?>
            <form class="demo2__panel" data-demo2-panel>
                <b class="demo2__panel-title">Neues Teammitglied</b>
                <div class="demo2__fields">
                    <label class="demo2__drop" data-demo2-drop>
                        <input type="file" name="photo" accept="image/*" hidden>
                        <img alt="" hidden data-demo2-preview>
                        <span>Foto hineinziehen oder auswählen</span>
                    </label>
                    <div class="demo2__inputs">
                        <label>Name <input name="name" autocomplete="off" maxlength="40" placeholder="z. B. Lisa Berger"></label>
                        <label>Aufgabe <input name="role" autocomplete="off" maxlength="40" placeholder="z. B. Konditorin"></label>
                        <label>Im Team seit <input name="since" autocomplete="off" maxlength="4" inputmode="numeric" placeholder="z. B. 2025"></label>
                    </div>
                </div>
                <label>Über mich <input name="about" autocomplete="off" maxlength="60" placeholder="Ein Satz über dich"></label>
                <button class="demo2__submit" type="submit">Hinzufügen</button>
            </form>
            <div class="demo2__confirm" role="alertdialog" data-demo2-confirm>
                <b data-demo2-confirm-title></b>
                <span>Das lässt sich nicht rückgängig machen.</span>
                <span class="demo__popover-actions">
                    <button class="demo__btn demo__btn--secondary" type="button" data-demo2-confirm-no>Abbrechen</button>
                    <button class="demo__btn demo__btn--danger" type="button" data-demo2-confirm-yes>Löschen</button>
                </span>
            </div>
            <div class="demo__glow" data-demo-glow><span class="demo__tag" data-demo-tag></span></div>
            <div class="demo__toast" data-demo-toast>Gespeichert – Lisa ist jetzt im Team.</div>
            <div class="demo__pointer" data-demo-cursor>
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 2l16 11-7 1.5L9.5 21z" fill="#0c1b4d" stroke="#fff" stroke-width="1.6" stroke-linejoin="round"/></svg>
                <span class="demo__file demo2__file" data-demo2-file>lisa.jpg</span>
            </div>
        </div>
    </template>
</div>
