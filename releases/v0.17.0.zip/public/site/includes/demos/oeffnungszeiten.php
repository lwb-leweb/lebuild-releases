<div class="demo3" data-demo3>
    <template data-demo3-template>
        <div class="demo__window">
            <div class="demo__chrome">
                <span class="demo__dots"><i></i><i></i><i></i></span>
                <span class="demo__url">www.baeckerei-huber.at/kontakt</span>
            </div>
            <div class="demo__page demo3__page">
                <div class="demo__nav">
                    <span class="demo__logo">huber<b>.</b></span>
                    <span class="demo__links"><i>Sortiment</i><i>Café</i><i class="is-current">Kontakt</i></span>
                    <span class="demo__order">Bestellen</span>
                </div>
                <div class="demo3__notice" data-demo3-notice></div>
                <div class="demo3__grid">
                    <div class="demo3__visit">
                        <small class="demo2__eyebrow">Kontakt</small>
                        <span class="demo2__headline">Komm vorbei, wir freuen uns.</span>
                        <span class="demo3__line"><b>Bäckerei Huber</b>Hauptplatz 12, 2020 Hollabrunn</span>
                        <span class="demo3__line"><b>Telefon</b>02952 123 45</span>
                        <img class="demo3__img" src="assets/img/demo/croissants.jpg" alt="" width="480" height="320">
                    </div>
                    <div class="demo3__hours" data-demo3-hours>
                        <span class="demo3__hours-title">Öffnungszeiten</span>
                        <div class="demo3__rows" data-demo3-rows></div>
                    </div>
                </div>
            </div>
            <?php require __DIR__ . '/leiste.php'; ?>
            <form class="demo2__panel demo3__panel" data-demo3-panel>
                <b class="demo2__panel-title">Öffnungszeiten</b>
                <div class="demo3__days">
                    <div class="demo3__day" data-day="Mo"><span class="demo3__name">Mo</span><button class="demo3__switch is-on" type="button" aria-label="Mo geöffnet"></button><input name="Mo-from" value="06:00" placeholder="–" inputmode="numeric" maxlength="5"><span>bis</span><input name="Mo-to" value="18:00" placeholder="–" inputmode="numeric" maxlength="5"></div>
                    <div class="demo3__day" data-day="Di"><span class="demo3__name">Di</span><button class="demo3__switch is-on" type="button" aria-label="Di geöffnet"></button><input name="Di-from" value="06:00" placeholder="–" inputmode="numeric" maxlength="5"><span>bis</span><input name="Di-to" value="18:00" placeholder="–" inputmode="numeric" maxlength="5"></div>
                    <div class="demo3__day" data-day="Mi"><span class="demo3__name">Mi</span><button class="demo3__switch is-on" type="button" aria-label="Mi geöffnet"></button><input name="Mi-from" value="06:00" placeholder="–" inputmode="numeric" maxlength="5"><span>bis</span><input name="Mi-to" value="18:00" placeholder="–" inputmode="numeric" maxlength="5"></div>
                    <div class="demo3__day" data-day="Do"><span class="demo3__name">Do</span><button class="demo3__switch is-on" type="button" aria-label="Do geöffnet"></button><input name="Do-from" value="06:00" placeholder="–" inputmode="numeric" maxlength="5"><span>bis</span><input name="Do-to" value="18:00" placeholder="–" inputmode="numeric" maxlength="5"></div>
                    <div class="demo3__day" data-day="Fr"><span class="demo3__name">Fr</span><button class="demo3__switch is-on" type="button" aria-label="Fr geöffnet"></button><input name="Fr-from" value="06:00" placeholder="–" inputmode="numeric" maxlength="5"><span>bis</span><input name="Fr-to" value="18:00" placeholder="–" inputmode="numeric" maxlength="5"></div>
                    <div class="demo3__day" data-day="Sa"><span class="demo3__name">Sa</span><button class="demo3__switch is-on" type="button" aria-label="Sa geöffnet"></button><input name="Sa-from" value="06:00" placeholder="–" inputmode="numeric" maxlength="5"><span>bis</span><input name="Sa-to" value="12:00" placeholder="–" inputmode="numeric" maxlength="5"></div>
                    <div class="demo3__day" data-day="So"><span class="demo3__name">So</span><button class="demo3__switch" type="button" aria-label="So geöffnet"></button><input name="So-from" value="" placeholder="–" inputmode="numeric" maxlength="5"><span>bis</span><input name="So-to" value="" placeholder="–" inputmode="numeric" maxlength="5"></div>
                </div>
                <label>Hinweis über den Zeiten <input name="note" autocomplete="off" maxlength="60" placeholder="z. B. Betriebsurlaub oder Feiertag"></label>
                <button class="demo2__submit" type="submit">Speichern</button>
            </form>
            <div class="demo__glow" data-demo-glow><span class="demo__tag" data-demo-tag></span></div>
            <div class="demo__toast" data-demo-toast>Gespeichert – die Öffnungszeiten sind online.</div>
            <div class="demo__pointer" data-demo-cursor>
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 2l16 11-7 1.5L9.5 21z" fill="#0c1b4d" stroke="#fff" stroke-width="1.6" stroke-linejoin="round"/></svg>
            </div>
        </div>
    </template>
</div>
