            <?php /* Leiste des Editors wie auf der echten Seite: Logo, Schalter Bearbeiten, Rückgängig, Speichern,
                     Hilfe, Mehr; der Stand hängt als Lasche daran, solange etwas ungespeichert ist (demos.js). */ ?>
            <div class="demo__bar">
                <span class="demo__status" data-demo-status hidden><i></i><span data-demo-count>1</span><span class="demo__status-word"> ungespeichert</span></span>
                <span class="demo__bar-logo" title="LeBuild">LE</span>
                <span class="demo__bar-divider"></span>
                <span class="demo__tool demo__tool--on" title="Bearbeiten ist an"><svg viewBox="0 0 24 24"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg></span>
                <span class="demo__bar-actions">
                    <span class="demo__tool demo__undo" title="Rückgängig" data-demo-undo><svg viewBox="0 0 24 24"><path d="M9 14 4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/></svg></span>
                    <span class="demo__tool demo__save" title="Speichern" data-demo-target="save"><svg viewBox="0 0 24 24"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2Z"/><path d="M17 21v-8H7v8"/><path d="M7 3v5h8"/></svg></span>
                </span>
                <span class="demo__tool" title="Hilfe"><svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 1 0 0-20"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3"/><path d="M12 17h.01"/></svg></span>
                <span class="demo__tool demo__tool--more" title="Mehr"><svg viewBox="0 0 24 24"><path d="M5 12h.01"/><path d="M12 12h.01"/><path d="M19 12h.01"/></svg></span>
            </div>
