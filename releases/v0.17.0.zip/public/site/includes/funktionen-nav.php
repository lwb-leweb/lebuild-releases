<?php
// Unternavigation der Funktionen-Seiten (Einträge: $FUNCTION_ITEMS in config.php). Nach header.php einbinden.
$functionCurrent = current_page($pageSlug ?? '');
?>
<nav class="subnav" aria-label="Funktionen">
    <div class="container">
        <ul class="subnav__list">
            <li><a class="subnav__link subnav__link--back" href="/funktionen">Alle Funktionen</a></li>
            <?php foreach ($FUNCTION_ITEMS as $item): ?>
                <?php $isActive = $functionCurrent === $item['href']; ?>
                <li>
                    <a
                        href="<?= e($item['href']) ?>"
                        class="subnav__link<?= $isActive ? ' is-active' : '' ?>"
                        <?= $isActive ? 'aria-current="page"' : '' ?>>
                        <?= e($item['label']) ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</nav>
