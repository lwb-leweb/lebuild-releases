<?php
require_once __DIR__ . '/config.php';
$current = current_page($pageSlug ?? '');
?>
<header class="site-header" data-header>
    <div class="container site-header__inner">
        <a class="brand" href="/" aria-label="<?= e(SITE_NAME) ?> Startseite" data-edit-id="header.link_1.url">
            <span class="brand__mark" aria-hidden="true" data-edit-id="header.container.text">LE</span>
            <span class="brand__name"><?= e(SITE_NAME) ?></span>
        </a>

        <button
            class="nav-toggle"
            type="button"
            aria-controls="primary-nav"
            aria-expanded="false"
            data-nav-toggle>
            <span class="nav-toggle__bars" aria-hidden="true"></span>
            <span class="visually-hidden" data-edit-id="header.container.text_2">Menü öffnen</span>
        </button>

        <nav id="primary-nav" class="primary-nav" aria-label="Hauptnavigation" data-nav>
            <ul class="primary-nav__list">
                <?php foreach ($NAV_ITEMS as $item): ?>
                    <?php $isActive = $current === $item['href'] || in_array($current, $item['children'] ?? [], true); ?>
                    <li class="primary-nav__item">
                        <a
                            href="<?= e($item['href']) ?>"
                            class="primary-nav__link<?= $isActive ? ' is-active' : '' ?>"
                            <?= $isActive ? 'aria-current="page"' : '' ?>>
                            <?= e($item['label']) ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>

        <div class="site-header__actions">
            <button class="theme-toggle" type="button" aria-label="Helles oder dunkles Design" data-theme-toggle>
                <svg class="theme-toggle__moon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg>
                <svg class="theme-toggle__sun" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/></svg>
            </button>
            <a class="site-header__login" href="../admin/" data-edit-id="header.link_3.url" data-edit-text-id="header.link_3.text">Anmelden</a>
            <a class="button button--accent button--small" href="#kontakt" data-edit-id="header.link_4.url" data-edit-text-id="header.link_4.text">Loslegen</a>
        </div>
    </div>
</header>
