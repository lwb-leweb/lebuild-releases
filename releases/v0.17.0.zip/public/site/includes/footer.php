    </main>

    <section id="kontakt" class="cta-band" aria-labelledby="cta-heading">
        <div class="container cta-band__inner">
            <div>
                <h2 id="cta-heading" class="cta-band__title" data-edit-id="footer.container.title" data-edit-label="Das will ich für meine Website. – Überschrift">Das will ich für meine Website.</h2>
                <p class="cta-band__lead" data-edit-id="footer.container.text" data-edit-label="Das will ich für meine Website. – Absatz">Schreib uns. Wir zeigen dir, wie das bei dir aussieht.</p>
            </div>
            <div class="cta-band__actions">
<?php if (SITE_EMAIL !== ''): ?>
                <a class="button button--accent" href="mailto:<?= e(SITE_EMAIL) ?>" data-edit-text-id="footer.cta_band_actions.text">Kontakt aufnehmen</a>
<?php endif; ?>
                <a class="button button--ghost" href="../admin/" data-edit-id="footer.link_1.url" data-edit-text-id="footer.link_1.text">Anmelden</a>
            </div>
        </div>
    </section>

    <footer class="site-footer">
        <div class="container site-footer__grid">
            <div class="site-footer__brand">
                <span class="brand">
                    <span class="brand__mark" data-edit-id="footer.site_footer_brand.text">LE</span>
                    <span class="brand__name"><?= e(SITE_NAME) ?></span>
                </span>
                <p class="site-footer__tagline" data-edit-id="footer.site_footer_brand.text_3">Websites, die du selbst aktuell hältst. Ein Produkt von LEWEB.</p>
            </div>

            <nav class="site-footer__legal" aria-label="Rechtliches">
                <h2 class="site-footer__heading" data-edit-id="footer.site_footer_legal.title" data-edit-label="Mehr – Überschrift">Mehr</h2>
                <ul>
                    <li><a href="/impressum" data-edit-id="footer.link_2.url" data-edit-text-id="footer.link_2.text" data-edit-label="Mehr – Link 1">Impressum</a></li>
                    <li><a href="../admin/" data-edit-id="footer.link_3.url" data-edit-text-id="footer.link_3.text" data-edit-label="Mehr – Link 2">Admin-Editor</a></li>
<?php if (SITE_EMAIL !== ''): ?>
                    <li><a href="mailto:<?= e(SITE_EMAIL) ?>"><?= e(SITE_EMAIL) ?></a></li>
<?php endif; ?>
                </ul>
            </nav>
        </div>

        <div class="container site-footer__bottom">
            <p>&copy; <?= e((string)date('Y')) ?> <?= e(SITE_NAME) ?><?= SITE_OWNER !== '' ? ' · ' . e(SITE_OWNER) : '' ?>. Alle Rechte vorbehalten.</p>
        </div>
    </footer>

    <script src="assets/js/main.js" defer></script>
<?php if (!empty($page['demos'])): ?>
    <script src="assets/js/demos.js" defer></script>
<?php endif; ?>
</body>
</html>
