<?php
// Karte eines Beitrags: Datum (ohne: angelegt am), Bild, Titel, Kurzfassung; Klick öffnet die eigene Seite.
$datum = (string) ($item['datum'] ?? '') ?: (string) ($item['created_at'] ?? '');
?>
<<?= ct_tag($item) ?> class="beispiel" <?= ct_action_attrs($item) ?>>
    <span class="beispiel__media"><?= ct_image($item, 'bild', 'titel') ?></span>
    <span class="beispiel__body">
        <small class="beispiel__branche"><?= $datum !== '' ? date('d.m.Y', strtotime($datum)) : '' ?></small>
        <h3><?= ct_text($item, 'titel') ?></h3>
        <p><?= ct_lines($item, 'kurz') ?></p>
        <span class="beispiel__go">Weiterlesen</span>
    </span>
</<?= ct_tag($item) ?>>
