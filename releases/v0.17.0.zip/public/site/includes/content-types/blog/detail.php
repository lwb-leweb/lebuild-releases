<?php $datum = (string) ($item['datum'] ?? '') ?: (string) ($item['created_at'] ?? ''); ?>
<article class="beispiel-page">
    <section class="section section--soft">
        <div class="container beispiel-page__intro">
            <div>
                <a class="beispiel-page__back" href="/blog#beitraege">← Alle Beiträge</a>
                <span class="section__eyebrow"><?= $datum !== '' ? date('d.m.Y', strtotime($datum)) : '' ?></span>
                <h1><?= ct_text($item, 'titel') ?></h1>
                <p class="section__lead"><?= ct_lines($item, 'kurz') ?></p>
            </div>
            <figure class="beispiel-page__media"><?= ct_image($item, 'bild', 'titel') ?></figure>
        </div>
    </section>

    <section class="section">
        <div class="container beispiel-page__content">
            <div class="prose"><?= ct_rich($item, 'text') ?></div>
        </div>
    </section>
</article>
