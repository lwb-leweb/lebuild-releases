<<?= ct_tag($item) ?> class="feature-card baustein" <?= ct_action_attrs($item) ?>>
    <span class="feature-card__icon"><?= icon((string) ($item['icon'] ?? '')) ?></span>
    <h3><?= ct_text($item, 'titel') ?></h3>
    <p><?= ct_text($item, 'kurz') ?></p>
    <span class="baustein__more">Mehr dazu</span>
</<?= ct_tag($item) ?>>
