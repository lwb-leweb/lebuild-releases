<div class="baustein-detail">
    <span class="feature-card__icon"><?= icon((string) ($item['icon'] ?? '')) ?></span>
    <h2><?= ct_text($item, 'titel') ?></h2>
    <div class="baustein-detail__text"><?= ct_rich($item, 'text') ?></div>
    <?php if (ct_rows($item, 'beispiele')): ?>
        <h3>Zum Beispiel</h3>
        <ul class="baustein-detail__list">
            <?php foreach (ct_rows($item, 'beispiele') as $row): ?>
                <li><?= ct_text($row, 'text') ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</div>
