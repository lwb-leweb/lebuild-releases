<details class="faq__item">
    <summary class="faq__question"><?= ct_text($item, 'frage') ?></summary>
    <p class="faq__answer"><?= ct_lines($item, 'antwort') ?></p>
</details>
