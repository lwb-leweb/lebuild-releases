<article class="beispiel-page">
    <section class="section section--soft">
        <div class="container beispiel-page__intro">
            <div>
                <a class="beispiel-page__back" href="/listen#beispiele">← Alle Beispiele</a>
                <span class="section__eyebrow"><?= ct_text($item, 'branche') ?></span>
                <h1><?= ct_text($item, 'titel') ?></h1>
                <p class="section__lead"><?= ct_lines($item, 'kurz') ?></p>
            </div>
            <figure class="beispiel-page__media"><?= ct_image($item, 'bild', 'titel') ?></figure>
        </div>
    </section>

    <section class="section">
        <div class="container beispiel-page__content">
            <div class="prose"><?= ct_rich($item, 'text') ?></div>
            <?php if (ct_rows($item, 'punkte')): ?>
                <div class="card-grid card-grid--2">
                    <?php foreach (ct_rows($item, 'punkte') as $row): ?>
                        <div class="feature-card">
                            <h3><?= ct_text($row, 'titel') ?></h3>
                            <p><?= ct_text($row, 'text') ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
</article>
