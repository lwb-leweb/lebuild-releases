<?php $isLink = content_types_item_target($item)['action'] === 'link'; ?>
<<?= ct_tag($item) ?> class="beispiel<?= $isLink ? ' beispiel--link' : '' ?>" <?= ct_action_attrs($item) ?>>
    <span class="beispiel__media"><?= ct_image($item, 'bild', 'titel') ?></span>
    <span class="beispiel__body">
        <small class="beispiel__branche"><?= ct_text($item, 'branche') ?></small>
        <h3><?= ct_text($item, 'titel') ?></h3>
        <p><?= ct_lines($item, 'kurz') ?></p>
        <span class="beispiel__go"><?= $isLink ? 'Zur Website ↗' : 'Eigene Seite ansehen' ?></span>
    </span>
</<?= ct_tag($item) ?>>
