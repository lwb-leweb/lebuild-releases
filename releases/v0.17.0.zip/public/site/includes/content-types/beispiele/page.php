<?php
// Eigene Seite eines Beispiels: Kopf und Fuß der Website um detail.php. Titel, Beschreibung und canonical
// setzt das Plugin; nach den Includes nur noch ct_item() und ct_detail() (die Navigation setzt $item).
$page = [
    'title'       => (string) ($item['titel'] ?? ''),
    'description' => (string) ($item['kurz'] ?? ''),
    'slug'        => 'beispiele/' . (string) ($item['slug'] ?? ''),
];
require __DIR__ . '/../../header.php';
?>

<?= ct_detail() ?>

<?php require __DIR__ . '/../../footer.php'; ?>
