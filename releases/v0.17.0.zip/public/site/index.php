<?php
$page = [
    'title'       => 'LeBuild – Die Website-Revolution',
    'description' => 'Mit LeBuild änderst du deine Website selbst, direkt auf der Seite. Und jede Anpassung oder Automatisierung setzt LEWEB schneller und günstiger um als in WordPress, TYPO3 und Co.',
    'slug'        => '',
    'demos'       => true,
];
require __DIR__ . '/includes/header.php';
?>

<section id="hero" class="hero">
    <div class="container">
        <div class="hero__grid">
            <div class="hero__content">
                <span class="hero__eyebrow" data-edit-id="hero_grid.text">Ohne Vorkenntnisse</span>
                <h1 data-edit-id="hero_grid.title" data-edit-label="Die Website-Revolution. – Überschrift">Die Website-Revolution.</h1>
                <p class="hero__lead" data-edit-id="hero_grid.text_2" data-edit-label="Die Website-Revolution. – Absatz">Inhalte änderst du selbst, direkt auf der Seite. Und was neu dazukommen soll, steht schneller und günstiger als je zuvor.</p>
                <div class="hero__actions">
                    <a class="button button--accent button--arrow" href="#kontakt" data-edit-id="link_1.url" data-edit-text-id="link_1.text">Jetzt loslegen</a>
                    <a class="button button--ghost" href="#mehr" data-edit-id="link_2.url" data-edit-text-id="link_2.text">Was noch alles geht</a>
                </div>
            </div>

            <div class="hero__visual">
                <div class="slides" data-slides>
                    <div class="slides__stage">
                        <div class="slide is-active" data-slide>
                            <?php require __DIR__ . '/includes/demos/texte.php'; ?>
                        </div>
                        <div class="slide" data-slide>
                            <?php require __DIR__ . '/includes/demos/eintraege.php'; ?>
                        </div>
                        <div class="slide" data-slide>
                            <?php require __DIR__ . '/includes/demos/oeffnungszeiten.php'; ?>
                        </div>
                    </div>
                    <div class="slides__tabs">
                        <button class="slides__tab is-active" type="button" data-slide-tab data-edit-id="slides_tabs.text">Texte, Bilder, Buttons</button>
                        <button class="slides__tab" type="button" data-slide-tab data-edit-id="slides_tabs.text_2">Einträge verwalten</button>
                        <button class="slides__tab" type="button" data-slide-tab data-edit-id="slides_tabs.text_3">Öffnungszeiten ändern</button>
                    </div>
                </div>
                <p class="demo-hint"><span class="is-current" data-edit-id="demo_hint.text" data-slide-hint>Probier es selbst: Klick in die Vorschau.</span><span data-edit-id="demo_hint.text_3" data-slide-hint>Ob Team, Speisekarte oder etwas ganz Eigenes: Jede Liste deiner Website pflegst du genauso.</span><span data-edit-id="demo_hint.text_4" data-slide-hint>Feiertag, Urlaub, Sonntagsdienst: in Sekunden aktuell.</span></p>
            </div>
        </div>
    </div>
</section>

<section id="vorteile" class="section">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text_10">Deine Vorteile</span>
            <h2 data-edit-id="section_header.title_9" data-edit-label="Schneller. Einfacher. Besser gefunden. – Überschrift">Schneller. Einfacher. Besser gefunden.</h2>
            <p class="section__lead" data-edit-id="section_header.text_11" data-edit-label="Schneller. Einfacher. Besser gefunden. – Absatz">Eine Website, die nicht nur gut aussieht, sondern auch gefunden wird, bei Google und in KI-Chats.</p>
        </header>

        <div class="card-grid card-grid--3">
            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon" data-edit-label="Superschnell – Icon"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/></svg></span>
                <h3 data-edit-id="feature_card.title" data-edit-label="Superschnell – Überschrift">Superschnell</h3>
                <p data-edit-id="feature_card.text" data-edit-label="Superschnell – Absatz">Deine Seiten liegen fertig bereit und laden sofort. Nichts wird bei jedem Aufruf erst aus einer Datenbank zusammengebaut.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_2" data-edit-label="Supereinfach – Icon"><path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/></svg></span>
                <h3 data-edit-id="feature_card.title_2" data-edit-label="Supereinfach – Überschrift">Supereinfach</h3>
                <p data-edit-id="feature_card.text_2" data-edit-label="Supereinfach – Absatz">Draufklicken, ändern, speichern. Ohne Schulung und ohne Backend mit hunderten Menüs.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_3" data-edit-label="Besser bei Google – Icon"><path d="M16 7h6v6"/><path d="m22 7-8.5 8.5-5-5L2 17"/></svg></span>
                <h3 data-edit-id="feature_card.title_3" data-edit-label="Besser bei Google – Überschrift">Besser bei Google</h3>
                <p data-edit-id="feature_card.text_3" data-edit-label="Besser bei Google – Absatz">Kurze Ladezeiten und sauberer Code sind genau das, was Suchmaschinen belohnen.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_4" data-edit-label="Gefunden in KI-Chats – Icon"><path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/></svg></span>
                <h3 data-edit-id="feature_card.title_4" data-edit-label="Gefunden in KI-Chats – Überschrift">Gefunden in KI-Chats</h3>
                <p data-edit-id="feature_card.text_4" data-edit-label="Gefunden in KI-Chats – Absatz">ChatGPT, Gemini und Co. lesen deine Inhalte direkt und ohne Umwege. So findet man dich auch dort.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_5" data-edit-label="Sicher und gesichert – Icon"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/></svg></span>
                <h3 data-edit-id="feature_card.title_5" data-edit-label="Sicher und gesichert – Überschrift">Sicher und gesichert</h3>
                <p data-edit-id="feature_card.text_5" data-edit-label="Sicher und gesichert – Absatz">Keine Erweiterungen von Dritten als Einfallstor, und vor jedem Speichern legt das System ein Backup an.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_6" data-edit-label="Pflege: du oder wir – Icon"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.106-3.105c.32-.322.863-.22.983.218a6 6 0 0 1-8.259 7.057l-7.91 7.91a1 1 0 0 1-2.999-3l7.91-7.91a6 6 0 0 1 7.057-8.259c.438.12.54.662.219.984z"/></svg></span>
                <h3 data-edit-id="feature_card.title_6" data-edit-label="Pflege: du oder wir – Überschrift">Pflege: du oder wir</h3>
                <p data-edit-id="feature_card.text_6" data-edit-label="Pflege: du oder wir – Absatz">Inhalte hältst du selbst aktuell. Hast du dafür keine Zeit, übernehmen wir das für dich.</p>
            </article>
        </div>
    </div>
</section>

<section id="stimmen" class="section quotes">
    <div class="container">
        <header class="section__header">
            <h2 data-edit-id="section_header.title_8" data-edit-label="Das sagen die ersten Kunden – Überschrift">Das sagen die ersten Kunden</h2>
        </header>
        <div class="quotes__grid">
            <figure class="quote">
                <blockquote data-edit-id="quote.text_10">Die Öffnungszeiten hab ich selbst geändert, in zwei Minuten. Früher hätte ich dafür eine E-Mail geschrieben und eine Woche gewartet.</blockquote>
                <figcaption><span class="quote__avatar" aria-hidden="true" data-edit-id="quote.text_11">?</span><span data-edit-id="quote.text_12"><b>Vorname Nachname</b><small>Firma, Ort</small></span></figcaption>
            </figure>
            <figure class="quote">
                <blockquote data-edit-id="quote.text_13">Endlich trau ich mich, auf meiner Website etwas zu ändern. Es ist wirklich nur draufklicken.</blockquote>
                <figcaption><span class="quote__avatar" aria-hidden="true" data-edit-id="quote.text_14">?</span><span data-edit-id="quote.text_15"><b>Vorname Nachname</b><small>Firma, Ort</small></span></figcaption>
            </figure>
            <figure class="quote">
                <blockquote data-edit-id="quote.text_16">Neue Mitarbeiterin? Hab ich selbst eingetragen. Und die Seite ist schneller als vorher.</blockquote>
                <figcaption><span class="quote__avatar" aria-hidden="true" data-edit-id="quote.text_17">?</span><span data-edit-id="quote.text_18"><b>Vorname Nachname</b><small>Firma, Ort</small></span></figcaption>
            </figure>
        </div>
    </div>
</section>

<section id="mehr" class="section section--soft">
    <div class="container">
        <header class="section__header">
            <h2 data-edit-id="section_header.title_5" data-edit-label="Nicht nur Text. So ziemlich alles. – Überschrift">Nicht nur Text. So ziemlich alles.</h2>
            <p class="section__lead" data-edit-id="section_header.text_8" data-edit-label="Nicht nur Text. So ziemlich alles. – Absatz">Alles, was deine Website braucht. Pflegen tust du es selbst.</p>
        </header>

        <div class="anything">
            <p class="anything__text" data-edit-id="anything.text_2">Genauso einfach:</p>
            <ul class="anything__list">
            <li data-edit-id="anything_list.text_9">Speisekarte</li>
            <li data-edit-id="anything_list.text_10">Angebote</li>
            <li data-edit-id="anything_list.text_11">Jobs</li>
            <li data-edit-id="anything_list.text_12">Termine</li>
            <li data-edit-id="anything_list.text_13">Referenzen</li>
            <li data-edit-id="anything_list.text_14">Produkte</li>
            <li data-edit-id="anything_list.text_15">FAQ</li>
            <li data-edit-id="anything_list.text_16">Blog</li>
            <li data-edit-id="anything_list.text_17">Öffnungszeiten</li>
            <li class="anything__more" data-edit-id="anything_list.text_18">… und alles, was deine Website sonst braucht</li>
            </ul>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="pro">
            <div class="pro__text">
                <h2 data-edit-id="pro_text.title_2" data-edit-label="U name it, we make it. – Überschrift">U name it, we make it.</h2>
                <p data-edit-id="pro_text.text_2" data-edit-label="U name it, we make it. – Absatz">WordPress, TYPO3 und die anderen großen CMS sind schwer anzupassen und kaum zu automatisieren. Bei uns gehen Änderungen, neue Funktionen und Automatisierungen so leicht wie noch nie: schneller umgesetzt und günstiger.</p>
            </div>
            <ul class="pro__list">
                <li><span class="pro__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="pro_icon.icon" data-edit-label="U name it, we make it. – Icon 1"><path d="M12 22a1 1 0 0 1 0-20 10 9 0 0 1 10 9 5 5 0 0 1-5 5h-2.25a1.75 1.75 0 0 0-1.4 2.8l.3.4a1.75 1.75 0 0 1-1.4 2.8z"/><circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/></svg></span><span data-edit-id="pro_list.text">Neues Design</span></li>
                <li><span class="pro__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="pro_icon.icon_2" data-edit-label="U name it, we make it. – Icon 2"><rect width="18" height="7" x="3" y="3" rx="1"/><rect width="9" height="7" x="3" y="14" rx="1"/><rect width="5" height="7" x="16" y="14" rx="1"/></svg></span><span data-edit-id="pro_list.text_2">Neue Bereiche</span></li>
                <li><span class="pro__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="pro_icon.icon_3" data-edit-label="U name it, we make it. – Icon 3"><path d="M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z"/><path d="M20 2v4"/><path d="M22 4h-4"/><circle cx="4" cy="20" r="2"/></svg></span><span data-edit-id="pro_list.text_3">Neue Funktionen</span></li>
                <li><span class="pro__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="pro_icon.icon_4" data-edit-label="U name it, we make it. – Icon 4"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/></svg></span><span data-edit-id="pro_list.text_4">Automatisierungen</span></li>
            </ul>
        </div>
    </div>
</section>

<section class="section section--soft">
    <div class="container">
        <header class="section__header">
            <h2 data-edit-id="section_header.title_6" data-edit-label="Blitzschnell. Ohne Ballast. – Überschrift">Blitzschnell. Ohne Ballast.</h2>
            <p class="section__lead" data-edit-id="section_header.text_9" data-edit-label="Blitzschnell. Ohne Ballast. – Absatz">Kein schwerfälliges CMS dahinter. Du siehst nur, was du brauchst.</p>
        </header>

        <div class="versus">
            <div class="versus__col">
                <div class="compare__shot compare__shot--cms" aria-hidden="true">
                    <span class="compare__top"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><b>12 Updates</b></span>
                    <span class="compare__body">
                        <span class="compare__side"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></span>
                        <span class="compare__main"><i></i><i></i><i></i><i></i></span>
                    </span>
                </div>
                <h3 data-edit-id="versus_col.title" data-edit-label="Klassisches CMS – Überschrift">Klassisches CMS</h3>
                <ul class="versus__list">
                    <li class="is-con"><span data-edit-id="versus_list.text_2">Eigenes Backend mit hunderten Menüs</span></li>
                    <li class="is-con"><span data-edit-id="versus_list.text_4">Jede Seite wird aus Datenbank und Erweiterungen zusammengebaut, ob nötig oder nicht</span></li>
                    <li class="is-con"><span data-edit-id="versus_list.text_6">Tausend Funktionen, die du nie brauchst</span></li>
                    <li class="is-con"><span data-edit-id="versus_list.text_8">Ständig Updates, die etwas kaputt machen können</span></li>
                    <li class="is-con"><span data-edit-id="versus_list.text_18">Sonderwünsche und Automatisierungen sind aufwendig und teuer</span></li>
                </ul>
            </div>
            <div class="versus__col versus__col--live">
                <div class="compare__shot compare__shot--live" aria-hidden="true">
                    <span class="compare__page"><i></i><i></i><i></i></span>
                    <span class="compare__bar" data-edit-id="compare_shot.text_2"><b>Bearbeiten</b><em>Speichern</em></span>
                </div>
                <h3 data-edit-id="versus_col.title_2" data-edit-label="LeBuild – Überschrift">LeBuild</h3>
                <ul class="versus__list">
                    <li class="is-pro"><span data-edit-id="versus_list.text_10">Direkt auf der Seite: draufklicken, ändern</span></li>
                    <li class="is-pro"><span data-edit-id="versus_list.text_12">Datenbank nur, wo sie Sinn macht, alles andere lädt sofort</span></li>
                    <li class="is-pro"><span data-edit-id="versus_list.text_14">Genau die Funktionen, die du brauchst</span></li>
                    <li class="is-pro"><span data-edit-id="versus_list.text_16">Updates laufen von selbst im Hintergrund</span></li>
                    <li class="is-pro"><span data-edit-id="versus_list.text_20">Jede Anpassung und Automatisierung schnell und günstig umgesetzt</span></li>
                </ul>
            </div>
        </div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
