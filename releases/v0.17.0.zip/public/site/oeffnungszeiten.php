<?php
$page = [
    'title'       => 'Öffnungszeiten',
    'description' => 'Öffnungszeiten wie im Google-Unternehmensprofil: mehrere Bereiche, Urlaub und Feiertage, „Jetzt geöffnet“. Du änderst sie direkt auf der Website.',
    'slug'        => 'oeffnungszeiten',
];
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/funktionen-nav.php';
?>

<section class="section section--soft">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text">Öffnungszeiten</span>
            <h1 data-edit-id="section_header.title" data-edit-label="Immer aktuell, auch am Feiertag. – Überschrift">Immer aktuell, auch am Feiertag.</h1>
            <p class="section__lead" data-edit-id="section_header.text_2" data-edit-label="Immer aktuell, auch am Feiertag. – Absatz">Wochenzeiten, Urlaub und Sonderzeiten trägst du einmal ein. Die Website zeigt von selbst, ob gerade offen ist.</p>
        </header>

        <div class="live-demo live-demo--wide area-tabs" data-tabs>
            <div class="area-tabs__list" role="tablist" aria-label="Bereiche">
                <button type="button" class="area-tabs__tab" role="tab" id="tab-wirtshaus" aria-controls="bereich-wirtshaus" aria-selected="true">
                    <span class="area-tabs__name">Wirtshaus</span>
                    <span data-plugin="opening-hours" data-view="status" data-area="Wirtshaus"></span>
                </button>
                <button type="button" class="area-tabs__tab" role="tab" id="tab-kueche" aria-controls="bereich-kueche" aria-selected="false" tabindex="-1">
                    <span class="area-tabs__name">Küche</span>
                    <span data-plugin="opening-hours" data-view="status" data-area="Küche"></span>
                </button>
                <button type="button" class="area-tabs__tab" role="tab" id="tab-hofladen" aria-controls="bereich-hofladen" aria-selected="false" tabindex="-1">
                    <span class="area-tabs__name">Hofladen</span>
                    <span data-plugin="opening-hours" data-view="status" data-area="Hofladen"></span>
                </button>
            </div>
            <div class="area-tabs__panel" role="tabpanel" id="bereich-wirtshaus" aria-labelledby="tab-wirtshaus">
                <div data-plugin="opening-hours" data-view="week" data-area="Wirtshaus" data-notices="no"></div>
            </div>
            <div class="area-tabs__panel" role="tabpanel" id="bereich-kueche" aria-labelledby="tab-kueche" hidden>
                <div data-plugin="opening-hours" data-view="week" data-area="Küche" data-notices="no"></div>
            </div>
            <div class="area-tabs__panel" role="tabpanel" id="bereich-hofladen" aria-labelledby="tab-hofladen" hidden>
                <div data-plugin="opening-hours" data-view="week" data-area="Hofladen" data-notices="no"></div>
            </div>
            <div class="area-tabs__notices">
                <h3 data-edit-id="area_tabs.title" data-edit-label="Urlaub und Sonderzeiten – Überschrift">Urlaub und Sonderzeiten</h3>
                <div data-plugin="opening-hours" data-view="notices"></div>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <header class="section__header">
            <h2 data-edit-id="section_header.title_2" data-edit-label="Was die Öffnungszeiten können – Überschrift">Was die Öffnungszeiten können</h2>
            <p class="section__lead" data-edit-id="section_header.text_3" data-edit-label="Was die Öffnungszeiten können – Absatz">So viel wie im Google-Unternehmensprofil, nur auf deiner eigenen Website.</p>
        </header>

        <div class="card-grid card-grid--3">
            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon" data-edit-label="Mehrere Bereiche – Icon"><path d="M15 21v-5a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v5"/><path d="M17.774 10.31a1.12 1.12 0 0 0-1.549 0 2.5 2.5 0 0 1-3.451 0 1.12 1.12 0 0 0-1.548 0 2.5 2.5 0 0 1-3.452 0 1.12 1.12 0 0 0-1.549 0 2.5 2.5 0 0 1-3.77-3.248l2.889-4.184A2 2 0 0 1 7 2h10a2 2 0 0 1 1.653.873l2.895 4.192a2.5 2.5 0 0 1-3.774 3.244"/><path d="M4 10.95V19a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8.05"/></svg></span>
                <h3 data-edit-id="feature_card.title" data-edit-label="Mehrere Bereiche – Überschrift">Mehrere Bereiche</h3>
                <p data-edit-id="feature_card.text" data-edit-label="Mehrere Bereiche – Absatz">Geschäft, Küche, Werkstatt: Jeder Bereich bekommt seine eigenen Zeiten.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_2" data-edit-label="Geteilte Zeiten – Icon"><line x1="10" x2="14" y1="2" y2="2"/><line x1="12" x2="15" y1="14" y2="11"/><circle cx="12" cy="14" r="8"/></svg></span>
                <h3 data-edit-id="feature_card.title_2" data-edit-label="Geteilte Zeiten – Überschrift">Geteilte Zeiten</h3>
                <p data-edit-id="feature_card.text_2" data-edit-label="Geteilte Zeiten – Absatz">Mittagspause, warme Küche, offen bis nach Mitternacht: Ein Tag kann beliebig viele Zeiträume haben.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_3" data-edit-label="Urlaub und Feiertage – Icon"><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M16 2v4"/><path d="M3 10h18"/><path d="M8 2v4"/><path d="M17 14h-6"/><path d="M13 18H7"/><path d="M7 14h.01"/><path d="M17 18h.01"/></svg></span>
                <h3 data-edit-id="feature_card.title_3" data-edit-label="Urlaub und Feiertage – Überschrift">Urlaub und Feiertage</h3>
                <p data-edit-id="feature_card.text_3" data-edit-label="Urlaub und Feiertage – Absatz">Eine Ausnahme gilt für einen Tag oder einen Zeitraum, geschlossen oder mit anderen Zeiten. Danach gilt wieder die normale Woche.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_4" data-edit-label="„Jetzt geöffnet“ – Icon"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg></span>
                <h3 data-edit-id="feature_card.title_4" data-edit-label="„Jetzt geöffnet“ – Überschrift">„Jetzt geöffnet“</h3>
                <p data-edit-id="feature_card.text_4" data-edit-label="„Jetzt geöffnet“ – Absatz">Besucher sehen sofort, ob offen ist und wann geschlossen wird, auch kurz vor Ladenschluss.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_5" data-edit-label="Hinweise von selbst – Icon"><path d="M10.268 21a2 2 0 0 0 3.464 0"/><path d="M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326"/></svg></span>
                <h3 data-edit-id="feature_card.title_5" data-edit-label="Hinweise von selbst – Überschrift">Hinweise von selbst</h3>
                <p data-edit-id="feature_card.text_5" data-edit-label="Hinweise von selbst – Absatz">Kommende Ausnahmen erscheinen als Hinweis auf der Seite und verschwinden, wenn sie vorbei sind.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_6" data-edit-label="In Sekunden geändert – Icon"><path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/></svg></span>
                <h3 data-edit-id="feature_card.title_6" data-edit-label="In Sekunden geändert – Überschrift">In Sekunden geändert</h3>
                <p data-edit-id="feature_card.text_6" data-edit-label="In Sekunden geändert – Absatz">Angemeldet klickst du auf die Zeiten und änderst sie direkt hier, ohne Umweg über ein Backend.</p>
            </article>
        </div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
