<?php
$page = [
    'title'       => 'Impressum',
    'description' => 'Impressum und rechtliche Angaben.',
    'slug'        => 'impressum',
];
require __DIR__ . '/includes/header.php';
?>

<section class="section section--narrow">
    <div class="container prose">
        <header class="page-header">
            <span class="section__eyebrow" data-edit-id="page_header.text">Rechtliches</span>
            <h1 data-edit-id="page_header.title" data-edit-label="Impressum – Überschrift">Impressum</h1>
            <p class="section__lead" data-edit-id="page_header.text_2" data-edit-label="Impressum – Absatz">Angaben gemäß § 5 ECG sowie § 25 MedienG (Österreich) – bitte vor Veröffentlichung anpassen.</p>
        </header>

        <h2 data-edit-id="container.title" data-edit-label="Anbieter – Überschrift">Anbieter</h2>
        <p data-edit-id="container.text" data-edit-label="Anbieter – Absatz">
            <strong>Dein Name oder Unternehmensname</strong><br>
            Straße und Hausnummer<br>
            PLZ Ort<br>
            Österreich
        </p>

        <h2 data-edit-id="container.title_2" data-edit-label="Kontakt – Überschrift">Kontakt</h2>
        <p data-edit-id="container.text_2" data-edit-label="Kontakt – Absatz">
            Telefon: <a href="tel:+43000000000">+43 000 000 000</a><br>
            E-Mail: <a href="mailto:office@example.com">office@example.com</a>
        </p>

        <h2 data-edit-id="container.title_3" data-edit-label="Unternehmensgegenstand – Überschrift">Unternehmensgegenstand</h2>
        <p data-edit-id="container.text_3" data-edit-label="Unternehmensgegenstand – Absatz">Kurze Beschreibung der Tätigkeit – z. B. Webentwicklung, Beratung, Dienstleistung.</p>

        <h2 data-edit-id="container.title_4" data-edit-label="UID / Firmenbuch – Überschrift">UID / Firmenbuch</h2>
        <p data-edit-id="container.text_4" data-edit-label="UID / Firmenbuch – Absatz">
            UID-Nummer: ATU00000000<br>
            Firmenbuchnummer: FN 000000 a<br>
            Firmenbuchgericht: Landesgericht ...
        </p>

        <h2 data-edit-id="container.title_5" data-edit-label="Aufsichtsbehörde / Kammer – Überschrift">Aufsichtsbehörde / Kammer</h2>
        <p data-edit-id="container.text_5" data-edit-label="Aufsichtsbehörde / Kammer – Absatz">Zuständige Behörde oder Kammer eintragen, falls erforderlich.</p>

        <h2 data-edit-id="container.title_6" data-edit-label="Online-Streitbeilegung – Überschrift">Online-Streitbeilegung</h2>
        <p data-edit-id="container.text_6" data-edit-label="Online-Streitbeilegung – Absatz">
            Die EU-Kommission stellt eine Plattform zur Online-Streitbeilegung bereit:
            <a href="https://ec.europa.eu/consumers/odr" target="_blank" rel="noopener">ec.europa.eu/consumers/odr</a>.
            Wir sind nicht verpflichtet, an einem Streitbeilegungsverfahren teilzunehmen.
        </p>

        <h2 data-edit-id="container.title_7" data-edit-label="Haftungsausschluss – Überschrift">Haftungsausschluss</h2>
        <p data-edit-id="container.text_7" data-edit-label="Haftungsausschluss – Absatz">
            Die Inhalte dieser Website wurden mit größtmöglicher Sorgfalt erstellt. Für die
            Richtigkeit, Vollständigkeit und Aktualität der Inhalte kann jedoch keine Gewähr
            übernommen werden.
        </p>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
