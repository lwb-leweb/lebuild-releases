<?php
$page = [
    'title'       => 'Cookie-Banner',
    'description' => 'Ein Cookie-Banner nach DSGVO: YouTube, Google Maps und Statistik laden erst nach Zustimmung, ohne Cookie-Wall und ohne fremden Dienst.',
    'slug'        => 'cookie-banner',
];
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/funktionen-nav.php';
?>

<section class="section section--soft">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text">Cookie-Banner</span>
            <h1 data-edit-id="section_header.title" data-edit-label="Fair zu Besuchern, sicher für dich. – Überschrift">Fair zu Besuchern, sicher für dich.</h1>
            <p class="section__lead" data-edit-id="section_header.text_2" data-edit-label="Fair zu Besuchern, sicher für dich. – Absatz">Videos, Karten und Statistik laden erst, wenn Besucher zustimmen. Das erkennt die Website von selbst, du musst nichts markieren.</p>
        </header>

        <div class="card-grid card-grid--3">
            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon" data-edit-label="Blockt, bis jemand zustimmt – Icon"><path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"/><path d="m10 15 5-3-5-3z"/></svg></span>
                <h3 data-edit-id="feature_card.title" data-edit-label="Blockt, bis jemand zustimmt – Überschrift">Blockt, bis jemand zustimmt</h3>
                <p data-edit-id="feature_card.text" data-edit-label="Blockt, bis jemand zustimmt – Absatz">YouTube, Vimeo, Google Maps, Google Analytics, Meta-Pixel und Hotjar bleiben aus, bis Besucher Ja sagen.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_2" data-edit-label="Drei gleiche Knöpfe – Icon"><path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/><path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/><path d="M7 21h10"/><path d="M12 3v18"/><path d="M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2"/></svg></span>
                <h3 data-edit-id="feature_card.title_2" data-edit-label="Drei gleiche Knöpfe – Überschrift">Drei gleiche Knöpfe</h3>
                <p data-edit-id="feature_card.text_2" data-edit-label="Drei gleiche Knöpfe – Absatz">Ablehnen, Einstellungen, Alle akzeptieren: gleich groß und gleich auffällig, so wie es das Gesetz verlangt.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_3" data-edit-label="Keine Cookie-Wall – Icon"><path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/></svg></span>
                <h3 data-edit-id="feature_card.title_3" data-edit-label="Keine Cookie-Wall – Überschrift">Keine Cookie-Wall</h3>
                <p data-edit-id="feature_card.text_3" data-edit-label="Keine Cookie-Wall – Absatz">Der Banner erscheint unten am Rand. Die Seite bleibt lesbar, auch bevor jemand entscheidet.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_4" data-edit-label="Einzeln laden – Icon"><path d="m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5"/><rect x="2" y="6" width="14" height="12" rx="2"/></svg></span>
                <h3 data-edit-id="feature_card.title_4" data-edit-label="Einzeln laden – Überschrift">Einzeln laden</h3>
                <p data-edit-id="feature_card.text_4" data-edit-label="Einzeln laden – Absatz">Wer nur ein Video sehen will, klickt am Video auf „Inhalt laden“, ohne allem zuzustimmen.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_5" data-edit-label="Deine Texte – Icon"><path d="M14 17H5"/><path d="M19 7h-9"/><circle cx="17" cy="17" r="3"/><circle cx="7" cy="7" r="3"/></svg></span>
                <h3 data-edit-id="feature_card.title_5" data-edit-label="Deine Texte – Überschrift">Deine Texte</h3>
                <p data-edit-id="feature_card.text_5" data-edit-label="Deine Texte – Absatz">Texte, Kategorien und Link zur Datenschutzerklärung pflegst du selbst. Nach einer Änderung fragt der Banner auf Wunsch alle neu.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_6" data-edit-label="Kein Cookie für den Banner – Icon"><path d="M12 10a2 2 0 0 0-2 2c0 1.02-.1 2.51-.26 4"/><path d="M14 13.12c0 2.38 0 6.38-1 8.88"/><path d="M17.29 21.02c.12-.6.43-2.3.5-3.02"/><path d="M2 12a10 10 0 0 1 18-6"/><path d="M2 16h.01"/><path d="M21.8 16c.2-2 .131-5.354 0-6"/><path d="M5 19.5C5.5 18 6 15 6 12a6 6 0 0 1 .34-2"/><path d="M8.65 22c.21-.66.45-1.32.57-2"/><path d="M9 6.8a6 6 0 0 1 9 5.2v2"/></svg></span>
                <h3 data-edit-id="feature_card.title_6" data-edit-label="Kein Cookie für den Banner – Überschrift">Kein Cookie für den Banner</h3>
                <p data-edit-id="feature_card.text_6" data-edit-label="Kein Cookie für den Banner – Absatz">Die Entscheidung bleibt im Browser des Besuchers. Auf deinem Server wird nichts davon gespeichert.</p>
            </article>
        </div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
