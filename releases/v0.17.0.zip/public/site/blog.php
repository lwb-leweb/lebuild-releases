<?php
$page = [
    'title'       => 'Blog',
    'description' => 'Neuigkeiten und Beiträge mit Bild schreibst du direkt auf deiner Website, jeder Beitrag bekommt eine eigene Seite.',
    'slug'        => 'blog',
];
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/funktionen-nav.php';
?>

<section class="section section--soft">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text">Blog</span>
            <h1 data-edit-id="section_header.title" data-edit-label="Neuigkeiten, so schnell wie ein Posting. – Überschrift">Neuigkeiten, so schnell wie ein Posting.</h1>
            <p class="section__lead" data-edit-id="section_header.text_2" data-edit-label="Neuigkeiten, so schnell wie ein Posting. – Absatz">Titel, Bild, Text: Ein Beitrag ist in Minuten online und bleibt dauerhaft auf deiner Website, nicht nur im Feed.</p>
        </header>

        <div id="beitraege" class="beispiele" data-plugin="content-types" data-view="list" data-type="blog" data-limit="6"></div>
    </div>
</section>

<section class="section">
    <div class="container">
        <header class="section__header">
            <h2 data-edit-id="section_header.title_3" data-edit-label="So geht&apos;s – Überschrift">So geht's</h2>
        </header>

        <div class="card-grid card-grid--3">
            <article class="step">
                <span class="step__number" data-edit-id="step.text">1</span>
                <span class="step__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="step_icon.icon" data-edit-label="Schreiben – Icon"><path d="M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z"/></svg></span>
                <h3 data-edit-id="step.title" data-edit-label="Schreiben – Überschrift">Schreiben</h3>
                <p data-edit-id="step.text_2" data-edit-label="Schreiben – Absatz">Auf der Blog-Seite auf „Neuer Eintrag“ klicken, Titel und Text eintippen, ein Bild dazu.</p>
            </article>

            <article class="step">
                <span class="step__number" data-edit-id="step.text_3">2</span>
                <span class="step__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="step_icon.icon_2" data-edit-label="Veröffentlichen – Icon"><path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/><path d="m9 16 2 2 4-4"/></svg></span>
                <h3 data-edit-id="step.title_2" data-edit-label="Veröffentlichen – Überschrift">Veröffentlichen</h3>
                <p data-edit-id="step.text_4" data-edit-label="Veröffentlichen – Absatz">Sofort oder zu einem festen Termin, etwa für die Ankündigung am Montag um acht.</p>
            </article>

            <article class="step">
                <span class="step__number" data-edit-id="step.text_5">3</span>
                <span class="step__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="step_icon.icon_3" data-edit-label="Gefunden werden – Icon"><path d="m21 21-4.34-4.34"/><circle cx="11" cy="11" r="8"/></svg></span>
                <h3 data-edit-id="step.title_3" data-edit-label="Gefunden werden – Überschrift">Gefunden werden</h3>
                <p data-edit-id="step.text_6" data-edit-label="Gefunden werden – Absatz">Jeder Beitrag hat eine eigene Seite mit eigener Adresse, die Google und KI-Chats lesen.</p>
            </article>
        </div>
    </div>
</section>

<section class="section section--soft">
    <div class="container">
        <header class="section__header">
            <h2 data-edit-id="section_header.title_2" data-edit-label="Was der Blog kann – Überschrift">Was der Blog kann</h2>
        </header>

        <div class="card-grid card-grid--3">
            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon" data-edit-label="Bild zu jedem Beitrag – Icon"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg></span>
                <h3 data-edit-id="feature_card.title" data-edit-label="Bild zu jedem Beitrag – Überschrift">Bild zu jedem Beitrag</h3>
                <p data-edit-id="feature_card.text" data-edit-label="Bild zu jedem Beitrag – Absatz">Hochladen, fertig. Die Website zeigt es in der Übersicht und auf der Seite des Beitrags.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_2" data-edit-label="Text mit Auszeichnung – Icon"><path d="M12 4v16"/><path d="M4 7V5a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v2"/><path d="M9 20h6"/></svg></span>
                <h3 data-edit-id="feature_card.title_2" data-edit-label="Text mit Auszeichnung – Überschrift">Text mit Auszeichnung</h3>
                <p data-edit-id="feature_card.text_2" data-edit-label="Text mit Auszeichnung – Absatz">Zwischenüberschriften, fett, Listen und Links, ohne dass das Layout der Website leidet.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_3" data-edit-label="Saubere Adressen – Icon"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg></span>
                <h3 data-edit-id="feature_card.title_3" data-edit-label="Saubere Adressen – Überschrift">Saubere Adressen</h3>
                <p data-edit-id="feature_card.text_3" data-edit-label="Saubere Adressen – Absatz">Die Adresse entsteht aus dem Titel, gut zu lesen und gut zu teilen.</p>
            </article>
        </div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
