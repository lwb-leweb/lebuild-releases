<?php
$page = [
    'title'       => 'Funktionen',
    'description' => 'Listen, Öffnungszeiten, Blog, Kontaktformular und Cookie-Banner: alles, was LeBuild für deine Website mitbringt, und alles pflegst du selbst.',
    'slug'        => 'funktionen',
];
require __DIR__ . '/includes/header.php';
?>

<section class="section section--soft">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text">Funktionen</span>
            <h1 data-edit-id="section_header.title" data-edit-label="Alles, was deine Website braucht. – Überschrift">Alles, was deine Website braucht.</h1>
            <p class="section__lead" data-edit-id="section_header.text_2" data-edit-label="Alles, was deine Website braucht. – Absatz">Jede Funktion schaltest du nur ein, wenn du sie brauchst. Gepflegt wird alles gleich: draufklicken, ändern, speichern.</p>
        </header>

        <ul class="targets targets--3">
            <li>
                <a class="targets__item" href="/listen" data-edit-id="link_1.url">
                    <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon" data-edit-label="Alles, was deine Website braucht. – Icon 1"><path d="M3 5h.01"/><path d="M3 12h.01"/><path d="M3 19h.01"/><path d="M8 5h13"/><path d="M8 12h13"/><path d="M8 19h13"/></svg></span>
                    <span class="targets__title" data-edit-id="targets_item.text">Listen</span>
                    <span data-edit-id="targets_item.text_2">Team, Leistungen, Speisekarte, Fragen: Alles, was mehrfach vorkommt, pflegst du als Liste.</span>
                    <span class="targets__go" data-edit-id="targets_item.text_3">Ansehen →</span>
                </a>
            </li>
            <li>
                <a class="targets__item" href="/oeffnungszeiten" data-edit-id="link_2.url">
                    <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_2" data-edit-label="Alles, was deine Website braucht. – Icon 2"><path d="M12 6v6l4 2"/><circle cx="12" cy="12" r="10"/></svg></span>
                    <span class="targets__title" data-edit-id="targets_item.text_4">Öffnungszeiten</span>
                    <span data-edit-id="targets_item.text_5">Wochenzeiten, Urlaub und Feiertage, dazu „Jetzt geöffnet“ wie bei Google.</span>
                    <span class="targets__go" data-edit-id="targets_item.text_6">Ansehen →</span>
                </a>
            </li>
            <li>
                <a class="targets__item" href="/blog" data-edit-id="link_3.url">
                    <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_3" data-edit-label="Alles, was deine Website braucht. – Icon 3"><path d="M15 18h-5"/><path d="M18 14h-8"/><path d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-4 0v-9a2 2 0 0 1 2-2h2"/><rect width="8" height="4" x="10" y="6" rx="1"/></svg></span>
                    <span class="targets__title" data-edit-id="targets_item.text_7">Blog</span>
                    <span data-edit-id="targets_item.text_8">Neuigkeiten und Beiträge mit Bild, jeder mit eigener Seite, auf Wunsch zu einem festen Termin.</span>
                    <span class="targets__go" data-edit-id="targets_item.text_9">Ansehen →</span>
                </a>
            </li>
            <li>
                <a class="targets__item" href="/kontaktformular" data-edit-id="link_4.url">
                    <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_4" data-edit-label="Alles, was deine Website braucht. – Icon 4"><path d="m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7"/><rect x="2" y="4" width="20" height="16" rx="2"/></svg></span>
                    <span class="targets__title" data-edit-id="targets_item.text_10">Kontaktformular</span>
                    <span data-edit-id="targets_item.text_11">Anfragen landen direkt in deinem Postfach, mit Spamschutz ohne lästige Rätsel.</span>
                    <span class="targets__go" data-edit-id="targets_item.text_12">Ansehen →</span>
                </a>
            </li>
            <li>
                <a class="targets__item" href="/cookie-banner" data-edit-id="link_5.url">
                    <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_5" data-edit-label="Alles, was deine Website braucht. – Icon 5"><path d="M12 2a10 10 0 1 0 10 10 4 4 0 0 1-5-5 4 4 0 0 1-5-5"/><path d="M8.5 8.5v.01"/><path d="M16 15.5v.01"/><path d="M12 12v.01"/><path d="M11 17v.01"/><path d="M7 14v.01"/></svg></span>
                    <span class="targets__title" data-edit-id="targets_item.text_13">Cookie-Banner</span>
                    <span data-edit-id="targets_item.text_14">YouTube, Google Maps und Statistik laden erst, wenn Besucher zustimmen.</span>
                    <span class="targets__go" data-edit-id="targets_item.text_15">Ansehen →</span>
                </a>
            </li>
            <li>
                <a class="targets__item" href="#kontakt" data-edit-id="link_6.url">
                    <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_6" data-edit-label="Alles, was deine Website braucht. – Icon 6"><path d="M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z"/><path d="M20 2v4"/><path d="M22 4h-4"/><circle cx="4" cy="20" r="2"/></svg></span>
                    <span class="targets__title" data-edit-id="targets_item.text_16">Deine Idee</span>
                    <span data-edit-id="targets_item.text_17">Buchungen, Gutscheine, eine Schnittstelle zu deinem Programm: Was fehlt, bauen wir dazu.</span>
                    <span class="targets__go" data-edit-id="targets_item.text_18">Anfragen →</span>
                </a>
            </li>
        </ul>
    </div>
</section>

<section class="section">
    <div class="container">
        <header class="section__header">
            <h2 data-edit-id="section_header.title_2" data-edit-label="Eine Bedienung für alles. – Überschrift">Eine Bedienung für alles.</h2>
            <p class="section__lead" data-edit-id="section_header.text_3" data-edit-label="Eine Bedienung für alles. – Absatz">Egal welche Funktion: Du lernst nichts Neues dazu.</p>
        </header>

        <div class="card-grid card-grid--3">
            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_7" data-edit-label="Direkt auf der Seite – Icon"><path d="M14 4.1 12 6"/><path d="m5.1 8-2.9-.8"/><path d="m6 12-1.9 2"/><path d="M7.2 2.2 8 5.1"/><path d="M9.037 9.69a.498.498 0 0 1 .653-.653l11 4.5a.5.5 0 0 1-.074.949l-4.349 1.041a1 1 0 0 0-.74.739l-1.04 4.35a.5.5 0 0 1-.95.074z"/></svg></span>
                <h3 data-edit-id="feature_card.title" data-edit-label="Direkt auf der Seite – Überschrift">Direkt auf der Seite</h3>
                <p data-edit-id="feature_card.text" data-edit-label="Direkt auf der Seite – Absatz">Du änderst Einträge dort, wo Besucher sie sehen. Kein eigenes Backend, kein Suchen in Menüs.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_8" data-edit-label="Nur, was du brauchst – Icon"><path d="M15.39 4.39a1 1 0 0 0 1.68-.474 2.5 2.5 0 1 1 3.014 3.015 1 1 0 0 0-.474 1.68l1.683 1.682a2.414 2.414 0 0 1 0 3.414L19.61 15.39a1 1 0 0 1-1.68-.474 2.5 2.5 0 1 0-3.014 3.015 1 1 0 0 1 .474 1.68l-1.683 1.682a2.414 2.414 0 0 1-3.414 0L8.61 19.61a1 1 0 0 0-1.68.474 2.5 2.5 0 1 1-3.014-3.015 1 1 0 0 0 .474-1.68l-1.683-1.682a2.414 2.414 0 0 1 0-3.414L4.39 8.61a1 1 0 0 1 1.68.474 2.5 2.5 0 1 0 3.014-3.015 1 1 0 0 1-.474-1.68l1.683-1.682a2.414 2.414 0 0 1 3.414 0z"/></svg></span>
                <h3 data-edit-id="feature_card.title_2" data-edit-label="Nur, was du brauchst – Überschrift">Nur, was du brauchst</h3>
                <p data-edit-id="feature_card.text_2" data-edit-label="Nur, was du brauchst – Absatz">Jede Funktion ist ein eigener Baustein. Was du nicht nutzt, ist nicht da und bremst nichts.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_9" data-edit-label="Schnell erweitert – Icon"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/></svg></span>
                <h3 data-edit-id="feature_card.title_3" data-edit-label="Schnell erweitert – Überschrift">Schnell erweitert</h3>
                <p data-edit-id="feature_card.text_3" data-edit-label="Schnell erweitert – Absatz">Eine neue Funktion setzen wir in Tagen um, nicht in Wochen, und sie fügt sich ein wie alle anderen.</p>
            </article>
        </div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
