<?php
$page = [
    'title'       => 'Listen',
    'description' => 'Fragen, Leistungen, Projekte, Team: Alles, was auf deiner Website mehrfach vorkommt, pflegst du als Liste. Und du bestimmst, was beim Klick auf einen Eintrag passiert.',
    'slug'        => 'listen',
];
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/funktionen-nav.php';
?>

<section class="section section--soft">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text">Listen</span>
            <h1 data-edit-id="section_header.title" data-edit-label="Alles, was mehrfach vorkommt, ist eine L… – Überschrift">Alles, was mehrfach vorkommt, ist eine Liste.</h1>
            <p class="section__lead" data-edit-id="section_header.text_2" data-edit-label="Alles, was mehrfach vorkommt, ist eine L… – Absatz">Fragen, Leistungen, Projekte, Team: Für jeden Eintrag füllst du ein kurzes Formular aus, die Website zeigt ihn so, wie es zu ihr passt. Und du bestimmst, was beim Klick passiert.</p>
        </header>

        <ul class="targets">
            <li>
                <a class="targets__item" href="#faq" data-edit-id="link_1.url">
                    <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon" data-edit-label="Alles, was mehrfach vorkommt, ist eine L… – Icon 1"><path d="M3 5h.01"/><path d="M3 12h.01"/><path d="M3 19h.01"/><path d="M8 5h13"/><path d="M8 12h13"/><path d="M8 19h13"/></svg></span>
                    <span class="targets__title" data-edit-id="targets_item.text_5">Nichts</span>
                    <span data-edit-id="targets_item.text">Der Eintrag steht einfach da, zum Beispiel eine Frage mit Antwort.</span>
                </a>
            </li>
            <li>
                <a class="targets__item" href="#bausteine" data-edit-id="link_2.url">
                    <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_2" data-edit-label="Alles, was mehrfach vorkommt, ist eine L… – Icon 2"><path d="M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z"/><path d="M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12"/><path d="M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17"/></svg></span>
                    <span class="targets__title" data-edit-id="targets_item.text_6">Details im Fenster</span>
                    <span data-edit-id="targets_item.text_2">Ein Klick öffnet mehr Infos über der Seite.</span>
                </a>
            </li>
            <li>
                <a class="targets__item" href="#beispiele" data-edit-id="link_3.url">
                    <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_3" data-edit-label="Alles, was mehrfach vorkommt, ist eine L… – Icon 3"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/></svg></span>
                    <span class="targets__title" data-edit-id="targets_item.text_7">Eigene Seite</span>
                    <span data-edit-id="targets_item.text_3">Der Eintrag bekommt eine eigene Seite mit eigener Adresse.</span>
                </a>
            </li>
            <li>
                <a class="targets__item" href="#beispiele" data-edit-id="link_4.url">
                    <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_4" data-edit-label="Alles, was mehrfach vorkommt, ist eine L… – Icon 4"><circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/></svg></span>
                    <span class="targets__title" data-edit-id="targets_item.text_8">Link</span>
                    <span data-edit-id="targets_item.text_4">Der Eintrag führt woandershin, etwa zu einer anderen Website.</span>
                </a>
            </li>
        </ul>
    </div>
</section>

<section id="faq" class="section section--narrow">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text_3">Ohne Klickziel</span>
            <h2 data-edit-id="section_header.title_2" data-edit-label="Häufige Fragen – Überschrift">Häufige Fragen</h2>
            <p class="section__lead" data-edit-id="section_header.text_4" data-edit-label="Häufige Fragen – Absatz">Einfach aufklappen. Eine neue Frage ist ein neuer Eintrag, die Reihenfolge änderst du mit den Pfeilen.</p>
        </header>

        <div class="faq" data-plugin="content-types" data-view="list" data-type="faq" data-limit="50"></div>
    </div>
</section>

<section id="bausteine" class="section section--soft">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text_5">Details im Fenster</span>
            <h2 data-edit-id="section_header.title_3" data-edit-label="Woraus ein Eintrag bestehen kann – Überschrift">Woraus ein Eintrag bestehen kann</h2>
            <p class="section__lead" data-edit-id="section_header.text_6" data-edit-label="Woraus ein Eintrag bestehen kann – Absatz">Klick auf eine Karte: Die Details öffnen sich über der Seite, du bleibst, wo du bist.</p>
        </header>

        <div class="card-grid bausteine" data-plugin="content-types" data-view="list" data-type="bausteine" data-limit="50"></div>
    </div>
</section>

<section id="beispiele" class="section">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text_7">Eigene Seite oder Link</span>
            <h2 data-edit-id="section_header.title_4" data-edit-label="So könnte das bei dir aussehen – Überschrift">So könnte das bei dir aussehen</h2>
            <p class="section__lead" data-edit-id="section_header.text_8" data-edit-label="So könnte das bei dir aussehen – Absatz">Jeder Eintrag entscheidet selbst: Er bekommt eine eigene Seite, oder er führt woandershin. Umstellen geht mit einem Klick im Formular.</p>
        </header>

        <div class="beispiele" data-plugin="content-types" data-view="list" data-type="beispiele" data-limit="50"></div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
