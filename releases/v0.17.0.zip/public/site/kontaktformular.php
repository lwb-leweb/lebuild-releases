<?php
$page = [
    'title'       => 'Kontaktformular',
    'description' => 'Anfragen von deiner Website landen direkt in deinem Postfach, mit Spamschutz ohne Rätsel und ohne fremde Dienste.',
    'slug'        => 'kontaktformular',
];
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/funktionen-nav.php';
?>

<section class="section section--soft">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text">Kontaktformular</span>
            <h1 data-edit-id="section_header.title" data-edit-label="Anfragen direkt ins Postfach. – Überschrift">Anfragen direkt ins Postfach.</h1>
            <p class="section__lead" data-edit-id="section_header.text_2" data-edit-label="Anfragen direkt ins Postfach. – Absatz">Besucher schreiben dir, ohne ihr Mailprogramm zu öffnen. Du antwortest einfach auf die Mail.</p>
        </header>

        <div class="card-grid card-grid--3">
            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon" data-edit-label="Landet bei dir – Icon"><polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/></svg></span>
                <h3 data-edit-id="feature_card.title" data-edit-label="Landet bei dir – Überschrift">Landet bei dir</h3>
                <p data-edit-id="feature_card.text" data-edit-label="Landet bei dir – Absatz">Jede Nachricht kommt als Mail an die Adresse, die du festlegst. „Antworten“ geht direkt an den Absender.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_2" data-edit-label="Spamschutz ohne Rätsel – Icon"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/></svg></span>
                <h3 data-edit-id="feature_card.title_2" data-edit-label="Spamschutz ohne Rätsel – Überschrift">Spamschutz ohne Rätsel</h3>
                <p data-edit-id="feature_card.text_2" data-edit-label="Spamschutz ohne Rätsel – Absatz">Kein Ampeln-Anklicken, kein Captcha. Bots fallen trotzdem raus, und zu viele Nachrichten in kurzer Zeit werden gebremst.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_3" data-edit-label="Keine fremden Dienste – Icon"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg></span>
                <h3 data-edit-id="feature_card.title_3" data-edit-label="Keine fremden Dienste – Überschrift">Keine fremden Dienste</h3>
                <p data-edit-id="feature_card.text_3" data-edit-label="Keine fremden Dienste – Absatz">Die Nachricht geht von deiner Website an dein Postfach. Kein Anbieter dazwischen, der mitliest.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_4" data-edit-label="Felder nach Bedarf – Icon"><rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M12 11h4"/><path d="M12 16h4"/><path d="M8 11h.01"/><path d="M8 16h.01"/></svg></span>
                <h3 data-edit-id="feature_card.title_4" data-edit-label="Felder nach Bedarf – Überschrift">Felder nach Bedarf</h3>
                <p data-edit-id="feature_card.text_4" data-edit-label="Felder nach Bedarf – Absatz">Name, E-Mail und Nachricht sind immer dabei. Firma, Telefon oder Betreff kommen dazu, wenn du sie brauchst.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_5" data-edit-label="Mehrere Empfänger – Icon"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><path d="M16 3.128a4 4 0 0 1 0 7.744"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><circle cx="9" cy="7" r="4"/></svg></span>
                <h3 data-edit-id="feature_card.title_5" data-edit-label="Mehrere Empfänger – Überschrift">Mehrere Empfänger</h3>
                <p data-edit-id="feature_card.text_5" data-edit-label="Mehrere Empfänger – Absatz">Das Formular für Bewerbungen geht an die Personalabteilung, das für Bestellungen an den Verkauf.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="feature_card_icon.icon_6" data-edit-label="Mit deinem Mailserver – Icon"><path d="M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z"/><path d="m21.854 2.147-10.94 10.939"/></svg></span>
                <h3 data-edit-id="feature_card.title_6" data-edit-label="Mit deinem Mailserver – Überschrift">Mit deinem Mailserver</h3>
                <p data-edit-id="feature_card.text_6" data-edit-label="Mit deinem Mailserver – Absatz">Versand über dein eigenes Postfach, damit Anfragen nicht im Spam-Ordner landen.</p>
            </article>
        </div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
