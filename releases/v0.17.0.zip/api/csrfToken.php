<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';

// CSRF-Token der aktuellen Anmeldung (nur lesen, wie getPage ohne CSRF): Der Seiten-Editor holt es
// nach einer neuen Anmeldung in einem anderen Tab (site-editor/request.js), ohne die Seite neu abzurufen.
require_auth();

json_response(['ok' => true, 'csrfToken' => csrf_token()]);
