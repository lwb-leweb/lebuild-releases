<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';

// Nur per POST mit CSRF-Token, damit ein Link auf einer fremden Seite niemanden abmeldet. Ohne
// Anmeldung (abgelaufen) gibt es nichts zu schützen: dann nur die Session aufräumen.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}
start_app_session();
if (session_user() !== null) {
    require_csrf();
    le_activity_log('logout');
}
logout_user();

json_response(['ok' => true]);

