<?php
declare(strict_types=1);

// Schließt ein Formular, das Bilder hochgeladen hat (site-editor/upload.js), nach Speichern oder Verwerfen: Seine
// offenen Uploads fallen aus der Liste, unbenutzte Dateien werden gelöscht (core/uploads.php). Body { form, urls? }:
// mit urls nur diese, und nur, wenn jede ein offener Upload dieses Formulars und Benutzers ist.

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/uploads.php';

require_auth();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$form = $body['form'] ?? null;
$urls = $body['urls'] ?? null;
$files = is_array($urls) ? array_map(static fn (mixed $url): ?string => is_string($url) ? upload_file_name($url) : null, $urls) : null;
if (!is_string($form) || !preg_match(LE_UPLOAD_FORM_PATTERN, $form) || ($urls !== null && ($files === null || in_array(null, $files, true)))) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidRequest']], 400);
}

$now = time();
try {
    $deleted = le_open_uploads_discard($form, (string) current_user()['id'], $files);
} catch (Throwable $e) {
    error_log('discard uploads failed: ' . $e->getMessage());
    json_response(['ok' => false, 'error' => API_TEXT['discardUploadsFailed']], 500);
}
if ($deleted === null) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidRequest']], 400);
}
// Fallback für nie geschlossene Formulare; scheitert er, ist das Verwerfen trotzdem erledigt.
le_open_uploads_expire($now);

json_response(['ok' => true, 'deleted' => $deleted]);
