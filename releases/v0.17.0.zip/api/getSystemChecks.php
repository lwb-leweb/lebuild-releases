<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/system.php';

require_admin();

json_response([
    'ok' => true,
    'checks' => system_checks(),
]);
