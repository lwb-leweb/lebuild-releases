<?php
declare(strict_types=1);

// Stand für Einstellungen → Backup (Sicherung der Installation, nicht die
// Seiten-Revisionen aus listBackups.php).

require_once __DIR__ . '/../core/siteBackup.php';

require_admin();

json_response(['ok' => true] + site_backup_admin_status());
