<?php
declare(strict_types=1);

// Öffentlicher Health-Check für Uptime-Monitore: ohne Session und CSRF, 503 bei einem Fehler,
// die Einzelprüfungen nur mit Bearer-Token (core/health.php).

require_once __DIR__ . '/../core/health.php';

health_respond();
