<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/mail.php';

require_admin();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

try {
    core_mail_delete_config();
} catch (Throwable $e) {
    error_log('deleteMailConfig: ' . $e->getMessage());
    json_response(['ok' => false, 'error' => API_TEXT['mailDeleteFailed']], 500);
}
le_activity_log('mail_settings_deleted');

json_response([
    'ok' => true,
    'config' => core_mail_public_config(),
    'status' => core_mail_status(),
]);
