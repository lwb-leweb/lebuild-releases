<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/fileStore.php';
require_once __DIR__ . '/../core/importer.php';
require_once __DIR__ . '/../core/labels.php';
require_once __DIR__ . '/../core/phpRewriter.php';

require_auth();

$page = safe_page_name((string) ($_GET['page'] ?? ''));

// Unter derselben Sperre wie das Speichern: direkt geänderte Dateien erst abgleichen (le_sync_request),
// dann gilt ihr Stand als Stand beim Laden. refreshed: Die ausgelieferte Seite hat die neuen
// Markierungen noch nicht, der Seiten-Editor lädt neu. Eine Komponente, deren Abgleich scheitert,
// kommt mit ihrem alten Stand, message sagt es (le_sync_skipped_notice); ein Speichern mit
// Änderungen an ihr antwortet 422.
[$locks, $sync] = le_sync_request([$page, ...array_keys(shared_components())]);
$refreshed = $sync['refreshed'];
// Felder samt Komponenten, Feldart je Pfad (Bild, Link, Linktext, Alt-Text, Hintergrund) und
// Namen; dieselbe Form vergleicht das Speichern als Stand beim Laden (merge_save_content).
['content' => $content, 'fieldKinds' => $fieldKinds, 'docs' => $docs] = page_editor_content($page);
unlock_pages($locks);

json_response([
    'ok' => true,
    'page' => $page,
    'content' => $content,
    'labels' => build_labels_for_content($content, $docs),
    'fieldKinds' => $fieldKinds,
    'refreshed' => $refreshed !== [],
] + le_sync_skipped_notice($sync['failed']));
