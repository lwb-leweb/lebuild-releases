<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/fileStore.php';

require_auth();

// Verlauf: ein Eintrag je Speichern mit fertiger Zeile (page_history), Wiederherstellen über restore.php.
$page = safe_page_name((string) ($_GET['page'] ?? ''));

json_response([
    'ok' => true,
    'page' => $page,
    'backups' => page_history($page, time()),
]);
