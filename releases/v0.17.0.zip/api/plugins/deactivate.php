<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/plugins.php';

require_admin();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$name = (string) ($body['name'] ?? '');
if (!plugin_name_valid($name)) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidPlugin']], 400);
}

// Lesen → Ändern → Schreiben von active-plugins.json unter Sperre, bis zum Ende des Requests.
$lock = store_lock('plugins');
$state = load_plugins_state();
$state['active'] = array_values(array_diff($state['active'], [$name]));

try {
    save_plugins_state($state);
} catch (Throwable $e) {
    error_log('plugin deactivate ' . $name . ': ' . $e->getMessage());
    json_response(['ok' => false, 'error' => API_TEXT['pluginStateFailed']], 500);
}
le_activity_log('plugin_deactivated', $name);

json_response(['ok' => true, 'name' => $name, 'state' => load_plugins_state()]);
