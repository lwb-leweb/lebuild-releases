<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/db.php';

require_admin();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$config = db_config_from_body(read_json_body());
$result = db_test_connection($config);
json_response($result, $result['ok'] ? 200 : 400);
