<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../../../core/db.php';
require_once __DIR__ . '/../../../core/pluginSchema.php';
require_once __DIR__ . '/../../../core/uploads.php';

require_auth();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$name = (string) ($body['plugin'] ?? '');
$id = (int) ($body['id'] ?? 0);
if (!plugin_name_valid($name) || $id <= 0) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidRequest']], 400);
}
require_plugin_active($name);

if (plugin_main_table(plugin_manifest($name)) === null) {
    json_response(['ok' => false, 'error' => API_TEXT['noMainTable']], 400);
}

try {
    $deleted = plugin_delete_entry($name, $id);
} catch (Throwable $e) {
    plugin_failure_response('delete', $e);
}
if (!$deleted) {
    json_response(['ok' => false, 'error' => API_TEXT['notFound']], 404);
}
le_activity_log('plugin_entry_deleted', le_activity_plugin_target($name, $id));

json_response(['ok' => true]);
