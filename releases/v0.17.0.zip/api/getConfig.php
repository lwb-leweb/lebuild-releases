<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';

require_auth();

// Ohne Gespeichertes die neutralen Vorgaben (LE_SITE_CONFIG_DEFAULTS).
json_response(['ok' => true, 'config' => le_site_config_with_defaults()]);
