<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/fileStore.php';
require_once __DIR__ . '/../core/uploads.php';
require_once __DIR__ . '/../core/images.php';

require_auth();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

// Über post_max_size verwirft PHP den ganzen Body, $_FILES bleibt leer.
if (empty($_FILES['file']) || !is_array($_FILES['file'])) {
    $tooLarge = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > upload_max_bytes();
    json_response(['ok' => false, 'error' => $tooLarge ? upload_too_large_message() : UPLOAD_TEXT['noFile']], 400);
}

// Formular, aus dem hochgeladen wird (site-editor/upload.js): Bis es gespeichert oder verworfen ist, bleibt der Upload offen.
$form = $_POST['form'] ?? '';
if (!is_string($form) || ($form !== '' && !preg_match(LE_UPLOAD_FORM_PATTERN, $form))) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidRequest']], 400);
}

$file = $_FILES['file'];
$error = $file['error'] ?? UPLOAD_ERR_NO_FILE;
if (($error === UPLOAD_ERR_INI_SIZE || $error === UPLOAD_ERR_FORM_SIZE) || ($error === UPLOAD_ERR_OK && ($file['size'] ?? 0) > upload_max_bytes())) {
    json_response(['ok' => false, 'error' => upload_too_large_message()], 400);
}
if ($error !== UPLOAD_ERR_OK) {
    json_response(['ok' => false, 'error' => UPLOAD_TEXT['failed']], 400);
}

$originalName = (string) ($file['name'] ?? '');
$extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
if (!isset(UPLOAD_MIME_TYPES[$extension])) {
    json_response(['ok' => false, 'error' => sprintf(UPLOAD_TEXT['type'], implode(', ', array_keys(UPLOAD_MIME_TYPES)))], 400);
}

$tmp = (string) ($file['tmp_name'] ?? '');
$mime = mime_content_type($tmp) ?: '';
// Endung und tatsächlicher Inhalt müssen zusammenpassen (UPLOAD_MIME_TYPES).
if (!in_array($mime, UPLOAD_MIME_TYPES[$extension], true)) {
    json_response(['ok' => false, 'error' => UPLOAD_TEXT['content']], 400);
}
if ($extension === 'svg' && !svg_is_safe((string) file_get_contents($tmp))) {
    json_response(['ok' => false, 'error' => UPLOAD_TEXT['svg']], 400);
}

// JPG und PNG als verkleinertes WebP (core/images.php), vor der Sperre: Das Umrechnen kann dauern. null: unverändert.
$webp = le_image_optimized($tmp, $extension);

prepare_storage();
$safeName = preg_replace('/[^a-zA-Z0-9._-]/', '-', pathinfo($originalName, PATHINFO_FILENAME));
$safeName = trim((string) $safeName, '-_.') ?: 'upload';
$targetName = $safeName . '-' . bin2hex(random_bytes(6)) . '.' . ($webp !== null ? 'webp' : $extension);
$targetPath = UPLOADS_ROOT . '/' . $targetName;

// Erst als offen merken, dann ablegen: So liegt keine Datei, die die Liste nicht kennt. Beides unter der Sperre der Liste,
// sonst könnte ein Verwerfen den Eintrag dazwischen erledigen und die Datei danach unbekannt liegen bleiben.
$now = time();
$stored = false;
try {
    $stored = le_open_uploads_hold(static function () use ($targetName, $form, $now, $tmp, $targetPath, $webp): bool {
        le_open_upload_add($targetName, $form, (string) current_user()['id'], $now);
        if ($webp === null ? move_uploaded_file($tmp, $targetPath) : le_image_write_webp($targetPath, $webp)) {
            return true;
        }
        le_open_uploads_close(static fn (array $entry, string $file): bool => $file === $targetName);
        return false;
    });
} catch (Throwable $e) {
    error_log('open upload failed: ' . $e->getMessage());
}
if (!$stored) {
    json_response(['ok' => false, 'error' => UPLOAD_TEXT['store']], 500);
}
// Fallback für nie geschlossene Formulare; scheitert er, ist der Upload trotzdem da.
le_open_uploads_expire($now);
le_activity_log('upload', $targetName);

json_response(['ok' => true, 'url' => UPLOADS_URL . $targetName]);
