<?php
declare(strict_types=1);

// Sicherung für Admins über die Session (Einstellungen → Backup). Gleiches ZIP
// wie api/backup.php, zählt aber nicht als Abruf (last_pull bleibt). POST mit
// CSRF-Header: Die Oberfläche lädt per fetch und speichert den Blob.

require_once __DIR__ . '/../core/siteBackup.php';

require_admin();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

site_backup_require_ready();
// Das Packen kann dauern: andere Anfragen derselben Sitzung nicht blockieren.
session_write_close();
@set_time_limit(SITE_BACKUP_TIME_LIMIT);

try {
    $prepared = site_backup_prepare();
    site_backup_stream(site_backup_build_zip($prepared), $prepared['fingerprint']);
    le_activity_log('backup_downloaded');
} catch (Throwable $e) {
    json_response(['ok' => false, 'error' => site_backup_failure_message('downloadSiteBackup', $e)], 500);
}
