<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/dbMigration.php';
require_once __DIR__ . '/../core/system.php';

require_admin();

// Grund für einen gesperrten „Nach SQLite umziehen“-Knopf: Text der Systemprüfung.
$sqliteCheck = array_values(array_filter(system_checks(), static fn (array $check): bool => $check['key'] === 'pdo_sqlite'))[0];

json_response([
    'ok' => true,
    'driver' => db_driver(),
    'sqliteMissing' => $sqliteCheck['ok'] ? null : $sqliteCheck['purpose'],
    // Meldungstext statt true, damit die Oberfläche denselben Text zeigt wie die 503.
    'migrationRunning' => db_migration_running() ? DB_MIGRATION_RUNNING_MESSAGE : null,
    'archive' => db_archive_entries(),
    'dbArchiveReminder' => db_archive_reminder_for_current_user(),
]);
