<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/mail.php';

require_admin();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();

try {
    core_mail_save_config($body);
} catch (InvalidArgumentException $e) {
    // Prüfung der Eingaben: Texte aus MAIL_CONFIG_TEXT (core_mail_validate_config).
    json_response(['ok' => false, 'error' => $e->getMessage()], 400);
} catch (Throwable $e) {
    error_log('saveMailConfig: ' . $e->getMessage());
    json_response(['ok' => false, 'error' => API_TEXT['mailSaveFailed']], 500);
}
le_activity_log('mail_settings_saved');

json_response([
    'ok' => true,
    'config' => core_mail_public_config(),
    'status' => core_mail_status(),
]);
