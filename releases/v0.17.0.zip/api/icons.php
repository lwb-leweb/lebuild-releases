<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/icons.php';

// Icons für die Auswahl der Feldart „Icon“ im Seiten-Editor (nur lesen, nur angemeldet), dazu die
// Attribute, die ein Tausch am <svg> setzt (le_icon_replacements), damit die Vorschau gleich aussieht.
require_auth();

json_response(['ok' => true, 'icons' => le_icon_list(), 'attrs' => LE_ICON_SVG_ATTRS, 'defaults' => LE_ICON_SVG_DEFAULTS]);
