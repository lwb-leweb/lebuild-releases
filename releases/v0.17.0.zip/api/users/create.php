<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/users.php';

require_admin();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$username = trim((string) ($body['username'] ?? ''));
$password = (string) ($body['password'] ?? '');
$role = (string) ($body['role'] ?? '');

if ($error = users_validate_username($username)) {
    json_response(['ok' => false, 'error' => $error], 400);
}
if ($error = users_validate_password($password)) {
    json_response(['ok' => false, 'error' => $error], 400);
}
if ($error = users_validate_role($role)) {
    json_response(['ok' => false, 'error' => $error], 400);
}

$now = current_iso_time();
$user = [
    'id' => users_generate_id(),
    'username' => $username,
    'passwordHash' => password_hash($password, PASSWORD_BCRYPT),
    'role' => $role,
    'createdAt' => $now,
    'updatedAt' => $now,
];

// Unter der Sperre: Zwei gleichzeitige Anlagen desselben Namens ergeben keinen doppelten Benutzer.
users_update(static function (array &$store) use ($user): void {
    foreach ($store['users'] as $other) {
        if (strcasecmp($other['username'], $user['username']) === 0) {
            json_response(['ok' => false, 'error' => API_TEXT['usernameTaken']], 409);
        }
    }
    $store['users'][] = $user;
});
le_activity_log('user_created', $username);

json_response(['ok' => true, 'user' => users_public_view($user)]);
