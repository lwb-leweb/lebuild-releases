<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/users.php';

require_admin();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$id = trim((string) ($body['id'] ?? ''));
if ($id === '') {
    json_response(['ok' => false, 'error' => API_TEXT['userIdRequired']], 400);
}

$self = current_user();
if ($self !== null && $self['id'] === $id) {
    json_response(['ok' => false, 'error' => API_TEXT['deleteSelf']], 400);
}

$deleted = users_update(static function (array &$store) use ($id): string {
    $index = null;
    $target = null;
    foreach ($store['users'] as $i => $user) {
        if ($user['id'] === $id) {
            $index = $i;
            $target = $user;
            break;
        }
    }
    if ($index === null || $target === null) {
        json_response(['ok' => false, 'error' => API_TEXT['userNotFound']], 404);
    }

    if ($target['role'] === USER_ROLE_ADMIN && users_count_admins($id) === 0) {
        json_response(['ok' => false, 'error' => API_TEXT['lastAdminDelete']], 400);
    }

    array_splice($store['users'], $index, 1);
    return $target['username'];
});
le_activity_log('user_deleted', $deleted);

json_response(['ok' => true]);
