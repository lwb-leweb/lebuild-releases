<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/dbMigration.php';

require_admin();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
// force: nur die Zugangsdaten löschen, wenn die MySQL-Datenbank nicht erreichbar ist.
$result = db_archive_delete((string) ($body['name'] ?? ''), ($body['force'] ?? false) === true);
if (!$result['ok']) {
    json_response($result, DB_MIGRATION_ERROR_STATUS[$result['error']] ?? 500);
}
le_activity_log('db_archive_deleted', (string) ($body['name'] ?? ''));

json_response(['ok' => true, 'archive' => db_archive_entries(), 'dbArchiveReminder' => db_archive_reminder_for_current_user()]);
