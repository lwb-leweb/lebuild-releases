<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/fileStore.php';
require_once __DIR__ . '/../core/updater.php';

start_app_session();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

// Der Versuch zählt schon vor der Passwortprüfung (gleichzeitige Versuche umgehen die Sperre nicht).
if (!login_attempt_begin()) {
    json_response(['ok' => false, 'error' => LOGIN_THROTTLED_MESSAGE], LOGIN_THROTTLED_STATUS);
}

$body = read_json_body();
$username = sanitize_text_value($body['username'] ?? '');
$password = (string) ($body['password'] ?? '');

if (!login_user($username, $password)) {
    le_activity_log('login_failed', '', $username);
    json_response(['ok' => false, 'error' => API_TEXT['invalidCredentials']], 401);
}
login_attempt_forget();
le_activity_log('login');
// Ablage (Seiten, Backups, Uploads) gibt es ab der ersten Anmeldung, auch vor dem Import.
prepare_storage();

// Ein hier eingespieltes Update meldet danach das Backend bzw. der Seiten-Editor (Admins).
remember_update_notice(updater_auto_update('login')['installed']);

// Die Login-Seite braucht nur das: weiter zum Ziel oder erst ein neues Passwort (mit CSRF-Token).
json_response([
    'ok' => true,
    'csrfToken' => csrf_token(),
    'mustChangePassword' => must_change_password(),
]);
