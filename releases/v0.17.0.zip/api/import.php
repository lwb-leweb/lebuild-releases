<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/importer.php';

require_admin();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$force = !empty($body['force']);
$status = run_import($force);
if (empty($status['skipped'])) {
    le_activity_log($force ? 'markers_refreshed' : 'import');
}

json_response([
    'ok' => true,
    'status' => $status,
    'pages' => list_page_info(),
]);
