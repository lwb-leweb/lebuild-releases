<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/fileStore.php';
require_once __DIR__ . '/../core/plugins.php';
require_once __DIR__ . '/../core/dbMigration.php';
require_once __DIR__ . '/../core/siteBackup.php';
require_once __DIR__ . '/../core/system.php';
require_once __DIR__ . '/../core/updater.php';

start_app_session();

// Session ohne existierenden Benutzer (gelöscht) zählt als ausgeloggt.
$currentUser = session_user();
$authenticated = $currentUser !== null;

// Ein Update aus diesem Abruf oder, schon beim Login eingespielt, aus der Session (dann gilt er als gezeigt).
$update = $authenticated ? updater_auto_update('bootstrap') : ['status' => null, 'installed' => null];
$loginUpdate = $authenticated ? take_update_notice() : null;

json_response([
    'ok' => true,
    'authenticated' => $authenticated,
    'csrfToken' => $authenticated ? csrf_token() : '',
    'role' => $currentUser['role'] ?? null,
    'username' => $currentUser['username'] ?? null,
    'pages' => $authenticated ? list_page_info() : [],
    'importStatus' => $authenticated ? import_status() : null,
    'updateStatus' => $update['status'],
    'updateInstalled' => $update['installed'] ?? $loginUpdate,
    'activePlugins' => $authenticated ? active_plugin_admin_info() : [],
    'systemProblems' => system_problems_for_current_user(),
    'dbArchiveReminder' => db_archive_reminder_for_current_user(),
    'siteBackup' => site_backup_dashboard_for_current_user(),
    // Bild-Upload und Link-Regel im Formular der Plugin-Einträge (site-editor/entry-form.js, richtext.js).
    'upload' => upload_config(),
    'textMarkup' => text_markup_config(),
]);
