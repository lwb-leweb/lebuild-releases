<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/dbMigration.php';

require_admin();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$target = (string) ($body['target'] ?? '');
if ($target !== DB_DRIVER_SQLITE && $target !== DB_DRIVER_MYSQL) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidTarget']], 400);
}
$config = $target === DB_DRIVER_MYSQL ? db_config_from_body($body) : null;

// Die Session-Sperre würde die Admin-Oberfläche sonst für die Dauer des
// Umzugs blockieren; ein Abbruch der Verbindung soll den Lauf nicht zerreißen.
session_write_close();
ignore_user_abort(true);
@set_time_limit(0);

$result = $config === null ? db_migrate_to_sqlite() : db_migrate_to_mysql($config);
if ($result['ok']) {
    le_activity_log('db_migrated', $target);
}
json_response($result, $result['ok'] ? 200 : (DB_MIGRATION_ERROR_STATUS[$result['error']] ?? 500));
