<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/fileStore.php';
require_once __DIR__ . '/../core/importer.php';
require_once __DIR__ . '/../core/phpRewriter.php';
require_once __DIR__ . '/../core/uploads.php';

require_auth();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$page = safe_page_name((string) ($body['page'] ?? ''));
$content = $body['content'] ?? null;
// Stand beim Laden (getPage) für die Prüfung je Feld (merge_save_content); ohne ihn gilt der
// geschickte Inhalt ganz (Aufrufe ohne geladenen Stand).
$base = $body['base'] ?? null;

if (!is_array($content) || ($base !== null && !is_array($base))) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidContent']], 400);
}

// Ganz oder gar nicht: erst alle Ersetzungen (Komponenten und Seite) berechnen,
// dann JSON mit Backup und Seitendateien schreiben. Die Sperre hält über den ganzen Ablauf,
// damit gleichzeitige Saves keinen Stand verlieren und der Verlauf jeden Stand richtig zuordnet.
// Mit Stand beim Laden kommen alle Komponenten aus dem Stand jetzt dazu, also sind alle gesperrt.
// Direkt geänderte Dateien gleicht le_sync_request vorher ab (scheitert das für die Seite, 422 und nichts
// gespeichert): Ihr neuer Stand ist dann der Stand jetzt, ein direkt geändertes Feld, das auch der Editor
// geändert hat, wird Konflikt. refreshed in der Antwort: Ohne Konflikt lädt der Editor ohnehin neu, mit
// Konflikt rät die Meldung dazu.
[$locks, $sync] = le_sync_request([$page, ...array_keys($base === null ? array_intersect_key($content, shared_components()) : shared_components())]);
$refreshed = $sync['refreshed'] !== [];
// Von jemand anderem seit dem Laden geänderte Felder bleiben, wie sie sind, die übrigen Änderungen
// werden gespeichert (ganz oder gar nicht); ohne übrige Änderung wird nichts geschrieben.
$conflicts = [];
if ($base !== null) {
    $editor = page_editor_content($page);
    ['content' => $content, 'saved' => $saved, 'conflicts' => $conflictIds] = merge_save_content($editor['content'], $content, $base);
    $conflicts = save_conflict_fields($conflictIds, $editor['docs']);
    if ($conflicts !== [] && $saved === []) {
        json_response(['ok' => false, 'error' => save_conflict_message($conflicts, false), 'fields' => $conflicts, 'refreshed' => $refreshed], 409);
    }
}
// Komponente, deren Abgleich gescheitert ist: Würde ihr Plan ihren gespeicherten Stand ändern, 422 (die Meldung
// nennt sie), sonst bleibt sie, wie sie ist (ihr altes JSON bekäme sonst den Hash der direkten Änderung). Nach dem
// Plan, nicht nach dem Präfix der ID: Seitenfelder mit Komponenten-Präfix (ältere Importe) gehören der Seite.
$plans = split_page_content($page, $content);
$touched = array_filter($sync['failed'], static fn (string $name): bool => isset($plans[$name])
    && array_diff_assoc(flatten_content($plans[$name]), flatten_content(load_component_content($name) ?? [])) !== [], ARRAY_FILTER_USE_KEY);
if ($touched !== []) {
    le_sync_failed($touched);
}
$plans = array_diff_key($plans, $sync['failed']);

// Vom Prüfen der Bilder bis zum Schreiben nacheinander mit dem Erledigen offener Uploads (le_open_uploads_hold):
// Kein neues Bild verschwindet mitten im Speichern, ein schon gelöschtes lehnt das Speichern ab.
le_open_uploads_hold(static function () use ($page, $plans): void {
    $errors = [];
    foreach ($plans as $name => $planContent) {
        $plans[$name] = ['content' => $planContent] + plan_source_rewrite($name, $planContent, true);
        $errors = array_merge($errors, $plans[$name]['errors']);
    }
    if ($errors !== []) {
        json_response(['ok' => false, 'error' => rewrite_error_message($errors), 'fields' => $errors], 422);
    }

    write_page_plans($page, $plans);
});
// Bei Konflikten lädt der Editor nicht neu: Er bekommt die gespeicherten Werte so, wie getPage sie
// liefert, als neuen Stand beim Laden.
$response = ['ok' => true, 'page' => $page, 'updatedAt' => page_updated_at($page), 'conflicts' => $conflicts, 'refreshed' => $refreshed];
if ($conflicts !== []) {
    $stored = flatten_content(page_editor_content($page)['content']);
    $response['message'] = save_conflict_message($conflicts, true);
    $response['saved'] = array_intersect_key($stored, array_flip($saved));
}
unlock_pages($locks);
// Nach den Einträgen des Abgleichs (le_log_after_unlock), der dieses Speichern ausgelöst hat.
le_log_after_unlock([$page => 'page_saved'], $locks, null);

json_response($response);
