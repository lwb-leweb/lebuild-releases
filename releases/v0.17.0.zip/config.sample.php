<?php
// Zugang des ersten Admins. Vor dem Hochladen nach config.php kopieren und ausfüllen.
// Beim ersten Login legt der Editor daraus den Admin an und leert das Passwort hier.
// Sobald es Benutzer gibt (content/users.json), gilt diese Datei nicht mehr.
return [
    // 3 bis 64 Zeichen: Buchstaben, Ziffern, Punkt, Unterstrich, Bindestrich.
    'username' => '',
    // Mindestens 8 Zeichen.
    'password' => '',
];
