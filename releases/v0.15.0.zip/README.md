# Live Editor

Kleines PHP/Vanilla-JS-Tool, um statische HTML-Seiten nach einem Import ohne Datenbank über JSON zu bearbeiten.

## Start

Mit einem lokalen PHP-Server (`index.php` ist der universelle Front-Controller — gleicher Code für Dev und Produktion):

```bash
php -S 127.0.0.1:8000 index.php
```

Dann im Browser öffnen:

- Login: `http://127.0.0.1:8000/login`
- Website (angemeldet mit Editor-Leiste): `http://127.0.0.1:8000/`
- Verwaltung (nur Admins): `http://127.0.0.1:8000/admin`

## Login & Benutzer

Angemeldet wird unter `/login`. Danach zeigt jede Seite der Website unten die Editor-Leiste (Name, Verwaltung für Admins, Abmelden); Texte, Bilder und Links werden direkt auf der Seite angeklickt und bearbeitet. Besucher sehen nichts davon und bekommen kein Cookie. Der Editor nutzt das Session-Cookie `le_session` und lässt eine PHP-Session der Website (Formulare, Mitgliederbereich) unberührt.

Beim ersten Login wird automatisch ein Admin-User in `content/users.json` angelegt:

- Benutzer: `admin`
- Passwort: `admin`

Wer sich so anmeldet, muss sofort ein eigenes Passwort festlegen; vorher ist nichts anderes erreichbar. Nach 10 Fehlversuchen sperrt der Login eine IP für 15 Minuten.

Diese Defaults sind per Env-Variable überschreibbar (Bootstrap nur beim Erst-Setup):

- `LIVE_EDITOR_USER`
- `LIVE_EDITOR_PASSWORD`

Sobald mindestens ein Admin in `content/users.json` existiert, werden die Env-Vars ignoriert — alle weiteren Benutzer werden über das Admin-UI verwaltet (**Benutzer**-Eintrag in der Sidebar).

### Rollen

- **admin** — kann alles: Inhalte bearbeiten, Einstellungen, SMTP, Updates, Plugins, Benutzer anlegen / Rollen ändern / löschen, Verwaltung unter `/admin`.
- **editor** — sieht nur die Website mit Leiste (`/admin` führt zurück auf die Website): bearbeitet Seiten und Plugin-Listen, nutzt Upload, sieht den Verlauf einer Seite und stellt frühere Stände wieder her. Settings, Plugin-Verwaltung, „Markierungen aktualisieren“, Benutzer und Update-Install sind über die API nicht erreichbar (403).

Passwörter werden als bcrypt-Hashes in `content/users.json` gespeichert. Diese Datei ist `.gitignore`d und durch `content/.htaccess` (Apache) sowie den Dev-Router gegen direkten HTTP-Zugriff geschützt.

## Voraussetzungen

PHP 8.0 oder neuer mit `pdo_sqlite`, `sodium`, `zip` und `curl`; Schreibrechte auf `content/`, `public/site/` und `public/uploads/`. Einstellungen → System und das Dashboard zeigen, was fehlt.

**Nginx:** neben `try_files $uri /index.php?$query_string;` zwingend

```
location ~ ^/(content|core|tests|tools)/ { deny all; }
```

sonst liefert Nginx vorhandene Dateien (z. B. `content/users.json`) direkt aus. Zusätzlich `/public/admin/` und `/public/admin/index.html` an `index.php` geben, sonst kommt die Verwaltungs-Shell ohne Rollenprüfung (die APIs bleiben geschützt).

## Ablauf

1. Die Beispielseite in `public/site/` ganz löschen und die statischen HTML-Dateien des Kunden dorthin legen
2. Unter `/login` anmelden, im Admin (`/admin`) den Import starten
3. Inhalte direkt auf der Website ändern, „Speichern“ übernimmt alle Änderungen auf einmal
4. Änderungen landen in der Seitendatei und in `content/cache/pages/*.json`; „Verlauf“ in der Leiste zeigt frühere Stände und stellt sie wieder her

## Speicherorte

- Seiteninhalt (JSON-Spiegel): `content/cache/pages/`
- Backups samt Kurzinfo für den Verlauf: `content/cache/backups/`
- Originale: `content/cache/originals/`
- Benutzer (bcrypt-Hashes, nicht im Git): `content/users.json`
- Uploads: `public/uploads/`
- Zugangsdaten (0600): `content/config/db.config.php`, `content/config/mail.config.php`
- Plugin-Daten (SQLite): `content/data/site.sqlite`

## Datenbank

Plugin-Daten liegen standardmäßig in SQLite. Admin → Einstellungen → Datenbank richtet MySQL/MariaDB ein und zieht die Daten in beide Richtungen um; Altdaten bleiben im Archiv, nach 30 Tagen erinnert das Dashboard ans Löschen.

## Hinweise

- Keine Datenbank für den Editor selbst; Plugins mit Daten nutzen SQLite (`content/data/site.sqlite`), MySQL nur auf Wunsch
- Kein Node.js
- Der Import schreibt `data-edit-id`-Marker byte-genau in die Seitendateien; Speichern ersetzt nur das bearbeitete Feld
- Bestehende Seiten stellt der Admin-Button „Markierungen aktualisieren“ auf neue Markierungen um (IDs und Inhalte bleiben); dabei werden auch Seitentitel und Meta-Beschreibung bearbeitbar
- Speichert jemand anderes dasselbe Feld, bleibt dessen Stand erhalten: Der Editor meldet das Feld, speichert den Rest und behält die eigene Änderung in der Liste
- Eine schreibgeschützte Seitendatei wird nicht ersetzt; Speichern meldet das, statt etwas halb zu schreiben
- Aufbau des Seiten-Editors, Design System und Bausteine: [knowledgebase/seiten-editor.md](knowledgebase/seiten-editor.md)

## Tests

```bash
php tests/run.php
```

Braucht PHP mit `curl`, `pdo_sqlite`, `sodium` und `zip`. Die Tests arbeiten in einer Wegwerf-Kopie unter dem Temp-Verzeichnis. MySQL-Tests laufen nur mit `TEST_MYSQL_DSN` (DSN einer leeren Wegwerf-Datenbank), `TEST_MYSQL_USER`, `TEST_MYSQL_PASS`, sonst werden sie übersprungen.

## Mail / SMTP

Der Core kann E-Mails zentral versenden:

- SMTP-Konfiguration: Admin → Einstellungen → E-Mail / SMTP
- Geschützte Runtime-Datei: `content/config/mail.config.php`
- Fallback ohne SMTP: PHP `mail()`, sofern auf dem Hosting verfügbar

Mail-Plugins wie `contact-form` rufen nur den Core-Mailer auf und kennen keine SMTP-Zugangsdaten.

## Auto-Update

Kunden-Installationen aktualisieren sich automatisch über signierte Releases im öffentlichen Repo `lwb-leweb/website-live-editor-releases`. Release-Workflow für Maintainer und Update-Verhalten beim Kunden: siehe [knowledgebase/release.md](knowledgebase/release.md).
