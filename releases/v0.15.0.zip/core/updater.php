<?php
declare(strict_types=1);

require_once __DIR__ . '/utils.php';

// Releases liegen öffentlich und signiert in einem eigenen Repo. Der Updater
// braucht deshalb keinen GitHub-Token; die Ed25519-Signatur beweist, dass
// das ZIP aus unserem Release-Workflow stammt.
const UPDATER_FEED_URL = 'https://raw.githubusercontent.com/lwb-leweb/website-live-editor-releases/main/latest.json';
const UPDATER_PUBLIC_KEY = 'fEx6rd4u89/GtfQ8a5x4X2kUab1+n7oS/NzWKsEupPo=';
const UPDATER_CHECK_INTERVAL_SECONDS = 12 * 60 * 60;
const UPDATER_USER_AGENT = 'live-editor-updater';
// So weit zurück (Bytes vom Ende) prüft updater_log_once() auf Wiederholungen.
const UPDATER_LOG_REPEAT_WINDOW_BYTES = 4096;
const UPDATER_ALLOWED_MANAGED_PATHS = [
    'api',
    'core',
    'public/admin',
    'plugins',
    'index.php',
    '.htaccess',
];
// Alte Orte der Zugangsdaten. Seit dem Umzug nach content/config/ (siehe
// updater_config_path()) nur noch für Installationen, die noch nicht
// umgezogen sind; entfällt in einem späteren Release.
const UPDATER_PROTECTED_RELATIVE_PATHS = [
    'core/db.config.php',
    'core/mail.config.php',
];

function updater_feed_url(): string
{
    $env = getenv('LIVE_EDITOR_UPDATE_FEED');
    return is_string($env) && $env !== '' ? $env : UPDATER_FEED_URL;
}

function updater_manifest_path(): string
{
    return PROJECT_ROOT . '/core/release.json';
}

function updater_cache_path(): string
{
    return CACHE_ROOT . '/update-cache.json';
}

function updater_backup_root(): string
{
    return CACHE_ROOT . '/update-backup';
}

function updater_tmp_root(): string
{
    return CACHE_ROOT . '/update-tmp';
}

function updater_lock_path(): string
{
    return CACHE_ROOT . '/update-lock';
}

function updater_log_path(): string
{
    return CACHE_ROOT . '/update-log.txt';
}

function updater_log(string $message): void
{
    @file_put_contents(
        updater_log_path(),
        '[' . current_iso_time() . '] ' . $message . PHP_EOL,
        FILE_APPEND
    );
}

/**
 * Wie updater_log(), aber ohne Wiederholung: Steht dieselbe Meldung schon im
 * Ende des Logs, entfällt sie. Für Fehler, die sonst jeder Request meldet.
 */
function updater_log_once(string $message): void
{
    $path = updater_log_path();
    $size = is_file($path) ? (int) filesize($path) : 0;
    $offset = max(0, $size - UPDATER_LOG_REPEAT_WINDOW_BYTES);
    $tail = $size > 0 ? (string) @file_get_contents($path, false, null, $offset) : '';
    if (!str_contains($tail, '] ' . $message . PHP_EOL)) {
        updater_log($message);
    }
}

function updater_config_lock_path(): string
{
    return CACHE_ROOT . '/config-move.lock';
}

/**
 * Pfad einer Zugangsdaten-Datei unter content/config/. Liegt sie noch am alten
 * Ort unter core/, wird sie einmal je Request umgezogen: kopieren, Kopie
 * prüfen, erst dann das Original löschen. Liegt sie an beiden Orten, gilt
 * content/config/. Scheitert der Umzug, bleibt das Original und wird genutzt.
 * Der Umzug läuft unter einer Sperre, damit parallele Requests sich nicht
 * gegenseitig die Kopie oder das Original wegnehmen.
 */
function updater_config_path(string $file): string
{
    static $resolved = [];
    if (isset($resolved[$file])) {
        return $resolved[$file];
    }

    $target = CONFIG_ROOT . '/' . $file;
    $legacy = null;
    foreach (UPDATER_PROTECTED_RELATIVE_PATHS as $relative) {
        if (basename($relative) === $file) {
            $legacy = $relative;
        }
    }
    $legacyPath = PROJECT_ROOT . '/' . ($legacy ?? '');
    if ($legacy === null || (!is_file($legacyPath) && !is_link($legacyPath))) {
        return $resolved[$file] = $target;
    }
    // Ein Symlink zeigt meist bewusst aus dem Webroot heraus: nicht umziehen.
    if (is_link($legacyPath)) {
        updater_log_once('config move skipped: ' . $legacy . ' is a symlink');
        return $resolved[$file] = $legacyPath;
    }

    $lock = null;
    try {
        $lock = updater_acquire_lock(updater_config_lock_path(), true);
        if (!$lock) {
            throw new RuntimeException('cannot lock');
        }
        // Ein paralleler Request kann inzwischen umgezogen haben.
        if (!is_file($legacyPath)) {
            return $resolved[$file] = $target;
        }
        $content = @file_get_contents($legacyPath);
        if ($content === false) {
            throw new RuntimeException('cannot read original');
        }

        if (is_file($target)) {
            if (!is_readable($target)) {
                throw new RuntimeException('content/config/' . $file . ' not readable');
            }
            if (file_get_contents($target) !== $content) {
                updater_log('config move: ' . $legacy . ' differs from content/config/, content/config/ wins');
            }
        } else {
            try {
                write_private_file($target, $content);
                if (file_get_contents($target) !== $content || !is_array(require $target)) {
                    throw new RuntimeException('copy differs or is no config array');
                }
            } catch (Throwable $e) {
                // Eigene, fehlerhafte Kopie entfernen: Sie darf beim nächsten
                // Request nicht als „an beiden Orten“ gewinnen.
                @unlink($target);
                throw $e;
            }
        }

        if (!@unlink($legacyPath) && is_file($legacyPath)) {
            updater_log_once('config move: could not delete ' . $legacy);
        }
        return $resolved[$file] = $target;
    } catch (Throwable $e) {
        updater_log_once('config move failed: ' . $legacy . ': ' . $e->getMessage());
        return $resolved[$file] = $legacyPath;
    } finally {
        updater_release_lock($lock);
    }
}

function updater_enabled(): bool
{
    $flag = getenv('LIVE_EDITOR_UPDATES');
    if ($flag === false || $flag === '') {
        return true;
    }
    return !in_array(strtolower($flag), ['off', '0', 'false', 'no'], true);
}

function updater_read_local_manifest(): array
{
    $path = updater_manifest_path();
    if (!is_file($path)) {
        return [
            'version' => '0.0.0',
            'requiresConfirmation' => false,
            'notes' => '',
            'managedPaths' => UPDATER_ALLOWED_MANAGED_PATHS,
        ];
    }
    $data = json_decode((string) file_get_contents($path), true);
    if (!is_array($data)) {
        return [
            'version' => '0.0.0',
            'requiresConfirmation' => false,
            'notes' => '',
            'managedPaths' => UPDATER_ALLOWED_MANAGED_PATHS,
        ];
    }
    return [
        'version' => (string) ($data['version'] ?? '0.0.0'),
        'requiresConfirmation' => !empty($data['requiresConfirmation']),
        'notes' => (string) ($data['notes'] ?? ''),
        'managedPaths' => is_array($data['managedPaths'] ?? null) ? $data['managedPaths'] : UPDATER_ALLOWED_MANAGED_PATHS,
    ];
}

function updater_load_cache(): array
{
    $defaults = [
        'lastCheck' => null,
        'latestVersion' => null,
        'requiresConfirmation' => false,
        'notes' => '',
        'zipUrl' => '',
        'signature' => '',
        'tag' => '',
        'lastError' => null,
        'skippedVersion' => null,
    ];
    $path = updater_cache_path();
    $data = is_file($path) ? json_decode((string) file_get_contents($path), true) : null;

    return is_array($data) ? array_merge($defaults, $data) : $defaults;
}

function updater_save_cache(array $cache): void
{
    ensure_dir(CACHE_ROOT);
    @file_put_contents(
        updater_cache_path(),
        json_encode($cache, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . PHP_EOL,
        LOCK_EX
    );
}

function updater_http_get(string $url, int $timeout = 15, array $extraHeaders = []): ?string
{
    $headers = ['Accept: application/json'];
    foreach ($extraHeaders as $h) {
        if (is_string($h) && $h !== '') {
            $headers[] = $h;
        }
    }

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_USERAGENT => UPDATER_USER_AGENT,
            CURLOPT_HTTPHEADER => $headers,
        ]);
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($body === false || $code < 200 || $code >= 300) {
            return null;
        }
        return (string) $body;
    }

    $headerLines = "User-Agent: " . UPDATER_USER_AGENT . "\r\n";
    foreach ($headers as $h) {
        $headerLines .= $h . "\r\n";
    }
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => $headerLines,
            'timeout' => $timeout,
            'follow_location' => 1,
        ],
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
        ],
    ]);
    $body = @file_get_contents($url, false, $context);
    return $body === false ? null : $body;
}

function updater_http_download(string $url, string $destPath, int $timeout = 60): bool
{
    ensure_dir(dirname($destPath));

    if (function_exists('curl_init')) {
        $fh = @fopen($destPath, 'wb');
        if (!$fh) {
            return false;
        }
        $opts = [
            CURLOPT_FILE => $fh,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_USERAGENT => UPDATER_USER_AGENT,
        ];
        $ch = curl_init($url);
        curl_setopt_array($ch, $opts);
        $ok = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        fclose($fh);
        if (!$ok || $code < 200 || $code >= 300) {
            @unlink($destPath);
            return false;
        }
        return true;
    }

    $body = updater_http_get($url, $timeout);
    if ($body === null) {
        return false;
    }
    return @file_put_contents($destPath, $body) !== false;
}

function updater_fetch_remote(): ?array
{
    $body = updater_http_get(updater_feed_url());
    $feed = $body !== null ? json_decode($body, true) : null;
    if (!is_array($feed) || empty($feed['version']) || empty($feed['zipUrl']) || empty($feed['signature'])) {
        return null;
    }

    return [
        'tag' => (string) ($feed['tag'] ?? ('v' . $feed['version'])),
        'version' => (string) $feed['version'],
        'requiresConfirmation' => !empty($feed['requiresConfirmation']),
        'notes' => (string) ($feed['notes'] ?? ''),
        'zipUrl' => (string) $feed['zipUrl'],
        'signature' => (string) $feed['signature'],
    ];
}

function updater_signature_valid(string $zipPath, string $signature): bool
{
    if (!function_exists('sodium_crypto_sign_verify_detached')) {
        return false;
    }
    $sig = base64_decode($signature, true);
    $key = base64_decode(UPDATER_PUBLIC_KEY, true);
    $data = @file_get_contents($zipPath);
    if ($sig === false || $key === false || $data === false
        || strlen($sig) !== SODIUM_CRYPTO_SIGN_BYTES || strlen($key) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) {
        return false;
    }

    return sodium_crypto_sign_verify_detached($sig, $data, $key);
}

function updater_status(): array
{
    $local = updater_read_local_manifest();
    $cache = updater_load_cache();
    $latest = $cache['latestVersion'];
    $hasUpdate = $latest !== null && version_compare($latest, $local['version'], '>');

    return [
        'enabled' => updater_enabled(),
        'currentVersion' => $local['version'],
        'latestVersion' => $latest,
        'tag' => $cache['tag'] ?? '',
        'hasUpdate' => $hasUpdate,
        'requiresConfirmation' => !empty($cache['requiresConfirmation']),
        'notes' => $cache['notes'] ?? '',
        'lastCheck' => $cache['lastCheck'] ?? null,
        'lastError' => $cache['lastError'] ?? null,
        'skippedVersion' => $cache['skippedVersion'] ?? null,
        'rollbackAvailable' => is_dir(updater_backup_root()),
    ];
}

function updater_check(bool $force = false): array
{
    if (!updater_enabled()) {
        return updater_status();
    }

    $cache = updater_load_cache();
    $now = time();
    $last = $cache['lastCheck'] ? strtotime((string) $cache['lastCheck']) : 0;
    if (!$force && $last && ($now - $last) < UPDATER_CHECK_INTERVAL_SECONDS) {
        return updater_status();
    }

    $remote = updater_fetch_remote();
    if ($remote === null) {
        $cache['lastCheck'] = current_iso_time();
        $cache['lastError'] = 'Konnte Update-Quelle nicht erreichen.';
        updater_save_cache($cache);
        updater_log('check failed: remote unreachable');
        return updater_status();
    }

    $cache = array_merge($cache, [
        'lastCheck' => current_iso_time(),
        'latestVersion' => $remote['version'],
        'requiresConfirmation' => $remote['requiresConfirmation'],
        'notes' => $remote['notes'],
        'zipUrl' => $remote['zipUrl'],
        'signature' => $remote['signature'],
        'tag' => $remote['tag'],
        'lastError' => null,
    ]);
    updater_save_cache($cache);
    updater_log(sprintf('check ok: latest=%s tag=%s confirm=%s', $remote['version'], $remote['tag'], $remote['requiresConfirmation'] ? 'yes' : 'no'));

    return updater_status();
}

function updater_should_auto_install(): bool
{
    if (!updater_enabled()) {
        return false;
    }
    $cache = updater_load_cache();
    $local = updater_read_local_manifest();
    if (empty($cache['latestVersion'])) {
        return false;
    }
    if (!empty($cache['requiresConfirmation'])) {
        return false;
    }
    // Nach einem Rollback diese Version nicht gleich wieder automatisch
    // einspielen; manuell installieren geht weiterhin.
    if (($cache['skippedVersion'] ?? null) === $cache['latestVersion']) {
        return false;
    }
    return version_compare((string) $cache['latestVersion'], $local['version'], '>');
}

/**
 * Beim Login und beim Laden des Backends (api/login.php, api/bootstrap.php): nach Updates sehen
 * und, wo es ohne Bestätigung geht, gleich einspielen. Liefert ['status' => updater_status()
 * oder null, 'installed' => ['previousVersion', 'newVersion'] oder null]; Fehler nur ins Log
 * ($context nennt den Aufrufer).
 */
function updater_auto_update(string $context): array
{
    $flow = ['status' => null, 'installed' => null];
    try {
        updater_check(false);
        if (updater_should_auto_install()) {
            $result = updater_install();
            if (!empty($result['ok'])) {
                $flow['installed'] = [
                    'previousVersion' => $result['previousVersion'] ?? null,
                    'newVersion' => $result['newVersion'] ?? null,
                ];
            }
        }
        $flow['status'] = updater_status();
    } catch (Throwable $e) {
        updater_log($context . ' update flow failed: ' . $e->getMessage());
    }
    return $flow;
}

function updater_acquire_lock(?string $path = null, bool $wait = false)
{
    ensure_dir(CACHE_ROOT);
    // c+: der Datenumzug liest seine Notiz aus der gehaltenen Sperrdatei.
    $fh = @fopen($path ?? updater_lock_path(), 'c+');
    if (!$fh) {
        return null;
    }
    if (!flock($fh, $wait ? LOCK_EX : LOCK_EX | LOCK_NB)) {
        fclose($fh);
        return null;
    }
    return $fh;
}

// Nur die Update-Sperre wird danach gelöscht. Andere Sperrdateien (Config-,
// Datenumzug) bleiben: An ihnen warten andere Requests bzw. sie tragen Notizen.
function updater_release_lock($fh): void
{
    if (!$fh) {
        return;
    }
    $isUpdateLock = stream_get_meta_data($fh)['uri'] === updater_lock_path();
    flock($fh, LOCK_UN);
    fclose($fh);
    if ($isUpdateLock) {
        @unlink(updater_lock_path());
    }
}

function updater_filtered_managed_paths(array $requested): array
{
    $allowed = [];
    foreach ($requested as $path) {
        if (!is_string($path) || $path === '') {
            continue;
        }
        $normalized = str_replace('\\', '/', $path);
        $normalized = trim($normalized, '/');
        if ($normalized === '' || strpos($normalized, '..') !== false) {
            continue;
        }
        if (in_array($normalized, UPDATER_ALLOWED_MANAGED_PATHS, true)) {
            $allowed[] = $normalized;
        }
    }
    return $allowed;
}

function updater_restore_protected_paths(string $backupRoot): void
{
    foreach (UPDATER_PROTECTED_RELATIVE_PATHS as $relative) {
        $backup = $backupRoot . '/' . $relative;
        if (!is_file($backup)) {
            continue;
        }

        $target = PROJECT_ROOT . '/' . $relative;
        ensure_dir(dirname($target));
        if (is_file($target) && !@unlink($target)) {
            updater_log('could not replace protected path: ' . $relative);
            continue;
        }
        if (!@copy($backup, $target)) {
            updater_log('could not restore protected path: ' . $relative);
        }
    }
}

function updater_rrmdir(string $path): bool
{
    if (is_link($path) || is_file($path)) {
        return @unlink($path);
    }
    if (!is_dir($path)) {
        return true;
    }
    $entries = scandir($path) ?: [];
    foreach ($entries as $entry) {
        if ($entry === '.' || $entry === '..') {
            continue;
        }
        updater_rrmdir($path . '/' . $entry);
    }
    return @rmdir($path);
}

function updater_find_extracted_root(string $extractDir): ?string
{
    $entries = array_values(array_filter(scandir($extractDir) ?: [], static fn ($e) => $e !== '.' && $e !== '..'));
    if (count($entries) === 1 && is_dir($extractDir . '/' . $entries[0])) {
        return $extractDir . '/' . $entries[0];
    }
    return $extractDir;
}

function updater_install(): array
{
    if (!updater_enabled()) {
        return ['ok' => false, 'error' => 'Updater deaktiviert.'];
    }
    if (!class_exists('ZipArchive')) {
        return ['ok' => false, 'error' => 'PHP ZipArchive-Erweiterung fehlt.'];
    }

    $cache = updater_load_cache();
    if (empty($cache['zipUrl']) || empty($cache['latestVersion'])) {
        return ['ok' => false, 'error' => 'Kein Update verfügbar (zuerst prüfen).'];
    }
    $local = updater_read_local_manifest();
    if (version_compare((string) $cache['latestVersion'], $local['version'], '<=')) {
        return ['ok' => false, 'error' => 'Bereits aktuell.'];
    }

    if (empty($cache['signature'])) {
        return ['ok' => false, 'error' => 'Update ist nicht signiert (zuerst prüfen).'];
    }
    if (!function_exists('sodium_crypto_sign_verify_detached')) {
        return ['ok' => false, 'error' => 'PHP sodium-Erweiterung fehlt.'];
    }

    $lock = updater_acquire_lock();
    if (!$lock) {
        return ['ok' => false, 'error' => 'Update läuft bereits.'];
    }

    // Läuft im Login-Request: nicht vom Zeitlimit oder einem geschlossenen
    // Browser-Tab mitten im Austausch abbrechen lassen.
    ignore_user_abort(true);
    @set_time_limit(300);

    try {
        $tmpRoot = updater_tmp_root();
        updater_rrmdir($tmpRoot);
        ensure_dir($tmpRoot);

        $zipPath = $tmpRoot . '/release.zip';
        if (!updater_http_download($cache['zipUrl'], $zipPath, 120)) {
            return ['ok' => false, 'error' => 'Download fehlgeschlagen.'];
        }
        if (!updater_signature_valid($zipPath, (string) $cache['signature'])) {
            updater_log('install refused: invalid signature for ' . $cache['latestVersion']);
            return ['ok' => false, 'error' => 'Signatur des Updates ungültig.'];
        }

        $extractDir = $tmpRoot . '/extracted';
        ensure_dir($extractDir);

        $zip = new ZipArchive();
        if ($zip->open($zipPath) !== true) {
            return ['ok' => false, 'error' => 'ZIP konnte nicht geöffnet werden.'];
        }

        for ($i = 0; $i < $zip->numFiles; $i++) {
            $entryName = $zip->getNameIndex($i);
            if (!is_string($entryName) || !zip_entry_name_safe($entryName)) {
                $zip->close();
                return ['ok' => false, 'error' => 'ZIP enthält ungültige Pfade.'];
            }
        }

        if (!$zip->extractTo($extractDir)) {
            $zip->close();
            return ['ok' => false, 'error' => 'ZIP konnte nicht entpackt werden.'];
        }
        $zip->close();

        $sourceRoot = updater_find_extracted_root($extractDir);
        if (!$sourceRoot || !is_dir($sourceRoot)) {
            return ['ok' => false, 'error' => 'Entpacktes Archiv ungültig.'];
        }

        $remoteManifestPath = $sourceRoot . '/core/release.json';
        if (!is_file($remoteManifestPath)) {
            return ['ok' => false, 'error' => 'Release-Manifest fehlt im Archiv.'];
        }
        $remoteManifest = json_decode((string) file_get_contents($remoteManifestPath), true);
        if (!is_array($remoteManifest) || empty($remoteManifest['version'])) {
            return ['ok' => false, 'error' => 'Release-Manifest unleserlich.'];
        }

        $managedRequested = is_array($remoteManifest['managedPaths'] ?? null)
            ? $remoteManifest['managedPaths']
            : UPDATER_ALLOWED_MANAGED_PATHS;
        $managedPaths = updater_filtered_managed_paths($managedRequested);
        if (empty($managedPaths)) {
            return ['ok' => false, 'error' => 'Keine erlaubten Pfade im Manifest.'];
        }

        $backupRoot = updater_backup_root();
        updater_rrmdir($backupRoot);
        ensure_dir($backupRoot);

        $swap = updater_swap_paths($sourceRoot, $managedPaths, $backupRoot);
        if (!$swap['ok']) {
            return ['ok' => false, 'error' => $swap['error']];
        }
        $swappedPaths = $swap['swapped'];

        updater_restore_protected_paths($backupRoot);
        updater_forget_compiled($swappedPaths);

        $cache['lastError'] = null;
        $cache['skippedVersion'] = null;
        $cache['lastCheck'] = current_iso_time();
        updater_save_cache($cache);

        updater_rrmdir($tmpRoot);

        updater_log(sprintf(
            'installed %s -> %s (paths: %s)',
            $local['version'],
            (string) $remoteManifest['version'],
            implode(',', $swappedPaths)
        ));

        return [
            'ok' => true,
            'previousVersion' => $local['version'],
            'newVersion' => (string) $remoteManifest['version'],
            'swappedPaths' => $swappedPaths,
        ];
    } finally {
        updater_release_lock($lock);
    }
}

/**
 * Tauscht die verwalteten Pfade gegen die aus dem Release. Scheitert ein
 * Schritt, wird alles bisher Getauschte zurückgelegt.
 */
function updater_swap_paths(string $sourceRoot, array $managedPaths, string $backupRoot): array
{
    $swappedPaths = [];
    foreach ($managedPaths as $relative) {
        $source = $sourceRoot . '/' . $relative;
        $target = PROJECT_ROOT . '/' . $relative;
        if (!file_exists($source)) {
            continue;
        }

        if (file_exists($target)) {
            $backup = $backupRoot . '/' . $relative;
            ensure_dir(dirname($backup));
            if (!@rename($target, $backup)) {
                updater_rollback_internal($swappedPaths, $backupRoot);
                return ['ok' => false, 'error' => 'Backup für ' . $relative . ' fehlgeschlagen.'];
            }
        }
        // Ab hier gilt der Pfad als angefasst: scheitert der Tausch, muss
        // der Rollback auch dieses Backup zurücklegen.
        $swappedPaths[] = $relative;

        ensure_dir(dirname($target));
        if (!@rename($source, $target)) {
            updater_rollback_internal($swappedPaths, $backupRoot);
            return ['ok' => false, 'error' => 'Tausch für ' . $relative . ' fehlgeschlagen.'];
        }
    }

    return ['ok' => true, 'swapped' => $swappedPaths];
}

function updater_rollback_internal(array $swappedPaths, string $backupRoot): void
{
    foreach (array_reverse($swappedPaths) as $relative) {
        $target = PROJECT_ROOT . '/' . $relative;
        $backup = $backupRoot . '/' . $relative;
        if (file_exists($target)) {
            updater_rrmdir($target);
        }
        if (file_exists($backup)) {
            @rename($backup, $target);
        }
    }
    updater_forget_compiled($swappedPaths);
}

/**
 * Nach dem Tausch von Code (Update, Rollback): OPcache vergisst die PHP-Dateien der verwalteten
 * Pfade, sonst liefe bei opcache.validate_timestamps=0 der alte Code weiter (forget_compiled_tree).
 */
function updater_forget_compiled(array $relatives): void
{
    foreach ($relatives as $relative) {
        forget_compiled_tree(PROJECT_ROOT . '/' . $relative);
    }
}

function updater_rollback(): array
{
    $backupRoot = updater_backup_root();
    if (!is_dir($backupRoot)) {
        return ['ok' => false, 'error' => 'Kein Backup verfügbar.'];
    }

    $lock = updater_acquire_lock();
    if (!$lock) {
        return ['ok' => false, 'error' => 'Update läuft gerade.'];
    }

    try {
        // Seit dem Update geänderte Zugangsdaten nicht mit den alten überschreiben.
        $keepRoot = updater_tmp_root() . '/keep-config';
        updater_rrmdir($keepRoot);
        foreach (UPDATER_PROTECTED_RELATIVE_PATHS as $relative) {
            if (is_file(PROJECT_ROOT . '/' . $relative)) {
                ensure_dir(dirname($keepRoot . '/' . $relative));
                @copy(PROJECT_ROOT . '/' . $relative, $keepRoot . '/' . $relative);
            }
        }

        $rolledBackFrom = updater_read_local_manifest()['version'];
        foreach (UPDATER_ALLOWED_MANAGED_PATHS as $relative) {
            $backupPath = $backupRoot . '/' . $relative;
            if (!file_exists($backupPath)) {
                continue;
            }
            $target = PROJECT_ROOT . '/' . $relative;
            if (file_exists($target)) {
                updater_rrmdir($target);
            }
            ensure_dir(dirname($target));
            if (!@rename($backupPath, $target)) {
                return ['ok' => false, 'error' => 'Rollback für ' . $relative . ' fehlgeschlagen.'];
            }
        }
        updater_restore_protected_paths($keepRoot);
        updater_forget_compiled(UPDATER_ALLOWED_MANAGED_PATHS);
        updater_rrmdir($keepRoot);
        updater_rrmdir($backupRoot);

        $local = updater_read_local_manifest();
        $cache = updater_load_cache();
        $cache['lastCheck'] = current_iso_time();
        $cache['skippedVersion'] = $rolledBackFrom;
        updater_save_cache($cache);

        updater_log('rollback to ' . $local['version']);
        return ['ok' => true, 'currentVersion' => $local['version']];
    } finally {
        updater_release_lock($lock);
    }
}
