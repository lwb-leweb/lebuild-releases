<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db.php';

// Systemprüfung: einzige Quelle für die Voraussetzungen des Editors. Admin →
// Einstellungen → System und der Hinweis im Dashboard lesen beide hier.

const SYSTEM_MIN_PHP_VERSION = '8.0';

function system_php_version_ok(string $version): bool
{
    return version_compare($version, SYSTEM_MIN_PHP_VERSION, '>=');
}

/**
 * Prüfliste mit key, label, ok und purpose (wofür es gebraucht wird).
 * $extensions/$phpVersion vorgeben nur für Tests; ohne Angabe gilt die
 * laufende PHP-Umgebung.
 */
function system_checks(?array $extensions = null, string $phpVersion = PHP_VERSION): array
{
    $loaded = array_map('strtolower', $extensions ?? get_loaded_extensions());

    $checks = [[
        'key' => 'php',
        'label' => 'PHP ' . $phpVersion . ' (mind. ' . SYSTEM_MIN_PHP_VERSION . ')',
        'ok' => system_php_version_ok($phpVersion),
        'purpose' => 'PHP-Version – unter ' . SYSTEM_MIN_PHP_VERSION . ' läuft der Editor nicht.',
    ]];

    $extensionPurposes = [
        'sodium' => 'sodium – ohne sie werden keine Updates installiert.',
        'pdo_sqlite' => DB_SQLITE_MISSING_MESSAGE,
        'zip' => 'zip – ohne sie werden keine Updates entpackt und installiert und keine Sicherungen erstellt.',
        'curl' => 'curl – ohne sie lädt der Editor Updates nur, wenn der Hoster allow_url_fopen erlaubt.',
    ];
    foreach ($extensionPurposes as $name => $purpose) {
        $checks[] = [
            'key' => $name,
            'label' => 'PHP-Erweiterung ' . $name,
            'ok' => in_array($name, $loaded, true),
            'purpose' => $purpose,
        ];
    }

    $writablePaths = [
        'content' => [CONTENT_ROOT, 'ohne Schreibrechte werden keine Inhalte, Benutzer oder Einstellungen gespeichert.'],
        'site' => [SITE_ROOT, 'ohne Schreibrechte werden Änderungen nicht in die Seiten der Website geschrieben.'],
        'uploads' => [UPLOADS_ROOT, 'ohne Schreibrechte lassen sich keine Bilder hochladen.'],
    ];
    foreach ($writablePaths as $key => [$path, $purpose]) {
        $relative = substr($path, strlen(PROJECT_ROOT) + 1) . '/';
        $checks[] = [
            'key' => 'writable_' . $key,
            'label' => 'Schreibrechte ' . $relative,
            'ok' => system_path_writable($path),
            'purpose' => $relative . ' – ' . $purpose,
        ];
    }

    return $checks;
}

/** Ein fehlender Ordner zählt als beschreibbar, wenn ensure_dir() ihn anlegen kann. */
function system_path_writable(string $path): bool
{
    return is_dir($path) ? is_writable($path) : !file_exists($path) && is_writable(dirname($path));
}

/** Nur die Einträge, die fehlen. */
function system_problems(array $checks): array
{
    return array_values(array_filter($checks, static fn (array $check): bool => !$check['ok']));
}

/** Mängel für den Dashboard-Hinweis: nur Admins bekommen sie, sonst leer. */
function system_problems_for_current_user(): array
{
    return is_admin() ? system_problems(system_checks()) : [];
}
