<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/db.php';
require_once __DIR__ . '/../../core/plugins.php';
require_once __DIR__ . '/../../core/pluginSchema.php';
require_once __DIR__ . '/../../core/uploads.php';
require_once __DIR__ . '/../../core/siteRoutes.php';

// Reihenfolge der Einträge eines Typs; vor dem ersten Sortieren haben alle sort_order 0.
const CONTENT_TYPES_ORDER = 'sort_order ASC, id DESC';
// Sortieren (↑/↓): Richtung → Schritt in der Liste.
const CONTENT_TYPES_SORT_STEPS = [INLINE_EDIT_SORT_UP => -1, INLINE_EDIT_SORT_DOWN => 1];
// Klickziele eines Eintrags (actions in der Typ-Definition) mit ihrer Beschriftung im Formular,
// in dieser Reihenfolge; ohne actions gilt CONTENT_TYPES_DEFAULT_ACTIONS.
const CONTENT_TYPES_ACTIONS = ['none' => 'Nichts', 'link' => 'Externer Link', 'page' => 'Eigene Seite', 'modal' => 'Modal'];
const CONTENT_TYPES_DEFAULT_ACTIONS = ['none'];
// Felder, die die Klickziele in den Eintrag bringen (im data-JSON): Name → Beschriftung. Ein Feld
// des Typs mit einem dieser Namen macht die Definition ungültig, sobald das Ziel es braucht.
const CONTENT_TYPES_ACTION_FIELDS = ['action' => 'Beim Klick', 'url' => 'Link', 'slug' => 'Adresse'];
// Ungültige Typ-Definition: Gründe (Typname, dann Wert) für den Hinweis im Backend und das Log.
const CONTENT_TYPES_INVALID_TEXT = [
    'unreadable' => '„%s“: Die Datei ist kein gültiger Content-Typ (JSON mit name, label und fields).',
    'actions' => '„%s“: actions muss eine Liste aus %s sein.',
    'action' => '„%s“: Unbekanntes Klickziel „%s“ in actions.',
    'duplicate' => '„%s“: Das Klickziel „%s“ steht mehrfach in actions.',
    'defaultAction' => '„%s“: defaultAction „%s“ steht nicht in actions.',
    'page' => '„%s“: Mit dem Ziel page braucht der Typ page mit path, titleField und descriptionField.',
    'pagePath' => '„%s“: page.path „%s“ ist kein gültiger Name (Buchstaben, Ziffern, - und _).',
    'pageTaken' => '„%s“: page.path „%s“ ist schon vergeben (Seite oder Datei der Website, Adresse des Editors).',
    'pageField' => '„%s“: page.%s muss ein Feld des Typs nennen (erlaubte Arten: %s).',
    'pageShared' => '„%s“: page.path „%s“ nutzt auch der Typ „%s“.',
    'reserved' => '„%s“: Das Feld „%s“ ist für die Klickziele reserviert.',
    'orderBy' => '„%s“: orderBy braucht field (ein Feld des Typs, erlaubte Arten: %s) und optional direction (asc oder desc).',
    'publishField' => '„%s“: publishField muss ein Feld des Typs nennen (erlaubte Arten: %s).',
    'optionsFrom' => '„%s“: optionsFrom von „%s“ muss einen anderen Content-Typ mit Textfeld nennen.',
];
// Auswahlfeld mit optionsFrom: Die Werte sind die Titel der Einträge eines anderen Typs (Feld name oder title,
// sonst das erste Textfeld, wie entryTitle im Formular), in dessen Listenreihenfolge. Das Formular bietet
// dazu „+ <Feld> hinzufügen“ an: Es legt über diesen Endpoint einen Eintrag im anderen Typ an.
const CONTENT_TYPES_TITLE_FIELDS = ['name', 'title'];
const CONTENT_TYPES_SAVE_URL = PLUGINS_URL . 'content-types/api/save.php';
// orderBy in der Typ-Definition: Einträge nach einem Feld statt von Hand (↑/↓ entfällt), erlaubte Arten
// und Richtungen. Ohne Wert zählt bei date/datetime das Anlegedatum, sonst stehen solche Einträge am Ende.
const CONTENT_TYPES_ORDER_FIELD_TYPES = ['text', 'number', 'date', 'datetime'];
const CONTENT_TYPES_ORDER_DIRECTIONS = ['asc', 'desc'];
// publishField: Auf der Website erscheint ein Eintrag erst ab diesem Datum (leer: sofort), das Backend zeigt alle.
const CONTENT_TYPES_PUBLISH_FIELD_TYPES = ['date', 'datetime'];
// Eintrag in der Seitenleiste des Backends, wenn es ungültige Typen gibt (Gründe in seiner Ansicht).
const CONTENT_TYPES_INVALID_LABEL = 'Ungültige Content-Typen';
// Einträge einer Liste: Vorgabe für data-limit und höchstens so viele.
const CONTENT_TYPES_LIST_LIMIT = 20;
const CONTENT_TYPES_LIST_MAX = 500;
// data-filter="<feld>=<wert>": Trennzeichen zwischen Feld und Wert (das erste zählt).
const CONTENT_TYPES_FILTER_SEPARATOR = '=';
// Erlaubte Arten der Felder, die Titel und Beschreibung der eigenen Seite liefern (page).
const CONTENT_TYPES_PAGE_FIELD_TYPES = ['titleField' => ['text'], 'descriptionField' => ['text', 'textarea', 'richtext']];
// Ausgabe des Shortcodes statt der Liste, wenn der Typ fehlt, ungültig ist oder die Einträge nicht
// laden (Grund nur im Log, nie auf der Website).
const CONTENT_TYPES_RENDER_FAILED = '<!-- content-types: list unavailable -->';
// Modal-Skript und sein CSS (nur Position, Scroll-Sperre, Fokus), eingebunden auf Seiten mit einer Liste
// eines Typs mit modal (content_types_filter_site_html).
const CONTENT_TYPES_MODAL_ASSETS = [
    'style' => PLUGINS_URL . 'content-types/assets/modal.css',
    'script' => PLUGINS_URL . 'content-types/assets/modal.js',
];
// Import (api/import.php): höchstens so viele Einträge und Bytes (Anfrage) auf einmal, Meldungen (Zeile ab 1,
// Feld, Grund ohne Feldnamen; image mit UPLOADS_URL und LE_SITE_FILES_URL, action mit den erlaubten Zielen).
const CONTENT_TYPES_IMPORT_MAX = 500;
const CONTENT_TYPES_IMPORT_MAX_BYTES = 5 * BYTES_PER_MB;
const CONTENT_TYPES_IMPORT_TEXT = [
    'tooLarge' => 'Die Datei ist größer als %d MB.',
    'notList' => 'Die Datei muss eine Liste (JSON-Array) von Einträgen enthalten.',
    'empty' => 'Die Datei enthält keine Einträge.',
    'tooMany' => 'Höchstens %d Einträge auf einmal.',
    'entry' => 'Zeile %d: Kein Eintrag (JSON-Objekt).',
    'line' => 'Zeile %d, %s: %s',
    'action' => 'Dieses Ziel gibt es hier nicht (erlaubt: %s).',
    'image' => 'Nur Bilder, die es schon gibt, unter %s oder %s.',
];

// Ordner der Website je Typ (von außen gesperrt: .htaccess, index.php): Vorlagen (template.php) und Typen der
// Website. Liegt dort typ.json (Typ-Definition, optional eintraege.json wie beim Import), legt
// content_types_adopt_site_types() den Typ einmal an; welche schon übernommen sind, steht in
// CONTENT_TYPES_ADOPTED_FILE (content_types_dir()). Gelöschte oder geänderte Typen und Einträge bleiben so.
const CONTENT_TYPES_TEMPLATE_DIR = LE_SITE_ROOT . '/includes/content-types';
const CONTENT_TYPES_SITE_TYPE_FILE = 'typ.json';
const CONTENT_TYPES_SITE_ENTRIES_FILE = 'eintraege.json';
const CONTENT_TYPES_ADOPTED_FILE = '.website-typen.json';

function content_types_dir(): string
{
    return plugin_data_path('content-types');
}

/**
 * Übernimmt die Typen der Website, die noch nicht übernommen sind (CONTENT_TYPES_TEMPLATE_DIR/<typ>/typ.json),
 * einmal je Request und nur bei aktivem Plugin: fehlt die Definition unter content_types_dir(), wird sie kopiert;
 * hat der Typ noch keine Einträge, kommen die aus eintraege.json dazu (content_types_import, ganz oder gar
 * nicht, Bilder müssen existieren). Danach gilt der Typ als übernommen und wird nie wieder angefasst.
 * Ohne Typen der Website oder wenn alle übernommen sind, kostet das nur das Lesen des Ordners und der Liste.
 * Unter store_lock(), damit gleichzeitige Requests nichts doppelt anlegen; Fehler nur ins Log, der Typ wird
 * dann beim nächsten Request wieder versucht.
 */
function content_types_adopt_site_types(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    // Vor der Arbeit: Import und Prüfung lesen selbst Typen (content_types_read) und landen wieder hier.
    $done = true;
    if (content_types_site_types_pending() === [] || !plugin_active('content-types') || !db_available() || db_migration_running()) {
        return;
    }
    $lock = store_lock('content-types-website');
    try {
        $adopted = content_types_adopted_site_types();
        $before = $adopted;
        // Zwei Durchgänge: Ein Typ, dessen Auswahl aus einem anderen kommt (optionsFrom), kann erst nach diesem
        // übernommen werden (seine Einträge brauchen dessen Werte); ins Log nur, was auch im zweiten scheitert.
        $pending = content_types_site_types_pending($adopted);
        foreach ([false, true] as $last) {
            $failed = [];
            foreach ($pending as $name) {
                try {
                    content_types_adopt_site_type($name);
                    $adopted[] = $name;
                } catch (Throwable $e) {
                    $failed[] = $name;
                    if ($last) {
                        error_log('content-types: Typ der Website ' . $name . ': ' . $e->getMessage()
                            . ($e instanceof PluginFieldException ? ' (' . content_types_import_message($e) . ')' : ''));
                    }
                }
            }
            $pending = $failed;
        }
        if ($adopted !== $before) {
            sort($adopted);
            $json = json_encode($adopted, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
            ensure_dir(content_types_dir());
            write_file_atomic(content_types_dir() . '/' . CONTENT_TYPES_ADOPTED_FILE, $json . PHP_EOL);
        }
    } catch (Throwable $e) {
        error_log('content-types: Typen der Website: ' . $e->getMessage());
    } finally {
        store_unlock($lock);
    }
}

/** Namen der Typen der Website mit typ.json, die nicht in $adopted stehen (ohne Angabe: content_types_adopted_site_types). */
function content_types_site_types_pending(?array $adopted = null): array
{
    $names = [];
    foreach (dir_entries(CONTENT_TYPES_TEMPLATE_DIR) as $name) {
        if (content_types_name_valid($name) && is_file(CONTENT_TYPES_TEMPLATE_DIR . '/' . $name . '/' . CONTENT_TYPES_SITE_TYPE_FILE)) {
            $names[] = $name;
        }
    }
    if ($names === []) {
        return [];
    }

    return array_values(array_diff($names, $adopted ?? content_types_adopted_site_types()));
}

/** Schon übernommene Typen der Website (CONTENT_TYPES_ADOPTED_FILE); fehlt die Datei oder ist kaputt: keine. */
function content_types_adopted_site_types(): array
{
    $data = json_decode((string) @file_get_contents(content_types_dir() . '/' . CONTENT_TYPES_ADOPTED_FILE), true);

    return is_array($data) ? array_values(array_filter($data, 'is_string')) : [];
}

/** Legt einen Typ der Website an (content_types_adopt_site_types): Definition, falls sie fehlt, Einträge, falls der Typ keine hat. */
function content_types_adopt_site_type(string $name): void
{
    $source = CONTENT_TYPES_TEMPLATE_DIR . '/' . $name;
    $target = content_types_dir() . '/' . $name . '.json';
    if (!is_file($target)) {
        $json = (string) file_get_contents($source . '/' . CONTENT_TYPES_SITE_TYPE_FILE);
        if ((json_decode($json, true)['name'] ?? null) !== $name) {
            throw new RuntimeException(CONTENT_TYPES_SITE_TYPE_FILE . ' is no content-type named ' . $name);
        }
        ensure_dir(content_types_dir());
        write_file_atomic($target, $json);
    }
    $entriesPath = $source . '/' . CONTENT_TYPES_SITE_ENTRIES_FILE;
    if (!is_file($entriesPath)) {
        return;
    }
    $stmt = db()->prepare('SELECT COUNT(*) FROM content_items WHERE content_type = ?');
    $stmt->execute([$name]);
    if ((int) $stmt->fetchColumn() === 0) {
        content_types_import($name, json_decode((string) file_get_contents($entriesPath), true, 512, JSON_THROW_ON_ERROR));
    }
}

function content_types_name_valid(string $name): bool
{
    return (bool) preg_match('/^[a-z][a-z0-9_-]*$/', $name);
}

function content_types_list_names(): array
{
    content_types_adopt_site_types();
    $dir = content_types_dir();
    if (!is_dir($dir)) {
        return [];
    }

    $names = [];
    foreach (scandir($dir) ?: [] as $entry) {
        if (!is_string($entry) || !str_ends_with($entry, '.json')) {
            continue;
        }
        $name = substr($entry, 0, -5);
        if (!content_types_name_valid($name)) {
            continue;
        }
        if (!is_file($dir . '/' . $entry)) {
            continue;
        }
        $names[] = $name;
    }
    sort($names);

    return $names;
}

/**
 * Typ-Definition aus content/plugins/content-types/<name>.json (Typen der Website vorher übernommen) mit den Vorgaben für actions und
 * defaultAction, noch ohne deren Prüfung (content_types_definition_problem). Wirft, wenn die Datei
 * fehlt oder kein Content-Typ ist (JSON, name, label, fields).
 */
function content_types_read(string $name): array
{
    if (!content_types_name_valid($name)) {
        throw new InvalidArgumentException(API_TEXT['invalidType']);
    }
    content_types_adopt_site_types();
    $path = content_types_dir() . '/' . $name . '.json';
    if (!is_file($path)) {
        throw new RuntimeException('Content-type not found: ' . $name);
    }

    $data = json_decode((string) file_get_contents($path), true);
    if (!is_array($data)) {
        throw new RuntimeException('Invalid JSON for content-type: ' . $name);
    }
    if (($data['name'] ?? '') !== $name) {
        throw new RuntimeException('Content-type name mismatch: ' . $name);
    }
    if (!is_string($data['label'] ?? null) || trim($data['label']) === '') {
        throw new RuntimeException('Content-type missing label: ' . $name);
    }
    if (!is_array($data['fields'] ?? null) || empty($data['fields'])) {
        throw new RuntimeException('Content-type has no fields: ' . $name);
    }

    $data['actions'] ??= CONTENT_TYPES_DEFAULT_ACTIONS;
    $data['defaultAction'] ??= is_array($data['actions']) ? ($data['actions'][0] ?? null) : null;

    return $data;
}

/** Gültige Typ-Definition (content_types_read + content_types_definition_problem); wirft mit dem Grund. */
function content_types_load(string $name): array
{
    $data = content_types_read($name);
    $problem = content_types_definition_problem($data);
    if ($problem !== null) {
        throw new RuntimeException('Invalid content-type: ' . $problem);
    }

    return $data;
}

/**
 * Grund, warum die Klickziele einer Definition (aus content_types_read) ungültig sind, als Text aus
 * CONTENT_TYPES_INVALID_TEXT; null, wenn sie gültig ist.
 */
function content_types_definition_problem(array $def): ?string
{
    $name = (string) $def['name'];
    $show = static fn (mixed $value): string => is_string($value) ? $value : (string) json_encode($value, JSON_UNESCAPED_UNICODE);
    $actions = $def['actions'];
    if (!is_array($actions) || $actions === [] || array_values($actions) !== $actions) {
        return sprintf(CONTENT_TYPES_INVALID_TEXT['actions'], $name, implode(', ', array_keys(CONTENT_TYPES_ACTIONS)));
    }
    foreach ($actions as $action) {
        if (!is_string($action) || !isset(CONTENT_TYPES_ACTIONS[$action])) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['action'], $name, $show($action));
        }
    }
    foreach (array_count_values($actions) as $action => $count) {
        if ($count > 1) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['duplicate'], $name, $action);
        }
    }
    if (!in_array($def['defaultAction'], $actions, true)) {
        return sprintf(CONTENT_TYPES_INVALID_TEXT['defaultAction'], $name, $show($def['defaultAction']));
    }

    // Nur Felder, die es im Formular gibt (Namen wie bei jedem Schema): Ein titleField auf ein Feld mit
    // ungültigem Namen gäbe sonst jeder eigenen Seite einen leeren Titel.
    $fieldTypes = array_column(content_types_schema_columns($def), 'type', 'name');
    $fieldNames = array_keys($fieldTypes);
    if (in_array('page', $actions, true)) {
        $page = $def['page'] ?? null;
        if (!is_array($page) || !is_string($page['path'] ?? null) || !isset($page['titleField'], $page['descriptionField'])) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['page'], $name);
        }
        if (!is_safe_page_name($page['path'])) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['pagePath'], $name, $page['path']);
        }
        if (le_site_path_taken($page['path'])) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['pageTaken'], $name, $page['path']);
        }
        $other = array_search($page['path'], content_types_page_paths($name), true);
        if ($other !== false) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['pageShared'], $name, $page['path'], $other);
        }
        foreach (CONTENT_TYPES_PAGE_FIELD_TYPES as $key => $types) {
            if (!is_string($page[$key]) || !in_array($fieldTypes[$page[$key]] ?? null, $types, true)) {
                return sprintf(CONTENT_TYPES_INVALID_TEXT['pageField'], $name, $key, implode(', ', $types));
            }
        }
    }

    foreach (content_types_action_field_names($actions) as $reserved) {
        if (in_array($reserved, $fieldNames, true)) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['reserved'], $name, $reserved);
        }
    }

    if (array_key_exists('orderBy', $def)) {
        $order = $def['orderBy'];
        if (!is_array($order) || !is_string($order['field'] ?? null)
            || !in_array($fieldTypes[$order['field']] ?? null, CONTENT_TYPES_ORDER_FIELD_TYPES, true)
            || !in_array($order['direction'] ?? 'asc', CONTENT_TYPES_ORDER_DIRECTIONS, true)) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['orderBy'], $name, implode(', ', CONTENT_TYPES_ORDER_FIELD_TYPES));
        }
    }
    if (array_key_exists('publishField', $def)
        && (!is_string($def['publishField']) || !in_array($fieldTypes[$def['publishField']] ?? null, CONTENT_TYPES_PUBLISH_FIELD_TYPES, true))) {
        return sprintf(CONTENT_TYPES_INVALID_TEXT['publishField'], $name, implode(', ', CONTENT_TYPES_PUBLISH_FIELD_TYPES));
    }
    foreach (content_types_schema_columns($def) as $field) {
        if ($field['type'] === 'select' && array_key_exists('optionsFrom', $field) && !content_types_options_source_valid($name, $field['optionsFrom'])) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['optionsFrom'], $name, $field['name']);
        }
    }

    return null;
}

/** Ob $from (optionsFrom eines Feldes des Typs $name) ein anderer lesbarer Typ mit Titelfeld ist (content_types_title_field). */
function content_types_options_source_valid(string $name, mixed $from): bool
{
    if (!is_string($from) || $from === $name || !in_array($from, content_types_list_names(), true)) {
        return false;
    }
    try {
        return content_types_title_field(content_types_read($from)) !== null;
    } catch (Throwable $e) {
        return false;
    }
}

/** Feld, das einen Eintrag benennt: ein Textfeld name oder title, sonst das erste Textfeld; null ohne. */
function content_types_title_field(array $def): ?string
{
    $text = array_values(array_filter(content_types_schema_columns($def), static fn (array $field): bool => $field['type'] === 'text'));
    foreach ($text as $field) {
        if (in_array($field['name'], CONTENT_TYPES_TITLE_FIELDS, true)) {
            return $field['name'];
        }
    }

    return $text[0]['name'] ?? null;
}

/**
 * Auswahlfeld mit optionsFrom fürs Formular und Speichern: options sind die Titel der Einträge des anderen Typs
 * (ohne leere und doppelte), optionsCreate sagt dem Formular, wie es dort einen neuen anlegt. Ein Wert $current,
 * den es dort nicht mehr gibt (gelöscht; Umbenennen zieht content_types_rename_option mit), bleibt als Option, damit der Eintrag ihn behält.
 */
function content_types_options_from(array $field, mixed $current): array
{
    $source = content_types_load((string) $field['optionsFrom']);
    $title = (string) content_types_title_field($source);
    $options = [];
    foreach (content_types_fetch_list($source['name'], null, null, $source) as $row) {
        $value = $row[$title] ?? null;
        if (is_string($value) && $value !== '' && !in_array($value, $options, true)) {
            $options[] = $value;
        }
    }
    if (is_string($current) && $current !== '' && !in_array($current, $options, true)) {
        $options[] = $current;
    }
    unset($field['optionLabels']);

    return ['options' => $options, 'optionsCreate' => ['url' => CONTENT_TYPES_SAVE_URL, 'type' => $source['name'], 'field' => $title]] + $field;
}

/** page.path der übrigen lesbaren Typen mit dem Ziel page (Typname → path), ohne $except. */
function content_types_page_paths(string $except): array
{
    $paths = [];
    foreach (content_types_list_names() as $name) {
        if ($name === $except) {
            continue;
        }
        try {
            $def = content_types_read($name);
        } catch (Throwable $e) {
            continue;
        }
        if (is_array($def['actions']) && in_array('page', $def['actions'], true) && is_string($def['page']['path'] ?? null)) {
            $paths[$name] = $def['page']['path'];
        }
    }

    return $paths;
}

/** Felder, die die Klickziele $actions brauchen: action ab zwei Zielen, url bei link, slug bei page. */
function content_types_action_field_names(array $actions): array
{
    $names = [];
    if (count($actions) > 1) {
        $names[] = 'action';
    }
    if (in_array('link', $actions, true)) {
        $names[] = 'url';
    }
    if (in_array('page', $actions, true)) {
        $names[] = 'slug';
    }

    return $names;
}

/**
 * Klickziel eines Eintrags: sein action, wenn der Typ es erlaubt, sonst defaultAction (Einträge ohne
 * Angabe, ältere oder importierte, und Ziele, die der Typ nicht mehr erlaubt). $def aus content_types_load.
 */
function content_types_item_action(array $def, array $item): string
{
    $action = $item['action'] ?? null;

    return content_types_action_allowed($def, $action) ? $action : $def['defaultAction'];
}

/** Ob $action ein Klickziel ist, das der Typ ($def aus content_types_load) erlaubt. */
function content_types_action_allowed(array $def, mixed $action): bool
{
    return is_string($action) && in_array($action, $def['actions'], true);
}

/**
 * Seitenleiste des Backends: je gültigem Typ ein Eintrag; gibt es ungültige oder unlesbare, steht
 * vorn ein Eintrag CONTENT_TYPES_INVALID_LABEL mit den Gründen (problems), die auch ins Log gehen.
 */
function content_types_admin_sidebar_entries(): array
{
    $entries = [];
    $problems = [];
    foreach (content_types_list_names() as $name) {
        try {
            $def = content_types_read($name);
        } catch (Throwable $e) {
            error_log('content-types: ' . $e->getMessage());
            $problems[] = sprintf(CONTENT_TYPES_INVALID_TEXT['unreadable'], $name);
            continue;
        }
        $problem = content_types_definition_problem($def);
        if ($problem !== null) {
            error_log('content-types: ' . $problem);
            $problems[] = $problem;
            continue;
        }
        $entries[] = [
            'name' => 'content-types',
            'route' => 'content-types/' . $name,
            'label' => (string) $def['label'],
            'hasAdminModule' => true,
            'hasSchema' => true,
            'type' => $name,
        ];
    }
    if ($problems !== []) {
        array_unshift($entries, [
            'name' => 'content-types',
            'route' => 'content-types',
            'label' => CONTENT_TYPES_INVALID_LABEL,
            'hasAdminModule' => true,
            'problems' => $problems,
        ]);
    }

    return $entries;
}

/** Felder des Typs ($def aus content_types_read), ohne die Klickziel-Felder; gültig wie bei jedem Schema (plugin_schema_columns). */
function content_types_schema_columns(array $def): array
{
    return plugin_schema_columns(['schema' => ['fields' => $def['fields']]]);
}

/**
 * Felder des Formulars (Backend und Website) und fürs Speichern: vor denen des Typs die Klickziel-Felder
 * (content_types_action_field_names). „Beim Klick“ bietet nur die erlaubten Ziele, vorausgewählt
 * defaultAction; Link und Adresse erscheinen nur beim passenden Ziel (showWhen), bei genau einem
 * Ziel immer. Auswahlfelder mit optionsFrom bekommen ihre Werte (content_types_options_from; $stored ist
 * der gespeicherte Eintrag beim Bearbeiten). Die Ausgabe auf der Website nutzt content_types_schema_columns.
 */
function content_types_form_columns(array $def, ?array $stored = null): array
{
    $actions = array_values(array_intersect(array_keys(CONTENT_TYPES_ACTIONS), $def['actions']));
    $choice = count($actions) > 1;
    $when = static fn (string $action): array => $choice ? ['showWhen' => ['field' => 'action', 'value' => $action]] : [];
    $fields = [
        'action' => [
            'type' => 'select',
            'required' => true,
            'options' => $actions,
            'optionLabels' => array_intersect_key(CONTENT_TYPES_ACTIONS, array_flip($actions)),
            'default' => $def['defaultAction'],
        ],
        'url' => ['type' => 'url'] + ($choice ? $when('link') : ['required' => true]),
        'slug' => ['type' => 'slug', 'from' => $def['page']['titleField'] ?? null] + $when('page'),
    ];

    $columns = [];
    foreach (content_types_action_field_names($def['actions']) as $name) {
        $columns[] = ['name' => $name, 'label' => CONTENT_TYPES_ACTION_FIELDS[$name]] + $fields[$name];
    }

    foreach (content_types_schema_columns($def) as $field) {
        $columns[] = $field['type'] === 'select' && isset($field['optionsFrom'])
            ? content_types_options_from($field, $stored[$field['name']] ?? null)
            : $field;
    }

    return $columns;
}

/**
 * Klickziel-Werte nach plugin_schema_values: Ein Link, der nur beim Ziel link erscheint (showWhen), ist
 * dann Pflicht (Meldung wie ein Pflichtfeld; bei genau einem Ziel ist er schon im Schema required);
 * mit dem Ziel page bekommt jeder Eintrag eine Adresse (slug, sonst aus titleField), eindeutig im Typ.
 */
function content_types_action_values(array $def, array $columns, array $values, ?int $id): array
{
    $byName = array_column($columns, null, 'name');
    $url = $byName['url'] ?? null;
    if (isset($url['showWhen']) && content_types_item_action($def, $values) === 'link' && plugin_schema_blank($url, $values['url'] ?? '')) {
        throw plugin_schema_required_error($url);
    }
    if (isset($byName['slug'])) {
        $slug = $values['slug'] ?? plugin_schema_normalize_value($byName['slug'], '', $values);
        $used = content_types_slugs_in_use((string) $def['name'], $id);
        $values['slug'] = plugin_unique_slug_with($slug, static fn (string $candidate): bool => in_array($candidate, $used, true));
    }

    return $values;
}

/** Adressen (slug) der übrigen Einträge eines Typs; die Einträge stehen als JSON in data, daher in PHP gelesen. */
function content_types_slugs_in_use(string $type, ?int $id): array
{
    $stmt = db()->prepare('SELECT id, data FROM content_items WHERE content_type = ? AND id <> ?');
    $stmt->execute([$type, $id ?? 0]);
    $slugs = [];
    foreach ($stmt->fetchAll() as $row) {
        $slug = content_types_expand_row($row)['slug'] ?? null;
        if (is_string($slug)) {
            $slugs[] = $slug;
        }
    }

    return $slugs;
}

/**
 * Einträge eines Typs in Listenreihenfolge, höchstens $limit (1 bis CONTENT_TYPES_LIST_MAX; null: alle, z. B.
 * fürs Backend, das jeden Eintrag zeigt, auch nach mehreren Importen). $filter [feld, wert]
 * (content_types_list_filter) behält nur Einträge, deren gespeicherter Wert gleich ist; verglichen wird in
 * PHP, weil die Werte als JSON in data stehen (JSON-SQL unterscheidet sich zwischen SQLite und MySQL). Dafür
 * wird der Typ ohne LIMIT gelesen, bis $limit Treffer da sind. $def (content_types_load) mit orderBy sortiert
 * nach dem Feld (dafür alle Einträge gelesen), $public lässt mit publishField die noch nicht fälligen weg.
 */
function content_types_fetch_list(string $type, ?int $limit = 100, ?array $filter = null, ?array $def = null, bool $public = false): array
{
    if (!content_types_name_valid($type)) {
        return [];
    }
    $limit = $limit === null ? null : max(1, min(CONTENT_TYPES_LIST_MAX, $limit));
    $ordered = isset($def['orderBy']);
    $hidden = $public && isset($def['publishField']);
    $stmt = db()->prepare(
        "SELECT id, data, sort_order, created_at, updated_at
         FROM content_items
         WHERE content_type = ?
         ORDER BY " . CONTENT_TYPES_ORDER .
        ($filter === null && !$ordered && !$hidden && $limit !== null ? " LIMIT {$limit}" : '')
    );
    $stmt->execute([$type]);
    $rows = [];
    $now = db_now();
    while (($ordered || $limit === null || count($rows) < $limit) && ($row = $stmt->fetch()) !== false) {
        $row = content_types_expand_row($row);
        if ($filter !== null && (!is_scalar($row[$filter[0]] ?? '') || (string) ($row[$filter[0]] ?? '') !== $filter[1])) {
            continue;
        }
        if ($hidden && !content_types_published($def, $row, $now)) {
            continue;
        }
        $rows[] = $row;
    }
    $stmt->closeCursor();
    if ($ordered) {
        $rows = content_types_sort_rows($def, $rows);
    }

    return $limit === null ? $rows : array_slice($rows, 0, $limit);
}

/**
 * Ob ein Eintrag auf der Website erscheint: ohne publishField immer, sonst wenn das Datum leer oder erreicht ist
 * ($now wie db_now(); ein Tag „2026-11-02“ ist ab Mitternacht fällig, weil er als Text davor sortiert).
 */
function content_types_published(array $def, array $row, ?string $now = null): bool
{
    $value = isset($def['publishField']) ? ($row[$def['publishField']] ?? null) : null;

    return !is_string($value) || $value === '' || $value <= ($now ?? db_now());
}

/**
 * Einträge nach orderBy ($def aus content_types_load): Zahlen als Zahl, sonst als Text; ohne Wert gilt bei
 * date/datetime das Anlegedatum, sonst steht der Eintrag am Ende. Gleiche Werte behalten die Listenreihenfolge.
 */
function content_types_sort_rows(array $def, array $rows): array
{
    $field = (string) $def['orderBy']['field'];
    $type = array_column(content_types_schema_columns($def), 'type', 'name')[$field] ?? 'text';
    $desc = ($def['orderBy']['direction'] ?? 'asc') === 'desc';
    $key = static function (array $row) use ($field, $type): mixed {
        $value = $row[$field] ?? null;
        if ($value === null || $value === '') {
            return in_array($type, ['date', 'datetime'], true) ? (string) $row['created_at'] : null;
        }
        return $type === 'number' ? (float) $value : (string) $value;
    };
    $keyed = array_map(static fn (array $row, int $index): array => [$key($row), $index, $row], $rows, array_keys($rows));
    usort($keyed, static function (array $a, array $b) use ($desc): int {
        if ($a[0] === null || $b[0] === null) {
            return ($a[0] === null) <=> ($b[0] === null) ?: $a[1] <=> $b[1];
        }
        $cmp = is_string($a[0]) ? strcmp($a[0], $b[0]) : $a[0] <=> $b[0];
        return ($desc ? -$cmp : $cmp) ?: $a[1] <=> $b[1];
    });

    return array_column($keyed, 2);
}

/**
 * data-filter einer Liste als [feld, wert]; null ohne Attribut. Wirft, wenn das Trennzeichen fehlt oder
 * das Feld kein einfaches Feld des Typs ist ($schema aus content_types_schema_columns, list zählt nicht).
 */
function content_types_list_filter(array $schema, ?string $raw): ?array
{
    if ($raw === null) {
        return null;
    }
    $parts = explode(CONTENT_TYPES_FILTER_SEPARATOR, $raw, 2);
    $fields = array_column($schema, 'type', 'name');
    if (count($parts) !== 2 || !isset($fields[$parts[0]]) || $fields[$parts[0]] === 'list') {
        throw new InvalidArgumentException('unknown filter field: ' . $parts[0]);
    }

    return $parts;
}

/** data-limit einer Liste: ganze Zahl ab 1, sonst CONTENT_TYPES_LIST_LIMIT; höchstens CONTENT_TYPES_LIST_MAX. */
function content_types_list_limit(?string $raw): int
{
    $limit = filter_var($raw, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);

    return $limit === false ? CONTENT_TYPES_LIST_LIMIT : min($limit, CONTENT_TYPES_LIST_MAX);
}

function content_types_fetch_by_id(string $type, int $id): ?array
{
    if (!content_types_name_valid($type) || $id <= 0) {
        return null;
    }
    $stmt = db()->prepare(
        'SELECT id, data, sort_order, created_at, updated_at
         FROM content_items WHERE content_type = ? AND id = ? LIMIT 1'
    );
    $stmt->execute([$type, $id]);
    $row = $stmt->fetch();

    return $row ? content_types_expand_row($row) : null;
}

/** Eintrag eines Typs mit der Adresse (slug) $slug; data ist JSON, daher in PHP verglichen. */
function content_types_fetch_by_slug(string $type, string $slug): ?array
{
    if (!content_types_name_valid($type)) {
        return null;
    }
    $stmt = db()->prepare(
        'SELECT id, data, sort_order, created_at, updated_at
         FROM content_items WHERE content_type = ? ORDER BY ' . CONTENT_TYPES_ORDER
    );
    $stmt->execute([$type]);
    foreach ($stmt->fetchAll() as $row) {
        $item = content_types_expand_row($row);
        if (($item['slug'] ?? null) === $slug) {
            return $item;
        }
    }

    return null;
}

/** Gültiger Typ mit dem Ziel page, dessen page.path $path ist; null ohne. Ungültige Typen zählen nicht. */
function content_types_page_type(string $path): ?array
{
    foreach (content_types_list_names() as $name) {
        try {
            $def = content_types_load($name);
        } catch (Throwable $e) {
            continue;
        }
        if (in_array('page', $def['actions'], true) && $def['page']['path'] === $path) {
            return $def;
        }
    }

    return null;
}

/**
 * Hook site_page: eigene Seite eines Eintrags unter /<page.path>/<slug>. Adressen unter page.path eines
 * gültigen Typs gehören dem Plugin; ohne passenden Eintrag mit Ziel page → PLUGIN_SITE_PAGE_NOT_FOUND.
 */
function content_types_site_page(string $path): ?array
{
    if (!preg_match('#^/([^/]+)(?:/([^/]*))?/?$#', $path, $m)) {
        return null;
    }
    $def = content_types_page_type($m[1]);
    if ($def === null) {
        return null;
    }
    require_once __DIR__ . '/template.php';
    $slug = $m[2] ?? '';
    $row = preg_match(PLUGIN_SLUG_PATTERN, $slug) ? content_types_fetch_by_slug($def['name'], $slug) : null;
    // Noch nicht fällig (publishField): wie ein fehlender Eintrag.
    if ($row !== null && !content_types_published($def, $row)) {
        $row = null;
    }

    return ($row === null ? null : content_types_page($def, $row)) ?? PLUGIN_SITE_PAGE_NOT_FOUND;
}

/**
 * Hook filter_site_html: Seiten mit einer Liste eines Typs mit modal (CONTENT_TYPES_MODAL_LIST_ATTR, vom
 * Renderer gesetzt) bekommen einmal Modal-Skript und -CSS vor das letzte </body>; sonst unverändert.
 */
function content_types_filter_site_html(string $html): string
{
    require_once __DIR__ . '/template.php';
    $pos = strripos($html, '</body>');
    if ($pos === false || !str_contains($html, ' ' . CONTENT_TYPES_MODAL_LIST_ATTR) || str_contains($html, CONTENT_TYPES_MODAL_ASSETS['script'])) {
        return $html;
    }
    $tags = '<link rel="stylesheet" href="' . CONTENT_TYPES_MODAL_ASSETS['style'] . '">'
        . '<script src="' . CONTENT_TYPES_MODAL_ASSETS['script'] . '" defer></script>';

    return substr_replace($html, $tags, $pos, 0);
}

function content_types_expand_row(array $row): array
{
    $data = json_decode((string) ($row['data'] ?? '{}'), true);
    if (!is_array($data)) {
        $data = [];
    }
    unset($row['data']);
    return $row + $data;
}

/**
 * Speichert einen Eintrag (neu ohne $id, am Ende der Liste). Beim Bearbeiten werden danach Bilder gelöscht,
 * die der Eintrag nicht mehr nutzt (ersetzt, Zeile entfernt), sofern sie sonst nirgends verwendet werden.
 * Liefert die id; 0, wenn es den Eintrag $id dieses Typs nicht (mehr) gibt (api/save.php antwortet dann 404).
 */
function content_types_save(string $type, array $rawValues, ?int $id = null): int
{
    if (!content_types_name_valid($type)) {
        throw new InvalidArgumentException(API_TEXT['invalidType']);
    }
    $def = content_types_load($type);
    if ($id === null || $id <= 0) {
        return content_types_insert($type, content_types_values($def, $rawValues, null));
    }
    $stored = content_types_fetch_by_id($type, $id);
    if ($stored === null) {
        return 0;
    }
    $values = content_types_values($def, $rawValues, $id);

    $fields = content_types_schema_columns($def);
    $before = plugin_schema_image_values($fields, $stored);
    $title = content_types_title_field($def);
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('UPDATE content_items SET data = ?, updated_at = ? WHERE content_type = ? AND id = ?');
        $stmt->execute([plugin_schema_json($values), db_now(), $type, $id]);
        if ($title !== null) {
            content_types_rename_option($type, $id, $stored[$title] ?? null, $values[$title] ?? null);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    delete_unused_uploads(array_diff($before, plugin_schema_image_values($fields, $values)));

    return $id;
}

/**
 * Geprüfte Werte eines Eintrags ($def aus content_types_load) wie beim Speichern: Klickziel (ohne erlaubtes
 * gilt defaultAction), Felder nach Schema, Link und Adresse; $id beim Bearbeiten, sonst null. Wirft
 * InvalidArgumentException (PluginFieldException mit Feld) bei ungültigen Werten.
 */
function content_types_values(array $def, array $rawValues, ?int $id): array
{
    $type = (string) $def['name'];
    if (count($def['actions']) > 1) {
        // Ohne erlaubtes Ziel (ältere Einträge, importierte ohne action) gilt defaultAction.
        $rawValues['action'] = content_types_item_action($def, $rawValues);
    }

    $stored = $id !== null && $id > 0 ? content_types_fetch_by_id($type, $id) : null;
    $columns = content_types_form_columns($def, $stored);
    // Versteckte Felder (showWhen passt nicht zum Ziel: Link, Adresse) zählen nicht und blockieren nie:
    // Es bleibt der gespeicherte Wert, ohne ihn entfällt das Feld (die Adresse kommt dann aus titleField).
    foreach ($columns as $column) {
        $when = $column['showWhen'] ?? null;
        if ($when !== null && ($rawValues[$when['field']] ?? null) !== $when['value']) {
            unset($rawValues[$column['name']]);
            if (isset($stored[$column['name']])) {
                $rawValues[$column['name']] = $stored[$column['name']];
            }
        }
    }

    return content_types_action_values($def, $columns, plugin_schema_values($columns, $rawValues, $stored ?? []), $id);
}

/**
 * Umbenannter Eintrag $id des Typs $type, dessen Titel ein Auswahlwert anderer Typen ist (optionsFrom): Deren
 * Einträge mit dem alten Titel $old bekommen den neuen $new. Nicht, solange ein anderer Eintrag des Typs den alten
 * Titel noch trägt (doppelte Werte zählen in der Auswahl einmal). Läuft in der Transaktion des Speicherns.
 */
function content_types_rename_option(string $type, int $id, mixed $old, mixed $new): void
{
    if (!is_string($old) || !is_string($new) || $old === '' || $new === '' || $old === $new) {
        return;
    }
    $targets = [];
    foreach (content_types_list_names() as $name) {
        try {
            $def = content_types_read($name);
        } catch (Throwable $e) {
            continue;
        }
        foreach (content_types_schema_columns($def) as $field) {
            if ($field['type'] === 'select' && ($field['optionsFrom'] ?? null) === $type) {
                $targets[$name][] = $field['name'];
            }
        }
    }
    if ($targets === []) {
        return;
    }
    $title = (string) content_types_title_field(content_types_read($type));
    foreach (content_types_fetch_list($type, null) as $row) {
        if ((int) $row['id'] !== $id && ($row[$title] ?? null) === $old) {
            return;
        }
    }
    $select = db()->prepare('SELECT id, data FROM content_items WHERE content_type = ?');
    $update = db()->prepare('UPDATE content_items SET data = ?, updated_at = ? WHERE id = ?');
    $now = db_now();
    foreach ($targets as $name => $names) {
        $select->execute([$name]);
        foreach ($select->fetchAll() as $row) {
            $data = json_decode((string) $row['data'], true);
            if (!is_array($data)) {
                continue;
            }
            $changed = false;
            foreach ($names as $field) {
                if (($data[$field] ?? null) === $old) {
                    $data[$field] = $new;
                    $changed = true;
                }
            }
            if ($changed) {
                $update->execute([plugin_schema_json($data), $now, $row['id']]);
            }
        }
    }
}

/** Legt einen Eintrag mit geprüften Werten (content_types_values) am Ende der Liste an; liefert die id. */
function content_types_insert(string $type, array $values): int
{
    $stmt = db()->prepare('SELECT MAX(sort_order) FROM content_items WHERE content_type = ?');
    $stmt->execute([$type]);
    $max = $stmt->fetchColumn();
    $sortOrder = $max === null ? 0 : (int) $max + 1;

    $now = db_now();
    $stmt = db()->prepare('INSERT INTO content_items (content_type, data, sort_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$type, plugin_schema_json($values), $sortOrder, $now, $now]);
    return (int) db()->lastInsertId();
}

/**
 * Importiert $entries (Liste von Einträgen, höchstens CONTENT_TYPES_IMPORT_MAX) ganz oder gar nicht: jeder
 * wird wie beim Speichern geprüft (content_types_values), ein action muss der Typ erlauben (ohne gilt
 * defaultAction), Bilder müssen vorhandene Dateien sein (upload_image_exists). Neue Einträge kommen in
 * dieser Reihenfolge ans Ende; Adressen (slug) sind eindeutig, auch untereinander, weil jeder Eintrag in
 * derselben Transaktion eingefügt ist, bevor der nächste geprüft wird. Liefert die Anzahl.
 * Wirft InvalidArgumentException (Liste, Anzahl, kein Objekt) bzw. PluginFieldException mit entry.
 */
function content_types_import(string $type, mixed $entries): int
{
    if (!content_types_name_valid($type)) {
        throw new InvalidArgumentException(API_TEXT['invalidType']);
    }
    if (!is_array($entries) || array_values($entries) !== $entries) {
        throw new InvalidArgumentException(CONTENT_TYPES_IMPORT_TEXT['notList']);
    }
    if ($entries === []) {
        throw new InvalidArgumentException(CONTENT_TYPES_IMPORT_TEXT['empty']);
    }
    if (count($entries) > CONTENT_TYPES_IMPORT_MAX) {
        throw new InvalidArgumentException(sprintf(CONTENT_TYPES_IMPORT_TEXT['tooMany'], CONTENT_TYPES_IMPORT_MAX));
    }
    $def = content_types_load($type);
    $fields = content_types_schema_columns($def);

    $pdo = db();
    $pdo->beginTransaction();
    try {
        foreach ($entries as $index => $entry) {
            if (!is_array($entry) || ($entry !== [] && array_values($entry) === $entry)) {
                throw new InvalidArgumentException(sprintf(CONTENT_TYPES_IMPORT_TEXT['entry'], $index + 1));
            }
            try {
                content_types_insert($type, content_types_import_values($def, $fields, $entry));
            } catch (PluginFieldException $e) {
                $e->entry = $index + 1;
                throw $e;
            }
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }

    return count($entries);
}

/**
 * Werte eines importierten Eintrags: content_types_values, dazu nur erlaubte Ziele (außer action ist ein
 * eigenes Feld des Typs, bei genau einem Ziel erlaubt) und vorhandene Bilder ($fields: content_types_schema_columns).
 * Bilder zählen wie angegeben und bereinigt: Ein Wert, den die Bereinigung leert (data:, ftp: …), wird abgelehnt.
 * Die angegebenen prüft es vor content_types_values: Fehlt ein Upload, gilt diese Meldung, nicht die des Speicherns.
 */
function content_types_import_values(array $def, array $fields, array $entry): array
{
    $ownAction = in_array('action', array_column($fields, 'name'), true);
    if (!$ownAction && array_key_exists('action', $entry) && !content_types_action_allowed($def, $entry['action'])) {
        $message = sprintf(CONTENT_TYPES_IMPORT_TEXT['action'], implode(', ', $def['actions']));
        throw plugin_schema_field_error('action', CONTENT_TYPES_ACTION_FIELDS['action'], $message);
    }
    $requireImages = static function (array $values) use ($fields): void {
        foreach ($fields as $field) {
            foreach (plugin_schema_image_values([$field], $values) as $url) {
                if (trim($url) !== '' && !upload_image_exists(trim($url))) {
                    $message = sprintf(CONTENT_TYPES_IMPORT_TEXT['image'], UPLOADS_URL, LE_SITE_FILES_URL);
                    throw plugin_schema_field_error($field['name'], plugin_schema_field_label($field), $message);
                }
            }
        }
    };
    $requireImages($entry);
    $values = content_types_values($def, $entry, null);
    $requireImages($values);

    return $values;
}

/** Meldung zu einem ungültigen importierten Eintrag: „Zeile 3, Titel: Pflichtfeld ist leer.“ */
function content_types_import_message(PluginFieldException $e): string
{
    return sprintf(CONTENT_TYPES_IMPORT_TEXT['line'], $e->entry, $e->label, $e->reason);
}

/**
 * Tauscht einen Eintrag mit seinem Nachbarn ($step -1 = nach oben, 1 = nach unten) bzw. mit dem
 * Eintrag $with (sichtbarer Nachbar in einer gefilterten oder gekürzten Liste; die übrigen bleiben,
 * wo sie sind) und nummeriert den Typ dabei durch. Liefert false, wenn es einen der Einträge nicht
 * gibt, er schon am Rand steht oder der Typ nach einem Feld sortiert (orderBy).
 */
function content_types_move(string $type, int $id, int $step, ?int $with = null): bool
{
    if (!content_types_name_valid($type) || $id <= 0) {
        return false;
    }
    // Mit orderBy bestimmt das Feld die Reihenfolge, von Hand verschieben gibt es nicht.
    if (isset(content_types_load($type)['orderBy'])) {
        return false;
    }
    $stmt = db()->prepare('SELECT id FROM content_items WHERE content_type = ? ORDER BY ' . CONTENT_TYPES_ORDER);
    $stmt->execute([$type]);
    $ids = array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));

    $pos = array_search($id, $ids, true);
    $target = $pos === false ? false : ($with === null ? $pos + $step : array_search($with, $ids, true));
    if ($target === false || $target === $pos || $target < 0 || $target >= count($ids)) {
        return false;
    }
    [$ids[$pos], $ids[$target]] = [$ids[$target], $ids[$pos]];

    $pdo = db();
    $update = $pdo->prepare('UPDATE content_items SET sort_order = ? WHERE content_type = ? AND id = ?');
    $pdo->beginTransaction();
    try {
        foreach ($ids as $index => $itemId) {
            $update->execute([$index, $type, $itemId]);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }

    return true;
}

/** Löscht den Eintrag samt seinen Bildern, sofern sie sonst nirgends verwendet werden (core/uploads.php). */
function content_types_delete(string $type, int $id): void
{
    if (!content_types_name_valid($type) || $id <= 0) {
        return;
    }
    plugin_delete_entry('content-types', $id, ['content_type' => $type]);
}

/**
 * Hook image_values (core/uploads.php): Bildwerte einer Zeile aus content_items laut Typ-Definition.
 * Für die Felder reicht content_types_read: Auch ein bei den Klickzielen ungültiger Typ verliert beim
 * Löschen eines Eintrags seine Bilder.
 */
function content_types_image_values(array $row): array
{
    return plugin_schema_image_values(content_types_schema_columns(content_types_read((string) $row['content_type'])), content_types_expand_row($row));
}

/** Hook upload_in_use (core/uploads.php): verweist ein Eintrag irgendeines Typs auf die Upload-Datei? */
function content_types_upload_in_use(string $file): bool
{
    $stmt = db()->prepare('SELECT 1 FROM content_items WHERE INSTR(data, ?) > 0 LIMIT 1');
    $stmt->execute([$file]);

    return $stmt->fetchColumn() !== false;
}
