<?php
declare(strict_types=1);

require_once __DIR__ . '/plugins.php';

function plugin_main_table(array $manifest): ?string
{
    $tables = $manifest['tables'] ?? [];
    if (!is_array($tables) || empty($tables)) {
        return null;
    }

    $name = $tables[0];
    if (!is_string($name) || !plugin_table_name_valid($name)) {
        return null;
    }

    return $name;
}

function plugin_schema_columns(array $manifest): array
{
    $fields = $manifest['schema']['fields'] ?? [];
    if (!is_array($fields)) {
        return [];
    }

    $columns = [];
    foreach ($fields as $field) {
        if (!is_array($field)) {
            continue;
        }
        $name = $field['name'] ?? null;
        if (!is_string($name) || !plugin_table_name_valid($name)) {
            continue;
        }
        $columns[] = plugin_schema_field($field);
    }

    return $columns;
}

/**
 * Feld aus dem Schema mit Art (Vorgabe text); ein list-Feld nur mit gültigen Unterfeldern
 * (plugin_schema_list_fields) und gültigem min/max (plugin_schema_list_limits), auch fürs Formular.
 * Ohne showWhen: Felder, die von anderen abhängen, gibt es nur für die Klickziele der Content-Typen
 * (content_types_form_columns), nicht im Schema eines Plugins oder Typs.
 */
function plugin_schema_field(array $field): array
{
    unset($field['showWhen']);
    $field['type'] = is_string($field['type'] ?? null) ? $field['type'] : 'text';
    if ($field['type'] === 'list') {
        $field['fields'] = plugin_schema_list_fields($field);
        [$field['min'], $field['max']] = plugin_schema_list_limits($field);
    }

    return $field;
}

/**
 * Unterfelder eines list-Feldes: Name wie ein Spaltenname, Art aus PLUGIN_SCHEMA_LIST_FIELD_TYPES
 * (Vorgabe text); andere fallen weg, wie ungültige Felder in plugin_schema_columns.
 */
function plugin_schema_list_fields(array $field): array
{
    $fields = [];
    foreach (is_array($field['fields'] ?? null) ? $field['fields'] : [] as $sub) {
        if (!is_array($sub) || !is_string($sub['name'] ?? null) || !plugin_table_name_valid($sub['name'])) {
            continue;
        }
        $sub['type'] = is_string($sub['type'] ?? null) ? $sub['type'] : 'text';
        if (in_array($sub['type'], PLUGIN_SCHEMA_LIST_FIELD_TYPES, true)) {
            $fields[] = $sub;
        }
    }

    return $fields;
}

/**
 * min/max eines list-Feldes: min ganze Zahl ab 0, max ab 1 (auch als Text wie „12“), max nicht unter min;
 * eine ungültige Angabe gilt als Vorgabe (PLUGIN_SCHEMA_LIST_MIN/MAX), bei max unter min beide.
 */
function plugin_schema_list_limits(array $field): array
{
    $min = filter_var($field['min'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);
    $max = filter_var($field['max'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $min = $min === false ? PLUGIN_SCHEMA_LIST_MIN : $min;
    $max = $max === false ? PLUGIN_SCHEMA_LIST_MAX : $max;

    return $max >= $min ? [$min, $max] : [PLUGIN_SCHEMA_LIST_MIN, PLUGIN_SCHEMA_LIST_MAX];
}

/** Zeilen eines list-Wertes, als Array oder gespeichert als JSON-Text (Spalte); alles außer Objekten fällt weg. */
function plugin_schema_list_rows(mixed $value): array
{
    if (is_string($value)) {
        $value = json_decode($value, true);
    }

    return is_array($value) ? array_values(array_filter($value, 'is_array')) : [];
}

/** Zeile einer Tabelle mit list-Feldern als Zeilen statt JSON-Text (generische Plugins), z. B. fürs Formular. */
function plugin_schema_decode_row(array $fields, array $row): array
{
    foreach ($fields as $field) {
        if ($field['type'] === 'list' && array_key_exists($field['name'], $row)) {
            $row[$field['name']] = plugin_schema_list_rows($row[$field['name']]);
        }
    }

    return $row;
}

/** Werte für Tabellenspalten: list-Zeilen als JSON-Text (plugin_schema_json). */
function plugin_schema_column_values(array $values): array
{
    return array_map(static fn (mixed $value): mixed => is_array($value) ? plugin_schema_json($value) : $value, $values);
}

/**
 * Eintragswerte als JSON: Pfade unmaskiert („/public/site/uploads/…“), damit die Suche nach Upload-Dateien
 * (INSTR in plugin_schema_upload_in_use und Hooks wie content_types_upload_in_use) sie findet.
 */
function plugin_schema_json(array $values): string
{
    $json = json_encode($values, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        throw new RuntimeException('Cannot encode item data');
    }

    return $json;
}

function plugin_schema_field_names(array $manifest): array
{
    return array_map(static fn (array $field): string => $field['name'], plugin_schema_columns($manifest));
}

/** Werte der Bildfelder eines Eintrags (Upload-Pfade), auch aus Zeilen von list-Feldern, z. B. zum Aufräumen beim Löschen. */
function plugin_schema_image_values(array $fields, array $row): array
{
    $values = [];
    foreach ($fields as $field) {
        $value = $row[$field['name']] ?? null;
        if (($field['type'] ?? '') === 'list') {
            foreach (plugin_schema_list_rows($value) as $item) {
                array_push($values, ...plugin_schema_image_values(plugin_schema_list_fields($field), $item));
            }
        } elseif (($field['type'] ?? '') === 'image' && is_string($value) && $value !== '') {
            $values[] = $value;
        }
    }

    return $values;
}

/** Zeile $id der Haupttabelle $table eines Plugins (generische Plugins), null ohne. */
function plugin_fetch_row(string $table, int $id): ?array
{
    $stmt = db()->prepare("SELECT * FROM `{$table}` WHERE `id` = ? LIMIT 1");
    $stmt->execute([$id]);
    $row = $stmt->fetch();

    return $row ?: null;
}

/**
 * Ob eine Spalte aus schema.fields der Haupttabelle die Upload-Datei $file enthält (Bildfeld, Bild in einer
 * Zeile eines list-Feldes oder Verweis im Text). Gilt für jedes Plugin mit Schema, auch ohne lib.php (generisches Admin-Formular).
 */
function plugin_schema_upload_in_use(array $manifest, string $file): bool
{
    $table = plugin_main_table($manifest);
    $columns = plugin_schema_field_names($manifest);
    if ($table === null || $columns === []) {
        return false;
    }
    $where = implode(' OR ', array_map(static fn (string $column): string => "INSTR(`{$column}`, ?) > 0", $columns));
    $stmt = db()->prepare("SELECT 1 FROM `{$table}` WHERE {$where} LIMIT 1");
    $stmt->execute(array_fill(0, count($columns), $file));

    return $stmt->fetchColumn() !== false;
}

// Slug: Umlaute werden umgeschrieben, alles außer a–z und 0–9 wird zu „-“; bleibt nichts übrig, gilt die Vorgabe.
const PLUGIN_SLUG_TRANSLITERATION = ['ä' => 'ae', 'ö' => 'oe', 'ü' => 'ue', 'ß' => 'ss'];
const PLUGIN_SLUG_FALLBACK = 'item';
// Höchstlänge eines Slugs aus slugify: Spaltenlänge (VARCHAR(255)) abzüglich Platz für „-n“
// aus plugin_unique_slug; die Umschreibung (ä → ae) kann Text verlängern.
const PLUGIN_SLUG_MAX_LENGTH = 240;
// Format eines Slugs, wie plugin_schema_slugify ihn erzeugt (z. B. für Adressen, die einen Slug enthalten).
const PLUGIN_SLUG_PATTERN = '/^[a-z0-9]+(?:-[a-z0-9]+)*$/';
// Meldung für ein leeres Pflichtfeld (Beschriftung wie im Formular: label, sonst Name).
const PLUGIN_SCHEMA_REQUIRED_MESSAGE = 'Bitte „%s“ ausfüllen.';
// Gründe ohne Feldnamen (PluginFieldException::$reason), wo die Meldung das Feld nennt: Pflichtfeld leer,
// zu wenige bzw. zu viele Zeilen eines list-Feldes. Dazu die Meldung zu einem ungültigen Wert (Beschriftung,
// Grund) und die Beschriftung eines Unterfeldes (Zeile mit itemLabel, sonst label, und Nummer ab 1; Unterfeld).
const PLUGIN_SCHEMA_REQUIRED_REASON = 'Pflichtfeld ist leer.';
const PLUGIN_SCHEMA_LIST_MIN_REASON = 'Mindestens %d.';
const PLUGIN_SCHEMA_LIST_MAX_REASON = 'Höchstens %d.';
const PLUGIN_SCHEMA_FIELD_MESSAGE = '%s: %s';
const PLUGIN_SCHEMA_FIELD_PATH = '%s %d › %s';
// Feldart url: Schemata wie Links im Text (TEXT_LINK_SCHEMES) oder ein Pfad mit diesem Anfang; sonst die Meldung.
const PLUGIN_SCHEMA_URL_PATH_STARTS = ['/', '#'];
const PLUGIN_SCHEMA_URL_MESSAGE = 'Bitte eine Adresse wie https://… eingeben.';
// Feldart date: kein gültiger Kalendertag.
const PLUGIN_SCHEMA_DATE_MESSAGE = 'Bitte ein gültiges Datum eingeben.';
// Wert eines Feldes außer list ist ein Objekt oder eine Liste (z. B. aus einem Import), statt Text, Zahl oder Ja/Nein.
const PLUGIN_SCHEMA_SCALAR_MESSAGE = 'Hier gehört ein einzelner Wert hin, keine Liste und kein Objekt.';
// Feldart list: erlaubte Arten der Unterfelder, Vorgaben für min/max und Meldungen bei zu wenigen bzw. zu
// vielen Zeilen (Anzahl, dann bei genau 1 itemLabel, sonst die Beschriftung des Feldes).
const PLUGIN_SCHEMA_LIST_FIELD_TYPES = ['text', 'textarea', 'richtext', 'image', 'url', 'number', 'boolean', 'select', 'icon'];
const PLUGIN_SCHEMA_LIST_MIN = 0;
const PLUGIN_SCHEMA_LIST_MAX = 50;
const PLUGIN_SCHEMA_LIST_MIN_MESSAGE = 'Mindestens %d %s.';
const PLUGIN_SCHEMA_LIST_MAX_MESSAGE = 'Höchstens %d %s.';
// Meldungen und Status, wenn ein Plugin-Eintrag an der Datenbank oder an seiner Definition scheitert
// (plugin_failure_response; Details nur ins Server-Log, nie Rohtext an den Browser).
const PLUGIN_FAILED_TEXT = [
    'load' => 'Die Einträge konnten nicht geladen werden.',
    'save' => 'Der Eintrag konnte nicht gespeichert werden.',
    'delete' => 'Der Eintrag konnte nicht gelöscht werden.',
    'sort' => 'Die Reihenfolge konnte nicht geändert werden.',
    'import' => 'Die Einträge konnten nicht importiert werden.',
];
const PLUGIN_FAILED_STATUS = 500;

/**
 * Ungültiger Wert eines Feldes (plugin_schema_values): die Meldung wie beim Speichern, dazu Feld (Name,
 * bei Unterfeldern „liste.unterfeld“), Beschriftung und der Grund ohne Feldnamen (z. B. für „Zeile 3,
 * Titel: Pflichtfeld ist leer.“ beim Import). $entry setzt, wer mehrere Einträge prüft (Zeile ab 1).
 */
class PluginFieldException extends InvalidArgumentException
{
    public string $reason;
    public ?int $entry = null;

    public function __construct(public string $field, public string $label, string $message, ?string $reason = null)
    {
        parent::__construct($message);
        $this->reason = $reason ?? $message;
    }
}

/** Antwort, wenn $action ('load', 'save', 'delete', 'sort', 'import') an $e scheitert: Meldung aus PLUGIN_FAILED_TEXT, Fehler ins Log. */
function plugin_failure_response(string $action, Throwable $e): void
{
    error_log('plugin ' . $action . ': ' . $e->getMessage());
    json_response(['ok' => false, 'error' => PLUGIN_FAILED_TEXT[$action]], PLUGIN_FAILED_STATUS);
}

function plugin_schema_slugify(string $value): string
{
    $value = strtr(mb_strtolower(trim($value), 'UTF-8'), PLUGIN_SLUG_TRANSLITERATION);
    $value = preg_replace('/[^a-z0-9]+/', '-', $value) ?? '';
    $value = trim(substr(trim($value, '-'), 0, PLUGIN_SLUG_MAX_LENGTH), '-');

    return $value !== '' ? $value : PLUGIN_SLUG_FALLBACK;
}

/** Slug, der in $table.$column noch frei ist, sonst mit -2, -3 …; die Zeile $id selbst zählt nicht. */
function plugin_unique_slug(string $table, string $column, string $slug, ?int $id): string
{
    $stmt = db()->prepare("SELECT 1 FROM `{$table}` WHERE `{$column}` = ? AND `id` <> ? LIMIT 1");

    return plugin_unique_slug_with($slug, static function (string $candidate) use ($stmt, $id): bool {
        $stmt->execute([$candidate, $id ?? 0]);
        $taken = $stmt->fetchColumn() !== false;
        $stmt->closeCursor();
        return $taken;
    });
}

/** $slug, wenn $taken($slug) false ist, sonst der erste freie mit -2, -3 … (auch für Slugs außerhalb einer Spalte, z. B. im JSON eines Eintrags). */
function plugin_unique_slug_with(string $slug, callable $taken): string
{
    $candidate = $slug;
    for ($n = 2; $taken($candidate); $n++) {
        $candidate = $slug . '-' . $n;
    }

    return $candidate;
}

/** Beschriftung eines Feldes wie im Formular: label, sonst der Name. */
function plugin_schema_field_label(array $field): string
{
    return is_string($field['label'] ?? null) && $field['label'] !== '' ? $field['label'] : $field['name'];
}

/** Fehler für ein leeres Pflichtfeld: Meldung wie im Formular, Grund ohne Feldnamen. */
function plugin_schema_required_error(array $field): PluginFieldException
{
    return plugin_schema_field_error($field['name'], plugin_schema_field_label($field), PLUGIN_SCHEMA_REQUIRED_REASON);
}

/**
 * Fehler des Feldes $name mit dem Grund $reason (ohne Feldnamen); die Meldung nennt die Beschriftung:
 * „Link: Bitte eine Adresse wie https://… eingeben.“, beim leeren Pflichtfeld „Bitte „Link“ ausfüllen.“.
 */
function plugin_schema_field_error(string $name, string $label, string $reason): PluginFieldException
{
    $message = $reason === PLUGIN_SCHEMA_REQUIRED_REASON
        ? sprintf(PLUGIN_SCHEMA_REQUIRED_MESSAGE, $label)
        : sprintf(PLUGIN_SCHEMA_FIELD_MESSAGE, $label, $reason);

    return new PluginFieldException($name, $label, $message, $reason);
}

/** Ob ein bereinigter Wert leer ist: leerer Text, keine Zahl, keine Zeile, Richtext ohne Text (z. B. „<p><br></p>“, „&nbsp;“). */
function plugin_schema_blank(array $field, mixed $value): bool
{
    if (($field['type'] ?? '') === 'richtext' && is_string($value)) {
        $value = preg_replace('/[\s\x{A0}]+/u', '', html_entity_decode(strip_tags($value), ENT_QUOTES | ENT_HTML5, 'UTF-8')) ?? $value;
    }

    return $value === '' || $value === null || $value === [];
}

/**
 * Werte eines Eintrags nach schema.fields: nur Felder, die in $rawValues stehen, normalisiert;
 * ein fehlendes oder leeres Pflichtfeld wirft PluginFieldException mit deutscher Meldung, ebenso
 * ein ungültiger Wert (url, Zeilen eines list-Feldes; plugin_schema_normalize_value).
 * $stored ist die gespeicherte Zeile beim Bearbeiten (leer beim Anlegen): Ein unverändert
 * mitgeschickter Slug bleibt, wie er ist (auch älter und länger als PLUGIN_SLUG_MAX_LENGTH), ebenso ein
 * gespeichertes Bild, dessen Upload-Datei inzwischen fehlt (le_upload_missing prüft nur neue).
 */
function plugin_schema_values(array $fields, array $rawValues, array $stored = []): array
{
    $values = [];
    $storedImages = plugin_schema_image_values($fields, $stored);
    foreach ($fields as $field) {
        $key = $field['name'];
        if (!array_key_exists($key, $rawValues)) {
            if (!empty($field['required'])) {
                throw plugin_schema_required_error($field);
            }
            // Fehlt ein list-Feld, gilt der gespeicherte Stand (beim Anlegen keine Zeile), damit min greift.
            if (($field['type'] ?? '') === 'list') {
                plugin_schema_list_values($field, $stored[$key] ?? []);
            }
            continue;
        }
        if (($field['type'] ?? '') === 'slug' && is_string($stored[$key] ?? null) && $stored[$key] !== '' && $rawValues[$key] === $stored[$key]) {
            $values[$key] = $stored[$key];
            continue;
        }
        $normalized = plugin_schema_field_value($field, $rawValues[$key], $rawValues, $storedImages);
        if (!empty($field['required']) && plugin_schema_blank($field, $normalized)) {
            throw plugin_schema_required_error($field);
        }
        $values[$key] = $normalized;
    }

    return $values;
}

/**
 * plugin_schema_normalize_value mit dem Feld am Fehler: eine Meldung ohne Feld (url) wird zur
 * PluginFieldException dieses Feldes, die es nennt (plugin_schema_field_error); die aus list-Zeilen nennen
 * ihr Feld schon. Ein Objekt oder eine Liste als Wert eines Feldes außer list wird abgelehnt
 * (PLUGIN_SCHEMA_SCALAR_MESSAGE), nicht zu „Array“. $storedImages wie bei plugin_schema_normalize_value.
 */
function plugin_schema_field_value(array $field, mixed $value, array $allValues, array $storedImages = []): mixed
{
    if (($field['type'] ?? '') !== 'list' && is_array($value)) {
        throw plugin_schema_field_error($field['name'], plugin_schema_field_label($field), PLUGIN_SCHEMA_SCALAR_MESSAGE);
    }
    try {
        return plugin_schema_normalize_value($field, $value, $allValues, $storedImages);
    } catch (PluginFieldException $e) {
        throw $e;
    } catch (InvalidArgumentException $e) {
        throw plugin_schema_field_error($field['name'], plugin_schema_field_label($field), $e->getMessage());
    }
}

/**
 * Wert eines Feldes nach seiner Art bereinigt; $allValues sind alle Werte des Eintrags (Slug aus „from“).
 * Wirft InvalidArgumentException mit deutscher Meldung bei einer url außerhalb der erlaubten Adressen
 * (Meldung ohne Feldnamen, das Feld setzt plugin_schema_field_value) und bei ungültigen Zeilen eines
 * list-Feldes (plugin_schema_list_values, PluginFieldException), ebenso bei einem Bild aus den Uploads, dessen Datei
 * fehlt, außer es steht in $storedImages (gespeicherte Bildwerte des Eintrags, le_upload_missing).
 */
function plugin_schema_normalize_value(array $field, mixed $value, array $allValues, array $storedImages = []): mixed
{
    $type = (string) ($field['type'] ?? 'text');

    if ($type === 'slug') {
        // Ohne strip_tags: Aus „Ich <3 Wien“ wird „ich-3-wien“, nicht „ich“ (slugify lässt nur a–z, 0–9 und - übrig).
        $text = trim((string) $value);
        if ($text === '' && is_string($field['from'] ?? null)) {
            $text = trim((string) ($allValues[$field['from']] ?? ''));
        }
        return plugin_schema_slugify($text);
    }

    if ($type === 'richtext') {
        return plugin_sanitize_richtext((string) $value);
    }

    if ($type === 'boolean') {
        return !empty($value) && $value !== '0' && $value !== 'false' ? '1' : '0';
    }

    if ($type === 'number') {
        return is_numeric($value) ? (string) $value : null;
    }

    if ($type === 'datetime') {
        $text = trim((string) $value);
        if ($text === '') {
            return null;
        }
        $text = str_replace('T', ' ', $text);
        if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $text)) {
            $text .= ':00';
        }
        return preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $text) ? $text : null;
    }

    // Kalendertag „YYYY-MM-DD“ (wie <input type="date"> ihn schickt); leer null, ein ungültiger Tag (31.02.) wirft.
    if ($type === 'date') {
        $text = trim((string) $value);
        if ($text === '') {
            return null;
        }
        $date = DateTimeImmutable::createFromFormat('!Y-m-d', $text);
        if ($date === false || $date->format('Y-m-d') !== $text) {
            throw new InvalidArgumentException(PLUGIN_SCHEMA_DATE_MESSAGE);
        }
        return $text;
    }

    // Bilder wie Bildfelder der Seiten (sanitize_field_value): nur http(s) und Pfade, kein javascript: oder data:.
    // Ein neuer Upload muss es noch geben (sonst verwiese der Eintrag still auf eine fehlende Datei, z. B. nach der Frist).
    // core/uploads.php erst hier laden: Nur Speicherwege brauchen es (es bindet diese Datei selbst ein).
    if ($type === 'image') {
        require_once __DIR__ . '/uploads.php';
        $url = sanitize_field_value('image', trim(strip_tags((string) $value)));
        if (le_upload_missing($url, $storedImages)) {
            throw new InvalidArgumentException(UPLOAD_TEXT['missing']);
        }
        return $url;
    }

    if ($type === 'url') {
        $text = trim(strip_tags((string) $value));
        $url = sanitize_url($text, TEXT_LINK_SCHEMES);
        $path = $url !== '' && in_array($url[0], PLUGIN_SCHEMA_URL_PATH_STARTS, true);
        if ($text !== '' && ($url === '' || (le_url_scheme($url) === null && !$path))) {
            throw new InvalidArgumentException(PLUGIN_SCHEMA_URL_MESSAGE);
        }
        return $url;
    }

    if ($type === 'list') {
        return plugin_schema_list_values($field, $value, $storedImages);
    }

    // Mehrzeiliger reiner Text, wörtlich gespeichert (kein strip_tags, „a<3“ bleibt): nur getrimmt, \r\n und \r
    // als \n, Steuerzeichen außer Tab und Umbruch fallen weg. Escaped wird erst bei der Ausgabe (le_text_lines,
    // ct_lines, content_types_plain).
    if ($type === 'textarea') {
        return trim(preg_replace(['/\r\n?/', '/[\x00-\x08\x0B-\x1F\x7F]/'], ["\n", ''], (string) $value) ?? '');
    }

    // Name eines Icons aus dem Satz des Seiten-Editors (LE_ICON_SET), sonst ''; erst hier laden, der Satz ist groß.
    if ($type === 'icon') {
        require_once __DIR__ . '/icons.php';
        return le_icon_name((string) $value);
    }

    if ($type === 'select') {
        $text = sanitize_plain_text((string) $value);
        if ($text === '') {
            return '';
        }
        $options = is_array($field['options'] ?? null)
            ? array_values(array_filter($field['options'], 'is_string'))
            : [];
        return in_array($text, $options, true) ? $text : '';
    }

    // text (auch unbekannte Arten): einzeiliger reiner Text wie ein Alt-Text der Seiten (sanitize_plain_text), wörtlich
    // gespeichert (kein strip_tags, „a<3“ bleibt), Steuerzeichen als Leerzeichen. Escaped wird erst bei der Ausgabe.
    return sanitize_plain_text((string) $value);
}

/**
 * Zeilen eines list-Feldes: jede nur mit den Unterfeldern, jedes bereinigt wie ein eigenes Feld; Zeilen
 * ohne Wert (auch nur mit leerem Kästchen oder Richtext ohne Text) fallen weg. Wirft PluginFieldException, wenn in einer
 * vorhandenen Zeile ein Unterfeld ungültig oder ein Pflicht-Unterfeld leer ist (Feld „liste.unterfeld“, Beschriftung
 * PLUGIN_SCHEMA_FIELD_PATH mit der Nummer der Zeile, z. B. „Punkt 2 › Link“) und bei weniger als min bzw. mehr
 * als max Zeilen (Feld der Liste). $storedImages wie bei plugin_schema_normalize_value.
 */
function plugin_schema_list_values(array $field, mixed $value, array $storedImages = []): array
{
    $fields = plugin_schema_list_fields($field);
    $label = plugin_schema_field_label($field);
    $rowLabel = plugin_schema_item_label($field) ?? $label;
    $subError = static fn (array $sub, int $index, PluginFieldException $e): PluginFieldException => plugin_schema_field_error(
        $field['name'] . '.' . $sub['name'],
        sprintf(PLUGIN_SCHEMA_FIELD_PATH, $rowLabel, $index + 1, plugin_schema_field_label($sub)),
        $e->reason
    );
    $rows = [];
    foreach (plugin_schema_list_rows($value) as $index => $raw) {
        $row = [];
        $filled = false;
        foreach ($fields as $sub) {
            try {
                $normalized = plugin_schema_field_value($sub, $raw[$sub['name']] ?? '', $raw, $storedImages);
            } catch (PluginFieldException $e) {
                throw $subError($sub, $index, $e);
            }
            $row[$sub['name']] = $normalized;
            $filled = $filled || !(plugin_schema_blank($sub, $normalized) || ($sub['type'] === 'boolean' && $normalized === '0'));
        }
        if (!$filled) {
            continue;
        }
        foreach ($fields as $sub) {
            if (!empty($sub['required']) && plugin_schema_blank($sub, $row[$sub['name']])) {
                throw $subError($sub, $index, plugin_schema_required_error($sub));
            }
        }
        $rows[] = $row;
    }

    [$min, $max] = plugin_schema_list_limits($field);
    if (count($rows) < $min) {
        throw new PluginFieldException($field['name'], $label, plugin_schema_list_count_message(PLUGIN_SCHEMA_LIST_MIN_MESSAGE, $field, $min), sprintf(PLUGIN_SCHEMA_LIST_MIN_REASON, $min));
    }
    if (count($rows) > $max) {
        throw new PluginFieldException($field['name'], $label, plugin_schema_list_count_message(PLUGIN_SCHEMA_LIST_MAX_MESSAGE, $field, $max), sprintf(PLUGIN_SCHEMA_LIST_MAX_REASON, $max));
    }

    return $rows;
}

/** „Höchstens 12 Punkte.“: Meldung $format mit Anzahl und Wort (bei 1 itemLabel, sonst die Beschriftung). */
function plugin_schema_list_count_message(string $format, array $field, int $count): string
{
    $item = plugin_schema_item_label($field);

    return sprintf($format, $count, $count === 1 && $item !== null ? $item : plugin_schema_field_label($field));
}

/** Wort für eine Zeile eines list-Feldes (itemLabel, Singular); null ohne. */
function plugin_schema_item_label(array $field): ?string
{
    return is_string($field['itemLabel'] ?? null) && $field['itemLabel'] !== '' ? $field['itemLabel'] : null;
}
