<?php declare(strict_types=1);
require __DIR__ . '/../backend/base/paths.php';
require LE_BACKEND . '/site/router.php';
