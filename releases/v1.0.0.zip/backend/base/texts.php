<?php
declare(strict_types=1);

// Texte, die der Browser zeigt, an einer Stelle (AGENTS.md: Meldungen stehen in Konstanten).

// Meldungen der API-Endpoints und des Kerns (json_response 'error'), wie der Browser sie zeigt.
// %s: Datei bzw. Fehler der Gegenstelle, nie ein Serverpfad.
const API_TEXT = [
    'method' => 'Diese Anfrage-Methode ist hier nicht erlaubt.',
    'invalidRequest' => 'Ungültige Anfrage.',
    'invalidJson' => 'Die Anfrage enthält kein gültiges JSON.',
    'invalidPageName' => 'Ungültiger Seitenname.',
    'invalidContent' => 'Ungültige Inhalte.',
    'invalidType' => 'Unbekannter Typ.',
    'invalidId' => 'Ungültige ID.',
    'invalidTarget' => 'Ungültiges Ziel.',
    'notFound' => 'Nicht gefunden.',
    'entryConflict' => 'Jemand anderes hat diesen Eintrag inzwischen geändert.',
    'notAuthenticated' => 'Du bist nicht mehr angemeldet. Bitte melde dich neu an.',
    'passwordChange' => 'Bitte lege zuerst ein neues Passwort fest.',
    'forbidden' => 'Dafür fehlen dir die Rechte.',
    'csrf' => 'Die Anmeldung wurde erneuert. Bitte lade die Seite neu.',
    'invalidCredentials' => 'Benutzername oder Passwort ist falsch.',
    // Login-Seite ohne Benutzer und ohne brauchbares setup.php (le_setup_missing); %d: PASSWORD_MIN_LENGTH.
    'setupMissing' => 'Noch kein Zugang eingerichtet. Im Ordner der Website (website/, am Server der Kundenordner) setup.sample.php nach setup.php kopieren und Benutzername und Passwort (%d bis %d Byte) des ersten Admins eintragen.',
    'userNotFound' => 'Benutzer nicht gefunden.',
    'usernameTaken' => 'Dieser Benutzername ist schon vergeben.',
    'userIdRequired' => 'Benutzer-ID fehlt.',
    'wrongPassword' => 'Das aktuelle Passwort stimmt nicht.',
    'lastAdminDemote' => 'Der letzte Administrator kann nicht herabgestuft werden.',
    'lastAdminDelete' => 'Der letzte Administrator kann nicht gelöscht werden.',
    'deleteSelf' => 'Das eigene Konto kann nicht gelöscht werden.',
    // users.json ließ sich nicht sperren oder schreiben (le_users_update_or_fail).
    'usersSaveFailed' => 'Die Benutzer ließen sich nicht speichern.',
    'pageNotFound' => 'Seite nicht gefunden.',
    'pageInvalid' => 'Die gespeicherten Inhalte dieser Seite sind beschädigt.',
    'invalidBackup' => 'Ungültiger Name eines gespeicherten Stands.',
    'backupNotFound' => 'Diesen gespeicherten Stand gibt es nicht mehr.',
    'backupInvalid' => 'Dieser gespeicherte Stand ist beschädigt.',
    'backupFailed' => 'Der bisherige Stand ließ sich nicht sichern.',
    // Abgleich einer direkt geänderten Datei gescheitert (le_sync_request): getPage, Speichern und
    // Wiederherstellen antworten 422; %s = „Name: Grund“ je Datei, dazu contactSupport.
    'syncFailed' => 'Die Seite lässt sich gerade nicht bearbeiten: Eine direkte Änderung lässt sich nicht übernehmen (%s).',
    // Dasselbe für Kopf- oder Fußzeile: getPage und Wiederherstellen laufen weiter und melden es als message.
    'syncSkipped' => 'Eine direkte Änderung lässt sich gerade nicht übernehmen (%s), dieser Teil bleibt beim alten Stand.',
    // Server lässt nicht schreiben (write_failed_message): vorab erkannt mit den betroffenen Namen
    // (writeFailedNames), mittendrin ohne; dazu, wer helfen kann (contactSupport).
    'writeFailed' => 'Nichts gespeichert: Der Server lässt keine Änderung zu%s.',
    'writeFailedNames' => ' (%s)',
    'contactSupport' => 'Bitte gib LEWEB Bescheid.',
    'lockFailed' => 'Die Seite ließ sich nicht sperren.',
    'encodeFailed' => 'Die Inhalte ließen sich nicht speichern.',
    'importStatusFailed' => 'Der Import-Status ließ sich nicht speichern.',
    'discardUploadsFailed' => 'Verworfene Bilder ließen sich nicht aufräumen.',
    // Sperre der offenen Uploads (le_open_uploads_hold) zu lange belegt.
    'uploadsBusy' => 'Gerade wird anderswo gespeichert oder ein Bild bearbeitet. Bitte gleich noch einmal versuchen.',
    'invalidPlugin' => 'Ungültiger Plugin-Name.',
    'pluginNotFound' => 'Plugin nicht gefunden.',
    'pluginNotInstalled' => 'Das Plugin ist nicht installiert.',
    'pluginNotActive' => 'Das Plugin ist nicht aktiv.',
    'noMainTable' => 'Das Plugin hat keine Haupttabelle.',
    'pluginOwnEndpoint' => 'Das Plugin hat dafür eigene Endpoints.',
    'noValidFields' => 'Keine gültigen Felder.',
    'uninstallFailed' => 'Deinstallieren fehlgeschlagen.',
    'pluginInvalid' => 'Die Beschreibung des Plugins (plugin.json) ist ungültig.',
    'pluginStateFailed' => 'Der Plugin-Status ließ sich nicht speichern.',
    // %s: SQL-Datei des Plugins (Fehler der Datenbank nur ins Log, installSqlFailed).
    'pluginInstallFailed' => 'Die Tabellen des Plugins ließen sich nicht anlegen (%s).',
    'uploadsUnwritable' => 'Uploads-Verzeichnis nicht beschreibbar.',
    'mailUnavailable' => 'Kein Mailversand verfügbar. Bitte SMTP in den Einstellungen konfigurieren.',
    'dbFieldsRequired' => 'Host, Datenbankname und Benutzer sind Pflicht.',
    'connectionFailed' => 'Verbindung fehlgeschlagen: %s',
    // Nur fürs Server-Log: %1$s: SQL-Datei des Plugins, %2$s: Fehler der Datenbank.
    'installSqlFailed' => '%1$s ist fehlgeschlagen: %2$s',
    'testRecipient' => 'Gültige Test-Empfänger-Adresse erforderlich.',
    'testMailFailed' => 'Die Testmail ließ sich nicht senden. Bitte die Mail-Einstellungen prüfen.',
    'mailSaveFailed' => 'Die Mail-Einstellungen ließen sich nicht speichern.',
    'mailDeleteFailed' => 'Die Mail-Einstellungen ließen sich nicht löschen.',
    'siteBackupKeyFailed' => 'Der Backup-Schlüssel ließ sich nicht speichern.',
    'updateFailed' => 'Update fehlgeschlagen.',
    'rollbackFailed' => 'Rollback fehlgeschlagen.',
    // Prüfung von Benutzername, Passwort und Rolle (users_validate_*); %d: Grenze in Zeichen.
    'usernameRequired' => 'Bitte einen Benutzernamen angeben.',
    'usernameShort' => 'Der Benutzername braucht mindestens %d Zeichen.',
    'usernameLong' => 'Der Benutzername darf höchstens %d Zeichen haben.',
    'usernameChars' => 'Der Benutzername darf nur Buchstaben, Ziffern, Punkt, Unterstrich und Bindestrich enthalten.',
    'passwordShort' => 'Das Passwort braucht mindestens %d Zeichen.',
    'passwordLong' => 'Das Passwort darf höchstens %d Byte lang sein (Umlaute und Sonderzeichen zählen doppelt oder mehr).',
    'invalidRole' => 'Unbekannte Rolle.',
    'samePassword' => 'Bitte ein anderes Passwort wählen.',
    'invalidEmail' => 'Bitte eine gültige E-Mail-Adresse eingeben.',
    'invalidUrl' => 'Bitte eine gültige Adresse der Website eingeben, z. B. https://www.beispiel.at.',
    'invalidImage' => 'Vorschaubild: bitte eine Adresse auf der Website (z. B. /assets/img/vorschau.jpg) oder eine https-Adresse eingeben.',
];
