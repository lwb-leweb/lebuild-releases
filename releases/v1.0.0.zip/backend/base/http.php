<?php
declare(strict_types=1);

// HTTP für jedes Thema: Bearer-Token der Anfrage, JSON-Antwort und JSON-Körper, Range-Anfragen.

require_once LE_BACKEND . '/base/texts.php';

/**
 * Token aus „Authorization: Bearer …“ (Sicherungs-Schlüssel, Health-Token); ohne $header aus der Anfrage, auch
 * wenn CGI/FPM den Header nur über getallheaders() kennt. null, wenn der Header fehlt oder kein Bearer ist.
 */
function le_request_bearer(?string $header = null): ?string
{
    if ($header === null) {
        $header = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? null;
        if ($header === null && function_exists('getallheaders')) {
            foreach (getallheaders() as $name => $value) {
                if (strcasecmp((string) $name, 'Authorization') === 0) {
                    $header = (string) $value;
                }
            }
        }
    }
    return is_string($header) && preg_match('/^Bearer\s+(\S+)\s*$/i', $header, $m) ? $m[1] : null;
}

/**
 * Bereich aus „Range: bytes=…“ für eine Datei mit $size Bytes (RFC 9110): [erstes, letztes Byte] für einen Bereich
 * (a-b, a- bis zum Ende, -n die letzten n; ein Ende hinter der Datei wird gekürzt), false, wenn er nicht in der Datei
 * liegt (Antwort 416), null ohne Header, bei falscher Form oder mehreren Bereichen (dann ganze Datei, das erlaubt die RFC).
 */
function le_http_range(?string $header, int $size): array|false|null
{
    if ($header === null || !preg_match('/^bytes=(\d*)-(\d*)$/i', trim($header), $m) || $m[1] . $m[2] === '') {
        return null;
    }
    // Zahlen über PHP_INT_MAX: Ein Anfang dahinter liegt nie in der Datei, ein so langer Rest umfasst sie ganz.
    $number = static fn (string $digits): int => strlen(ltrim($digits, '0')) > 18 ? PHP_INT_MAX : (int) $digits;
    if ($m[1] === '') {
        $length = $number($m[2]);
        return $length === 0 || $size === 0 ? false : [max(0, $size - $length), $size - 1];
    }
    $first = $number($m[1]);
    $last = $m[2] === '' ? PHP_INT_MAX : $number($m[2]);
    if ($last < $first) {
        return null;
    }

    return $first >= $size ? false : [$first, min($last, $size - 1)];
}

// Jede API-Antwort ist persönlich oder hängt am Stand (Gast-bootstrap, 401): nie aus einem Cache, auch ohne Session.
function json_response(array $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function read_json_body(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return [];
    }

    $data = json_decode($raw, true);
    if (!is_array($data)) {
        json_response(['ok' => false, 'error' => API_TEXT['invalidJson']], 400);
    }

    return $data;
}

// Erlaubte Zeichen einer angefragten Datei unter frontend, einer Seite in der Sitemap und eines Bilds der Website in
// der Mediathek; „..“ ist zusätzlich verboten. Ausgeliefert werden Dateien unter public mit jedem UTF-8
// (le_site_decoded_path).
const LE_SITE_PATH_PATTERN = '#^[A-Za-z0-9_./@\-]+$#';
// Dateien, die der Router als Seite rendert (Shortcodes, Plugin-Filter, Editor); alles andere geht unverändert raus.
const LE_SITE_DOCUMENT_EXTENSIONS = ['php', 'html', 'htm'];

// Ordner unter public mit Teilen der Website (Kopf, Fuß, Vorlagen der Plugins): nie als eigene Adresse.
const LE_SITE_INCLUDES_DIR = 'includes';

/**
 * Adresse in einer Schreibweise, gegen die der Router alle Sperren prüft: Mehrfach-Slashes und „.“-Stücke
 * fallen weg (/./content//x → /content/x), ein Schrägstrich am Ende bleibt. null bei „..“-Stücken.
 */
function le_site_canonical_path(string $path): ?string
{
    $segments = [];
    foreach (explode('/', $path) as $part) {
        if ($part === '..') {
            return null;
        }
        if ($part !== '' && $part !== '.') {
            $segments[] = $part;
        }
    }
    $canonical = '/' . implode('/', $segments);

    return $segments !== [] && str_ends_with($path, '/') ? $canonical . '/' : $canonical;
}

/**
 * Kanonische Adresse mit dekodierten Stücken (/Team%20Foto.jpg → /Team Foto.jpg), gegen die le_site_request_file
 * alle Sperren prüft. null bei „..“, einem Stück, das dekodiert „.“ oder „..“ ist, mit „/“, „\\“, „:“ oder
 * „<>"*?|“ (Windows: Datenströme wie kontakt.php::$DATA, Platzhalter beim Auflösen), Steuerzeichen, ungültigem UTF-8, einem Punkt am Anfang (außer .well-known) oder
 * einem Leerzeichen oder Punkt am Ende (Windows: x.php. ist x.php): %2e%2e, %2F, %00, %2Egit.
 */
function le_site_decoded_path(string $path): ?string
{
    $canonical = le_site_canonical_path($path);
    if ($canonical === null) {
        return null;
    }
    $segments = [];
    foreach (explode('/', trim($canonical, '/')) as $part) {
        if ($part === '') {
            continue;
        }
        $part = rawurldecode($part);
        if (($part[0] === '.' && $part !== '.well-known') || strpbrk($part, '/\\:<>"*?|') !== false || str_ends_with($part, ' ') || str_ends_with($part, '.')
            || preg_match('/[\x00-\x1F\x7F]/', $part) || !preg_match('//u', $part)) {
            return null;
        }
        $segments[] = $part;
    }
    $decoded = '/' . implode('/', $segments);

    return $segments !== [] && str_ends_with($canonical, '/') ? $decoded . '/' : $decoded;
}

/**
 * Datei unter public für die Adresse $path (wie im Browser, %XX dekodiert le_site_decoded_path), wie der Router
 * sie ausliefert, null ohne:
 *   /                → index.{php,html}
 *   /imprint         → imprint, imprint.{php,html} oder imprint/index.{php,html}
 *   /public/site/x   → x (kanonisch)
 */
function le_site_request_file(string $path): ?string
{
    $path = le_site_decoded_path($path);
    if ($path === null) {
        return null;
    }
    if (str_starts_with($path, LE_SITE_FILES_URL)) {
        $relative = substr($path, strlen(LE_SITE_FILES_URL));
    } elseif ($path === '/') {
        $relative = '';
    } else {
        $relative = ltrim($path, '/');
    }
    $relative = rtrim($relative, '/');

    if (str_contains($relative, '..')) {
        return null;
    }
    // Teile der Website sind keine Adresse (/includes/…, /public/site/includes/…, groß/klein egal). Auf Dateisystemen,
    // die Namen gleichsetzen (ohne Groß/klein, „ſ“ = „s“, 8.3-Namen), zählt derselbe Ordner unter jedem Namen.
    $first = explode('/', $relative)[0];
    $includes = @stat(LE_SITE_ROOT . '/' . LE_SITE_INCLUDES_DIR);
    $firstStat = $first === '' ? false : @stat(LE_SITE_ROOT . '/' . $first);
    if (strtolower($first) === LE_SITE_INCLUDES_DIR
        || ($includes !== false && $firstStat !== false && $includes['ino'] !== 0
            && [$includes['dev'], $includes['ino']] === [$firstStat['dev'], $firstStat['ino']])) {
        return null;
    }

    $candidates = [];
    if ($relative === '') {
        $candidates[] = LE_SITE_ROOT . '/index.php';
        $candidates[] = LE_SITE_ROOT . '/index.html';
    } else {
        $candidates[] = LE_SITE_ROOT . '/' . $relative;
        if (!le_site_is_document($relative)) {
            $candidates[] = LE_SITE_ROOT . '/' . $relative . '.php';
            $candidates[] = LE_SITE_ROOT . '/' . $relative . '.html';
            $candidates[] = LE_SITE_ROOT . '/' . $relative . '/index.php';
            $candidates[] = LE_SITE_ROOT . '/' . $relative . '/index.html';
        }
    }

    // Auch nicht unter anderem Namen (Windows: „includes.“, Kurznamen INCLUD~1 bzw. ENV~1 für .env; macOS: Groß/klein):
    // der echte Pfad darf weder unter includes liegen noch ein Stück mit Punkt am Anfang haben (außer .well-known).
    // Verknüpfungen (auf Dateien oder Ordner, auch mittendrin) gelten nur mit Ziel unter der Wurzel (le_site_file_inside),
    // sonst wie eine fehlende Datei.
    $lowerReal = static fn (string $file): ?string => ($real = @realpath($file)) !== false ? strtolower(str_replace('\\', '/', $real)) : null;
    foreach ($candidates as $candidate) {
        if (is_file($candidate)) {
            $real = $lowerReal($candidate);
            $root = $lowerReal(LE_SITE_ROOT);
            $includes = $lowerReal(LE_SITE_ROOT . '/' . LE_SITE_INCLUDES_DIR);
            if ($real !== null && $includes !== null && str_starts_with($real, $includes . '/')) {
                return null;
            }
            if (!le_site_file_inside($candidate)) {
                continue;
            }
            foreach (explode('/', substr($real, strlen($root) + 1)) as $segment) {
                if ($segment !== '' && $segment[0] === '.' && $segment !== '.well-known') {
                    return null;
                }
            }
            return $candidate;
        }
    }

    return null;
}

/**
 * Ob $file nach Auflösen aller Verknüpfungen unter der aufgelösten Wurzel der Website liegt (LE_SITE_ROOT, die selbst ein
 * Link sein darf: Mehrfachbetrieb, Deploy), Groß/klein genau. Die eine Grenze für alles, was der Kern aus public/ ausliefert
 * (le_site_request_file), als Startseite prüft (Health) und als Seite importiert und speichert (page_extension,
 * le_import_sources). Das PHP der Website liest private/ weiter über Dateipfade.
 */
function le_site_file_inside(string $file): bool
{
    $real = realpath($file);
    $root = realpath(LE_SITE_ROOT);

    return $real !== false && $root !== false && str_starts_with($real, $root . DIRECTORY_SEPARATOR);
}

/** Ob $file (Datei oder Adresse) ein Dokument der Website ist (LE_SITE_DOCUMENT_EXTENSIONS). */
function le_site_is_document(string $file): bool
{
    return in_array(strtolower(pathinfo($file, PATHINFO_EXTENSION)), LE_SITE_DOCUMENT_EXTENSIONS, true);
}
