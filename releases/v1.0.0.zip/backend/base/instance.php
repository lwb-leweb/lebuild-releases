<?php
declare(strict_types=1);

// Welche Website dieser Prozess bedient. Der Code (backend/, plugins/, frontend/) liegt in LE_ROOT,
// die Daten der Website (setup.php, private/, public/ samt Uploads) in LE_INSTANCE_ROOT: in einer Einzelinstallation
// website/ im Hauptordner, mit mehreren Websites auf einem Server (ein Checkout für alle) je Kunde ein Kundenordner mit
// demselben Aufbau unter LEBUILD_SITES (knowledgebase/architecture.md, „Mehrere Websites“).
// backend/base/paths.php bindet die Datei nach den Code-Ordnern ein; so läuft sie auch für Website-PHP, Plugin-Endpoints und ops/.

// Ordner der Website ohne LEBUILD_SITE und LEBUILD_SITES (Einzelinstallation), relativ zum Hauptordner; le_instance_is_multi
// vergleicht mit ihm, nie mit dem Code-Ordner. Aufgelöst wie LE_ROOT (auch wenn website/ selbst ein Symlink ist).
const LE_INSTANCE_DEFAULT_DIR = 'website';
define('LE_INSTANCE_DEFAULT_ROOT', realpath(LE_ROOT . '/' . LE_INSTANCE_DEFAULT_DIR) ?: LE_ROOT . '/' . LE_INSTANCE_DEFAULT_DIR);

// Ordner mit den Kundenordnern und LE_INSTANCE_DOMAINS_FILE; der Host der Anfrage wählt den Kundenordner.
const LE_INSTANCE_SITES_ENV = 'LEBUILD_SITES';
// Domain der Vorschau-Adressen <kurzname>.<domain>, z. B. vorschau.leweb.at.
const LE_INSTANCE_PREVIEW_ENV = 'LEBUILD_PREVIEW_DOMAIN';
// Genau ein Kundenordner (Kommandozeile, Tests, Dev-Server). Hat Vorrang vor LEBUILD_SITES, der Host zählt dann nicht.
const LE_INSTANCE_SITE_ENV = 'LEBUILD_SITE';
// Kurzname eines Kunden: Name seines Ordners, seiner Vorschau-Adresse und seines Repos; höchstens 40 Zeichen, „-“ wie
// im Hostnamen nicht am Rand (sonst wäre die Vorschau-Adresse kein Hostname).
const LE_INSTANCE_NAME_PATTERN = '/^[a-z0-9]([a-z0-9-]{0,38}[a-z0-9])?$/';
// Hostname: Teile aus Buchstaben, Ziffern und „-“ (nicht am Rand), durch Punkte getrennt, höchstens 253 Zeichen.
const LE_INSTANCE_HOST_PATTERN = '/^(?=.{1,253}$)[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$/';
// Hauptdomain → Kurzname ({"leweb.at": "leweb"}), gepflegt von ops/tools/sites.php.
const LE_INSTANCE_DOMAINS_FILE = 'domains.json';
// Gegenform einer Hauptdomain, die per 301 auf sie weiterleitet (leweb.at ↔ www.leweb.at).
const LE_INSTANCE_WWW_PREFIX = 'www.';
// Vorschau-Adressen nimmt keine Suchmaschine auf, nur die echte Domain.
const LE_INSTANCE_PREVIEW_ROBOTS = 'noindex, nofollow';
// Ordner mit den privaten Daten einer Website (Benutzer, Schlüssel, Datenbank, Cache) und ihr Cache, relativ zum Ordner der
// Website (LE_INSTANCE_ROOT oder ein Kundenordner): Daraus entstehen CONTENT_ROOT und CACHE_ROOT (backend/base/paths.php), und so
// liest le_instance_live_domain die Notiz eines fremden Kundenordners.
const LE_INSTANCE_PRIVATE_DIR = 'private';
const LE_INSTANCE_CACHE_DIR = LE_INSTANCE_PRIVATE_DIR . '/cache';
// Im Kundenordner: die Domain, unter der die Website schon per HTTPS aufgerufen wurde (le_instance_note_live). Ein
// Aufruf über HTTPS heißt: Es gibt ein Zertifikat, ihr DNS hat also hierher gezeigt. Stimmt sie mit domains.json
// überein, leitet die Vorschau-Adresse per 301 dorthin weiter; vorher bleibt die Vorschau zum Aufbauen nutzbar.
const LE_INSTANCE_LIVE_FILE = LE_INSTANCE_CACHE_DIR . '/live-domain';
// Meldungen beim Start (Kommandozeile bzw. Fehlerprotokoll des Servers); %s: Wert von LEBUILD_SITE.
const LE_INSTANCE_TEXT = [
    'cliSite' => LE_INSTANCE_SITES_ENV . ' ist gesetzt: Auf der Kommandozeile mit ' . LE_INSTANCE_SITE_ENV . ' den Kundenordner angeben.',
    'siteMissing' => LE_INSTANCE_SITE_ENV . ' zeigt auf keinen Ordner: %s',
    // Fehlerprotokoll; %s: Pfad, der weder unter LE_INSTANCE_ROOT noch unter LE_ROOT liegt.
    'foreignPath' => 'Pfad liegt außerhalb der Website (LE_INSTANCE_ROOT): %s',
];
// Übergang (kann weg, wenn alle Kundenordner und Checkouts umgestellt sind, Phase 10): Namen des früheren Aufbaus im Ordner
// der Website (bzw. bei der Einzelinstallation im Hauptordner). Ein Ordner damit wird nie bedient und nie beschrieben:
// Unter dem neuen Kern liefe die Website unter /site/…, includes/ wäre als Seite erreichbar, und der erste Aufruf legte
// private/ mit neuem Schlüssel an.
// Eine übrige config.php allein gilt nicht als alt (die Website läuft, die Systemprüfung warnt bei einem Passwort darin).
const LE_INSTANCE_LEGACY_SETUP = 'config.php';
const LE_INSTANCE_LEGACY_PRIVATE = 'content';
const LE_INSTANCE_LEGACY_SITE = 'public/site';
// Weg in den neuen Aufbau, alter Name => neuer (Meldungen, le_instance_legacy_way), und wo er beschrieben ist.
const LE_INSTANCE_LEGACY_MOVES = [
    LE_INSTANCE_LEGACY_PRIVATE . '/' => LE_INSTANCE_PRIVATE_DIR . '/',
    LE_INSTANCE_LEGACY_SITE . '/' => 'public/',
    LE_INSTANCE_LEGACY_SETUP => 'setup.php',
];
const LE_INSTANCE_LEGACY_GUIDE = 'ops/README.md';
// Fehlerprotokoll bzw. Kommandozeile; %1$s: Ordner, %2$s: Fund (le_instance_legacy), %3$s: Weg (le_instance_legacy_way).
const LE_INSTANCE_LEGACY_TEXT = 'Ordner der Website im alten Aufbau (%2$s gefunden): %1$s. Erst umstellen: %3$s';
// Antwort an den Browser, solange ein Ordner im alten Aufbau liegt (ohne Pfade oder Gründe).
const LE_INSTANCE_LEGACY_BODY = 'Die Website ist gerade nicht erreichbar.';

/** Host (HTTP_HOST, Caddys ?domain=) in vergleichbarer Form: klein, ohne Port und Punkt am Ende (auch für eigene Links, le_url_link_attrs). */
function le_host_normalize(string $host): string
{
    $host = (string) preg_replace('/:\d*$/', '', strtolower(trim($host)));

    return str_ends_with($host, '.') ? substr($host, 0, -1) : $host;
}

/** Liegt der Host $host unter der Domain $domain (x.vorschau.leweb.at unter vorschau.leweb.at, nicht sie selbst)? */
function le_host_under(string $host, string $domain): bool
{
    return str_ends_with($host, '.' . $domain);
}

/** Host wie die Auflösung ihn vergleicht (le_host_normalize); null, wenn er kein Hostname ist. */
function le_instance_host(string $host): ?string
{
    $host = le_host_normalize($host);

    return preg_match(LE_INSTANCE_HOST_PATTERN, $host) ? $host : null;
}

/** Kundenordner $name unter $sites, null bei ungültigem Kurznamen oder ohne Ordner. */
function le_instance_site_dir(string $sites, string $name): ?string
{
    if (!preg_match(LE_INSTANCE_NAME_PATTERN, $name)) {
        return null;
    }
    $dir = realpath($sites . '/' . $name);

    return $dir !== false && is_dir($dir) ? $dir : null;
}

/** Inhalt von domains.json unter $sites: [Domain => Kurzname], leer ohne lesbare Datei. */
function le_instance_domains(string $sites): array
{
    $domains = json_decode((string) @file_get_contents($sites . '/' . LE_INSTANCE_DOMAINS_FILE), true);

    return is_array($domains) ? array_filter($domains, 'is_string') : [];
}

/** www-Gegenform eines Hosts: leweb.at ↔ www.leweb.at (Weiterleitung; ops/tools/sites.php vergibt beide nur an einen Kunden). */
function le_instance_www_counterpart(string $host): string
{
    return str_starts_with($host, LE_INSTANCE_WWW_PREFIX) ? substr($host, strlen(LE_INSTANCE_WWW_PREFIX)) : LE_INSTANCE_WWW_PREFIX . $host;
}

/** Domain des Kunden $name aus $domains, wenn sie laut LE_INSTANCE_LIVE_FILE in seinem Ordner $dir schon online ist. */
function le_instance_live_domain(array $domains, string $name, string $dir): ?string
{
    $domain = array_search($name, $domains, true);

    return is_string($domain) && (string) @file_get_contents($dir . '/' . LE_INSTANCE_LIVE_FILE) === $domain ? $domain : null;
}

/**
 * Kundenordner für den Host $host unter $sites, in dieser Reihenfolge: Vorschau-Adresse <kurzname>.$previewDomain
 * mit vorhandenem Ordner (Weiterleitung auf die Domain, sobald sie online ist: le_instance_live_domain), Domain aus
 * domains.json, die www-Gegenform einer eingetragenen Domain (Weiterleitung).
 * ['dir' => Ordner|null, 'preview' => bool, 'redirect' => Domain|null]; dir und redirect null: unbekannt (404).
 * Einzige Rechenweise für die Anfrage (le_instance_boot) und Caddys Zertifikats-Frage (ops/deploy/tls-ask.php).
 */
function le_instance_resolve(string $host, string $sites, string $previewDomain): array
{
    $none = ['dir' => null, 'preview' => false, 'redirect' => null];
    $host = le_instance_host($host);
    if ($host === null) {
        return $none;
    }
    $domains = le_instance_domains($sites);
    $preview = le_instance_host($previewDomain);
    if ($preview !== null && le_host_under($host, $preview)) {
        $name = substr($host, 0, -strlen($preview) - 1);
        $dir = le_instance_site_dir($sites, $name);
        if ($dir !== null) {
            $live = le_instance_live_domain($domains, $name, $dir);
            return $live !== null
                ? ['dir' => null, 'preview' => false, 'redirect' => $live]
                : ['dir' => $dir, 'preview' => true, 'redirect' => null];
        }
    }
    $dir = le_instance_site_dir($sites, $domains[$host] ?? '');
    if ($dir !== null) {
        return ['dir' => $dir, 'preview' => false, 'redirect' => null];
    }
    $other = le_instance_www_counterpart($host);
    if (le_instance_site_dir($sites, $domains[$other] ?? '') !== null) {
        return ['dir' => null, 'preview' => false, 'redirect' => $other];
    }

    return $none;
}

/**
 * Ordner der Website dieses Prozesses (LE_INSTANCE_ROOT): LEBUILD_SITE, sonst im Mehrfachbetrieb (LEBUILD_SITES)
 * der Kundenordner zum Host, sonst LE_INSTANCE_DEFAULT_ROOT. Antwortet selbst, wo es keinen Ordner gibt: 301 auf die
 * eingetragene Form der Domain, 404 ohne Inhalt. Vorschau-Antworten bekommen X-Robots-Tag. Auf der Kommandozeile
 * gibt es keinen Host: Mit LEBUILD_SITES, aber ohne LEBUILD_SITE bricht sie ab, statt still im Code-Ordner zu schreiben.
 */
function le_instance_boot(): string
{
    $site = (string) getenv(LE_INSTANCE_SITE_ENV);
    if ($site !== '') {
        $dir = realpath($site);
        if ($dir === false || !is_dir($dir)) {
            le_instance_stop(sprintf(LE_INSTANCE_TEXT['siteMissing'], $site));
        }
        return $dir;
    }
    $sites = (string) getenv(LE_INSTANCE_SITES_ENV);
    if ($sites === '') {
        return LE_INSTANCE_DEFAULT_ROOT;
    }
    if (PHP_SAPI === 'cli') {
        le_instance_stop(LE_INSTANCE_TEXT['cliSite']);
    }

    $found = le_instance_resolve((string) ($_SERVER['HTTP_HOST'] ?? ''), $sites, (string) getenv(LE_INSTANCE_PREVIEW_ENV));
    if ($found['redirect'] !== null) {
        header('Location: https://' . $found['redirect'] . ($_SERVER['REQUEST_URI'] ?? '/'), true, 301);
        exit;
    }
    if ($found['dir'] === null) {
        http_response_code(404);
        exit;
    }
    if ($found['preview']) {
        header('X-Robots-Tag: ' . LE_INSTANCE_PREVIEW_ROBOTS);
    } elseif (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        // Aufruf über die echte Domain per HTTPS; backend/base/files.php merkt ihn sich (le_instance_note_live).
        define('LE_INSTANCE_LIVE_HOST', le_host_normalize((string) $_SERVER['HTTP_HOST']));
    }

    return $found['dir'];
}

/**
 * Hält LE_INSTANCE_LIVE_FILE auf der Domain, unter der diese Anfrage per HTTPS kam (le_instance_boot); schreibt nur,
 * wenn sie sich ändert. Ruft backend/base/files.php am Ende auf, wenn write_file_atomic samt Konstanten bereitsteht.
 */
function le_instance_note_live(): void
{
    if (!defined('LE_INSTANCE_LIVE_HOST')) {
        return;
    }
    $file = LE_INSTANCE_ROOT . '/' . LE_INSTANCE_LIVE_FILE;
    if ((string) @file_get_contents($file) === LE_INSTANCE_LIVE_HOST) {
        return;
    }
    try {
        write_file_atomic($file, LE_INSTANCE_LIVE_HOST);
    } catch (RuntimeException $e) {
        error_log('live-domain: ' . $e->getMessage());
    }
}

/**
 * Abbruch beim Start: Meldung auf STDERR mit Exit-Code 1, im Webserver $status samt $body (ohne Pfade) und Eintrag im
 * Fehlerprotokoll.
 */
function le_instance_stop(string $message, int $status = 500, string $body = ''): void
{
    if (PHP_SAPI === 'cli') {
        fwrite(STDERR, $message . "\n");
        exit(1);
    }
    error_log($message);
    http_response_code($status);
    if ($body !== '') {
        header('Content-Type: text/plain; charset=utf-8');
        header('Retry-After: 3600');
        echo $body;
    }
    exit;
}

/**
 * Übergang (Phase 10): Fund des früheren Aufbaus einer Website in $dir (content/ bzw. public/site/), sonst null. content/
 * gibt es im neuen Aufbau nie, public/site/ zählt, solange public/ selbst keine Startseite hat (im neuen Aufbau darf die
 * Website einen Ordner site/ haben, im alten lag alles darunter). Auch gemischt (private/ und content/ zugleich) gilt als
 * alt. Einzige Erkennung, auch für ops/tools/sites.php.
 */
function le_instance_legacy(string $dir): ?string
{
    $public = dirname($dir . '/' . LE_INSTANCE_LEGACY_SITE);
    if (is_dir($dir . '/' . LE_INSTANCE_LEGACY_PRIVATE)) {
        return LE_INSTANCE_LEGACY_PRIVATE . '/';
    }
    return is_dir($dir . '/' . LE_INSTANCE_LEGACY_SITE) && glob($public . '/index.{php,html}', GLOB_BRACE) === [] ? LE_INSTANCE_LEGACY_SITE . '/' : null;
}

/** Übergang (Phase 10): Weg in den neuen Aufbau für Meldungen, z. B. „content/ → private/, …, Anleitung: ops/README.md“. */
function le_instance_legacy_way(): string
{
    $moves = array_map(static fn (string $old, string $new): string => $old . ' → ' . $new, array_keys(LE_INSTANCE_LEGACY_MOVES), LE_INSTANCE_LEGACY_MOVES);
    return implode(', ', $moves) . ', Anleitung: ' . LE_INSTANCE_LEGACY_GUIDE;
}

/** Übergang (Phase 10): Ordner, in denen alte Daten dieser Website liegen können; in der Einzelinstallation auch der Hauptordner. */
function le_instance_legacy_dirs(): array
{
    return le_instance_is_multi() ? [LE_INSTANCE_ROOT] : [LE_INSTANCE_ROOT, LE_ROOT];
}

/**
 * Ob dieser Prozess die Website eines Kundenordners bedient (Mehrfachbetrieb oder LEBUILD_SITE), nicht die aus dem
 * Standardordner LE_INSTANCE_DEFAULT_ROOT; LEBUILD_SITE auf diesen Ordner (auch über einen Symlink) ist keiner.
 */
function le_instance_is_multi(): bool
{
    return LE_INSTANCE_ROOT !== LE_INSTANCE_DEFAULT_ROOT;
}

/**
 * $path relativ zum Ordner der Website (private/cache/x), wie Meldungen, Systemprüfung und Sicherung ihn zeigen. Ein
 * Code-Pfad (auch plugins/) liegt nie darin, auch nicht in der Einzelinstallation (website/): so ein Fehler im Aufrufer wie
 * jeder andere Pfad außerhalb, LogicException statt still abgeschnittener Zeichen oder Code unter dem Namen von Kundendaten.
 */
function le_instance_relative(string $path): string
{
    if ($path === LE_INSTANCE_ROOT || !le_path_in($path, [LE_INSTANCE_ROOT])) {
        throw new LogicException(sprintf(LE_INSTANCE_TEXT['foreignPath'], $path));
    }
    return substr($path, strlen(LE_INSTANCE_ROOT) + 1);
}

// LE_INSTANCE_LOOKUP_ONLY: Der Prozess bedient selbst keine Website und schreibt keine Daten einer Website, auch wenn
// LEBUILD_SITES gesetzt ist: ops/deploy/tls-ask.php (Caddy fragt über 127.0.0.1 nach einer anderen Domain), der
// Elternprozess von ops/tools/sites.php und ops/tools/backup-pull.php. LE_INSTANCE_ROOT ist dann der Standardordner, damit
// backend/base/paths.php die Datenordner definieren kann; solche Prozesse nutzen nur Helfer mit ausdrücklichem Pfad, nie CONTENT_ROOT & Co.
define('LE_INSTANCE_ROOT', defined('LE_INSTANCE_LOOKUP_ONLY') ? LE_INSTANCE_DEFAULT_ROOT : le_instance_boot());
// Übergang (Phase 10): Ordner im alten Aufbau vor allem anderen abweisen, bevor etwas gelesen oder angelegt wird (503). In der
// Einzelinstallation lagen die Daten früher im Hauptordner.
if (!defined('LE_INSTANCE_LOOKUP_ONLY')) {
    foreach (le_instance_legacy_dirs() as $leLegacyDir) {
        $leLegacyFound = le_instance_legacy($leLegacyDir);
        if ($leLegacyFound !== null) {
            le_instance_stop(sprintf(LE_INSTANCE_LEGACY_TEXT, $leLegacyDir, $leLegacyFound, le_instance_legacy_way()), 503, LE_INSTANCE_LEGACY_BODY);
        }
    }
    unset($leLegacyDir, $leLegacyFound);
}
