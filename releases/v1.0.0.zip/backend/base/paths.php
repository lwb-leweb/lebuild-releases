<?php
declare(strict_types=1);

// Alle Ordner von Code und Website als Konstanten, dazu feste Adressen, die mehrere Themen brauchen (Login- und
// Startadresse, Versions-Manifest). Ein Umzug eines Ordners ist eine Zeile hier.

// Hauptordner des Codes (backend/, frontend/, plugins/). __DIR__ ist schon aufgelöst (PHP folgt Symlinks), wie
// LE_INSTANCE_ROOT per realpath: le_instance_is_multi vergleicht so auch unter Symlinks richtig.
define('LE_ROOT', dirname(__DIR__, 2));
// PHP-Kern; Kern-Dateien laden einander nur über diese Konstante.
const LE_BACKEND = LE_ROOT . '/backend';
// Browser-Code der Verwaltung und des Seiten-Editors (Adresse /admin/…).
const LE_FRONTEND = LE_ROOT . '/frontend';
// Shell der Verwaltung (nur für Admins) und Login-Seite (/login), beide liefert der Router aus.
const LE_ADMIN_SHELL_FILE = LE_FRONTEND . '/app/index.html';
const LE_LOGIN_PAGE_FILE = LE_FRONTEND . '/app/login.html';
// Plugins, je Ordner eins (Adresse /plugins/<name>/…).
const LE_PLUGINS = LE_ROOT . '/plugins';
// Endpunkte (Adresse /api/…); welche Datei unter welcher Adresse läuft, steht nur in LE_API_ROUTES_FILE.
const LE_API = LE_BACKEND . '/api';
const LE_API_ROUTES_FILE = LE_API . '/routes.php';
// Plugin-Schnittstelle: Der Kern lädt sie vor jedem Plugin-Code, Plugins laden keine Kern-Datei selbst.
const LE_PLUGIN_API_FILE = LE_BACKEND . '/plugins/api.php';
// Einziger Ordner, den der Webserver ausliefert: der Einstieg index.php (lädt den Router) und die .htaccess für Apache.
const LE_WEBROOT = LE_ROOT . '/webroot';
// Apache ohne einstellbaren Webroot: Die .htaccess im Hauptordner schickt alles nach LE_WEBROOT.
const LE_ROOT_HTACCESS_FILE = LE_ROOT . '/.htaccess';
// Versions-Manifest relativ zum Hauptordner, hier wie im Release-ZIP (knowledgebase/release.md).
const LE_RELEASE_PATH = 'release.json';

// LE_INSTANCE_ROOT: Daten dieser Website; in einer Einzelinstallation website/ im Hauptordner.
require_once LE_BACKEND . '/base/instance.php';

// public/ der Website: Seiten, Assets und Uploads (Adresse /public/site/…). Die Verwaltung (frontend/) ist Code und liegt
// immer unter LE_ROOT.
define('PUBLIC_ROOT', LE_INSTANCE_ROOT . '/public');
define('LE_SITE_ROOT', PUBLIC_ROOT);
define('CONTENT_ROOT', LE_INSTANCE_ROOT . '/' . LE_INSTANCE_PRIVATE_DIR);
// Persistente Konfiguration bleibt direkt unter private/ (users.json,
// plugins.json, config.json, content-types/, labels/). Alles, was sich aus
// public/ + dem Importer rekonstruieren lässt — Seiten-JSON, Backups,
// Originale, Import-Status, Updater-Runtime-State — landet unter
// private/cache/ und ist gefahrlos wegwerfbar.
define('CACHE_ROOT', LE_INSTANCE_ROOT . '/' . LE_INSTANCE_CACHE_DIR);
define('PAGES_ROOT', CACHE_ROOT . '/pages');
define('BACKUPS_ROOT', CACHE_ROOT . '/backups');
define('ORIGINALS_ROOT', CACHE_ROOT . '/originals');
// Einstellungen der Website (Backend → Einstellungen: name, url, email …); lesen über le_site_config().
const LE_SITE_CONFIG_FILE = CONTENT_ROOT . '/config.json';
// Kanonischer URL-Pfad der Website-Dateien unter LE_SITE_ROOT (le_site_request_file). Präfix LE_: Der Kern läuft im
// selben Prozess wie das PHP der Website, die eigene Namen wie SITE_URL definiert (public/includes/config.php).
const LE_SITE_FILES_URL = '/public/site/';
// Hochgeladene Bilder liegen bei den übrigen Bildern der Website, in einem eigenen Ordner, der nie ins Git kommt
// (.gitignore, sites_gitignore_lines): Gesichert werden sie mit der Sicherung, nicht im Repo.
const LE_SITE_UPLOADS_DIR = 'uploads';
define('UPLOADS_ROOT', LE_SITE_ROOT . '/' . LE_SITE_UPLOADS_DIR);
// URL-Pfad, unter dem api/upload.php hochgeladene Dateien ausliefert (Bildfelder speichern ihn so).
const UPLOADS_URL = LE_SITE_FILES_URL . LE_SITE_UPLOADS_DIR . '/';
// Zugangsdaten (db.config.php, mail.config.php): unter private/, damit Backups
// sie erfassen und Updates sie nicht anfassen.
define('CONFIG_ROOT', CONTENT_ROOT . '/config');
// Plugin-Daten in SQLite (Standard, solange keine MySQL-Config existiert).
define('DATA_ROOT', CONTENT_ROOT . '/data');
// Altdaten nach einem Treiber-Umzug (nicht im Cache, damit sie im Backup landen).
define('DB_ARCHIVE_ROOT', CONTENT_ROOT . '/db-archiv');
// Schlüssel der Installation (app_secret), Benutzer (users_path), Stand der Sicherung (site_backup_state_path).
const LE_SECRET_FILE = CONTENT_ROOT . '/secret.key';
const LE_USERS_FILE = CONTENT_ROOT . '/users.json';
const LE_BACKUP_STATE_FILE = CONTENT_ROOT . '/backup.json';
// Daten mit Geheimnissen, die der Kern nur für den Eigentümer schreibt (write_private_file, SQLite per chmod);
// Ordner mit allem darunter. Einzige Liste dafür: Das Einspielen einer Sicherung setzt genau hier PRIVATE_FILE_MODE
// (le_private_data), alles andere bekommt die Rechte neuer Dateien. Das Aktivitäts-Log und private/cache/ sind nicht in
// der Sicherung.
const LE_PRIVATE_DATA = [LE_SECRET_FILE, LE_USERS_FILE, LE_BACKUP_STATE_FILE, CONFIG_ROOT, DATA_ROOT, DB_ARCHIVE_ROOT];

// Alte Namen für das PHP der Website (public/includes/, Vorlagen der Content-Typen und Kundenseiten, die daraus
// entstanden sind; includes/config.php der Kunden lädt heute LE_PROJECT_ROOT . '/core/siteRoutes.php', das seit dem Umzug nach
// backend/ abbricht – Phase 10 stellt die Kunden-Repos vorher um und entfernt die Zeile). Der Kern selbst nutzt
// LE_ROOT und LE_SITE_ROOT. Nicht entfernen, solange Seiten sie nutzen.
define('LE_PROJECT_ROOT', LE_ROOT);
define('PROJECT_ROOT', LE_ROOT);
define('SITE_ROOT', LE_SITE_ROOT);

// Adressen der Endpunkte (Router, api/routes.php) und der Plugin-Dateien (/plugins/<name>/api|assets|admin/…).
const LE_API_URL = '/api/';
const PLUGINS_URL = '/plugins/';
// Ordner eines Plugins, deren Dateien unter PLUGINS_URL . '<name>/<ordner>/…' ausgeliefert werden: für die Website und
// für die Verwaltung.
const LE_PLUGIN_SITE_FILES_DIR = 'assets';
const LE_PLUGIN_ADMIN_FILES_DIR = 'admin';
// Login-Seite (liefert der Router aus); `?next=` nennt das Ziel nach dem Login, siehe safe_redirect_path().
const LOGIN_URL = '/login';
// Ziel, wenn `next` fehlt oder nicht auf diese Website zeigt; Editoren landen von /admin aus hier.
const LE_SITE_HOME_URL = '/';
// Alter Name für Kundenseiten, die ihn nutzen; der Kern nutzt LE_SITE_HOME_URL.
if (!defined('SITE_HOME_URL')) {
    define('SITE_HOME_URL', LE_SITE_HOME_URL);
}
// Versions-Manifest des Kerns (Version, managedPaths, minPhp; knowledgebase/release.md).
const LE_RELEASE_FILE = LE_ROOT . '/' . LE_RELEASE_PATH;
// Version ohne lesbares Manifest.
const LE_RELEASE_VERSION_NONE = '0.0.0';

/** Inhalt von LE_RELEASE_FILE; [] ohne Datei oder ohne JSON-Objekt. Liest jedes Mal neu (der Rollback tauscht die Datei). */
function le_release_manifest(): array
{
    $data = is_file(LE_RELEASE_FILE) ? json_decode((string) file_get_contents(LE_RELEASE_FILE), true) : null;
    return is_array($data) ? $data : [];
}

/** Version des laufenden Kerns aus LE_RELEASE_FILE (Sicherung, Updater). */
function le_release_version(): string
{
    return (string) (le_release_manifest()['version'] ?? LE_RELEASE_VERSION_NONE);
}

// Fotos der Website (Endungen) kommen nie ins Git, auch nicht im Kundenordner (sites_gitignore_lines): Personenfotos
// ließen sich aus der Historie nicht löschen, und das Repo wüchse mit jedem Bild. SVG (Logos, Icons) schon.
const LE_SITE_PHOTO_EXTENSIONS = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'avif'];
// Lokale Kopie einer Website: Fehlende Bilder (Fotos und Uploads, nie im Git) leitet der Router auf dieselbe Adresse
// dieser Website um, z. B. https://kunde.at (Env-Variable, nur http/https mit Host, ohne Query).
const LE_IMAGES_FROM_ENV = 'LEBUILD_IMAGES_FROM';
const LE_IMAGES_FROM_PATTERN = '#^https?://[^/\s?\#@]+(/[^\s?\#]*)?$#i';

// Fehler im Aufrufer: le_root_relative mit einem Pfad, der nicht unter LE_ROOT liegt (im Mehrfachbetrieb auch die Daten
// eines Kundenordners).
const LE_ROOT_FOREIGN_PATH_TEXT = 'Pfad liegt außerhalb des Hauptordners (LE_ROOT): %s';

/**
 * $path (unter LE_ROOT) relativ zum Hauptordner, wie das Release-ZIP und managedPaths ihn nennen. LE_ROOT selbst und Pfade
 * außerhalb (auch ein ähnlicher Name wie LE_ROOT . '-alt'): LogicException statt still abgeschnittener Zeichen.
 */
function le_root_relative(string $path): string
{
    if ($path === LE_ROOT || !le_path_in($path, [LE_ROOT])) {
        throw new LogicException(sprintf(LE_ROOT_FOREIGN_PATH_TEXT, $path));
    }
    return substr($path, strlen(LE_ROOT) + 1);
}

/** Ist $path einer der Pfade $dirs oder liegt darunter? Ganze Segmente: „private/configx“ liegt nicht in „private/config“. */
function le_path_in(string $path, array $dirs): bool
{
    foreach ($dirs as $dir) {
        if ($path === $dir || str_starts_with($path, $dir . '/')) {
            return true;
        }
    }
    return false;
}

/** Gehört $path (absolut) zu LE_PRIVATE_DATA, ist also nur für den Eigentümer lesbar? */
function le_private_data(string $path): bool
{
    return le_path_in($path, LE_PRIVATE_DATA);
}
