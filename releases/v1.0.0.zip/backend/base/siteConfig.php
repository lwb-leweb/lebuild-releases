<?php
declare(strict_types=1);

// Einstellungen der Website (Verwaltung → Einstellungen: Name, Adresse, E-Mail …), mit Vorgaben, solange nichts gespeichert ist.

require_once LE_BACKEND . '/base/files.php';
require_once LE_BACKEND . '/base/http.php';
require_once LE_BACKEND . '/base/texts.php';

// Vorgaben, solange nichts gespeichert ist: neutral wie in public/includes/config.php, nie die Daten
// des Anbieters (sonst übernimmt sie das erste Speichern der Einstellungen).
const LE_SITE_CONFIG_DEFAULTS = [
    'name' => 'LeBuild',
    'tagline' => 'Wir denken Websites neu',
    'url' => 'https://example.com',
    'email' => 'office@example.com',
    'owner' => 'Dein Name',
    'locale' => 'de_AT',
    'image' => '',
];
// Einstellung „Vorschaubild“ (Schlüssel image): Adresse auf der Website (/assets/share.jpg) oder https-Adresse (site/seo.php).
const LE_SEO_IMAGE_PATTERN = '#^(?:/[A-Za-z0-9._~/%-]+|https://[A-Za-z0-9.-]+(?::\d+)?/[A-Za-z0-9._~/%-]*)$#';

/** Einstellungen der Website (LE_SITE_CONFIG_FILE); [] ohne Datei oder bei kaputtem JSON. */
function le_site_config(): array
{
    $config = is_file(LE_SITE_CONFIG_FILE) ? json_decode((string) file_get_contents(LE_SITE_CONFIG_FILE), true) : null;

    return is_array($config) ? $config : [];
}

/** le_site_config() über den Vorgaben (LE_SITE_CONFIG_DEFAULTS), für die Einstellungen im Backend. */
function le_site_config_with_defaults(): array
{
    return array_merge(LE_SITE_CONFIG_DEFAULTS, le_site_config());
}

/**
 * Einstellungen speichern (api/settings/save.php): nur die Schlüssel von LE_SITE_CONFIG_DEFAULTS aus $values, getrimmt,
 * über dem Gespeicherten. Falsche Form (keiner dieser Schlüssel, ein Wert, der kein Text und keine Zahl ist): 400
 * invalidRequest. Leer ist erlaubt, sonst eine echte E-Mail (dient auch als Empfänger für Formulare), eine
 * http(s)-Adresse und ein Vorschaubild nach LE_SEO_IMAGE_PATTERN; sonst 400 und nichts gespeichert. Lesen → Ändern →
 * Schreiben unter der Sperre bis zum Ende der Anfrage; kodieren oder schreiben scheitert: 500 (atomic_write).
 */
function le_site_config_save(array $values): void
{
    $input = [];
    foreach (array_keys(LE_SITE_CONFIG_DEFAULTS) as $key) {
        if (!array_key_exists($key, $values)) {
            continue;
        }
        if (!is_string($values[$key]) && !is_int($values[$key]) && !is_float($values[$key])) {
            json_response(['ok' => false, 'error' => API_TEXT['invalidRequest']], 400);
        }
        $input[$key] = trim((string) $values[$key]);
    }
    if ($input === []) {
        json_response(['ok' => false, 'error' => API_TEXT['invalidRequest']], 400);
    }
    if (($input['email'] ?? '') !== '' && !filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
        json_response(['ok' => false, 'error' => API_TEXT['invalidEmail']], 400);
    }
    if (($input['url'] ?? '') !== '' && (!filter_var($input['url'], FILTER_VALIDATE_URL) || !preg_match('#^https?://#i', $input['url']))) {
        json_response(['ok' => false, 'error' => API_TEXT['invalidUrl']], 400);
    }
    if (($input['image'] ?? '') !== '' && !preg_match(LE_SEO_IMAGE_PATTERN, $input['image'])) {
        json_response(['ok' => false, 'error' => API_TEXT['invalidImage']], 400);
    }

    le_store_lock_until_end('config');
    $json = json_encode(array_merge(le_site_config(), $input), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        json_response(['ok' => false, 'error' => API_TEXT['encodeFailed']], 500);
    }
    atomic_write(LE_SITE_CONFIG_FILE, $json . PHP_EOL);
}
