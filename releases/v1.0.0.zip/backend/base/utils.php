<?php
declare(strict_types=1);

// Was zu keiner anderen Werkzeug-Datei gehört: Bilder von der echten Website (lokale Kopie), Zeitzone, Zeitangaben für
// Menschen, Schlüssel der Installation (app_secret).

require_once LE_BACKEND . '/base/files.php';

/** Adresse aus LE_IMAGES_FROM_ENV ohne „/“ am Ende, oder null (nicht gesetzt oder ungültig). */
function le_images_from(): ?string
{
    $url = getenv(LE_IMAGES_FROM_ENV);

    return is_string($url) && preg_match(LE_IMAGES_FROM_PATTERN, $url) ? rtrim($url, '/') : null;
}
// Zeitzone für Veröffentlichungszeiten und Zeitstempel, falls der Hoster im
// php.ini keine setzt. PHP < 8.4 meldet dann '', ab 8.4 den Standard 'UTC' –
// beides gilt als „nicht gesetzt“.
const APP_TIMEZONE = 'Europe/Vienna';
if (in_array((string) ini_get('date.timezone'), ['', 'UTC'], true)) {
    date_default_timezone_set(APP_TIMEZONE);
}
// Zeitangaben für Menschen (day_time_label): Kalendertag als heute, gestern oder Datum, dazu die Uhrzeit.
const DAY_LABEL_TODAY = 'heute';
const DAY_LABEL_YESTERDAY = 'gestern';
const DAY_LABEL_DATE_FORMAT = 'd.m.Y';
const DAY_LABEL_TIME_FORMAT = 'H:i';

/** „heute, 03:12“, „gestern, 03:12“ oder „12.10.2026, 03:12“ – Kalendertage in der App-Zeitzone. */
function day_time_label(int $ts, int $now): string
{
    $zone = new DateTimeZone(date_default_timezone_get());
    $time = (new DateTimeImmutable('@' . $ts))->setTimezone($zone);
    $today = (new DateTimeImmutable('@' . $now))->setTimezone($zone);
    $day = $time->format('Y-m-d');
    if ($day === $today->format('Y-m-d')) {
        $label = DAY_LABEL_TODAY;
    } elseif ($day === $today->modify('-1 day')->format('Y-m-d')) {
        $label = DAY_LABEL_YESTERDAY;
    } else {
        $label = $time->format(DAY_LABEL_DATE_FORMAT);
    }
    return $label . ', ' . $time->format(DAY_LABEL_TIME_FORMAT);
}

// So oft (je APP_SECRET_WAIT_US) wartet app_secret auf den Schlüssel, den ein gleichzeitiger Request gerade anlegt.
const APP_SECRET_WAIT_ATTEMPTS = 40;
const APP_SECRET_WAIT_US = 25000;

/**
 * Zufälliger Schlüssel pro Installation (HMAC für Formular-Signaturen,
 * Rate-Limit-Dateinamen). Wird beim ersten Aufruf erzeugt und liegt in
 * private/, das weder ausgeliefert noch vom Update angefasst wird.
 * Nur ein Request legt ihn an (fopen 'x', zunächst leer), der Inhalt kommt
 * über write_private_file (nie mit Standardrechten lesbar); gleichzeitige
 * Requests warten auf diesen Schlüssel statt einen eigenen zu schreiben.
 */
function app_secret(): string
{
    static $secret = null;
    if ($secret !== null) {
        return $secret;
    }

    $path = LE_SECRET_FILE;
    ensure_dir(CONTENT_ROOT);
    for ($attempt = 0; $attempt < APP_SECRET_WAIT_ATTEMPTS; $attempt++) {
        $existing = is_file($path) ? trim((string) @file_get_contents($path)) : '';
        if (strlen($existing) >= 64) {
            return $secret = $existing;
        }
        $claim = @fopen($path, 'x');
        if ($claim !== false) {
            fclose($claim);
            return $secret = app_secret_write($path);
        }
        usleep(APP_SECRET_WAIT_US);
    }
    // Die Datei ist da, aber ohne gültigen Schlüssel (beschädigt, abgebrochenes Anlegen): neu.
    return $secret = app_secret_write($path);
}

function app_secret_write(string $path): string
{
    $new = bin2hex(random_bytes(32));
    try {
        write_private_file($path, $new);
    } catch (RuntimeException $e) {
        // Keine leere Datei zurücklassen, auf die spätere Requests warten würden.
        if (is_file($path) && filesize($path) === 0) {
            @unlink($path);
        }
        throw $e;
    }
    return $new;
}

function current_iso_time(): string
{
    return gmdate('Y-m-d\TH:i:s\Z');
}
