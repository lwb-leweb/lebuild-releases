<?php
declare(strict_types=1);

// Abgleich direkt geänderter Seitendateien (FTP, Deploy): geänderte Quellen erkennen und ihre Markierungen aktualisieren.

require_once LE_BACKEND . '/base/files.php';
require_once LE_BACKEND . '/base/http.php';
require_once LE_BACKEND . '/base/texts.php';
require_once LE_BACKEND . '/pages/import.php';
require_once LE_BACKEND . '/pages/save.php';
require_once LE_BACKEND . '/pages/store.php';

// Urheber von „Markierungen aktualisieren“ beim Abgleich (le_sync_sources) in Verlauf und Aktivitäts-Log:
// die direkte Änderung, nicht wer die Seite gerade lädt. Kein gültiger Benutzername (users_validate_username).
const LE_SYNC_AUTHOR = 'Direkte Änderung';

/**
 * [gemerkter Hash (LE_SOURCE_HASH_KEY, null ohne), Hash der Quelldatei] von $name; null, wenn Quelldatei oder JSON
 * fehlt. Gleich: Das JSON passt zur Datei (le_source_in_sync).
 */
function le_source_hashes(string $name): ?array
{
    $file = page_source_path($name);
    $json = page_json_path($name);
    if ($file === null || !is_file($json)) {
        return null;
    }
    return [le_page_json_source_hash((string) file_get_contents($json)), le_source_hash((string) file_get_contents($file))];
}

/** Passt das JSON zur Quelldatei ($hashes aus le_source_hashes)? false ohne Datei, JSON oder gemerkten Hash. */
function le_source_in_sync(?array $hashes): bool
{
    return $hashes !== null && $hashes[0] === $hashes[1];
}

/**
 * Abgleich: Weicht die Quelldatei einer der Seiten bzw. Komponenten $names vom gemerkten Hash ab
 * (LE_SOURCE_HASH_KEY; direkt geändert: Deploy, FTP, Editor), laufen für sie „Markierungen
 * aktualisieren“ (mit Backup, IDs bleiben, Urheber LE_SYNC_AUTHOR); danach gilt die Datei, und das
 * Speichern prüft je Feld gegen sie (merge_save_content). Ohne gemerkten Hash (Altbestand) wird er
 * nur gesetzt, bei nicht beschreibbarer JSON nicht einmal das (nächstes Mal wieder). Namen ohne
 * Quelldatei oder JSON bleiben außen vor. Der Aufrufer hält lock_pages($names) = $locks. Den Eintrag
 * „Markierungen aktualisiert“ meldet es je Datei gleich nach ihrem Abgleich an (le_log_after_unlock):
 * Bricht der Abgleich einer späteren Datei mit Ausnahme oder exit ab, steht der frühere trotzdem im Log.
 * Liefert ['refreshed' => abgeglichene Namen, 'failed' => Name → Schlüssel aus IMPORT_SKIP_REASONS].
 */
function le_sync_sources(array $names, array $locks): array
{
    $sync = ['refreshed' => [], 'failed' => []];
    foreach (array_unique($names) as $name) {
        $hashes = le_source_hashes($name);
        if ($hashes === null || le_source_in_sync($hashes)) {
            continue;
        }
        [$stored, $hash] = $hashes;
        $json = page_json_path($name);
        if ($stored === null) {
            if (path_writable($json)) {
                le_write_source_hash($name, $hash);
            }
            continue;
        }
        $problem = le_refresh_markers_locked($name, LE_SYNC_AUTHOR);
        if ($problem === null) {
            $sync['refreshed'][] = $name;
            le_log_after_unlock([$name => 'markers_refreshed'], $locks, LE_SYNC_AUTHOR);
        } else {
            error_log('source sync failed: ' . $name . ' (' . $problem . ')');
            $sync['failed'][$name] = $problem;
        }
    }
    return $sync;
}

/**
 * Sperre und Abgleich eines Requests (getPage, savePage, restore): lock_pages($names), dann $beforeSync (restore liest
 * dort den gewählten Eintrag, den das Aufräumen nach dem Backup des Abgleichs sonst löschen könnte), dann
 * le_sync_sources. Scheitert
 * er für die Seite, endet der Request mit 422 (le_sync_failed), und gespeichert wird nichts. Scheitert er für eine
 * Komponente, läuft der Request weiter: Kopf- und Fußzeile gehören zu jeder Seite, eine Fußzeile, die z. B. in
 * Windows-1252 gespeichert wurde, sperrte sonst jede Seite samt Verlauf. Ihr JSON bleibt beim alten Stand, und der
 * Aufrufer schreibt sie nicht (savePage: 422, wenn sie sich ändern würde; getPage und restore melden es mit
 * le_sync_skipped_notice, restore zählt ihre Felder als übersprungen); der nächste Request versucht es wieder.
 * Ein Abbruch hält die Sperren bis nach der Rücknahme (le_hold_until_shutdown), auch beim Aufrufer danach.
 * Liefert [Sperren (frei mit unlock_pages), ['refreshed' => abgeglichene Namen, 'failed' => Komponente → Schlüssel
 * aus IMPORT_SKIP_REASONS]].
 */
function le_sync_request(array $names, ?callable $beforeSync = null): array
{
    $locks = lock_pages($names);
    // Schon für den Abgleich: Bricht er mittendrin ab (Ausnahme, exit), nimmt le_refresh_markers_locked zurück, bevor frei wird.
    le_hold_until_shutdown($locks);
    if ($beforeSync !== null) {
        $beforeSync();
    }
    $sync = le_sync_sources($names, $locks);
    $pages = array_diff_key($sync['failed'], shared_components());
    if ($pages !== []) {
        le_sync_failed($pages);
    }
    return [$locks, $sync];
}

/**
 * Gescheiterte Abgleiche $failed (Name → Schlüssel aus IMPORT_SKIP_REASONS) für den Browser: ['message' =>
 * API_TEXT[$text] mit „Name: Grund“ je Datei und contactSupport, 'fields' => wie beim Speichern, die id ist aber
 * der Name der Seite bzw. Komponente, keine Feld-ID].
 */
function le_sync_problem(array $failed, string $text): array
{
    $fields = [];
    foreach ($failed as $name => $problem) {
        $fields[] = ['id' => (string) $name, 'label' => plan_label((string) $name), 'reason' => IMPORT_SKIP_REASONS[$problem]];
    }
    $reasons = array_map(static fn (array $field): string => $field['label'] . ': ' . $field['reason'], $fields);
    return ['message' => sprintf(API_TEXT[$text], implode('; ', $reasons)) . ' ' . API_TEXT['contactSupport'], 'fields' => $fields];
}

/** Antwortet 422 mit API_TEXT['syncFailed'] für $failed (le_sync_problem) und beendet den Request. */
function le_sync_failed(array $failed): void
{
    $problem = le_sync_problem($failed, 'syncFailed');
    json_response(['ok' => false, 'error' => $problem['message'], 'fields' => $problem['fields']], 422);
}

/** Hinweis für getPage und restore, wenn der Abgleich einer Komponente gescheitert ist (API_TEXT['syncSkipped']); sonst []. */
function le_sync_skipped_notice(array $failed): array
{
    return $failed === [] ? [] : ['message' => le_sync_problem($failed, 'syncSkipped')['message']];
}
