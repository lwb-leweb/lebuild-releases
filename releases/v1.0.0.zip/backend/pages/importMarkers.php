<?php
declare(strict_types=1);

// Import, Markierungen: bearbeitbare Elemente im Quelltext finden und ihre data-edit-Attribute setzen.

require_once LE_BACKEND . '/html/icons.php';
require_once LE_BACKEND . '/html/markup.php';
require_once LE_BACKEND . '/html/textMarkup.php';
require_once LE_BACKEND . '/pages/fields.php';
require_once LE_BACKEND . '/pages/import.php';
require_once LE_BACKEND . '/pages/importIds.php';
require_once LE_BACKEND . '/pages/labels.php';
require_once LE_BACKEND . '/pages/routes.php';
require_once LE_BACKEND . '/pages/store.php';

/**
 * Entfernt LE_IMPORT_XML_REMNANTS (samt folgendem Zeilenumbruch) nur im Vorspann: hinter BOM, Leerraum, PHP-Blöcken (laut
 * Tokenizer, auch in .html: der alte Import behielt dort PHP-Blöcke am Anfang als Vorspann) und einem DOCTYPE. Ab dem
 * ersten anderen Zeichen, in PHP-Code oder im Inhalt bleibt alles byte-gleich.
 */
function le_import_strip_xml_remnant(string $source): string
{
    $pos = str_starts_with($source, LE_UTF8_BOM) ? strlen(LE_UTF8_BOM) : 0;
    $doctype = false;
    while (true) {
        $pos += strspn($source, " \t\r\n", $pos);
        // Erst der Rest, dann PHP: Mit short_open_tag=On liest der Tokenizer „<?xml …>“ als PHP-Block.
        foreach (LE_IMPORT_XML_REMNANTS as $remnant) {
            if (substr_compare($source, $remnant, $pos, strlen($remnant)) === 0) {
                $end = $pos + strlen($remnant);
                $end += ($source[$end] ?? '') === "\n" ? 1 : 0;
                $source = substr($source, 0, $pos) . substr($source, $end);
                continue 2;
            }
        }
        if (!$doctype && strncasecmp(substr($source, $pos, 9), '<!doctype', 9) === 0) {
            $close = strpos($source, '>', $pos);
            if ($close === false) {
                return $source;
            }
            $pos = $close + 1;
            $doctype = true;
            continue;
        }
        if (!str_starts_with(substr($source, $pos, 2), '<?')) {
            return $source;
        }
        // Tokenizer über die Quelle ohne die schon entfernten Reste; zählt nur ein Block, der genau an $pos beginnt.
        $block = array_column(le_markup_php_blocks($source) ?? [], 1, 0)[$pos] ?? null;
        if ($block === null) {
            return $source;
        }
        $pos = $block;
    }
}

/**
 * Ein Importweg für HTML und PHP: Markierungen entscheiden, vorhandene IDs behalten,
 * fehlende vergeben (nie eine aus $issued, import_issued_ids), Marker byte-genau setzen oder
 * entfernen und die Werte aus demselben Baum lesen. ['source' => neue Datei, 'content' => Werte ohne Präfix]
 */
function import_source(string $source, string $prefix = '', array $issued = [], bool $php = true): array
{
    $source = import_clean_links(le_import_strip_xml_remnant($source), $php);
    $doc = le_markup_parse_source($source, $php);
    $state = ['marks' => [], 'headings' => [], 'meta' => []];
    $heading = null;
    foreach ($doc['roots'] as $root) {
        import_walk($doc, $root, [], $state, $heading);
    }
    // Elemente im PHP-Code (etwa in einem String) werden nie bearbeitbar: Text dort wäre Code. Ebenso Elemente mit PHP
    // in einem ID-Marker (etwa ein Echo-Tag in data-edit-id): Die ID ließe sich nur über den Code hinweg setzen.
    $state['marks'] = array_values(array_filter($state['marks'], static fn (array $mark): bool => !le_markup_edit_in_php($doc, $doc['nodes'][$mark['index']]) && !($php && import_marker_has_php($doc['nodes'][$mark['index']]))));
    $pre = field_id_prefix($prefix);
    $marks = import_assign_labels(import_assign_ids($doc, $state['marks'], $pre, $issued), $state['headings']);

    $edits = [];
    $content = [];
    $marked = [];
    foreach ($marks as $mark) {
        $marked[$mark['index']] = true;
        import_sync_attributes($doc, $mark['index'], $mark['attrs'], $edits);
        foreach (import_mark_values($doc, $mark) as $id => $value) {
            set_nested_value($content, str_starts_with($id, $pre) ? substr($id, strlen($pre)) : $id, $value);
        }
    }
    foreach ($doc['nodes'] as $index => $node) {
        if ($node['type'] === 'element' && !isset($marked[$index])) {
            import_sync_attributes($doc, $index, [], $edits);
        }
    }

    // Im PHP-Code ändert der Import nichts, auch keine alten Marker dort oder mit PHP im Wert: Sie sind harmlos (nie
    // bearbeitbar), eine Änderung an den Bytes könnte den Code des Entwicklers zerbrechen.
    $edits = array_filter($edits, static fn (array $edit): bool => !le_markup_edit_touches_php($doc, $edit));
    return ['source' => markup_apply($source, $edits), 'content' => $content];
}

/**
 * Links auf Seiten der Website ohne Endung, wie der Router sie ausliefert (le_site_clean_path): href="kontakt.html"
 * → "kontakt", "/public/site/a.php#x" → "/a#x", "index.html" → "/". Anker, Query und relative Schreibweise
 * bleiben; fremde Ziele, Links mit PHP und alles, was der Router nicht umleitet, bleiben unverändert.
 */
function import_clean_links(string $source, bool $php = true): string
{
    $doc = le_markup_parse_source($source, $php);
    $edits = [];
    foreach ($doc['nodes'] as $index => $node) {
        $attr = $node['type'] === 'element' && $node['tag'] === 'a' ? markup_attr($node, 'href') : null;
        $clean = $attr === null || $attr['has_php'] ? null : import_clean_href(markup_attr_text($node, 'href'));
        if ($clean !== null && !le_markup_edit_in_php($doc, $node)) {
            $edits[] = markup_set_attr($doc, $index, 'href', markup_attr_escape($clean));
        }
    }
    return $edits === [] ? $source : markup_apply($source, $edits);
}

/** Ziel ohne Endung für einen Link (import_clean_links), null, wenn er bleibt. Relativ heißt ab /: Seiten und Komponenten liegen direkt unter public. */
function import_clean_href(string $href): ?string
{
    if (!preg_match('/^([^?#]+)(.*)$/s', $href, $m) || preg_match('#^([a-z][a-z0-9+.-]*:|//)#i', $m[1])) {
        return null;
    }
    $path = le_site_canonical_path('/' . ltrim($m[1], '/'));
    $file = $path === null ? null : le_site_request_file($path);
    $clean = $file === null ? null : le_site_clean_path($path, $file);
    if ($clean === null) {
        return null;
    }
    return (str_starts_with($m[1], '/') || $clean === '/' ? $clean : ltrim($clean, '/')) . $m[2];
}

/** Marker, die der Import setzt und an nicht (mehr) markierten Elementen entfernt. */
function import_edit_attributes(): array
{
    return [...array_keys(EDIT_MARKERS), 'data-edit-label'];
}

/**
 * Durchlauf: entscheidet je Element, ob es Text, Link, Bild, Icon oder Hintergrund wird.
 * Markierung: index, tag, field (title|text|url|image|icon|Name aus IMPORT_META_FIELDS|null), text (eigenes Textfeld, bei Links der Linktext),
 * alt, bg, group (Abschnittsname), heading (Knoten der zuständigen Überschrift).
 * $heading ist die im aktuellen Abschnitt geltende Überschrift: Ein benannter Block (id, class,
 * Strukturtag außer header/hgroup) beginnt ohne; beim Verlassen gilt die äußere wieder.
 */
function import_walk(array $doc, int $index, array $ancestors, array &$state, ?int &$heading): void
{
    $node = $doc['nodes'][$index];
    $icon = $node['type'] === 'element' && $node['tag'] === 'svg' && le_icon_svg($doc, $index);
    if ($node['type'] !== 'element' || (!$icon && in_array($node['tag'], IMPORT_SKIP_TAGS, true)) || markup_attr($node, 'data-plugin') !== null) {
        return;
    }
    $tag = $node['tag'];
    $mark = [
        'index' => $index,
        'tag' => $tag,
        'field' => null,
        'text' => false,
        'alt' => false,
        'bg' => false,
        'group' => closest_context_name($doc, $ancestors),
        'heading' => $heading,
        'attrs' => [],
    ];
    $descend = true;

    if (!import_is_hidden($node)) {
        $mark['bg'] = import_target_readable($node, 'background');
        if ($icon) {
            $mark['field'] = 'icon';
        } elseif ($tag === 'img') {
            if (import_target_readable($node, 'src')) {
                $mark['field'] = 'image';
                // Ein alt mit PHP-Block ist nicht zurückschreibbar und wird kein Feld; ohne alt schon.
                $mark['alt'] = edit_target_problem($node, 'alt') === null;
            }
        } elseif ($tag === 'title') {
            // Es gilt das erste <title> (wie im Browser); mit PHP darin gibt es kein Feld.
            if (!isset($state['meta'][IMPORT_TITLE_KIND]) && !markup_inner_has_php($doc, $index)) {
                $mark['field'] = IMPORT_TITLE_KIND;
                $mark['heading'] = null;
            }
            $state['meta'][IMPORT_TITLE_KIND] = true;
            $descend = false;
        } elseif ($tag === 'meta') {
            // Nur bekannte Namen mit content-Attribut ohne PHP; ohne content keine Beschreibung, kein
            // Feld. Je Name nur die erste Angabe (die gilt auch im Browser).
            $name = strtolower(trim(markup_attr_text($node, 'name')));
            if (isset(IMPORT_META_FIELDS[$name]) && !isset($state['meta'][$name]) && import_target_readable($node, 'content')) {
                $state['meta'][$name] = true;
                $mark['field'] = $name;
                $mark['heading'] = null;
            }
        } elseif (in_array($tag, IMPORT_CANDIDATE_TAGS, true) || markup_attr($node, 'data-edit-id') !== null) {
            $shape = import_content_shape($doc, $index);
            if ($tag === 'a' && import_target_value($doc, $index, 'href') !== '') {
                $mark['field'] = 'url';
                $mark['text'] = $shape === 'text';
                $descend = !$mark['text'];
            } elseif ($tag === 'a') {
                // Ohne speicherbares Ziel nur ein Textfeld (data-edit-text-id), wie ein span.
                $mark['text'] = $shape === 'text';
                $descend = !$mark['text'];
            } elseif ($shape === 'text') {
                $mark['field'] = semantic_field($tag);
                $descend = false;
            }
        }
        if (in_array($tag, IMPORT_HEADING_TAGS, true) && !markup_inner_has_php($doc, $index)) {
            $text = label_heading_text(markup_inner_html($doc, $index));
            if ($text !== '') {
                $state['headings'][$index] = $text;
                $heading = $index;
                $mark['heading'] = $index;
            }
        }
    }

    $markPos = null;
    if ($mark['field'] !== null || $mark['text'] || $mark['bg']) {
        $markPos = count($state['marks']);
        $state['marks'][] = $mark;
    }
    // Ein Icon ist ein Feld als Ganzes, auch versteckt wird nichts darin markiert.
    if ($icon) {
        $descend = false;
    }
    if ($descend) {
        $ancestors[] = $index;
        $firstChildMark = count($state['marks']);
        $boundary = !in_array($tag, IMPORT_HEADING_WRAPPER_TAGS, true) && context_name_from_element($node) !== '';
        $inner = null;
        foreach ($node['children'] as $child) {
            if ($boundary) {
                import_walk($doc, $child, $ancestors, $state, $inner);
            } else {
                import_walk($doc, $child, $ancestors, $state, $heading);
            }
        }
        // Ein reines Hintergrund-Element, das einen Abschnitt beginnt, heißt nach dessen erster
        // Überschrift, wie tief sie auch liegt (sie steht erst nach dem Element selbst).
        $first = $boundary && $markPos !== null && import_label_kind($mark) === 'background' ? import_first_heading($doc, $index, $state['headings']) : null;
        if ($first !== null) {
            $state['marks'][$markPos]['heading'] = $first;
        }
        // Ein Icon vor der ersten Überschrift seines Abschnitts (Karte: Icon, dann Titel) heißt nach ihr.
        $first = $boundary ? import_first_heading($doc, $index, $state['headings']) : null;
        for ($m = $firstChildMark; $first !== null && $m < count($state['marks']); $m++) {
            if ($state['marks'][$m]['field'] === 'icon' && $state['marks'][$m]['heading'] === null) {
                $state['marks'][$m]['heading'] = $first;
            }
        }
    }
}

/** Erste Überschrift (Knoten aus $headings, wie import_walk sie erkennt) im Teilbaum von $index; null ohne. */
function import_first_heading(array $doc, int $index, array $headings): ?int
{
    foreach (array_keys($headings) as $heading) {
        if ($heading > $index && $doc['nodes'][$heading]['start'] < $doc['nodes'][$index]['end']) {
            return $heading;
        }
    }
    return null;
}

/**
 * Form des Inhalts eines Kandidaten:
 * 'text'     – nur Text und Inline-Elemente (rekursiv), mit Text, ohne PHP, ohne Icon;
 * 'children' – kein eigener Text, nur a/span-Kinder → die Kinder werden markiert;
 * 'mixed'    – alles andere (Block-Kinder, Bilder, Icons, PHP, leer).
 */
function import_content_shape(array $doc, int $index): string
{
    $node = $doc['nodes'][$index];
    if ($node['self_closing'] || markup_inner_has_php($doc, $index)) {
        return 'mixed';
    }
    $directText = false;
    $childTags = [];
    foreach ($node['children'] as $child) {
        $childNode = $doc['nodes'][$child];
        if ($childNode['type'] === 'text') {
            $directText = $directText || import_has_text(substr($doc['source'], $childNode['start'], $childNode['end'] - $childNode['start']));
        } elseif ($childNode['type'] === 'element') {
            $childTags[] = $childNode['tag'];
        }
    }
    if ($node['tag'] !== 'a' && !in_array($node['tag'], IMPORT_HEADING_TAGS, true) && !$directText && $childTags !== [] && array_diff($childTags, IMPORT_CHILD_TAGS) === []) {
        return 'children';
    }
    if (import_is_inline_content($doc, $index) && import_has_text(strip_tags(markup_inner_html($doc, $index)))) {
        return 'text';
    }
    return 'mixed';
}

/** Alle Nachkommen sind Inline-Elemente; Inline-Elemente außer <br> ohne Text gelten als Icon. */
function import_is_inline_content(array $doc, int $index): bool
{
    foreach ($doc['nodes'][$index]['children'] as $child) {
        $childNode = $doc['nodes'][$child];
        if ($childNode['type'] !== 'element') {
            continue;
        }
        if (!in_array($childNode['tag'], TEXT_ALLOWED_TAGS, true)) {
            return false;
        }
        if ($childNode['tag'] !== 'br' && (!import_has_text(strip_tags(markup_inner_html($doc, $child))) || !import_is_inline_content($doc, $child))) {
            return false;
        }
    }
    return true;
}

/** Enthält der rohe Text (mit Entities) etwas anderes als Leerraum? */
function import_has_text(string $raw): bool
{
    return (bool) preg_match('/[^\s\x{A0}]/u', html_entity_decode($raw, ENT_HTML5 | ENT_QUOTES, 'UTF-8'));
}

function import_is_hidden(array $node): bool
{
    if (markup_attr($node, 'hidden') !== null) {
        return true;
    }
    return (bool) preg_match('/display\s*:\s*none|visibility\s*:\s*hidden/i', markup_attr_text($node, 'style'));
}

/**
 * Attributwert für Namen (id, class); leer, wenn er einen PHP-Block enthält.
 */
function import_attr_value(array $node, string $name): string
{
    $attr = markup_attr($node, $name);
    return $attr === null || $attr['has_php'] ? '' : sanitize_text_value(markup_attr_text($node, $name));
}

/**
 * Ziel (src, href, background) steht in der Datei und ist zurückschreibbar (edit_target_problem,
 * dieselbe Regel wie beim Speichern). Ob ein Bild- oder Hintergrundfeld entsteht, hängt daran,
 * nicht am Wert: ein geleertes Bild (src="", url()) oder ein data:-Wert bleibt ein Feld (Wert ''
 * nach der Bereinigung), sonst ginge es beim Re-Import verloren.
 */
function import_target_readable(array $node, string $target): bool
{
    return markup_attr($node, edit_target_attr($target)) !== null && edit_target_problem($node, $target) === null;
}

/**
 * Bereinigter Wert eines Ziels wie beim Speichern (source_field_value); leer, wenn es nicht
 * lesbar ist. Ein Link mit leerem Wert (auch javascript:) hat kein speicherbares Ziel und wird
 * nur Text (Entscheidung 11).
 */
function import_target_value(array $doc, int $index, string $target): string
{
    return import_target_readable($doc['nodes'][$index], $target) ? source_field_value($doc, $index, $target) : '';
}

/** Marker, die eine Markierung trägt (Name → gewünscht). */
function import_mark_markers(array $mark): array
{
    return array_keys(array_filter([
        'data-edit-id' => $mark['field'] !== null,
        'data-edit-text-id' => $mark['text'],
        'data-edit-alt-id' => $mark['alt'],
        'data-edit-bg-id' => $mark['bg'],
    ]));
}

/** Gleicht die Edit-Attribute eines Elements mit $wanted (Name → Wert) ab: setzen, ersetzen, entfernen. */
function import_sync_attributes(array $doc, int $index, array $wanted, array &$edits): void
{
    $node = $doc['nodes'][$index];
    foreach (import_edit_attributes() as $name) {
        $attr = markup_attr($node, $name);
        if (!isset($wanted[$name])) {
            if ($attr !== null) {
                $edits[] = markup_remove_attr($doc, $index, $name);
            }
        } elseif ($attr === null || markup_attr_text($node, $name) !== $wanted[$name]) {
            $edits[] = markup_set_attr($doc, $index, $name, markup_attr_escape($wanted[$name]));
        }
    }
}

/** Ob ein ID-Marker des Elements (data-edit-id, data-edit-…-id) PHP-Code im Wert hat; ein Label mit PHP schützt der Edit-Filter. */
function import_marker_has_php(array $node): bool
{
    foreach (array_keys(EDIT_MARKERS) as $name) {
        $attr = markup_attr($node, $name);
        if ($attr !== null && $attr['has_php']) {
            return true;
        }
    }
    return false;
}

/** Werte einer Markierung (ID wie in der Datei → Wert), gelesen wie beim Speichern (source_field_value). */
function import_mark_values(array $doc, array $mark): array
{
    $node = $doc['nodes'][$mark['index']];
    $values = [];
    foreach (array_intersect_key($mark['attrs'], EDIT_MARKERS) as $marker => $id) {
        $values[$id] = source_field_value($doc, $mark['index'], edit_marker_target($marker, $node));
    }
    return $values;
}
