<?php
declare(strict_types=1);

require_once LE_BACKEND . '/html/textMarkup.php';
require_once LE_BACKEND . '/pages/labels.php';
require_once LE_BACKEND . '/base/files.php';
require_once LE_BACKEND . '/pages/fields.php';
require_once LE_BACKEND . '/base/http.php';
require_once LE_BACKEND . '/base/texts.php';
require_once LE_BACKEND . '/media/uploads.php';
require_once LE_BACKEND . '/base/activity.php';

function prepare_storage(): void
{
    ensure_dir(PAGES_ROOT);
    ensure_dir(BACKUPS_ROOT);
    ensure_dir(ORIGINALS_ROOT);
    le_private_prepare();
    le_uploads_prepare();
}

function page_json_path(string $page): string
{
    return PAGES_ROOT . '/' . safe_page_name($page) . '.json';
}

// Schlüssel im JSON einer Seite oder Komponente neben ihren Feldern: Hash der Quelldatei, wie der Kern
// sie zuletzt geschrieben bzw. importiert hat (Speichern, Wiederherstellen, Import). Weicht die Datei
// davon ab, wurde sie direkt geändert (Deploy, FTP, Editor): le_sync_sources gleicht ab. Kein Feld,
// le_page_json_content lässt ihn weg. Das „@“ kann keine Feld-ID tragen (import_id_storable,
// sanitize_content_tree), so verdeckt der Schlüssel nie ein Feld, auch kein von Hand gesetztes data-edit-id="sourceHash".
const LE_SOURCE_HASH_KEY = '@sourceHash';
const LE_SOURCE_HASH_ALGO = 'sha256';

/** Hash einer Quelldatei (Inhalt $source) für LE_SOURCE_HASH_KEY. */
function le_source_hash(string $source): string
{
    return hash(LE_SOURCE_HASH_ALGO, $source);
}

/** Felder aus dem Text einer Seiten-JSON oder eines ihrer Backups, ohne LE_SOURCE_HASH_KEY; null, wenn unlesbar. */
function le_page_json_content(string $json): ?array
{
    $data = json_decode($json, true);
    if (!is_array($data)) {
        return null;
    }
    unset($data[LE_SOURCE_HASH_KEY]);
    return $data;
}

/** Gemerkter Hash der Quelldatei aus dem Text einer Seiten-JSON; null ohne (Altbestand) oder wenn unlesbar. */
function le_page_json_source_hash(string $json): ?string
{
    $hash = json_decode($json, true)[LE_SOURCE_HASH_KEY] ?? null;
    return is_string($hash) ? $hash : null;
}

/** Hash der Quelldatei nach dem Schreiben eines Plans ('file', 'source' wie aus plan_source_rewrite): neue Fassung, sonst die Datei. */
function le_plan_source_hash(array $plan): string
{
    return le_source_hash($plan['source'] ?? (string) file_get_contents($plan['file']));
}

/**
 * Merkt $hash als Hash der Quelldatei im JSON von $name, ohne dass sich Felder ändern: kein Backup,
 * „Zuletzt gespeichert“ bleibt (Altbestand ohne Hash, Datei ohne geänderte Felder). Eine unlesbare
 * JSON bleibt, wie sie ist. Der Aufrufer hält lock_pages.
 */
function le_write_source_hash(string $name, string $hash): void
{
    $path = page_json_path($name);
    $content = is_file($path) ? le_page_json_content((string) file_get_contents($path)) : null;
    if ($content === null) {
        return;
    }
    clearstatcache(true, $path);
    $updatedAt = (int) filemtime($path);
    atomic_write($path, (string) page_json_text($content, $hash));
    touch($path, $updatedAt);
}

function load_page_content(string $page): array
{
    $path = page_json_path($page);
    if (!is_file($path)) {
        json_response(['ok' => false, 'error' => API_TEXT['pageNotFound']], 404);
    }

    $data = le_page_json_content((string) file_get_contents($path));
    if ($data === null) {
        json_response(['ok' => false, 'error' => API_TEXT['pageInvalid']], 500);
    }

    return $data;
}

function list_pages(): array
{
    prepare_storage();
    $files = glob(PAGES_ROOT . '/*.json') ?: [];
    $components = array_keys(shared_components());
    $pages = array_map(static fn (string $file): string => basename($file, '.json'), $files);
    $pages = array_values(array_filter($pages, static fn (string $p): bool => !in_array($p, $components, true)));
    sort($pages);

    return $pages;
}

/** JSON einer Seite oder Komponente; null ohne Datei oder wenn sie unlesbar ist (anders als load_page_content ohne Abbruch). */
function load_component_content(string $name): ?array
{
    $path = page_json_path($name);
    if (!is_file($path)) {
        return null;
    }
    return le_page_json_content((string) file_get_contents($path));
}

/**
 * Seitentitel für Listen: erstes title-, sonst text-Feld als Klartext ($kinds: Feldarten wie aus
 * page_field_kinds, sonst nach der ID; ein Titel der Art plain bleibt, wie er ist). $kindOf (Pfad →
 * Art) ersetzt den Rückfall auf field_kind und läuft nur, wenn die Art den Titel ändert: Ein Wert,
 * den die Textbereinigung nicht verändert, ist in jeder Art derselbe (page_info liest die
 * Seitendatei so nur dann).
 */
function page_title_from_content(array $content, string $fallback, array $kinds = [], ?callable $kindOf = null): string
{
    $flat = flatten_content($content);
    foreach (['title', 'text'] as $field) {
        foreach ($flat as $path => $value) {
            $path = (string) $path;
            if (!preg_match('/(^|\.)' . $field . '$/', $path) || !is_scalar($value)) {
                continue;
            }
            $value = (string) $value;
            $title = trim($value);
            if (isset($kinds[$path]) || text_markup_plain($value) !== $title) {
                $title = trim(field_plain_text($kinds[$path] ?? ($kindOf === null ? field_kind($path) : $kindOf($path)), $value));
            }
            if ($title !== '') {
                return $title;
            }
        }
    }

    return $fallback;
}

/** Endung der Seitendatei unter public (.php vor .html wie bei der Auslieferung); null, wenn keine da ist. */
function page_extension(string $page): ?string
{
    foreach (['php', 'html'] as $ext) {
        if (is_file(LE_SITE_ROOT . '/' . $page . '.' . $ext) && le_site_file_inside(LE_SITE_ROOT . '/' . $page . '.' . $ext)) {
            return $ext;
        }
    }
    return null;
}

/** Quelldatei einer Seite oder Komponente (header/footer) unter public; null, wenn sie fehlt oder ein Link nach außen ist. */
function page_source_path(string $name): ?string
{
    $component = shared_components()[$name] ?? null;
    if ($component !== null) {
        return is_file($component) && le_site_file_inside($component) ? $component : null;
    }
    $page = safe_page_name($name);
    $ext = page_extension($page);
    return $ext === null ? null : LE_SITE_ROOT . '/' . $page . '.' . $ext;
}

/** „Zuletzt gespeichert“ einer Seite: Änderungszeit ihrer JSON, null ohne JSON. */
function page_updated_at(string $page): ?string
{
    $path = page_json_path($page);
    clearstatcache(true, $path);
    return is_file($path) ? gmdate('c', (int) filemtime($path)) : null;
}

/**
 * Rückt „Zuletzt gespeichert“ vor, wenn sich nur die Seitendatei oder eine Komponente
 * geändert hat und die JSON der Seite deshalb nicht neu geschrieben wurde.
 */
function mark_page_updated(string $page): void
{
    $path = page_json_path(safe_page_name($page));
    if (is_file($path)) {
        touch($path);
    }
}

/**
 * Eintrag der Seitenliste (Backend, JSON-Block des Seiten-Editors): Name, Titel, zuletzt gespeichert,
 * Endung. Ohne Seitendatei (JSON da, Datei gelöscht) ist ext null und missing true: Das Backend zeigt
 * die Seite mit Hinweis, öffnet sie aber nicht.
 */
function page_info(string $page): array
{
    // Mit kaputter JSON (unlesbar) heißt die Seite nach ihrem Namen; Backend, Verlauf und Seiten-Editor laden trotzdem.
    $content = load_component_content($page) ?? [];
    $ext = page_extension($page);
    // Feldart wie page_field_kinds, aber die Seitendatei wird nur gelesen, wenn ein Titelkandidat sie braucht.
    $doc = null;
    $kindOf = static function (string $path) use (&$doc, $page): string {
        $doc ??= page_source_doc($page);
        return field_kind_in_doc($doc, field_id_prefix($page) . $path);
    };
    return [
        'page' => $page,
        'title' => page_title_from_content($content, $page, [], $kindOf),
        'updatedAt' => page_updated_at($page),
        'ext' => $ext,
        'missing' => $ext === null,
    ];
}

function list_page_info(): array
{
    prepare_storage();
    return array_map('page_info', list_pages());
}

/**
 * Schlüssel bereinigen und jeden Wert nach seiner Feldart: $kinds (Pfad → Art aus der Markierung
 * in der Datei, page_field_kinds/plan_source_rewrite), für Felder ohne Markierung field_kind der ID.
 */
function sanitize_content_tree(array $content, array $kinds = [], string $prefix = ''): array
{
    $clean = [];
    foreach ($content as $key => $value) {
        $safeKey = preg_replace('/[^a-zA-Z0-9_-]/', '', (string) $key);
        if ($safeKey === '') {
            continue;
        }
        $id = $prefix === '' ? $safeKey : $prefix . '.' . $safeKey;
        if (is_array($value)) {
            $clean[$safeKey] = sanitize_content_tree($value, $kinds, $id);
        } else {
            $clean[$safeKey] = sanitize_field_value($kinds[$id] ?? field_kind($id), is_scalar($value) ? (string) $value : '');
        }
    }

    return $clean;
}

// Sperrdatei je Seite oder Komponente in ihrem Backup-Ordner (lock_pages).
const PAGE_LOCK_FILE = '.lock';

/**
 * Sperrt Seiten und Komponenten ($names) für den ganzen Ablauf Lesen → Backup → JSON → Dateien
 * (Speichern, Wiederherstellen, Import): wartet auf laufende und sperrt in fester Reihenfolge
 * (sortiert), damit zwei Requests einander nicht verklemmen. Namen ohne Quelldatei werden nicht
 * gesperrt (für sie wird nichts geschrieben, Grund „Quelldatei fehlt“), so entstehen für erfundene
 * Namen weder Ordner noch Sperrdateien. Frei mit unlock_pages, spätestens am Ende des Requests.
 * Nie verschachtelt aufrufen (eine zweite Sperre derselben Seite wartete auf die erste).
 */
function lock_pages(array $names): array
{
    $names = array_filter(array_unique(array_map('safe_page_name', $names)), static fn (string $name): bool => page_source_path($name) !== null);
    sort($names);
    $locks = [];
    foreach ($names as $name) {
        $dir = BACKUPS_ROOT . '/' . $name;
        try {
            ensure_dir($dir);
        } catch (RuntimeException $e) {
            // Ohne Pfad in der Antwort (ensure_dir nennt ihn).
            json_response(['ok' => false, 'error' => API_TEXT['lockFailed']], 500);
        }
        $lock = le_lock_file($dir . '/' . PAGE_LOCK_FILE, true);
        if ($lock === null) {
            json_response(['ok' => false, 'error' => API_TEXT['lockFailed']], 500);
        }
        $locks[] = $lock;
    }
    return $locks;
}

/** Gibt Sperren aus lock_pages frei; schon freigegebene bleiben unberührt (le_log_after_unlock). */
function unlock_pages(array $locks): void
{
    foreach (array_reverse($locks) as $lock) {
        if (is_resource($lock)) {
            store_unlock($lock);
        }
    }
}

/**
 * Inhalt der JSON einer Seite bzw. Komponente, wie save_page_content sie schreibt ($content
 * bereinigt, $sourceHash unter LE_SOURCE_HASH_KEY vorn); null, wenn er sich nicht kodieren lässt.
 */
function page_json_text(array $content, ?string $sourceHash = null): ?string
{
    $data = $sourceHash === null ? $content : [LE_SOURCE_HASH_KEY => $sourceHash] + $content;
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    return $json === false ? null : $json . PHP_EOL;
}

/** Seitenname nach der Whitelist (Buchstaben, Ziffern, _ und -), ohne die Anfrage abzubrechen. */
function is_safe_page_name(string $page): bool
{
    return preg_match('/^[a-zA-Z0-9_-]+$/', $page) === 1;
}

function safe_page_name(string $page): string
{
    $page = trim($page);
    if (!is_safe_page_name($page)) {
        json_response(['ok' => false, 'error' => API_TEXT['invalidPageName']], 400);
    }

    return $page;
}

function sanitize_text_value(mixed $value): string
{
    if (!is_scalar($value)) {
        return '';
    }

    $clean = strip_tags((string) $value, '<br>');
    // strip_tags keeps attributes on allowed tags — normalize <br foo="…"> to plain <br>
    $clean = preg_replace('/<br\b[^>]*>/i', '<br>', $clean) ?? $clean;
    return trim($clean);
}

function flatten_content(array $content, string $prefix = ''): array
{
    $flat = [];
    foreach ($content as $key => $value) {
        $path = $prefix === '' ? (string) $key : $prefix . '.' . $key;
        if (is_array($value)) {
            $flat += flatten_content($value, $path);
        } else {
            $flat[$path] = $value;
        }
    }

    return $flat;
}

/** Gegenstück zu flatten_content: Pfad → Wert wird wieder ein Baum. */
function unflatten_content(array $flat): array
{
    $tree = [];
    foreach ($flat as $path => $value) {
        set_nested_value($tree, (string) $path, $value);
    }
    return $tree;
}

function set_nested_value(array &$target, string $path, mixed $value): void
{
    $parts = explode('.', $path);
    $cursor = &$target;
    foreach ($parts as $index => $part) {
        if ($index === count($parts) - 1) {
            $cursor[$part] = $value;
            return;
        }

        if (!isset($cursor[$part]) || !is_array($cursor[$part])) {
            $cursor[$part] = [];
        }
        $cursor = &$cursor[$part];
    }
}

// Namen der Komponenten für Kunden (Nachfrage beim Wiederherstellen im Verlauf).
const COMPONENT_LABELS = ['header' => 'Kopfzeile', 'footer' => 'Fußzeile'];

function shared_components(): array
{
    return [
        'header' => LE_SITE_ROOT . '/includes/navigation.php',
        'footer' => LE_SITE_ROOT . '/includes/footer.php',
    ];
}

/**
 * Schreibt Einträge im Aktivitäts-Log (Ziel → Aktion, Urheber $user, null = der Angemeldete) am Ende des Requests,
 * nach allen anderen Shutdown-Funktionen (Rücknahme beim Speichern, plans_restore_point) und nach dem Freigeben
 * von $locks: So nimmt das Log seine Sperre nie unter lock_pages, auch wenn der Request vorher mit
 * einer Antwort (409, 422) endet. Schon freigegebene Sperren bleiben frei (unlock_pages). Einträge stehen in der
 * Reihenfolge der Aufrufe: Speichern und Wiederherstellen melden ihren eigenen Eintrag ebenso hier an, damit er nach
 * dem Abgleich steht, den sie ausgelöst haben.
 */
function le_log_after_unlock(array $entries, array $locks, ?string $user): void
{
    if ($entries === []) {
        return;
    }
    le_after_shutdown(static function () use ($entries, $locks, $user): void {
        unlock_pages($locks);
        foreach ($entries as $target => $action) {
            le_activity_log($action, (string) $target, $user);
        }
    });
}

/**
 * Hält Sperren aus lock_pages bis nach der Rücknahme am Prozessende, auch wenn die Variable des Aufrufers vorher
 * verschwindet (eine Ausnahme räumt seine lokalen Variablen samt Sperren ab). Im Normalfall gibt der Aufrufer selbst
 * frei, dann ist hier nichts mehr zu tun (unlock_pages).
 */
function le_hold_until_shutdown(array $locks): void
{
    le_after_shutdown(static function () use ($locks): void {
        unlock_pages($locks);
    });
}
