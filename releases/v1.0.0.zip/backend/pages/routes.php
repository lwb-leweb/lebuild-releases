<?php
declare(strict_types=1);

require_once LE_BACKEND . '/base/http.php';

// Adresse der Verwaltung (Router, Dateien aus LE_FRONTEND). Die Login-Seite ist LOGIN_URL.
const LE_ADMIN_PATH = '/admin';
// Adresse der 404-Seite der Website (404.php oder 404.html über le_site_request_file).
const LE_SITE_NOT_FOUND_PAGE = '/404';
// Wert von <meta name="robots"> für Seiten, die nicht in Suchmaschinen sollen (404, Seiten mit eigenem noindex in der Sitemap).
const LE_SITE_NOINDEX = 'noindex';

/**
 * Ob die Adresse /$name schon vergeben ist: eine Datei, Seite oder ein Ordner der Website (le_site_request_file;
 * Adressen darunter gehören der Website) oder ein reservierter Name (le_site_reserved_names). Groß/klein zählt nicht:
 * Auf Hostern, deren Dateisystem sie nicht unterscheidet, wäre /Impressum dieselbe Seite wie /impressum.
 */
function le_site_path_taken(string $name): bool
{
    if (le_site_request_file('/' . $name) !== null) {
        return true;
    }
    $taken = le_site_reserved_names();
    foreach (scandir(LE_SITE_ROOT) ?: [] as $entry) {
        $taken[] = $entry;
        if (le_site_is_document($entry)) {
            $taken[] = pathinfo($entry, PATHINFO_FILENAME);
        }
    }

    return in_array(strtolower($name), array_map('strtolower', $taken), true);
}

/**
 * Erste Adress-Segmente, die der Router selbst belegt (klein geschrieben): Verwaltung, Login, Endpunkte, Plugins und
 * /public/ (darunter nur /public/site/, LE_SITE_FILES_URL). Eine feste Liste aus den Adressen, nicht der Inhalt des
 * Code-Ordners: Seiten wie /tools oder /docs gehören der Website.
 */
function le_router_reserved_names(): array
{
    return [ltrim(LE_ADMIN_PATH, '/'), ltrim(LOGIN_URL, '/'), trim(LE_API_URL, '/'), trim(PLUGINS_URL, '/'), explode('/', trim(LE_SITE_FILES_URL, '/'))[0]];
}

/** Erste Adress-Segmente, die nicht der Website gehören: die des Routers und die Teile der Website (includes). */
function le_site_reserved_names(): array
{
    return [...le_router_reserved_names(), LE_SITE_INCLUDES_DIR];
}

/**
 * Adresse ohne Endung für eine Seite, die mit Endung, mit „/“ am Ende oder über /public/site/ aufgerufen wurde ($path
 * kanonisch, $file aus le_site_request_file): /impressum.php → /impressum, /impressum/ → /impressum,
 * /public/site/index.html → /, /a/index.php → /a/ (Ordner mit index behalten ihr „/“).
 * null, wenn $path schon so heißt, die Datei kein Dokument ist, mit „_“ beginnt (Hilfs-Endpoints der Website)
 * oder die Adresse ohne Endung eine andere Datei liefern würde (z. B. a.php neben a.html) bzw. der Router sie
 * vorher selbst beantwortet (/login, /admin, /api …: le_site_reserved_names).
 */
function le_site_clean_path(string $path, string $file): ?string
{
    $name = basename($file);
    // Ob nach Endung oder /public/site/ gefragt wurde, auch kodiert (/impressum.ph%70); verglichen wird roh.
    $decoded = le_site_decoded_path($path) ?? $path;
    $asked = le_site_is_document($decoded) || str_starts_with($decoded, LE_SITE_FILES_URL) || ($decoded !== '/' && str_ends_with($decoded, '/'));
    if (!$asked || !le_site_is_document($file) || str_starts_with($name, '_')) {
        return null;
    }
    $relative = substr($file, strlen(LE_SITE_ROOT) + 1);
    $dir = dirname($relative) === '.' ? '' : dirname($relative) . '/';
    $stem = pathinfo($name, PATHINFO_FILENAME);
    // Adresse wie im Browser: Leerzeichen, Klammern, Umlaute als %XX.
    $clean = '/' . implode('/', array_map('rawurlencode', explode('/', $dir . ($stem === 'index' ? '' : $stem))));
    $first = strtolower(explode('/', ltrim($clean, '/'))[0]);
    if ($first !== '' && in_array($first, array_map('strtolower', le_site_reserved_names()), true)) {
        return null;
    }
    if ($clean === $path || realpath((string) le_site_request_file($clean)) !== realpath($file)) {
        return null;
    }

    return $clean;
}

/**
 * Was der Router für eine Adresse ausliefert (auf oberster Ebene eingebunden, siehe dort):
 *   file   – Seitendatei (PHP oder HTML), null ohne (dann leeres HTML für finish)
 *   status – HTTP-Status
 *   vars   – Variablen, die die Seite sieht (z. B. $item in page.php von Content-Typen)
 *   finish – null oder Closure(string $html): string, bekommt das gerenderte HTML vor Shortcodes und Filtern
 *   editor – Datei, deren Seite der Seiten-Editor bearbeitet (site_editor_page)
 * Plugins liefern dieselbe Form über den Hook site_page.
 */
function le_site_document(?string $file, int $status = 200, array $vars = [], ?Closure $finish = null, ?string $editor = null): array
{
    return ['file' => $file, 'status' => $status, 'vars' => $vars, 'finish' => $finish, 'editor' => $editor ?? (string) $file];
}

/**
 * Ob der Router für $path (kanonisch, ohne Datei der Website und ohne Plugin-Seite) die 404-Seite zeigt: Adressen
 * ohne Endung oder mit der eines Dokuments. Fehlende Bilder, Skripte und Stylesheets bekommen nur „Not Found“.
 */
function le_site_not_found_is_page(string $path): bool
{
    $ext = pathinfo(rtrim($path, '/'), PATHINFO_EXTENSION);

    return $ext === '' || le_site_is_document($path);
}
