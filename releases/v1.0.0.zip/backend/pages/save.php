<?php
declare(strict_types=1);

// Seiten speichern, ganz oder gar nicht (AGENTS.md): Seiten-JSON samt Backup, Seite und Komponenten zusammen.

require_once LE_BACKEND . '/base/files.php';
require_once LE_BACKEND . '/base/http.php';
require_once LE_BACKEND . '/base/texts.php';
require_once LE_BACKEND . '/pages/history.php';
require_once LE_BACKEND . '/pages/rewrite.php';
require_once LE_BACKEND . '/pages/store.php';
require_once LE_BACKEND . '/html/markup.php';
require_once LE_BACKEND . '/html/textMarkup.php';
require_once LE_BACKEND . '/pages/fields.php';
require_once LE_BACKEND . '/pages/labels.php';

/**
 * $kinds: Feldarten aus der Datei (siehe sanitize_content_tree). Gleicht der Inhalt dem
 * gespeicherten, wird nichts geschrieben und kein Backup angelegt (wiederholter Import), außer
 * es kommen Komponenten dieses Speicherns mit ($history['components'], save_page_group).
 * Neben dem Backup liegt die Kurzinfo für den Verlauf (backup_info); $history: 'doc' = Baum der
 * neuen Quelldatei für die Feldnamen (Import, sonst wird die Datei gelesen), 'restored' = true
 * beim Wiederherstellen, 'components' = Name → ['before' => Inhalt davor, 'after' => Inhalt
 * danach, 'fields' => Felder (ID mit Präfix)] (save_page_group), 'user' = Urheber statt des
 * angemeldeten Benutzers (Abgleich, LE_SYNC_AUTHOR). Liefert die Kurzinfo des
 * Backups ([] ohne Backup, erste JSON) oder null, wenn nichts geschrieben wurde. Der Aufrufer
 * hält die Sperre (lock_pages) und räumt alte Backups erst weg, wenn alles geschrieben ist
 * (prune_backups), damit ein Fehler danach den Stand davor wiederherstellen kann.
 * $sourceHash: Hash der Quelldatei nach diesem Schreiben (le_plan_source_hash), null behält den
 * gemerkten; ändert sich nur er, schreibt le_write_source_hash ihn ohne Backup (Rückgabe null).
 */
function save_page_content(string $page, array $content, array $kinds = [], array $history = [], ?string $sourceHash = null): ?array
{
    prepare_storage();
    $page = safe_page_name($page);
    $path = page_json_path($page);
    $components = $history['components'] ?? [];

    $content = sanitize_content_tree($content, $kinds);
    $current = is_file($path) ? (string) file_get_contents($path) : null;
    $storedHash = $current === null ? null : le_page_json_source_hash($current);
    $sourceHash ??= $storedHash;
    $json = page_json_text($content, $sourceHash);
    if ($json === null) {
        json_response(['ok' => false, 'error' => API_TEXT['encodeFailed']], 500);
    }
    if ($current === null) {
        atomic_write($path, $json);
        return [];
    }
    if ($current === $json && $components === []) {
        return null;
    }
    $old = le_page_json_content($current);
    if ($sourceHash !== $storedHash && $components === [] && $old !== null && page_json_text($old) === page_json_text($content)) {
        le_write_source_hash($page, (string) $sourceHash);
        return null;
    }
    $delay = (int) getenv(SAVE_DELAY_ENV);
    if ($delay > 0) {
        usleep($delay * 1000);
    }

    $backupPath = create_backup_file($page, $current);
    $info = backup_info($page, $old ?? [], $content, $kinds, $history['doc'] ?? null, !empty($history['restored']), $history['user'] ?? null);
    if ($components !== []) {
        $info['fields'] = array_merge($info['fields'], ...array_values(array_column($components, 'fields')));
        $info['components'] = array_map(static fn (array $component): array => ['before' => $component['before'], 'after' => $component['after']], $components);
    }
    $encoded = json_encode($info, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($encoded !== false) {
        atomic_write(backup_info_path($backupPath), $encoded . PHP_EOL);
    }

    atomic_write($path, $json);
    return $info;
}

/**
 * Ein Speichern einer Seite samt Komponenten (api/savePage.php, api/restore.php): $plans Name →
 * ['content' => Inhalt, 'kinds' => Feldarten, 'file'/'source' wie aus plan_source_rewrite für den
 * Hash der Quelldatei] für die Seite $page und mitgeschickte Komponenten.
 * Erst die Komponenten, dann die Seite. Hat sich eine Komponente geändert, bekommt die Seite einen
 * Verlaufseintrag, auch wenn sie selbst gleich bleibt: Seine Kurzinfo nennt die Felder der
 * Komponente (ID mit Präfix, Name wie im Editor, 'component' = ihr Name) und trägt ihren Inhalt davor und danach, damit
 * „Diesen Stand wiederherstellen“ sie mit zurücksetzt (backup_components).
 * Liefert, ob eine JSON geschrieben wurde. Der Aufrufer hält die Sperre (lock_pages).
 */
function save_page_group(string $page, array $plans, bool $restored = false): bool
{
    $written = false;
    $components = [];
    foreach ($plans as $name => $plan) {
        $name = (string) $name; // Seiten wie „404“: PHP macht den Schlüssel zur Zahl.
        if ($name === $page) {
            continue;
        }
        $before = load_component_content($name) ?? [];
        $info = save_page_content($name, $plan['content'], $plan['kinds'], ['restored' => $restored], le_plan_source_hash($plan));
        $written = $written || $info !== null;
        if (($info['fields'] ?? []) !== []) {
            $prefix = field_id_prefix($name);
            $components[$name] = [
                'before' => $before,
                'after' => load_component_content($name) ?? [],
                'fields' => array_map(static fn (array $field): array => ['id' => $prefix . $field['id'], 'component' => $name] + $field, $info['fields']),
            ];
        }
    }
    $info = save_page_content($page, $plans[$page]['content'], $plans[$page]['kinds'], ['restored' => $restored, 'components' => $components], le_plan_source_hash($plans[$page]));
    return $written || $info !== null;
}

// Name der Seite in Meldungen zu Schreibfehlern (plan_label, write_failed_message) statt ihres Dateinamens.
const SAVE_WRITE_TEXT = [
    'page' => 'diese Seite',
];
// Zusätze zur Meldung bei Konflikten beim Speichern (save_conflict_message).
const SAVE_CONFLICT_TEXT = [
    'saved' => 'Alle anderen Änderungen sind gespeichert.',
    'reload' => 'Du kannst deine Fassung trotzdem speichern oder die andere übernehmen.',
];

/**
 * Altbestand angleichen (api/getPage.php, api/restore.php; $doc aus page_source_doc): Hat ein
 * Textfeld denselben Klartext wie die Datei, aber eine andere Form (alter Klartext mit &, <br>
 * ohne Fettung …), gilt das bereinigte Fragment der Datei – so verliert der erste Save nach
 * dem Update keine Fettung. $plainOnly (Restore): nur Werte ohne Auszeichnung angleichen, ein
 * Backup mit anderer Fettung oder anderem Link stellt diese wieder her; eines, das sich nur durch
 * fehlende Attribute unterscheidet (Stand vor text_markup_attrs), behält die Klassen der Datei.
 */
function align_text_with_source(array $doc, string $name, array $content, bool $plainOnly = false): array
{
    $prefix = field_id_prefix($name);
    foreach (flatten_content($content) as $id => $value) {
        if (!is_string($value)) {
            continue;
        }
        $found = find_field_element($doc, $prefix . $id);
        if (is_string($found) || $found[1] !== 'inner' || markup_inner_has_php($doc, $found[0])) {
            continue;
        }
        $fromFile = source_field_value($doc, $found[0], 'inner');
        if ($fromFile === $value || text_markup_plain($fromFile) !== text_markup_plain($value)) {
            continue;
        }
        if (!$plainOnly || !text_markup_has_formatting($value) || text_markup_without_attrs($fromFile) === $value) {
            set_nested_value($content, (string) $id, $fromFile);
        }
    }
    return $content;
}

/**
 * Inhalt einer Seite für den Seiten-Editor (api/getPage.php) und als Stand jetzt beim Speichern
 * (merge_save_content): ['content' => Felder der Seite samt Komponenten, 'fieldKinds' => Pfad →
 * Feldart, 'docs' => Name → Baum der Quelldatei für die Feldnamen]. Altbestand ohne Auszeichnung
 * bekommt die Form der Datei (align_text_with_source); Seitenfelder mit Komponenten-Präfix (ältere
 * Importe) stehen neben den Feldern der Komponente und gehen vor (split_page_content).
 */
function page_editor_content(string $page): array
{
    $docs = [$page => page_source_doc($page)];
    $content = align_text_with_source($docs[$page], $page, load_page_content($page));
    $fieldKinds = page_field_kinds($docs[$page], $page, $content);
    foreach (array_keys(shared_components()) as $componentName) {
        $componentContent = load_component_content($componentName);
        if ($componentContent !== null) {
            $docs[$componentName] = page_source_doc($componentName);
            $componentContent = align_text_with_source($docs[$componentName], $componentName, $componentContent);
            foreach (page_field_kinds($docs[$componentName], $componentName, $componentContent) as $id => $kind) {
                $fieldKinds[$componentName . '.' . $id] ??= $kind;
            }
            $content[$componentName] = array_replace_recursive($componentContent, is_array($content[$componentName] ?? null) ? $content[$componentName] : []);
        }
    }
    return ['content' => $content, 'fieldKinds' => $fieldKinds, 'docs' => $docs];
}

/**
 * Speichern gegen den Stand beim Laden (api/savePage.php): $content = Inhalt im Editor, $base =
 * derselbe Inhalt beim Laden (getPage), $current = Stand jetzt (page_editor_content), alles samt
 * Komponenten. Je Feld: gleicht der Editor-Wert $base, hat der Editor es nicht geändert und es gilt
 * der Stand jetzt (eine länger offene Seite überschreibt nichts Neueres). Ein geändertes Feld wird
 * übernommen, wenn es seit dem Laden gleich blieb (oder schon den neuen Wert hat), sonst hat es
 * jemand anderes geändert: Es bleibt, wie es ist, und kommt in 'conflicts'.
 * Liefert ['content' => Inhalt zum Speichern, 'saved' => IDs übernommener Änderungen, 'conflicts' => IDs].
 */
function merge_save_content(array $current, array $content, array $base): array
{
    $merged = flatten_content($current);
    $loaded = flatten_content($base);
    $saved = [];
    $conflicts = [];
    foreach (flatten_content($content) as $id => $value) {
        $id = (string) $id;
        $before = $loaded[$id] ?? null;
        $now = $merged[$id] ?? null;
        if ($value === $before || $value === $now) {
            continue;
        }
        if ($now === $before) {
            $merged[$id] = $value;
            $saved[] = $id;
        } else {
            $conflicts[] = $id;
        }
    }
    return ['content' => unflatten_content($merged), 'saved' => $saved, 'conflicts' => $conflicts];
}

/**
 * Stand beim Laden für merge_save_content, in dem die Felder aus $overwrite den Stand jetzt bekommen: Sie gelten dann
 * als seit dem Laden unverändert, die geschickte Fassung ($content) wird gespeichert. Nur Felder, die der Absender
 * geändert hat; gibt es eines nicht mehr, scheitert das Speichern daran (nicht gefunden) statt wieder Konflikt zu sein.
 */
function le_save_base_overwrite(array $base, array $current, array $content, array $overwrite): array
{
    if ($overwrite === []) {
        return $base;
    }
    $flat = flatten_content($base);
    $now = flatten_content($current);
    $sent = flatten_content($content);
    foreach ($overwrite as $id) {
        if (!is_string($id) || !array_key_exists($id, $sent) || ($flat[$id] ?? null) === $sent[$id]) {
            continue;
        }
        if (array_key_exists($id, $now)) {
            $flat[$id] = $now[$id];
        } else {
            unset($flat[$id]);
        }
    }
    return unflatten_content($flat);
}

/** Konflikte als Felder wie in der 422-Antwort ([['id', 'label', 'reason']]), Namen wie im Editor ($docs aus page_editor_content). */
function save_conflict_fields(array $ids, array $docs): array
{
    $labels = build_labels_for_content(unflatten_content(array_fill_keys($ids, '')), $docs);
    return array_map(static fn (string $id): array => ['id' => $id, 'label' => $labels[$id], 'reason' => REWRITE_REASONS['conflict']], $ids);
}

/** Meldung zu Konflikten beim Speichern; $saved: die übrigen Änderungen sind gespeichert. */
function save_conflict_message(array $fields, bool $saved): string
{
    return rewrite_error_message($fields) . ($saved ? ' ' . SAVE_CONFLICT_TEXT['saved'] : '') . ' ' . SAVE_CONFLICT_TEXT['reload'];
}

/**
 * Teilt den Inhalt einer Seite samt Komponenten (api/savePage.php) in Name → Inhalt. Unter dem
 * Schlüssel einer Komponente stehen ihre Felder; Felder, die in der Seitendatei markiert sind
 * (Seiten-IDs mit Komponenten-Präfix aus älteren Importen, z. B. header.eigen), gehören der Seite,
 * so fällt beim Speichern kein Seitenfeld aus ihrem JSON. Gibt es eine solche ID auch in der
 * Komponente, behält die Komponente ihren gespeicherten Wert. Eine Komponente ohne eigene Felder
 * bekommt keinen Plan. Gegenstück: page_editor_content legt diese Seitenfelder zu den Feldern der
 * Komponente.
 */
function split_page_content(string $page, array $content): array
{
    $pageDoc = null;
    $plans = [];
    foreach (array_keys(shared_components()) as $name) {
        if (!isset($content[$name]) || !is_array($content[$name])) {
            continue;
        }
        $component = [];
        $own = [];
        $stored = null;
        foreach (flatten_content($content[$name]) as $id => $value) {
            $id = (string) $id;
            $pageDoc ??= page_source_doc($page);
            if (find_field_element($pageDoc, $name . '.' . $id) === 'missing') {
                $component[$id] = $value;
                continue;
            }
            $own[$id] = $value;
            $stored ??= flatten_content(load_component_content($name) ?? []);
            if (array_key_exists($id, $stored)) {
                $component[$id] = $stored[$id];
            }
        }
        // Nur mit Feldern der Komponente ein Plan: sonst bliebe ihr JSON leer bzw. scheiterte eine
        // Site ohne Komponenten-Datei an „Quelldatei fehlt“, obwohl alle Felder der Seite gehören.
        if (array_diff_key($component, $own) !== []) {
            $plans[$name] = unflatten_content($component);
        }
        if ($own === []) {
            unset($content[$name]);
        } else {
            $content[$name] = unflatten_content($own);
        }
    }
    $plans[$page] = $content;
    return $plans;
}

/**
 * Schreibt fehlerfreie Pläne einer Seite samt Komponenten (Name → plan_source_rewrite plus
 * 'content') als ein Speichern: erst alle JSON samt Backups (save_page_group), dann alle Dateien;
 * „zuletzt gespeichert“ rückt vor, wenn sich etwas geändert hat. Ganz oder gar nicht auch beim
 * Schreiben: Lässt sich eine Datei oder Ablage nicht schreiben, antwortet es vorher mit 422 wie
 * bei Feldfehlern (plan_write_errors). Scheitert danach doch ein Schreiben (Platte voll), stellt
 * plans_restore_point den Stand davor her, bevor der Request endet; alte Backups und Snapshots räumt erst ein
 * gelungenes Speichern weg. Der Aufrufer hält lock_pages.
 */
function write_page_plans(string $page, array $plans, bool $restored = false): void
{
    // Fehlende Ablage (Seiten, Backups, Originale) zuerst anlegen; geht das nicht, meldet es plan_write_errors als 422.
    try {
        prepare_storage();
    } catch (RuntimeException $e) {
    }
    $errors = plan_write_errors($plans);
    if ($errors !== []) {
        json_response(['ok' => false, 'error' => write_failed_message(array_column($errors, 'label')), 'fields' => $errors], 422);
    }
    $restore = plans_restore_point($plans);
    $done = false;
    register_shutdown_function(static function () use (&$done, $restore): void {
        if (!$done) {
            $restore();
        }
    });
    $changed = save_page_group($page, $plans, $restored);
    foreach ($plans as $plan) {
        $changed = $changed || $plan['source'] !== null;
        write_source_rewrite($plan);
    }
    $done = true;
    foreach ($plans as $name => $plan) {
        prune_backups((string) $name);
        if ($plan['source'] !== null) {
            prune_file_snapshots($plan['file']);
        }
    }
    if ($changed) {
        mark_page_updated($page);
    }
}

/** Name eines Plans in Meldungen: Kopf-/Fußzeile (COMPONENT_LABELS), sonst „diese Seite“, nie eine Datei. */
function plan_label(string $name): string
{
    return COMPONENT_LABELS[$name] ?? SAVE_WRITE_TEXT['page'];
}

/**
 * Fehler wie aus plan_source_rewrite für alles, was das Speichern der Pläne schreiben würde und
 * nicht kann: geänderte Quelldatei (schreibgeschützt oder Ordner ohne Schreibrecht), JSON und
 * Backup-Ordner unter private/cache. Eine Komponente, an der sich nichts ändert (save_page_content
 * schreibt sie nicht), zählt nicht. Leer, wenn alles geht.
 */
function plan_write_errors(array $plans): array
{
    $errors = [];
    foreach ($plans as $name => $plan) {
        $name = (string) $name;
        $json = page_json_path($name);
        $unchanged = isset(COMPONENT_LABELS[$name]) && $plan['source'] === null && is_file($json)
            && file_get_contents($json) === page_json_text(sanitize_content_tree($plan['content'], $plan['kinds']), le_plan_source_hash($plan));
        $reason = match (true) {
            $unchanged => null,
            $plan['source'] !== null && !path_writable($plan['file']) => REWRITE_REASONS['file_locked'],
            !path_writable($json), !is_writable(BACKUPS_ROOT . '/' . safe_page_name($name)) => REWRITE_REASONS['store_locked'],
            default => null,
        };
        if ($reason !== null) {
            $errors[] = ['id' => $name, 'label' => plan_label($name), 'reason' => $reason];
        }
    }
    return $errors;
}

/**
 * Stand vor dem Schreiben der Pläne: Inhalt der JSON und der geänderten Quelldateien, Dateien in
 * den Backup-Ordnern und unter ORIGINALS_ROOT. Liefert die Funktion, die ihn wiederherstellt
 * (Dateien zurück, neu angelegte Backups, Kurzinfos und Snapshots weg). Unter ORIGINALS_ROOT nur
 * die Snapshots der eigenen Quelldateien: Snapshots einer gleichzeitig gespeicherten anderen Seite bleiben.
 */
function plans_restore_point(array $plans): Closure
{
    $files = [];
    $dirs = [];
    $snapshots = [];
    foreach ($plans as $name => $plan) {
        $json = page_json_path((string) $name);
        $files[$json] = is_file($json) ? (string) file_get_contents($json) : null;
        if ($plan['source'] !== null) {
            $files[$plan['file']] = (string) file_get_contents($plan['file']);
            [$base, $ext] = snapshot_name_parts($plan['file']);
            $snapshots[] = '/^' . preg_quote($base, '/') . '\.\d{14}' . preg_quote($ext, '/') . '$/';
        }
        $dir = BACKUPS_ROOT . '/' . safe_page_name((string) $name);
        $dirs[$dir] = dir_entries($dir);
    }
    $originals = dir_entries(ORIGINALS_ROOT);
    return static function () use ($files, $dirs, $originals, $snapshots): void {
        foreach ($files as $file => $content) {
            if ($content === null) {
                @unlink($file);
            } elseif (@file_get_contents($file) !== $content) {
                // Atomar wie beim Speichern (Rechte der Datei bleiben): Scheitert es, bleibt die neue Fassung ganz statt halb.
                try {
                    write_file_atomic($file, $content);
                } catch (RuntimeException $e) {
                    error_log('save rollback: ' . $e->getMessage());
                }
            }
            forget_compiled_file($file);
        }
        foreach ($dirs as $dir => $before) {
            foreach (array_diff(dir_entries($dir), $before) as $added) {
                @unlink($dir . '/' . $added);
            }
        }
        foreach (array_diff(dir_entries(ORIGINALS_ROOT), $originals) as $added) {
            foreach ($snapshots as $pattern) {
                if (preg_match($pattern, $added) === 1) {
                    @unlink(ORIGINALS_ROOT . '/' . $added);
                    break;
                }
            }
        }
    };
}

// Nur für die Tests (tests/): Millisekunden Pause zwischen Lesen und Schreiben in save_page_content,
// damit sich gleichzeitige Saves ohne Sperre sicher überschneiden. Sonst nie gesetzt.
const SAVE_DELAY_ENV = 'LEBUILD_TEST_SAVE_DELAY_MS';

/**
 * Stand aus dem Verlauf wiederherstellen (api/pages/restore.php): Name des Backups prüfen (400 invalidBackup), dann
 * dieselbe Sperre wie beim Speichern, für die Seite und alle Komponenten, die der Eintrag mit zurücksetzen kann. Den
 * Eintrag samt Komponenten vor dem Abgleich lesen (le_backup_entry): Dessen Backup räumt alte Backups weg, der gewählte
 * (älteste) Stand ginge sonst verloren. Direkt geänderte Dateien danach abgleichen (le_sync_request, scheitert es: 422),
 * sonst verdeckte der neue Hash ihre unmarkierten Teile. Ein Abbruch hält die Sperren bis nach der Rücknahme
 * (le_hold_until_shutdown in le_sync_request). Liefert die Antwort ohne 'ok': page, restored, skipped, bei gescheitertem Abgleich einer
 * Komponente message.
 */
function le_page_restore(string $page, string $backup): array
{
    // Abgleich erst hier: save.php lädt auch getPage, der Abgleich lädt den Import.
    require_once LE_BACKEND . '/pages/sync.php';
    if (!preg_match(LE_BACKUP_NAME_PATTERN, $backup)) {
        json_response(['ok' => false, 'error' => API_TEXT['invalidBackup']], 400);
    }

    $entry = [];
    [$locks, $sync] = le_sync_request([$page, ...array_keys(shared_components())], static function () use ($page, $backup, &$entry): void {
        $entry = le_backup_entry($page, $backup);
    });

    // Die Seite aus dem Backup, dazu die Komponenten, die das Speichern dieses Eintrags mitgeschrieben
    // hat (backup_components); ganz oder gar nicht wie beim Speichern.
    // Nur Felder, die in der Datei noch markiert sind; IDs, die es nicht mehr gibt, werden gezählt.
    // Alter Klartext (ohne Auszeichnung) mit gleichem Text behält die Auszeichnung der Datei (wie getPage);
    // ein Wert mit Auszeichnung kommt so zurück, wie er im Backup steht.
    // Die Live-Seite rendert aus public/, nicht aus dem JSON: erst prüfen, dann beides schreiben.
    $plans = [];
    $errors = [];
    $restoredCount = 0;
    $skipped = 0;
    foreach ($entry as $name => $values) {
        $name = (string) $name; // Seiten wie „404“: PHP macht den Schlüssel zur Zahl.
        // Eine Komponente, deren Datei es nicht mehr gibt oder deren Abgleich gescheitert ist (le_sync_request),
        // blockiert die Seite nicht: ihre Felder zählen als übersprungen. Fehlt die Seite selbst, bleibt es beim Fehler.
        if ($name !== $page && (page_source_path($name) === null || isset($sync['failed'][$name]))) {
            $skipped += count(flatten_content($values));
            continue;
        }
        $doc = page_source_doc($name);
        ['content' => $restored, 'skipped' => $unknown] = known_source_fields($doc, $name, $values);
        $restored = align_text_with_source($doc, $name, $restored, true);
        $plans[$name] = ['doc' => $doc, 'restored' => $restored] + plan_source_rewrite($name, $restored);
        $errors = array_merge($errors, $plans[$name]['errors']);
        $restoredCount += count(flatten_content($restored));
        $skipped += $unknown;
    }
    if ($errors !== []) {
        le_rewrite_failed($errors);
    }
    // Das Backup liegt über dem aktuellen Stand: Felder, die es nicht kennt (z. B. später
    // dazugekommene Alt-Texte), bleiben im JSON wie in der Datei.
    foreach ($plans as $name => $plan) {
        $name = (string) $name;
        // Eine kaputte aktuelle JSON (unlesbar) ersetzt das Backup ganz: So repariert „Verlauf“ die Seite.
        $plans[$name]['content'] = array_replace_recursive(load_component_content($name) ?? [], $plan['restored']);
        $plans[$name]['kinds'] = page_field_kinds($plan['doc'], $name, $plans[$name]['content']);
    }

    write_page_plans($page, $plans, true);
    unlock_pages($locks);
    // Nach den Einträgen des Abgleichs (le_log_after_unlock), der dieses Wiederherstellen ausgelöst hat.
    le_log_after_unlock([$page => 'page_restored'], $locks, null);

    return ['page' => $page, 'restored' => $restoredCount, 'skipped' => $skipped] + le_sync_skipped_notice($sync['failed']);
}

/**
 * Speichern aus dem Seiten-Editor (api/pages/save.php), ganz oder gar nicht: erst alle Ersetzungen (Komponenten und Seite)
 * berechnen, dann JSON mit Backup und Seitendateien schreiben. Die Sperre hält über den ganzen Ablauf, damit gleichzeitige
 * Saves keinen Stand verlieren und der Verlauf jeden Stand richtig zuordnet; ein Abbruch hält sie bis nach der Rücknahme
 * (le_hold_until_shutdown in le_sync_request). Mit Stand beim Laden ($base, aus getPage) kommen alle Komponenten aus dem Stand jetzt dazu,
 * also sind alle gesperrt; ohne ihn gilt $content ganz (Aufrufe ohne geladenen Stand). Direkt geänderte Dateien gleicht
 * le_sync_request vorher ab (scheitert das für die Seite, 422 und nichts gespeichert): Ihr neuer Stand ist dann der Stand
 * jetzt, ein direkt geändertes Feld, das auch der Editor geändert hat, wird Konflikt. $overwrite: Konflikt-Felder, die der
 * Benutzer trotzdem mit seiner Fassung überschreibt („Meine Fassung speichern“).
 * Liefert die Antwort ohne 'ok': page, updatedAt, conflicts, refreshed (ohne Konflikt lädt der Editor ohnehin neu, mit
 * Konflikt bietet er „Andere Fassung übernehmen“ an), bei Konflikten message und saved. Fehler beenden die Anfrage
 * (json_response): 409 nur Konflikte, 422 Abgleich, Felder, Schreibrechte, 500/503 Sperren und Schreiben (Rücknahme).
 */
function le_page_save(string $page, array $content, ?array $base, array $overwrite): array
{
    // Abgleich und offene Uploads erst hier: save.php lädt auch getPage, die offenen Uploads laden das Plugin-System.
    require_once LE_BACKEND . '/pages/sync.php';
    require_once LE_BACKEND . '/media/openUploads.php';
    [$locks, $sync] = le_sync_request([$page, ...array_keys($base === null ? array_intersect_key($content, shared_components()) : shared_components())]);
    $refreshed = $sync['refreshed'] !== [];
    // Von jemand anderem seit dem Laden geänderte Felder bleiben, wie sie sind, die übrigen Änderungen
    // werden gespeichert (ganz oder gar nicht); ohne übrige Änderung wird nichts geschrieben.
    $conflicts = [];
    if ($base !== null) {
        $editor = page_editor_content($page);
        $base = le_save_base_overwrite($base, $editor['content'], $content, $overwrite);
        ['content' => $content, 'saved' => $saved, 'conflicts' => $conflictIds] = merge_save_content($editor['content'], $content, $base);
        $conflicts = save_conflict_fields($conflictIds, $editor['docs']);
        if ($conflicts !== [] && $saved === []) {
            json_response(['ok' => false, 'error' => save_conflict_message($conflicts, false), 'fields' => $conflicts, 'refreshed' => $refreshed], 409);
        }
    }
    // Komponente, deren Abgleich gescheitert ist: Würde ihr Plan ihren gespeicherten Stand ändern, 422 (die Meldung
    // nennt sie), sonst bleibt sie, wie sie ist (ihr altes JSON bekäme sonst den Hash der direkten Änderung). Nach dem
    // Plan, nicht nach dem Präfix der ID: Seitenfelder mit Komponenten-Präfix (ältere Importe) gehören der Seite.
    $plans = split_page_content($page, $content);
    $touched = array_filter($sync['failed'], static fn (string $name): bool => isset($plans[$name])
        && array_diff_assoc(flatten_content($plans[$name]), flatten_content(load_component_content($name) ?? [])) !== [], ARRAY_FILTER_USE_KEY);
    if ($touched !== []) {
        le_sync_failed($touched);
    }
    $plans = array_diff_key($plans, $sync['failed']);

    // Vom Prüfen der Bilder bis zum Schreiben nacheinander mit dem Erledigen offener Uploads (le_open_uploads_hold):
    // Kein neues Bild verschwindet mitten im Speichern, ein schon gelöschtes lehnt das Speichern ab.
    le_open_uploads_hold(static function () use ($page, $plans): void {
        $errors = [];
        foreach ($plans as $name => $planContent) {
            $name = (string) $name; // Seiten wie „404“: PHP macht den Schlüssel zur Zahl.
            $plans[$name] = ['content' => $planContent] + plan_source_rewrite($name, $planContent, true);
            $errors = array_merge($errors, $plans[$name]['errors']);
        }
        if ($errors !== []) {
            le_rewrite_failed($errors);
        }

        write_page_plans($page, $plans);
    });
    // Bei Konflikten lädt der Editor nicht neu: Er bekommt die gespeicherten Werte so, wie getPage sie
    // liefert, als neuen Stand beim Laden.
    $response = ['page' => $page, 'updatedAt' => page_updated_at($page), 'conflicts' => $conflicts, 'refreshed' => $refreshed];
    if ($conflicts !== []) {
        $stored = flatten_content(page_editor_content($page)['content']);
        $response['message'] = save_conflict_message($conflicts, true);
        $response['saved'] = array_intersect_key($stored, array_flip($saved));
    }
    unlock_pages($locks);
    // Nach den Einträgen des Abgleichs (le_log_after_unlock), der dieses Speichern ausgelöst hat.
    le_log_after_unlock([$page => 'page_saved'], $locks, null);

    return $response;
}
