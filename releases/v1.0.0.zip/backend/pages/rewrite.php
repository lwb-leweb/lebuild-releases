<?php
declare(strict_types=1);

require_once LE_BACKEND . '/pages/store.php';
require_once LE_BACKEND . '/html/markup.php';
require_once LE_BACKEND . '/pages/labels.php';
require_once LE_BACKEND . '/html/icons.php';
require_once LE_BACKEND . '/base/files.php';
require_once LE_BACKEND . '/pages/fields.php';
require_once LE_BACKEND . '/media/uploads.php';
require_once LE_BACKEND . '/pages/history.php';
require_once LE_BACKEND . '/html/textMarkup.php';

// Gründe, warum ein Feld nicht zurückgeschrieben werden kann.
const REWRITE_REASONS = [
    'missing' => 'nicht gefunden',
    'duplicate' => 'mehrfach vorhanden',
    'php' => 'enthält PHP',
    'nested' => 'enthält ein anderes Feld',
    'void' => 'hat keinen Innenbereich',
    'no_file' => 'Quelldatei fehlt',
    // Beim Schreiben (plan_write_errors): Seitendatei bzw. Ablage unter private/cache.
    'file_locked' => 'Datei nicht beschreibbar',
    'store_locked' => 'Ablage nicht beschreibbar',
    'conflict' => 'inzwischen von jemand anderem geändert',
    'image_missing' => UPLOAD_TEXT['missing'],
    'image_document' => UPLOAD_TEXT['imageDocument'],
];
// Feldarten mit einem Bild als Wert: Beim Speichern muss ein neuer Wert ein Bild (le_upload_is_document) und, aus den
// Uploads, eine vorhandene Datei sein (le_upload_missing).
const LE_REWRITE_IMAGE_KINDS = ['image', 'background'];

/**
 * Berechnet die neue Datei für Feldwerte (ID → Wert, IDs wie in der Datei).
 * ['source' => neuer Inhalt oder null, wenn nichts zu ändern ist,
 *  'errors' => [['id' => …, 'reason' => Schlüssel aus REWRITE_REASONS]],
 *  'kinds' => [ID => Feldart aus der Markierung] für die JSON-Bereinigung]
 * Mit $checkUploads (Speichern, nicht Wiederherstellen) ist ein geändertes Bild, das ein Dokument ist (image_document), oder
 * eines aus den Uploads, dessen Datei fehlt (image_missing, le_upload_missing), ein Fehler. Unverändert heißt wie bei Plugin-Einträgen: steht schon in einem Bildfeld
 * der Datei (auch einem anderen).
 */
function rewrite_source(string $source, array $flat, bool $checkUploads = false, bool $php = true): array
{
    if ($checkUploads) {
        // Erst hier: Öffentliche Seiten binden diese Datei ein (backend/pages/siteEditor.php), brauchen die Uploads aber nicht.
        require_once LE_BACKEND . '/media/uploads.php';
    }
    $doc = le_markup_parse_source($source, $php);
    $replacements = [];
    $errors = [];
    $kinds = [];
    // Bildwerte in der Datei und geänderte Bilder (ID → Wert), geprüft nach der Schleife gegen alle gespeicherten.
    $storedImages = [];
    $newImages = [];
    // Feld je Ersetzung (gleicher Index), für die Prüfung auf PHP-Code nach der Schleife.
    $owners = [];
    foreach ($flat as $id => $value) {
        $owners = array_pad($owners, count($replacements), $previous ?? '');
        $previous = (string) $id;
        if (!is_string($value)) {
            continue;
        }
        $id = (string) $id;
        $found = find_field_element($doc, $id);
        if (is_string($found)) {
            $errors[] = ['id' => $id, 'reason' => $found];
            continue;
        }
        [$index, $target] = $found;
        $problem = $target === 'inner' ? null : edit_target_problem($doc['nodes'][$index], $target);
        if (($target === 'inner' || $target === 'icon') && markup_inner_has_php($doc, $index)) {
            $problem = 'php';
        }
        if ($problem !== null) {
            $errors[] = ['id' => $id, 'reason' => $problem];
            continue;
        }
        // Die Datei bekommt denselben bereinigten Wert wie das JSON (sanitize_content_tree mit 'kinds').
        $kinds[$id] = field_target_kind($doc, $index, $target);
        $value = sanitize_field_value($kinds[$id], $value);
        // Unverändert = gleiche bereinigte Form wie in der Datei; dann bleibt die Datei, auch innere Felder.
        $stored = source_field_value($doc, $index, $target);
        $isImage = $checkUploads && in_array($kinds[$id], LE_REWRITE_IMAGE_KINDS, true);
        if ($isImage) {
            $storedImages[] = $stored;
        }
        if ($stored === $value) {
            continue;
        }
        // Element liegt (ganz oder mit einem Ende) im PHP-Code, etwa in einem String: Text dort wäre Code. Erst hier,
        // damit ein unverändertes Feld dort das Speichern der übrigen nicht blockiert.
        if (le_markup_edit_in_php($doc, $doc['nodes'][$index])) {
            $errors[] = ['id' => $id, 'reason' => 'php'];
            continue;
        }
        if ($isImage) {
            $newImages[$id] = $value;
        }
        if ($target === 'background') {
            $replacements[] = markup_set_background_url($doc, $index, $value);
            continue;
        }
        if ($target === 'icon') {
            // Ohne Icon aus dem Satz (fremdes SVG, Backup davon) bleibt das SVG, wie es ist.
            if ($value !== '') {
                array_push($replacements, ...le_icon_replacements($doc, $index, $value));
            }
            continue;
        }
        if ($target !== 'inner') {
            $replacements[] = markup_set_attr($doc, $index, $target, markup_attr_escape($value));
            if ($target === 'src') {
                array_push($replacements, ...image_variant_removals($doc, $index));
            }
            continue;
        }
        if (inner_has_field($doc, $index)) {
            $errors[] = ['id' => $id, 'reason' => 'nested'];
            continue;
        }
        // Reiner Text kommt kodiert in den Rohtext (& < > als Entities), Auszeichnung so, wie sie ist.
        $replacements[] = markup_set_inner($doc, $index, $kinds[$id] === 'plain' ? text_markup_escape($value) : $value);
    }
    $owners = array_pad($owners, count($replacements), $previous ?? '');
    // Auch Folge-Ersetzungen eines Feldes (z. B. <source> neben einem neuen Bild) dürfen keinen PHP-Code berühren.
    $inPhp = [];
    foreach ($replacements as $i => $replacement) {
        if (le_markup_edit_in_php($doc, $replacement)) {
            $inPhp[$owners[$i]] = true;
        }
    }
    foreach (array_keys($inPhp) as $id) {
        $errors[] = ['id' => (string) $id, 'reason' => 'php'];
    }
    // Ein Fehler hier bricht das Speichern ganz ab, die Ersetzung dieser Felder wird nie geschrieben. Nur geänderte Bilder:
    // Ein schon gespeichertes Dokument im Bildfeld hält das Speichern der übrigen Felder nicht auf und lässt sich ersetzen.
    foreach ($newImages as $id => $value) {
        if (le_upload_is_document($value)) {
            $errors[] = ['id' => $id, 'reason' => 'image_document'];
        } elseif (le_upload_missing($value, $storedImages)) {
            $errors[] = ['id' => $id, 'reason' => 'image_missing'];
        }
    }

    return [
        'source' => $replacements === [] ? null : markup_apply($source, $replacements),
        'errors' => $errors,
        'kinds' => $kinds,
    ];
}

/**
 * Plan für das Zurückschreiben einer Seite oder Komponente (header/footer):
 * ['file' => Pfad|null, 'source' => neuer Inhalt|null, 'errors' => [['id', 'label', 'reason' (deutsch)]],
 *  'kinds' => [Pfad wie im Inhalt => Feldart] für save_page_content].
 * Schreibt nichts; das macht write_source_rewrite() nach der Fehlerprüfung. $checkUploads wie bei rewrite_source.
 */
function plan_source_rewrite(string $name, array $content, bool $checkUploads = false): array
{
    $file = page_source_path($name);
    if ($file === null) {
        return ['file' => null, 'source' => null, 'errors' => [['id' => $name, 'label' => $name, 'reason' => REWRITE_REASONS['no_file']]], 'kinds' => []];
    }
    $prefix = field_id_prefix($name);
    $flat = [];
    foreach (flatten_content($content) as $id => $value) {
        $flat[$prefix . $id] = $value;
    }
    $result = rewrite_source((string) file_get_contents($file), $flat, $checkUploads, le_source_is_php($file));
    $errors = [];
    $table = $result['errors'] === [] ? [] : page_label_table($name, page_source_doc($name));
    foreach ($result['errors'] as $error) {
        $errors[] = ['id' => $error['id'], 'label' => label_for_id($table, $error['id'], $name), 'reason' => REWRITE_REASONS[$error['reason']]];
    }

    $kinds = [];
    foreach ($result['kinds'] as $id => $kind) {
        $kinds[substr((string) $id, strlen($prefix))] = $kind;
    }

    return ['file' => $file, 'source' => $result['source'], 'errors' => $errors, 'kinds' => $kinds];
}

/** Schreibt einen fehlerfreien Plan atomar (mit Snapshot); nichts zu tun, wenn sich nichts ändert. */
function write_source_rewrite(array $plan): void
{
    if ($plan['source'] === null) {
        return;
    }
    snapshot_original_file($plan['file'], false);
    atomic_write($plan['file'], $plan['source']);
}

/** Meldung für die 422-Antwort: „‚Name‘ (Grund) konnte nicht gespeichert werden.“ */
function rewrite_error_message(array $errors): string
{
    $names = array_map(static fn (array $e): string => '‚' . $e['label'] . '‘ (' . $e['reason'] . ')', $errors);
    return implode(', ', $names) . (count($errors) === 1 ? ' konnte' : ' konnten') . ' nicht gespeichert werden.';
}

/** Antwortet 422 mit den Feldfehlern aus plan_source_rewrite (Meldung rewrite_error_message) und beendet die Anfrage. */
function le_rewrite_failed(array $errors): void
{
    json_response(['ok' => false, 'error' => rewrite_error_message($errors), 'fields' => $errors], 422);
}
