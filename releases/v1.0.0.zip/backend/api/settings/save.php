<?php
declare(strict_types=1);

require_once LE_BACKEND . '/site/indexNow.php';
require_once LE_BACKEND . '/base/activity.php';
require_once LE_BACKEND . '/base/siteConfig.php';

le_indexnow_watch();

le_site_config_save(read_json_body());
le_activity_log('settings_saved');

json_response(['ok' => true]);
