<?php
declare(strict_types=1);

require_once LE_BACKEND . '/base/http.php';
require_once LE_BACKEND . '/base/siteConfig.php';


// Ohne Gespeichertes die neutralen Vorgaben (LE_SITE_CONFIG_DEFAULTS).
json_response(['ok' => true, 'config' => le_site_config_with_defaults()]);
