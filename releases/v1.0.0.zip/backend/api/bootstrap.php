<?php
declare(strict_types=1);

require_once LE_BACKEND . '/users/auth.php';
require_once LE_BACKEND . '/pages/store.php';
require_once LE_BACKEND . '/plugins/plugins.php';
require_once LE_BACKEND . '/database/migration.php';
require_once LE_BACKEND . '/backup/siteBackup.php';
require_once LE_BACKEND . '/system/checks.php';
require_once LE_BACKEND . '/update/updater.php';
require_once LE_BACKEND . '/media/library.php';
require_once LE_BACKEND . '/update/notice.php';
require_once LE_BACKEND . '/pages/import.php';

resume_app_session(false);

// Session ohne existierenden Benutzer (gelöscht) zählt als ausgeloggt.
$currentUser = session_user();
$authenticated = $currentUser !== null;

// Ein Update aus diesem Abruf oder, schon beim Login eingespielt, aus der Session (dann gilt er als gezeigt).
$update = $authenticated ? updater_auto_update('bootstrap') : ['status' => null, 'installed' => null];
$loginUpdate = $authenticated ? take_update_notice() : null;
// Unbenutzte Uploads nach der Frist weg (höchstens einmal am Tag, le_media_cleanup_if_due).
if ($authenticated) {
    le_media_cleanup_if_due();
}

json_response([
    'ok' => true,
    'authenticated' => $authenticated,
    'csrfToken' => $authenticated ? csrf_token() : '',
    'role' => $currentUser['role'] ?? null,
    'username' => $currentUser['username'] ?? null,
    'userId' => $currentUser['id'] ?? null,
    'pages' => $authenticated ? list_page_info() : [],
    'importStatus' => $authenticated ? import_status() : null,
    'updateStatus' => $update['status'],
    'updateInstalled' => $update['installed'] ?? $loginUpdate,
    'activePlugins' => $authenticated ? active_plugin_admin_info() : [],
    'systemProblems' => system_problems_for_current_user(),
    'dbArchiveReminder' => db_archive_reminder_for_current_user(),
    'siteBackup' => site_backup_dashboard_for_current_user(),
    // Bild-Upload und Link-Regel im Formular der Plugin-Einträge (shared/entry-form/, richtext.js).
    'upload' => upload_config(),
    'textMarkup' => text_markup_config(),
]);
