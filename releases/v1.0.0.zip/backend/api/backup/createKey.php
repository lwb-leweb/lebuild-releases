<?php
declare(strict_types=1);

// Neuen Schlüssel für api/backup.php erzeugen; der alte gilt dann nicht mehr.
// Der Klartext steht nur in dieser Antwort.

require_once LE_BACKEND . '/backup/siteBackup.php';

try {
    $key = site_backup_create_key();
} catch (Throwable $e) {
    error_log('createSiteBackupKey: ' . $e->getMessage());
    json_response(['ok' => false, 'error' => API_TEXT['siteBackupKeyFailed']], 500);
}
le_activity_log('backup_key_created');

json_response(['ok' => true, 'key' => $key] + site_backup_admin_status());
