<?php
declare(strict_types=1);

// Stand für Einstellungen → Backup (Sicherung der Installation, nicht die
// Seiten-Revisionen aus listBackups.php).

require_once LE_BACKEND . '/backup/siteBackup.php';

json_response(['ok' => true] + site_backup_admin_status());
