<?php
declare(strict_types=1);

require_once LE_BACKEND . '/plugins/plugins.php';

json_response(['ok' => true] + le_plugins_list());
