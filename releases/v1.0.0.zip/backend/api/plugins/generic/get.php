<?php
declare(strict_types=1);

require_once LE_BACKEND . '/plugins/plugins.php';
require_once LE_BACKEND . '/plugins/pluginSchema.php';
require_once LE_BACKEND . '/plugins/entries.php';

$name = (string) ($_GET['plugin'] ?? '');
$id = (int) ($_GET['id'] ?? 0);
if (!plugin_name_valid($name) || $id <= 0) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidRequest']], 400);
}
['manifest' => $manifest, 'table' => $table] = le_plugin_generic_table($name, 'get');

try {
    $row = plugin_fetch_row($table, $id);
} catch (Throwable $e) {
    plugin_failure_response('load', $e);
}

if (!$row) {
    json_response(['ok' => false, 'error' => API_TEXT['notFound']], 404);
}

$fields = plugin_schema_columns($manifest);
json_response([
    'ok' => true,
    'row' => plugin_schema_decode_row($fields, $row),
    // Stand beim Laden: save.php meldet 409, wenn der Eintrag inzwischen geändert wurde.
    'version' => plugin_entry_version($row),
    'schema' => $fields,
]);
