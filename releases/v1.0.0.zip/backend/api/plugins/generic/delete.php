<?php
declare(strict_types=1);

require_once LE_BACKEND . '/plugins/plugins.php';
require_once LE_BACKEND . '/plugins/entries.php';
require_once LE_BACKEND . '/site/indexNow.php';
require_once LE_BACKEND . '/base/activity.php';

le_indexnow_watch();

$body = read_json_body();
$name = (string) ($body['plugin'] ?? '');
$id = (int) ($body['id'] ?? 0);
if (!plugin_name_valid($name) || $id <= 0) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidRequest']], 400);
}
le_plugin_generic_table($name, 'delete');

try {
    $deleted = plugin_delete_entry($name, $id);
} catch (Throwable $e) {
    plugin_failure_response('delete', $e);
}
if (!$deleted) {
    json_response(['ok' => false, 'error' => API_TEXT['notFound']], 404);
}
le_activity_log('plugin_entry_deleted', le_activity_plugin_target($name, $id));

json_response(['ok' => true]);
