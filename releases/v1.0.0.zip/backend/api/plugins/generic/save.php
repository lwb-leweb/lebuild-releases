<?php
declare(strict_types=1);

require_once LE_BACKEND . '/plugins/entries.php';
require_once LE_BACKEND . '/site/indexNow.php';
require_once LE_BACKEND . '/base/activity.php';

le_indexnow_watch();

$body = read_json_body();
$name = (string) ($body['plugin'] ?? '');
$saved = le_plugin_generic_save($name, $body);
le_activity_log($saved['created'] ? 'plugin_entry_created' : 'plugin_entry_updated', le_activity_plugin_target($name, $saved['id']));

json_response(['ok' => true, 'id' => $saved['id']]);
