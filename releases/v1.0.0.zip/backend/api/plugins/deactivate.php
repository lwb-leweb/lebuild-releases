<?php
declare(strict_types=1);

require_once LE_BACKEND . '/plugins/plugins.php';
require_once LE_BACKEND . '/site/indexNow.php';
require_once LE_BACKEND . '/base/activity.php';

le_indexnow_watch();

$body = read_json_body();
$name = (string) ($body['name'] ?? '');
$state = le_plugin_deactivate($name);
le_activity_log('plugin_deactivated', $name);

json_response(['ok' => true, 'name' => $name, 'state' => $state]);
