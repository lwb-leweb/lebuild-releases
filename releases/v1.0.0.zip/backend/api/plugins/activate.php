<?php
declare(strict_types=1);

require_once LE_BACKEND . '/plugins/plugins.php';
require_once LE_BACKEND . '/base/db.php';
require_once LE_BACKEND . '/site/indexNow.php';
require_once LE_BACKEND . '/base/activity.php';

le_indexnow_watch();
require_no_db_migration();

$body = read_json_body();
$name = (string) ($body['name'] ?? '');
$state = le_plugin_activate($name);
le_activity_log('plugin_activated', $name);

json_response(['ok' => true, 'name' => $name, 'state' => $state]);
