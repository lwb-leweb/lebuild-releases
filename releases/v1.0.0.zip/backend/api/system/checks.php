<?php
declare(strict_types=1);

require_once LE_BACKEND . '/system/checks.php';

json_response([
    'ok' => true,
    'checks' => system_checks(),
]);
