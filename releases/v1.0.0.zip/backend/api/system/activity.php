<?php
declare(strict_types=1);

require_once LE_BACKEND . '/base/activity.php';

// Aktivitäts-Log für Verwaltung → Aktivität (nur Admins): neueste zuerst, ?user= filtert, ?offset=&limit= blättert,
// ?until=&untilCount= (Stand aus der ersten Seite) hält neuere Einträge draußen.
try {
    $page = le_activity_page(
        is_string($_GET['user'] ?? null) ? $_GET['user'] : '',
        (int) ($_GET['offset'] ?? 0),
        (int) ($_GET['limit'] ?? LE_ACTIVITY_PAGE_SIZE),
        null,
        is_string($_GET['until'] ?? null) ? $_GET['until'] : '',
        (int) ($_GET['untilCount'] ?? 0)
    );
} catch (Throwable $e) {
    error_log('activity: ' . $e->getMessage());
    json_response(['ok' => false, 'error' => LE_ACTIVITY_READ_FAILED_TEXT], 500);
}

json_response(['ok' => true] + $page);
