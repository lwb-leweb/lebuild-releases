<?php
declare(strict_types=1);

// Öffentlicher Health-Check für Uptime-Monitore: ohne Session und CSRF, 503 bei einem Fehler,
// die Einzelprüfungen nur mit Bearer-Token (backend/system/health.php).

require_once LE_BACKEND . '/system/health.php';

le_health_respond();
