<?php
declare(strict_types=1);

require_once LE_BACKEND . '/users/users.php';

$store = users_load();
$users = array_map('users_public_view', $store['users']);

json_response(['ok' => true, 'users' => $users]);
