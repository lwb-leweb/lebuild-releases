<?php
declare(strict_types=1);

require_once LE_BACKEND . '/users/users.php';
require_once LE_BACKEND . '/base/activity.php';

$body = read_json_body();
$updated = le_users_edit(trim((string) ($body['id'] ?? '')), $body);
le_activity_log('user_updated', $updated['username']);

json_response(['ok' => true, 'user' => users_public_view($updated)]);
