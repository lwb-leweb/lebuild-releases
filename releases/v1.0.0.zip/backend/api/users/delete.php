<?php
declare(strict_types=1);

require_once LE_BACKEND . '/users/auth.php';
require_once LE_BACKEND . '/users/users.php';
require_once LE_BACKEND . '/base/activity.php';

$body = read_json_body();
$deleted = le_users_delete(trim((string) ($body['id'] ?? '')), (string) (current_user()['id'] ?? ''));
le_activity_log('user_deleted', $deleted);

json_response(['ok' => true]);
