<?php
declare(strict_types=1);

require_once LE_BACKEND . '/users/auth.php';
require_once LE_BACKEND . '/users/users.php';
require_once LE_BACKEND . '/base/activity.php';

$body = read_json_body();
$self = current_user();
if ($self === null) {
    json_response(['ok' => false, 'error' => API_TEXT['notAuthenticated']], 401);
}
$result = le_users_change_password($self, trim((string) ($body['id'] ?? '')), (string) ($body['currentPassword'] ?? ''), (string) ($body['newPassword'] ?? ''));
le_activity_log('user_password_changed', $result['user']['username'], $self['username']);

// Die eigene Session läuft weiter, mit neuer ID und neuem Token (das Backend übernimmt es).
if ($result['self']) {
    auth_renew_session($result['user']);
    json_response(['ok' => true, 'csrfToken' => csrf_token()]);
}
json_response(['ok' => true]);
