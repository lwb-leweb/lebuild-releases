<?php
declare(strict_types=1);

require_once LE_BACKEND . '/users/auth.php';

// CSRF-Token der aktuellen Anmeldung (nur lesen, wie getPage ohne CSRF): Der Seiten-Editor holt es
// nach einer neuen Anmeldung in einem anderen Tab (shared/request.js), ohne die Seite neu abzurufen.
json_response(['ok' => true, 'csrfToken' => csrf_token()]);
