<?php
declare(strict_types=1);

require_once LE_BACKEND . '/users/auth.php';
require_once LE_BACKEND . '/base/activity.php';

// Nur per POST (api/routes.php) mit CSRF-Token, damit ein Link auf einer fremden Seite niemanden abmeldet. Ohne
// Anmeldung (abgelaufen) gibt es nichts zu schützen: dann nur die Session aufräumen.
resume_app_session(false);
if (session_user() !== null) {
    require_csrf();
    le_activity_log('logout');
}
logout_user();

json_response(['ok' => true]);

