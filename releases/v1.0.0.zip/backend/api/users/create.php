<?php
declare(strict_types=1);

require_once LE_BACKEND . '/users/users.php';
require_once LE_BACKEND . '/base/activity.php';

$body = read_json_body();
$user = le_users_create(trim((string) ($body['username'] ?? '')), (string) ($body['password'] ?? ''), (string) ($body['role'] ?? ''));
le_activity_log('user_created', $user['username']);

json_response(['ok' => true, 'user' => users_public_view($user)]);
