<?php
declare(strict_types=1);

require_once LE_BACKEND . '/users/auth.php';
require_once LE_BACKEND . '/media/openUploads.php';
require_once LE_BACKEND . '/base/activity.php';

$file = le_upload_accept($_FILES['file'] ?? null, $_POST['form'] ?? '', (int) ($_SERVER['CONTENT_LENGTH'] ?? 0), (string) current_user()['id'], $_POST['kind'] ?? '');
le_activity_log('upload', $file);

json_response(['ok' => true, 'url' => UPLOADS_URL . $file]);
