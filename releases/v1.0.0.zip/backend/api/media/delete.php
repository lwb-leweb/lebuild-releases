<?php
declare(strict_types=1);

require_once LE_BACKEND . '/media/library.php';

// Mediathek (nur Admins): unbenutzte Bilder löschen, {urls: [...]}; Verwendetes bleibt mit Grund (le_media_delete).

$body = read_json_body();
$result = le_media_delete(is_array($body['urls'] ?? null) ? $body['urls'] : []);
if ($result['deleted'] !== []) {
    le_activity_log('media_deleted', implode(', ', array_map('basename', $result['deleted'])));
}

json_response(['ok' => true] + $result + ['items' => le_media_list()]);
