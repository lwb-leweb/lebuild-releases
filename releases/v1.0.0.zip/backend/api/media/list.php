<?php
declare(strict_types=1);

require_once LE_BACKEND . '/media/library.php';
require_once LE_BACKEND . '/pages/history.php';

// Mediathek (nur Admins): alle Bilder der Website mit Status (le_media_list) und der Frist fürs Aufräumen.

json_response(['ok' => true, 'items' => le_media_list(), 'unusedDays' => LE_MEDIA_UNUSED_DAYS, 'backupRetention' => BACKUP_RETENTION]);
