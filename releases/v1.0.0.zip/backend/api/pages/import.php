<?php
declare(strict_types=1);

require_once LE_BACKEND . '/pages/import.php';
require_once LE_BACKEND . '/site/indexNow.php';

le_indexnow_watch();

$body = read_json_body();
$force = !empty($body['force']);
$status = run_import($force);
if (empty($status['skipped'])) {
    le_activity_log($force ? 'markers_refreshed' : 'import');
}

json_response([
    'ok' => true,
    'status' => $status,
    'pages' => list_page_info(),
]);
