<?php
declare(strict_types=1);

require_once LE_BACKEND . '/pages/store.php';
require_once LE_BACKEND . '/pages/save.php';
require_once LE_BACKEND . '/site/indexNow.php';

le_indexnow_watch();

$body = read_json_body();
$page = safe_page_name((string) ($body['page'] ?? ''));
$content = $body['content'] ?? null;
// Stand beim Laden (getPage) für die Prüfung je Feld (merge_save_content); ohne ihn gilt der geschickte Inhalt ganz.
$base = $body['base'] ?? null;
// Konflikt-Felder, die der Benutzer trotzdem mit seiner Fassung überschreibt („Meine Fassung speichern“).
$overwrite = $body['overwrite'] ?? [];
if (!is_array($content) || ($base !== null && !is_array($base)) || !is_array($overwrite) || array_values($overwrite) !== $overwrite) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidContent']], 400);
}

json_response(['ok' => true] + le_page_save($page, $content, $base, $overwrite));
