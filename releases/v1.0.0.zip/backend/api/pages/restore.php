<?php
declare(strict_types=1);

require_once LE_BACKEND . '/pages/store.php';
require_once LE_BACKEND . '/pages/save.php';
require_once LE_BACKEND . '/site/indexNow.php';

le_indexnow_watch();

$body = read_json_body();
$page = safe_page_name((string) ($body['page'] ?? ''));
$backup = basename(sanitize_text_value($body['backup'] ?? ''));

json_response(['ok' => true] + le_page_restore($page, $backup));
