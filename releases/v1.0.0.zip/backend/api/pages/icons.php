<?php
declare(strict_types=1);

require_once LE_BACKEND . '/html/icons.php';
require_once LE_BACKEND . '/base/http.php';

// Icons für die Auswahl der Feldart „Icon“ im Seiten-Editor (nur lesen, nur angemeldet), dazu die
// Attribute, die ein Tausch am <svg> setzt (le_icon_replacements), damit die Vorschau gleich aussieht.
json_response(['ok' => true, 'icons' => le_icon_list(), 'attrs' => LE_ICON_SVG_ATTRS, 'defaults' => LE_ICON_SVG_DEFAULTS]);
