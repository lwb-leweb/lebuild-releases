<?php
declare(strict_types=1);

require_once LE_BACKEND . '/base/mail.php';

json_response([
    'ok' => true,
    'config' => core_mail_public_config(),
    'status' => core_mail_status(),
]);
