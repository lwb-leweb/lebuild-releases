<?php
declare(strict_types=1);

require_once LE_BACKEND . '/base/mail.php';
require_once LE_BACKEND . '/base/activity.php';

$body = read_json_body();

try {
    core_mail_save_config($body);
} catch (InvalidArgumentException $e) {
    // Prüfung der Eingaben: Texte aus MAIL_CONFIG_TEXT (core_mail_validate_config).
    json_response(['ok' => false, 'error' => $e->getMessage()], 400);
} catch (Throwable $e) {
    error_log('saveMailConfig: ' . $e->getMessage());
    json_response(['ok' => false, 'error' => API_TEXT['mailSaveFailed']], 500);
}
le_activity_log('mail_settings_saved');

json_response([
    'ok' => true,
    'config' => core_mail_public_config(),
    'status' => core_mail_status(),
]);
