<?php
declare(strict_types=1);

require_once LE_BACKEND . '/base/mail.php';

$body = read_json_body();
$to = trim((string) ($body['to'] ?? ''));
if ($to === '') {
    $to = core_mail_default_recipient();
}
if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
    json_response(['ok' => false, 'error' => API_TEXT['testRecipient']], 400);
}

try {
    $result = core_mail_send([
        'to' => $to,
        'subject' => 'LeBuild SMTP-Test',
        'text' => "Diese Testmail wurde von LeBuild versendet.\n\nWenn sie angekommen ist, funktioniert der Mailversand.",
    ]);
} catch (Throwable $e) {
    error_log('testMailConfig: ' . $e->getMessage());
    json_response(['ok' => false, 'error' => API_TEXT['testMailFailed']], 500);
}

json_response([
    'ok' => true,
    'transport' => $result['transport'] ?? 'unknown',
]);
