<?php
declare(strict_types=1);

require_once LE_BACKEND . '/base/mail.php';
require_once LE_BACKEND . '/base/activity.php';

try {
    core_mail_delete_config();
} catch (Throwable $e) {
    error_log('deleteMailConfig: ' . $e->getMessage());
    json_response(['ok' => false, 'error' => API_TEXT['mailDeleteFailed']], 500);
}
le_activity_log('mail_settings_deleted');

json_response([
    'ok' => true,
    'config' => core_mail_public_config(),
    'status' => core_mail_status(),
]);
