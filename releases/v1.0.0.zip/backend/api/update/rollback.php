<?php
declare(strict_types=1);

require_once LE_BACKEND . '/update/updater.php';

$result = updater_rollback();
if (empty($result['ok'])) {
    json_response(['ok' => false, 'error' => $result['error'] ?? API_TEXT['rollbackFailed'], 'status' => updater_status()], 500);
}
le_activity_log('update_rolled_back', (string) ($result['currentVersion'] ?? ''));

json_response([
    'ok' => true,
    'currentVersion' => $result['currentVersion'] ?? null,
    'status' => updater_status(),
]);
