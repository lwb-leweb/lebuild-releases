<?php
declare(strict_types=1);

require_once LE_BACKEND . '/update/updater.php';

$result = updater_install(true);
if (empty($result['ok'])) {
    json_response(['ok' => false, 'error' => $result['error'] ?? API_TEXT['updateFailed'], 'status' => updater_status()], 500);
}
le_activity_log('update_installed', ($result['previousVersion'] ?? '?') . ' → ' . ($result['newVersion'] ?? '?'));

json_response([
    'ok' => true,
    'previousVersion' => $result['previousVersion'] ?? null,
    'newVersion' => $result['newVersion'] ?? null,
    'swappedPaths' => $result['swappedPaths'] ?? [],
    'status' => updater_status(),
]);
