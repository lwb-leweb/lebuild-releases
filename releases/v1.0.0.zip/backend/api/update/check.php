<?php
declare(strict_types=1);

require_once LE_BACKEND . '/update/updater.php';

$status = updater_check(true);

json_response(['ok' => true, 'status' => $status]);
