<?php
declare(strict_types=1);

// Routentabelle der Endpunkte: Adresse unter LE_API_URL ohne .php => Datei unter LE_API, erlaubte Methoden, Rolle
// (LE_ROLES) und ob ein CSRF-Token nötig ist (für alle Methoden außer LE_SAFE_METHODS). Der Router prüft in
// dieser Reihenfolge: Eintrag (sonst 404), Methode (405), Rolle (401/403), CSRF (403); erst dann bindet er die Datei ein.
// Was hier fehlt, ist nicht erreichbar. Ausnahmen von „angemeldet und CSRF“ wie in AGENTS.md: login, logout (CSRF nur
// mit Anmeldung, prüft der Endpunkt), backup (Bearer-Schlüssel), health (Einzelprüfungen mit Bearer-Token), bootstrap.
return [
    'activity' => ['file' => 'system/activity.php', 'methods' => ['GET'], 'role' => LE_ROLE_ADMIN, 'csrf' => false],
    'backup' => ['file' => 'backup/pull.php', 'methods' => ['GET'], 'role' => LE_ROLE_PUBLIC, 'csrf' => false],
    'bootstrap' => ['file' => 'bootstrap.php', 'methods' => ['GET'], 'role' => LE_ROLE_PUBLIC, 'csrf' => false],
    'checkUpdate' => ['file' => 'update/check.php', 'methods' => ['POST'], 'role' => LE_ROLE_ADMIN, 'csrf' => true],
    'createSiteBackupKey' => ['file' => 'backup/createKey.php', 'methods' => ['POST'], 'role' => LE_ROLE_ADMIN, 'csrf' => true],
    'csrfToken' => ['file' => 'users/csrfToken.php', 'methods' => ['GET'], 'role' => LE_ROLE_SIGNED_IN, 'csrf' => false],
    'deleteDbArchive' => ['file' => 'database/deleteArchive.php', 'methods' => ['POST'], 'role' => LE_ROLE_ADMIN, 'csrf' => true],
    'deleteMailConfig' => ['file' => 'mail/delete.php', 'methods' => ['POST'], 'role' => LE_ROLE_ADMIN, 'csrf' => true],
    'deleteMedia' => ['file' => 'media/delete.php', 'methods' => ['POST'], 'role' => LE_ROLE_ADMIN, 'csrf' => true],
    'discardUploads' => ['file' => 'media/discardUploads.php', 'methods' => ['POST'], 'role' => LE_ROLE_SIGNED_IN, 'csrf' => true],
    'downloadSiteBackup' => ['file' => 'backup/download.php', 'methods' => ['POST'], 'role' => LE_ROLE_ADMIN, 'csrf' => true],
    'getConfig' => ['file' => 'settings/get.php', 'methods' => ['GET'], 'role' => LE_ROLE_SIGNED_IN, 'csrf' => false],
    'getDbStatus' => ['file' => 'database/status.php', 'methods' => ['GET'], 'role' => LE_ROLE_ADMIN, 'csrf' => false],
    'getMailConfig' => ['file' => 'mail/get.php', 'methods' => ['GET'], 'role' => LE_ROLE_ADMIN, 'csrf' => false],
    'getPage' => ['file' => 'pages/get.php', 'methods' => ['GET'], 'role' => LE_ROLE_SIGNED_IN, 'csrf' => false],
    'getSiteBackupStatus' => ['file' => 'backup/status.php', 'methods' => ['GET'], 'role' => LE_ROLE_ADMIN, 'csrf' => false],
    'getSystemChecks' => ['file' => 'system/checks.php', 'methods' => ['GET'], 'role' => LE_ROLE_ADMIN, 'csrf' => false],
    // HEAD: Monitore fragen auch so.
    'health' => ['file' => 'system/health.php', 'methods' => ['GET', 'HEAD'], 'role' => LE_ROLE_PUBLIC, 'csrf' => false],
    'icons' => ['file' => 'pages/icons.php', 'methods' => ['GET'], 'role' => LE_ROLE_SIGNED_IN, 'csrf' => false],
    'import' => ['file' => 'pages/import.php', 'methods' => ['POST'], 'role' => LE_ROLE_ADMIN, 'csrf' => true],
    'installUpdate' => ['file' => 'update/install.php', 'methods' => ['POST'], 'role' => LE_ROLE_ADMIN, 'csrf' => true],
    'listBackups' => ['file' => 'pages/history.php', 'methods' => ['GET'], 'role' => LE_ROLE_SIGNED_IN, 'csrf' => false],
    'login' => ['file' => 'users/login.php', 'methods' => ['POST'], 'role' => LE_ROLE_PUBLIC, 'csrf' => false],
    'logout' => ['file' => 'users/logout.php', 'methods' => ['POST'], 'role' => LE_ROLE_PUBLIC, 'csrf' => false],
    'media' => ['file' => 'media/list.php', 'methods' => ['GET'], 'role' => LE_ROLE_ADMIN, 'csrf' => false],
    'migrateDb' => ['file' => 'database/migrate.php', 'methods' => ['POST'], 'role' => LE_ROLE_ADMIN, 'csrf' => true],
    'plugins/activate' => ['file' => 'plugins/activate.php', 'methods' => ['POST'], 'role' => LE_ROLE_ADMIN, 'csrf' => true],
    'plugins/dbConfig' => ['file' => 'database/config.php', 'methods' => ['GET', 'POST'], 'role' => LE_ROLE_ADMIN, 'csrf' => true],
    'plugins/deactivate' => ['file' => 'plugins/deactivate.php', 'methods' => ['POST'], 'role' => LE_ROLE_ADMIN, 'csrf' => true],
    'plugins/generic/delete' => ['file' => 'plugins/generic/delete.php', 'methods' => ['POST'], 'role' => LE_ROLE_SIGNED_IN, 'csrf' => true],
    'plugins/generic/get' => ['file' => 'plugins/generic/get.php', 'methods' => ['GET'], 'role' => LE_ROLE_SIGNED_IN, 'csrf' => false],
    'plugins/generic/list' => ['file' => 'plugins/generic/list.php', 'methods' => ['GET'], 'role' => LE_ROLE_SIGNED_IN, 'csrf' => false],
    'plugins/generic/save' => ['file' => 'plugins/generic/save.php', 'methods' => ['POST'], 'role' => LE_ROLE_SIGNED_IN, 'csrf' => true],
    'plugins/list' => ['file' => 'plugins/list.php', 'methods' => ['GET'], 'role' => LE_ROLE_SIGNED_IN, 'csrf' => false],
    'plugins/testDb' => ['file' => 'database/test.php', 'methods' => ['POST'], 'role' => LE_ROLE_ADMIN, 'csrf' => true],
    'plugins/uninstall' => ['file' => 'plugins/uninstall.php', 'methods' => ['POST'], 'role' => LE_ROLE_ADMIN, 'csrf' => true],
    'restore' => ['file' => 'pages/restore.php', 'methods' => ['POST'], 'role' => LE_ROLE_SIGNED_IN, 'csrf' => true],
    'rollbackUpdate' => ['file' => 'update/rollback.php', 'methods' => ['POST'], 'role' => LE_ROLE_ADMIN, 'csrf' => true],
    'saveConfig' => ['file' => 'settings/save.php', 'methods' => ['POST'], 'role' => LE_ROLE_ADMIN, 'csrf' => true],
    'saveMailConfig' => ['file' => 'mail/save.php', 'methods' => ['POST'], 'role' => LE_ROLE_ADMIN, 'csrf' => true],
    'savePage' => ['file' => 'pages/save.php', 'methods' => ['POST'], 'role' => LE_ROLE_SIGNED_IN, 'csrf' => true],
    'testMailConfig' => ['file' => 'mail/test.php', 'methods' => ['POST'], 'role' => LE_ROLE_ADMIN, 'csrf' => true],
    'upload' => ['file' => 'media/upload.php', 'methods' => ['POST'], 'role' => LE_ROLE_SIGNED_IN, 'csrf' => true],
    'users/changePassword' => ['file' => 'users/changePassword.php', 'methods' => ['POST'], 'role' => LE_ROLE_PASSWORD_CHANGE, 'csrf' => true],
    'users/create' => ['file' => 'users/create.php', 'methods' => ['POST'], 'role' => LE_ROLE_ADMIN, 'csrf' => true],
    'users/delete' => ['file' => 'users/delete.php', 'methods' => ['POST'], 'role' => LE_ROLE_ADMIN, 'csrf' => true],
    'users/list' => ['file' => 'users/list.php', 'methods' => ['GET'], 'role' => LE_ROLE_ADMIN, 'csrf' => false],
    'users/update' => ['file' => 'users/update.php', 'methods' => ['POST'], 'role' => LE_ROLE_ADMIN, 'csrf' => true],
];
