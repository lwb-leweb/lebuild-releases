<?php
declare(strict_types=1);

require_once LE_BACKEND . '/base/db.php';
require_once LE_BACKEND . '/database/migration.php';
require_once LE_BACKEND . '/site/indexNow.php';
require_once LE_BACKEND . '/base/activity.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    json_response([
        'ok' => true,
        'configured' => db_config_exists(),
    ]);
}

le_indexnow_watch();
require_no_db_migration();

$config = db_config_from_body(read_json_body());

// Früh ablehnen, bevor der Verbindungstest dauert; unter dem Lock wird erneut geprüft.
if ($error = db_config_change_error()) {
    json_response($error, DB_MIGRATION_ERROR_STATUS[$error['error']]);
}

$test = db_test_connection($config);
if (!$test['ok']) {
    json_response(['ok' => false, 'error' => sprintf(API_TEXT['connectionFailed'], $test['error'])], 400);
}

$result = db_save_config_locked($config);
if (!$result['ok']) {
    json_response($result, DB_MIGRATION_ERROR_STATUS[$result['error']] ?? 500);
}
le_activity_log('db_settings_saved');

json_response(['ok' => true, 'configured' => true]);
