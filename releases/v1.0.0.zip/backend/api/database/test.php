<?php
declare(strict_types=1);

require_once LE_BACKEND . '/base/db.php';

$config = db_config_from_body(read_json_body());
$result = db_test_connection($config);
json_response($result, $result['ok'] ? 200 : 400);
