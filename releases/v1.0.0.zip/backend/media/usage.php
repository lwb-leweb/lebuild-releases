<?php
declare(strict_types=1);

// Hochgeladene Dateien wieder entfernen, sobald nichts mehr auf sie verweist
// (z. B. beim Löschen eines Plugin-Eintrags). Verweise zählen als Treffer des
// Dateinamens (zufälliger Suffix aus le_upload_accept). Im Zweifel bleibt die
// Datei liegen: ein falscher Treffer, eine unlesbare Datei oder ein Fehler bei
// der Suche zählen als „verwendet“. Uploads aus Formularen, die noch nicht
// gespeichert oder verworfen sind, führt die Liste offener Uploads (le_open_*).

require_once LE_BACKEND . '/media/uploads.php';
require_once LE_BACKEND . '/plugins/plugins.php';
require_once LE_BACKEND . '/plugins/entries.php';

// Hier können Seiten auf Uploads verweisen: Seiten-JSON, Seiten-Backups, Snapshots der Quelldateien, Site-Dateien.
const UPLOAD_REFERENCE_ROOTS = [PAGES_ROOT, BACKUPS_ROOT, ORIGINALS_ROOT, LE_SITE_ROOT];
// Einzelne Dateien, die ebenfalls auf Uploads verweisen können: die Einstellungen der Website (Vorschaubild, og:image).
const UPLOAD_REFERENCE_FILES = [LE_SITE_CONFIG_FILE];
// Binärdateien mit diesen Endungen werden nicht durchsucht; alle anderen Dateien gelten als Text.
const UPLOAD_REFERENCE_SKIP_EXTENSIONS = [
    'jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'ico', 'bmp', 'tif', 'tiff',
    'mp4', 'mov', 'webm', 'm4v', 'avi', 'mkv', 'mp3', 'wav', 'ogg', 'm4a',
    'woff', 'woff2', 'ttf', 'otf', 'eot', 'pdf', 'zip', 'gz', 'tar', '7z', 'rar',
];
// Größere Dateien werden nicht eingelesen, sondern zählen als Verwendung (im Zweifel behalten).
const UPLOAD_REFERENCE_MAX_BYTES = 5 * 1024 * 1024;

/**
 * Ob eine Seite, ein Backup, eine Site-Datei, die Einstellungen oder ein Plugin die Upload-Datei $file noch verwendet
 * (uploads_in_use für eine Datei).
 */
function upload_in_use(string $file): bool
{
    return uploads_in_use([$file]) !== [];
}

/**
 * Welche der Upload-Dateien $files eine Seite, ein Backup, eine Site-Datei, die Einstellungen oder ein Plugin noch
 * verwendet: alle Textdateien einmal lesen (le_media_text_files), nicht je Datei; Schluss, sobald alle gefunden sind.
 * Im Zweifel verwendet: bei Fehlern (dann alle), unlesbaren oder zu großen Textdateien und Ordner-Links (werden nicht
 * verfolgt, gelten für jede Datei). Liefert die verwendeten Namen.
 */
function uploads_in_use(array $files): array
{
    $left = [];
    foreach ($files as $file) {
        $left[(string) $file] = true;
    }
    $used = [];
    $mark = static function (?string $content) use (&$left, &$used): void {
        foreach (array_keys($left) as $file) {
            if ($content === null || str_contains($content, (string) $file)) {
                $used[] = (string) $file;
                unset($left[$file]);
            }
        }
    };
    try {
        foreach (UPLOAD_REFERENCE_ROOTS as $root) {
            foreach (le_media_text_files($root) as $content) {
                if ($left === []) {
                    return $used;
                }
                $mark($content);
            }
        }
        foreach (UPLOAD_REFERENCE_FILES as $path) {
            if (is_file($path)) {
                $content = @file_get_contents($path);
                $mark($content === false ? null : $content);
            }
        }
        foreach (array_keys($left) as $file) {
            if (plugins_upload_in_use((string) $file)) {
                $used[] = (string) $file;
            }
        }
    } catch (Throwable $e) {
        error_log('uploads_in_use failed: ' . $e->getMessage());
        return array_keys(array_fill_keys(array_map('strval', $files), true));
    }

    return $used;
}

/**
 * Inhalte der Textdateien unter $root, in denen ein Upload stehen kann (ohne Binärdateien nach
 * UPLOAD_REFERENCE_SKIP_EXTENSIONS, ohne die Uploads selbst: auch ein SVG verweist auf nichts); null für eine Datei,
 * die nicht gelesen werden kann oder größer als UPLOAD_REFERENCE_MAX_BYTES ist, und für einen Ordner-Link (zählen als
 * Treffer für jedes Bild). Für uploads_in_use und die Mediathek (le_media_status).
 */
function le_media_text_files(string $root): Generator
{
    if (!is_dir($root)) {
        return;
    }
    $entries = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
    foreach ($entries as $entry) {
        if ($entry->isLink() && $entry->isDir()) {
            yield null;
            continue;
        }
        if (!$entry->isFile() || str_starts_with($entry->getPathname(), UPLOADS_ROOT . '/')
            || in_array(strtolower($entry->getExtension()), UPLOAD_REFERENCE_SKIP_EXTENSIONS, true)) {
            continue;
        }
        if ($entry->getSize() > UPLOAD_REFERENCE_MAX_BYTES) {
            yield null;
            continue;
        }
        $content = @file_get_contents($entry->getPathname());
        yield $content === false ? null : $content;
    }
}

/**
 * Plugin-Daten: Spalten aus schema.fields der Haupttabelle (jedes Plugin mit Schema) und der Hook
 * „<plugin>_upload_in_use(string $file): bool“ für alles andere (z. B. JSON-Spalten der Content-Typen).
 * Gilt für installierte Plugins, aktiv oder nicht (die Daten bleiben). Wirft bei Fehlern.
 */
function plugins_upload_in_use(string $file): bool
{
    $state = load_plugins_state();
    foreach (array_unique(array_merge($state['active'], array_keys($state['installed']))) as $name) {
        if (plugin_schema_upload_in_use(plugin_manifest($name), $file)) {
            return true;
        }
        $fn = plugin_hook_function($name, 'upload_in_use');
        if ($fn !== null && $fn($file) !== false) {
            return true;
        }
    }

    return false;
}

/**
 * Löscht die Upload-Dateien zu den Bildwerten $urls, die nirgends mehr verwendet werden (uploads_in_use, einmal für
 * alle). Aufruf erst, nachdem der Eintrag selbst gelöscht ist; wirft nie (der Eintrag ist dann schon weg), Fehler lassen
 * die Datei liegen. Liefert die gelöschten Dateinamen.
 */
function delete_unused_uploads(array $urls): array
{
    $candidates = [];
    try {
        $uploadsDir = realpath(UPLOADS_ROOT);
        foreach (array_unique(array_filter($urls, 'is_string')) as $url) {
            $file = upload_file_name($url);
            if ($file === null || $uploadsDir === false) {
                continue;
            }
            $path = UPLOADS_ROOT . '/' . $file;
            $real = realpath($path);
            // Nur echte Dateien direkt in UPLOADS_ROOT, keine Links nach draußen.
            if ($real !== false && !is_link($path) && is_file($real) && dirname($real) === $uploadsDir) {
                $candidates[$file] = $real;
            }
        }
        $used = array_flip(uploads_in_use(array_keys($candidates)));
    } catch (Throwable $e) {
        error_log('delete_unused_uploads failed: ' . $e->getMessage());
        return [];
    }
    $deleted = [];
    foreach ($candidates as $file => $real) {
        if (!isset($used[(string) $file]) && @unlink($real)) {
            $deleted[] = (string) $file;
        }
    }

    return $deleted;
}
