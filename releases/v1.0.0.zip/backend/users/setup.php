<?php
declare(strict_types=1);

// Erst-Einrichtung: Zugang des ersten Admins aus setup.php, solange es keine Benutzer gibt.

require_once LE_BACKEND . '/base/files.php';
require_once LE_BACKEND . '/base/utils.php';
require_once LE_BACKEND . '/users/users.php';

// Zugang des ersten Admins wie die wp-config.php von WordPress: Vorlage setup.sample.php, ausgefüllt als
// setup.php im Ordner der Website. Gilt nur, solange es private/users.json nicht gibt (login_user).
const LE_SETUP_CONFIG_FILE = LE_INSTANCE_ROOT . '/setup.php';
// Formulare in frontend/app/login.html; ohne Benutzer und setup.php steht dort der Hinweis (Router).
const LE_LOGIN_FORMS_START = '<!-- le:login-forms -->';
const LE_LOGIN_FORMS_END = '<!-- /le:login-forms -->';

/**
 * Inhalt von setup.php und setup.sample.php (gleiches Format): Nach dem Anlegen des Admins schreibt
 * le_setup_clear_password() die Datei neu, statt sie zu bearbeiten; Werte nur über var_export.
 */
function le_setup_config_source(string $username, string $password): string
{
    return "<?php\n"
        . "// Zugang des ersten Admins. Vor dem Hochladen nach setup.php kopieren und ausfüllen.\n"
        . "// Beim ersten Login legt der Editor daraus den Admin an und leert das Passwort hier.\n"
        . "// Sobald es Benutzer gibt (private/users.json), gilt diese Datei nicht mehr.\n"
        . "return [\n"
        . sprintf("    // %d bis %d Zeichen: Buchstaben, Ziffern, Punkt, Unterstrich, Bindestrich.\n", USERNAME_MIN_LENGTH, USERNAME_MAX_LENGTH)
        . "    'username' => " . var_export($username, true) . ",\n"
        . sprintf("    // %d bis %d Byte (Umlaute und Sonderzeichen zählen doppelt oder mehr).\n", PASSWORD_MIN_LENGTH, PASSWORD_MAX_LENGTH)
        . "    'password' => " . var_export($password, true) . ",\n"
        . "];\n";
}

/** Array aus setup.php ($file: Datei im selben Format, z. B. eine alte config.php); null ohne Datei, bei Fehlern (ins Fehlerprotokoll) und ohne Array. */
function le_setup_config_read(string $file = LE_SETUP_CONFIG_FILE): ?array
{
    if (!is_file($file)) {
        return null;
    }
    // Per FTP hochgeladen oder geändert: nie eine alte, übersetzte Fassung aus OPcache.
    forget_compiled_file($file);
    try {
        $config = (static fn () => include $file)();
    } catch (Throwable $e) {
        users_log_once(basename($file) . ' cannot be read: ' . $e->getMessage());
        return null;
    }
    return is_array($config) ? $config : null;
}

/** Benutzername und Passwort aus setup.php, wenn beide gelten (users_validate_*); sonst null. */
function le_setup_credentials(): ?array
{
    $config = le_setup_config_read() ?? [];
    $username = is_string($config['username'] ?? null) ? trim($config['username']) : '';
    $password = is_string($config['password'] ?? null) ? $config['password'] : '';
    if (users_validate_username($username) !== null || users_validate_password($password) !== null) {
        return null;
    }
    return ['username' => $username, 'password' => $password];
}

/** Weder Benutzer noch ein brauchbares setup.php: Niemand kommt hinein, /login zeigt den Hinweis. */
function le_setup_missing(): bool
{
    return !is_file(users_path()) && le_setup_credentials() === null;
}

/** Benutzer gibt es, aber in setup.php steht noch ein Passwort (Systemprüfung). */
function le_setup_password_left(): bool
{
    $password = is_file(users_path()) ? (le_setup_config_read()['password'] ?? '') : '';
    return is_string($password) && $password !== '';
}

/** setup.php ohne Passwort neu schreiben (atomar); scheitert es, bleibt der Admin und es steht im Fehlerprotokoll. */
function le_setup_clear_password(string $username): void
{
    try {
        write_file_atomic(LE_SETUP_CONFIG_FILE, le_setup_config_source($username, ''));
    } catch (RuntimeException $e) {
        error_log('lebuild: first admin created, but setup.php still holds the password: ' . $e->getMessage());
    }
}

function auth_bootstrap_admin(string $username, string $password): ?array
{
    $now = current_iso_time();
    $hash = password_hash($password, PASSWORD_BCRYPT);
    if (!is_string($hash) || $hash === '') {
        return null;
    }
    $user = [
        'id' => users_generate_id(),
        'username' => $username,
        'passwordHash' => $hash,
        'role' => USER_ROLE_ADMIN,
        'createdAt' => $now,
        'updatedAt' => $now,
    ];
    // Unter der Sperre: Zwei gleichzeitige Erst-Logins legen nicht zwei Admins an.
    return users_update(static function (array &$store) use ($user): ?array {
        if (is_file(users_path())) {
            return null;
        }
        $store['users'][] = $user;
        return $user;
    });
}
