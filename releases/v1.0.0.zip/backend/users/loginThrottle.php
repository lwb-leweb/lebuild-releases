<?php
declare(strict_types=1);

// Bremse für Login, Passwortwechsel und Sicherungs-Abruf: Fehlversuche je Adresse und je Benutzer, bekannte Geräte.

require_once LE_BACKEND . '/base/files.php';
require_once LE_BACKEND . '/base/utils.php';
require_once LE_BACKEND . '/users/users.php';

const LOGIN_MAX_FAILURES = 10;
const LOGIN_FAILURE_WINDOW = 900;
// Antwort bei Sperre; gilt für den Login und den Sicherungs-Abruf (gleicher Zähler).
const LOGIN_THROTTLED_MESSAGE = 'Zu viele Fehlversuche, bitte in ' . LOGIN_FAILURE_WINDOW / 60 . ' Minuten erneut versuchen.';
const LOGIN_THROTTLED_STATUS = 429;
// Falsche aktuelle Passwörter beim Passwortwechsel je Session (Zeitstempel, Fenster und Grenze wie beim Login).
const LE_PASSWORD_FAILURES_SESSION_KEY = 'passwordFailures';
// Je Benutzername (klein geschrieben, von jeder Adresse): Nach LOGIN_MAX_FAILURES Fehlversuchen im Fenster nur noch ein
// Versuch je so viele Sekunden. Bremst verteilte Angriffe. Ein Angreifer kann diese Versuche besetzen; deshalb gilt die
// Bremse nicht für Geräte, auf denen sich der Benutzer schon angemeldet hat (Cookie LE_LOGIN_DEVICE_COOKIE_PREFIX…).
const LE_LOGIN_USER_SLOW_SECONDS = 10;
// Bekanntes Gerät: signiertes Cookie je Benutzer nach erfolgreichem Login, so lange gültig.
const LE_LOGIN_DEVICE_COOKIE_PREFIX = 'le_device_';
const LE_LOGIN_DEVICE_DAYS = 180;
const LE_LOGIN_USER_SLOWED_MESSAGE = 'Zu viele Fehlversuche für diesen Benutzer, bitte in ' . LE_LOGIN_USER_SLOW_SECONDS . ' Sekunden erneut versuchen.';
// Feste Hashes eines Wegwerf-Passworts: Unbekannte Benutzernamen prüfen dagegen, damit die Antwortzeit
// nicht verrät, welche Namen es gibt. Je Kosten einer, passend zum password_hash dieses PHP (10 bis 8.3, 12 ab 8.4).
const LE_LOGIN_DUMMY_HASHES = [
    '$2y$10$h9Mwc0hXBxu/mFks5pinvu.FiYkUoHU2u4V0ZheIu.7RCWVc5mz7K',
    '$2y$12$ackoGkS4amPtsuoQrbVm3eOXmEKh.07n1t/ghVuws7URCofAieJpa',
];

/** Schlüssel der Login-Sperre für eine Adresse: IPv6 je /64-Netz (so viel bekommt jeder Anschluss), IPv4 je Adresse. */
function le_login_ip_key(string $ip): string
{
    $bin = @inet_pton($ip);
    if ($bin === false || strlen($bin) !== 16) {
        return $ip;
    }
    if (str_starts_with($bin, str_repeat("\0", 10) . "\xff\xff")) {
        return (string) inet_ntop(substr($bin, 12));
    }
    return bin2hex(substr($bin, 0, 8)) . '::/64';
}

function login_throttle_path(): string
{
    $ip = le_login_ip_key((string) ($_SERVER['REMOTE_ADDR'] ?? ''));
    return CACHE_ROOT . '/login-throttle/' . substr(hash_hmac('sha256', $ip, app_secret()), 0, 32) . '.json';
}

/** Zähler je Benutzername (u- davor, damit er neben denen der Adressen liegt); klein wie login_user() vergleicht (strcasecmp). */
function le_login_user_throttle_path(string $username): string
{
    return CACHE_ROOT . '/login-throttle/u-' . substr(hash_hmac('sha256', 'user:' . strtolower($username), app_secret()), 0, 32) . '.json';
}

/**
 * Verbucht einen Versuch für $username wie login_attempt_begin für die Adresse. false (nichts verbucht): Es gab schon
 * LOGIN_MAX_FAILURES Versuche im Fenster und der letzte ist keine LE_LOGIN_USER_SLOW_SECONDS her.
 */
function le_login_user_attempt_begin(string $username): bool
{
    $allowed = true;
    login_change_failures(static function (array $failures) use (&$allowed): ?array {
        if (count($failures) >= LOGIN_MAX_FAILURES && time() - max($failures) < LE_LOGIN_USER_SLOW_SECONDS) {
            $allowed = false;
            return null;
        }
        $failures[] = time();
        return $failures;
    }, le_login_user_throttle_path($username));
    return $allowed;
}

function le_login_device_cookie_name(string $username): string
{
    return LE_LOGIN_DEVICE_COOKIE_PREFIX . substr(hash_hmac('sha256', 'device-name:' . strtolower($username), app_secret()), 0, 16);
}

/**
 * Wert des Geräte-Cookies: Ausstellungszeit und Signatur über Benutzer-ID, sessionVersion und Zeit. Ein neues Passwort
 * (sessionVersion) oder ein neu angelegter Benutzer gleichen Namens macht alte Cookies ungültig.
 */
function le_login_device_value(string $username, int $issued): string
{
    $user = users_find_by_username($username);
    $bind = $user === null ? 'unbekannt' : $user['id'] . ':' . users_session_version($user);
    return $issued . '.' . hash_hmac('sha256', 'device:' . $bind . ':' . $issued, app_secret());
}

/** Hat sich $username in diesem Browser schon angemeldet (gültiges, nicht abgelaufenes Geräte-Cookie)? */
function le_login_device_known(string $username): bool
{
    $value = $username === '' ? null : ($_COOKIE[le_login_device_cookie_name($username)] ?? null);
    if (!is_string($value) || !preg_match('/^(\d{1,12})\.[0-9a-f]{64}$/', $value, $m)) {
        return false;
    }
    $issued = (int) $m[1];
    return $issued > time() - LE_LOGIN_DEVICE_DAYS * 86400 && $issued <= time() && hash_equals(le_login_device_value($username, $issued), $value);
}

/** Merkt das Gerät nach einem erfolgreichen Login (HttpOnly, wie das Session-Cookie). */
function le_login_device_remember(string $username): void
{
    $now = time();
    setcookie(le_login_device_cookie_name($username), le_login_device_value($username, $now), [
        'expires' => $now + LE_LOGIN_DEVICE_DAYS * 86400,
        // Nur der Login braucht es; die Seiten der Website bekommen es nicht.
        'path' => '/api/login.php',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
}

/** Nimmt den mit le_login_user_attempt_begin verbuchten Versuch zurück (Passwort richtig). */
function le_login_user_attempt_forget(string $username): void
{
    login_change_failures(static function (array $failures): array {
        array_pop($failures);
        return $failures;
    }, le_login_user_throttle_path($username));
}

/** Versuche im Fenster aus dem Inhalt einer Zähler-Datei (JSON-Liste von Zeitstempeln). */
function login_failures_in_window(string $raw): array
{
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        return [];
    }
    $cutoff = time() - LOGIN_FAILURE_WINDOW;
    return array_values(array_filter(array_map('intval', $data), static fn (int $ts): bool => $ts > $cutoff));
}

function login_recent_failures(): array
{
    return login_failures_in_window((string) @file_get_contents(login_throttle_path()));
}

/** Nur lesen, ohne zu verbuchen (api/backup.php vor allem anderen). */
function login_throttled(): bool
{
    return count(login_recent_failures()) >= LOGIN_MAX_FAILURES;
}

/**
 * Verbucht einen Versuch dieser IP, bevor Passwort oder Sicherungs-Schlüssel geprüft werden;
 * false (nichts verbucht), wenn schon LOGIN_MAX_FAILURES Versuche im Fenster liegen. Lesen und
 * Schreiben laufen unter flock auf der Zähler-Datei: Auch gleichzeitige Versuche zählen alle.
 * Ein gelungener Versuch nimmt nur sich selbst zurück (login_attempt_forget), frühere Fehlversuche
 * bleiben: Ein eigenes Konto setzt den Zähler für fremde Passwörter nicht zurück. Lässt
 * sich die Datei nicht anlegen, bleibt der Login möglich (wie ohne Zähler).
 */
function login_attempt_begin(): bool
{
    $allowed = true;
    login_change_failures(static function (array $failures) use (&$allowed): ?array {
        if (count($failures) >= LOGIN_MAX_FAILURES) {
            $allowed = false;
            return null;
        }
        $failures[] = time();
        return $failures;
    });
    return $allowed;
}

/** Nimmt einen mit login_attempt_begin verbuchten Versuch zurück (Login oder Sicherungs-Schlüssel richtig); es zählt nur die Zahl. */
function login_attempt_forget(): void
{
    login_change_failures(static function (array $failures): array {
        array_pop($failures);
        return $failures;
    });
}

/** Zähler-Datei unter flock lesen, $change anwenden (null: nicht schreiben) und zurückschreiben. */
function login_change_failures(callable $change, ?string $path = null): void
{
    $path ??= login_throttle_path();
    try {
        ensure_dir(dirname($path));
    } catch (RuntimeException $e) {
        error_log('login throttle: ' . $e->getMessage());
        return;
    }
    $handle = @fopen($path, 'c+');
    if ($handle === false || !flock($handle, LOCK_EX)) {
        error_log('login throttle: cannot lock ' . $path);
        if ($handle !== false) {
            fclose($handle);
        }
        return;
    }
    $failures = $change(login_failures_in_window((string) stream_get_contents($handle)));
    if ($failures !== null) {
        ftruncate($handle, 0);
        rewind($handle);
        fwrite($handle, (string) json_encode($failures));
        fflush($handle);
    }
    flock($handle, LOCK_UN);
    fclose($handle);
}
