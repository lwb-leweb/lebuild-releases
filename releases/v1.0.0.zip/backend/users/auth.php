<?php
declare(strict_types=1);

require_once LE_BACKEND . '/base/utils.php';
require_once LE_BACKEND . '/users/users.php';
require_once LE_BACKEND . '/base/http.php';
require_once LE_BACKEND . '/base/texts.php';
require_once LE_BACKEND . '/users/loginThrottle.php';
require_once LE_BACKEND . '/users/setup.php';

// Eigener Name für die Session des Editors: Sie teilt sich nie die PHP-Session der Kundenseite
// (PHPSESSID oder was Site-PHP nutzt). Login, Erkennung auf der Website, Abmelden und das Verwerfen
// leerer Sessions betreffen nur diese; die Session der Website wird nie gelesen, geleert oder verworfen.
const APP_SESSION_NAME = 'le_session';
// Kennung der Antwort auf ein ungültiges CSRF-Token (require_csrf); der Seiten-Editor erkennt daran
// eine inzwischen erneuerte Anmeldung (CSRF_ERROR_CODE in frontend/shared/request.js).
const CSRF_ERROR_CODE = 'csrf';
// Eigener Ordner für die Session-Dateien des Editors: Den gemeinsamen Ordner des Servers räumen andere
// (Ubuntu per Cron nach 24 Minuten, andere Programme mit eigener Laufzeit) unvorhersehbar auf.
// Ohne Anfrage an den Server (Tippen zählt nicht) endet die Anmeldung nach LE_SESSION_IDLE Sekunden.
const LE_SESSION_DIR = CACHE_ROOT . '/sessions';
const LE_SESSION_IDLE = 8 * 3600;
// Form einer Session-ID, wie PHP sie vergibt und annimmt (Zeichen aus session.sid_bits_per_character, höchstens 256). Ein
// Cookie in anderer Form ist nie eine Anmeldung; resume_app_session startet damit nichts (sonst je Anfrage Warnungen im Log).
const LE_SESSION_ID_PATTERN = '/^[A-Za-z0-9,-]{1,256}$/D';
// Fehlerprotokoll, wenn LE_SESSION_DIR im Mehrfachbetrieb nicht nutzbar ist (le_app_session_open).
const LE_SESSION_DIR_TEXT = 'Eigener Session-Ordner ' . LE_SESSION_DIR . ' ist nicht beschreibbar oder der Session-Handler ist nicht „files“; im Mehrfachbetrieb gibt es keinen gemeinsamen Ordner.';

/**
 * Führt $open (session_start, session_regenerate_id: beide öffnen die Datei) mit eigenem Ordner, eigener
 * Laufzeit und eigenem Aufräumen aus. Solange eine Session läuft, lässt PHP diese Werte nicht ändern (Warnung):
 * Sie werden nur ohne laufende Session gesetzt und zurückgesetzt. session_regenerate_id läuft so mit den Werten
 * vom Öffnen. Ist unsere Session offen, gelten sie bis zum Ende der Anfrage, auch nach session_write_close oder
 * session_destroy; zurückgesetzt wird nur, wenn das Öffnen scheitert. Im Router startet die Session der
 * Kundenseite vorher (Website-PHP rendert vor signed_in_user, start_app_session schließt sie) und behält den
 * Ordner des Servers; startet Code der Kundenseite seine Session erst nach unserer (nach signed_in_user oder
 * require_auth), landet sie im Editor-Ordner mit dessen Laufzeit.
 * Mit anderem Handler (z. B. Redis des Hosters) oder nicht beschreibbarem Ordner bleibt alles beim Server.
 * Nicht im Mehrfachbetrieb: Dort teilen sich alle Kunden den Ordner des Servers, ein Cookie von A gälte
 * bei einer Kopie von A; dann RuntimeException (500) statt einer Session.
 */
function le_app_session_open(callable $open): void
{
    $previous = [];
    $own = ini_get('session.save_handler') === 'files' && (is_dir(LE_SESSION_DIR) || @mkdir(LE_SESSION_DIR, 0700, true)) && is_writable(LE_SESSION_DIR);
    if (!$own && le_instance_is_multi()) {
        throw new RuntimeException(LE_SESSION_DIR_TEXT);
    }
    if ($own && session_status() !== PHP_SESSION_ACTIVE) {
        $settings = ['session.save_path' => LE_SESSION_DIR, 'session.gc_maxlifetime' => (string) LE_SESSION_IDLE, 'session.gc_probability' => '1', 'session.gc_divisor' => '100'];
        foreach ($settings as $key => $value) {
            $previous[$key] = (string) ini_get($key);
            ini_set($key, $value);
        }
    }
    try {
        $open();
    } finally {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            foreach ($previous as $key => $value) {
                ini_set($key, $value);
            }
        }
    }
}

// Öffnet unsere Session, ohne Cookie eine neue: nur für den Login (auth_complete_login), alle anderen setzen fort
// (resume_app_session). $quiet: ohne Cache-Header von PHP (Fortsetzen auf der Website).
function start_app_session(bool $quiet = false): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        if (session_name() === APP_SESSION_NAME) {
            return;
        }
        // Site-PHP hat im selben Request (Router) seine Session gestartet: so gespeichert und
        // geschlossen, wie sie ist; danach läuft unsere mit unserer ID.
        session_write_close();
        session_id(is_string($_COOKIE[APP_SESSION_NAME] ?? null) ? $_COOKIE[APP_SESSION_NAME] : '');
    }

    session_name(APP_SESSION_NAME);
    if ($quiet) {
        session_cache_limiter('');
    }
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
    le_app_session_open('session_start');
}

// Bestehende Anmeldung fortsetzen, aber nie eine neue Session anfangen: nur wenn der Browser
// unser Session-Cookie (APP_SESSION_NAME) mitschickt. Besucher der Website und Gäste der API bekommen so kein Cookie.
// $quiet (Website): ohne Cache-Header von PHP, ein fremdes oder abgelaufenes Cookie macht die Seite nicht uncachebar,
// persönliche Antworten setzen no-store selbst (Router); die API (require_auth, bootstrap, logout) behält sie.
// Eine leere Session (abgelaufen, fremde ID) wird verworfen: keine leere Session-Datei, und mit
// session.use_strict_mode kein neues Cookie (PHP vergibt dort für eine unbekannte ID eine neue und schickt sie).
function resume_app_session(bool $quiet = true): bool
{
    $cookie = $_COOKIE[APP_SESSION_NAME] ?? null;
    if (!is_string($cookie) || !preg_match(LE_SESSION_ID_PATTERN, $cookie)) {
        return false;
    }
    if (session_status() === PHP_SESSION_ACTIVE && session_name() === APP_SESSION_NAME) {
        return is_logged_in();
    }
    start_app_session($quiet);
    if ($_SESSION === []) {
        session_destroy();
        remove_session_cookie_header();
        return false;
    }
    return is_logged_in();
}

// Nimmt unser Session-Cookie aus den Antwort-Headern; andere Cookies (z. B. aus Site-PHP) bleiben.
function remove_session_cookie_header(): void
{
    $prefix = 'set-cookie: ' . strtolower(APP_SESSION_NAME) . '=';
    $cookies = array_filter(headers_list(), static fn (string $header): bool => stripos($header, 'set-cookie:') === 0);
    header_remove('Set-Cookie');
    foreach ($cookies as $cookie) {
        if (!str_starts_with(strtolower($cookie), $prefix)) {
            header($cookie, false);
        }
    }
}

/** Dummy-Hash mit denselben Kosten wie neue Hashes (users_needs_rehash bringt alte Konten dorthin). */
function le_login_dummy_hash(): string
{
    foreach (LE_LOGIN_DUMMY_HASHES as $hash) {
        if (!password_needs_rehash($hash, PASSWORD_BCRYPT)) {
            return $hash;
        }
    }
    return LE_LOGIN_DUMMY_HASHES[count(LE_LOGIN_DUMMY_HASHES) - 1];
}

// Einzige Stelle, an der eine Session entsteht: nach geprüftem Passwort (login_user).
function auth_complete_login(array $user): void
{
    start_app_session();
    le_app_session_open(static fn () => session_regenerate_id(true));
    $_SESSION['logged_in'] = true;
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['session_version'] = users_session_version($user);
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

/**
 * Nach der eigenen Passwortänderung: Die laufende Session bleibt angemeldet, bekommt aber eine
 * neue ID, ein neues CSRF-Token und den neuen Stand ($user aus users.json); alle anderen Sessions
 * des Benutzers enden (current_user).
 */
function auth_renew_session(array $user): void
{
    le_app_session_open(static fn () => session_regenerate_id(true));
    $_SESSION['session_version'] = users_session_version($user);
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

function login_user(string $username, string $password): bool
{
    $username = trim($username);
    if ($username === '' || $password === '') {
        return false;
    }

    // Mit kaputter users.json meldet sich niemand an (auch nicht mit setup.php, users_load).
    if (!empty(users_load()['broken'])) {
        return false;
    }
    // setup.php gilt nur, solange es users.json gar nicht gibt (Erst-Setup); danach ohne Passwort.
    if (!is_file(users_path())) {
        $setup = le_setup_credentials();
        if ($setup === null || !hash_equals($setup['username'], $username) || !hash_equals($setup['password'], $password)) {
            return false;
        }
        $bootstrapped = auth_bootstrap_admin($setup['username'], $setup['password']);
        if ($bootstrapped === null) {
            return false;
        }
        le_setup_clear_password($setup['username']);
        auth_complete_login($bootstrapped);
        return true;
    }

    $user = users_find_by_username($username);
    if ($user === null) {
        password_verify($password, le_login_dummy_hash());
        return false;
    }
    if (!users_verify_password($user, $password)) {
        return false;
    }

    if (users_needs_rehash($user)) {
        $newHash = password_hash($password, PASSWORD_BCRYPT);
        if (is_string($newHash) && $newHash !== '') {
            $user = users_update(static function (array &$store) use ($user, $newHash): array {
                foreach ($store['users'] as &$candidate) {
                    if ($candidate['id'] === $user['id']) {
                        $candidate['passwordHash'] = $newHash;
                        $candidate['updatedAt'] = current_iso_time();
                        return $candidate;
                    }
                }
                return $user;
            });
        }
    }

    auth_complete_login($user);
    return true;
}

// Ohne mitgeschicktes Cookie gibt es nichts zu löschen; eine schon verworfene Session (resume_app_session) nichts zu beenden.
function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies') && isset($_COOKIE[APP_SESSION_NAME])) {
        $params = session_get_cookie_params();
        setcookie(APP_SESSION_NAME, '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_destroy();
    }
}

function is_logged_in(): bool
{
    return !empty($_SESSION['logged_in']);
}

function current_user(): ?array
{
    if (!is_logged_in()) {
        return null;
    }
    $id = $_SESSION['user_id'] ?? null;
    if (!is_string($id) || $id === '') {
        return null;
    }
    $user = users_find_by_id($id);
    // Passwort seit dem Login geändert (selbst oder durch einen Admin): Diese Session gilt nicht mehr.
    if ($user === null || (int) ($_SESSION['session_version'] ?? 0) !== users_session_version($user)) {
        return null;
    }

    return $user;
}

// Benutzer der laufenden Session; eine Session ohne existierenden Benutzer (gelöscht) wird beendet.
function session_user(): ?array
{
    $user = current_user();
    if ($user === null && is_logged_in()) {
        logout_user();
    }
    return $user;
}

// Fertig angemeldeter Benutzer für Website, /login und /admin (Router): Cookie mitgeschickt,
// Benutzer existiert, kein offener Passwortwechsel. Startet für Besucher keine Session.
function signed_in_user(): ?array
{
    if (!resume_app_session()) {
        return null;
    }
    $user = session_user();
    return $user !== null && empty($user['mustChangePassword']) ? $user : null;
}

// Ziel nach dem Login: nur ein Pfad dieser Website. Genau ein führender Slash, kein Backslash
// (Browser lesen ihn als Slash, `/\evil` wäre fremd) und keine Steuerzeichen; sonst LE_SITE_HOME_URL.
function safe_redirect_path(mixed $next): string
{
    if (!is_string($next) || !preg_match('#^/(?![/\\\\])[^\\\\\x00-\x1F\x7F]*$#D', $next)) {
        return LE_SITE_HOME_URL;
    }
    return $next;
}

// Pfad der Seite dieser Website, von der die Anfrage kam (Referer mit gleichem Host), für die
// Rückkehr nach dem Login; null ohne, bei fremden Hosts, unsicheren Pfaden und der Login-Seite selbst.
function referer_path(): ?string
{
    $referer = parse_url((string) ($_SERVER['HTTP_REFERER'] ?? ''));
    if (!is_array($referer) || !isset($referer['host'])) {
        return null;
    }
    $host = $referer['host'] . (isset($referer['port']) ? ':' . $referer['port'] : '');
    if (strcasecmp($host, (string) ($_SERVER['HTTP_HOST'] ?? '')) !== 0) {
        return null;
    }
    $path = ($referer['path'] ?? '/') . (isset($referer['query']) ? '?' . $referer['query'] : '');
    return safe_redirect_path($path) === $path && rtrim((string) ($referer['path'] ?? ''), '/') !== LOGIN_URL ? $path : null;
}

function current_role(): ?string
{
    // Rolle immer aus users.json, nie aus der Session: gelöschte oder
    // herabgestufte Benutzer verlieren ihre Rechte sofort.
    return current_user()['role'] ?? null;
}

// Offener Passwortwechsel: nur noch Konten aus dem früheren Erst-Login mit admin/admin (vor setup.php).
function must_change_password(): bool
{
    return !empty(current_user()['mustChangePassword']);
}

function is_admin(): bool
{
    return current_role() === USER_ROLE_ADMIN;
}

function require_auth(bool $allowPendingPasswordChange = false): void
{
    if (!resume_app_session(false) || session_user() === null) {
        json_response(['ok' => false, 'error' => API_TEXT['notAuthenticated']], 401);
    }
    if (!$allowPendingPasswordChange && must_change_password()) {
        json_response(['ok' => false, 'error' => API_TEXT['passwordChange']], 403);
    }
}

function require_admin(): void
{
    require_auth();
    if (!is_admin()) {
        json_response(['ok' => false, 'error' => API_TEXT['forbidden']], 403);
    }
}

// Wer einen Endpunkt aufrufen darf (Spalte role in api/routes.php, le_require_role): jeder, angemeldet, angemeldet auch
// mit offenem Passwortwechsel (nur der Wechsel selbst), nur Admins.
const LE_ROLE_PUBLIC = 'public';
const LE_ROLE_SIGNED_IN = 'signedIn';
const LE_ROLE_PASSWORD_CHANGE = 'passwordChange';
const LE_ROLE_ADMIN = 'admin';
const LE_ROLES = [LE_ROLE_PUBLIC, LE_ROLE_SIGNED_IN, LE_ROLE_PASSWORD_CHANGE, LE_ROLE_ADMIN];
// Methoden, die nichts ändern: Sie brauchen nie ein CSRF-Token.
const LE_SAFE_METHODS = ['GET', 'HEAD'];

/** Bricht mit 401/403 ab, wenn die Anfrage $role (LE_ROLES) nicht hat; öffentlich startet keine Session. */
function le_require_role(string $role): void
{
    match ($role) {
        LE_ROLE_PUBLIC => null,
        LE_ROLE_SIGNED_IN => require_auth(),
        LE_ROLE_PASSWORD_CHANGE => require_auth(true),
        LE_ROLE_ADMIN => require_admin(),
    };
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf'];
}

function require_csrf(): void
{
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!is_string($token) || !hash_equals(csrf_token(), $token)) {
        json_response(['ok' => false, 'error' => API_TEXT['csrf'], 'code' => CSRF_ERROR_CODE], 403);
    }
}
