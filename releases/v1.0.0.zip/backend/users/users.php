<?php
declare(strict_types=1);

require_once LE_BACKEND . '/base/utils.php';
require_once LE_BACKEND . '/users/loginThrottle.php';

const USER_ROLE_EDITOR = 'editor';
const USER_ROLE_ADMIN = 'admin';
const USERS_STORE_VERSION = 1;
// Grenzen für Benutzername und Passwort (users_validate_*), in Bytes wie strlen().
const USERNAME_MIN_LENGTH = 3;
const USERNAME_MAX_LENGTH = 64;
const PASSWORD_MIN_LENGTH = 8;
// bcrypt (password_hash) nutzt nur die ersten 72 Byte und schneidet den Rest still ab.
const PASSWORD_MAX_LENGTH = 72;

function users_path(): string
{
    return LE_USERS_FILE;
}

function users_empty_store(): array
{
    return ['version' => USERS_STORE_VERSION, 'users' => []];
}

/**
 * Benutzer aus users.json. Ohne Datei ein leerer Store (Erst-Setup, auth_bootstrap_admin). Ist sie
 * da, aber unlesbar oder kein gültiger Store, ist der Store 'broken': niemand meldet sich an und
 * users_save überschreibt sie nie. Einträge, die nicht gelten (unbekannte Rolle, Pflichtfeld fehlt),
 * landen in 'unusable': Sie melden sich nicht an, bleiben beim Speichern aber erhalten.
 */
function users_load(): array
{
    $path = users_path();
    if (!is_file($path)) {
        return users_empty_store();
    }

    $raw = @file_get_contents($path);
    $data = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($data) || !isset($data['users']) || !is_array($data['users'])) {
        users_log_once('users.json is unreadable or invalid; login refused, file left untouched');
        return users_empty_store() + ['broken' => true];
    }

    $store = [
        'version' => is_int($data['version'] ?? null) ? $data['version'] : USERS_STORE_VERSION,
        'users' => [],
    ];

    foreach ($data['users'] as $user) {
        $valid = is_array($user) && !empty($user['id']) && !empty($user['username']) && !empty($user['passwordHash']) && !empty($user['role']);
        if (!$valid || !in_array($user['role'], [USER_ROLE_EDITOR, USER_ROLE_ADMIN], true)) {
            users_log_once('users.json has entries with unknown role or missing fields; they cannot log in but are kept');
            $store['unusable'][] = $user;
            continue;
        }
        $entry = [
            'id' => (string) $user['id'],
            'username' => (string) $user['username'],
            'passwordHash' => (string) $user['passwordHash'],
            'role' => (string) $user['role'],
            'createdAt' => (string) ($user['createdAt'] ?? current_iso_time()),
            'updatedAt' => (string) ($user['updatedAt'] ?? current_iso_time()),
        ];
        if (!empty($user['mustChangePassword'])) {
            $entry['mustChangePassword'] = true;
        }
        if (users_session_version($user) > 0) {
            $entry['sessionVersion'] = users_session_version($user);
        }
        $store['users'][] = $entry;
    }

    return $store;
}

/**
 * Stand der Anmeldungen eines Benutzers: Jede Passwortänderung zählt ihn hoch, Sessions mit einem
 * älteren Stand gelten nicht mehr (current_user). Ohne Eintrag 0.
 */
function users_session_version(array $user): int
{
    return max(0, (int) ($user['sessionVersion'] ?? 0));
}

/** Fehler zu users.json einmal je Request ins Fehlerprotokoll (users_load läuft je Request oft). */
function users_log_once(string $message): void
{
    static $logged = [];
    if (!isset($logged[$message])) {
        $logged[$message] = true;
        error_log('lebuild: ' . $message);
    }
}

function users_save(array $store): void
{
    // Nie einen Store aus einer kaputten Datei schreiben: Sie bleibt, wie sie ist, zum Reparieren.
    if (!empty($store['broken'])) {
        throw new RuntimeException('users.json is unreadable, not overwritten');
    }
    $store['version'] = USERS_STORE_VERSION;
    if (!isset($store['users']) || !is_array($store['users'])) {
        $store['users'] = [];
    }
    $store['users'] = array_merge($store['users'], $store['unusable'] ?? []);
    unset($store['unusable']);

    $encoded = json_encode($store, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if ($encoded === false) {
        throw new RuntimeException('Failed to encode users store');
    }

    write_private_file(users_path(), $encoded);
}

/**
 * Lesen → Ändern → Schreiben von users.json unter store_lock('users'): $change bekommt den Store
 * per Referenz, sein Ergebnis kommt zurück. So geht bei gleichzeitigen Änderungen (zwei Admins)
 * keine verloren. Bricht $change die Anfrage ab (json_response), wird nichts geschrieben.
 */
function users_update(callable $change): mixed
{
    $lock = store_lock('users');
    try {
        $store = users_load();
        $result = $change($store);
        users_save($store);
        return $result;
    } finally {
        store_unlock($lock);
    }
}

/**
 * users_update für die Endpoints unter api/users/: Scheitern Sperre oder Schreiben, kommt der Grund
 * ins Fehlerprotokoll und die Antwort ist JSON mit usersSaveFailed (500) statt einer HTML-Fehlerseite.
 */
function le_users_update_or_fail(callable $change): mixed
{
    try {
        return users_update($change);
    } catch (Throwable $e) {
        error_log('lebuild users: ' . $e->getMessage());
        json_response(['ok' => false, 'error' => API_TEXT['usersSaveFailed']], 500);
    }
}

/** Ist $username (ohne Groß/klein) im Store schon vergeben, außer an den Benutzer $exceptId? */
function le_users_name_taken(array $store, string $username, string $exceptId = ''): bool
{
    foreach ($store['users'] as $other) {
        if ($other['id'] !== $exceptId && strcasecmp($other['username'], $username) === 0) {
            return true;
        }
    }
    return false;
}

/**
 * Benutzer anlegen (api/users/create.php): Name, Passwort und Rolle prüfen (400 mit der Meldung aus users_validate_*),
 * unter der Sperre ein vergebener Name (ohne Groß/klein) 409. Liefert den neuen Benutzer.
 */
function le_users_create(string $username, string $password, string $role): array
{
    if ($error = users_validate_username($username)) {
        json_response(['ok' => false, 'error' => $error], 400);
    }
    if ($error = users_validate_password($password)) {
        json_response(['ok' => false, 'error' => $error], 400);
    }
    if ($error = users_validate_role($role)) {
        json_response(['ok' => false, 'error' => $error], 400);
    }

    $now = current_iso_time();
    $user = [
        'id' => users_generate_id(),
        'username' => $username,
        'passwordHash' => password_hash($password, PASSWORD_BCRYPT),
        'role' => $role,
        'createdAt' => $now,
        'updatedAt' => $now,
    ];
    // Unter der Sperre: Zwei gleichzeitige Anlagen desselben Namens ergeben keinen doppelten Benutzer.
    le_users_update_or_fail(static function (array &$store) use ($user): void {
        if (le_users_name_taken($store, $user['username'])) {
            json_response(['ok' => false, 'error' => API_TEXT['usernameTaken']], 409);
        }
        $store['users'][] = $user;
    });
    return $user;
}

/** Stelle des Benutzers $id in $store['users'] (unter der Sperre von users_update); unbekannt → 404 userNotFound. */
function le_users_index_or_fail(array $store, string $id): int
{
    foreach ($store['users'] as $i => $user) {
        if ($user['id'] === $id) {
            return $i;
        }
    }
    json_response(['ok' => false, 'error' => API_TEXT['userNotFound']], 404);
}

/**
 * Benutzer ändern (api/users/update.php): $fields mit 'username' und/oder 'role' (fehlt der Schlüssel, bleibt der Wert).
 * Ohne ID 400; unter der Sperre unbekannt 404, Name ungültig 400 oder vergeben 409, Rolle ungültig 400, den letzten Admin
 * herabstufen 400. Ohne Änderung bleibt updatedAt. Liefert den Benutzer danach.
 */
function le_users_edit(string $id, array $fields): array
{
    if ($id === '') {
        json_response(['ok' => false, 'error' => API_TEXT['userIdRequired']], 400);
    }

    return le_users_update_or_fail(static function (array &$store) use ($id, $fields): array {
        $index = le_users_index_or_fail($store, $id);
        $current = $store['users'][$index];
        $updated = $current;
        $changed = false;

        if (array_key_exists('username', $fields)) {
            $newUsername = trim((string) $fields['username']);
            if ($error = users_validate_username($newUsername)) {
                json_response(['ok' => false, 'error' => $error], 400);
            }
            if (strcasecmp($newUsername, $current['username']) !== 0 && le_users_name_taken($store, $newUsername, $id)) {
                json_response(['ok' => false, 'error' => API_TEXT['usernameTaken']], 409);
            }
            $updated['username'] = $newUsername;
            $changed = $changed || $newUsername !== $current['username'];
        }

        if (array_key_exists('role', $fields)) {
            $newRole = (string) $fields['role'];
            if ($error = users_validate_role($newRole)) {
                json_response(['ok' => false, 'error' => $error], 400);
            }
            if ($newRole !== $current['role']) {
                if ($current['role'] === USER_ROLE_ADMIN && $newRole !== USER_ROLE_ADMIN && users_count_admins($id) === 0) {
                    json_response(['ok' => false, 'error' => API_TEXT['lastAdminDemote']], 400);
                }
                $updated['role'] = $newRole;
                $changed = true;
            }
        }

        if ($changed) {
            $updated['updatedAt'] = current_iso_time();
            $store['users'][$index] = $updated;
        }
        return $updated;
    });
}

/**
 * Benutzer löschen (api/users/delete.php): ohne ID 400, das eigene Konto ($selfId) 400; unter der Sperre unbekannt 404,
 * der letzte Admin 400. Liefert den Namen des Gelöschten.
 */
function le_users_delete(string $id, string $selfId): string
{
    if ($id === '') {
        json_response(['ok' => false, 'error' => API_TEXT['userIdRequired']], 400);
    }
    if ($selfId === $id) {
        json_response(['ok' => false, 'error' => API_TEXT['deleteSelf']], 400);
    }

    return le_users_update_or_fail(static function (array &$store) use ($id): string {
        $index = le_users_index_or_fail($store, $id);
        $target = $store['users'][$index];
        if ($target['role'] === USER_ROLE_ADMIN && users_count_admins($id) === 0) {
            json_response(['ok' => false, 'error' => API_TEXT['lastAdminDelete']], 400);
        }
        array_splice($store['users'], $index, 1);
        return $target['username'];
    });
}

/**
 * Passwort wechseln (api/users/changePassword.php) für den angemeldeten Benutzer $self: ohne $targetId (oder mit der
 * eigenen) das eigene, sonst nur als Admin ein fremdes (403). Das neue Passwort prüft users_validate_password (400). Beim
 * eigenen zählt ein falsches aktuelles Passwort wie ein Fehlversuch beim Login je Adresse und dazu je Session (gebremst:
 * LOGIN_THROTTLED_STATUS, falsch: 400); nach dem Erst-Login (mustChangePassword) reicht die frische Session. Unter der
 * Sperre: unbekannt 404, aktuelles Passwort noch einmal geprüft. Alle Sessions des Benutzers enden (sessionVersion).
 * Liefert ['user' => Benutzer danach, 'self' => eigenes Passwort?].
 */
function le_users_change_password(array $self, string $targetId, string $currentPassword, string $newPassword): array
{
    if ($targetId === '' || $targetId === $self['id']) {
        $isSelf = true;
        $targetId = $self['id'];
    } else {
        $isSelf = false;
        if ($self['role'] !== USER_ROLE_ADMIN) {
            json_response(['ok' => false, 'error' => API_TEXT['forbidden']], 403);
        }
    }

    // Das Standardpasswort ist kürzer als PASSWORD_MIN_LENGTH und fällt schon hier durch.
    if ($error = users_validate_password($newPassword)) {
        json_response(['ok' => false, 'error' => $error], 400);
    }

    // Falsche aktuelle Passwörter zählen wie Fehlversuche beim Login je Adresse (derselbe Zähler) und dazu je Session: Mit
    // einer übernommenen Session ließe sich sonst unbegrenzt raten. Nicht je Benutzer: Fehlversuche anderer für denselben
    // Namen sperrten sonst den angemeldeten Benutzer aus. Geprüft wird unten unter der Sperre noch einmal.
    if ($isSelf && empty($self['mustChangePassword'])) {
        $cutoff = time() - LOGIN_FAILURE_WINDOW;
        $sessionFailures = array_values(array_filter((array) ($_SESSION[LE_PASSWORD_FAILURES_SESSION_KEY] ?? []), static fn (mixed $t): bool => is_int($t) && $t > $cutoff));
        if (count($sessionFailures) >= LOGIN_MAX_FAILURES || !login_attempt_begin()) {
            json_response(['ok' => false, 'error' => LOGIN_THROTTLED_MESSAGE], LOGIN_THROTTLED_STATUS);
        }
        if (!users_verify_password($self, $currentPassword)) {
            $_SESSION[LE_PASSWORD_FAILURES_SESSION_KEY] = [...$sessionFailures, time()];
            json_response(['ok' => false, 'error' => API_TEXT['wrongPassword']], 400);
        }
        login_attempt_forget();
    }

    $changed = le_users_update_or_fail(static function (array &$store) use ($targetId, $isSelf, $currentPassword, $newPassword): array {
        $index = le_users_index_or_fail($store, $targetId);
        // Beim erzwungenen Wechsel nach dem Erst-Login ist das alte Passwort das
        // bekannte Standardpasswort; die frische Session reicht als Nachweis.
        if ($isSelf && empty($store['users'][$index]['mustChangePassword'])) {
            if (!users_verify_password($store['users'][$index], $currentPassword)) {
                json_response(['ok' => false, 'error' => API_TEXT['wrongPassword']], 400);
            }
        }

        $store['users'][$index]['passwordHash'] = password_hash($newPassword, PASSWORD_BCRYPT);
        $store['users'][$index]['updatedAt'] = current_iso_time();
        // Alle bestehenden Sessions des Benutzers enden (gestohlene Session nach einem Reset).
        $store['users'][$index]['sessionVersion'] = users_session_version($store['users'][$index]) + 1;
        if ($isSelf) {
            unset($store['users'][$index]['mustChangePassword']);
        }
        return $store['users'][$index];
    });
    return ['user' => $changed, 'self' => $isSelf];
}

function users_find_by_username(string $username): ?array
{
    $username = trim($username);
    if ($username === '') {
        return null;
    }
    $store = users_load();
    foreach ($store['users'] as $user) {
        if (strcasecmp($user['username'], $username) === 0) {
            return $user;
        }
    }

    return null;
}

function users_find_by_id(string $id): ?array
{
    if ($id === '') {
        return null;
    }
    $store = users_load();
    foreach ($store['users'] as $user) {
        if ($user['id'] === $id) {
            return $user;
        }
    }

    return null;
}

function users_verify_password(array $user, string $password): bool
{
    if (empty($user['passwordHash']) || !is_string($user['passwordHash'])) {
        return false;
    }

    return password_verify($password, $user['passwordHash']);
}

function users_needs_rehash(array $user): bool
{
    if (empty($user['passwordHash']) || !is_string($user['passwordHash'])) {
        return false;
    }

    return password_needs_rehash($user['passwordHash'], PASSWORD_BCRYPT);
}

function users_generate_id(): string
{
    return 'u_' . bin2hex(random_bytes(6));
}

function users_validate_username(string $username): ?string
{
    $username = trim($username);
    if ($username === '') {
        return API_TEXT['usernameRequired'];
    }
    if (strlen($username) < USERNAME_MIN_LENGTH) {
        return sprintf(API_TEXT['usernameShort'], USERNAME_MIN_LENGTH);
    }
    if (strlen($username) > USERNAME_MAX_LENGTH) {
        return sprintf(API_TEXT['usernameLong'], USERNAME_MAX_LENGTH);
    }
    if (!preg_match('/^[a-zA-Z0-9._-]+$/', $username)) {
        return API_TEXT['usernameChars'];
    }

    return null;
}

function users_validate_password(string $password): ?string
{
    if (strlen($password) < PASSWORD_MIN_LENGTH) {
        return sprintf(API_TEXT['passwordShort'], PASSWORD_MIN_LENGTH);
    }
    if (strlen($password) > PASSWORD_MAX_LENGTH) {
        return sprintf(API_TEXT['passwordLong'], PASSWORD_MAX_LENGTH);
    }

    return null;
}

function users_validate_role(string $role): ?string
{
    if (!in_array($role, [USER_ROLE_EDITOR, USER_ROLE_ADMIN], true)) {
        return API_TEXT['invalidRole'];
    }

    return null;
}

function users_count_admins(?string $excludeId = null): int
{
    $store = users_load();
    $count = 0;
    foreach ($store['users'] as $user) {
        if (($user['role'] ?? null) !== USER_ROLE_ADMIN) {
            continue;
        }
        if ($excludeId !== null && $user['id'] === $excludeId) {
            continue;
        }
        $count++;
    }

    return $count;
}

function users_public_view(array $user): array
{
    return [
        'id' => $user['id'],
        'username' => $user['username'],
        'role' => $user['role'],
        'createdAt' => $user['createdAt'] ?? null,
        'updatedAt' => $user['updatedAt'] ?? null,
    ];
}
