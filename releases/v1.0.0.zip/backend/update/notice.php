<?php
declare(strict_types=1);

// Hinweis „Update installiert“ für Admins (eigene Datei: der Seiten-Editor braucht ihn, nicht den Updater).

require_once LE_BACKEND . '/users/auth.php';

// Hinweis „Update installiert“ aus dem Login (api/login.php) für Admins, bis das Backend
// (api/bootstrap.php) oder der Seiten-Editor (backend/pages/siteEditor.php) ihn einmal zeigt.
const UPDATE_NOTICE_SESSION_KEY = 'updateInstalled';

function remember_update_notice(?array $installed): void
{
    if ($installed !== null && is_admin()) {
        $_SESSION[UPDATE_NOTICE_SESSION_KEY] = $installed;
    }
}

/** Gemerkter Hinweis, nur einmal; null ohne oder für Nicht-Admins. */
function take_update_notice(): ?array
{
    $notice = $_SESSION[UPDATE_NOTICE_SESSION_KEY] ?? null;
    unset($_SESSION[UPDATE_NOTICE_SESSION_KEY]);
    return is_array($notice) && is_admin() ? $notice : null;
}
