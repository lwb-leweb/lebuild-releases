<?php
declare(strict_types=1);

require_once LE_BACKEND . '/base/utils.php';
require_once LE_BACKEND . '/base/activity.php';
require_once LE_BACKEND . '/base/files.php';
require_once LE_BACKEND . '/update/install.php';

// Releases liegen öffentlich und signiert in einem eigenen Repo. Der Updater
// braucht deshalb keinen GitHub-Token; die RSA-Signatur (OpenSSL) beweist,
// dass das ZIP aus unserem Release-Workflow stammt.
const UPDATER_FEED_URL = 'https://raw.githubusercontent.com/lwb-leweb/lebuild-releases/main/latest.json';
const UPDATER_OPENSSL_PUBLIC_KEY = <<<'PEM'
-----BEGIN PUBLIC KEY-----
MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAvSlRiP1ClK9aRARTq8UN
fWPBJLSGpezaDw8YpDQMNOGwUmu/jfPGpgCZZ73ohIMxeWgfB/YfYIi4gheWntna
HFFhXEcsvW4Q5AYVDKhbqpDgm4GOcPbFBcNy/4GJbFkI+fxov+9+o1uPIqgP+oN2
2ZW4rNSTVxHxVCeolD7h1XoY4BbpjbJrRQgtEX2dwl4G+LqgpHFqzpVZ/Hu6aqsW
gRWA54oI7pehsxBY3O/h6SMTaCwgELee9exFbozSy+/zviW0Q8TwQrlefLsTaCgN
uImiNyAbGGnM7TbaeGdS+SXASCV8ueS2A89uLrMsNXVUumoWa/K+gXu1+gnElfKN
QBdu62/d6MmWLYgbV3a0UqqOQAncgvA4GWlqyg7I8m5rvv2QhKoY+cGV3PRAlTkW
wDEHp6jncX3whrMoQwx08TFN8ax99mQ0nt5+JT+rhXOe/FJeuRXoPAUUs+xbnn2L
v0m5LlyofLaj4HHhfmPRY6aPG6hVN0kS4vjRgJ6mqPL/JGHRxO9nkOai/MwB6XT+
BX7pVB1O2VpYisFOXD0hgmsfzS86WDL+OK5mfnZUfGDuIjy1HiB++oGUXq0vYs25
52R8aowKgnDg2ISAkvYXcMRz/+Ar2joYSL2swaF3VedGFfLiUV0X2wlpMyJyMsLB
/G56M27Q7aYldkKwaCfc0/UCAwEAAQ==
-----END PUBLIC KEY-----
PEM;
// Meldungen von updater_install(), die api/installUpdate.php an den Browser gibt.
const UPDATER_OPENSSL_MISSING_MESSAGE = 'PHP openssl-Erweiterung fehlt.';
const UPDATER_SIGNATURE_INVALID_MESSAGE = 'Signatur des Updates ungültig.';
// Meldungen an den Browser (Einstellungen → Updates); Details stehen im Update-Log.
const UPDATER_TEXT = [
    'disabled' => 'Updater deaktiviert.',
    'zipMissing' => 'PHP ZipArchive-Erweiterung fehlt.',
    'noUpdate' => 'Kein Update verfügbar (zuerst prüfen).',
    'upToDate' => 'Bereits aktuell.',
    'running' => 'Update läuft bereits.',
    'download' => 'Download fehlgeschlagen.',
    'zipOpen' => 'ZIP konnte nicht geöffnet werden.',
    'zipPaths' => 'ZIP enthält ungültige Pfade.',
    'zipExtract' => 'ZIP konnte nicht entpackt werden.',
    'archiveInvalid' => 'Entpacktes Archiv ungültig.',
    'manifestMissing' => 'Release-Manifest fehlt im Archiv.',
    'manifestUnreadable' => 'Release-Manifest unleserlich.',
    'versionMismatch' => 'Version im Update passt nicht.',
    'needsConfirmation' => 'Update muss bestätigt werden.',
    'noPaths' => 'Keine erlaubten Pfade im Manifest.',
    'noBackup' => 'Kein Backup verfügbar.',
    'busy' => 'Update läuft gerade.',
    'unreachable' => 'Konnte Update-Quelle nicht erreichen.',
    'failed' => 'Update fehlgeschlagen, Details im Update-Log.',
    // %s: verwalteter Pfad wie frontend (aus release.json, keine Server-Pfade).
    'backupFailed' => 'Backup für %s fehlgeschlagen.',
    'swapFailed' => 'Tausch für %s fehlgeschlagen.',
    'rollbackFailed' => 'Rollback für %s fehlgeschlagen.',
    // %1$s Version des Updates, %2$s minPhp aus release.json, %3$s laufende PHP-Version.
    'phpTooOld' => 'Update %1$s braucht PHP %2$s oder neuer, hier läuft PHP %3$s. Bitte beim Hoster eine neuere PHP-Version einstellen.',
];
const UPDATER_CHECK_INTERVAL_SECONDS = 12 * 60 * 60;
const UPDATER_USER_AGENT = 'lebuild-updater';

function updater_feed_url(): string
{
    $env = getenv('LEBUILD_UPDATE_FEED');
    return is_string($env) && $env !== '' ? $env : UPDATER_FEED_URL;
}

function updater_cache_path(): string
{
    return CACHE_ROOT . '/update-cache.json';
}

function updater_backup_root(): string
{
    return CACHE_ROOT . '/update-backup';
}

function updater_tmp_root(): string
{
    return CACHE_ROOT . '/update-tmp';
}

function updater_lock_path(): string
{
    return CACHE_ROOT . '/update-lock';
}

/**
 * Auto-Update an? Aus mit LEBUILD_UPDATES=off und immer mit eigenem Kundenordner (le_instance_is_multi): Dort ist
 * der Code ein Git-Checkout für alle Websites, Updates kommen per Tag (ops/README.md, „Updates“).
 */
function updater_enabled(): bool
{
    if (le_instance_is_multi()) {
        return false;
    }
    $flag = getenv('LEBUILD_UPDATES');
    if ($flag === false || $flag === '') {
        return true;
    }
    return !in_array(strtolower($flag), ['off', '0', 'false', 'no'], true);
}

function updater_read_local_manifest(): array
{
    $data = le_release_manifest();
    return [
        'version' => le_release_version(),
        'requiresConfirmation' => !empty($data['requiresConfirmation']),
        'notes' => (string) ($data['notes'] ?? ''),
        'managedPaths' => is_array($data['managedPaths'] ?? null) ? $data['managedPaths'] : UPDATER_ALLOWED_MANAGED_PATHS,
    ];
}

function updater_load_cache(): array
{
    $defaults = [
        'lastCheck' => null,
        'latestVersion' => null,
        'requiresConfirmation' => false,
        'notes' => '',
        'zipUrl' => '',
        'opensslSignature' => '',
        // Mindestversion PHP des Releases (minPhp aus latest.json bzw. dem signierten release.json).
        'minPhp' => '',
        'tag' => '',
        'lastError' => null,
        'skippedVersion' => null,
        // Version, deren automatische Installation gescheitert ist; bis zur nächsten Feed-Prüfung kein neuer Versuch.
        'failedVersion' => null,
    ];
    $path = updater_cache_path();
    $data = is_file($path) ? json_decode((string) file_get_contents($path), true) : null;

    return is_array($data) ? array_merge($defaults, $data) : $defaults;
}

function updater_save_cache(array $cache): void
{
    // Nur ein Cache: Scheitert das Schreiben, prüft der nächste Request wieder.
    try {
        write_file_atomic(updater_cache_path(), json_encode($cache, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . PHP_EOL);
    } catch (RuntimeException $e) {
    }
}

function updater_http_get(string $url, int $timeout = 15): ?string
{
    $headers = ['Accept: application/json'];

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_USERAGENT => UPDATER_USER_AGENT,
            CURLOPT_HTTPHEADER => $headers,
        ]);
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($body === false || $code < 200 || $code >= 300) {
            return null;
        }
        return (string) $body;
    }

    $headerLines = "User-Agent: " . UPDATER_USER_AGENT . "\r\n";
    foreach ($headers as $h) {
        $headerLines .= $h . "\r\n";
    }
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => $headerLines,
            'timeout' => $timeout,
            'follow_location' => 1,
        ],
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
        ],
    ]);
    $body = @file_get_contents($url, false, $context);
    return $body === false ? null : $body;
}

function updater_http_download(string $url, string $destPath, int $timeout = 60): bool
{
    ensure_dir(dirname($destPath));

    if (function_exists('curl_init')) {
        $fh = @fopen($destPath, 'wb');
        if (!$fh) {
            return false;
        }
        $opts = [
            CURLOPT_FILE => $fh,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_USERAGENT => UPDATER_USER_AGENT,
        ];
        $ch = curl_init($url);
        curl_setopt_array($ch, $opts);
        $ok = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        fclose($fh);
        if (!$ok || $code < 200 || $code >= 300) {
            @unlink($destPath);
            return false;
        }
        return true;
    }

    $body = updater_http_get($url, $timeout);
    if ($body === null) {
        return false;
    }
    return @file_put_contents($destPath, $body) !== false;
}

function updater_fetch_remote(): ?array
{
    $body = updater_http_get(updater_feed_url());
    $feed = $body !== null ? json_decode($body, true) : null;
    if (!is_array($feed) || empty($feed['version']) || empty($feed['zipUrl'])) {
        return null;
    }

    return [
        'tag' => (string) ($feed['tag'] ?? ('v' . $feed['version'])),
        'version' => (string) $feed['version'],
        'requiresConfirmation' => !empty($feed['requiresConfirmation']),
        'notes' => (string) ($feed['notes'] ?? ''),
        'zipUrl' => (string) $feed['zipUrl'],
        // Fehlt sie, lehnt updater_install() das Update ab (mit Eintrag im Log).
        'opensslSignature' => (string) ($feed['opensslSignature'] ?? ''),
        'minPhp' => (string) ($feed['minPhp'] ?? ''),
    ];
}

/** Meldung, wenn PHP $version (sonst das laufende) unter minPhp des Releases $releaseVersion liegt, sonst null. */
function updater_php_too_old(string $releaseVersion, string $minPhp, string $version = PHP_VERSION): ?string
{
    return $minPhp !== '' && version_compare($version, $minPhp, '<') ? sprintf(UPDATER_TEXT['phpTooOld'], $releaseVersion, $minPhp, $version) : null;
}

/** $publicKey: PEM; ein anderer als der eigene nur beim Signieren (ops/tools/sign-release.php). */
function updater_signature_valid(string $zipPath, string $signature, string $publicKey = UPDATER_OPENSSL_PUBLIC_KEY): bool
{
    if (!function_exists('openssl_verify')) {
        return false;
    }
    $sig = base64_decode($signature, true);
    $key = @openssl_pkey_get_public($publicKey);
    $data = @file_get_contents($zipPath);
    if ($sig === false || $sig === '' || $key === false || $data === false) {
        return false;
    }

    return openssl_verify($data, $sig, $key, OPENSSL_ALGO_SHA256) === 1;
}

function updater_status(): array
{
    $local = updater_read_local_manifest();
    $cache = updater_load_cache();
    $latest = $cache['latestVersion'];
    // Abgeschaltet gibt es kein Update anzubieten, auch wenn der Cache von früher eine neuere Version kennt.
    $hasUpdate = updater_enabled() && $latest !== null && version_compare($latest, $local['version'], '>');

    return [
        'enabled' => updater_enabled(),
        // Mehrfachbetrieb: Der Code ist ein Checkout für alle Websites, die Verwaltung zeigt nur die Version.
        'multiSite' => le_instance_is_multi(),
        'currentVersion' => $local['version'],
        'latestVersion' => $latest,
        'tag' => $cache['tag'] ?? '',
        'hasUpdate' => $hasUpdate,
        'requiresConfirmation' => !empty($cache['requiresConfirmation']),
        // Grund, warum das Update hier nie installiert wird (PHP unter minPhp des Releases), für Banner und Dashboard.
        'phpTooOld' => $hasUpdate ? updater_php_too_old((string) $latest, (string) $cache['minPhp']) : null,
        'notes' => $cache['notes'] ?? '',
        'lastCheck' => $cache['lastCheck'] ?? null,
        'lastError' => $cache['lastError'] ?? null,
        'skippedVersion' => $cache['skippedVersion'] ?? null,
        'failedVersion' => $cache['failedVersion'] ?? null,
        // Im Mehrfachbetrieb kein Rollback: Er schriebe den Checkout für alle Websites.
        'rollbackAvailable' => !le_instance_is_multi() && is_dir(updater_backup_root()),
    ];
}

function updater_check(bool $force = false): array
{
    if (!updater_enabled()) {
        return updater_status();
    }

    $cache = updater_load_cache();
    $now = time();
    $last = $cache['lastCheck'] ? strtotime((string) $cache['lastCheck']) : 0;
    if (!$force && $last && ($now - $last) < UPDATER_CHECK_INTERVAL_SECONDS) {
        return updater_status();
    }

    $remote = updater_fetch_remote();
    if ($remote === null) {
        $cache['lastCheck'] = current_iso_time();
        $cache['lastError'] = UPDATER_TEXT['unreachable'];
        updater_save_cache($cache);
        updater_log('check failed: remote unreachable');
        return updater_status();
    }

    $cache = array_merge($cache, [
        'lastCheck' => current_iso_time(),
        'latestVersion' => $remote['version'],
        'requiresConfirmation' => $remote['requiresConfirmation'],
        'notes' => $remote['notes'],
        'zipUrl' => $remote['zipUrl'],
        'opensslSignature' => $remote['opensslSignature'],
        'minPhp' => $remote['minPhp'],
        'tag' => $remote['tag'],
        'lastError' => null,
        'failedVersion' => null,
    ]);
    updater_save_cache($cache);
    updater_log(sprintf('check ok: latest=%s tag=%s confirm=%s', $remote['version'], $remote['tag'], $remote['requiresConfirmation'] ? 'yes' : 'no'));

    return updater_status();
}

function updater_should_auto_install(): bool
{
    if (!updater_enabled()) {
        return false;
    }
    $cache = updater_load_cache();
    $local = updater_read_local_manifest();
    if (empty($cache['latestVersion'])) {
        return false;
    }
    if (!empty($cache['requiresConfirmation'])) {
        return false;
    }
    if (updater_php_too_old((string) $cache['latestVersion'], (string) $cache['minPhp']) !== null) {
        return false;
    }
    // Nach einem Rollback diese Version nicht gleich wieder automatisch
    // einspielen; manuell installieren geht weiterhin.
    if (($cache['skippedVersion'] ?? null) === $cache['latestVersion']) {
        return false;
    }
    if (($cache['failedVersion'] ?? null) === $cache['latestVersion']) {
        return false;
    }
    return version_compare((string) $cache['latestVersion'], $local['version'], '>');
}

/**
 * Beim Login und beim Laden des Backends (api/login.php, api/bootstrap.php): nach Updates sehen
 * und, wo es ohne Bestätigung geht, gleich einspielen. Liefert ['status' => updater_status()
 * oder null, 'installed' => ['previousVersion', 'newVersion'] oder null]; Fehler nur ins Log
 * ($context nennt den Aufrufer).
 */
function updater_auto_update(string $context): array
{
    $flow = ['status' => null, 'installed' => null];
    try {
        updater_check(false);
        if (updater_should_auto_install()) {
            $version = updater_load_cache()['latestVersion'];
            try {
                $result = updater_install(false);
            } catch (Throwable $e) {
                updater_log($context . ' update install failed: ' . $e->getMessage());
                $result = ['ok' => false, 'error' => UPDATER_TEXT['failed']];
            }
            // Gescheitert (nicht nur belegt oder zur Bestätigung zurückgestellt): einmal melden, bis zur nächsten
            // Feed-Prüfung nicht wieder bei jedem Aufruf herunterladen und tauschen. Gilt nur für die versuchte
            // Version; kennt der Cache inzwischen eine neuere, bleibt die frei.
            if (empty($result['ok']) && !in_array($result['error'] ?? null, [UPDATER_TEXT['running'], UPDATER_TEXT['needsConfirmation']], true)) {
                $cache = updater_load_cache();
                if ($cache['latestVersion'] === $version) {
                    $cache['failedVersion'] = $version;
                    $cache['lastError'] = $result['error'] ?? UPDATER_TEXT['failed'];
                    updater_save_cache($cache);
                }
            }
            if (!empty($result['ok'])) {
                le_activity_log('update_installed', ($result['previousVersion'] ?? '?') . ' → ' . ($result['newVersion'] ?? '?'));
                $flow['installed'] = [
                    'previousVersion' => $result['previousVersion'] ?? null,
                    'newVersion' => $result['newVersion'] ?? null,
                ];
            }
        }
        $flow['status'] = updater_status();
    } catch (Throwable $e) {
        updater_log($context . ' update flow failed: ' . $e->getMessage());
    }
    return $flow;
}

/** Sperre eines Updates oder Rollbacks (le_lock_file ohne Warten); null, wenn schon eines läuft. */
function updater_acquire_lock()
{
    return le_lock_file(updater_lock_path());
}

// Nur die Update-Sperre wird danach gelöscht. Andere Sperrdateien (Config-,
// Datenumzug) bleiben: An ihnen warten andere Requests bzw. sie tragen Notizen.
function updater_release_lock($fh): void
{
    if (!$fh) {
        return;
    }
    $isUpdateLock = stream_get_meta_data($fh)['uri'] === updater_lock_path();
    store_unlock($fh);
    if ($isUpdateLock) {
        @unlink(updater_lock_path());
    }
}
