<?php
declare(strict_types=1);

// Update einspielen und zurücknehmen: verwaltete Pfade tauschen, Rollback.

require_once LE_BACKEND . '/base/files.php';
require_once LE_BACKEND . '/base/utils.php';
require_once LE_BACKEND . '/update/updater.php';

// plugins/ relativ zum Hauptordner; der Updater tauscht es je Plugin-Ordner (Namen wie plugin_name_valid()),
// damit Plugins, die nur auf einer Installation liegen, stehen bleiben.
define('UPDATER_PLUGINS_PATH', le_root_relative(LE_PLUGINS));
// Nur diese Pfade (relativ zum Hauptordner, aus den Konstanten in paths.php) tauscht ein Update; website/ mit setup.php
// (Zugang des ersten Admins) gehört nie dazu.
define('UPDATER_ALLOWED_MANAGED_PATHS', array_map('le_root_relative', [LE_BACKEND, LE_RELEASE_FILE, LE_FRONTEND, LE_PLUGINS, LE_WEBROOT, LE_ROOT_HTACCESS_FILE]));
const UPDATER_PLUGIN_DIR_PATTERN = '/^[a-z][a-z0-9_-]*$/';
// Liste der beim Update getauschten Pfade im Backup, für den Rollback.
const UPDATER_BACKUP_PATHS_FILE = 'paths.json';

function updater_filtered_managed_paths(array $requested): array
{
    $allowed = [];
    foreach ($requested as $path) {
        if (!is_string($path) || $path === '') {
            continue;
        }
        $normalized = str_replace('\\', '/', $path);
        $normalized = trim($normalized, '/');
        if ($normalized === '' || strpos($normalized, '..') !== false) {
            continue;
        }
        if (in_array($normalized, UPDATER_ALLOWED_MANAGED_PATHS, true)) {
            $allowed[] = $normalized;
        }
    }
    return $allowed;
}

/** 'plugins' wird zu 'plugins/<name>' je Plugin, das das Release mitbringt. */
function updater_expand_plugin_paths(string $sourceRoot, array $managedPaths): array
{
    $expanded = [];
    foreach ($managedPaths as $relative) {
        if ($relative !== UPDATER_PLUGINS_PATH) {
            $expanded[] = $relative;
            continue;
        }
        $dir = $sourceRoot . '/' . UPDATER_PLUGINS_PATH;
        foreach (is_dir($dir) ? (scandir($dir) ?: []) : [] as $entry) {
            if (preg_match(UPDATER_PLUGIN_DIR_PATTERN, $entry) && is_dir($dir . '/' . $entry)) {
                $expanded[] = UPDATER_PLUGINS_PATH . '/' . $entry;
            }
        }
    }
    return $expanded;
}

function updater_save_backup_paths(string $backupRoot, array $paths): void
{
    try {
        write_file_atomic($backupRoot . '/' . UPDATER_BACKUP_PATHS_FILE, (string) json_encode(array_values($paths)));
    } catch (Throwable $e) {
        // Eine alte Liste (etwa vor einem Teil-Rollback) nennt Pfade, die schon zurückliegen; ohne Liste legt der
        // Rollback nur zurück, was noch im Backup liegt.
        @unlink($backupRoot . '/' . UPDATER_BACKUP_PATHS_FILE);
        updater_log('could not write ' . UPDATER_BACKUP_PATHS_FILE . ' in ' . $backupRoot);
    }
}

/**
 * Pfade, die der Rollback zurücklegt: die beim Update getauschten (laut Liste
 * im Backup). Backups ohne lesbare Liste (Update durch eine Version vor dem
 * Tausch je Plugin, Schreiben der Liste gescheitert): jeder verwaltete Pfad,
 * von dem es ein Backup gibt, plugins/ aber je Plugin im Backup, nie als ganzer
 * Ordner (sonst wären Plugins nur dieser Installation weg). Plugins, die erst
 * das Update mitbrachte, bleiben dann liegen.
 */
function updater_backup_paths(string $backupRoot): array
{
    $list = json_decode((string) @file_get_contents($backupRoot . '/' . UPDATER_BACKUP_PATHS_FILE), true);
    if (!is_array($list)) {
        $present = array_values(array_filter(UPDATER_ALLOWED_MANAGED_PATHS, static fn ($relative) => file_exists($backupRoot . '/' . $relative)));
        return updater_expand_plugin_paths($backupRoot, $present);
    }
    return array_values(array_filter($list, static fn ($relative) => is_string($relative) && (
        in_array($relative, UPDATER_ALLOWED_MANAGED_PATHS, true)
        || (str_starts_with($relative, UPDATER_PLUGINS_PATH . '/') && preg_match(UPDATER_PLUGIN_DIR_PATTERN, substr($relative, strlen(UPDATER_PLUGINS_PATH) + 1)))
    )));
}

function updater_find_extracted_root(string $extractDir): ?string
{
    $entries = array_values(array_filter(scandir($extractDir) ?: [], static fn ($e) => $e !== '.' && $e !== '..'));
    if (count($entries) === 1 && is_dir($extractDir . '/' . $entries[0])) {
        return $extractDir . '/' . $entries[0];
    }
    return $extractDir;
}

/** $confirmed: vom Admin ausgelöst; ohne Bestätigung nur Releases ohne requiresConfirmation. */
function updater_install(bool $confirmed = false): array
{
    if (!updater_enabled()) {
        return ['ok' => false, 'error' => UPDATER_TEXT['disabled']];
    }
    if (!class_exists('ZipArchive')) {
        return ['ok' => false, 'error' => UPDATER_TEXT['zipMissing']];
    }

    $cache = updater_load_cache();
    if (empty($cache['zipUrl']) || empty($cache['latestVersion'])) {
        return ['ok' => false, 'error' => UPDATER_TEXT['noUpdate']];
    }
    $local = updater_read_local_manifest();
    if (version_compare((string) $cache['latestVersion'], $local['version'], '<=')) {
        return ['ok' => false, 'error' => UPDATER_TEXT['upToDate']];
    }
    // Auch bestätigt nie: Der neue Code liefe auf diesem PHP nicht.
    $tooOld = updater_php_too_old((string) $cache['latestVersion'], (string) $cache['minPhp']);
    if ($tooOld !== null) {
        updater_log_once('install refused: ' . $cache['latestVersion'] . ' requires PHP ' . $cache['minPhp'] . ', running ' . PHP_VERSION);
        return ['ok' => false, 'error' => $tooOld];
    }

    if (empty($cache['opensslSignature'])) {
        updater_log_once('install refused: missing openssl signature for ' . $cache['latestVersion']);
        return ['ok' => false, 'error' => UPDATER_SIGNATURE_INVALID_MESSAGE];
    }
    if (!function_exists('openssl_verify')) {
        return ['ok' => false, 'error' => UPDATER_OPENSSL_MISSING_MESSAGE];
    }

    $lock = updater_acquire_lock();
    if (!$lock) {
        return ['ok' => false, 'error' => UPDATER_TEXT['running']];
    }

    // Läuft im Login-Request: nicht vom Zeitlimit oder einem geschlossenen
    // Browser-Tab mitten im Austausch abbrechen lassen.
    ignore_user_abort(true);
    @set_time_limit(300);

    try {
        $tmpRoot = updater_tmp_root();
        le_rrmdir($tmpRoot);
        ensure_dir($tmpRoot);

        $zipPath = $tmpRoot . '/release.zip';
        if (!updater_http_download($cache['zipUrl'], $zipPath, 120)) {
            return ['ok' => false, 'error' => UPDATER_TEXT['download']];
        }
        if (!updater_signature_valid($zipPath, (string) $cache['opensslSignature'])) {
            updater_log('install refused: invalid signature for ' . $cache['latestVersion']);
            return ['ok' => false, 'error' => UPDATER_SIGNATURE_INVALID_MESSAGE];
        }

        $extractDir = $tmpRoot . '/extracted';
        ensure_dir($extractDir);

        $zip = new ZipArchive();
        if ($zip->open($zipPath) !== true) {
            return ['ok' => false, 'error' => UPDATER_TEXT['zipOpen']];
        }

        for ($i = 0; $i < $zip->numFiles; $i++) {
            $entryName = $zip->getNameIndex($i);
            if (!is_string($entryName) || !zip_entry_name_safe($entryName)) {
                $zip->close();
                return ['ok' => false, 'error' => UPDATER_TEXT['zipPaths']];
            }
        }

        if (!$zip->extractTo($extractDir)) {
            $zip->close();
            return ['ok' => false, 'error' => UPDATER_TEXT['zipExtract']];
        }
        $zip->close();

        $sourceRoot = updater_find_extracted_root($extractDir);
        if (!$sourceRoot || !is_dir($sourceRoot)) {
            return ['ok' => false, 'error' => UPDATER_TEXT['archiveInvalid']];
        }

        $remoteManifestPath = $sourceRoot . '/' . LE_RELEASE_PATH;
        if (!is_file($remoteManifestPath)) {
            return ['ok' => false, 'error' => UPDATER_TEXT['manifestMissing']];
        }
        $remoteManifest = json_decode((string) file_get_contents($remoteManifestPath), true);
        if (!is_array($remoteManifest) || empty($remoteManifest['version'])) {
            return ['ok' => false, 'error' => UPDATER_TEXT['manifestUnreadable']];
        }
        // Der Feed ist nicht signiert: Version und Bestätigungspflicht gelten
        // aus dem signierten Manifest. Sonst spielte ein manipulierter Feed ein
        // altes, gültig signiertes Release ein oder umginge die Bestätigung.
        $remoteVersion = (string) $remoteManifest['version'];
        if ($remoteVersion !== (string) $cache['latestVersion'] || version_compare($remoteVersion, $local['version'], '<=')) {
            updater_log_once('install refused: archive version ' . $remoteVersion . ' does not match feed ' . $cache['latestVersion'] . ' or is not newer than ' . $local['version']);
            return ['ok' => false, 'error' => UPDATER_TEXT['versionMismatch']];
        }
        // Wie die Bestätigungspflicht gilt minPhp aus dem signierten Manifest, auch wenn der Feed es verschweigt.
        $minPhp = (string) ($remoteManifest['minPhp'] ?? '');
        $tooOld = updater_php_too_old($remoteVersion, $minPhp);
        if ($tooOld !== null) {
            $cache['minPhp'] = $minPhp;
            updater_save_cache($cache);
            updater_log_once('install refused: ' . $remoteVersion . ' requires PHP ' . $minPhp . ', running ' . PHP_VERSION);
            return ['ok' => false, 'error' => $tooOld];
        }
        if (!empty($remoteManifest['requiresConfirmation']) && !$confirmed) {
            // Banner zeigen wie bei einem ehrlichen Feed.
            $cache['requiresConfirmation'] = true;
            updater_save_cache($cache);
            updater_log_once('install deferred: ' . $remoteVersion . ' requires confirmation');
            return ['ok' => false, 'error' => UPDATER_TEXT['needsConfirmation']];
        }

        $managedRequested = is_array($remoteManifest['managedPaths'] ?? null)
            ? $remoteManifest['managedPaths']
            : UPDATER_ALLOWED_MANAGED_PATHS;
        $managedPaths = updater_filtered_managed_paths($managedRequested);
        if (empty($managedPaths)) {
            return ['ok' => false, 'error' => UPDATER_TEXT['noPaths']];
        }
        $managedPaths = updater_expand_plugin_paths($sourceRoot, $managedPaths);

        // Das neue Backup entsteht erst neben dem alten: Scheitert der Tausch,
        // bleibt das bisherige Backup und damit der Rollback erhalten.
        $stagedBackup = $tmpRoot . '/backup';
        ensure_dir($stagedBackup);

        $swap = updater_swap_paths($sourceRoot, $managedPaths, $stagedBackup);
        if (!$swap['ok']) {
            // Nicht alles zurückgelegt: Die Reste liegen im neuen Backup, der
            // Rollback in den Einstellungen legt sie zurück.
            if ($swap['incomplete'] !== []) {
                updater_save_backup_paths($stagedBackup, $swap['incomplete']);
                if (!updater_replace_path($stagedBackup, updater_backup_root())) {
                    updater_log('could not keep backup of failed update in ' . $stagedBackup);
                }
            }
            return ['ok' => false, 'error' => $swap['error']];
        }
        $swappedPaths = $swap['swapped'];

        updater_forget_compiled($swappedPaths);
        updater_save_backup_paths($stagedBackup, $swappedPaths);
        if (!updater_replace_path($stagedBackup, updater_backup_root())) {
            updater_log('could not replace update backup, rollback restores the version before the previous update');
        }

        $cache['lastError'] = null;
        $cache['skippedVersion'] = null;
        $cache['failedVersion'] = null;
        $cache['lastCheck'] = current_iso_time();
        updater_save_cache($cache);

        le_rrmdir($tmpRoot);

        updater_log(sprintf(
            'installed %s -> %s (paths: %s)',
            $local['version'],
            (string) $remoteManifest['version'],
            implode(',', $swappedPaths)
        ));

        return [
            'ok' => true,
            'previousVersion' => $local['version'],
            'newVersion' => (string) $remoteManifest['version'],
            'swappedPaths' => $swappedPaths,
        ];
    } finally {
        updater_release_lock($lock);
    }
}

/**
 * Tauscht die verwalteten Pfade gegen die aus dem Release. Scheitert ein
 * Schritt, wird alles bisher Getauschte zurückgelegt; 'incomplete' nennt, was
 * dabei nicht zurück konnte.
 */
function updater_swap_paths(string $sourceRoot, array $managedPaths, string $backupRoot): array
{
    $swappedPaths = [];
    foreach ($managedPaths as $relative) {
        $source = $sourceRoot . '/' . $relative;
        $target = LE_ROOT . '/' . $relative;
        if (!file_exists($source)) {
            continue;
        }

        if (file_exists($target)) {
            $backup = $backupRoot . '/' . $relative;
            ensure_dir(dirname($backup));
            if (!@rename($target, $backup)) {
                $incomplete = updater_rollback_internal($swappedPaths, $backupRoot);
                return ['ok' => false, 'error' => sprintf(UPDATER_TEXT['backupFailed'], $relative), 'incomplete' => $incomplete];
            }
        }
        // Ab hier gilt der Pfad als angefasst: scheitert der Tausch, muss
        // der Rollback auch dieses Backup zurücklegen.
        $swappedPaths[] = $relative;

        ensure_dir(dirname($target));
        if (!@rename($source, $target)) {
            $incomplete = updater_rollback_internal($swappedPaths, $backupRoot);
            return ['ok' => false, 'error' => sprintf(UPDATER_TEXT['swapFailed'], $relative), 'incomplete' => $incomplete];
        }
    }

    return ['ok' => true, 'swapped' => $swappedPaths];
}

/**
 * Setzt $from an die Stelle von $to, ohne $to vorher zu löschen: $to wird erst
 * beiseite benannt und nur gelöscht, wenn $from an seinem Platz liegt, sonst
 * kommt es zurück. $from null: $to nur entfernen. false, wenn $to unverändert ist.
 */
function updater_replace_path(?string $from, string $to): bool
{
    $aside = null;
    if (file_exists($to) || is_link($to)) {
        $aside = updater_tmp_root() . '/discard-' . bin2hex(random_bytes(4));
        ensure_dir(updater_tmp_root());
        if (!@rename($to, $aside)) {
            return false;
        }
    }
    if ($from !== null) {
        ensure_dir(dirname($to));
        if (!@rename($from, $to)) {
            if ($aside !== null && !@rename($aside, $to)) {
                updater_log('could not put back ' . $to . ' from ' . $aside);
            }
            return false;
        }
    }
    if ($aside !== null && !le_rrmdir($aside)) {
        updater_log('could not delete ' . $aside);
    }
    return true;
}

/**
 * Legt die Backups der Pfade zurück; Pfade ohne Backup gab es vorher nicht und
 * werden entfernt. Läuft bei einem Fehler weiter und liefert die Pfade, die
 * nicht zurückgelegt sind (ihr Backup bleibt liegen).
 */
function updater_rollback_internal(array $swappedPaths, string $backupRoot): array
{
    $failed = [];
    foreach (array_reverse($swappedPaths) as $relative) {
        $backup = $backupRoot . '/' . $relative;
        if (!updater_replace_path(file_exists($backup) ? $backup : null, LE_ROOT . '/' . $relative)) {
            $failed[] = $relative;
        }
    }
    updater_forget_compiled($swappedPaths);
    if ($failed !== []) {
        updater_log('rollback incomplete: ' . implode(',', $failed));
    }
    return array_reverse($failed);
}

/**
 * Nach dem Tausch von Code (Update, Rollback): OPcache vergisst die PHP-Dateien der verwalteten
 * Pfade, sonst liefe bei opcache.validate_timestamps=0 der alte Code weiter (forget_compiled_tree).
 */
function updater_forget_compiled(array $relatives): void
{
    foreach ($relatives as $relative) {
        forget_compiled_tree(LE_ROOT . '/' . $relative);
    }
}

function updater_rollback(): array
{
    if (le_instance_is_multi()) {
        return ['ok' => false, 'error' => UPDATER_TEXT['disabled']];
    }
    $backupRoot = updater_backup_root();
    if (!is_dir($backupRoot)) {
        return ['ok' => false, 'error' => UPDATER_TEXT['noBackup']];
    }

    $lock = updater_acquire_lock();
    if (!$lock) {
        return ['ok' => false, 'error' => UPDATER_TEXT['busy']];
    }

    try {
        $rolledBackFrom = updater_read_local_manifest()['version'];
        // Scheitert ein Pfad, laufen die übrigen weiter; das Backup bleibt für
        // einen zweiten Versuch liegen, der nur noch die Reste zurücklegt.
        $failed = updater_rollback_internal(updater_backup_paths($backupRoot), $backupRoot);
        if ($failed === []) {
            le_rrmdir($backupRoot);
        } else {
            updater_save_backup_paths($backupRoot, $failed);
        }

        $local = updater_read_local_manifest();
        $cache = updater_load_cache();
        $cache['lastCheck'] = current_iso_time();
        // Beim zweiten Versuch nach einem Teil-Rollback ist backend/ meist schon zurück.
        if ($rolledBackFrom !== $local['version']) {
            $cache['skippedVersion'] = $rolledBackFrom;
        }
        updater_save_cache($cache);

        if ($failed !== []) {
            return ['ok' => false, 'error' => sprintf(UPDATER_TEXT['rollbackFailed'], implode(', ', $failed))];
        }
        updater_log('rollback to ' . $local['version']);
        return ['ok' => true, 'currentVersion' => $local['version']];
    } finally {
        updater_release_lock($lock);
    }
}
