<?php
declare(strict_types=1);

// Sicherung einspielen (ops/tools/sites.php new --backup): Inhalt prüfen, Dateien tauschen, bei Fehler zurück.

require_once LE_BACKEND . '/backup/siteBackup.php';
require_once LE_BACKEND . '/backup/siteBackupFormat.php';
require_once LE_BACKEND . '/base/files.php';

// Sicherungen aus dem früheren Aufbau (bis 0.x: content/ und public/site/ statt private/ und public/) spielt das Einspielen
// in die heutigen Ordner ein; erkennbar an content/, das es in einer heutigen Sicherung nicht gibt. Kann weg, sobald keine
// solche Sicherung mehr aufbewahrt wird (ops/tools/backup-pull.php: BACKUP_PULL_KEEP_MONTHLY_DAYS, rund 15 Monate).
const LE_SITE_BACKUP_LEGACY_PRIVATE = 'content/';
const LE_SITE_BACKUP_LEGACY_PUBLIC = 'public/site/';
// Unterordner des Arbeitsordners, in den eine solche Sicherung zuerst unter ihren alten Namen entpackt wird.
const LE_SITE_BACKUP_LEGACY_UNPACK = 'alter-aufbau';

// Einspielen (le_site_backup_restore): Arbeitsordner im Kundenordner, von dort kommen die fertigen Ordner per rename an ihren Platz.
const LE_SITE_BACKUP_RESTORE_TMP_PREFIX = '.backup-restore-';
// Meldungen von le_site_backup_restore() (ops/tools/sites.php gibt sie aus); nie mit Server-Pfaden.
const LE_SITE_BACKUP_RESTORE_TEXT = [
    // %s: Daten-Ordner wie content
    'notEmpty' => '%s/ ist nicht leer, eine Sicherung kommt nur in eine neue Website',
    'open' => 'ZIP ließ sich nicht öffnen',
    // %d: gebraucht, frei, Reserve (MB)
    'space' => 'Zu wenig freier Speicher: Die Sicherung braucht %d MB, frei sind %d MB, davon bleiben %d MB frei',
    'failed' => 'Die Sicherung ließ sich nicht einspielen, die Website bleibt leer',
    // %s: Eintrag bzw. Daten-Ordner
    'rights' => '%s: Rechte ließen sich nicht setzen',
    'root' => '%s/ ließ sich nicht einspielen',
    // %s: Liste der Reste (relativ)
    'leftover' => 'Die Sicherung ließ sich nicht einspielen, bitte von Hand entfernen: %s',
];

/** Ob unter $dir eine Datei liegt (leere Ordner zählen nicht); $skip: absolute Pfade, die nicht zählen. */
function le_site_backup_has_files(string $dir, array $skip = []): bool
{
    if (!is_dir($dir) || is_link($dir)) {
        return file_exists($dir) || is_link($dir);
    }
    foreach (scandir($dir) ?: [] as $entry) {
        $path = $dir . '/' . $entry;
        if ($entry !== '.' && $entry !== '..' && !in_array($path, $skip, true) && le_site_backup_has_files($path, $skip)) {
            return true;
        }
    }
    return false;
}

/**
 * Alte Präfixe => heutige Ordner (relativ zur Website), wenn die Einträge $paths einer Sicherung aus dem früheren Aufbau
 * stammen (LE_SITE_BACKUP_LEGACY_PRIVATE kommt vor); sonst [].
 */
function le_site_backup_legacy_prefixes(array $paths): array
{
    foreach ($paths as $path) {
        if (str_starts_with($path, LE_SITE_BACKUP_LEGACY_PRIVATE)) {
            return [LE_SITE_BACKUP_LEGACY_PRIVATE => le_instance_relative(CONTENT_ROOT) . '/', LE_SITE_BACKUP_LEGACY_PUBLIC => le_instance_relative(LE_SITE_ROOT) . '/'];
        }
    }
    return [];
}

/** Eintrag $path einer Sicherung unter dem heutigen Namen (erstes passendes Präfix aus $prefixes ersetzt). */
function le_site_backup_current_path(string $path, array $prefixes): string
{
    foreach ($prefixes as $old => $new) {
        if (str_starts_with($path, $old)) {
            return $new . substr($path, strlen($old));
        }
    }
    return $path;
}

/** Wird der ZIP-Eintrag $path beim Einspielen übernommen? Nur Dateien in den Daten-Ordnern, ohne SITE_BACKUP_EXCLUDED. */
function le_site_backup_restorable(string $path): bool
{
    $roots = array_map('le_instance_relative', LE_SITE_BACKUP_DATA_ROOTS);
    return le_path_in($path, $roots) && !in_array($path, $roots, true)
        && !le_path_in($path, array_map('le_instance_relative', SITE_BACKUP_EXCLUDED));
}

/**
 * Sicherung $zipPath in die Website dieses Prozesses einspielen (LE_INSTANCE_ROOT), z. B. die einer
 * Einzelinstallation in einen neuen Kundenordner (ops/tools/sites.php new --backup, als PHP-Benutzer mit
 * LEBUILD_SITE). Nur in eine frische Website: Liegt unter private/ oder public/ (samt Uploads) schon
 * eine Datei (außer in SITE_BACKUP_EXCLUDED, z. B. Sessions eines Vorschau-Aufrufs), bricht es ab; deshalb ohne
 * Seitensperre.
 *
 * Zuerst wird das ZIP ganz geprüft (le_site_backup_verify_zip: Manifest, Prüfsummen, keine Pfade mit „..“) und
 * der Platz (neben LE_SITE_BACKUP_FREE_RESERVE). Eingespielt wird nur, was site_backup_files() hier sichern würde
 * (le_site_backup_restorable); plugins/ (Code), database/ (MySQL-Export, backend/backup/restore-mysql.php) und alles
 * andere wird übersprungen. Eine Sicherung aus dem früheren Aufbau (content/, public/site/) landet in den heutigen
 * Ordnern (le_site_backup_legacy_prefixes). Danach le_site_backup_restore_files(): ganz oder gar nicht. Rechte nach dem Ziel:
 * LE_PRIVATE_DATA bekommt PRIVATE_FILE_MODE, alles andere le_new_file_mode() wie neue Dateien (write_file_atomic),
 * auch wenn die Sicherung 0600 trägt (ältere Fassungen legten jede neue Datei so an).
 * Liefert ['restored' => Anzahl Dateien, 'skipped' => [Einträge], 'driver' => …, 'version' => …];
 * jeder Fehler als SiteBackupException (Meldungen aus LE_SITE_BACKUP_RESTORE_TEXT, ohne Server-Pfade).
 * $free: freier Platz in Byte statt disk_free_space() (nur Tests).
 */
function le_site_backup_restore(string $zipPath, ?float $free = null): array
{
    if (!class_exists('ZipArchive')) {
        throw new SiteBackupException(SITE_BACKUP_ZIP_MISSING_MESSAGE);
    }
    foreach (LE_SITE_BACKUP_DATA_ROOTS as $root) {
        if (le_site_backup_has_files($root, SITE_BACKUP_EXCLUDED)) {
            throw new SiteBackupException(sprintf(LE_SITE_BACKUP_RESTORE_TEXT['notEmpty'], le_instance_relative($root)));
        }
    }

    $zip = new ZipArchive();
    if ($zip->open($zipPath) !== true) {
        throw new SiteBackupException(LE_SITE_BACKUP_RESTORE_TEXT['open']);
    }
    try {
        try {
            $manifest = le_site_backup_verify_zip($zip);
        } catch (RuntimeException $e) {
            throw new SiteBackupException($e->getMessage());
        }
        $restore = [];
        $skipped = [];
        $bytes = 0;
        $prefixes = le_site_backup_legacy_prefixes(array_column($manifest['files'], 'path'));
        foreach ($manifest['files'] as $file) {
            $current = le_site_backup_current_path($file['path'], $prefixes);
            if (le_site_backup_restorable($current)) {
                $restore[$file['path']] = $current;
                $bytes += $file['size'];
            } else {
                $skipped[] = $file['path'];
            }
        }
        $free ??= @disk_free_space(LE_INSTANCE_ROOT);
        if ($free !== false && $bytes > $free - LE_SITE_BACKUP_FREE_RESERVE) {
            throw new SiteBackupException(sprintf(LE_SITE_BACKUP_RESTORE_TEXT['space'], (int) ceil($bytes / 1048576), (int) floor(max(0, $free) / 1048576), LE_SITE_BACKUP_FREE_RESERVE / 1048576));
        }
        le_site_backup_restore_files($zip, $restore);
        return ['restored' => count($restore), 'skipped' => $skipped, 'driver' => $manifest['driver'] ?? null, 'version' => $manifest['version'] ?? null];
    } finally {
        $zip->close();
    }
}

/**
 * Entpackt $names (Eintrag im ZIP => heutiger Pfad, le_site_backup_current_path) aus $zip in einen Arbeitsordner im
 * Kundenordner und setzt die Daten-Ordner per rename an ihren Platz (vorher leer oder fehlend). Einträge unter altem
 * Namen entpackt es erst nach LE_SITE_BACKUP_LEGACY_UNPACK und legt sie dann unter dem heutigen Namen ab. Scheitert etwas, nimmt le_site_backup_restore_undo() alles zurück; bleibt dabei
 * etwas liegen, nennt die Meldung es (relativ).
 */
function le_site_backup_restore_files(ZipArchive $zip, array $names): void
{
    $tmp = LE_INSTANCE_ROOT . '/' . LE_SITE_BACKUP_RESTORE_TMP_PREFIX . bin2hex(random_bytes(8));
    // Ziel => gab es vorher (als leeren Ordner); $placed: schon per rename eingesetzt.
    $touched = [];
    $placed = [];
    try {
        ensure_dir($tmp);
        $renamed = array_filter($names, static fn (string $current, int|string $entry): bool => $current !== (string) $entry, ARRAY_FILTER_USE_BOTH);
        $unpack = $renamed === [] ? $tmp : $tmp . '/' . LE_SITE_BACKUP_LEGACY_UNPACK;
        if ($names !== [] && !$zip->extractTo($unpack, array_keys($names))) {
            throw new SiteBackupException(LE_SITE_BACKUP_RESTORE_TEXT['failed']);
        }
        // Alter Aufbau: jeden Eintrag an seinen heutigen Platz, auch die, deren Name gleich bleibt.
        foreach ($renamed === [] ? [] : $names as $entry => $current) {
            ensure_dir(str_ends_with($current, '/') ? $tmp . '/' . $current : dirname($tmp . '/' . $current));
            if (!str_ends_with($current, '/') && !@rename($unpack . '/' . $entry, $tmp . '/' . $current)) {
                throw new SiteBackupException(LE_SITE_BACKUP_RESTORE_TEXT['failed']);
            }
        }
        if ($renamed !== [] && !le_rrmdir($unpack)) {
            throw new SiteBackupException(LE_SITE_BACKUP_RESTORE_TEXT['failed']);
        }
        // Rechte nach dem Ziel, nicht nach der Sicherung: Ältere Fassungen legten jede neue Datei mit 0600 an. Ein
        // Ordner-Eintrag („private/leer/“, nur in fremden ZIPs) behält die Rechte, mit denen extractTo ihn angelegt hat,
        // wie die übrigen Ordner (mit x, setgid vom Elternordner).
        foreach ($names as $path) {
            if (str_ends_with($path, '/')) {
                continue;
            }
            if (!@chmod($tmp . '/' . $path, le_private_data(LE_INSTANCE_ROOT . '/' . $path) ? PRIVATE_FILE_MODE : le_new_file_mode())) {
                throw new SiteBackupException(sprintf(LE_SITE_BACKUP_RESTORE_TEXT['rights'], $path));
            }
        }
        foreach (LE_SITE_BACKUP_DATA_ROOTS as $target) {
            $root = le_instance_relative($target);
            if (!is_dir($tmp . '/' . $root)) {
                continue;
            }
            $touched[$target] = is_dir($target);
            ensure_dir(dirname($target));
            if (!le_rrmdir($target) || !@rename($tmp . '/' . $root, $target)) {
                throw new SiteBackupException(sprintf(LE_SITE_BACKUP_RESTORE_TEXT['root'], $root));
            }
            $placed[$target] = true;
        }
    } catch (Throwable $e) {
        error_log('site backup restore: ' . $e->getMessage());
        $left = le_site_backup_restore_undo($touched, $placed, $tmp);
        if ($left !== []) {
            throw new SiteBackupException(sprintf(LE_SITE_BACKUP_RESTORE_TEXT['leftover'], implode(', ', $left)), 0, $e);
        }
        throw $e instanceof SiteBackupException ? $e : new SiteBackupException(LE_SITE_BACKUP_RESTORE_TEXT['failed'], 0, $e);
    }
    // Übrig sind nur leere Ordner (z. B. public/ des Arbeitsordners).
    if (!le_rrmdir($tmp)) {
        error_log('site backup restore: ' . le_instance_relative($tmp) . ' left behind');
    }
}

/**
 * Rücknahme von le_site_backup_restore_files(): eingesetzte Ordner ($placed) wieder entfernen, Ordner, die es vorher
 * gab ($touched => true), leer neu anlegen, den Arbeitsordner $tmp wegräumen. Liefert, was liegen blieb (relativ).
 */
function le_site_backup_restore_undo(array $touched, array $placed, string $tmp): array
{
    $left = [];
    foreach ($touched as $target => $existed) {
        $back = !isset($placed[$target]) || le_rrmdir($target);
        try {
            if ($existed) {
                ensure_dir($target);
            }
        } catch (RuntimeException) {
            $back = false;
        }
        if (!$back) {
            $left[] = le_instance_relative($target);
        }
    }
    if (!le_rrmdir($tmp)) {
        $left[] = le_instance_relative($tmp);
    }
    return $left;
}
