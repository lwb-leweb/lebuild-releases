<?php
declare(strict_types=1);

// Spielt die Plugin-Tabellen einer MySQL-Sicherung (database/schema.json und
// database/<tabelle>.jsonl) in die Datenbank dieser Installation ein. Auf der
// Kunden-Installation, nachdem die Sicherung entpackt ist (siehe
// knowledgebase/backup.md):
//   php backend/backup/restore-mysql.php [ordner mit database/, Standard: Installation]
// Legt fehlende Tabellen per install-Datei an, übernimmt Zeilen samt id und
// den id-Zähler. Enthält eine Zieltabelle schon Zeilen, bricht es vorher ab.

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

// Einstieg im Backend, damit jede Installation das Skript in der Version ihres Kerns hat (ops/ ist nicht im Release).
require_once __DIR__ . '/../base/paths.php';
require_once LE_BACKEND . '/database/migration.php';
require_once LE_BACKEND . '/backup/siteBackupFormat.php';

/**
 * Tabellen aus schema.json, geprüft gegen die installierten Plugins
 * (private/active-plugins.json aus der Sicherung): [Tabelle => ['columns', 'nextId']].
 */
function backup_restore_schema(string $dir, array $plugins): array
{
    $schema = json_decode((string) @file_get_contents($dir . '/' . SITE_BACKUP_DB_SCHEMA), true);
    if (!is_array($schema)) {
        throw new RuntimeException($dir . '/' . SITE_BACKUP_DB_SCHEMA . ' fehlt oder ist ungültig');
    }
    $expected = array_merge(...array_values($plugins));
    $unknown = array_diff(array_keys($schema), $expected);
    if ($unknown) {
        throw new RuntimeException('Tabellen ohne installiertes Plugin: ' . implode(', ', $unknown));
    }
    $tables = [];
    foreach ($expected as $table) {
        $entry = $schema[$table] ?? null;
        $columns = is_array($entry) ? ($entry['columns'] ?? null) : null;
        // next_id berücksichtigt den Zähler der Quelle (gelöschte Zeilen am Ende).
        $nextId = is_array($entry) ? ($entry['next_id'] ?? null) : null;
        if (!is_array($columns) || array_filter($columns, 'is_string') !== $columns || !is_int($nextId)) {
            throw new RuntimeException('Tabelle ' . $table . ' fehlt in ' . SITE_BACKUP_DB_SCHEMA . ' oder ist ungültig');
        }
        if (!is_file($dir . '/' . $table . SITE_BACKUP_DB_ROWS_SUFFIX)) {
            throw new RuntimeException('Datei ' . $table . SITE_BACKUP_DB_ROWS_SUFFIX . ' fehlt');
        }
        $tables[$table] = ['columns' => $columns, 'nextId' => $nextId];
    }
    return $tables;
}

/** Zeilen einer .jsonl-Datei blockweise einfügen; liefert die Zahl der Zeilen. */
function backup_restore_table(PDO $pdo, string $dir, string $table, array $columns): int
{
    $insert = db_migration_inserter($pdo, $table, $columns);
    $fh = fopen($dir . '/' . $table . SITE_BACKUP_DB_ROWS_SUFFIX, 'rb');
    $rows = [];
    $count = 0;
    $line = 0;
    while (($json = fgets($fh)) !== false) {
        $line++;
        if (trim($json) === '') {
            continue;
        }
        $row = json_decode($json, true);
        if (!is_array($row) || count($row) !== count($columns) || array_diff($columns, array_keys($row))) {
            fclose($fh);
            throw new RuntimeException("Zeile {$line} in {$table}" . SITE_BACKUP_DB_ROWS_SUFFIX . ' passt nicht zu den Spalten');
        }
        $rows[] = array_map(static fn (string $column) => $row[$column], $columns);
        if (count($rows) === DB_MIGRATION_BATCH) {
            $insert($rows);
            $count += count($rows);
            $rows = [];
        }
    }
    fclose($fh);
    if ($rows) {
        $insert($rows);
        $count += count($rows);
    }
    $stored = (int) $pdo->query("SELECT COUNT(*) FROM `{$table}`")->fetchColumn();
    if ($stored !== $count) {
        throw new RuntimeException("Zeilenzahl in {$table} weicht ab ({$stored} statt {$count})");
    }
    return $count;
}

/** Ganzer Lauf; Rückgabe ist der Exit-Code. */
function backup_restore_main(array $argv): int
{
    $dir = rtrim($argv[1] ?? LE_INSTANCE_ROOT, '/') . '/' . SITE_BACKUP_DB_DIR;
    $plugins = db_migration_plugins();
    if (!$plugins) {
        // Nur „nichts zu tun“, wenn auch die Sicherung keine Tabellen hat (kein database/ wie bei SQLite, oder ein
        // leeres schema.json); sonst sähe ein Restore ohne Wirkung erfolgreich aus.
        if (is_dir($dir)) {
            $schema = json_decode((string) @file_get_contents($dir . '/' . SITE_BACKUP_DB_SCHEMA), true);
            if (!is_array($schema)) {
                echo 'FEHLER: ' . $dir . '/' . SITE_BACKUP_DB_SCHEMA . " fehlt oder ist ungültig\n";
                return 1;
            }
            if ($schema !== []) {
                echo 'FEHLER: Tabellen ohne installiertes Plugin: ' . implode(', ', array_keys($schema)) . "\n";
                return 1;
            }
        }
        echo "Keine installierten Plugins mit Tabellen, nichts einzuspielen.\n";
        return 0;
    }

    $created = [];
    $filled = [];
    try {
        $tables = backup_restore_schema($dir, $plugins);
        $driver = db_driver();
        $error = db_migration_check_schemas($driver, $plugins);
        if ($error !== null) {
            throw new RuntimeException($error['message']);
        }
        $pdo = db();
        foreach (array_keys($tables) as $table) {
            if (db_table_exists($pdo, $table) && $pdo->query("SELECT 1 FROM `{$table}` LIMIT 1")->fetchColumn() !== false) {
                throw new RuntimeException("Tabelle {$table} enthält schon Zeilen. Abbruch, nichts verändert.");
            }
        }

        foreach ($plugins as $name => $pluginTables) {
            // Scheitert die Schema-Datei, räumt db_run_schema ihre Tabellen selbst weg.
            array_push($created, ...le_plugin_create_missing_tables($pdo, $driver, $name, $pluginTables));
            foreach ($pluginTables as $table) {
                $columns = db_migration_columns($pdo, $table);
                $expected = $tables[$table]['columns'];
                if (count($expected) !== count($columns) || array_diff($columns, $expected)) {
                    throw new RuntimeException("Spalten von {$table} passen nicht zur Sicherung (andere Plugin-Version?)");
                }
                $filled[] = $table;
                $count = backup_restore_table($pdo, $dir, $table, $columns);
                db_set_next_id($pdo, $driver, $table, max(db_next_id($pdo, $driver, $table), $tables[$table]['nextId']));
                echo "{$table}: {$count} Zeilen\n";
            }
        }
    } catch (Throwable $e) {
        // Nichts Halbes zurücklassen: angelegte Tabellen weg, vorher leere wieder leeren.
        echo 'FEHLER: ' . $e->getMessage() . "\n";
        try {
            if (isset($pdo)) {
                db_drop_tables($pdo, $created);
                foreach (array_diff($filled, $created) as $table) {
                    $pdo->exec("DELETE FROM `{$table}`");
                }
            }
        } catch (Throwable $cleanup) {
            echo 'Aufräumen fehlgeschlagen, Tabellen ' . implode(', ', $filled) . ' von Hand leeren: ' . $cleanup->getMessage() . "\n";
        }
        return 1;
    }
    $real = realpath($dir);
    if ($real !== false && $real !== LE_INSTANCE_ROOT && le_path_in($real, [LE_INSTANCE_ROOT])) {
        echo "Fertig. {$dir} liegt im Ordner der Website und enthält Kundendaten: jetzt löschen.\n";
    } else {
        echo "Fertig.\n";
    }
    return 0;
}

if (get_included_files()[0] === __FILE__) {
    exit(backup_restore_main($argv));
}
