<?php
declare(strict_types=1);

// Health-Check für Uptime-Monitore (api/health.php): Kann die Installation ihre Arbeit tun?
// Geprüft wird Echtes in klein: private/ und den Ordner der Website beschreiben, die Startseite rendern wie
// der Router, die Plugin-Datenbank abfragen. Öffentlich nur status und checkedAt, die
// Einzelprüfungen nur mit dem Token (LEBUILD_HEALTH_TOKEN bzw. health.config.php).

require_once LE_BACKEND . '/plugins/plugins.php';
require_once LE_BACKEND . '/plugins/render.php';
require_once LE_BACKEND . '/users/users.php';
require_once LE_BACKEND . '/base/http.php';

const LE_HEALTH_TOKEN_ENV = 'LEBUILD_HEALTH_TOKEN';
const LE_HEALTH_CONFIG_FILE = 'health.config.php';
// So lange gilt ein Ergebnis; Monitore fragen seltener, eine Abfrage-Flut kostet so nur einen Lauf.
const LE_HEALTH_CACHE_SECONDS = 10;
const LE_HEALTH_CACHE_FILE = 'health.json';
const LE_HEALTH_LOCK_FILE = 'health.lock';
// So lange wartet eine Abfrage auf einen laufenden Lauf; hängt der, meldet sie einen Fehler statt mitzuhängen.
// Länger als ein Lauf sein kann: MySQL-Verbindung (DB_MYSQL_CONNECT_TIMEOUT) + Antwort (LE_HEALTH_DB_SECONDS) + Startseite.
const LE_HEALTH_LOCK_SECONDS = 25;
// Lesefrist für MySQL-Verbindungen während der Prüfungen; ohne sie wartet mysqlnd auf einen stummen Server einen Tag.
const LE_HEALTH_DB_SECONDS = 5;
// Meldungen der Einzelprüfungen (nur mit Token sichtbar): nie Pfade oder Texte von Exceptions.
const LE_HEALTH_TEXT = [
    'content' => 'private/ lässt sich nicht lesen oder beschreiben.',
    'site' => 'Der Ordner der Website lässt sich nicht beschreiben, Speichern scheitert.',
    'users' => 'private/users.json ist nicht lesbar, niemand kann sich anmelden.',
    'render' => 'Die Startseite lässt sich nicht rendern.',
    'database' => 'Die Plugin-Datenbank antwortet nicht.',
    'lock' => 'Eine laufende Prüfung wird nicht fertig.',
    'failed' => 'Prüfung fehlgeschlagen.',
];

/** Prüfungen nach Name: jede liefert null (in Ordnung) oder eine Meldung aus LE_HEALTH_TEXT. */
function le_health_checks(): array
{
    $checks = [
        'content' => 'le_health_check_content',
        'site' => 'le_health_check_site',
        'render' => 'le_health_check_render',
    ];
    // Die Datenbank nur, wenn ein aktives Plugin Tabellen hat; sonst braucht sie niemand.
    $table = le_health_database_table();
    if ($table !== null) {
        $checks['database'] = static fn (): ?string => le_health_check_database($table);
    }
    return $checks;
}

/** private/ schreiben und zurücklesen (Wegwerf-Datei im Cache), users.json muss für users_load() taugen. */
function le_health_check_content(): ?string
{
    ensure_dir(CACHE_ROOT);
    if (!le_health_probe(CACHE_ROOT)) {
        return LE_HEALTH_TEXT['content'];
    }
    if (!empty(users_load()['broken'])) {
        return LE_HEALTH_TEXT['users'];
    }
    return null;
}

/** Ordner der Website beschreiben: Dorthin schreibt jedes Speichern (write_file_atomic). */
function le_health_check_site(): ?string
{
    return is_dir(LE_SITE_ROOT) && le_health_probe(LE_SITE_ROOT) ? null : LE_HEALTH_TEXT['site'];
}

/**
 * Wegwerf-Datei in $dir anlegen, schreiben, zurücklesen und löschen. Name wie die Temp-Dateien von write_file_atomic
 * (Git im Kundenordner übergeht sie); tempnam weicht ohne Schreibrecht auf den Temp-Ordner aus, das zählt als Fehler.
 */
function le_health_probe(string $dir): bool
{
    $probe = @tempnam($dir, 'health-probe' . LE_ATOMIC_TMP_INFIX);
    if ($probe === false) {
        return false;
    }
    $value = bin2hex(random_bytes(8));
    $ok = realpath(dirname($probe)) === realpath($dir)
        && @file_put_contents($probe, $value, LOCK_EX) === strlen($value)
        && @file_get_contents($probe) === $value;
    @unlink($probe);
    return $ok;
}

/** Startseite wie der Router (Seite, Shortcodes, Plugin-Filter); das Ergebnis muss ein HTML-Dokument sein. */
function le_health_check_render(): ?string
{
    // Dieselbe Datei wie der Router für „/“ (auch kein Link nach außen).
    $file = le_site_request_file('/');
    if ($file === null) {
        return LE_HEALTH_TEXT['render'];
    }
    if (str_ends_with($file, '.php')) {
        // Was das PHP der Website auf einer Besucherseite vorfindet, dieselbe Liste wie render.php.
        require_once LE_BACKEND . '/site/sitePhp.php';
        $level = ob_get_level();
        ob_start();
        try {
            le_plugins_load_public();
            (static function (string $__file): void {
                require $__file;
            })($file);
            // Puffer, die die Seite selbst geöffnet hat, gehören zur Ausgabe.
            while (ob_get_level() > $level + 1) {
                ob_end_flush();
            }
            $html = (string) ob_get_clean();
        } finally {
            while (ob_get_level() > $level) {
                ob_end_clean();
            }
            // Was die Seite an Headern gesetzt hat (Cookies, Weiterleitung, Status), gehört nicht in die Antwort.
            header_remove();
            http_response_code(200);
        }
    } else {
        $html = (string) file_get_contents($file);
    }
    $html = filter_site_html(render_shortcodes_in_html($html));
    return preg_match('/<(html|body)[\s>]/i', $html) === 1 ? null : LE_HEALTH_TEXT['render'];
}

/** Erste Tabelle eines aktiven Plugins (laut plugins.json), null ohne solche Plugins. */
function le_health_database_table(): ?string
{
    $state = load_plugins_state();
    foreach ($state['active'] as $name) {
        $tables = $state['installed'][$name]['tables'] ?? [];
        if ($tables !== []) {
            return $tables[0];
        }
    }
    return null;
}

/** SELECT 1 und eine Abfrage auf eine Tabelle, die ein Plugin wirklich nutzt. */
function le_health_check_database(string $table): ?string
{
    if (!plugin_table_name_valid($table)) {
        return LE_HEALTH_TEXT['database'];
    }
    $pdo = db();
    if ((int) $pdo->query('SELECT 1')->fetchColumn() !== 1) {
        return LE_HEALTH_TEXT['database'];
    }
    $pdo->query('SELECT 1 FROM ' . $table . ' LIMIT 1')->fetchAll();
    return null;
}

/**
 * Führt die Prüfungen aus: status ok/error, je Prüfung name, ok, ggf. error, durationMs.
 * Beendet eine Prüfung den Prozess (exit der Startseite, z. B. Sprachweiche per Location, oder ein
 * Fatal Error), läuft nichts danach und kein finally. Dann übernimmt die Shutdown-Funktion: Sie
 * verwirft Ausgabe und Header der Seite, zählt die Prüfung als Fehler, führt die übrigen aus und
 * gibt den Bericht an $onExit (antwortet mit JSON), sonst bekäme der Monitor HTML oder 302.
 */
function le_health_run(array $checks, ?callable $onExit = null): array
{
    $state = ['results' => [], 'current' => null, 'started' => 0.0, 'done' => false];
    $level = ob_get_level();
    register_shutdown_function(static function () use (&$state, $checks, $level, $onExit): void {
        if ($state['done'] || $state['current'] === null) {
            return;
        }
        while (ob_get_level() > $level) {
            ob_end_clean();
        }
        if (!headers_sent()) {
            header_remove();
            // Nach einem Fatal Error steht schon „500“ als Statuszeile; die räumt nur header() mit Code weg,
            // http_response_code() allein nicht.
            header('Cache-Control: no-store', true, 200);
        }
        $name = $state['current'];
        error_log('health ' . $name . ' ended the request (exit or fatal error)');
        $state['results'][] = le_health_result($name, LE_HEALTH_TEXT[$name] ?? LE_HEALTH_TEXT['failed'], $state['started']);
        $rest = array_slice($checks, array_search($name, array_keys($checks), true) + 1, null, true);
        $report = le_health_finish([...$state['results'], ...le_health_run($rest)['checks']]);
        if ($onExit !== null) {
            $onExit($report);
        }
    });
    // Gilt für jede MySQL-Verbindung, die währenddessen aufgeht (Startseite, Datenbank-Prüfung), auch für den Handshake.
    $readTimeout = ini_set('mysqlnd.net_read_timeout', (string) LE_HEALTH_DB_SECONDS);
    try {
        foreach ($checks as $name => $check) {
            $state['current'] = (string) $name;
            $state['started'] = microtime(true);
            try {
                $error = $check();
            } catch (Throwable $e) {
                error_log('health ' . $name . ' failed: ' . $e->getMessage());
                $error = LE_HEALTH_TEXT[$name] ?? LE_HEALTH_TEXT['failed'];
            }
            $state['results'][] = le_health_result((string) $name, $error, $state['started']);
        }
    } finally {
        if ($readTimeout !== false) {
            ini_set('mysqlnd.net_read_timeout', $readTimeout);
        }
    }
    $state['done'] = true;
    return le_health_finish($state['results']);
}

function le_health_result(string $name, ?string $error, float $started): array
{
    $result = ['name' => $name, 'ok' => $error === null];
    if ($error !== null) {
        $result['error'] = $error;
    }
    $result['durationMs'] = (int) round((microtime(true) - $started) * 1000);
    return $result;
}

function le_health_finish(array $results): array
{
    $failed = array_filter($results, static fn (array $r): bool => !$r['ok']);
    return ['status' => $failed ? 'error' : 'ok', 'checks' => $results, 'checkedAt' => current_iso_time(), 'ageMs' => 0];
}

/**
 * Bericht, höchstens LE_HEALTH_CACHE_SECONDS alt. Gleichzeitige Abfragen warten auf einen Lauf
 * (Sperre) statt je einen zu starten, höchstens LE_HEALTH_LOCK_SECONDS, danach Fehler „lock“. $checks ersetzt die Prüfliste (Tests) und umgeht den Cache.
 * $onExit bekommt den Bericht, wenn eine Prüfung den Prozess beendet hat (le_health_run).
 */
function le_health_report(?array $checks = null, ?callable $onExit = null): array
{
    if ($checks !== null) {
        return le_health_run($checks, $onExit);
    }
    $cacheFile = CACHE_ROOT . '/' . LE_HEALTH_CACHE_FILE;
    $cached = le_health_cached_report($cacheFile);
    if ($cached !== null) {
        return $cached;
    }
    $lock = is_dir(CACHE_ROOT) ? @fopen(CACHE_ROOT . '/' . LE_HEALTH_LOCK_FILE, 'c') : false;
    if ($lock !== false && !le_health_lock($lock)) {
        fclose($lock);
        return le_health_cached_report($cacheFile) ?? le_health_finish([le_health_result('lock', LE_HEALTH_TEXT['lock'], microtime(true))]);
    }
    try {
        // Wer auf die Sperre gewartet hat, nimmt das Ergebnis des Laufs davor.
        $report = le_health_cached_report($cacheFile);
        if ($report !== null) {
            return $report;
        }
        $report = le_health_run(le_health_checks(), static function (array $report) use ($cacheFile, $onExit): void {
            le_health_store_report($cacheFile, $report);
            if ($onExit !== null) {
                $onExit($report);
            }
        });
        le_health_store_report($cacheFile, $report);
    } finally {
        if ($lock !== false) {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }
    return $report;
}

/** Sperre nehmen, aber höchstens LE_HEALTH_LOCK_SECONDS warten. */
function le_health_lock($lock): bool
{
    $deadline = microtime(true) + LE_HEALTH_LOCK_SECONDS;
    while (!flock($lock, LOCK_EX | LOCK_NB)) {
        if (microtime(true) >= $deadline) {
            return false;
        }
        usleep(100000);
    }
    return true;
}

function le_health_store_report(string $cacheFile, array $report): void
{
    // tempnam legt die Datei mit 0600 an, aber nur in einem beschreibbaren Ordner (sonst im Temp-Ordner des Systems).
    if (is_dir(CACHE_ROOT) && is_writable(CACHE_ROOT) && ($tmp = @tempnam(CACHE_ROOT, 'health-'))) {
        if (@file_put_contents($tmp, json_encode($report)) === false || !@rename($tmp, $cacheFile)) {
            @unlink($tmp);
        }
    }
}

function le_health_cached_report(string $cacheFile): ?array
{
    $mtime = is_file($cacheFile) ? @filemtime($cacheFile) : false;
    if ($mtime === false || time() - $mtime >= LE_HEALTH_CACHE_SECONDS) {
        return null;
    }
    $report = json_decode((string) @file_get_contents($cacheFile), true);
    if (!is_array($report) || !isset($report['status'], $report['checks'], $report['checkedAt'])) {
        return null;
    }
    $report['ageMs'] = (time() - $mtime) * 1000;
    return $report;
}

/** Token für die Einzelprüfungen: Env-Variable, sonst private/config/health.config.php (['token' => …]). */
function le_health_token(): ?string
{
    $token = getenv(LE_HEALTH_TOKEN_ENV);
    if (!is_string($token) || trim($token) === '') {
        $path = CONFIG_ROOT . '/' . LE_HEALTH_CONFIG_FILE;
        $config = is_file($path) ? require $path : null;
        $token = is_array($config) ? (string) ($config['token'] ?? '') : '';
    }
    // Getrimmt, damit ein Zeilenende aus Datei oder Panel das Token nicht unbrauchbar macht.
    $token = trim($token);
    return $token !== '' ? $token : null;
}

/** Bearer-Token der Anfrage (le_request_bearer) passt zum Token? Beide Seiten gehasht, damit auch die Länge nicht durchsickert. */
function le_health_authorized(?string $bearer, ?string $token): bool
{
    if ($token === null || $bearer === null) {
        return false;
    }
    return hash_equals(hash('sha256', $token), hash('sha256', $bearer));
}

/** Öffentlich nur status und checkedAt; mit Token der ganze Bericht. */
function le_health_view(array $report, bool $authorized): array
{
    return $authorized ? $report : ['status' => $report['status'], 'checkedAt' => $report['checkedAt']];
}

/** Antwort von api/health.php: 503 bei status error, für alle Aufrufer gleich. */
function le_health_respond(?array $checks = null): void
{
    le_health_send(le_health_report($checks, 'le_health_send'));
}

function le_health_send(array $report): void
{
    json_response(le_health_view($report, le_health_authorized(le_request_bearer(), le_health_token())), $report['status'] === 'error' ? 503 : 200);
}
