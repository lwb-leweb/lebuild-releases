<?php declare(strict_types=1);

// Router für jede Anfrage: Caddy (ops/deploy/routes.caddy), Apache (webroot/.htaccess) und der eingebaute Server
// (`php -S 127.0.0.1:8000 -t webroot webroot/index.php`) schicken alles an webroot/index.php, der zuerst
// backend/base/paths.php und dann diese Datei lädt; sie liefern selbst nichts aus. Der Router entscheidet nach der
// kanonischen Adresse: Endpunkte nur aus api/routes.php, von Plugins nur assets/, admin/ und die Endpunkte aktiver Plugins,
// die Verwaltung aus LE_FRONTEND, reservierte Namen (le_router_reserved_names) sonst nie, alles andere aus der Website.

// Nicht parse_url: Es liest bei //content/x „content“ als Host und schneidet es ab.
$path = explode('?', (string) ($_SERVER['REQUEST_URI'] ?? '/'), 2)[0];
if ($path === '') {
    $path = '/';
}

require_once LE_BACKEND . '/users/auth.php';
require_once LE_BACKEND . '/pages/routes.php';
require_once LE_BACKEND . '/users/setup.php';
require_once LE_BACKEND . '/site/respond.php';
require_once LE_BACKEND . '/base/http.php';
require_once LE_BACKEND . '/base/texts.php';
require_once LE_BACKEND . '/base/utils.php';

// Browser raten den Typ nie, sondern nehmen den Content-Type ernst.
header('X-Content-Type-Options: nosniff');

// Alle Sperren und Zuordnungen unten gelten für die kanonische Schreibweise (le_site_canonical_path), damit
// /./content/x oder /public//site/includes/x nicht an ihnen vorbeikommen; „..“ gibt es nie.
$path = le_site_canonical_path($path);
if ($path === null) {
    return le_respond_not_found();
}
// Versteckte Dateien (.git, .env, .htaccess …) gibt es nicht, außer .well-known. Kodierte Segmente
// (..%2Fx) sind keine Datei auf der Platte, sie prüft die Seitenauflösung (404-Seite der Website).
foreach (explode('/', $path) as $segment) {
    if ($segment !== '' && $segment[0] === '.' && $segment !== '.well-known' && !str_contains($segment, '%')) {
        return le_respond_not_found();
    }
}

// 1. Endpunkte unter /api/: nur, was in api/routes.php steht, und erst nach Methode, Rolle und CSRF (le_api_endpoint).
//    Eingebunden auf oberster Ebene wie bisher beim direkten Aufruf (die Endpunkte sehen ihre Variablen global).
if (str_starts_with($path, LE_API_URL)) {
    $endpoint = le_api_endpoint(substr($path, strlen(LE_API_URL)));
    if ($endpoint === null) {
        return le_respond_not_found();
    }
    require $endpoint;
    return true;
}

// 2. Endpunkte der Plugins (/plugins/<name>/api/<datei>.php): nur aktive Plugins (sonst 404 wie require_plugin_active),
//    davor die Plugin-Schnittstelle und die lib.php des Plugins. Rolle, CSRF und Methode prüft der Endpunkt selbst.
require_once LE_BACKEND . '/plugins/plugins.php';
if (preg_match(LE_PLUGIN_ENDPOINT_PATTERN, $path, $m)) {
    $endpoint = le_plugin_endpoint_file($m[1], $m[2]);
    if ($endpoint === null) {
        return le_respond_not_found();
    }
    require_plugin_active($m[1]);
    le_plugin_load_for_endpoint($m[1]);
    require $endpoint;
    return true;
}

require_once LE_BACKEND . '/site/minify.php';

// 3. Uploads: nie ausführen, SVGs nur in der Sandbox (le_serve_upload_file) – wie die .htaccess in UPLOADS_ROOT, aber
//    ohne mod_headers. Fehlt die Datei (auch ein Link nach außen, le_site_request_file), mit LEBUILD_IMAGES_FROM die
//    Weiterleitung auf die echte Website.
if (preg_match('#^' . preg_quote(UPLOADS_URL, '#') . '([A-Za-z0-9][A-Za-z0-9._-]*)$#', $path, $m)) {
    if (le_site_request_file($path) === UPLOADS_ROOT . '/' . $m[1]) {
        return le_serve_upload_file(UPLOADS_ROOT . '/' . $m[1]);
    }
    // Lokale Kopie ohne die Uploads (nie im Git): das Bild von der echten Website (le_images_from).
    $imagesFrom = le_images_from();
    return $imagesFrom !== null ? le_respond_redirect($imagesFrom . $path) : le_respond_not_found();
}

// 4. Login-Seite (eigene schlanke Seite, kein Admin-SPA). Wer schon angemeldet
//    ist, geht gleich zum Ziel aus ?next= weiter; die Seite lädt nach dem Login
//    neu und landet so ebenfalls hier. Ohne ?next= gilt die Seite dieser Website,
//    von der der Besucher kam (Referer); sie kommt in die Adresse, damit sie das
//    Neuladen nach dem Login übersteht.
if (rtrim($path, '/') === LOGIN_URL) {
    $next = $_GET['next'] ?? referer_path();
    if (signed_in_user() !== null) {
        return le_respond_redirect(safe_redirect_path($next));
    }
    if (!isset($_GET['next']) && $next !== null) {
        return le_respond_redirect(LOGIN_URL . '?next=' . rawurlencode($next));
    }
    header('Cache-Control: no-store');
    le_deny_foreign_framing();
    // Weder Benutzer noch ein brauchbares setup.php: Hinweis statt Formular.
    return le_setup_missing()
        ? le_respond_login_setup(LE_LOGIN_PAGE_FILE)
        : le_serve_static_file(LE_LOGIN_PAGE_FILE);
}

// 5. Verwaltung: /admin und /admin/* zeigen auf LE_FRONTEND. Existiert die angefragte Datei dort (CSS, JS, Bild, Modul,
//    Seiten-Editor, le_code_file), geht sie ohne Anmeldung raus; sonst fällt die Anfrage auf die Shell (LE_ADMIN_SHELL_FILE)
//    zurück, damit Deep-Links wie /admin/settings nach Reload weiter funktionieren. Die Shell bekommen nur Admins.
if (preg_match('#^' . LE_ADMIN_PATH . '(?:/(.*))?$#', $path, $m)) {
    $rel = isset($m[1]) ? trim($m[1], '/') : '';
    $shell = LE_ADMIN_SHELL_FILE;

    if ($rel !== '') {
        if (str_contains($rel, '..') || !preg_match(LE_SITE_PATH_PATTERN, $rel)) {
            return le_respond_not_found();
        }
        $asset = le_code_file(LE_FRONTEND, $rel);
        if ($asset !== null && realpath($asset) !== realpath($shell)) {
            return le_serve_static_file($asset);
        }
    }

    // Ohne Anmeldung zur Login-Seite (danach zurück), Editoren auf die Website.
    if (signed_in_user() === null) {
        return le_respond_redirect(LOGIN_URL . '?next=' . $path);
    }
    if (!is_admin()) {
        return le_respond_redirect(LE_SITE_HOME_URL);
    }
    header('Cache-Control: no-store');
    le_deny_foreign_framing();
    return is_file($shell) ? le_serve_static_file($shell) : le_respond_not_found();
}

// 6. Dateien der Plugins, auch inaktiver: /plugins/<name>/assets/… für die Website mit Browser-Cache wie deren Dateien,
//    /plugins/<name>/admin/… für die Verwaltung ohne (wie /admin). CSS und JS gehen verkleinert raus (backend/site/minify.php).
if (preg_match(LE_PLUGIN_FILE_PATTERN, $path, $m)) {
    $asset = plugin_name_valid($m[1]) ? le_code_file(LE_PLUGINS . '/' . $m[1] . '/' . $m[2], $m[3]) : null;
    if ($asset === null) {
        return le_respond_not_found();
    }
    return le_serve_static_file(le_minified_file($asset) ?? $asset, $m[2] === LE_PLUGIN_SITE_FILES_DIR ? le_static_max_age($asset) : null, $asset);
}

// 7. Reservierte Namen (le_router_reserved_names, groß/klein egal) gehören nie der Website, was oben nicht passt, gibt es
//    nicht (unter /plugins/ also nur, was Schritt 2 und 6 ausliefern); unter /public/ nur /public/site/. Alle anderen
//    ersten Abschnitte (auch /tools, /docs, /content) sind Website. Verglichen wird dekodiert wie in der Seitenauflösung
//    (/%61dmin ist /admin, /%70ublic/site/ ist /public/site/).
$decodedPath = le_site_decoded_path($path) ?? $path;
if (!str_starts_with($decodedPath, LE_SITE_FILES_URL) && in_array(strtolower(explode('/', $decodedPath)[1]), le_router_reserved_names(), true)) {
    return le_respond_not_found();
}

// 8. Site-Dokumente und Site-Assets. URL wird auf /public/site/ gemappt (le_site_request_file):
//    - /                          → /public/site/index.{php,html}
//    - /imprint                   → /public/site/imprint.{php,html} oder .../index.{php,html}
//    - /styles.min.css            → /public/site/styles.min.css
//    - /assets/logos/favicon.png  → /public/site/assets/logos/favicon.png
//    - /public/site/foo.html      → /public/site/foo.html (kanonisch)
//    Ohne Datei fragt der Router die Plugins (Hook site_page, z. B. /<pfad>/<slug> von Content-Typen).
//    Seiten brauchen Shortcodes, Plugins und den Editor (lädt render.php über site/sitePhp.php); Site-PHP nutzt
//    Core-Funktionen (z. B. le_site_config in includes/config.php).
require_once LE_BACKEND . '/site/seo.php';
require_once LE_BACKEND . '/site/indexNow.php';

$file = le_site_request_file($path);

// Seiten haben Adressen ohne Endung und ohne „/“ am Ende: /impressum.php, /impressum/, /public/site/impressum.html
// → 301 auf /impressum (mit Query). Nur GET/HEAD, damit Formulare, die an eine .php posten, weiter ankommen.
$cleanPath = $file !== null && in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', LE_SAFE_METHODS, true) ? le_site_clean_path($path, $file) : null;
if ($cleanPath !== null) {
    $query = (string) ($_SERVER['QUERY_STRING'] ?? '');
    header('Location: ' . $cleanPath . ($query !== '' ? '?' . $query : ''), true, 301);
    return true;
}

// Lokale Kopie: Fotos sind nie im Git (LE_SITE_PHOTO_EXTENSIONS), fehlende kommen von der echten Website (le_images_from).
$imagesFrom = $file === null ? le_images_from() : null;
if ($imagesFrom !== null && preg_match('#^/[A-Za-z0-9._/-]+$#', $path) && in_array(strtolower(pathinfo($path, PATHINFO_EXTENSION)), [...LE_SITE_PHOTO_EXTENSIONS, 'svg'], true)) {
    return le_respond_redirect($imagesFrom . $path);
}

// robots.txt und sitemap.xml erzeugt der Kern (backend/site/seo.php), solange die Website keine eigenen hat.
if ($file === null && $path === LE_SEO_ROBOTS_URL) {
    return le_respond_text(le_seo_robots_txt(), 'text/plain; charset=utf-8');
}
// Schlüssel für IndexNow (backend/site/indexNow.php): Suchmaschinen prüfen damit, dass die Meldungen von der Website kommen.
if ($file === null && preg_match('#^/[0-9a-f]{32}\.txt$#', $path) && $path === le_indexnow_key_path()) {
    return le_respond_text(le_indexnow_key(), 'text/plain; charset=utf-8');
}
if ($file === null && $path === LE_SEO_SITEMAP_URL) {
    $sitemap = le_seo_sitemap_xml();
    return $sitemap !== null ? le_respond_text($sitemap, 'application/xml; charset=utf-8') : le_respond_not_found();
}

require LE_BACKEND . '/site/render.php';


/**
 * Datei des Endpunkts zur Adresse $address (unter LE_API_URL, mit .php) laut LE_API_ROUTES_FILE; null ohne Eintrag.
 * Vorher in fester Reihenfolge: Methode (405 mit Allow), Rolle (le_require_role: 401/403), CSRF (403); jede Prüfung bricht ab.
 */
function le_api_endpoint(string $address): ?string
{
    $routes = require LE_API_ROUTES_FILE;
    $key = str_ends_with($address, '.php') ? substr($address, 0, -strlen('.php')) : null;
    $route = $key !== null ? ($routes[$key] ?? null) : null;
    if ($route === null) {
        return null;
    }
    $method = (string) ($_SERVER['REQUEST_METHOD'] ?? 'GET');
    if (!in_array($method, $route['methods'], true)) {
        header('Allow: ' . implode(', ', $route['methods']));
        json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
    }
    le_require_role($route['role']);
    if ($route['csrf'] && !in_array($method, LE_SAFE_METHODS, true)) {
        require_csrf();
    }

    return LE_API . '/' . $route['file'];
}
