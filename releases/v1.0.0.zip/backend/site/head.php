<?php
declare(strict_types=1);

// Kopf und Rahmen der Seiten der Website: <base>, Titel und Tags im <head>, Rahmen der Startseite, 404-Seite, Links mit Fragment.

require_once LE_BACKEND . '/base/http.php';
require_once LE_BACKEND . '/base/siteConfig.php';
require_once LE_BACKEND . '/html/markup.php';
require_once LE_BACKEND . '/pages/routes.php';

// Website-Adresse aus den Einstellungen (le_site_config, Schlüssel url): http(s), Host, optional Port und Pfad.
const LE_SITE_BASE_URL_PATTERN = '#^https?://[A-Za-z0-9.-]+(?::\d+)?(?:/[A-Za-z0-9._~/-]*)?$#';

// Seite im Rahmen der Startseite (le_site_page_frame): der Inhalt kommt in dieses Element, ohne es in <body>; ohne
// Startseite oder ohne beides in dieses Gerüst.
const LE_SITE_PAGE_FRAME = 'main';
const LE_SITE_PAGE_FALLBACK = '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"></head><body><main>%s</main></body></html>';
// 404-Seite ohne eigene 404.php/404.html (le_site_not_found_document): Titel und Inhalt im Rahmen der Startseite.
const LE_SITE_NOT_FOUND_TITLE = 'Seite nicht gefunden';
const LE_SITE_NOT_FOUND_HTML = '<section style="max-width:40rem;margin:0 auto;padding:6rem 1.5rem;text-align:center"><h1>Seite nicht gefunden</h1>'
    . '<p>Diese Seite gibt es nicht oder nicht mehr.</p><p><a href="/">Zur Startseite</a></p></section>';

/**
 * 404-Seite der Website (LE_SITE_NOT_FOUND_PAGE: 404.php oder 404.html) mit Status 404. Ohne eigene die Startseite
 * als Rahmen (le_site_page_frame) mit LE_SITE_NOT_FOUND_HTML, Titel LE_SITE_NOT_FOUND_TITLE, noindex, ohne canonical
 * und mit <base> auf die Startseite (relative Adressen ihres Kopfes); null ohne beides.
 */
function le_site_not_found_document(): ?array
{
    $file = le_site_request_file(LE_SITE_NOT_FOUND_PAGE);
    if ($file !== null && le_site_is_document($file)) {
        return le_site_document($file, 404);
    }
    $home = le_site_request_file(LE_SITE_HOME_URL);
    if ($home === null || !le_site_is_document($home)) {
        return null;
    }
    $head = ['title' => LE_SITE_NOT_FOUND_TITLE, 'canonical' => null, 'robots' => LE_SITE_NOINDEX, 'base' => LE_SITE_HOME_URL];
    $finish = static fn (string $html): string => le_site_html_set_head(le_site_page_frame($html, LE_SITE_NOT_FOUND_HTML), $head);

    return le_site_document($home, 404, [], $finish, '');
}

/**
 * Seite im Rahmen von $frame (gerenderte Startseite mit Kopf und Fuß): ihr LE_SITE_PAGE_FRAME bzw. <body> enthält
 * danach nur $inner. Ohne beides LE_SITE_PAGE_FALLBACK.
 */
function le_site_page_frame(string $frame, string $inner): string
{
    $doc = markup_parse($frame);
    $index = markup_find_tag($doc, LE_SITE_PAGE_FRAME) ?? markup_find_tag($doc, 'body');

    return $index !== null ? markup_apply($frame, [markup_set_inner($doc, $index, $inner)]) : sprintf(LE_SITE_PAGE_FALLBACK, $inner);
}

/**
 * Website-Adresse aus den Einstellungen („Website-URL“) ohne „/“ am Ende, z. B. für canonical; null, wenn
 * keine oder keine gültige eingetragen ist. Nie aus der Anfrage (Host-Header ist vom Besucher).
 */
function le_site_base_url(): ?string
{
    $url = le_site_config()['url'] ?? null;
    $url = is_string($url) ? trim($url) : '';

    return preg_match(LE_SITE_BASE_URL_PATTERN, $url) ? rtrim($url, '/') : null;
}

/**
 * Tags des Kopfes ($headIndex in $doc aus markup_parse) je Schlüssel (title, base, link:canonical, meta:<Name>) als
 * Liste ihrer Knoten, getrennt nach Tag-Art: ein <meta name="title"> ist kein <title>. Nur Kinder des Kopfes, ein
 * <title> in einem SVG im Body zählt nicht.
 */
function le_site_head_tags(array $doc, int $headIndex): array
{
    $byKey = [];
    foreach ($doc['nodes'][$headIndex]['children'] as $i) {
        $node = $doc['nodes'][$i];
        if ($node['type'] !== 'element') {
            continue;
        }
        $key = match ($node['tag']) {
            'title', 'base' => $node['tag'],
            'meta' => 'meta:' . strtolower(trim(markup_attr_text($node, 'property') ?: markup_attr_text($node, 'name'))),
            'link' => in_array('canonical', preg_split('/\s+/', strtolower(markup_attr_text($node, 'rel'))) ?: [], true) ? 'link:canonical' : '',
            default => '',
        };
        if ($key !== '') {
            $byKey[$key][] = $i;
        }
    }

    return $byKey;
}

/**
 * Setzt im <head> von $html Titel, Beschreibung und canonical ($head: title, description als Klartext,
 * canonical als Adresse; fehlende Schlüssel bleiben, wie sie sind): das erste vorhandene Tag bekommt den Wert,
 * weitere gleiche fallen weg, fehlende kommen ans Ende des Kopfes; og:title, og:description, og:url,
 * twitter:title und twitter:description nur, wenn es sie gibt (property oder name). canonical null entfernt
 * canonical und og:url, $head['robots'] setzt <meta name="robots">. Namen wie der Browser ohne Groß/klein („Description“). $head['base'] kommt als <base href> an den
 * Anfang des Kopfes, wenn es keinen gibt (le_site_base_inserted). Ohne <head> bleibt $html unverändert.
 */
function le_site_html_set_head(string $html, array $head): string
{
    $doc = markup_parse($html);
    $headIndex = markup_find_tag($doc, 'head');
    if ($headIndex === null) {
        return $html;
    }
    $byKey = le_site_head_tags($doc, $headIndex);

    // [Schlüssel, Inhalt, einfügen, wenn es fehlt]; Inhalt null entfernt alle Tags des Schlüssels.
    $tags = [];
    foreach (['title' => ['title', 'meta:og:title', 'meta:twitter:title'], 'description' => ['meta:description', 'meta:og:description', 'meta:twitter:description'], 'canonical' => ['link:canonical', 'meta:og:url'], 'robots' => ['meta:robots']] as $name => $keys) {
        if (array_key_exists($name, $head)) {
            foreach ($keys as $i => $key) {
                $tags[] = [$key, $head[$name], $i === 0];
            }
        }
    }
    $edits = [];
    $append = '';
    foreach ($tags as [$key, $value, $insert]) {
        if ($value === null) {
            foreach ($byKey[$key] ?? [] as $extra) {
                $edits[] = markup_remove_node($doc, $extra);
            }
            continue;
        }
        $value = markup_attr_escape($value);
        $found = $byKey[$key] ?? [];
        if ($found === []) {
            $append .= !$insert ? '' : match ($key) {
                'title' => '<title>' . $value . '</title>',
                'link:canonical' => '<link rel="canonical" href="' . $value . '">',
                default => '<meta name="' . substr($key, strlen('meta:')) . '" content="' . $value . '">',
            };
            continue;
        }
        $first = array_shift($found);
        $edits[] = match ($key) {
            'title' => markup_set_inner($doc, $first, $value),
            'link:canonical' => markup_set_attr($doc, $first, 'href', $value),
            default => markup_set_attr($doc, $first, 'content', $value),
        };
        foreach ($found as $extra) {
            $edits[] = markup_remove_node($doc, $extra);
        }
    }

    $node = $doc['nodes'][$headIndex];
    if (isset($head['base']) && !isset($byKey['base'])) {
        // Vor allen relativen Adressen im Kopf (Stylesheets), damit sie schon danach aufgelöst werden.
        $edits[] = ['start' => $node['inner_start'], 'end' => $node['inner_start'], 'text' => '<base href="' . markup_attr_escape($head['base']) . '">'];
        le_site_base_inserted(true);
    }
    if ($append !== '') {
        $edits[] = ['start' => $node['inner_end'], 'end' => $node['inner_end'], 'text' => $append];
    }

    return markup_apply($html, $edits);
}

/**
 * Ob le_site_html_set_head in dieser Anfrage ein <base> eingesetzt hat ($set: merken). Dann zeigen Links nur mit
 * Fragment auf die Startseite; der Router schreibt sie nach Shortcodes und Filtern um (le_site_fragment_links).
 */
function le_site_base_inserted(bool $set = false): bool
{
    static $inserted = false;

    return $inserted = $inserted || $set;
}

/**
 * Angefragte Adresse wie in der Adresszeile: kanonischer Pfad (le_site_canonical_path) samt Query, prozentkodiert wie
 * vom Browser geschickt; was dort nicht stehen darf (", <, Leerzeichen), wird kodiert. null ohne Anfrage oder bei „..“.
 */
function le_site_request_url(): ?string
{
    if (!isset($_SERVER['REQUEST_URI'])) {
        return null;
    }
    [$path, $query] = array_pad(explode('?', (string) $_SERVER['REQUEST_URI'], 2), 2, '');
    $path = le_site_canonical_path($path === '' ? '/' : $path);
    if ($path === null) {
        return null;
    }

    return (string) preg_replace_callback("#[^A-Za-z0-9._~!$&'()*+,;=:@/?%-]#", static fn (array $m): string => rawurlencode($m[0]), $path . ($query !== '' ? '?' . $query : ''));
}

/**
 * Links nur mit Fragment (<a href="#main">, <area href="#">) im Body auf $self + Fragment, damit sie unter einem <base>
 * auf der Seite bleiben; alles andere byte-gleich. $self: Adresse der Seite (le_site_request_url), roh.
 */
function le_site_fragment_links(string $html, string $self): string
{
    $doc = markup_parse($html);
    $body = markup_find_tag($doc, 'body');
    $head = markup_find_tag($doc, 'head');
    $from = $body !== null ? $doc['nodes'][$body]['start'] : ($head !== null ? $doc['nodes'][$head]['end'] : 0);
    $edits = [];
    foreach ($doc['nodes'] as $index => $node) {
        if ($node['type'] !== 'element' || $node['start'] < $from || !in_array($node['tag'], ['a', 'area'], true) || markup_attr($node, 'href') === null) {
            continue;
        }
        $href = trim(markup_attr_text($node, 'href'));
        if (str_starts_with($href, '#')) {
            $edits[] = markup_set_attr($doc, $index, 'href', markup_attr_escape($self . $href));
        }
    }

    return $edits === [] ? $html : markup_apply($html, $edits);
}
