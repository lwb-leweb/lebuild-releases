<?php
declare(strict_types=1);

// IndexNow (Bing, Yandex, Seznam, Naver; Google nimmt nicht teil): Nach jeder erfolgreichen Änderung über das Backend
// meldet der Kern neue, geänderte und entfernte Adressen der Sitemap sofort, statt zu warten, bis die Suchmaschine
// die Sitemap wieder liest. Nur auf der echten Website (Anfrage über den Host der Website-Adresse), also nie lokal
// und nie über die Vorschau-Adresse. Der Schlüssel kommt aus app_secret(), die Website liefert ihn unter /<key>.txt.

require_once LE_BACKEND . '/base/utils.php';

const LE_INDEXNOW_ENDPOINT = 'https://api.indexnow.org/indexnow';
// Letzter gemeldeter Stand der Sitemap: {"urls": {"/pfad": Zeitstempel oder null}}.
const LE_INDEXNOW_STATE_FILE = CACHE_ROOT . '/indexnow.json';
const LE_INDEXNOW_TIMEOUT = 5;
// Höchstzahl Adressen je Meldung (Vorgabe von IndexNow).
const LE_INDEXNOW_MAX_URLS = 10000;

/** Schlüssel dieser Website (32 Hex-Zeichen), fest je Installation. */
function le_indexnow_key(): string
{
    return substr(hash_hmac('sha256', 'indexnow', app_secret()), 0, 32);
}

/** Adresse, unter der die Website den Schlüssel ausliefert (/<key>.txt). */
function le_indexnow_key_path(): string
{
    return '/' . le_indexnow_key() . '.txt';
}

/** Ziel der Meldungen; null, wenn LEBUILD_INDEXNOW = off. Die Env-Variable kann auch eine andere Adresse sein (Tests). */
function le_indexnow_endpoint(): ?string
{
    $env = trim((string) getenv('LEBUILD_INDEXNOW'));
    if (in_array(strtolower($env), ['off', '0', 'false', 'no'], true)) {
        return null;
    }

    return preg_match('#^https?://#', $env) ? $env : LE_INDEXNOW_ENDPOINT;
}

/**
 * Aus den Endpunkten, die Seiten, Plugin-Einträge, aktive Plugins, die Datenbank der Einträge oder die Website-Adresse ändern,
 * direkt nach require_csrf (die Liste prüft der IndexNow-Test): Bei POST nach dem Ende der Anfrage die Änderungen melden
 * (le_indexnow_after_request).
 */
function le_indexnow_watch(): void
{
    static $watching = false;
    if ($watching || ($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        return;
    }
    $watching = true;
    register_shutdown_function('le_indexnow_after_request');
}

/**
 * Nach einer erfolgreichen Anfrage (Status unter 400) auf der echten Website: Antwort erst abschließen
 * (fastcgi_finish_request, der Benutzer wartet nicht), dann melden. Fehler landen nur im Log.
 */
function le_indexnow_after_request(): void
{
    $status = (int) http_response_code();
    if ($status >= 400 || le_indexnow_endpoint() === null) {
        return;
    }
    try {
        require_once LE_BACKEND . '/site/seo.php';
        $host = le_indexnow_live_host();
        if ($host === null) {
            return;
        }
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_write_close();
        }
        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();
        }
        le_indexnow_submit_changes($host);
    } catch (Throwable $e) {
        error_log('indexnow: ' . $e->getMessage());
    }
}

/** Host der Website-Adresse, wenn die Anfrage über ihn kam; sonst null (lokal, Vorschau, ohne Website-Adresse). */
function le_indexnow_live_host(): ?string
{
    $base = le_seo_base_url();
    $host = $base !== null ? le_host_normalize((string) parse_url($base, PHP_URL_HOST)) : '';

    return $host !== '' && $host === le_host_normalize((string) ($_SERVER['HTTP_HOST'] ?? '')) ? $host : null;
}

/**
 * Vergleicht die Sitemap mit dem letzten Stand und meldet, was neu, geändert oder entfernt ist. Ohne Stand
 * (erstes Mal) wird er nur angelegt. Der Stand rückt nach, außer die Meldung kam nicht an (Netz, 429, 5xx):
 * dann versucht es die nächste Änderung wieder.
 */
function le_indexnow_submit_changes(string $host): void
{
    $lock = store_lock('indexnow');
    try {
        $current = le_seo_sitemap_urls();
        $state = is_file(LE_INDEXNOW_STATE_FILE) ? json_decode((string) file_get_contents(LE_INDEXNOW_STATE_FILE), true) : null;
        $previous = is_array($state['urls'] ?? null) ? $state['urls'] : null;
        $changed = $previous === null ? [] : le_indexnow_changed($previous, $current);
        if ($changed !== [] && !le_indexnow_send($host, $changed)) {
            return;
        }
        if ($previous === null || $changed !== []) {
            write_file_atomic(LE_INDEXNOW_STATE_FILE, (string) json_encode(['urls' => $current], JSON_UNESCAPED_SLASHES));
        }
    } finally {
        store_unlock($lock);
    }
}

/** Pfade, die in $current neu sind, ein anderes Änderungsdatum haben oder in $previous standen und fehlen. */
function le_indexnow_changed(array $previous, array $current): array
{
    $changed = [];
    foreach ($current as $path => $lastmod) {
        if (!array_key_exists($path, $previous) || $previous[$path] !== $lastmod) {
            $changed[] = (string) $path;
        }
    }
    foreach (array_keys(array_diff_key($previous, $current)) as $path) {
        $changed[] = (string) $path;
    }

    return $changed;
}

/** Meldet $paths an IndexNow; false nur, wenn es später noch einmal versucht werden soll (Netz, 429, 5xx). */
function le_indexnow_send(string $host, array $paths): bool
{
    $endpoint = le_indexnow_endpoint();
    $base = le_seo_base_url();
    if ($endpoint === null || $base === null) {
        return true;
    }
    $body = (string) json_encode([
        'host' => $host,
        'key' => le_indexnow_key(),
        'urlList' => array_map(static fn (string $p): string => $base . $p, array_slice($paths, 0, LE_INDEXNOW_MAX_URLS)),
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $headers = ['Content-Type: application/json; charset=utf-8'];
    $status = 0;
    if (function_exists('curl_init')) {
        $ch = curl_init($endpoint);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => LE_INDEXNOW_TIMEOUT,
            CURLOPT_CONNECTTIMEOUT => LE_INDEXNOW_TIMEOUT,
        ]);
        curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
    } else {
        $context = stream_context_create(['http' => [
            'method' => 'POST', 'header' => implode("\r\n", $headers), 'content' => $body,
            'timeout' => LE_INDEXNOW_TIMEOUT, 'ignore_errors' => true,
        ]]);
        @file_get_contents($endpoint, false, $context);
        $line = function_exists('http_get_last_response_headers') ? (http_get_last_response_headers()[0] ?? '') : ($http_response_header[0] ?? '');
        $status = preg_match('#^HTTP/\S+ (\d{3})#', (string) $line, $m) ? (int) $m[1] : 0;
    }
    if ($status !== 200 && $status !== 202) {
        error_log('indexnow: status ' . $status . ' for ' . count($paths) . ' urls');
    }

    return $status !== 0 && $status !== 429 && $status < 500;
}
