<?php
declare(strict_types=1);

// Plugin-Schnittstelle: alles aus dem Kern, was Plugins nutzen (Wächter, Antworten, Datenbank, Schema, Markierungen,
// Uploads und Einträge, Richtext, Icons, Mail, Seitenadressen, SEO, IndexNow, Aktivität). Plugins laden keine Kern-Datei
// selbst: Der Kern lädt diese Datei vor jedem Plugin-Code (Hook, Shortcode, public.php), Plugin-Endpunkte laden sie bis
// zum Router über LE_PLUGIN_API_FILE. backend/base/paths.php und backend/base/instance.php hat jeder Einstieg vorher geladen.

require_once LE_BACKEND . '/base/utils.php';
require_once LE_BACKEND . '/base/activity.php';
require_once LE_BACKEND . '/users/auth.php';
require_once LE_BACKEND . '/base/db.php';
require_once LE_BACKEND . '/base/mail.php';
require_once LE_BACKEND . '/html/markup.php';
require_once LE_BACKEND . '/html/iconSet.php';
require_once LE_BACKEND . '/html/icons.php';
require_once LE_BACKEND . '/html/textMarkup.php';
require_once LE_BACKEND . '/plugins/plugins.php';
require_once LE_BACKEND . '/plugins/pluginSchema.php';
require_once LE_BACKEND . '/media/uploads.php';
require_once LE_BACKEND . '/plugins/entries.php';
require_once LE_BACKEND . '/pages/routes.php';
require_once LE_BACKEND . '/site/seo.php';
require_once LE_BACKEND . '/site/indexNow.php';
require_once LE_BACKEND . '/media/openUploads.php';
require_once LE_BACKEND . '/media/usage.php';
require_once LE_BACKEND . '/pages/store.php';
require_once LE_BACKEND . '/base/siteConfig.php';
require_once LE_BACKEND . '/site/head.php';
