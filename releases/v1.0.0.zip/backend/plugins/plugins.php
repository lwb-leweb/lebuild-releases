<?php
declare(strict_types=1);

require_once LE_BACKEND . '/base/db.php';
require_once LE_BACKEND . '/base/files.php';
require_once LE_BACKEND . '/base/http.php';
require_once LE_BACKEND . '/base/texts.php';
require_once LE_BACKEND . '/plugins/hooks.php';
require_once LE_BACKEND . '/plugins/markers.php';

// Schema-Datei je Treiber im Plugin-Ordner (spec-plugin-migrations ersetzt sie später durch Dateien je Version).
const PLUGIN_SQL_FILES = [
    DB_DRIVER_MYSQL  => 'sql/install.mysql.sql',
    DB_DRIVER_SQLITE => 'sql/install.sqlite.sql',
];
// Antwort des Hooks site_page, wenn die Adresse dem Plugin gehört, es dort aber nichts gibt (404-Seite der Website).
const PLUGIN_SITE_PAGE_NOT_FOUND = ['notFound' => true];

function plugin_name_valid(string $name): bool
{
    return (bool) preg_match('/^[a-z][a-z0-9_-]*$/', $name);
}

function plugin_table_name_valid(string $name): bool
{
    return (bool) preg_match('/^[a-z][a-z0-9_]*$/', $name);
}

function plugin_path(string $name, string $sub = ''): string
{
    if (!plugin_name_valid($name)) {
        throw new InvalidArgumentException('Invalid plugin name: ' . $name);
    }

    $base = LE_PLUGINS . '/' . $name;
    if ($sub === '') {
        return $base;
    }

    $normalized = str_replace('\\', '/', ltrim($sub, '/'));
    if ($normalized === '' || str_contains($normalized, '..')) {
        throw new InvalidArgumentException('Invalid plugin path: ' . $sub);
    }

    return $base . '/' . $normalized;
}

/** Pfad der Schema-Datei (PLUGIN_SQL_FILES) für den aktiven (oder angegebenen) Treiber. Deinstallieren löscht die gemerkten Tabellen. */
function plugin_sql_path(string $name, ?string $driver = null): string
{
    return plugin_path($name, PLUGIN_SQL_FILES[$driver ?? db_driver()]);
}

/** Meldung, wenn einem Plugin die Schema-Datei für einen Treiber fehlt; nennt ihren Pfad im Plugin (PLUGIN_SQL_FILES). */
function plugin_schema_missing_message(string $name, string $driver): string
{
    return 'Dem Plugin ' . $name . ' fehlt ' . PLUGIN_SQL_FILES[$driver] . ' für die Datenbank ' . $driver . '.';
}

function plugin_manifest(string $name): array
{
    static $cache = [];

    if (!plugin_name_valid($name)) {
        throw new InvalidArgumentException('Invalid plugin name: ' . $name);
    }
    if (isset($cache[$name])) {
        return $cache[$name];
    }

    $path = plugin_path($name, 'plugin.json');
    if (!is_file($path)) {
        throw new RuntimeException('Plugin manifest not found: ' . $name);
    }

    $data = json_decode((string) file_get_contents($path), true);
    if (!is_array($data)) {
        throw new RuntimeException('Invalid plugin manifest JSON: ' . $name);
    }
    if (($data['name'] ?? '') !== $name) {
        throw new RuntimeException('Plugin manifest name mismatch: ' . $name);
    }
    foreach (['label', 'version', 'requires'] as $required) {
        if (!array_key_exists($required, $data)) {
            throw new RuntimeException('Missing plugin manifest key "' . $required . '": ' . $name);
        }
    }

    $data['requires'] = array_merge(
        ['database' => false, 'mail' => false, 'uploads' => false],
        is_array($data['requires']) ? $data['requires'] : []
    );
    $data['tables'] = plugin_valid_tables($data['tables'] ?? []);
    if (array_key_exists('inlineEdit', $data)) {
        $data['inlineEdit'] = plugin_valid_inline_edit($name, $data['inlineEdit']);
    }

    $cache[$name] = $data;
    return $data;
}

function plugin_valid_tables(mixed $tables): array
{
    if (!is_array($tables)) {
        return [];
    }

    $valid = [];
    foreach ($tables as $table) {
        if (is_string($table) && plugin_table_name_valid($table)) {
            $valid[] = $table;
        }
    }

    return array_values(array_unique($valid));
}

/**
 * inlineEdit aus plugin.json: je Aktion ein Pfad „api/<datei>.php“ (optional mit fester Query),
 * der im Plugin existiert. list, get, save, delete sind Pflicht, sort nur bei Plugins mit Reihenfolge.
 */
function plugin_valid_inline_edit(string $name, mixed $inlineEdit): array
{
    $error = new RuntimeException('Invalid plugin manifest key "inlineEdit": ' . $name);
    if (!is_array($inlineEdit) || array_diff_key($inlineEdit, PLUGIN_INLINE_EDIT_ENDPOINTS) !== []) {
        throw $error;
    }

    $valid = [];
    foreach (PLUGIN_INLINE_EDIT_ENDPOINTS as $action => $required) {
        $endpoint = $inlineEdit[$action] ?? null;
        if ($endpoint === null && !$required) {
            continue;
        }
        if (!is_string($endpoint) || !preg_match('#^api/[a-z0-9_-]+\.php(\?[a-z0-9_=&-]+)?$#i', $endpoint)
            || !is_file(plugin_path($name, (string) strtok($endpoint, '?')))) {
            throw $error;
        }
        $valid[$action] = $endpoint;
    }

    return $valid;
}

/** URLs der inlineEdit-Endpoints aller aktiven Plugins, die mitmachen: [Plugin => [Aktion => URL]]. */
function plugin_inline_edit_config(): array
{
    $config = [];
    foreach (load_plugins_state()['active'] as $name) {
        try {
            $inlineEdit = plugin_manifest($name)['inlineEdit'] ?? null;
        } catch (Throwable $e) {
            continue;
        }
        if ($inlineEdit === null) {
            continue;
        }
        $config[$name] = array_map(static fn (string $endpoint): string => PLUGINS_URL . $name . '/' . $endpoint, $inlineEdit);
    }

    return $config;
}

function list_plugin_dirs(): array
{
    if (!is_dir(LE_PLUGINS)) {
        return [];
    }

    $names = [];
    foreach (scandir(LE_PLUGINS) ?: [] as $entry) {
        if ($entry === '.' || $entry === '..' || !plugin_name_valid($entry)) {
            continue;
        }
        if (!is_dir(LE_PLUGINS . '/' . $entry)) {
            continue;
        }
        if (!is_file(LE_PLUGINS . '/' . $entry . '/plugin.json')) {
            continue;
        }
        $names[] = $entry;
    }
    sort($names);

    return $names;
}

function plugins_state_path(): string
{
    return CONTENT_ROOT . '/active-plugins.json';
}

function plugin_data_path(string $name): string
{
    if (!plugin_name_valid($name)) {
        throw new InvalidArgumentException('Invalid plugin name: ' . $name);
    }
    return CONTENT_ROOT . '/plugins/' . $name;
}

function load_plugins_state(): array
{
    $path = plugins_state_path();
    if (!is_file($path)) {
        return ['active' => [], 'installed' => []];
    }

    $data = json_decode((string) file_get_contents($path), true);
    return plugins_state_normalize(is_array($data) ? $data : []);
}

/** Beim Lesen und Schreiben: nur gültige Plugin-Namen, active ohne Doppelte, installed mit geprüften Tabellennamen. */
function plugins_state_normalize(array $state): array
{
    $active = [];
    foreach (is_array($state['active'] ?? null) ? $state['active'] : [] as $name) {
        if (is_string($name) && plugin_name_valid($name)) {
            $active[] = $name;
        }
    }
    $installed = [];
    foreach (is_array($state['installed'] ?? null) ? $state['installed'] : [] as $name => $meta) {
        if (is_string($name) && plugin_name_valid($name) && is_array($meta)) {
            $meta['tables'] = plugin_valid_tables($meta['tables'] ?? []);
            $installed[$name] = $meta;
        }
    }
    return ['active' => array_values(array_unique($active)), 'installed' => $installed];
}

function save_plugins_state(array $state): void
{
    $path = plugins_state_path();
    $payload = plugins_state_normalize($state);
    // Leer als {} statt [], wie bisher in active-plugins.json.
    if ($payload['installed'] === []) {
        $payload['installed'] = new stdClass();
    }

    $json = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        throw new RuntimeException('Cannot encode active-plugins.json');
    }

    write_file_atomic($path, $json . PHP_EOL);
}

function plugin_active(string $name): bool
{
    if (!plugin_name_valid($name)) {
        return false;
    }

    $state = load_plugins_state();
    return in_array($name, $state['active'], true);
}

/** plugin_manifest() für API-Endpoints: Ist plugin.json fehlerhaft, antwortet der Request mit 500 und fester Meldung (Details ins Log). */
function le_plugin_manifest_or_fail(string $name): array
{
    try {
        return plugin_manifest($name);
    } catch (Throwable $e) {
        error_log('plugin manifest ' . $name . ': ' . $e->getMessage());
        json_response(['ok' => false, 'error' => API_TEXT['pluginInvalid']], 500);
    }
}

/** Plugin-Name aus einer Anfrage: ungültig (plugin_name_valid) → 400 invalidPlugin. */
function le_require_plugin_name(string $name): void
{
    if (!plugin_name_valid($name)) {
        json_response(['ok' => false, 'error' => API_TEXT['invalidPlugin']], 400);
    }
}

/**
 * Lesen → Ändern → Schreiben von active-plugins.json (Aktivieren, Deaktivieren, Deinstallieren): sperrt bis zum Ende der
 * Anfrage (le_store_lock_until_end), $change bekommt den Stand per Referenz und darf mit json_response abbrechen (dann
 * bleibt die Datei). Scheitert das Speichern, ins Log mit $action und $name und 500 pluginStateFailed. Liefert den neuen Stand.
 */
function le_plugins_state_update(string $action, string $name, callable $change): array
{
    le_store_lock_until_end('plugins');
    $state = load_plugins_state();
    $change($state);
    try {
        save_plugins_state($state);
    } catch (Throwable $e) {
        error_log('plugin ' . $action . ' ' . $name . ': ' . $e->getMessage());
        json_response(['ok' => false, 'error' => API_TEXT['pluginStateFailed']], 500);
    }
    return load_plugins_state();
}

/** Plugin deaktivieren (api/plugins/deactivate.php); ein nicht aktives bleibt, wie es ist. Liefert den neuen Stand. */
function le_plugin_deactivate(string $name): array
{
    le_require_plugin_name($name);
    return le_plugins_state_update('deactivate', $name, static function (array &$state) use ($name): void {
        $state['active'] = array_values(array_diff($state['active'], [$name]));
    });
}

/**
 * Plugin aktivieren (api/plugins/activate.php): gültiger Name (400), plugin.json da (404) und lesbar (500), dann unter der
 * Sperre des Plugin-Status die Anforderungen: Datenbank (409 database_required), beschreibbare Uploads und Mailversand
 * (409). Beim ersten Mal mit Datenbank die Tabellen aus der Schema-Datei (409 schema_missing, 500 pluginInstallFailed) und
 * Version, Zeit und Tabellen merken. Liefert den neuen Stand.
 */
function le_plugin_activate(string $name): array
{
    // Mail erst hier: plugins.php lädt jede Besucherseite, den Mailversand braucht nur das Aktivieren.
    require_once LE_BACKEND . '/base/mail.php';
    le_require_plugin_name($name);
    if (!is_file(plugin_path($name, 'plugin.json'))) {
        json_response(['ok' => false, 'error' => API_TEXT['pluginNotFound']], 404);
    }
    $manifest = le_plugin_manifest_or_fail($name);

    return le_plugins_state_update('activate', $name, static function (array &$state) use ($name, $manifest): void {
        if (!empty($manifest['requires']['database']) && !db_available()) {
            json_response(db_migration_error('database_required', DB_UNAVAILABLE_MESSAGE), DB_MIGRATION_ERROR_STATUS['database_required']);
        }
        if (!empty($manifest['requires']['uploads']) && (!is_dir(UPLOADS_ROOT) || !is_writable(UPLOADS_ROOT))) {
            json_response([
                'ok' => false,
                'error' => 'uploads_unwritable',
                'message' => API_TEXT['uploadsUnwritable'],
            ], 409);
        }
        if (!empty($manifest['requires']['mail']) && !core_mail_available()) {
            json_response([
                'ok' => false,
                'error' => 'mail_unavailable',
                'message' => API_TEXT['mailUnavailable'],
            ], 409);
        }

        if (!empty($manifest['requires']['database']) && !isset($state['installed'][$name])) {
            $sqlPath = plugin_sql_path($name);
            if (!is_file($sqlPath)) {
                json_response(db_migration_error('schema_missing', plugin_schema_missing_message($name, db_driver())), DB_MIGRATION_ERROR_STATUS['schema_missing']);
            }
            try {
                db_run_schema(db(), db_driver(), (string) file_get_contents($sqlPath), $manifest['tables']);
            } catch (Throwable $e) {
                error_log('plugin activate ' . $name . ': ' . sprintf(API_TEXT['installSqlFailed'], basename($sqlPath), $e->getMessage()));
                json_response(['ok' => false, 'error' => sprintf(API_TEXT['pluginInstallFailed'], basename($sqlPath))], 500);
            }
            $state['installed'][$name] = [
                'version' => (string) ($manifest['version'] ?? '0.0.0'),
                'installedAt' => current_iso_time(),
                'tables' => $manifest['tables'] ?? [],
            ];
        }

        if (!in_array($name, $state['active'], true)) {
            $state['active'][] = $name;
        }
    });
}

/** Ob $name im Stand $state installiert ist: mit gemerkten Tabellen, aktiv oder mit eigenen Dateien (plugin_data_path). */
function le_plugin_installed(array $state, string $name): bool
{
    return isset($state['installed'][$name]) || in_array($name, $state['active'], true) || file_exists(plugin_data_path($name));
}

// Aktionen der generischen Endpoints (api/plugins/generic/<aktion>.php). Ein Plugin mit eigenem
// plugins/<name>/api/<aktion>.php bedienen sie dafür nicht: Sie umgingen seine Regeln (opening_hours_delete räumt etwa
// die Ausnahmen eines Bereichs mit auf).
const LE_PLUGIN_GENERIC_ACTIONS = ['list', 'get', 'save', 'delete'];
const LE_PLUGIN_GENERIC_URL = '/api/plugins/generic/';

// Adresse eines Plugin-Endpunkts: /plugins/<name>/api/<datei>.php (le_plugin_endpoint_file prüft beide Teile).
const LE_PLUGIN_ENDPOINT_PATTERN = '#^' . PLUGINS_URL . '([^/]+)/api/([^/]+)\.php$#';
// Dateien eines Plugins, die der Router ausliefert (LE_PLUGIN_SITE_FILES_DIR, LE_PLUGIN_ADMIN_FILES_DIR); alles andere im
// Plugin-Ordner ist von außen nicht erreichbar.
const LE_PLUGIN_FILE_PATTERN = '#^' . PLUGINS_URL . '([^/]+)/(' . LE_PLUGIN_SITE_FILES_DIR . '|' . LE_PLUGIN_ADMIN_FILES_DIR . ')/(.+)$#';
// Name eines Endpunkts unter plugins/<name>/api/ (ohne .php): keine Unterordner, keine Punkte.
const LE_PLUGIN_ENDPOINT_NAME_PATTERN = '/^[A-Za-z0-9_-]+$/';

/** Datei des Endpunkts $endpoint (ohne .php) von Plugin $name; null bei ungültigem Namen oder ohne Datei. */
function le_plugin_endpoint_file(string $name, string $endpoint): ?string
{
    if (!plugin_name_valid($name) || !preg_match(LE_PLUGIN_ENDPOINT_NAME_PATTERN, $endpoint)) {
        return null;
    }
    $file = plugin_path($name, 'api/' . $endpoint . '.php');

    return is_file($file) ? $file : null;
}

/** Adresse des eigenen Endpoints von $name für $action (LE_PLUGIN_GENERIC_ACTIONS), null ohne. */
function le_plugin_own_endpoint(string $name, string $action): ?string
{
    return le_plugin_endpoint_file($name, $action) !== null ? PLUGINS_URL . $name . '/api/' . $action . '.php' : null;
}

/** Endpoints je Aktion für die generische Ansicht im Backend: die eigenen des Plugins, sonst die generischen. */
function le_plugin_entry_endpoints(string $name): array
{
    $endpoints = [];
    foreach (LE_PLUGIN_GENERIC_ACTIONS as $action) {
        $endpoints[$action] = le_plugin_own_endpoint($name, $action) ?? LE_PLUGIN_GENERIC_URL . $action . '.php';
    }
    return $endpoints;
}

/** Generischer Endpoint für $action: 400, wenn $name dafür einen eigenen hat. */
function le_require_generic_endpoint(string $name, string $action): void
{
    if (le_plugin_own_endpoint($name, $action) !== null) {
        json_response(['ok' => false, 'error' => API_TEXT['pluginOwnEndpoint']], 400);
    }
}

function require_plugin_active(string $name): void
{
    if (!plugin_active($name)) {
        json_response(['ok' => false, 'error' => API_TEXT['pluginNotActive']], 404);
    }
    // Zentrale Sperre während eines Datenumzugs: schreibende Requests von
    // Plugins mit Datenbank → 503, Lesen läuft weiter aus der alten Quelle.
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if ($method !== 'GET' && $method !== 'HEAD' && !empty(le_plugin_manifest_or_fail($name)['requires']['database'])) {
        require_no_db_migration();
    }
}

/**
 * Tabellen installierter Plugins, die in der Datenbank fehlen, aus der Schema-Datei
 * neu anlegen. Passiert, wenn active-plugins.json ohne die Datenbank ankommt
 * (frische Installation aus dem Repo, gelöschte site.sqlite, neue MySQL-DB).
 * Fehler landen im Log; der eigentliche Request meldet dann „no such table“.
 * Nicht auf der Kommandozeile: Restore und Umzug legen Tabellen selbst an.
 */
function plugin_restore_missing_tables(PDO $pdo): void
{
    if (PHP_SAPI === 'cli' || db_migration_running()) {
        return;
    }
    $driver = db_driver();
    foreach (load_plugins_state()['installed'] as $name => $meta) {
        try {
            le_plugin_create_missing_tables($pdo, $driver, $name, $meta['tables'] ?? []);
        } catch (Throwable $e) {
            error_log('plugin ' . $name . ': ' . $e->getMessage());
        }
    }
}

/**
 * Fehlende Tabellen $tables des Plugins $name aus seiner install-Datei für $driver anlegen; liefert die angelegten.
 * Wirft, wenn die Datei fehlt (plugin_schema_missing_message) oder scheitert (dann bleibt keine halbe Tabelle, db_run_schema).
 */
function le_plugin_create_missing_tables(PDO $pdo, string $driver, string $name, array $tables): array
{
    $missing = array_values(array_filter($tables, static fn (string $table): bool => !db_table_exists($pdo, $table)));
    if ($missing === []) {
        return [];
    }
    $sqlPath = plugin_sql_path($name, $driver);
    if (!is_file($sqlPath)) {
        throw new RuntimeException(plugin_schema_missing_message($name, $driver));
    }
    try {
        db_run_schema($pdo, $driver, (string) file_get_contents($sqlPath), $tables);
    } catch (Throwable $e) {
        throw new RuntimeException(sprintf(API_TEXT['installSqlFailed'], basename($sqlPath), $e->getMessage()), 0, $e);
    }

    return $missing;
}

function plugin_has_admin_sidebar(array $manifest): bool
{
    return is_array($manifest['admin']['sidebar'] ?? null);
}

/** Hat das Plugin ein Schema für die generische Ansicht im Backend (schema.fields)? */
function le_plugin_has_schema(array $manifest): bool
{
    return isset($manifest['schema']['fields']) && is_array($manifest['schema']['fields']);
}

/**
 * Alle Plugins für Verwaltung → Plugins (api/plugins/list.php): je Plugin Beschriftung, Version, Anforderungen, Zustand
 * und was es im Backend mitbringt; eine unlesbare plugin.json nur mit Meldung (pluginInvalid, Grund ins Log). Dazu, ob die
 * Datenbank für Plugins bereitsteht.
 */
function le_plugins_list(): array
{
    $state = load_plugins_state();
    $plugins = [];

    foreach (list_plugin_dirs() as $name) {
        try {
            $manifest = plugin_manifest($name);
            $adminModule = plugin_admin_module_path($manifest);
            $plugins[] = [
                'name' => $name,
                'label' => (string) ($manifest['label'] ?? $name),
                'version' => (string) ($manifest['version'] ?? '0.0.0'),
                'description' => (string) ($manifest['description'] ?? ''),
                'requires' => $manifest['requires'],
                'active' => in_array($name, $state['active'], true),
                'installed' => le_plugin_installed($state, $name),
                'installedVersion' => $state['installed'][$name]['version'] ?? null,
                'hasAdminSidebar' => plugin_has_admin_sidebar($manifest),
                'hasAdminModule' => $adminModule !== null,
                'hasSchema' => le_plugin_has_schema($manifest),
            ];
        } catch (Throwable $e) {
            error_log('plugin list ' . $name . ': ' . $e->getMessage());
            $plugins[] = [
                'name' => $name,
                'error' => API_TEXT['pluginInvalid'],
            ];
        }
    }

    return [
        'plugins' => $plugins,
        'dbAvailable' => db_available(),
        'dbMessage' => db_available() ? '' : DB_UNAVAILABLE_MESSAGE,
    ];
}

function active_plugin_admin_info(): array
{
    $state = load_plugins_state();
    $info = [];

    foreach ($state['active'] as $name) {
        try {
            $manifest = plugin_manifest($name);
        } catch (Throwable $e) {
            continue;
        }
        if (!plugin_has_admin_sidebar($manifest)) {
            continue;
        }

        $extra = plugin_extra_sidebar_entries($name);
        if ($extra !== null) {
            foreach ($extra as $entry) {
                $info[] = $entry;
            }
            continue;
        }

        $sidebar = $manifest['admin']['sidebar'];
        $module = plugin_admin_module_path($manifest);
        $info[] = [
            'name' => $name,
            'route' => $name,
            'label' => (string) ($sidebar['label'] ?? $manifest['label'] ?? $name),
            'hasAdminModule' => $module !== null,
            'hasSchema' => le_plugin_has_schema($manifest),
            'endpoints' => le_plugin_entry_endpoints($name),
        ];
    }

    return $info;
}

/**
 * Lädt die public.php jedes aktiven Plugins (Lesefunktionen für das PHP der Website), vorher die Plugin-Schnittstelle.
 * Der Router und der Health-Check rufen das vor dem Rendern auf; die Website lädt dafür keine Plugin- oder Kern-Datei selbst.
 */
function le_plugins_load_public(): void
{
    foreach (load_plugins_state()['active'] ?? [] as $name) {
        $public = is_string($name) && plugin_name_valid($name) ? plugin_path($name, 'public.php') : null;
        if ($public !== null && is_file($public)) {
            // Erst, wenn es Plugin-Code gibt: Besucherseiten ohne ihn laden die Schnittstelle (Uploads, Schema …) nicht.
            require_once LE_PLUGIN_API_FILE;
            // Wie bei den Hooks: Ein kaputtes Plugin nimmt die Website nicht mit, es fehlen nur seine Lesefunktionen.
            try {
                require_once $public;
            } catch (Throwable $e) {
                error_log('public.php ' . $name . ' failed: ' . $e->getMessage());
            }
        }
    }
}

/**
 * Lädt die lib.php von $name (gültiger Name) samt der Plugin-Schnittstelle davor: Plugins laden keine Kern-Datei selbst.
 * false ohne lib.php. Hooks laden Plugins nur so, der Router vor einem Plugin-Endpunkt über le_plugin_load_for_endpoint.
 */
function le_plugin_load_lib(string $name): bool
{
    $libPath = plugin_path($name, 'lib.php');
    if (!is_file($libPath)) {
        return false;
    }
    require_once LE_PLUGIN_API_FILE;
    require_once $libPath;

    return true;
}

/**
 * Vor einem Endpunkt von $name (gültiger Name): erst die Plugin-Schnittstelle, dann die lib.php, falls es eine gibt. Die
 * Schnittstelle kommt immer mit, auch ein Plugin mit api/ ohne lib.php bekommt Wächter und Helfer.
 */
function le_plugin_load_for_endpoint(string $name): void
{
    require_once LE_PLUGIN_API_FILE;
    le_plugin_load_lib($name);
}

function plugin_extra_sidebar_entries(string $name): ?array
{
    $fn = plugin_hook_function($name, 'admin_sidebar_entries');
    if ($fn === null) {
        return null;
    }

    try {
        $entries = $fn();
    } catch (Throwable $e) {
        return null;
    }
    if (!is_array($entries)) {
        return null;
    }

    $valid = [];
    foreach ($entries as $entry) {
        if (!is_array($entry)) {
            continue;
        }
        $route = $entry['route'] ?? null;
        $label = $entry['label'] ?? null;
        if (!is_string($route) || !is_string($label) || $label === '') {
            continue;
        }
        if (!preg_match('/^[a-z][a-z0-9_-]*(\/[a-z][a-z0-9_-]+)*$/', $route)) {
            continue;
        }
        $entry['name'] = $name;
        $entry['route'] = $route;
        $entry['label'] = $label;
        $entry['hasAdminModule'] = !empty($entry['hasAdminModule']);
        $entry['hasSchema'] = !empty($entry['hasSchema']);
        $valid[] = $entry;
    }

    return $valid;
}

function plugin_admin_module_path(array $manifest): ?string
{
    $module = $manifest['admin']['sidebar']['module'] ?? null;
    if (!is_string($module) || trim($module) === '') {
        return null;
    }
    if (str_contains(str_replace('\\', '/', $module), '..')) {
        return null;
    }

    return $module;
}
