<?php
declare(strict_types=1);

// Hooks der Plugins (knowledgebase/hooks.md): Hook-Funktion finden und aufrufen für Seiten, Filter, Sitemap und Einträge;
// dazu die Helfer, mit denen Filter Markup, CSS und Skripte vor </head> und </body> einfügen.

require_once LE_BACKEND . '/html/markup.php';
require_once LE_BACKEND . '/plugins/plugins.php';

/** Hook-Funktion „<plugin>_<hook>“ aus der lib.php des Plugins (siehe knowledgebase/hooks.md), null ohne. */
function plugin_hook_function(string $name, string $hook): ?string
{
    if (!plugin_name_valid($name)) {
        return null;
    }
    if (!le_plugin_load_lib($name)) {
        return null;
    }
    $fn = str_replace('-', '_', $name) . '_' . $hook;

    return function_exists($fn) ? $fn : null;
}

function filter_site_html(string $html): string
{
    $state = load_plugins_state();
    foreach ($state['active'] as $name) {
        $fn = plugin_hook_function($name, 'filter_site_html');
        if ($fn === null) {
            continue;
        }
        try {
            $next = $fn($html);
        } catch (Throwable $e) {
            error_log('filter_site_html ' . $name . ' failed: ' . $e->getMessage());
            continue;
        }
        if (is_string($next)) {
            $html = $next;
        }
    }

    return $html;
}

/**
 * Für filter_site_html: $markup vor das schließende $tag ('head' oder 'body') der Seite (le_html_close_tag), höchstens
 * einmal: Steht $once schon in der Seite oder gibt es keine Stelle (JSON, Teilstück, ohne </head>), bleibt $html, wie es ist.
 */
function le_plugin_insert_html(string $html, string $tag, string $markup, string $once): string
{
    if ($once === '' || str_contains($html, $once)) {
        return $html;
    }
    $at = le_html_close_tag($html, $tag);

    return $at === null ? $html : substr_replace($html, $markup, $at, 0);
}

/** CSS-Datei $url als <link rel="stylesheet"> vor das schließende $tag (Vorgabe </head>), höchstens einmal. */
function le_plugin_insert_style(string $html, string $url, string $tag = 'head'): string
{
    $href = htmlspecialchars($url, ENT_QUOTES);

    return le_plugin_insert_html($html, $tag, '<link rel="stylesheet" href="' . $href . '">', $href);
}

/** Skript $url vor </body>, höchstens einmal (le_plugin_insert_html): mit defer, mit $module als ES-Modul (type="module"). */
function le_plugin_insert_script(string $html, string $url, bool $module = false): string
{
    $href = htmlspecialchars($url, ENT_QUOTES);
    $src = 'src="' . $href . '"';

    return le_plugin_insert_html($html, 'body', '<script ' . ($module ? 'type="module" ' . $src : $src . ' defer') . '></script>', $href);
}

/**
 * Seite eines Plugins unter einer Adresse, die keine Datei der Website ist (Abfrage-Hook site_page,
 * z. B. /<pfad>/<slug> von Content-Typen): ein Dokument wie le_site_document() (der Router bindet es auf oberster
 * Ebene ein) oder PLUGIN_SITE_PAGE_NOT_FOUND; null, wenn die Adresse keinem aktiven Plugin gehört.
 */
function plugin_site_page(string $path): ?array
{
    foreach (load_plugins_state()['active'] as $name) {
        $fn = plugin_hook_function($name, 'site_page');
        if ($fn === null) {
            continue;
        }
        try {
            $page = $fn($path);
        } catch (Throwable $e) {
            error_log('site_page ' . $name . ' failed: ' . $e->getMessage());
            continue;
        }
        if (is_array($page)) {
            return $page;
        }
    }

    return null;
}

/**
 * Titel bzw. Adresse einer Rohzeile der Tabelle $table des Plugins $plugin für Meldungen (Abfrage-Hook entry_label,
 * z. B. Konfliktliste beim Einspielen von Plugin-Daten); '' ohne Hook oder wenn er wirft.
 */
function le_plugin_entry_label(string $plugin, string $table, array $row): string
{
    $fn = plugin_hook_function($plugin, 'entry_label');
    try {
        $label = $fn !== null ? $fn($table, $row) : '';
    } catch (Throwable $e) {
        error_log('entry_label ' . $plugin . ' failed: ' . $e->getMessage());
        return '';
    }

    return is_string($label) ? $label : '';
}

/**
 * Grund, warum eine eben geschriebene Rohzeile (mit id) der Tabelle $table so nicht bleiben darf (Abfrage-Hook
 * entry_problem, z. B. Adresse schon vergeben, Typ unbekannt); null ohne. Läuft in der Transaktion des Schreibens,
 * sieht also den neuen Stand. Eine Exception geht weiter (der Aufrufer bricht ab).
 */
function le_plugin_entry_problem(string $plugin, string $table, array $row): ?string
{
    $fn = plugin_hook_function($plugin, 'entry_problem');
    $problem = $fn !== null ? $fn($table, $row) : null;

    return is_string($problem) && $problem !== '' ? $problem : null;
}

/**
 * Aktion entry_updated: Zeile $before der Tabelle $table ist jetzt $after (beide Rohzeilen), geändert außerhalb des
 * Speicherns des Plugins (Einspielen von Plugin-Daten). Jedes aktive Plugin kann nachziehen (z. B. Verweise auf einen
 * umbenannten Eintrag), in derselben Transaktion; eine Exception geht weiter und alles wird zurückgenommen.
 */
function le_action_entry_updated(string $table, array $before, array $after): void
{
    foreach (load_plugins_state()['active'] as $name) {
        $fn = plugin_hook_function($name, 'action_entry_updated');
        if ($fn !== null) {
            $fn($table, $before, $after);
        }
    }
}

// Adresse aus dem Hook sitemap_urls: Pfad auf der Website, Sonderzeichen kodiert (rawurlencode).
const PLUGIN_SITEMAP_PATH_PATTERN = '#^/[A-Za-z0-9._~/%@-]*$#';

/**
 * Eigene Adressen der aktiven Plugins für die Sitemap (Abfrage-Hook sitemap_urls, z. B. Eintragsseiten von
 * Content-Typen) als [Pfad => Zeitstempel der letzten Änderung oder null]. Der Hook liefert eine Liste von
 * ['path' => '/beitraege/x', 'lastmod' => Zeitstempel, Datumstext oder null]; ungültige Pfade fallen weg,
 * ein werfender Hook zählt nicht (Log).
 */
function plugin_sitemap_urls(): array
{
    $urls = [];
    foreach (load_plugins_state()['active'] as $name) {
        $fn = plugin_hook_function($name, 'sitemap_urls');
        if ($fn === null) {
            continue;
        }
        try {
            $list = $fn();
        } catch (Throwable $e) {
            error_log('sitemap_urls ' . $name . ' failed: ' . $e->getMessage());
            continue;
        }
        foreach (is_array($list) ? $list : [] as $url) {
            $path = is_array($url) ? ($url['path'] ?? null) : null;
            if (!is_string($path) || !preg_match(PLUGIN_SITEMAP_PATH_PATTERN, $path) || str_contains($path, '..')) {
                continue;
            }
            $lastmod = $url['lastmod'] ?? null;
            $urls[$path] = match (true) {
                is_int($lastmod) => $lastmod,
                is_string($lastmod) && $lastmod !== '' => strtotime($lastmod) ?: null,
                default => null,
            };
        }
    }

    return $urls;
}
