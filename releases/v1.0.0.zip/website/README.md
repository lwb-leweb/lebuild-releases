# Website

Die Daten dieser Website; der Code von LeBuild liegt daneben und wird nie hier abgelegt.

- `public/` – die Website selbst: Seiten, CSS, Bilder, Uploads in `public/uploads/`. Alles darin außer `includes/` und Punktdateien ist über eine Adresse abrufbar.
- `private/` – Benutzer, Einstellungen, Seitenstände, Sicherungen, Plugin-Daten. Nie abrufbar (auf Apache sperrt zusätzlich `private/.htaccess`, nicht ändern); das PHP der Website darf daraus lesen.
- `setup.php` – Zugang des ersten Admins (Vorlage `setup.sample.php` im LeBuild-Paket), nach dem ersten Login ohne Passwort.

Verknüpfungen (Symlinks) in `public/`, die nach außen zeigen, liefert LeBuild nicht aus.
