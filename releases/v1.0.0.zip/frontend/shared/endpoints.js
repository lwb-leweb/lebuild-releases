// Adressen aller Kern-Endpunkte für den Browser, gegliedert wie backend/api/: der Schlüssel ist die Datei unter
// backend/api/ ohne .php (pages.history → pages/history.php), die Adresse bleibt, wie sie immer war. Die einzige
// Stelle mit Adressen unter /api/ im Browser-Code, auch Plugin-Module nennen keine; tests/frontend/structure.test.php
// gleicht sie in beiden Richtungen mit backend/api/routes.php ab. Nicht hier: backup (Abhol-Skript) und health
// (Monitore), die der Browser nie ruft.
export const ENDPOINTS = {
  bootstrap: '/api/bootstrap.php',
  users: {
    login: '/api/login.php',
    logout: '/api/logout.php',
    csrfToken: '/api/csrfToken.php',
    list: '/api/users/list.php',
    create: '/api/users/create.php',
    update: '/api/users/update.php',
    delete: '/api/users/delete.php',
    changePassword: '/api/users/changePassword.php'
  },
  pages: {
    get: '/api/getPage.php',
    save: '/api/savePage.php',
    history: '/api/listBackups.php',
    restore: '/api/restore.php',
    import: '/api/import.php',
    icons: '/api/icons.php'
  },
  media: {
    list: '/api/media.php',
    upload: '/api/upload.php',
    delete: '/api/deleteMedia.php',
    discardUploads: '/api/discardUploads.php'
  },
  plugins: {
    list: '/api/plugins/list.php',
    activate: '/api/plugins/activate.php',
    deactivate: '/api/plugins/deactivate.php',
    uninstall: '/api/plugins/uninstall.php',
    generic: {
      list: '/api/plugins/generic/list.php',
      get: '/api/plugins/generic/get.php',
      save: '/api/plugins/generic/save.php',
      delete: '/api/plugins/generic/delete.php'
    }
  },
  database: {
    config: '/api/plugins/dbConfig.php',
    test: '/api/plugins/testDb.php',
    status: '/api/getDbStatus.php',
    migrate: '/api/migrateDb.php',
    deleteArchive: '/api/deleteDbArchive.php'
  },
  update: {
    check: '/api/checkUpdate.php',
    install: '/api/installUpdate.php',
    rollback: '/api/rollbackUpdate.php'
  },
  backup: {
    status: '/api/getSiteBackupStatus.php',
    createKey: '/api/createSiteBackupKey.php',
    download: '/api/downloadSiteBackup.php'
  },
  settings: {
    get: '/api/getConfig.php',
    save: '/api/saveConfig.php'
  },
  mail: {
    get: '/api/getMailConfig.php',
    save: '/api/saveMailConfig.php',
    delete: '/api/deleteMailConfig.php',
    test: '/api/testMailConfig.php'
  },
  system: {
    checks: '/api/getSystemChecks.php',
    activity: '/api/activity.php'
  }
};
