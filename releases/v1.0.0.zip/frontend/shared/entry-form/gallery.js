import { imagePicker, uploadImage, imageAccept, draggingFiles } from '../upload.js';
import { editorButton } from '../buttons.js';
import { ENTRY_TEXT, fieldLabel } from './text.js';
import { fieldBox, symbolButton, rowButton } from './inputs.js';

// Bildraster: eine list mit genau einem image-Unterfeld und sonst nur Texten erscheint als Kacheln (galleryField).

// Bildfeld einer list, die als Raster erscheint (galleryField): genau ein image-Unterfeld, sonst nur Texte.
export function galleryImage(field) {
  const subs = Array.isArray(field.fields) ? field.fields : [];
  const images = subs.filter(function (sub) { return sub.type === 'image'; });
  const plain = subs.every(function (sub) { return sub.type === 'image' || sub.type === 'text'; });
  return images.length === 1 && plain ? images[0] : null;
}

// list mit Bildern (galleryImage) als Raster: je Zeile eine Kachel mit Bild (Klick ersetzt es, Ziehen
// verschiebt die Kachel), kleinen Textfeldern für die übrigen Unterfelder, ←/→ und Entfernen. „+ … hinzufügen“
// und auf das Raster gezogene Dateien laden mehrere Bilder auf einmal hoch (höchstens field.max Zeilen),
// jedes wird eine Zeile. Änderungen melden sich als input am Formular; read() wie listField.
export function galleryField(field, value, ctx, imageSub) {
  const look = ctx.look;
  const box = fieldBox(look, field, 'div');
  const grid = document.createElement('div');
  grid.className = look.gallery;
  const texts = field.fields.filter(function (sub) { return sub !== imageSub; });
  const max = Number(field.max) > 0 ? Number(field.max) : Infinity;
  const rows = [];
  let dragged = null;
  const changed = function () { grid.dispatchEvent(new Event('input', { bubbles: true })); };
  const refresh = function () {
    rows.forEach(function (row, index) {
      row.before.disabled = index === 0;
      row.after.disabled = index === rows.length - 1;
    });
    add.hidden = rows.length >= max;
  };
  const move = function (row, to) {
    const from = rows.indexOf(row);
    if (to < 0 || to >= rows.length || to === from) return;
    rows.splice(from, 1);
    rows.splice(to, 0, row);
    grid.insertBefore(row.tile, rows[to + 1] ? rows[to + 1].tile : null);
    refresh();
    changed();
  };
  const addTile = function (values) {
    const tile = document.createElement('div');
    tile.className = look.galleryTile;
    const row = { tile: tile, image: values && values[imageSub.name] ? String(values[imageSub.name]) : '', captions: [] };
    const media = editorButton('', look.galleryMedia, function () { replace.input.click(); });
    const img = document.createElement('img');
    img.alt = '';
    img.loading = 'lazy';
    const missing = document.createElement('span');
    missing.textContent = ENTRY_TEXT.imageMissing;
    media.append(img, missing);
    row.missing = missing;
    row.show = function () {
      img.hidden = !row.image;
      missing.hidden = Boolean(row.image);
      if (row.image) img.src = row.image;
      media.title = row.image ? ENTRY_TEXT.imageReplace : ENTRY_TEXT.imageMissing;
      media.setAttribute('aria-label', media.title);
    };
    const replace = imagePicker(function (url) {
      row.image = url;
      row.show();
      changed();
    }, ctx.notify, look.picker, ctx.uploads);
    replace.element.hidden = true;
    // Ziehen nur am Bild, damit Text in den Feldern markierbar bleibt.
    media.addEventListener('pointerdown', function () { tile.draggable = true; });
    tile.addEventListener('dragstart', function (event) {
      dragged = row;
      event.dataTransfer.effectAllowed = 'move';
    });
    tile.addEventListener('dragend', function () {
      tile.draggable = false;
      dragged = null;
    });
    tile.addEventListener('dragover', function (event) {
      if (!dragged || dragged === row) return;
      event.preventDefault();
      event.dataTransfer.dropEffect = 'move';
    });
    tile.addEventListener('drop', function (event) {
      if (!dragged || dragged === row) return;
      event.preventDefault();
      event.stopPropagation();
      move(dragged, rows.indexOf(row));
    });
    tile.append(media, replace.element);
    texts.forEach(function (sub) {
      const input = document.createElement('input');
      input.type = 'text';
      input.name = sub.name;
      input.className = look.galleryCaption;
      input.placeholder = fieldLabel(sub);
      input.setAttribute('aria-label', fieldLabel(sub));
      input.value = values && values[sub.name] != null ? String(values[sub.name]) : '';
      if (sub.required) input.required = true;
      row.captions.push({ field: sub, input: input });
      tile.appendChild(input);
    });
    const actions = document.createElement('div');
    actions.className = look.galleryActions;
    row.before = rowButton('←', ENTRY_TEXT.imageBefore, look.iconButton, function () { move(row, rows.indexOf(row) - 1); });
    row.after = rowButton('→', ENTRY_TEXT.imageAfter, look.iconButton, function () { move(row, rows.indexOf(row) + 1); });
    row.remove = function () {
      const index = rows.indexOf(row);
      if (index === -1) return;
      rows.splice(index, 1);
      tile.remove();
      refresh();
      changed();
    };
    actions.append(row.before, row.after, symbolButton('trash', ENTRY_TEXT.imageRemove, look.iconButton, function () {
      const index = rows.indexOf(row);
      row.remove();
      const next = rows[index] || rows[index - 1];
      (next ? next.tile.querySelector('button') : add).focus();
    }));
    tile.appendChild(actions);
    row.show();
    rows.push(row);
    grid.appendChild(tile);
    refresh();
    return row;
  };
  // Mehrere Dateien: je eine Kachel, die bis zum Upload wartet; scheitert er, fällt sie weg (Meldung über notify).
  const uploadFiles = function (files) {
    const free = max - rows.length;
    const name = fieldLabel(field);
    if (files.length > free) ctx.notify(ENTRY_TEXT.imagesTooMany.replace('{max}', String(max)).replace('{name}', function () { return name; }));
    const jobs = files.slice(0, Math.max(free, 0)).map(function (file) {
      const row = addTile(null);
      row.tile.classList.add(look.galleryPending);
      row.missing.textContent = ENTRY_TEXT.imageUploading;
      return uploadImage(file, ctx.notify, ctx.uploads, true).then(function (url) {
        row.image = url;
        row.tile.classList.remove(look.galleryPending);
        row.show();
        changed();
      }, function (error) {
        row.remove();
        throw error;
      });
    });
    if (!jobs.length) return;
    changed();
    Promise.allSettled(jobs).then(function (results) {
      const done = results.filter(function (result) { return result.status === 'fulfilled'; }).length;
      if (done) ctx.notify(ENTRY_TEXT.imagesUploaded.replace('{count}', String(done)));
    });
  };
  const add = document.createElement('label');
  add.className = look.picker;
  add.textContent = ENTRY_TEXT.addImages.replace('{name}', function () { return fieldLabel(field); });
  const many = document.createElement('input');
  many.type = 'file';
  many.multiple = true;
  many.accept = imageAccept();
  many.hidden = true;
  many.addEventListener('change', function () {
    const files = Array.from(many.files || []);
    many.value = '';
    uploadFiles(files);
  });
  add.appendChild(many);
  // Dateien auf das Raster ziehen (Zähler wie imageDropArea: Kinder melden dragleave am Rahmen).
  let depth = 0;
  grid.addEventListener('dragenter', function (event) {
    if (!draggingFiles(event)) return;
    event.preventDefault();
    if (++depth === 1) grid.classList.add(look.galleryActive);
  });
  grid.addEventListener('dragover', function (event) {
    if (!draggingFiles(event)) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = 'copy';
  });
  grid.addEventListener('dragleave', function () {
    if (depth > 0 && --depth === 0) grid.classList.remove(look.galleryActive);
  });
  grid.addEventListener('drop', function (event) {
    if (!draggingFiles(event)) return;
    event.preventDefault();
    depth = 0;
    grid.classList.remove(look.galleryActive);
    uploadFiles(Array.from(event.dataTransfer.files));
  });
  (Array.isArray(value) ? value : []).forEach(addTile);
  box.append(grid, add);
  refresh();
  return {
    box: box,
    input: null,
    read: function () {
      return rows.map(function (row) {
        const data = {};
        data[imageSub.name] = row.image;
        row.captions.forEach(function (caption) { data[caption.field.name] = caption.input.value; });
        return data;
      });
    }
  };
}
