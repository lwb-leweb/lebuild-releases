import { imagePicker, filePicker, imageDropArea, draggingFiles } from '../upload.js';
import { editorButton } from '../buttons.js';
import { iconGrid, ICON_TEXT } from '../icon-grid.js';
import { icon } from '../icons.js';
import { errorNotice, editorPost } from '../request.js';
import { ENTRY_TEXT, fieldLabel } from './text.js';

// Eingabe eines einzelnen Feldes: Feldart → Eingabefeld, Auswahl samt „+ hinzufügen“, Bild, Datei (PDF), Icon,
// Adresse (slug) und die kleinen Knöpfe, die Zeilen, Blöcke und Bildraster teilen.

// Feldart → type des <input>; alle übrigen Arten (text, slug, …) sind Textfelder.
export const INPUT_TYPES = {
  number: 'number',
  datetime: 'datetime-local',
  date: 'date'
};
export const INPUT_TYPE_TEXT = 'text';

// Feldart → inputmode (Tastatur am Handy); geprüft wird die Adresse auf dem Server.
export const INPUT_MODES = {
  url: 'url'
};

// Wert für das Eingabefeld: Datum aus der Datenbank („2026-10-15 09:30:00“) für datetime-local.
export function formatInputValue(field, value) {
  if (field.type === 'datetime' && value) {
    return String(value).replace(' ', 'T').slice(0, 16);
  }
  return value == null ? '' : String(value);
}

export function fieldBox(look, field, tag) {
  const box = document.createElement(tag);
  box.className = look.field;
  const label = document.createElement(look.labelTag);
  if (look.label) label.className = look.label;
  label.textContent = fieldLabel(field);
  box.appendChild(label);
  return box;
}

// Wert der Option „+ … hinzufügen“: Steuerzeichen, die in keinem gespeicherten Wert vorkommen (sanitize_plain_text).
const CREATE_OPTION_VALUE = '\u0000create';

// Auswahl: Wert ist die Option, angezeigt wird ihre Beschriftung aus optionLabels, sonst die Option selbst.
// Mit optionsCreate (Content-Typen, optionsFrom) kommt „+ <Feld> hinzufügen“ dazu (createOption).
export function selectInput(field, value, notify) {
  const select = document.createElement('select');
  if (!field.required) select.add(new Option(ENTRY_TEXT.emptyOption, ''));
  const labels = field.optionLabels && typeof field.optionLabels === 'object' ? field.optionLabels : {};
  (Array.isArray(field.options) ? field.options : []).forEach(function (option) {
    if (typeof option !== 'string') return;
    select.add(new Option(Object.prototype.hasOwnProperty.call(labels, option) ? labels[option] : option, option));
  });
  const create = field.optionsCreate && typeof field.optionsCreate === 'object' ? new Option('', CREATE_OPTION_VALUE) : null;
  if (create) select.add(create);
  select.value = value;
  // Pflichtfeld ohne passende Option: nichts gewählt (der Browser meldet es), nie „+ … hinzufügen“.
  if (select.value === CREATE_OPTION_VALUE) select.selectedIndex = -1;
  if (create) createOption(field, select, create, notify);
  return select;
}

// „+ <Feld> hinzufügen“ am Ende der Auswahl: fragt nach dem Namen, legt ihn als Eintrag im anderen Typ an
// (optionsCreate: { url, type, field }) und wählt ihn. Gibt es ihn schon, wird er nur gewählt; abgebrochen
// oder fehlgeschlagen (Hinweis über notify) gilt wieder die vorige Auswahl.
function createOption(field, select, option, notify) {
  const create = field.optionsCreate;
  const name = fieldLabel(field);
  const fill = function (text) { return text.replace('{name}', function () { return name; }); };
  option.text = fill(ENTRY_TEXT.addOption);
  let previous = select.value;
  // Wert wählen; gibt es ihn nicht (leer bei Pflicht), ist nichts gewählt.
  const choose = function (value) {
    select.value = value;
    if (select.value !== value) select.selectedIndex = -1;
    previous = select.value;
  };
  select.addEventListener('change', function () {
    if (select.value !== CREATE_OPTION_VALUE) {
      previous = select.value;
      return;
    }
    choose(previous);
    const text = (window.prompt(fill(ENTRY_TEXT.addOptionPrompt)) || '').trim();
    if (!text) return;
    if (Array.prototype.some.call(select.options, function (entry) { return entry !== option && entry.value === text; })) {
      choose(text);
      return;
    }
    const data = {};
    data[create.field] = text;
    select.disabled = true;
    editorPost(create.url, { type: create.type, data: data }).then(function () {
      select.insertBefore(new Option(text, text), option);
      choose(text);
      select.dispatchEvent(new Event('input', { bubbles: true }));
    }).catch(function (error) {
      const notice = errorNotice(error);
      if (notify) notify(notice.message, notice.action);
    }).finally(function () {
      select.disabled = false;
      select.focus();
    });
  });
}

// Bildfeld: Ablagefläche mit Vorschau (ohne Bild der Hinweis zum Hineinziehen), Dateiauswahl mit
// sofortigem Upload und „Entfernen“. Die URL steht im versteckten Eingabefeld; Änderungen melden
// sich als input am Formular (ungespeicherte Eingaben). Hochgeladen wird für das Formular uploads.
export function imageField(look, field, input, notify, uploads) {
  const box = fieldBox(look, field, 'div');
  input.type = 'hidden';
  const set = function (url) {
    input.value = url;
    show();
    input.dispatchEvent(new Event('input', { bubbles: true }));
  };
  const picker = imagePicker(set, notify, look.picker, uploads);
  const area = imageDropArea(picker, { drop: look.imageDrop, active: look.imageDropActive, image: look.image, empty: look.imageEmpty });
  const remove = editorButton(ENTRY_TEXT.remove, look.picker, function () { set(''); });
  const chooseText = picker.element.firstChild.nodeValue;
  const show = function () {
    area.show(input.value);
    remove.hidden = !input.value;
    picker.element.firstChild.nodeValue = input.value ? ENTRY_TEXT.otherImage : chooseText;
  };
  show();
  const actions = document.createElement('div');
  actions.className = look.imageActions;
  actions.append(picker.element, remove);
  box.append(input, area.element, actions);
  return box;
}

// Dateifeld (PDF): Name der Datei als Link (neuer Tab), Auswahl mit sofortigem Upload und „Entfernen“; abgelegte
// Datei lädt ebenso hoch. Die URL steht im versteckten Eingabefeld, Änderungen melden sich als input am Formular.
export function fileField(look, field, input, notify, uploads) {
  const box = fieldBox(look, field, 'div');
  input.type = 'hidden';
  const set = function (url) {
    input.value = url;
    show();
    input.dispatchEvent(new Event('input', { bubbles: true }));
  };
  const picker = filePicker(set, notify, look.picker, uploads);
  const link = document.createElement('a');
  link.className = look.file;
  link.target = '_blank';
  link.rel = 'noopener';
  link.title = ENTRY_TEXT.fileOpen;
  const remove = editorButton(ENTRY_TEXT.remove, look.picker, function () { set(''); });
  const chooseText = picker.element.firstChild.nodeValue;
  const show = function () {
    link.hidden = !input.value;
    link.href = input.value || '#';
    link.textContent = input.value ? decodeURIComponent(input.value.split('/').pop()) : '';
    remove.hidden = !input.value;
    picker.element.firstChild.nodeValue = input.value ? ENTRY_TEXT.otherFile : chooseText;
  };
  show();
  box.addEventListener('dragover', function (event) {
    if (!draggingFiles(event)) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = 'copy';
  });
  box.addEventListener('drop', function (event) {
    if (!draggingFiles(event)) return;
    event.preventDefault();
    const file = event.dataTransfer.files[0];
    if (file) picker.upload(file);
  });
  const actions = document.createElement('div');
  actions.className = look.imageActions;
  actions.append(picker.element, remove);
  box.append(input, link, actions);
  return box;
}

// Icon-Feld: Suche und Raster aller Icons wie im Seiten-Editor (icon-grid.js); der Name steht im
// versteckten Eingabefeld, ohne Pflicht gibt es „Entfernen“. Änderungen melden sich als input am Formular.
export function iconField(look, field, input, notify) {
  const box = fieldBox(look, field, 'div');
  input.type = 'hidden';
  const set = function (name) {
    input.value = name;
    remove.hidden = !name;
    input.dispatchEvent(new Event('input', { bubbles: true }));
  };
  const icons = iconGrid(look.iconGrid, input.value, set);
  icons.search.placeholder = ICON_TEXT.search;
  icons.search.setAttribute('aria-label', ICON_TEXT.search);
  const remove = editorButton(ENTRY_TEXT.remove, look.picker, function () {
    icons.select('');
    set('');
  });
  remove.hidden = !input.value;
  box.append(input, icons.search, icons.grid, icons.empty);
  if (!field.required) box.appendChild(remove);
  icons.ready.catch(function (error) {
    const notice = errorNotice(error);
    if (notify) notify(notice.message, notice.action);
  });
  return box;
}

// Ein Feld des Formulars aus dem Schema: { box, input, read() }; read() = Wert (boolean '1'/'0', list
// die Zeilen). ctx: { look, notify, uploads, editors, beforeCheck, row }; Texteditoren kommen mit ctx.row (Zeile
// eines list-Feldes, sonst undefined) nach ctx.editors (Pflicht prüft check()).
// Knopf nur mit Symbol (icons.js); label für Screenreader und Tooltip.
export function symbolButton(name, label, className, onClick) {
  const button = editorButton('', className, onClick);
  button.append(icon(name));
  button.title = label;
  button.setAttribute('aria-label', label);
  return button;
}

// Mehrzeiliges Textfeld wächst mit seinem Inhalt (bis zur Höchsthöhe aus dem CSS, dann scrollt es),
// statt den Text unten abzuschneiden. Gemessen wird erst, wenn es im Dokument steht.
export function autoGrow(textarea) {
  const fit = function () {
    if (!textarea.isConnected) return;
    textarea.style.height = 'auto';
    textarea.style.height = (textarea.scrollHeight + textarea.offsetHeight - textarea.clientHeight) + 'px';
  };
  textarea.addEventListener('input', fit);
  textarea.addEventListener('focus', fit);
  window.requestAnimationFrame(fit);
}

// Adresse (slug): als Text unter ihrem Quellfeld (Präfix aus dem Schema, z. B. „/aktuelles/“), erst der
// Stift macht sie zum Eingabefeld; leer steht da, woraus sie beim Speichern entsteht.
export function slugField(look, field, input, sourceLabel) {
  const box = document.createElement('div');
  box.className = look.slug;
  const text = document.createElement('span');
  text.className = look.slugText;
  const auto = ENTRY_TEXT.slugAuto.replace('{name}', function () { return sourceLabel || fieldLabel(field); });
  const show = function () {
    text.textContent = input.value ? (field.prefix || '') + input.value : auto;
    text.classList.toggle(look.slugAuto, !input.value);
  };
  let editing = false;
  // Beim Bearbeiten bleibt nur das Präfix als Text vor dem Feld.
  const edit = symbolButton('pencil', ENTRY_TEXT.slugEdit, look.iconButton, function () {
    editing = true;
    text.textContent = field.prefix || '';
    text.classList.remove(look.slugAuto);
    text.hidden = !field.prefix;
    edit.hidden = true;
    input.hidden = false;
    input.focus();
  });
  input.className = look.slugInput;
  input.hidden = true;
  input.setAttribute('aria-label', fieldLabel(field));
  input.addEventListener('input', function () { if (!editing) show(); });
  show();
  box.append(text, edit, input);
  return box;
}

// Knopf einer Zeile mit Zeichen statt Text (↑/↓); label für Screenreader und Tooltip.
export function rowButton(text, label, className, onClick) {
  const button = editorButton(text, className, onClick);
  button.title = label;
  button.setAttribute('aria-label', label);
  return button;
}
