import { editorButton } from '../buttons.js';
import { richTextEditor } from '../richtext.js';
import { ENTRY_TEXT, fieldLabel } from './text.js';
import { INPUT_TYPES, INPUT_TYPE_TEXT, INPUT_MODES, formatInputValue, fieldBox, selectInput, imageField, fileField, iconField, symbolButton, autoGrow, slugField, rowButton } from './inputs.js';
import { galleryImage, galleryField } from './gallery.js';

// Ein Feld des Formulars aus dem Schema (buildField) samt den zusammengesetzten Feldarten list und blocks und
// der Sichtbarkeit nach showWhen.

// Eingabefelder, die focus() bzw. eine neue Zeile in list zuerst anspricht.
const FOCUS_TARGET = 'input:not([type="file"]):not([type="hidden"]):not([hidden]), select, textarea:not([hidden]), [contenteditable="true"]';

export function buildField(field, rawValue, ctx) {
  if (field.type === 'blocks') return blocksField(field, rawValue, ctx);
  if (field.type === 'list') {
    const image = galleryImage(field);
    return image ? galleryField(field, rawValue, ctx, image) : listField(field, rawValue, ctx);
  }
  const look = ctx.look;
  const value = formatInputValue(field, rawValue);
  let input;
  let box;
  if (field.type === 'boolean') {
    input = document.createElement('input');
    input.type = 'checkbox';
    input.checked = value !== '' && value !== '0';
    box = document.createElement('label');
    box.className = look.checkbox;
    const line = document.createElement('span');
    line.append(input, ' ' + fieldLabel(field));
    box.appendChild(line);
  } else if (field.type === 'richtext' || field.type === 'textarea') {
    input = document.createElement('textarea');
    input.value = value;
    if (field.type === 'textarea') autoGrow(input);
  } else if (field.type === 'select') {
    input = selectInput(field, value, ctx.notify);
  } else {
    input = document.createElement('input');
    input.type = Object.prototype.hasOwnProperty.call(INPUT_TYPES, field.type) ? INPUT_TYPES[field.type] : INPUT_TYPE_TEXT;
    if (Object.prototype.hasOwnProperty.call(INPUT_MODES, field.type)) input.inputMode = INPUT_MODES[field.type];
    input.value = value;
  }
  // Beispiel im leeren Feld (placeholder aus dem Schema, z. B. „z. B. 8–12, 14–18“).
  if (field.placeholder && (input.tagName === 'INPUT' || input.tagName === 'TEXTAREA')) input.placeholder = field.placeholder;
  input.name = field.name;
  // Ein verstecktes Pflichtfeld kann der Browser nicht melden; das prüft check().
  if (field.required && field.type !== 'richtext') input.required = true;
  if (field.type === 'image') {
    box = imageField(look, field, input, ctx.notify, ctx.uploads);
  } else if (field.type === 'file') {
    box = fileField(look, field, input, ctx.notify, ctx.uploads);
  } else if (field.type === 'icon') {
    box = iconField(look, field, input, ctx.notify);
  } else if (field.type === 'slug' && ctx.slugSource && ctx.slugSource(field.from)) {
    box = slugField(look, field, input, ctx.slugSource(field.from));
  } else if (field.type === 'richtext') {
    const editor = richTextEditor(input);
    ctx.editors.push({ field: field, input: input, editor: editor, row: ctx.row });
    box = fieldBox(look, field, 'div');
    box.appendChild(editor.element);
  } else if (!box) {
    box = fieldBox(look, field, 'label');
    box.appendChild(input);
  }
  return {
    box: box,
    input: input,
    read: function () { return field.type === 'boolean' ? (input.checked ? '1' : '0') : input.value; }
  };
}

// Leerer Wert einer Zeile wie auf dem Server (plugin_schema_list_values): leer, leeres Kästchen oder keine Zeile.
function emptyRowValue(field, value) {
  return value === '' || (field.type === 'boolean' && value === '0') || (Array.isArray(value) && value.length === 0);
}

// Erstes Eingabefeld in element fokussieren; liefert, ob es eines gab.
export function focusFirst(element) {
  const first = element.querySelector(FOCUS_TARGET);
  if (first) first.focus();
  return Boolean(first);
}

// Feld der Art list: je Zeile eine Karte mit den Unterfeldern, ↑/↓ (am Rand ausgeblendet) und
// Entfernen, darunter „+ <itemLabel> hinzufügen“. Leere Zeilen fallen wie auf dem Server weg, ihre
// Pflicht-Unterfelder gelten nicht (ctx.beforeCheck, check()); min/max prüft der Server. Änderungen
// melden sich als input am Formular (ungespeicherte Eingaben). read() = Zeilen in der angezeigten Reihenfolge.
function listField(field, value, ctx) {
  const look = ctx.look;
  const box = fieldBox(look, field, 'div');
  const list = document.createElement('div');
  list.className = look.list;
  const rows = [];
  const changed = function () { list.dispatchEvent(new Event('input', { bubbles: true })); };
  const refresh = function () {
    rows.forEach(function (row, index) {
      row.up.hidden = index === 0;
      row.down.hidden = index === rows.length - 1;
    });
  };
  const addRow = function (values) {
    const card = document.createElement('div');
    card.className = look.listRow;
    const row = { card: card };
    const rowCtx = Object.assign({}, ctx, { row: row });
    const fields = (Array.isArray(field.fields) ? field.fields : []).map(function (sub) {
      const built = buildField(sub, values && values[sub.name] != null ? values[sub.name] : '', rowCtx);
      card.appendChild(built.box);
      return { field: sub, built: built };
    });
    row.read = function () {
      const data = {};
      fields.forEach(function (sub) { data[sub.field.name] = sub.built.read(); });
      return data;
    };
    row.empty = function () {
      return fields.every(function (sub) { return emptyRowValue(sub.field, sub.built.read()); });
    };
    // Pflicht nur für Zeilen mit Inhalt; Texteditoren prüft check() über row.empty().
    row.require = function () {
      const filled = !row.empty();
      fields.forEach(function (sub) {
        if (sub.field.required && sub.field.type !== 'richtext') sub.built.input.required = filled;
      });
    };
    const move = function (step, button, other) {
      const from = rows.indexOf(row);
      const to = from + step;
      if (to < 0 || to >= rows.length) return;
      rows.splice(from, 1);
      rows.splice(to, 0, row);
      list.insertBefore(card, step < 0 ? rows[to + 1].card : rows[to - 1].card.nextSibling);
      refresh();
      (button.hidden ? other : button).focus();
      changed();
    };
    const remove = function () {
      const index = rows.indexOf(row);
      rows.splice(index, 1);
      card.remove();
      refresh();
      const next = rows[index] || rows[index - 1];
      if (!next || !focusFirst(next.card)) add.focus();
      changed();
    };
    const actions = document.createElement('div');
    actions.className = look.listRowActions;
    row.up = rowButton(ENTRY_TEXT.rowUp, ENTRY_TEXT.rowUpLabel, look.picker, function () { move(-1, row.up, row.down); });
    row.down = rowButton(ENTRY_TEXT.rowDown, ENTRY_TEXT.rowDownLabel, look.picker, function () { move(1, row.down, row.up); });
    actions.append(row.up, row.down, editorButton(ENTRY_TEXT.remove, look.picker, remove));
    card.appendChild(actions);
    rows.push(row);
    list.appendChild(card);
    refresh();
    return card;
  };
  const name = field.itemLabel;
  const add = editorButton(name ? ENTRY_TEXT.addRow.replace('{name}', function () { return name; }) : ENTRY_TEXT.addRowFallback, look.picker, function () {
    focusFirst(addRow(null));
    changed();
  });
  (Array.isArray(value) ? value : []).forEach(addRow);
  ctx.beforeCheck.push(function () { rows.forEach(function (row) { row.require(); }); });
  box.append(list, add);
  return {
    box: box,
    input: null,
    read: function () { return rows.map(function (row) { return row.read(); }); }
  };
}

// Kurzfassung eines eingeklappten Blocks im Kopf: Anfang des Textes, Bildtext oder Zahl der Fotos/Downloads.
const BLOCK_SUMMARY_LENGTH = 80;
function blockSummary(data) {
  const count = function (text, rows) { return Array.isArray(rows) && rows.length ? text.replace('{count}', String(rows.length)) : ''; };
  if (Array.isArray(data.bilder)) return count(ENTRY_TEXT.blockImages, data.bilder);
  if (Array.isArray(data.dateien)) return count(ENTRY_TEXT.blockFiles, data.dateien);
  // Text über DOMParser: im geparsten Dokument lädt und läuft nichts (auch kein onerror an Bildern).
  const parsed = new DOMParser().parseFromString(String(data.text || ''), 'text/html');
  const text = (parsed.body.textContent || '').replace(/\s+/g, ' ').trim();
  return text.length > BLOCK_SUMMARY_LENGTH ? text.slice(0, BLOCK_SUMMARY_LENGTH - 1) + '…' : text;
}

// Feld der Art blocks (kleiner Builder): je Block eine Karte mit Art, ↑/↓, Entfernen und den Feldern seiner
// Art (field.blockTypes vom Server, z. B. Fotos als Bildraster); Ziehen am Kopf verschiebt die Karte. Darunter
// je erlaubter Art „+ Text“, „+ Bild“ …. Vorhandene Blöcke starten eingeklappt (Kopf mit Kurzfassung, blockSummary). Leere Blöcke fallen wie auf dem Server weg, ihre Pflichtfelder gelten
// nicht (ctx.beforeCheck); min/max prüft der Server. read() = [{ type, feld: wert }] in der angezeigten Reihenfolge.
function blocksField(field, value, ctx) {
  const look = ctx.look;
  const types = field.blockTypes && typeof field.blockTypes === 'object' ? field.blockTypes : {};
  const box = fieldBox(look, field, 'div');
  const list = document.createElement('div');
  list.className = look.blocks;
  const max = Number(field.max) > 0 ? Number(field.max) : Infinity;
  const rows = [];
  let dragged = null;
  const changed = function () { list.dispatchEvent(new Event('input', { bubbles: true })); };
  const refresh = function () {
    rows.forEach(function (row, index) {
      row.up.disabled = index === 0;
      row.down.disabled = index === rows.length - 1;
    });
    adds.hidden = rows.length >= max;
  };
  const move = function (row, to) {
    const from = rows.indexOf(row);
    if (to < 0 || to >= rows.length || to === from) return;
    rows.splice(from, 1);
    rows.splice(to, 0, row);
    list.insertBefore(row.card, rows[to + 1] ? rows[to + 1].card : null);
    refresh();
    changed();
  };
  const addBlock = function (type, values) {
    const def = types[type];
    if (!def || !Array.isArray(def.fields)) return null;
    const card = document.createElement('div');
    card.className = look.block;
    const head = document.createElement('div');
    head.className = look.blockHead;
    head.title = ENTRY_TEXT.blockMove;
    const title = document.createElement('span');
    title.className = look.blockTitle;
    title.textContent = def.label;
    const summary = document.createElement('span');
    summary.className = look.blockSummary;
    const body = document.createElement('div');
    body.className = look.blockBody;
    const row = { card: card, type: type };
    // Einklappen: nur der Kopf mit Kurzfassung bleibt; die Felder gehen trotzdem mit.
    row.collapse = function (on) {
      card.classList.toggle(look.blockCollapsed, on);
      body.hidden = on;
      summary.textContent = on ? blockSummary(row.read()) : '';
      toggle.title = on ? ENTRY_TEXT.blockExpand : ENTRY_TEXT.blockCollapse;
      toggle.setAttribute('aria-label', toggle.title);
      toggle.setAttribute('aria-expanded', String(!on));
    };
    const toggle = symbolButton('chevronDown', ENTRY_TEXT.blockCollapse, look.iconButton, function () { row.collapse(!body.hidden); });
    const rowCtx = Object.assign({}, ctx, { row: row });
    row.up = rowButton(ENTRY_TEXT.rowUp, ENTRY_TEXT.rowUpLabel, look.iconButton, function () { move(row, rows.indexOf(row) - 1); });
    row.down = rowButton(ENTRY_TEXT.rowDown, ENTRY_TEXT.rowDownLabel, look.iconButton, function () { move(row, rows.indexOf(row) + 1); });
    const remove = symbolButton('trash', ENTRY_TEXT.blockRemove, look.iconButton, function () {
      const index = rows.indexOf(row);
      rows.splice(index, 1);
      card.remove();
      refresh();
      const next = rows[index] || rows[index - 1];
      (next ? next.up : adds.querySelector('button')).focus();
      changed();
    });
    head.append(toggle, title, summary, row.up, row.down, remove);
    card.append(head, body);
    title.addEventListener('click', function () { row.collapse(!body.hidden); });
    const fields = def.fields.map(function (sub) {
      const built = buildField(sub, values && values[sub.name] != null ? values[sub.name] : (sub.type === 'list' ? [] : ''), rowCtx);
      body.appendChild(built.box);
      return { field: sub, built: built };
    });
    row.read = function () {
      const data = { type: type };
      fields.forEach(function (sub) { data[sub.field.name] = sub.built.read(); });
      return data;
    };
    row.empty = function () {
      return fields.every(function (sub) { return emptyRowValue(sub.field, sub.built.read()); });
    };
    // Vor dem Prüfen: Ein gefüllter Block mit leerem Pflichtfeld klappt auf, damit der Browser bzw. check() es zeigen kann.
    row.require = function () {
      const filled = !row.empty();
      fields.forEach(function (sub) {
        if (sub.field.required && sub.field.type !== 'richtext' && sub.built.input) sub.built.input.required = filled;
      });
      const missing = filled && fields.some(function (sub) { return sub.field.required && emptyRowValue(sub.field, sub.built.read()); });
      if (missing || (filled && body.querySelector(':invalid'))) row.collapse(false);
    };
    // Ziehen nur am Kopf; Bildraster und Listen im Block ziehen ihre eigenen Kacheln.
    head.addEventListener('pointerdown', function (event) {
      if (!event.target.closest('button') && event.target !== title) card.draggable = true;
    });
    card.addEventListener('dragstart', function (event) {
      if (event.target !== card) return;
      dragged = row;
      event.dataTransfer.effectAllowed = 'move';
    });
    card.addEventListener('dragend', function () {
      card.draggable = false;
      dragged = null;
    });
    card.addEventListener('dragover', function (event) {
      if (!dragged || dragged === row) return;
      event.preventDefault();
      event.dataTransfer.dropEffect = 'move';
    });
    card.addEventListener('drop', function (event) {
      if (!dragged || dragged === row) return;
      event.preventDefault();
      move(dragged, rows.indexOf(row));
    });
    rows.push(row);
    list.appendChild(card);
    // Vorhandene Blöcke starten eingeklappt (Überblick), neu angelegte offen.
    if (values) row.collapse(true);
    refresh();
    return row;
  };
  const adds = document.createElement('div');
  adds.className = look.blockAdd;
  Object.keys(types).forEach(function (type) {
    const label = ENTRY_TEXT.addBlock.replace('{name}', function () { return types[type].label; });
    adds.appendChild(editorButton(label, look.picker, function () {
      const row = addBlock(type, null);
      if (row && !focusFirst(row.card)) row.up.focus();
      changed();
    }));
  });
  (Array.isArray(value) ? value : []).forEach(function (block) {
    if (block && typeof block === 'object') addBlock(block.type, block);
  });
  ctx.beforeCheck.push(function () { rows.forEach(function (row) { row.require(); }); });
  box.append(list, adds);
  refresh();
  return {
    box: box,
    input: null,
    read: function () { return rows.map(function (row) { return row.read(); }); }
  };
}

// Feld nur sichtbar, solange ein anderes Feld einen bestimmten Wert hat (showWhen: { field, value }; nur
// Link und Adresse der Content-Typen je nach „Beim Klick“, aus Schemas entfernt der Server es). Versteckte
// Felder gehen trotzdem mit, damit beim Umschalten nichts verloren geht; ob er sie übernimmt, entscheidet der Server.
export function applyShowWhen(schema, fields) {
  schema.forEach(function (field) {
    const when = field.showWhen;
    const source = when ? fields[when.field] : null;
    if (!source) return;
    const box = fields[field.name].box;
    const update = function () { box.hidden = source.read() !== when.value; };
    source.box.addEventListener('change', update);
    update();
  });
}
