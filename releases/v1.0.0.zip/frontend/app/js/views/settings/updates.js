import { state, setMessage, formatDate } from '../../../../shared/core.js';
import { forceRemoteCheck, rollback, installUpdate } from '../../update.js';

// Karte „Updates“ und die Zeile „Bezeichnung – Wert“ (row), die auch System, Datenbank und Backup nutzen.

export function row(label, value) {
  const r = document.createElement('div');
  r.className = 'update-card__row';
  const a = document.createElement('small');
  a.textContent = label;
  const b = document.createElement('span');
  b.textContent = value;
  r.appendChild(a);
  r.appendChild(b);
  return r;
}

export function renderUpdates() {
  const el = document.getElementById('updateSection');
  if (!el) return;
  el.innerHTML = '';
  const status = state.updateStatus;
  if (!status) {
    el.appendChild(row('Status', 'Unbekannt'));
    return;
  }

  el.appendChild(row('Aktuelle Version', status.currentVersion || '–'));
  // Mehrere Websites auf einem Server: Updates kommen per Git-Tag, nur die Version, ohne „Jetzt prüfen“ und „Rollback“.
  if (!status.multiSite) {
    el.appendChild(row('Verfügbar', status.latestVersion || '–'));
    el.appendChild(row('Letzte Prüfung', formatDate(status.lastCheck)));
  }
  el.appendChild(row('Auto-Update', status.enabled ? 'aktiviert' : 'deaktiviert'));

  // phpTooOld: Das Update braucht ein neueres PHP, installieren geht hier nicht.
  if (!status.multiSite && (status.phpTooOld || status.lastError)) {
    const errNote = document.createElement('div');
    errNote.className = 'update-card__notes';
    errNote.textContent = status.phpTooOld || status.lastError;
    el.appendChild(errNote);
  }

  if (status.hasUpdate && status.notes) {
    const notes = document.createElement('div');
    notes.className = 'update-card__notes';
    notes.textContent = status.notes;
    el.appendChild(notes);
  }

  const actions = document.createElement('div');
  actions.className = 'update-card__actions';

  const checkBtn = document.createElement('button');
  checkBtn.type = 'button';
  checkBtn.className = 'secondary';
  checkBtn.textContent = 'Jetzt prüfen';
  checkBtn.addEventListener('click', function () {
    checkBtn.disabled = true;
    setMessage(document.getElementById('updateMessage'), 'Prüfe…', true);
    forceRemoteCheck()
      .then(function () {
        setMessage(document.getElementById('updateMessage'), 'Prüfung abgeschlossen.', true);
      })
      .catch(function (e) {
        setMessage(document.getElementById('updateMessage'), e.message, false);
      })
      .finally(function () { checkBtn.disabled = false; });
  });
  if (!status.multiSite) actions.appendChild(checkBtn);

  if (status.hasUpdate && !status.phpTooOld) {
    const installBtn = document.createElement('button');
    installBtn.type = 'button';
    installBtn.textContent = 'Update ' + status.latestVersion + ' installieren';
    installBtn.addEventListener('click', function () {
      const label = installBtn.textContent;
      installBtn.disabled = true;
      installBtn.textContent = 'Installiere…';
      // Den neuen Stand zeichnet onUpdateStatusChange (setUpdateStatus in installUpdate).
      installUpdate()
        .then(function (data) {
          setMessage(document.getElementById('updateMessage'),
            'Installiert: ' + (data.previousVersion || '?') + ' → ' + (data.newVersion || '?'), true);
        })
        .catch(function (e) {
          setMessage(document.getElementById('updateMessage'), e.message, false);
          installBtn.disabled = false;
          installBtn.textContent = label;
        });
    });
    actions.appendChild(installBtn);
  }

  if (status.rollbackAvailable) {
    const rb = document.createElement('button');
    rb.type = 'button';
    rb.className = 'secondary';
    rb.textContent = 'Rollback';
    rb.addEventListener('click', function () {
      if (!window.confirm('Letzte Aktualisierung zurücknehmen?')) return;
      rb.disabled = true;
      rollback()
        .then(function (data) {
          setMessage(document.getElementById('updateMessage'),
            'Zurückgesetzt auf ' + (data.currentVersion || '?'), true);
        })
        .catch(function (e) {
          setMessage(document.getElementById('updateMessage'), e.message, false);
          rb.disabled = false;
        });
    });
    actions.appendChild(rb);
  }

  el.appendChild(actions);
}
