import { state } from '../../../../shared/core.js';
import { dom, updateDom } from '../../shell.js';
import { onUpdateStatusChange } from '../../update.js';
import { closeModal } from '../../modal.js';
import { SAVE_KEY_ATTR } from '../../save-button.js';
import { loadConfig, saveConfig } from './site.js';
import { loadMailConfig, saveMailConfig, deleteMailConfig, sendTestMail } from './mail.js';
import { renderUpdates } from './updates.js';
import { loadSystemChecks } from './system.js';
import { loadDbStatus, stopMigrationPoll } from './database.js';
import { loadBackupStatus } from './backup.js';

// Ansicht „Einstellungen“: alle Karten in einer Vorlage; mount verdrahtet die Karten aus den Dateien daneben.

const TEMPLATE = `
  <section class="view-area">
    <div class="card-grid">
      <div class="view-card span-6">
        <div class="topbar">
          <strong>Einstellungen</strong>
          <p id="settingsMessage" class="message"></p>
          <button id="settingsSaveButton" type="button" ${SAVE_KEY_ATTR} disabled>Speichern</button>
        </div>
        <form id="settingsForm" class="settings-form">
          <label class="field"><small>Name</small><input name="name" type="text"></label>
          <label class="field"><small>Tagline</small><input name="tagline" type="text"></label>
          <label class="field"><small>Website-URL</small><input name="url" type="url"></label>
          <label class="field"><small>E-Mail</small><input name="email" type="email"></label>
          <label class="field"><small>Inhaber</small><input name="owner" type="text"></label>
          <label class="field"><small>Locale</small><input name="locale" type="text"></label>
          <label class="field"><small>Vorschaubild für Google und Social Media (Adresse, z. B. /assets/img/vorschau.jpg, ideal 1200 × 630)</small><input name="image" type="text" placeholder="/assets/img/vorschau.jpg"></label>
        </form>
      </div>
      <div class="view-card span-6">
        <div class="topbar">
          <strong>Updates</strong>
          <p id="updateMessage" class="message"></p>
        </div>
        <div id="updateSection" class="update-card"></div>
      </div>
      <div id="settingsSystemCard" class="view-card span-12">
        <div class="topbar">
          <strong>System</strong>
          <p id="systemMessage" class="message"></p>
        </div>
        <div id="systemChecks" class="update-card"></div>
      </div>
      <div id="settingsDbCard" class="view-card span-12">
        <div class="topbar">
          <strong>Datenbank</strong>
          <p id="dbSettingsMessage" class="message"></p>
        </div>
        <div id="dbSettingsStatus" class="update-card"></div>
        <div id="dbArchive" class="generic-list"></div>
      </div>
      <div id="settingsBackupCard" class="view-card span-12">
        <div class="topbar">
          <strong>Backup</strong>
          <p id="backupMessage" class="message"></p>
        </div>
        <div id="backupStatus" class="update-card"></div>
      </div>
      <div class="view-card span-12">
        <div class="topbar">
          <strong>E-Mail / SMTP</strong>
          <p id="mailSettingsMessage" class="message"></p>
        </div>
        <form id="mailSettingsForm" class="settings-form">
          <label class="field"><small>Host</small><input name="host" type="text" autocomplete="off"></label>
          <label class="field"><small>Port</small><input name="port" type="number" min="1" max="65535" value="587"></label>
          <label class="field"><small>Verschlüsselung</small>
            <select name="encryption">
              <option value="tls">STARTTLS</option>
              <option value="ssl">SSL/TLS</option>
              <option value="none">Keine</option>
            </select>
          </label>
          <label class="field"><small>Benutzer</small><input name="username" type="text" autocomplete="username"></label>
          <label class="field"><small>Passwort</small><input name="password" type="password" autocomplete="new-password" placeholder="Leer lassen: bestehendes Passwort behalten"></label>
          <label class="field"><small>Absender-E-Mail</small><input name="fromEmail" type="email"></label>
          <label class="field"><small>Absender-Name</small><input name="fromName" type="text"></label>
          <label class="field"><small>Standard-Empfänger</small><input name="defaultRecipient" type="email"></label>
          <label class="field"><small>Test-Empfänger</small><input name="testRecipient" type="email"></label>
        </form>
        <p id="mailSettingsStatus" class="mail-status"></p>
        <div class="form-actions">
          <button id="mailSettingsSaveButton" type="button" ${SAVE_KEY_ATTR}>SMTP speichern</button>
          <button id="mailSettingsTestButton" type="button" class="secondary">Test senden</button>
          <button id="mailSettingsDeleteButton" type="button" class="secondary">SMTP deaktivieren</button>
        </div>
      </div>
    </div>
  </section>
`;

let unsubscribed = false;

export function mount(outlet) {
  outlet.innerHTML = TEMPLATE;
  updateDom({
    settingsForm: outlet.querySelector('#settingsForm'),
    settingsSaveButton: outlet.querySelector('#settingsSaveButton'),
    settingsMessage: outlet.querySelector('#settingsMessage')
  });
  dom.settingsSaveButton.addEventListener('click', saveConfig);
  outlet.querySelector('#mailSettingsSaveButton').addEventListener('click', saveMailConfig);
  outlet.querySelector('#mailSettingsTestButton').addEventListener('click', sendTestMail);
  outlet.querySelector('#mailSettingsDeleteButton').addEventListener('click', deleteMailConfig);
  loadConfig();
  loadMailConfig();
  // Sprungziel aus dem Dashboard erst anfahren, wenn die Karten darüber gefüllt sind.
  Promise.all([loadSystemChecks(), loadDbStatus(), loadBackupStatus()]).then(scrollToFocus);
  renderUpdates();
  if (!unsubscribed) {
    onUpdateStatusChange(renderUpdates);
    unsubscribed = true;
  }
}

export function unmount() {
  stopMigrationPoll();
  closeModal();
}

function scrollToFocus() {
  const card = state.settingsFocus && document.getElementById(state.settingsFocus);
  state.settingsFocus = null;
  if (card) card.scrollIntoView();
}
