import { state, api, setMessage, formatDate } from '../../../../shared/core.js';
import { openModal, submitOnEnter } from '../../modal.js';
import { DB_FORM_FIELDS, readDbForm } from '../../db-form.js';
import { ENDPOINTS } from '../../../../shared/endpoints.js';
import { row } from './updates.js';

// Karte „Datenbank“: Stand, Umzug SQLite ↔ MySQL samt Fortschritt und Archiv der alten Datenbank.

const MIGRATION_PROGRESS = 'Umzug wird ausgeführt…';
// Läuft beim Laden ein Umzug (z. B. aus einem anderen Tab), fragt die Karte so oft nach.
const MIGRATION_POLL_MS = 3000;
const DB_DRIVER_LABELS = { sqlite: 'SQLite', mysql: 'MySQL' };
const DB_ARCHIVE_LABELS = { sqlite: 'SQLite-Datei vom ', mysql: 'MySQL-Daten vom ' };
const DB_ARCHIVE_CONFIRM = {
  sqlite: ' endgültig löschen?',
  mysql: ' endgültig löschen? Dabei werden auch die Plugin-Tabellen in dieser MySQL-Datenbank gelöscht.'
};
let migrationPoll = null;

function setDbMessage(text, ok) {
  setMessage(document.getElementById('dbSettingsMessage'), text, ok);
}

export function loadDbStatus() {
  return api(ENDPOINTS.database.status)
    .then(renderDbStatus)
    .catch(function (error) {
      setDbMessage(error.message, false);
    });
}

function renderDbStatus(data) {
  const el = document.getElementById('dbSettingsStatus');
  if (!el) return;
  el.innerHTML = '';
  state.dbArchiveReminder = data.dbArchiveReminder || null;
  el.appendChild(row('Aktiver Treiber', DB_DRIVER_LABELS[data.driver] || data.driver));
  // Warum der Knopf gesperrt ist: laufender Umzug bzw. fehlendes pdo_sqlite.
  const reason = data.migrationRunning || (data.driver === 'mysql' && data.sqliteMissing ? 'Nach SQLite umziehen geht nicht: ' + data.sqliteMissing : null);
  if (reason) {
    const note = document.createElement('div');
    note.className = 'update-card__notes';
    note.textContent = reason;
    el.appendChild(note);
  }

  const actions = document.createElement('div');
  actions.className = 'update-card__actions';
  const button = document.createElement('button');
  button.type = 'button';
  button.disabled = !!reason;
  if (data.driver === 'mysql') {
    button.textContent = 'Nach SQLite umziehen';
    button.addEventListener('click', migrateToSqlite);
  } else {
    button.textContent = 'Nach MySQL umziehen';
    button.addEventListener('click', openMysqlMigration);
  }
  actions.appendChild(button);
  el.appendChild(actions);

  renderDbArchive(data.archive || []);
  if (data.migrationRunning) startMigrationPoll(data.driver);
}

function startMigrationPoll(driverBefore) {
  if (migrationPoll) return;
  migrationPoll = setInterval(function () {
    api(ENDPOINTS.database.status)
      .then(function (data) {
        if (!migrationPoll || data.migrationRunning) return;
        stopMigrationPoll();
        const label = DB_DRIVER_LABELS[data.driver] || data.driver;
        // Das Ergebnis kennt nur der Tab, der umgezogen hat. Ohne Treiberwechsel
        // war es ein gescheiterter Umzug oder das Löschen von Altdaten: neutral melden.
        setDbMessage(data.driver !== driverBefore
          ? 'Umzug abgeschlossen. Aktiver Treiber: ' + label + '.'
          : 'Sperre aufgehoben, Treiber unverändert: ' + label + '.', true);
        renderDbStatus(data);
      })
      .catch(function (error) {
        if (migrationPoll) setDbMessage(error.message, false);
      });
  }, MIGRATION_POLL_MS);
}

export function stopMigrationPoll() {
  clearInterval(migrationPoll);
  migrationPoll = null;
}

function renderDbArchive(entries) {
  const el = document.getElementById('dbArchive');
  if (!el) return;
  el.innerHTML = '';
  if (!entries.length) return;
  const heading = document.createElement('h4');
  heading.className = 'db-archive__title';
  heading.textContent = 'Altdaten früherer Umzüge';
  el.appendChild(heading);
  const list = document.createElement('ul');
  entries.forEach(function (entry) {
    const item = document.createElement('li');
    item.className = 'generic-list__row';
    const title = document.createElement('span');
    title.className = 'generic-list__title';
    title.textContent = (DB_ARCHIVE_LABELS[entry.kind] || '') + formatDate(entry.createdAt.replace(' ', 'T')) +
      (entry.due ? ' – bitte prüfen und löschen' : '');
    const actions = document.createElement('div');
    actions.className = 'generic-list__actions';
    const del = document.createElement('button');
    del.type = 'button';
    del.className = 'secondary';
    del.textContent = 'Löschen';
    del.addEventListener('click', function () { deleteDbArchive(entry, del); });
    actions.appendChild(del);
    item.appendChild(title);
    item.appendChild(actions);
    list.appendChild(item);
  });
  el.appendChild(list);
}

function migrationText(data) {
  const counts = Object.keys(data.counts || {}).map(function (table) {
    return table + ': ' + data.counts[table];
  }).join(', ');
  const done = 'Umzug abgeschlossen' + (counts ? ' (' + counts + ' Zeilen)' : '') + '.';
  return data.warning ? done + ' ' + data.warning : done;
}

function migrationDone(data) {
  // Ein Hinweis (z. B. Altdaten nicht archiviert) braucht Handarbeit: als Warnung zeigen.
  setDbMessage(migrationText(data), !data.warning);
  return loadDbStatus();
}

// Fehler immer auch in der Karte zeigen und den Stand neu laden (z. B. nach einem Timeout).
function migrationFailed(error) {
  setDbMessage(error.message, false);
  return loadDbStatus();
}

function migrateToSqlite(event) {
  if (!window.confirm('Plugin-Daten von MySQL nach SQLite umziehen? Plugins können währenddessen nicht speichern.')) return;
  event.currentTarget.disabled = true;
  setDbMessage(MIGRATION_PROGRESS, true);
  api(ENDPOINTS.database.migrate, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ target: 'sqlite' })
  })
    .then(migrationDone)
    .catch(migrationFailed);
}

function openMysqlMigration() {
  const modal = openModal({
    title: 'Nach MySQL umziehen',
    bodyHtml: `<form id="dbMigrateForm" class="settings-form">${DB_FORM_FIELDS}
      <div class="form-actions"><button type="button" class="secondary" data-action="test">Verbindung testen</button></div>
    </form>`,
    submitLabel: 'Umziehen',
    // Der Umzug läuft weiter, wenn die Ansicht wechselt: Dialog bleibt bis zum Ergebnis.
    keepOnUnmount: true,
    onSubmit(modalCtx) {
      const form = modalCtx.body.querySelector('#dbMigrateForm');
      if (!window.confirm('Plugin-Daten von SQLite nach MySQL umziehen? Plugins können währenddessen nicht speichern.')) return;
      modalCtx.setBusy(true);
      modalCtx.setMessage(MIGRATION_PROGRESS, true);
      setDbMessage(MIGRATION_PROGRESS, true);
      api(ENDPOINTS.database.migrate, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({ target: 'mysql' }, readDbForm(form)))
      })
        .then(function (data) {
          modalCtx.setBusy(false);
          // Ansicht inzwischen verlassen (Dialog blieb offen): Ergebnis im Dialog
          // zeigen, umgezogen ist schon – nur noch „Schließen“ anbieten.
          if (!document.getElementById('settingsDbCard')) {
            // Inzwischen ersetzt: Die Knöpfe gehören schon dem neuen Dialog.
            if (!modalCtx.isOpen()) return;
            modalCtx.setMessage(migrationText(data), !data.warning);
            form.classList.add('hidden');
            modalCtx.submitButton.classList.add('hidden');
            modalCtx.cancelButton.textContent = 'Schließen';
            return;
          }
          modalCtx.close('submit');
          return migrationDone(data);
        })
        .catch(function (error) {
          modalCtx.setBusy(false);
          modalCtx.setMessage(error.message, false);
          migrationFailed(error);
        });
    }
  });
  const form = modal.body.querySelector('#dbMigrateForm');
  submitOnEnter(modal, form);
  form.querySelector('[data-action="test"]').addEventListener('click', function () {
    modal.setMessage('Teste Verbindung…', true);
    api(ENDPOINTS.database.test, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(readDbForm(form))
    })
      .then(function () { modal.setMessage('Verbindung klappt.', true); })
      .catch(function (error) { modal.setMessage(error.message, false); });
  });
}

function deleteDbArchive(entry, button) {
  if (!window.confirm('Altdaten „' + entry.name + '“' + (DB_ARCHIVE_CONFIRM[entry.kind] || DB_ARCHIVE_CONFIRM.sqlite))) return;
  sendDbArchiveDelete(entry, button, false);
}

// MySQL der Altdaten nicht erreichbar: Die Zeile bietet dann an, nur die Datei zu löschen.
function offerForceDelete(entry, button) {
  const actions = button.parentNode;
  if (!actions || actions.querySelector('[data-action="force"]')) return;
  const force = document.createElement('button');
  force.type = 'button';
  force.className = 'secondary';
  force.dataset.action = 'force';
  force.textContent = 'Nur Zugangsdaten löschen';
  force.addEventListener('click', function () {
    if (!window.confirm('Nur die Zugangsdaten „' + entry.name + '“ löschen? Die Tabellen bleiben dann in MySQL und müssen von Hand gelöscht werden.')) return;
    sendDbArchiveDelete(entry, force, true);
  });
  actions.insertBefore(force, button);
}

function sendDbArchiveDelete(entry, button, force) {
  button.disabled = true;
  api(ENDPOINTS.database.deleteArchive, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: entry.name, force: force })
  })
    .then(function (data) {
      state.dbArchiveReminder = data.dbArchiveReminder || null;
      renderDbArchive(data.archive || []);
      setDbMessage('Gelöscht.', true);
    })
    .catch(function (error) {
      setDbMessage(error.message, false);
      button.disabled = false;
      if (error.code === 'archive_db_failed') offerForceDelete(entry, button);
    });
}
