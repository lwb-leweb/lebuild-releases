import { state, api, download, copyToClipboard, setMessage } from '../../../../shared/core.js';
import { openModal } from '../../modal.js';
import { ENDPOINTS } from '../../../../shared/endpoints.js';
import { row } from './updates.js';

// Karte „Backup“: Stand der Sicherung, Schlüssel fürs Abholen, Download.

const BACKUP_KEY_CONFIRM = 'Neuen Backup-Schlüssel erzeugen? Der bisherige gilt sofort nicht mehr, das Abhol-Skript braucht dann den neuen.';

function setBackupMessage(text, ok) {
  setMessage(document.getElementById('backupMessage'), text, ok);
}

export function loadBackupStatus() {
  return api(ENDPOINTS.backup.status)
    .then(renderBackupStatus)
    .catch(function (error) {
      setBackupMessage(error.message, false);
    });
}

function renderBackupStatus(data) {
  const el = document.getElementById('backupStatus');
  if (!el) return;
  el.innerHTML = '';
  state.siteBackup = data.siteBackup || null;
  el.appendChild(row('Backup-Schlüssel', !data.configured ? 'nicht eingerichtet'
    : data.keyCreated ? 'eingerichtet seit ' + data.keyCreated : 'eingerichtet'));
  if (data.configured) el.appendChild(row('Letzte Sicherung', data.siteBackup.lastBackup));
  const note = document.createElement('div');
  note.className = 'update-card__notes';
  note.textContent = 'Mit dem Schlüssel holt das Abhol-Skript die Sicherung jede Nacht ab. Herunterladen geht auch ohne Schlüssel.';
  el.appendChild(note);

  const actions = document.createElement('div');
  actions.className = 'update-card__actions';
  const create = document.createElement('button');
  create.type = 'button';
  create.textContent = data.configured ? 'Neuen Backup-Schlüssel erzeugen' : 'Backup-Schlüssel erzeugen';
  create.addEventListener('click', function () { createBackupKey(create, data.configured); });
  const get = document.createElement('button');
  get.type = 'button';
  get.className = 'secondary';
  get.textContent = 'Backup herunterladen';
  get.addEventListener('click', function () { downloadBackup(get); });
  actions.appendChild(create);
  actions.appendChild(get);
  el.appendChild(actions);
}

function createBackupKey(button, replace) {
  if (replace && !window.confirm(BACKUP_KEY_CONFIRM)) return;
  button.disabled = true;
  api(ENDPOINTS.backup.createKey, { method: 'POST' })
    .then(function (data) {
      renderBackupStatus(data);
      setBackupMessage('Backup-Schlüssel erzeugt.', true);
      showBackupKey(data.key);
    })
    .catch(function (error) {
      setBackupMessage(error.message, false);
      button.disabled = false;
    });
}

// Klartext nur in diesem Dialog; beim Schließen leert das Modal seinen Inhalt.
function showBackupKey(key) {
  const modal = openModal({
    title: 'Backup-Schlüssel',
    bodyHtml: '<p>Diesen Schlüssel jetzt ins Abhol-Skript übernehmen. Er wird nicht noch einmal angezeigt; geht er verloren, einfach einen neuen erzeugen.</p>' +
      '<label class="field"><small>Schlüssel</small><input type="text" readonly spellcheck="false" autocomplete="off"></label>',
    submitLabel: 'Kopieren',
    cancelLabel: 'Schließen',
    onSubmit: function (ctx) {
      copyToClipboard(input)
        .then(function () { ctx.setMessage('Kopiert.', true); })
        .catch(function (error) { ctx.setMessage(error.message, false); });
    }
  });
  const input = modal.body.querySelector('input');
  input.value = key;
  input.select();
}

function downloadBackup(button) {
  button.disabled = true;
  setBackupMessage('Sicherung wird erstellt…', true);
  download(ENDPOINTS.backup.download, { method: 'POST' })
    .then(function () {
      setBackupMessage('Sicherung heruntergeladen.', true);
    })
    .catch(function (error) {
      setBackupMessage(error.message, false);
    })
    .finally(function () {
      button.disabled = false;
    });
}
