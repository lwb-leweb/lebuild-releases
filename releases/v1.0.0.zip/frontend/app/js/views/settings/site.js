import { api, setMessage } from '../../../../shared/core.js';
import { dom } from '../../shell.js';
import { ENDPOINTS } from '../../../../shared/endpoints.js';

// Karte „Einstellungen“: Name, Website-URL, Vorschaubild … laden und speichern (api getConfig/saveConfig).

const SETTINGS_KEYS = ['name', 'tagline', 'url', 'email', 'owner', 'locale', 'image'];

export function loadConfig() {
  api(ENDPOINTS.settings.get)
    .then(function (data) {
      const cfg = data.config || {};
      SETTINGS_KEYS.forEach(function (key) {
        const input = dom.settingsForm.elements[key];
        if (input) input.value = cfg[key] || '';
      });
      // Erst mit geladenen Werten speicherbar: sonst überschreiben leere Felder Name, URL und E-Mail.
      dom.settingsSaveButton.disabled = false;
      setMessage(dom.settingsMessage, '', true);
    })
    .catch(function (error) {
      setMessage(dom.settingsMessage, error.message, false);
    });
}

export function saveConfig() {
  const cfg = {};
  SETTINGS_KEYS.forEach(function (key) {
    const input = dom.settingsForm.elements[key];
    if (input) cfg[key] = input.value;
  });
  // Gesperrt bis zur Antwort: ein zweiter Klick oder Strg+S speichert nicht doppelt.
  const button = dom.settingsSaveButton;
  button.disabled = true;
  api(ENDPOINTS.settings.save, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(cfg)
  })
    .then(function () {
      setMessage(dom.settingsMessage, 'Gespeichert.', true);
    })
    .catch(function (error) {
      setMessage(dom.settingsMessage, error.message, false);
    })
    .finally(function () {
      button.disabled = false;
    });
}
