import { api, setMessage } from '../../../../shared/core.js';
import { ENDPOINTS } from '../../../../shared/endpoints.js';
import { row } from './updates.js';

// Karte „System“: Ergebnis der Systemprüfung.

export function loadSystemChecks() {
  return api(ENDPOINTS.system.checks)
    .then(function (data) {
      renderSystemChecks(data.checks || []);
      setMessage(document.getElementById('systemMessage'), '', true);
    })
    .catch(function (error) {
      setMessage(document.getElementById('systemMessage'), error.message, false);
    });
}

function renderSystemChecks(checks) {
  const el = document.getElementById('systemChecks');
  if (!el) return;
  el.innerHTML = '';
  checks.forEach(function (check) {
    const r = row(check.label, check.ok ? 'OK' : 'Mangel');
    r.lastChild.className = check.ok ? 'message ok' : 'message';
    el.appendChild(r);
    if (!check.ok) {
      const purpose = document.createElement('small');
      purpose.className = 'message';
      purpose.textContent = check.purpose;
      el.appendChild(purpose);
    }
  });
}
