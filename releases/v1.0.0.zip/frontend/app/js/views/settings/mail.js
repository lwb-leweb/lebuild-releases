import { api, setMessage } from '../../../../shared/core.js';
import { ENDPOINTS } from '../../../../shared/endpoints.js';

// Karte „E-Mail / SMTP“: Zugangsdaten laden, speichern, löschen und eine Test-Mail senden.

export function loadMailConfig() {
  api(ENDPOINTS.mail.get)
    .then(function (data) {
      fillMailForm(data.config || {});
      renderMailStatus(data.status || {}, data.config || {});
      setMailMessage('', true);
    })
    .catch(function (error) {
      setMailMessage(error.message, false);
    });
}

function fillMailForm(cfg) {
  const form = document.getElementById('mailSettingsForm');
  if (!form) return;
  form.elements.host.value = cfg.host || '';
  form.elements.port.value = cfg.port || 587;
  form.elements.encryption.value = cfg.encryption || 'tls';
  form.elements.username.value = cfg.username || '';
  form.elements.password.value = '';
  form.elements.fromEmail.value = cfg.fromEmail || '';
  form.elements.fromName.value = cfg.fromName || '';
  form.elements.defaultRecipient.value = cfg.defaultRecipient || '';
  form.elements.testRecipient.value = cfg.defaultRecipient || cfg.resolvedRecipient || '';
  form.elements.password.placeholder = cfg.passwordSet
    ? 'Gespeichertes Passwort behalten'
    : 'SMTP-Passwort';
}

function mailPayload() {
  const form = document.getElementById('mailSettingsForm');
  const fields = form.elements;
  return {
    host: fields.host.value,
    port: parseInt(fields.port.value, 10) || 587,
    encryption: fields.encryption.value,
    username: fields.username.value,
    password: fields.password.value,
    fromEmail: fields.fromEmail.value,
    fromName: fields.fromName.value,
    defaultRecipient: fields.defaultRecipient.value
  };
}

export function saveMailConfig() {
  const button = document.getElementById('mailSettingsSaveButton');
  if (button) button.disabled = true;
  api(ENDPOINTS.mail.save, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(mailPayload())
  })
    .then(function (data) {
      fillMailForm(data.config || {});
      renderMailStatus(data.status || {}, data.config || {});
      setMailMessage('SMTP gespeichert.', true);
    })
    .catch(function (error) {
      setMailMessage(error.message, false);
    })
    .finally(function () {
      if (button) button.disabled = false;
    });
}

export function deleteMailConfig() {
  if (!window.confirm('SMTP-Einstellungen löschen und auf PHP mail() zurückfallen?')) return;
  const button = document.getElementById('mailSettingsDeleteButton');
  if (button) button.disabled = true;
  api(ENDPOINTS.mail.delete, { method: 'POST' })
    .then(function (data) {
      fillMailForm(data.config || {});
      renderMailStatus(data.status || {}, data.config || {});
      setMailMessage('SMTP deaktiviert.', true);
    })
    .catch(function (error) {
      setMailMessage(error.message, false);
    })
    .finally(function () {
      if (button) button.disabled = false;
    });
}

export function sendTestMail() {
  const form = document.getElementById('mailSettingsForm');
  const button = document.getElementById('mailSettingsTestButton');
  const payload = mailPayload();
  const testRecipient = form.elements.testRecipient.value;
  const shouldSave = !!(payload.host || payload.username || payload.password || payload.fromEmail || payload.fromName || payload.defaultRecipient);
  const send = function () {
    return api(ENDPOINTS.mail.test, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ to: testRecipient })
    });
  };
  if (button) button.disabled = true;
  (shouldSave
    ? api(ENDPOINTS.mail.save, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
    .then(function (data) {
      fillMailForm(data.config || {});
      form.elements.testRecipient.value = testRecipient;
      renderMailStatus(data.status || {}, data.config || {});
      return send();
    })
    : send())
    .then(function (data) {
      setMailMessage('Testmail versendet (' + (data.transport || 'Mail') + ').', true);
    })
    .catch(function (error) {
      setMailMessage(error.message, false);
    })
    .finally(function () {
      if (button) button.disabled = false;
    });
}

function renderMailStatus(status, cfg) {
  const el = document.getElementById('mailSettingsStatus');
  if (!el) return;
  if (status.configured) {
    el.textContent = 'SMTP aktiv: ' + (cfg.host || 'Host') + ':' + (cfg.port || 587);
    el.className = 'mail-status ok';
    return;
  }
  if (status.mailFallback) {
    el.textContent = 'Fallback aktiv: PHP mail() wird genutzt, solange kein SMTP gespeichert ist.';
    el.className = 'mail-status ok';
    return;
  }
  if (status.mailFunction) {
    el.textContent = 'PHP mail() ist vorhanden, aber lokal ist kein Sendmail-Binary erreichbar. SMTP-Daten speichern.';
    el.className = 'mail-status';
    return;
  }
  el.textContent = 'Kein Mailversand verfügbar. SMTP-Daten speichern, bevor Mail-Plugins aktiviert werden.';
  el.className = 'mail-status';
}

function setMailMessage(text, ok) {
  setMessage(document.getElementById('mailSettingsMessage'), text, ok);
}
