import { api, postJson, setMessage, escapeHtml } from '../../../shared/core.js';
import { openModal, closeModal } from '../modal.js';
import { showToast } from '../router.js';
import { openEntryModal, entryTitle, deleteQuestion } from '../../../shared/entry-form/index.js';
import { ENDPOINTS } from '../../../shared/endpoints.js';

let pluginName = null;
// Name im Kopf wie in der Seitenleiste (Label aus dem Manifest), sonst der Slug.
let pluginLabel = '';
let outletEl = null;
let currentSchema = [];
// Endpoints je Aktion (active_plugin_admin_info): die eigenen des Plugins, sonst api/plugins/generic/.
let endpoints = {};
// Zählt Mount und Unmount mit; eine Antwort, die zu einem früheren Mount gehört (schneller Wechsel
// von Plugin A zu B), wird verworfen und zeigt weder Zeilen noch Formular von A.
let mountToken = 0;

const genericPluginView = {
  id: '__generic__',
  mount(outlet, ctx) {
    mountToken++;
    pluginName = ctx.pluginName;
    pluginLabel = (ctx.info && ctx.info.label) || ctx.pluginName;
    endpoints = (ctx.info && ctx.info.endpoints) || {};
    outletEl = outlet;
    renderShell();
    loadList();
  },
  unmount() {
    mountToken++;
    closeModal();
    pluginName = null;
    pluginLabel = '';
    outletEl = null;
    currentSchema = [];
    endpoints = {};
  }
};

export default genericPluginView;

function renderShell() {
  outletEl.innerHTML = `
    <section class="view-area generic-plugin-view">
      <div class="view-card span-12">
        <div class="topbar">
          <strong>${escapeHtml(pluginLabel)}</strong>
          <button type="button" id="newItemBtn">Neu</button>
        </div>
        <p id="genericMsg" class="message"></p>
        <div id="genericList" class="generic-list"></div>
      </div>
    </section>
  `;
  outletEl.querySelector('#newItemBtn').addEventListener('click', function () {
    openForm(null, currentSchema);
  });
}

// Hängt an eine Antwort: verwirft sie, wenn die Ansicht seit dem Aufruf neu gemountet wurde.
function current(handler) {
  const token = mountToken;
  return function (value) {
    if (token === mountToken) handler(value);
  };
}

function loadList() {
  api(endpointFor('list') + '?plugin=' + encodeURIComponent(pluginName))
    .then(current(function (data) {
      currentSchema = data.schema || [];
      renderList(data.rows || [], currentSchema);
    }))
    .catch(current(showError));
}

function renderList(rows, schema) {
  const list = document.getElementById('genericList');
  if (!list) return;

  if (!rows.length) {
    list.innerHTML = '<p class="message">Noch keine Einträge.</p>';
    return;
  }

  list.innerHTML = '<ul>' + rows.map(function (row) {
    const title = entryTitle(schema, row);
    return `
      <li class="generic-list__row" data-id="${row.id}">
        <span class="generic-list__title">${escapeHtml(title)}</span>
        <div class="generic-list__actions">
          <button type="button" data-action="edit" data-id="${row.id}">Bearbeiten</button>
          <button type="button" data-action="delete" data-id="${row.id}" class="secondary">Löschen</button>
        </div>
      </li>
    `;
  }).join('') + '</ul>';

  list.querySelectorAll('button[data-action="edit"]').forEach(function (button) {
    button.addEventListener('click', function () {
      openFormFromServer(parseInt(button.dataset.id, 10));
    });
  });
  list.querySelectorAll('button[data-action="delete"]').forEach(function (button) {
    button.addEventListener('click', function () {
      const id = parseInt(button.dataset.id, 10);
      const row = rows.find(function (entry) { return Number(entry.id) === id; });
      if (!window.confirm(deleteQuestion(schema, row))) return;
      postJson(endpointFor('delete'), { plugin: pluginName, id: id }).then(current(loadList)).catch(current(showError));
    });
  });
}

function openFormFromServer(id) {
  api(endpointFor('get') + '?plugin=' + encodeURIComponent(pluginName) + '&id=' + id)
    .then(current(function (data) {
      currentSchema = data.schema || currentSchema;
      openForm(data.row || null, currentSchema, data.version);
    }))
    .catch(current(showError));
}

function openForm(row, schema, version) {
  const name = pluginName;
  const saveUrl = endpointFor('save');
  openEntryModal(openModal, {
    schema: schema,
    row: row,
    notify: showToast,
    save: function (data, extra) {
      const body = Object.assign({ plugin: name, data: data }, extra);
      if (row && row.id) body.id = row.id;
      if (row && version) body.version = version;
      return postJson(saveUrl, body);
    },
    reload: row ? current(function () { openFormFromServer(row.id); }) : null,
    onSaved: current(loadList)
  });
}

function endpointFor(action) {
  return endpoints[action] || ENDPOINTS.plugins.generic[action];
}

function showError(error) {
  const msg = document.getElementById('genericMsg');
  if (msg) setMessage(msg, error.message || String(error), false);
}
