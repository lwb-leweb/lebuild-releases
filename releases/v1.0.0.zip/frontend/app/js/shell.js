import { state } from '../../shared/core.js';

// DOM der Verwaltung (Shell in app/index.html): Elemente der Seitenleiste und Ansichten, angemeldeter Benutzer.
// Nur die Verwaltung lädt diese Datei; der Seiten-Editor auf der Website kennt das DOM der Verwaltung nicht.

// Shell elements (always present). View-internal refs (previewFrame,
// settingsForm, ...) are registered by view modules via
// updateDom() when they mount, and cleared via clearViewDom() on unmount.
export const dom = {
  editorView: document.getElementById('editorView'),
  viewOutlet: document.getElementById('viewOutlet'),
  pagesButton: document.getElementById('pagesButton'),
  pagesCount: document.getElementById('pagesCount'),
  pluginsManageButton: document.getElementById('pluginsManageButton'),
  pluginsActiveList: document.getElementById('pluginsActiveList'),
  userAvatar: document.getElementById('userAvatar'),
  userName: document.getElementById('userName'),
  usersButton: document.getElementById('usersButton'),
  activityButton: document.getElementById('activityButton'),
  mediaButton: document.getElementById('mediaButton'),
  settingsButton: document.getElementById('settingsButton'),
  dashboardButton: document.getElementById('dashboardButton'),
  logoutButton: document.getElementById('logoutButton'),
  siteLink: document.getElementById('siteLink'),
  updateBanner: document.getElementById('updateBanner'),

  // View-internal refs — populated by view modules on mount
  previewFrame: null,
  settingsForm: null,
  settingsSaveButton: null,
  settingsMessage: null
};

const VIEW_DOM_KEYS = [
  'previewFrame',
  'settingsForm', 'settingsSaveButton', 'settingsMessage'
];

export function updateDom(refs) {
  Object.assign(dom, refs);
}

export function clearViewDom() {
  VIEW_DOM_KEYS.forEach(function (key) { dom[key] = null; });
}

// Angemeldeter Benutzer unten in der Seitenleiste: Anfangsbuchstabe als Avatar, Name (state.username).
export function renderUser() {
  const text = state.username || '';
  dom.userName.textContent = text;
  dom.userAvatar.textContent = text.charAt(0).toUpperCase();
}
