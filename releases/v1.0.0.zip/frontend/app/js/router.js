import { state, api, escapeHtml, ADMIN_URL, pageRoute } from '../../shared/core.js';
import { dom, clearViewDom } from './shell.js';
import { pageMissing, firstOpenablePage } from './pages.js';
import { openModal, closeModal } from './modal.js';
import { showToast as showToastIn } from '../../shared/toast.js';
import { openEntryModal, entryTitle, titleField, deleteQuestion } from '../../shared/entry-form/index.js';
import * as DashboardView from './views/dashboard.js';
import * as SettingsView from './views/settings/index.js';
import * as PageView from './views/page.js';
import * as PageListView from './views/page-list.js';
import * as PluginsView from './views/plugins.js';
import * as UsersView from './views/users.js';
import * as ActivityView from './views/activity.js';
import * as MediaView from './views/media.js';

export const BASE_PATH = ADMIN_URL + '/';

const views = {
  dashboard: DashboardView,
  settings: SettingsView,
  page: PageView,
  pages: PageListView,
  plugins: PluginsView,
  users: UsersView,
  activity: ActivityView,
  media: MediaView,
  plugin: createPluginViewProxy()
};

let currentName = null;
let currentView = null;

function parsePath(path) {
  if (path === BASE_PATH || path === BASE_PATH.slice(0, -1)) {
    path = '';
  } else if (path.startsWith(BASE_PATH)) {
    path = path.slice(BASE_PATH.length);
  }
  const slash = path.indexOf('/');
  return {
    name: slash === -1 ? path : path.slice(0, slash),
    param: slash === -1 ? '' : path.slice(slash + 1)
  };
}

// Darf die aktuelle Ansicht für name verlassen werden? Eine Ansicht mit leave(retry) entscheidet
// selbst (Seitenansicht: erst nach der Warnung des Seiten-Editors im iframe) und ruft retry auf,
// sobald es geht. Ein Wechsel innerhalb derselben Ansicht ist immer erlaubt.
function mayLeave(name, retry) {
  return name === currentName || !currentView || typeof currentView.leave !== 'function' || currentView.leave(retry);
}

export function navigate(route, options) {
  const url = BASE_PATH + route;
  // Adresse und Browser-Verlauf ändern sich erst, wenn die Ansicht wirklich wechselt.
  if (!mayLeave(parsePath(url).name, function () { navigate(route, options); })) return;
  if (window.location.pathname !== url) {
    if (options && options.replace) {
      history.replaceState(null, '', url);
    } else {
      history.pushState(null, '', url);
    }
  }
  renderView();
}

function renderView() {
  const { name, param } = parsePath(window.location.pathname);
  // Zurück/Vor im Browser: die Adresse steht schon, die Ansicht wechselt erst, wenn es geht.
  if (!mayLeave(name, renderView)) return;

  // Seite ohne Seitendatei (auch per Adresse): nicht öffnen, sondern wie ohne Seite weiter.
  // Nur eigene Einträge: views.constructor oder views.toString kämen sonst aus Object.prototype.
  if (!Object.prototype.hasOwnProperty.call(views, name) || (name === 'page' && (!param || pageMissing(param)))) {
    // Ohne Seite (vor dem Import) die Liste der Seiten: Dort steht „Import starten“.
    const first = firstOpenablePage();
    if (first !== null) {
      navigate(pageRoute(first), { replace: true });
    } else {
      navigate('pages', { replace: true });
    }
    return;
  }

  if (name === currentName && currentView && typeof currentView.update === 'function') {
    currentView.update(param);
    syncSidebar(name);
    return;
  }

  if (currentView && typeof currentView.unmount === 'function') {
    currentView.unmount();
  }
  clearViewDom();
  dom.viewOutlet.textContent = '';

  currentView = views[name];
  currentName = name;
  currentView.mount(dom.viewOutlet, param);
  syncSidebar(name);
}

// Markiert den Punkt der Seitenleiste zur Ansicht: data-view nennt die Ansichten eines Punkts,
// Erweiterungen (plugin/<route>) ihren Eintrag; aria-current für Screenreader.
function syncSidebar(name) {
  const param = parsePath(window.location.pathname).param;
  document.querySelectorAll('.sidebar .nav-item').forEach(function (btn) {
    const active = btn.dataset.route !== undefined
      ? name === 'plugin' && btn.dataset.route === param
      : (btn.dataset.view || '').split(' ').indexOf(name) !== -1;
    btn.classList.toggle('active', active);
    if (active) btn.setAttribute('aria-current', 'page');
    else btn.removeAttribute('aria-current');
  });
}

function createPluginViewProxy() {
  let loadedModule = null;
  // Zählt jede Navigation mit; ein Mount, der nach einem await nicht mehr der neueste ist,
  // bricht ab (sonst landet ein spät geladenes Plugin über der inzwischen aktiven Ansicht).
  let mountToken = 0;

  return {
    async mount(outlet, route) {
      const token = ++mountToken;
      const segments = String(route || '').split('/').filter(Boolean);
      const pluginName = segments[0] || '';
      const subRoute = segments.slice(1).join('/');

      if (!pluginName || !/^[a-z][a-z0-9_-]*$/.test(pluginName)) {
        outlet.innerHTML = '<section class="view-area"><div class="view-card"><p class="message">Ungültiger Plugin-Name.</p></div></section>';
        return;
      }

      const info = (state.activePlugins || []).find(function (plugin) {
        const expected = plugin.route || plugin.name;
        return expected === route || plugin.name === pluginName;
      });
      if (!info) {
        outlet.innerHTML = '<section class="view-area"><div class="view-card"><p class="message">Plugin ist nicht aktiv.</p></div></section>';
        return;
      }

      try {
        let module = null;
        if (info.hasAdminModule) {
          module = (await import('/plugins/' + pluginName + '/admin/module.js')).default;
        } else if (info.hasSchema) {
          module = (await import('./views/plugin-generic.js')).default;
        } else {
          outlet.innerHTML = '<section class="view-area"><div class="view-card"><p>Dieses Plugin hat keine Admin-Oberfläche.</p></div></section>';
          return;
        }
        if (token !== mountToken) return;

        if (!module || (module.id !== pluginName && module.id !== '__generic__')) {
          throw new Error('Plugin-Modul passt nicht zum Plugin.');
        }
        loadedModule = module;
        await module.mount(outlet, buildPluginContext(pluginName, subRoute, info));
      } catch (error) {
        if (token !== mountToken) return;
        outlet.innerHTML = '<section class="view-area"><div class="view-card"><p class="message">Plugin-Modul konnte nicht geladen werden: ' + escapeHtml(error.message || String(error)) + '</p></div></section>';
      }
    },
    unmount() {
      mountToken++;
      if (loadedModule && typeof loadedModule.unmount === 'function') {
        try {
          loadedModule.unmount();
        } catch (e) {
        }
      }
      loadedModule = null;
    }
  };
}

function buildPluginContext(pluginName, subRoute, info) {
  return {
    pluginName: pluginName,
    subRoute: subRoute || '',
    info: info || null,
    api: api,
    navigate: navigate,
    state: state,
    confirm: function (message) { return window.confirm(message); },
    toast: function (message) { window.alert(message); },
    ui: {
      openModal: openModal,
      closeModal: closeModal,
      // Formular für einen Eintrag aus dem Schema (shared/entry-form/index.js, auch auf der Website).
      openEntryForm: function (options) {
        return openEntryModal(openModal, Object.assign({ notify: showToast }, options));
      },
      entryTitle: entryTitle,
      titleField: titleField,
      deleteQuestion: deleteQuestion
    }
  };
}

export function showToast(message) {
  showToastIn(message, document.body);
}

let initialized = false;
export function initRouter() {
  if (!initialized) {
    window.addEventListener('popstate', renderView);
    initialized = true;
  }
  renderView();
}
