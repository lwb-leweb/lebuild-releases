<?php
declare(strict_types=1);

// Formular aus einer Datei (public/includes/forms/<name>.json) absenden. Ablauf wie api/submit.php:
// Honeypot → Rate-Limit prüfen → Eingaben gegen die Definition → Slot reservieren → Versand (mit Anhängen).

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo API_TEXT['method'];
    return;
}

// Der Name steht in der Adresse, damit er auch ankommt, wenn PHP eine zu große Anfrage samt $_POST verwirft.
$name = is_string($_GET['form'] ?? null) ? $_GET['form'] : '';
$anchor = contact_form_definition_name_valid($name) ? contact_form_definition_anchor($name) : CONTACT_FORM_ANCHOR;
$fail = static fn (int $status, string $result) => contact_form_fail($status, $result, $anchor, $anchor);
try {
    $definition = contact_form_definition($name);
} catch (Throwable $e) {
    // Ein ungültiger Name kommt nie roh ins Log (Zeilenumbrüche fälschten sonst Einträge).
    error_log('contact-form form ' . (contact_form_definition_name_valid($name) ? $name : '(ungültiger Name)') . ': ' . $e->getMessage());
    $fail(400, 'unbekannt');
    return;
}

if ($_POST === [] && $_FILES === [] && (int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
    $fail(413, 'zu-gross');
    return;
}

if (contact_form_honeypot_tripped()) {
    contact_form_submit_redirect($anchor, $anchor);
    return;
}

if (!contact_form_rate_check()) {
    $fail(429, 'zu-viele');
    return;
}

$input = contact_form_definition_input($definition, $_POST, $_FILES);
if (isset($input['error'])) {
    $fail(match ($input['error']) { 'zu-gross' => 413, default => 400 }, $input['error']);
    return;
}

$recipient = $definition['recipient'] !== '' ? $definition['recipient'] : contact_form_config_recipient();
if ($recipient === '') {
    $fail(500, 'kein-empfaenger');
    return;
}

$mail = contact_form_definition_mail($definition, $input['values']);
$slot = contact_form_rate_reserve();
if ($slot === null) {
    $fail(429, 'zu-viele');
    return;
}

try {
    core_mail_send([
        'to' => $recipient,
        'subject' => $mail['subject'],
        'text' => $mail['text'],
        'replyTo' => contact_form_definition_reply_to($definition, $input['values']),
        'attachments' => $input['files'],
    ]);
} catch (Throwable $e) {
    error_log('contact-form form ' . $name . ' mail failed: ' . $e->getMessage());
    contact_form_rate_release($slot);
    $fail(500, 'versand');
    return;
}

contact_form_submit_redirect($anchor, $anchor);
