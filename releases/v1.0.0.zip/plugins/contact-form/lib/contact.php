<?php
declare(strict_types=1);

// Formulare: festes Kontaktformular, Signatur des Empfängers, Mail, Antwort an den Browser.

// Spamschutz-Konstanten (Ablauf in README.md, „Für Agenten“, „Fehlervermeidung“).
const CONTACT_FORM_HONEYPOT   = 'url';   // verstecktes Feld; nur Bots fuellen es aus

// Antworten von api/submit.php an den Besucher (Klartext).
const CONTACT_FORM_TEXT = [
    'rateLimit' => 'Zu viele Anfragen, bitte später erneut.',
    'missingFields' => 'Fehlende Felder.',
    'invalidEmail' => 'Ungültige E-Mail.',
    'noRecipient' => 'Empfänger-Adresse nicht konfiguriert.',
    'sendFailed' => 'Versand fehlgeschlagen.',
    'sent' => 'Danke, Ihre Nachricht ist angekommen.',
    'invalidValue' => 'Bitte die Eingaben prüfen.',
    'fileType' => 'Dieser Dateityp ist nicht erlaubt.',
    'fileSize' => 'Die Dateien sind zu groß.',
    'unknownForm' => 'Unbekanntes Formular.',
];
// Markierung in der Adresse nach dem Absenden aus dem Browser (?kontakt=…#kontaktformular): Wert → Text der Meldung.
const CONTACT_FORM_RESULT_PARAM = 'kontakt';
const CONTACT_FORM_ANCHOR = 'kontaktformular';
const CONTACT_FORM_RESULTS = [
    'gesendet' => 'sent',
    'fehlende-felder' => 'missingFields',
    'ungueltige-email' => 'invalidEmail',
    'zu-viele' => 'rateLimit',
    'kein-empfaenger' => 'noRecipient',
    'versand' => 'sendFailed',
    'ungueltig' => 'invalidValue',
    'dateityp' => 'fileType',
    'zu-gross' => 'fileSize',
    'unbekannt' => 'unknownForm',
];

function contact_form_config_recipient(): string
{
    return core_mail_default_recipient();
}

// Kontext der Signatur eines Empfängers aus data-recipient. Bis 2026-11 stand auch der Standard-Empfänger signiert in
// jeder Seite; mit neuem Kontext gelten diese alten Signaturen nicht mehr (alte Kopien gehen an den aktuellen Empfänger).
const CONTACT_FORM_SIGNATURE_CONTEXT = 'contact-form-recipient-attr|';

function contact_form_signature(string $recipient): string
{
    return hash_hmac('sha256', CONTACT_FORM_SIGNATURE_CONTEXT . $recipient, app_secret());
}

/** Empfänger aus data-recipient, wenn die Signatur passt; sonst (auch ohne) der beim Absenden eingestellte. */
function contact_form_verified_recipient(string $recipient, string $signature): string
{
    if ($recipient !== '' && filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
        $expected = contact_form_signature($recipient);
        if (hash_equals($expected, $signature)) {
            return $recipient;
        }
    }

    return contact_form_config_recipient();
}

/**
 * Whitelist optionaler Zusatzfelder. Schluessel = POST-Feldname, Wert = Label im
 * Mailtext. Reihenfolge = Reihenfolge im Mailtext. Labels generisch halten; ein
 * site-spezifisches Body-Label ist ein spaeteres, admin-konfigurierbares v2-Thema.
 * Nur Felder aus dieser Liste landen in der Mail -- niemals beliebige $_POST-Keys.
 */
function contact_form_extra_fields(): array
{
    return [
        'company'  => 'Firma',
        'phone'    => 'Telefon',
        'telegram' => 'Telegram',
        'subject'  => 'Betreff',
    ];
}

/** Nachricht wörtlich (kein strip_tags, „a < b“ bleibt): Umbrüche als \n, Steuerzeichen außer Tab und Umbruch fallen weg. */
function contact_form_message_text(string $value): string
{
    return trim(preg_replace(['/\r\n?/', '/[\x00-\x08\x0B-\x1F\x7F]/'], ["\n", ''], $value) ?? '');
}

/**
 * Betreff und Text der Mail (text/plain, nichts wird als HTML gelesen): Name einzeilig, die befüllten
 * Whitelist-Felder (Registry-Reihenfolge), eine Leerzeile, die Nachricht. Alle Werte wörtlich; niemals
 * beliebige $post-Keys. Der Betreff bleibt fest, ein Feld `subject` ist nur ein Body-Feld.
 */
function contact_form_mail(string $name, string $email, string $message, array $post): array
{
    $lines = [
        'Name: ' . $name,
        'E-Mail: ' . $email,
    ];
    foreach (contact_form_extra_fields() as $key => $label) {
        $value = core_mail_clean_header(is_string($post[$key] ?? null) ? $post[$key] : '');
        if ($value !== '') {
            // mb_substr: ein Umlaut an der Grenze darf nicht halbiert werden.
            $lines[] = $label . ': ' . mb_substr($value, 0, 200);
        }
    }

    return [
        'subject' => 'Kontaktformular: ' . mb_substr($name, 0, 60),
        'text' => implode("\n", $lines) . "\n\n" . $message . "\n",
    ];
}

/**
 * Honeypot: ist das versteckte Feld vorhanden UND befuellt, ist es ein Bot.
 * Fehlt das Feld (alte Formulare), wird nicht geblockt.
 */
function contact_form_honeypot_tripped(): bool
{
    return trim((string) ($_POST[CONTACT_FORM_HONEYPOT] ?? '')) !== '';
}

/**
 * Erfolgs-/Honeypot-Antwort: 303-Redirect auf den Referer. Bewusst identisch
 * fuer beide Faelle, damit ein Honeypot-Treffer wie ein Erfolg aussieht. Aus dem
 * Browser abgeschickt (contact_form_navigation) mit Markierung „gesendet“.
 */
function contact_form_submit_redirect(string $param = CONTACT_FORM_RESULT_PARAM, string $anchor = CONTACT_FORM_ANCHOR): void
{
    if (contact_form_navigation()) {
        contact_form_back('gesendet', $param, $anchor);
        return;
    }
    http_response_code(303);
    header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? '/'));
}

/** Abgeschickt als Seitenaufruf des Browsers (normales Formular), nicht per fetch: Antwort ist dann eine Rückleitung. */
function contact_form_navigation(): bool
{
    // Ohne Sec-Fetch-Mode (alte Browser, http): Formulare schicken Accept mit text/html vorne; jQuery & Co. setzen
    // X-Requested-With.
    $mode = (string) ($_SERVER['HTTP_SEC_FETCH_MODE'] ?? '');
    if ($mode !== '') {
        return $mode === 'navigate';
    }
    return !isset($_SERVER['HTTP_X_REQUESTED_WITH']) && str_starts_with(strtolower(trim((string) ($_SERVER['HTTP_ACCEPT'] ?? ''))), 'text/html');
}

/**
 * Zurück auf die Seite des Formulars (Pfad und Query des Referers, nie ein fremder Host) mit ?kontakt=$result
 * (CONTACT_FORM_RESULTS) und Sprung zum Formular. Formulare aus einer Datei nehmen ?formular-<name>=…#formular-<name>.
 */
function contact_form_back(string $result, string $param = CONTACT_FORM_RESULT_PARAM, string $anchor = CONTACT_FORM_ANCHOR): void
{
    $referer = parse_url((string) ($_SERVER['HTTP_REFERER'] ?? '')) ?: [];
    $path = (string) ($referer['path'] ?? '');
    // Nur ein Pfad dieser Website: kein //host, kein Backslash (Browser lesen /\host wie //host), keine Steuerzeichen.
    if (!preg_match('#^/(?![/\\\\])[^\\\\\x00-\x20\x7f]*$#', $path)) {
        $path = '/';
    }
    // Die übrige Query bleibt wörtlich, nur eine alte Markierung fällt weg.
    $keep = array_filter(explode('&', (string) ($referer['query'] ?? '')), static fn (string $part): bool => $part !== ''
        && !preg_match('/[\x00-\x20\x7f]/', $part) && explode('=', $part, 2)[0] !== $param);
    $keep[] = $param . '=' . rawurlencode($result);
    http_response_code(303);
    header('Location: ' . $path . '?' . implode('&', $keep) . '#' . $anchor);
}

/** Fehlerantwort: aus dem Browser als Rückleitung mit Markierung, sonst Status mit Text (fetch, curl). */
function contact_form_fail(int $status, string $result, string $param = CONTACT_FORM_RESULT_PARAM, string $anchor = CONTACT_FORM_ANCHOR): void
{
    if (contact_form_navigation()) {
        contact_form_back($result, $param, $anchor);
        return;
    }
    http_response_code($status);
    echo CONTACT_FORM_TEXT[CONTACT_FORM_RESULTS[$result]];
}

/** Meldung nach der Rückleitung (?kontakt=…) für das Formular; null ohne oder bei unbekannter Markierung. */
function contact_form_result_notice(string $param = CONTACT_FORM_RESULT_PARAM): ?array
{
    $result = $_GET[$param] ?? '';
    $key = is_string($result) ? (CONTACT_FORM_RESULTS[$result] ?? null) : null;
    return $key === null ? null : ['ok' => $key === 'sent', 'text' => CONTACT_FORM_TEXT[$key]];
}
