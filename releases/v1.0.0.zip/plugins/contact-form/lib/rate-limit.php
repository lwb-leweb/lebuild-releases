<?php
declare(strict_types=1);

// Formulare: Bremse je IP (höchstens CONTACT_FORM_RATE_MAX Absendungen je Fenster), Zeitstempel in Dateien.

const CONTACT_FORM_RATE_MAX   = 5;       // max. Submits pro IP (IPv6: je /64) und Fenster
const CONTACT_FORM_RATE_WINDOW = 3600;   // Fenster in Sekunden (60 Min)
const CONTACT_FORM_RATE_PRUNE_ODDS = 50; // etwa jede 50. Reservierung raeumt alte Dateien weg

function contact_form_rate_dir(): string
{
    return CACHE_ROOT . '/contact-form/ratelimit';
}

/**
 * Datei pro IP, IPv6 je /64-Netz wie bei der Login-Sperre (sonst nimmt ein Spammer für jede Anfrage eine neue
 * Adresse aus seinem Netz). Keine Roh-IP speichern -- nur per HMAC mit dem Installations-Schlüssel.
 */
function contact_form_rate_file(): string
{
    $ip = le_login_ip_key((string) ($_SERVER['REMOTE_ADDR'] ?? ''));
    $hash = substr(hash_hmac('sha256', $ip, app_secret()), 0, 32);

    return contact_form_rate_dir() . '/' . $hash . '.json';
}

/**
 * Liest die Timestamps der aktuellen IP und verwirft alles ausserhalb des Fensters.
 */
function contact_form_rate_timestamps(): array
{
    $raw = @file_get_contents(contact_form_rate_file());
    if ($raw === false) {
        return [];
    }

    $data = json_decode($raw, true);
    if (!is_array($data)) {
        return [];
    }

    $cutoff = time() - CONTACT_FORM_RATE_WINDOW;
    $valid = [];
    foreach ($data as $ts) {
        $ts = (int) $ts;
        if ($ts > $cutoff) {
            $valid[] = $ts;
        }
    }

    return $valid;
}

/**
 * false = gesperrt. Prueft nur, schreibt nichts (frueher 429 vor der Validierung).
 * Entscheidend ist contact_form_rate_reserve() direkt vor dem Versand.
 */
function contact_form_rate_check(): bool
{
    return count(contact_form_rate_timestamps()) < CONTACT_FORM_RATE_MAX;
}

/**
 * Fuehrt $fn unter einer exklusiven Sperre fuer alle Rate-Limit-Dateien aus. Ohne Sperre
 * (Verzeichnis nicht beschreibbar) laeuft $fn trotzdem, damit das Formular nicht ausfaellt.
 */
function contact_form_rate_locked(callable $fn): mixed
{
    try {
        ensure_dir(contact_form_rate_dir());
    } catch (Throwable $e) {
        error_log('contact-form rate limit: ' . $e->getMessage());
    }
    $lock = @fopen(contact_form_rate_dir() . '/.lock', 'c');
    if ($lock !== false && !flock($lock, LOCK_EX)) {
        fclose($lock);
        $lock = false;
    }
    try {
        return $fn();
    } finally {
        if ($lock !== false) {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }
}

/** Schreibt die Timestamps der aktuellen IP atomar via tmp + rename. */
function contact_form_rate_write(array $timestamps): void
{
    $file = contact_form_rate_file();
    $tmp = $file . '.' . bin2hex(random_bytes(4)) . '.tmp';
    if (file_put_contents($tmp, json_encode(array_values($timestamps)), LOCK_EX) === false) {
        @unlink($tmp);
        return;
    }
    if (!rename($tmp, $file)) {
        @unlink($tmp);
    }
}

/**
 * Reserviert vor dem Versand einen Slot: Pruefen und Eintragen unter einer Sperre, damit
 * parallele Anfragen das Limit nicht gemeinsam unterlaufen. Liefert den Timestamp des
 * Slots (fuer contact_form_rate_release()) oder null, wenn das Limit erreicht ist.
 * Erst nach Honeypot und Validierung aufrufen -- sonst fuellen Bots das Fenster mit
 * Garbage und sperren echte Nutzer aus.
 */
function contact_form_rate_reserve(): ?int
{
    return contact_form_rate_locked(static function (): ?int {
        $timestamps = contact_form_rate_timestamps();
        if (count($timestamps) >= CONTACT_FORM_RATE_MAX) {
            return null;
        }
        $now = time();
        $timestamps[] = $now;
        contact_form_rate_write($timestamps);
        // Gelegentlich alte Dateien anderer IPs wegraeumen.
        if (random_int(1, CONTACT_FORM_RATE_PRUNE_ODDS) === 1) {
            contact_form_rate_prune();
        }
        return $now;
    });
}

/** Gibt einen Slot wieder frei, wenn der Versand gescheitert ist. */
function contact_form_rate_release(int $slot): void
{
    contact_form_rate_locked(static function () use ($slot): void {
        $timestamps = contact_form_rate_timestamps();
        $pos = array_search($slot, $timestamps, true);
        if ($pos !== false) {
            unset($timestamps[$pos]);
            contact_form_rate_write($timestamps);
        }
    });
}

/**
 * Loescht Rate-Limit-Dateien, die seit einem ganzen Fenster nicht geschrieben wurden (und
 * liegengebliebene .tmp). Laeuft unter der Sperre aus contact_form_rate_reserve().
 */
function contact_form_rate_prune(): int
{
    $dir = contact_form_rate_dir();
    $cutoff = time() - CONTACT_FORM_RATE_WINDOW;
    $removed = 0;
    foreach (array_merge(glob($dir . '/*.json') ?: [], glob($dir . '/*.tmp') ?: []) as $file) {
        $mtime = @filemtime($file);
        if ($mtime !== false && $mtime < $cutoff && @unlink($file)) {
            $removed++;
        }
    }
    return $removed;
}
