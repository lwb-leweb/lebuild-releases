<?php
declare(strict_types=1);

// Formulare aus einer Datei: Eingaben und Anhänge prüfen (Arten, Größen, Office-Dateien).

// Erlaubte Anhänge: Endung → MIME-Typen, die finfo dafür melden darf (Office-Dateien sind ZIP-Archive).
const CONTACT_FORM_FILE_TYPES = [
    'pdf' => ['application/pdf'],
    'jpg' => ['image/jpeg'],
    'jpeg' => ['image/jpeg'],
    'png' => ['image/png'],
    'webp' => ['image/webp'],
    'heic' => ['image/heic', 'image/heif'],
    'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip', 'application/octet-stream'],
    'xlsx' => ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip', 'application/octet-stream'],
];
// docx/xlsx sind ZIP-Archive, finfo erkennt sie oft nur als ZIP: Mit der zip-Erweiterung muss das Archiv ein
// OOXML-Dokument dieser Art sein (ohne sie bleibt nur die Prüfung oben, README). Den Hauptteil nennt [Content_Types].xml
// mit seinem Inhaltstyp; sein Name ist frei (Word Online: word/document2.xml), Teilnamen ohne Rücksicht auf Groß/klein.
// Makro-Varianten (docm, xlsm) haben einen anderen Inhaltstyp und fallen durch.
const CONTACT_FORM_OOXML_CONTENT_TYPES = '[Content_Types].xml';
const CONTACT_FORM_OOXML_TYPES_NS = 'http://schemas.openxmlformats.org/package/2006/content-types';
const CONTACT_FORM_OOXML_MAIN_TYPES = [
    'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml',
    'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml',
];
const CONTACT_FORM_OOXML_TYPES_MAX = 1024 * 1024; // [Content_Types].xml, entpackt
const CONTACT_FORM_FILE_MAX_TOTAL = 10 * 1024 * 1024; // alle Anhänge einer Anfrage zusammen
const CONTACT_FORM_FILE_MAX_COUNT = 10;
const CONTACT_FORM_TEXT_MAX = 200;       // einzeilige Felder
const CONTACT_FORM_TEXTAREA_MAX = 5000;  // mehrzeilige Felder

/**
 * Prüft die Eingaben gegen die Definition. Liefert ['values' => name → Wert (string oder Liste), 'files' => Anhänge
 * für core_mail_send] oder ['error' => Ergebnis aus CONTACT_FORM_RESULTS]. Andere POST-Felder werden ignoriert.
 */
function contact_form_definition_input(array $definition, array $post, array $files): array
{
    $values = [];
    $attachments = [];
    $total = 0;
    foreach ($definition['steps'] as $step) {
        $stepShown = contact_form_condition_met($step['showIf'], $values);
        foreach ($step['fields'] as $field) {
            $name = $field['name'];
            // Ausgeblendet (showIf nicht erfüllt): nicht prüfen, nichts übernehmen, Anhänge verwerfen.
            if (!$stepShown || !contact_form_condition_met($field['showIf'], $values)) {
                $values[$name] = $field['type'] === 'file' || ($field['type'] === 'checkbox' && $field['options'] !== []) ? [] : '';
                continue;
            }
            if ($field['type'] === 'file') {
                $uploads = contact_form_uploaded_files($files[$name] ?? null);
                if ($uploads === null) {
                    return ['error' => 'zu-gross'];
                }
                if (!$field['multiple'] && count($uploads) > 1) {
                    return ['error' => 'ungueltig'];
                }
                if ($uploads === [] && $field['required']) {
                    return ['error' => 'fehlende-felder'];
                }
                $names = [];
                foreach ($uploads as $upload) {
                    $total += $upload['size'];
                    if ($total > CONTACT_FORM_FILE_MAX_TOTAL || count($attachments) >= CONTACT_FORM_FILE_MAX_COUNT) {
                        return ['error' => 'zu-gross'];
                    }
                    $attachment = contact_form_file_attachment($upload, $field['accept']);
                    if ($attachment === null) {
                        return ['error' => 'dateityp'];
                    }
                    $attachments[] = $attachment;
                    $names[] = $attachment['name'];
                }
                $values[$name] = $names;
                continue;
            }

            $raw = $post[$name] ?? null;
            if ($field['type'] === 'checkbox' && $field['options'] !== []) {
                $list = is_array($raw) ? $raw : ($raw === null ? [] : [$raw]);
                $list = array_values(array_unique(array_filter($list, 'is_string')));
                if (array_diff($list, $field['options']) !== []) {
                    return ['error' => 'ungueltig'];
                }
                if ($list === [] && $field['required']) {
                    return ['error' => 'fehlende-felder'];
                }
                // In der Reihenfolge der Definition.
                $values[$name] = array_values(array_intersect($field['options'], $list));
                continue;
            }
            if ($raw !== null && !is_string($raw)) {
                return ['error' => 'ungueltig'];
            }
            $value = $field['type'] === 'textarea' ? contact_form_message_text((string) $raw) : core_mail_clean_header((string) $raw);
            if ($field['type'] === 'checkbox') {
                $value = $value !== '' ? 'Ja' : '';
            }
            if ($value === '') {
                if ($field['required']) {
                    return ['error' => 'fehlende-felder'];
                }
                $values[$name] = '';
                continue;
            }
            if (!contact_form_value_valid($field, $value)) {
                return ['error' => $field['type'] === 'email' ? 'ungueltige-email' : 'ungueltig'];
            }
            $values[$name] = $value;
        }
    }
    return ['values' => $values, 'files' => $attachments];
}

/** Wert eines befüllten Feldes passt zu Typ und Grenzen. */
function contact_form_value_valid(array $field, string $value): bool
{
    if (isset($field['maxlength']) && mb_strlen($value) > $field['maxlength']) {
        return false;
    }
    switch ($field['type']) {
        case 'email':
            return mb_strlen($value) <= CONTACT_FORM_TEXT_MAX && filter_var($value, FILTER_VALIDATE_EMAIL) !== false;
        case 'tel':
            return (bool) preg_match('#^[0-9 +()/.\-]{3,40}$#', $value);
        case 'number':
            if (!is_numeric($value) || strlen($value) > 30) {
                return false;
            }
            return ($field['min'] === null || (float) $value >= $field['min']) && ($field['max'] === null || (float) $value <= $field['max']);
        case 'date':
            $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
            return $date !== false && $date->format('Y-m-d') === $value;
        case 'select':
        case 'radio':
            return in_array($value, $field['options'], true);
        default:
            return true;
    }
}

/**
 * Hochgeladene Dateien eines Feldes als Liste (eins oder name[] mehrere). Leere Auswahl fällt weg.
 * null: zu groß (Grenze von PHP) oder kaputter Upload.
 */
function contact_form_uploaded_files(mixed $entry): ?array
{
    if (!is_array($entry) || !isset($entry['error'])) {
        return [];
    }
    $keys = ['name', 'type', 'tmp_name', 'error', 'size'];
    $list = [];
    if (is_array($entry['error'])) {
        foreach (array_keys($entry['error']) as $i) {
            $list[] = array_combine($keys, array_map(static fn (string $k) => $entry[$k][$i] ?? null, $keys));
        }
    } else {
        $list[] = $entry;
    }
    $files = [];
    foreach ($list as $file) {
        $error = (int) $file['error'];
        if ($error === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        if ($error !== UPLOAD_ERR_OK || !is_string($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            return null;
        }
        $files[] = ['name' => (string) $file['name'], 'tmp' => $file['tmp_name'], 'size' => (int) $file['size']];
    }
    return $files;
}

/** Datei als Anhang, wenn Endung erlaubt und Inhalt dazu passt; sonst null. */
function contact_form_file_attachment(array $upload, array $accept): ?array
{
    $ext = strtolower(pathinfo($upload['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $accept, true)) {
        return null;
    }
    $data = @file_get_contents($upload['tmp']);
    if ($data === false || $data === '') {
        return null;
    }
    $type = CONTACT_FORM_FILE_TYPES[$ext][0];
    if (class_exists('finfo')) {
        $detected = (string) (new finfo(FILEINFO_MIME_TYPE))->buffer($data);
        if (!in_array($detected, CONTACT_FORM_FILE_TYPES[$ext], true)) {
            return null;
        }
    }
    if (isset(CONTACT_FORM_OOXML_MAIN_TYPES[$ext]) && class_exists('ZipArchive') && !contact_form_ooxml_valid($upload['tmp'], CONTACT_FORM_OOXML_MAIN_TYPES[$ext])) {
        return null;
    }
    return ['name' => $upload['name'], 'type' => $type, 'data' => $data];
}

/**
 * Ist die Datei $path ein OOXML-Dokument, dessen [Content_Types].xml (höchstens CONTACT_FORM_OOXML_TYPES_MAX) einen Teil
 * mit dem Inhaltstyp $mainType nennt, den es im ZIP auch gibt?
 */
function contact_form_ooxml_valid(string $path, string $mainType): bool
{
    $zip = new ZipArchive();
    if ($zip->open($path, ZipArchive::RDONLY) !== true) {
        return false;
    }
    try {
        $stat = $zip->statName(CONTACT_FORM_OOXML_CONTENT_TYPES, ZipArchive::FL_NOCASE);
        if ($stat === false || $stat['size'] > CONTACT_FORM_OOXML_TYPES_MAX) {
            return false;
        }
        $raw = $zip->getFromIndex($stat['index'], CONTACT_FORM_OOXML_TYPES_MAX);
        $types = is_string($raw) && strlen($raw) === $stat['size'] ? @simplexml_load_string($raw, 'SimpleXMLElement', LIBXML_NONET) : false;
        if ($types === false) {
            return false;
        }
        foreach ($types->children(CONTACT_FORM_OOXML_TYPES_NS)->Override as $override) {
            // Attribute ohne Präfix stehen in keinem Namensraum, nur attributes() findet sie hier.
            $attrs = $override->attributes();
            $part = ltrim(rawurldecode((string) $attrs['PartName']), '/');
            if (strcasecmp(trim((string) $attrs['ContentType']), $mainType) === 0 && $part !== '' && $zip->locateName($part, ZipArchive::FL_NOCASE) !== false) {
                return true;
            }
        }
        return false;
    } finally {
        $zip->close();
    }
}
