# Formulare (Plugin `contact-form`)

Rendert per Shortcode das feste Kontaktformular oder ein eigenes Formular aus einer Datei der Website (beliebige Felder, mehrere Schritte, Anhänge). Der Versand nutzt den zentralen Core-Mailer: SMTP, wenn in den globalen Einstellungen konfiguriert, sonst PHP `mail()`. Der interne Name bleibt `contact-form`, im Admin heißt es „Formulare“.

## Aktivierung

Im Admin unter "Erweiterungen" das Plugin "Formulare" aktivieren. Es legt keine Datenbanktabellen an.

## Was es kann

- Kontaktformular per Shortcode rendern
- Name, E-Mail und Nachricht validieren
- Standard-Empfaenger aus den globalen Mail-Einstellungen verwenden
- Optional signierten Shortcode-Empfaenger verwenden
- Versand ueber SMTP oder PHP `mail()` via Core-Mailer
- Spamschutz ohne externen Dienst: Honeypot-Feld + datei-basiertes IP-Rate-Limit (max. 5 Submits / 60 Min / IP)
- Optionale Zusatzfelder (Firma, Telefon, Telegram, Betreff) ueber eine Whitelist im Plugin-Code -- werden mit Label oberhalb der Nachricht in den Mailtext aufgenommen
- Eigene Formulare aus `website/public/includes/forms/<name>.json`: zehn Feldtypen, mehrere Schritte, Abhängigkeiten zwischen Feldern, Dateien als Mail-Anhang (siehe „Formulare aus einer Datei“)

## Formulare aus einer Datei

Wir legen jedes Formular als JSON im Repo der Website an; der Kunde kann es nicht bearbeiten. Eingebunden wird es mit `data-form`:

```html
<div data-plugin="contact-form" data-view="form" data-form="projekt"></div>
```

Beispiel mit allen Feldtypen und einer Abhängigkeit: `website/public/includes/forms/projekt.json` (Testseite `/anfrage`).

| Schlüssel | Bedeutung |
|---|---|
| `title` | Erste Zeile der Mail, Vorgabe für den Betreff |
| `subject` | Betreff, `{feldname}` wird durch den Wert ersetzt (optional) |
| `recipient` | Empfänger (optional, sonst Standard-Empfänger der Einstellungen) |
| `submit`, `next`, `back` | Knopftexte (Vorgabe Absenden, Weiter, Zurück) |
| `success` | eigene Erfolgsmeldung (optional) |
| `fields` oder `steps` | Liste der Felder, oder Schritte `[{ "title": "…", "fields": [...] }]` |

Feld: `name` (`a-z0-9_`, nicht `url`, `form`, `recipient`, `recipient_sig`), `label`, `type`, optional `required`, `placeholder`, `help`, `showIf`.

### Abhängigkeiten (`showIf`)

Ein Feld oder ein ganzer Schritt erscheint nur, wenn ein früheres Feld mit `options` (`radio`, `select`, `checkbox`) eine bestimmte Antwort hat:

```json
{ "title": "Deine bestehende Website", "showIf": { "field": "bestehend", "value": "Ja" }, "fields": [...] }
{ "name": "anders", "label": "Was genau?", "type": "textarea", "required": true, "showIf": { "field": "funktionen", "value": ["Etwas anderes"] } }
```

- `value`: eine Option oder eine Liste (eine davon genügt; bei Checkboxen: eine davon angehakt). Nur Optionen des Feldes, sonst ist die Datei ungültig.
- Ausgeblendet heißt: nicht ausgefüllt. `assets/form.js` blendet ein und aus, ausgeblendete Felder sind `disabled`, Schritte fallen aus „Weiter“ und der Zählung; `required` gilt nur, solange das Feld zu sehen ist.
- Der Server wertet dieselben Bedingungen aus und übergeht ausgeblendete Felder (keine Prüfung, nicht in der Mail, Anhänge verworfen). Ohne JavaScript stehen alle Felder da, bedingte ohne `required`.
- Ketten gehen: hängt ein Feld an einem ausgeblendeten, ist es auch aus.
- Fortschritt: `assets/form.js` setzt `--le-form-progress` (0 bis 1) an `.le-form__progress`, z. B. für einen Balken.

| `type` | Extra | Mail |
|---|---|---|
| `text`, `tel`, `textarea` | `maxlength` (höchstens 200, mehrzeilig 5000) | Wert |
| `email` | – | Wert; das erste E-Mail-Feld wird Reply-To |
| `number` | `min`, `max`, `step` | Wert |
| `date` | – | `JJJJ-MM-TT` |
| `select`, `radio` | `options` (Liste aus Texten) | gewählte Option |
| `checkbox` | mit `options`: Mehrfachauswahl; ohne: ein Kästchen (z. B. Zustimmung) | Optionen mit Komma bzw. „Ja“ |
| `file` | `multiple`, `accept` (Teilmenge von pdf, jpg, jpeg, png, webp, heic, docx, xlsx) | Dateinamen, Dateien als Anhang |

- Der Server prüft jede Eingabe gegen die Datei: Pflichtfelder, Typ, Optionen, Endung und Inhalt der Datei (finfo, falls vorhanden; ohne finfo nur die Endung). `docx`/`xlsx` müssen mit der zip-Erweiterung zudem ein echtes Word- bzw. Excel-Dokument sein (`[Content_Types].xml` nennt einen vorhandenen Hauptteil dieser Art, Name egal; mit Makros, also docm/xlsm, nicht), ohne sie reicht wie bisher, was finfo meldet (auch ein beliebiges ZIP). Alle Anhänge zusammen höchstens 10 MB, höchstens 10 Dateien; nichts bleibt auf dem Server.
- Andere POST-Felder werden ignoriert. Honeypot und Rate-Limit wie beim Kontaktformular.
- Mehrere Schritte zeigt `assets/form.js` einzeln mit Weiter/Zurück und prüft je Schritt; ohne JavaScript stehen alle untereinander.
- Eine kaputte Datei gibt nur `<!-- contact-form: form invalid -->` aus, der Grund steht im PHP-Log.
- Klassen zum Gestalten: `le-form`, `le-form__step`, `le-form__step-title`, `le-form__progress`, `le-form__field` (`--<type>`), `le-form__option`, `le-form__help`, `le-form__required`, `le-form__nav`, `le-form__back`, `le-form__next`, `le-form__submit`, `le-form__notice--ok`/`--error`.

## Im Admin verwenden

SMTP wird nicht im Plugin selbst gepflegt. Die Einstellungen liegen global unter "Einstellungen" -> "E-Mail / SMTP".

## API-Endpoints

| Endpoint | Methode | Auth | Parameter | Response |
|---|---|---|---|---|
| `/plugins/contact-form/api/submit.php` | POST | nein | `name`, `email`, `message`, `recipient` und `recipient_sig` (nur mit `data-recipient`), optional `company`, `phone`, `telegram`, `subject`, Honeypot `url` | siehe Antwort-Codes unten |
| `/plugins/contact-form/api/form.php?form=<name>` | POST (multipart) | nein | Felder der Formular-Datei, Honeypot `url` | wie unten, dazu `400` „Bitte die Eingaben prüfen.“, „Dieser Dateityp ist nicht erlaubt.“, „Unbekanntes Formular.“ und `413` „Die Dateien sind zu groß.“; aus dem Browser `?formular-<name>=<ergebnis>#formular-<name>` (zusätzlich `ungueltig`, `dateityp`, `zu-gross`, `unbekannt`) |

Beispiel:

```bash
curl -i -X POST https://example.com/plugins/contact-form/api/submit.php \
  -d 'name=Max' \
  -d 'email=max@example.com' \
  -d 'message=Hallo'
```

### Antwort-Codes

| Fall | Code | Body | AJAX (`res.ok`) |
|---|---|---|---|
| Erfolg | `303` | `Location: Referer` | true (Redirect folgt) |
| Honeypot-Treffer | `303` | `Location: Referer` | true (stiller Drop, keine Mail) |
| Pflichtfeld fehlt | `400` | „Fehlende Felder." | false |
| Ungueltige E-Mail | `400` | „Ungültige E-Mail." | false |
| Rate-Limit | `429` | „Zu viele Anfragen, bitte später erneut." | false |
| Kein Empfänger (kein signierter `recipient` bzw. keiner in der Formular-Datei, kein Standard-Empfänger in den Einstellungen) | `500` | „Empfänger-Adresse nicht konfiguriert." | false |
| Versand-Fehler | `500` | „Versand fehlgeschlagen." | false |

Ein Honeypot-Treffer antwortet bewusst wie ein Erfolg, damit Bots den Mechanismus nicht erkennen.

Normales Absenden aus dem Browser (`Sec-Fetch-Mode: navigate`; ohne diesen Header: `Accept` beginnt mit `text/html` und kein `X-Requested-With`): Erfolg und jeder Fehler leiten per `303` auf die Seite des Formulars zurück (Pfad und Query des Referers wörtlich, nie ein fremder Host), mit `?kontakt=<ergebnis>#kontaktformular` (`gesendet`, `fehlende-felder`, `ungueltige-email`, `zu-viele`, `kein-empfaenger`, `versand`). Das Formular (`id="kontaktformular"`) zeigt dann die Meldung (`p.contact-form__notice--ok` bzw. `--error`); die Eingaben sind nach einem Fehler leer. Per `fetch`/curl bleibt es bei der Tabelle oben.

### Zusatzfelder (Whitelist)

Optionale Felder werden nur uebernommen, wenn ihr Name in der Registry `contact_form_extra_fields()` (`lib/contact.php`) steht -- derzeit `company` (Firma), `phone` (Telefon), `telegram` (Telegram), `subject` (Betreff). Jeder Wert wird auf eine Zeile bereinigt und auf 200 Zeichen gekuerzt; leere Felder werden uebersprungen. `subject` landet nur im Body und setzt den Mail-Betreff nicht (bleibt `Kontaktformular: {name}`). Andere `$_POST`-Keys werden ignoriert.

### Spamschutz

- **Honeypot:** verstecktes Feld `url`. Befuellt -> stiller Drop (`303`), keine Mail.
- **Rate-Limit:** max. 5 Versandversuche pro IP (IPv6 je /64-Netz) und 60-Minuten-Fenster. Der Slot wird nach Honeypot und Validierung unter einer Dateisperre reserviert, bevor die Mail rausgeht; gleichzeitige Anfragen koennen das Limit so nicht gemeinsam unterlaufen. Scheitert der Versand, wird der Slot wieder frei. State liegt unter `website/private/cache/contact-form/ratelimit/<hash>.json` (gehashte IP, wegwerfbar). Bei Ueberschreitung `429`.

## Shortcodes

```html
<div data-plugin="contact-form" data-view="form"></div>
```

Mit explizitem Empfaenger:

```html
<div data-plugin="contact-form" data-view="form" data-recipient="office@example.com"></div>
```

| Attribut | Bedeutung |
|---|---|
| `recipient` | Optionaler Empfaenger. Wird serverseitig signiert, bevor das Formular ausgegeben wird. Ohne ihn steht weder Adresse noch Signatur in der Seite, `submit.php` nimmt den Standard-Empfänger, der beim Absenden eingestellt ist. |
| `form` | Name einer Formular-Datei in `website/public/includes/forms/`; dann gilt „Formulare aus einer Datei“ statt des Kontaktformulars. |

## Frontend einbinden

Den Shortcode-Marker in eine Seite unter `website/public/` setzen. Der Router ersetzt ihn bei aktiven Plugins durch das Formular mit der CSS-Klasse `contact-form` -- inklusive Honeypot-Feld und der Registry-Felder.

Custom-Formulare (eigenes Markup statt Shortcode) posten die Zusatzfelder direkt unter ihren Registry-Namen (`company`, `phone`, `telegram`, `subject`) und sollten das Honeypot-Feld `url` mitschicken (off-screen, `autocomplete=off`, `tabindex=-1`, `aria-hidden`).

## Bekannte Einschraenkungen

- Kein Captcha (externer Dienst + Keys) -- erst, wenn Honeypot + Rate-Limit nachweislich nicht reichen.
- Rate-Limit nutzt `REMOTE_ADDR`. Hinter Cloudflare/Proxy ist das die Proxy-IP, das Limit greift dann global statt pro Besucher. `X-Forwarded-For` wird bewusst nicht vertraut (spoofbar).
- Rate-Limit-State liegt in `website/private/cache/` und ist nicht persistent -- beim Leeren des Caches wird das Fenster zurueckgesetzt. Dateien, die eine Stunde nicht geschrieben wurden, loescht `contact_form_rate_prune()` gelegentlich (etwa jede 50. Reservierung).
- Betreff ist nicht vom Client steuerbar (Header-Injection-Schutz); `subject` ist nur ein Body-Feld.
- Nur Textmails; Anhänge nur bei Formularen aus einer Datei.
- Nach einem Fehler beim Server sind die Eingaben leer (die Prüfung im Browser fängt das Meiste vorher ab).
- Erfolg fuehrt zurueck zur Referrer-Seite.

## Für Agenten

### Was das Plugin tut

Das Plugin („Formulare“ im Admin) rendert per Shortcode ein einfaches Kontaktformular oder mit `data-form="<name>"` ein Formular aus `website/public/includes/forms/<name>.json` (Felder, Schritte, Anhänge; Aufbau in README, „Formulare aus einer Datei“). Es sendet an den Standard-Empfaenger, einen signierten Shortcode-Empfaenger bzw. den `recipient` der Formular-Datei.
Der Versand laeuft immer ueber den Core-Mailer (`backend/base/mail.php`), der SMTP nutzt, wenn `website/private/config/mail.config.php` vorhanden ist, und sonst auf PHP `mail()` zurueckfaellt.
Es schuetzt sich selbst per Honeypot und datei-basiertem IP-Rate-Limit (kein externer Dienst, keine DB) und kann optionale Zusatzfelder ueber eine Whitelist im Plugin-Code in den Mailtext aufnehmen.

### Was du als KI tun darfst

- Formularfelder im Renderer erweitern, wenn die Submit-Validierung synchron angepasst wird.
- Betreff, Textformat und Redirect-Verhalten vorsichtig anpassen.
- Sicherheitslogik fuer Spam-Schutz ergaenzen, z.B. Honeypot oder Rate-Limit.
- Dokumentation und Changelog bei jeder funktionalen Aenderung aktualisieren.

### Was du NICHT anfassen darfst

- Keine SMTP-Logik in dieses Plugin kopieren. Mailversand gehoert in `backend/base/mail.php`.
- Keine SMTP-Passwoerter in `website/private/config.json`, Page-JSON oder Plugin-Manifest speichern.
- Die Empfaenger-Signatur nicht entfernen, weil sonst Formular-Posts beliebige Empfaenger setzen koennten.
- Keine Datenbank-Abhaengigkeit einbauen.

### Dateistruktur

- `plugin.json` -- Manifest, Shortcode-Definition und Mail-Capability.
- `lib.php` -- Einstieg, laedt die Teile unter `lib/`.
- `lib/contact.php` -- Empfaenger-Ermittlung, signierte Empfaenger-Felder, Feld-Registry (`contact_form_extra_fields`), Mailtext (`contact_form_mail`), Honeypot (`CONTACT_FORM_HONEYPOT`), Antwort an den Browser.
- `lib/rate-limit.php` -- Bremse je IP (`CONTACT_FORM_RATE_*`).
- `lib/definition.php` -- Formulare aus einer Datei lesen und pruefen, Mailtext dazu.
- `lib/input.php` -- Eingaben und Anhaenge eines Formulars aus einer Datei pruefen.
- `api/submit.php` -- oeffentlicher Frontend-Endpoint fuer Formular-Posts (Honeypot -> Rate-Limit -> Validierung -> Whitelist-Body -> Versand).
- `api/form.php` -- Endpoint fuer Formulare aus einer Datei (Name in `?form=`, gleicher Ablauf, Eingaben gegen die Definition, Anhaenge).
- `render/form.php` -- Shortcode-Renderer fuer das Formular (inkl. Honeypot- und Registry-Feldern); mit `form`-Attribut bindet er `templates/definition.php` ein.
- `templates/definition.php` -- HTML eines Formulars aus einer Datei.
- `assets/form.js` -- Schritte einzeln zeigen, je Schritt pruefen, Groesse der Anhaenge pruefen. Ohne JS muss alles funktionieren.
- `README.md` -- diese Doku (Nutzer, Entwickler, Agenten).

### Datenbank

Keine Datenbank. Das Plugin speichert selbst keine Inhalte. Der Rate-Limit-State liegt wegwerfbar unter `website/private/cache/contact-form/ratelimit/<hash>.json` -- nur gehashte IP + Timestamps, niemals Roh-IP.

### Haeufige Anpassungen -- wie geht das?

Neues Pflicht-Formularfeld hinzufuegen:
1. Feld in `render/form.php` rendern.
2. Wert in `api/submit.php` lesen und validieren, in `contact_form_mail()` in den Mailtext aufnehmen.
3. README und Changelog aktualisieren.

Optionales Zusatzfeld (Whitelist) hinzufuegen:
1. Schluessel + Label in `contact_form_extra_fields()` in `lib/contact.php` ergaenzen (Reihenfolge = Reihenfolge im Mailtext, Label generisch halten).
2. Mehr ist nicht noetig: `render/form.php` rendert das Feld automatisch, `contact_form_mail()` liest, bereinigt (`core_mail_clean_header`, max. 200 Zeichen) und haengt es an den Body. Niemals beliebige `$_POST`-Keys uebernehmen -- nur die Registry.
3. Kein reservierter Key (`name`, `email`, `message`, `recipient`, `recipient_sig`, der Honeypot) gehoert in die Registry.
4. README und Changelog aktualisieren.

Standard-Empfaenger aendern:
1. Nicht im Plugin hart codieren.
2. Admin -> Einstellungen -> E-Mail / SMTP -> Standard-Empfaenger nutzen.
3. Alternativ im Shortcode `data-recipient` setzen; der Renderer signiert diesen Wert per HMAC mit `app_secret()` (`CONTACT_FORM_SIGNATURE_CONTEXT`). Ohne `data-recipient` kommt kein Empfänger in die Seite, `submit.php` nimmt den beim Absenden eingestellten.

Mailversand anpassen:
1. Nur den Aufruf von `core_mail_send()` in `api/submit.php` anpassen.
2. Transportdetails bleiben im Core-Mailer.

Neuen Feldtyp fuer Formulare aus einer Datei:
1. In `CONTACT_FORM_FIELD_TYPES` aufnehmen, Extras in `contact_form_definition_field()` pruefen.
2. Wert in `contact_form_definition_input()`/`contact_form_value_valid()` pruefen, HTML in `templates/definition.php`.
3. Test in `tests/plugins/forms.test.php`, README (Feldtabelle) und Changelog.

### Fehlervermeidung

- Formular-Dateien sind vertrauenswuerdig (Repo der Website), Besucher schicken nur den Namen; der Name geht nur durch `contact_form_definition_name_valid()` in einen Pfad. Uebernommen werden nur Felder der Definition, nie beliebige `$_POST`-Keys.
- `showIf` wertet der Server selbst aus (`contact_form_condition_met()` in `contact_form_definition_input()`), nie dem Browser glauben: Ausgeblendete Felder werden nicht geprueft und nicht uebernommen. Bedingungen zeigen nur auf fruehere Felder mit `options` (keine Zyklen).
- Anhaenge werden nie gespeichert, nur gemailt: Endung aus `CONTACT_FORM_FILE_TYPES` und `accept`, Inhalt per finfo passend (docx/xlsx mit ZipArchive als OOXML-Dokument der Art, `contact_form_ooxml_valid`), zusammen hoechstens `CONTACT_FORM_FILE_MAX_TOTAL`. Die Upload-Whitelist des Kerns (Bilder auf dem Server) gilt dafuer nicht.

- `api/submit.php` bleibt bewusst ohne Admin-Auth, weil Website-Besucher das Formular absenden muessen.
- Dynamische Werte im Renderer immer mit `htmlspecialchars()` escapen.
- Werte der Besucher kommen wörtlich in die Mail (kein `strip_tags`, „<3“ bleibt); das geht nur, weil die Mail `text/plain` ist. Eine HTML-Mail müsste jeden Wert escapen.
- Besucher-E-Mail nur als `Reply-To` verwenden, nicht als SMTP-Absender.
- Fehlerdetails aus SMTP nicht im Frontend ausgeben; sie koennen interne Hostnamen verraten. Antworttexte nur aus `CONTACT_FORM_TEXT` (`lib/contact.php`), nie als Literal oder Exception-Text.
- Honeypot-Treffer NIE mit `400`/`500` beantworten -- immer mit `303` wie ein Erfolg (`contact_form_submit_redirect()`), sonst lernen Bots den Mechanismus.
- Rate-Limit-Slot mit `contact_form_rate_reserve()` erst NACH Honeypot und Validierung, aber VOR `core_mail_send()` reservieren (Pruefen und Eintragen unter einer Sperre, sonst unterlaufen parallele Anfragen das Limit). Scheitert der Versand, `contact_form_rate_release()`. Frueher reservieren hiesse: Bots fuellen das Fenster mit Garbage-Posts und sperren echte Nutzer aus. `contact_form_rate_check()` ist nur die fruehe 429-Pruefung.
- Niemals die Roh-IP im Rate-Limit-State speichern, nur den HMAC mit dem Installations-Schlüssel (`hash_hmac('sha256', le_login_ip_key(IP), app_secret())`, IPv6 je /64-Netz).
- `subject` aus der Registry ist nur ein Body-Feld und darf den Mail-Betreff NICHT setzen (Header-Injection). Betreff bleibt `Kontaktformular: {name}`.
- Hinter Cloudflare/Proxy ist `REMOTE_ADDR` die Proxy-IP -- das Rate-Limit greift dann global. `X-Forwarded-For` wird bewusst nicht vertraut (spoofbar).

## Changelog

- **2026-11-15** -- `docx`/`xlsx`-Anhänge: mit der zip-Erweiterung nur echte OOXML-Dokumente der passenden Art (Hauptteil laut `[Content_Types].xml`, auch `word/document2.xml` von Word Online), kein beliebiges ZIP und keine Makro-Dokumente.
- **2026-11-15** -- Ohne `data-recipient` stehen weder Standard-Empfänger noch Signatur in der Seite; `submit.php` nimmt den beim Absenden eingestellten. Signaturen haben einen neuen Kontext: Alte Kopien einer Seite mit dem früheren Standard-Empfänger gehen an den aktuellen. Ebenso geht ein Formular mit eigenem `data-recipient`, das vor dem Update geladen wurde (offener Tab), einmal an den aktuellen Standard-Empfänger statt an seinen; nach dem Neuladen gilt wieder `data-recipient`.

- **2026-11-14** -- Ein ungültiger Formularname aus `?form=` kommt nicht mehr roh ins Log (Zeilenumbrüche fälschten sonst Einträge).

- **2026-11-11 -- v1.4.0** -- Abhängigkeiten in Formularen aus einer Datei: `showIf` an Feldern und Schritten (`{ "field", "value" }`), im Browser ein- und ausgeblendet (`disabled`), der Server übergeht ausgeblendete Felder. Fortschritt zählt nur sichtbare Schritte und setzt `--le-form-progress`.

- **2026-11-11 -- v1.3.0** -- Formulare aus einer Datei (`data-form`, `public/site/includes/forms/<name>.json`): zehn Feldtypen, mehrere Schritte (`assets/form.js`), Dateien als Mail-Anhang (Core-Mailer kann jetzt `attachments`), Endpoint `api/form.php`. Im Admin heißt das Plugin „Formulare“; Kontaktformular unverändert.

- **2026-10-28** -- Name, Nachricht und Zusatzfelder kommen wörtlich in die Mail (kein `strip_tags` mehr, „Ich <3“ und „a < b“ bleiben); die Mail ist `text/plain`. Mailtext baut `contact_form_mail()`.
- **2026-10-28** -- Antworttexte von `submit.php` stehen in `CONTACT_FORM_TEXT` (falsche Methode: `API_TEXT['method']`, jetzt deutsch). Betreff kuerzt den Namen per `mb_substr` (kein halbierter Umlaut). Rate-Limit-Dateien, die eine Stunde nicht geschrieben wurden, raeumt etwa jede 50. Reservierung weg.
- **2026-10-28** -- Rate-Limit reserviert den Slot unter `flock` vor dem Versand (`contact_form_rate_reserve()`, bei Versandfehler `contact_form_rate_release()`), parallele Anfragen kommen nicht mehr ueber 5 pro Stunde.
- **2026-10-13 -- v1.2.1** -- Empfaenger-Signatur und Rate-Limit-Hash per HMAC mit dem Installations-Schluessel (`app_secret()`) statt mit Pfad + Admin-Passwort (war faelschbar).
- **2026-05-23 -- v1.2.0** -- Spamschutz im Plugin: Honeypot-Feld `url` (stiller `303`-Drop) und datei-basiertes IP-Rate-Limit (max. 5 / 60 Min, gehashter State unter `content/cache/`, `429` bei Ueberschreitung). Konfigurierbare Zusatzfelder ueber die Whitelist `contact_form_extra_fields()` (`company`, `phone`, `telegram`, `subject`) -- bereinigt, auf 200 Zeichen gekuerzt, mit Label in den Mailtext. `subject` bleibt ein Body-Feld. Renderer gibt Honeypot- und Registry-Felder aus. Kein Core-Eingriff am Mailer.
- **2026-05-21 -- v1.1.0** -- Versand auf den zentralen Core-Mailer umgestellt. SMTP wird global in den Einstellungen verwaltet; ohne SMTP bleibt PHP `mail()` als Fallback.
- **2026-05-20 -- v1.0.0** -- Erstes Release mit Shortcode-Formular und `mail()`-Versand.
