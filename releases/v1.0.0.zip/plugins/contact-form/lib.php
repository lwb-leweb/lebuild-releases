<?php
declare(strict_types=1);

// Formulare: einziger Einstieg, lädt die Teile unter lib/ (contact vor definition: CONTACT_FORM_RESERVED_FIELDS nennt
// CONTACT_FORM_HONEYPOT beim Laden).

require_once __DIR__ . '/lib/contact.php';
require_once __DIR__ . '/lib/rate-limit.php';
require_once __DIR__ . '/lib/definition.php';
require_once __DIR__ . '/lib/input.php';
