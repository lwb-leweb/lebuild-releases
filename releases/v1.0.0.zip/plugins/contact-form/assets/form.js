// Formulare aus einer Datei (templates/definition.php): Schritte einzeln zeigen, je Schritt prüfen, Größe der Anhänge
// vor dem Absenden prüfen, Felder und Schritte mit showIf (data-le-form-if) ein- und ausblenden. Ausgeblendete
// Felder sind disabled: Der Browser prüft und schickt sie nicht. Ohne dieses Skript stehen alle Schritte
// untereinander und der Server prüft allein (er übergeht ausgeblendete Felder ebenso).
(function () {
  'use strict';

  var TOO_BIG = 'Die Dateien sind zusammen zu groß (höchstens %s MB).';
  var PICK_ONE = 'Bitte mindestens eine Möglichkeit wählen.';

  function controls(root) {
    return Array.prototype.slice.call(root.querySelectorAll('input, select, textarea'));
  }

  // Pflicht-Gruppe aus Checkboxen: mindestens eine angehakt (kann der Browser nicht selbst).
  function groupsValid(root) {
    var groups = root.querySelectorAll('[data-le-form-required]');
    for (var i = 0; i < groups.length; i++) {
      var boxes = groups[i].querySelectorAll('input[type="checkbox"]');
      if (boxes.length && boxes[0].disabled) continue; // ausgeblendet
      var any = Array.prototype.some.call(boxes, function (b) { return b.checked; });
      if (boxes.length) {
        boxes[0].setCustomValidity(any ? '' : PICK_ONE);
        if (!any) {
          boxes[0].reportValidity();
          boxes[0].addEventListener('change', function () { this.setCustomValidity(''); }, { once: true });
          return false;
        }
      }
    }
    return true;
  }

  function sizeValid(form) {
    var max = parseInt(form.getAttribute('data-max-total'), 10) || 0;
    var inputs = form.querySelectorAll('input[type="file"]');
    var total = 0;
    Array.prototype.forEach.call(inputs, function (input) {
      Array.prototype.forEach.call(input.files || [], function (f) { total += f.size; });
    });
    var first = inputs[0];
    if (!first || !max) return true;
    first.setCustomValidity(total > max ? TOO_BIG.replace('%s', Math.round(max / 1048576)) : '');
    if (total > max) {
      first.reportValidity();
      return false;
    }
    return true;
  }

  function valid(root, form) {
    if (!groupsValid(root)) return false;
    var list = controls(root);
    for (var i = 0; i < list.length; i++) {
      if (!list[i].checkValidity()) {
        list[i].reportValidity();
        return false;
      }
    }
    return root !== form && !root.querySelector('input[type="file"]') ? true : sizeValid(form);
  }

  function setup(form) {
    if (form.__leForm) return;
    form.__leForm = true;
    // Das Skript prüft selbst, Schritt für Schritt; der Browser würde sonst an Feldern verborgener Schritte scheitern.
    form.noValidate = true;
    form.addEventListener('change', function (e) {
      if (e.target.type === 'file') e.target.setCustomValidity('');
    });
    // Bedingte Pflichtfelder: ausgeblendet sind sie disabled und zählen dann nicht.
    Array.prototype.forEach.call(form.querySelectorAll('[data-le-form-required-shown]'), function (c) { c.required = true; });

    var steps = Array.prototype.slice.call(form.querySelectorAll('[data-le-form-step]'));
    var back = form.querySelector('[data-le-form-back]');
    var next = form.querySelector('[data-le-form-next]');
    var submit = form.querySelector('.le-form__submit');
    var progress = form.querySelector('[data-le-form-progress]');
    var current = steps[0] || null;
    var paged = steps.length > 1 && back && next && submit && progress;

    // showIf: Feld oder Schritt nur, wenn das Feld data-le-form-if eine der Optionen hat. In Reihenfolge des
    // Dokuments, damit ausgeblendete Felder (disabled, nicht in FormData) ihre abhängigen mitnehmen.
    var conditional = Array.prototype.slice.call(form.querySelectorAll('[data-le-form-if]'));
    conditional.forEach(function (el) {
      try { el.__leIf = JSON.parse(el.getAttribute('data-le-form-if-values')) || []; } catch (e) { el.__leIf = []; }
    });
    function shown(el) { return !el.__leOff; }
    function active() { return steps.filter(shown); }
    // Gesamtzahl für „Schritt x von y“: Ausgeblendete Schritte, deren Frage noch offen ist, zählen je Frage
    // einmal mit (Ja/Nein-Zweige), damit die Zahl nach der Antwort nicht springt.
    function total() {
      var data = new FormData(form);
      var open = {};
      steps.forEach(function (s) {
        var name = s.__leOff && s.getAttribute('data-le-form-if');
        if (name && !data.getAll(name).concat(data.getAll(name + '[]')).length) open[name] = true;
      });
      return active().length + Object.keys(open).length;
    }
    function update() {
      conditional.forEach(function (el) {
        var data = new FormData(form);
        var name = el.getAttribute('data-le-form-if');
        var values = data.getAll(name).concat(data.getAll(name + '[]'));
        var outer = el.parentElement && el.parentElement.closest('[data-le-form-if]');
        var on = (!outer || shown(outer)) && values.some(function (v) { return el.__leIf.indexOf(v) !== -1; });
        el.__leOff = !on;
        if (!el.hasAttribute('data-le-form-step')) el.hidden = !on;
        controls(el).forEach(function (c) { c.disabled = !on; });
      });
    }

    function show(step, focus) {
      current = step;
      var list = active();
      var index = list.indexOf(step);
      steps.forEach(function (s) { s.hidden = s !== step; });
      back.hidden = index === 0;
      next.hidden = index === list.length - 1;
      submit.hidden = index !== list.length - 1;
      progress.hidden = false;
      var count = Math.max(total(), list.length);
      progress.textContent = 'Schritt ' + (index + 1) + ' von ' + count;
      progress.style.setProperty('--le-form-progress', String((index + 1) / count));
      if (focus) {
        var first = controls(step)[0];
        if (first) first.focus();
      }
    }
    function go(delta) {
      var list = active();
      var target = list[list.indexOf(current) + delta];
      if (target) show(target, true);
    }

    function onChange() {
      update();
      if (paged) show(current, false); // Anzahl der Schritte kann sich geändert haben
    }
    form.addEventListener('change', onChange);
    form.addEventListener('input', onChange);

    form.addEventListener('submit', function (e) {
      if (paged) {
        var list = active();
        var index = list.indexOf(current);
        // Enter in einem früheren Schritt: weiter statt absenden.
        if (index < list.length - 1) {
          e.preventDefault();
          if (valid(current, form)) go(1);
          return;
        }
        // Letzter Schritt: ist ein früherer doch unvollständig, dorthin zurück.
        for (var i = 0; i < index; i++) {
          if (!controls(list[i]).every(function (c) { return c.checkValidity(); })) {
            e.preventDefault();
            show(list[i], false);
            valid(list[i], form);
            return;
          }
        }
      }
      if (!valid(form, form)) e.preventDefault();
    });

    update();
    if (!paged) return;
    next.addEventListener('click', function () {
      if (valid(current, form)) go(1);
    });
    back.addEventListener('click', function () { go(-1); });
    show(current, false);
  }

  function init() {
    Array.prototype.forEach.call(document.querySelectorAll('form[data-le-form]'), setup);
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
