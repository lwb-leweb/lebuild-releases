<?php
declare(strict_types=1);

// Hook des Info-Hinweises (knowledgebase/hooks.md).

/**
 * Hook: Hinweis vor </body>, CSS vor </head>. Besucher ohne aktuellen Hinweis bekommen die Seite
 * unverändert, Angemeldete immer den Hinweis zum Bearbeiten.
 */
function site_notice_filter_site_html(string $html): string
{
    if (le_html_close_tag($html, 'body') === null || str_contains($html, SITE_NOTICE_ROOT_ATTR)) {
        return $html;
    }
    try {
        $row = site_notice_entry();
    } catch (Throwable $e) {
        // Fehlertext nur ins Log, die Seite kommt ohne Hinweis.
        error_log('site-notice: ' . $e->getMessage());
        return $html;
    }
    $state = site_notice_state($row, date('Y-m-d'));
    $editor = signed_in_user() !== null;
    if ($state !== null && !$editor) {
        return $html;
    }

    $html = le_plugin_insert_html($html, 'body', site_notice_html($row, $state, $editor), SITE_NOTICE_ROOT_ATTR);

    return le_plugin_insert_style($html, SITE_NOTICE_STYLE);
}
