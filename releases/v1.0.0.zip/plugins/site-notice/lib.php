<?php
declare(strict_types=1);

// Info-Hinweis: einziger Einstieg, lädt die Teile unter lib/ (Hinweis, Hook filter_site_html).

require_once __DIR__ . '/lib/notice.php';
require_once __DIR__ . '/lib/hooks.php';
