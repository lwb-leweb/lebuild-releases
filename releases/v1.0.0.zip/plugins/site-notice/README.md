# Info-Hinweis Plugin

Ein kurzer Hinweis auf jeder Seite der Website, z. B. „Wir sind im Betriebsurlaub“ oder „Wir bauen gerade um“. Besucher klicken ihn weg; der Browser merkt sich das.

## Aktivierung

Im Backend unter Plugins aktivieren. Legt die Tabelle `site_notices` an, danach steht „Info-Hinweis“ in der Seitenleiste. Die Website braucht keinen Einbau: Der Hinweis erscheint auf jeder Seite unten links.

## Was es kann

- Genau ein Hinweis; leerer Text heißt: kein Hinweis
- Optional Zeitraum: „Anzeigen ab“ und „Anzeigen bis“ (je einschließlich), leer heißt sofort bzw. ohne Ende; ein Ende vor dem Beginn weist das Speichern im Seiten-Editor ab (400)
- Wegklicken; werden Text, Beginn oder Ende geändert, sehen ihn alle wieder
- Ohne aktuellen Hinweis bleibt die Seite für Besucher unverändert (kein CSS, kein Skript)

## Bearbeiten

Auf der Website (auch Redakteure): Angemeldete sehen den Hinweis unten links immer, auch weggeklickt, vor oder nach dem Zeitraum (gestrichelt, mit Grund); ohne Text steht dort „+ Info-Hinweis“. Klick öffnet das Formular. In „Ansehen“ ist ausgeblendet, was Besucher nicht sehen. Abschalten: Text leeren oder „Anzeigen bis“ auf gestern setzen.

Im Admin gibt es weiter die generische Liste; zählt dort aber nur der älteste Eintrag.

## API-Endpoints

Seiten-Editor (`inlineEdit`): `api/{list,get,save}.php` arbeiten immer auf dem einen Hinweis (älteste Zeile), `save` legt ihn beim ersten Mal an und antwortet mit der festen Kennung `SITE_NOTICE_ITEM_ID`, danach nur mit `version` aus `get` (sonst 409, „Neu“ im Backend überschreibt ihn so nicht); `delete` löscht ihn (nur im Backend, der Seiten-Editor bietet kein Löschen). Das Backend (generische Ansicht) nutzt dieselben Endpoints; die generischen unter `/api/plugins/generic/` lehnen das Plugin ab.

## Frontend einbinden

Nichts einzubauen. Farben passt die Website über CSS-Variablen an:

```css
.site-notices { --site-notice-bg: #0b3d2e; --site-notice-color: #fff; --site-notice-radius: 4px; }
```

Klassen: `.site-notices` (Wurzel, fest unten links, auf dem Handy volle Breite), `.site-notice`, `.site-notice__text`, `.site-notice__close`; nur angemeldet `.site-notice--off`, `.site-notice--add`, `.site-notice__state`.

## Datenbank

`site_notices`: `id`, `title` (Nachricht, mehrzeiliger Text, leer erlaubt), `starts_on`, `ends_on` (`YYYY-MM-DD` oder leer), `created_at`, `updated_at`.

## Bekannte Einschränkungen

- Nur Text, keine Links oder Formatierung.
- Ohne JavaScript erscheint kein Hinweis (versteckt ausgeliefert, damit Weggeklicktes nicht aufblitzt).
- Weggeklickt gilt pro Browser (localStorage), im privaten Fenster bis zum Schließen; sperrt der Browser den Speicher, kommt der Hinweis auf jeder Seite wieder.
- Steht der Cookie-Banner offen, liegt er über dem Hinweis.

## Für Agenten

### Was das Plugin tut

Zeigt einen kurzen Hinweis (Betriebsurlaub, Umbau) auf jeder Seite der Website unten links, wegklickbar, bearbeitbar im Seiten-Editor (Einzelansicht mit fester Kennung `SITE_NOTICE_ITEM_ID`). Bedienung: `README.md`.

### Was du als KI tun darfst

- Aussehen in `assets/site-notice.css` ändern; Klassen `site-notice*` und die Variablen `--site-notice-*` bleiben, Websites stylen darauf.
- Texte in `SITE_NOTICE_TEXT` (`lib/notice.php`) anpassen.
- Für eine Website den Hinweis per `api/save.php` (`{type: notice, data}`, gibt es ihn schon: mit `version` aus `api/get.php`) setzen.

### Was du NICHT anfassen darfst

- Kein eigenes Admin-Modul: Das Backend kommt aus `schema.fields` (generische Ansicht). Ein Modul erst, wenn das Schema nicht mehr reicht.
- `site_notice_key()` nicht ohne Not ändern: Sonst sehen alle Besucher weggeklickte Hinweise wieder.

### Dateistruktur

- `plugin.json` — Manifest mit Schema (Nachricht, Anzeigen ab/bis), Sidebar ohne Modul
- `lib.php` — Einstieg, lädt `lib/notice.php` (der eine Hinweis `site_notice_entry`, älteste Zeile; Zustand, HTML für Besucher und Angemeldete, Speichern) und `lib/hooks.php` (Hook `filter_site_html`)
- `api/` — Endpoints für Seiten-Editor (`inlineEdit`) und Backend; `delete` löscht den Hinweis (nur das Backend bietet es an)
- `assets/site-notice.css`, `assets/site-notice.js` — Grundform, Anzeigen und Wegklicken (localStorage `site-notice-dismissed`)
- `sql/install.mysql.sql`, `sql/install.sqlite.sql` — Tabelle `site_notices` (Deinstallieren löscht sie über `tables`)

### Datenbank

`site_notices` (`id`, `title`, `starts_on`, `ends_on`, `created_at`, `updated_at`). Die Nachricht heißt `title`, damit die generische Liste sie als Titel zeigt (`TITLE_FIELDS` in `frontend/shared/entry-form/text.js`).

### Häufige Anpassungen — wie geht das?

**Neues Feld (z. B. Link):** Feld in `plugin.json` (`schema.fields`), Spalte in beiden `sql/install.*.sql` (bestehende Installationen brauchen eine Migration), Ausgabe in `site_notice_html()` escaped, README und Test anpassen, Version hochzählen.

**Andere Position:** nur `assets/site-notice.css` (`.site-notices`).

### Fehlervermeidung

- Text immer über `le_text_lines()` ausgeben (escaped, Umbrüche als `<br>`), nie roh.
- Der Filter läuft auf jeder Seite: ohne aktuelle Hinweise früh zurück, Fehler nur ins Log, die Seite kommt dann ohne Hinweis.
- Datum gegen `date('Y-m-d')` vergleichen (Zeitzone `APP_TIMEZONE`), nicht in SQL rechnen (`CURDATE()` gibt es unter SQLite nicht).

## Changelog

- **2026-11-15** — Die Kennung fürs Wegklicken enthält Beginn und Ende: Ein neuer Zeitraum mit demselben Text erscheint wieder (einmalig sehen dadurch alle einen schon weggeklickten Hinweis wieder).
- **2026-11-14** — `api/save.php` weist ein Ende vor dem Beginn ab (400, `SITE_NOTICE_TEXT['dateOrder']`); bisher wurde es gespeichert und der Hinweis erschien nie.
- **2026-11-10 — v1.1.0** — Nur noch ein Hinweis, direkt auf der Website bearbeitbar (auch für Redakteure); leerer Text schaltet ihn ab.
- **2026-11-09 — v1.0.0** — Erste Fassung: Hinweise mit optionalem Zeitraum auf jeder Seite, wegklickbar.
