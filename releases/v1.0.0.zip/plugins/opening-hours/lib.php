<?php
declare(strict_types=1);

// Öffnungszeiten: einziger Einstieg, lädt die Teile unter lib/ (Zeiten, Hook filter_site_html).

require_once __DIR__ . '/lib/hours.php';
require_once __DIR__ . '/lib/hooks.php';
