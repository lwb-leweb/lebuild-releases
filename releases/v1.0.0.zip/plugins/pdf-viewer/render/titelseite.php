<?php
require_once __DIR__ . '/../lib.php';

// Erste Seite eines PDFs als Bild (Leinwand), gezeichnet von assets/pdf-viewer.js, sobald sie sichtbar wird.
$pdfSrc = pdf_viewer_src($attrs['src'] ?? null);
if ($pdfSrc === null) {
    echo PDF_VIEWER_INVALID;
    return;
}
?>
<span class="pdf-titelseite" data-pdf-titelseite="<?= htmlspecialchars($pdfSrc, ENT_QUOTES) ?>"></span>
