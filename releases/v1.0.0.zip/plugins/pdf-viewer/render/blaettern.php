<?php
require_once __DIR__ . '/../lib.php';

// PDF zum Durchblättern: Bühne, Leiste (zurück, Seite, weiter, Vollbild) und Download; zeichnet assets/pdf-viewer.js.
$pdfSrc = pdf_viewer_src($attrs['src'] ?? null);
if ($pdfSrc === null) {
    echo PDF_VIEWER_INVALID;
    return;
}
$pdfDownload = strtolower(trim((string) ($attrs['download'] ?? ''))) !== PDF_VIEWER_NO_DOWNLOAD;
$pdfText = static fn (string $key): string => htmlspecialchars(PDF_VIEWER_TEXT[$key], ENT_QUOTES);
?>
<div class="pdf-blaetterer" data-pdf-blaetterer="<?= htmlspecialchars($pdfSrc, ENT_QUOTES) ?>">
  <div class="pdf-blaetterer__buehne" data-buehne><p class="pdf-blaetterer__status" data-status><?= $pdfText('loading') ?></p></div>
  <div class="pdf-blaetterer__leiste">
    <button type="button" class="pdf-blaetterer__knopf" data-zurueck aria-label="<?= $pdfText('previous') ?>" title="<?= $pdfText('previous') ?>"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg></button>
    <span class="pdf-blaetterer__seite" data-seite aria-live="polite"></span>
    <button type="button" class="pdf-blaetterer__knopf" data-weiter aria-label="<?= $pdfText('next') ?>" title="<?= $pdfText('next') ?>"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg></button>
    <button type="button" class="pdf-blaetterer__knopf pdf-blaetterer__knopf--neben" data-zoom-aus disabled aria-label="<?= $pdfText('zoomOut') ?>" title="<?= $pdfText('zoomOut') ?>"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/><path d="M8 11h6"/></svg></button>
    <button type="button" class="pdf-blaetterer__knopf pdf-blaetterer__knopf--zoom" data-zoom-ein aria-label="<?= $pdfText('zoomIn') ?>" title="<?= $pdfText('zoomIn') ?>"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/><path d="M11 8v6"/><path d="M8 11h6"/></svg></button>
    <button type="button" class="pdf-blaetterer__knopf pdf-blaetterer__knopf--zoom" data-vollbild aria-label="<?= $pdfText('fullscreen') ?>" title="<?= $pdfText('fullscreen') ?>"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 3H5a2 2 0 0 0-2 2v3"/><path d="M21 8V5a2 2 0 0 0-2-2h-3"/><path d="M3 16v3a2 2 0 0 0 2 2h3"/><path d="M16 21h3a2 2 0 0 0 2-2v-3"/></svg></button>
<?php if ($pdfDownload): ?>
    <a class="pdf-blaetterer__download" href="<?= htmlspecialchars($pdfSrc, ENT_QUOTES) ?>" download><?= $pdfText('download') ?></a>
<?php endif ?>
  </div>
  <noscript><p class="pdf-blaetterer__status"><?= $pdfText('noscript') ?></p></noscript>
</div>
