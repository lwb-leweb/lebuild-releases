<?php
declare(strict_types=1);

// PDF Viewer: einziger Einstieg, lädt die Teile unter lib/ (Prüfung der Adresse, Hook filter_site_html).

require_once __DIR__ . '/lib/viewer.php';
require_once __DIR__ . '/lib/hooks.php';
