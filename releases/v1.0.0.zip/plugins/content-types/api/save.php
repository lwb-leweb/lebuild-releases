<?php
declare(strict_types=1);

require_auth();
require_csrf();
le_indexnow_watch();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$type = (string) ($body['type'] ?? '');
if (!content_types_name_valid($type)) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidType']], 400);
}

$rawValues = is_array($body['data'] ?? null) ? $body['data'] : [];
$id = isset($body['id']) ? (int) $body['id'] : null;

try {
    // Nacheinander mit dem Erledigen offener Uploads (le_open_uploads_hold): kein Bild verschwindet mitten im Speichern.
    $newId = le_open_uploads_hold(static function () use ($type, $rawValues, $id, $body): int {
        $stored = $id !== null && $id > 0 ? content_types_fetch_by_id($type, $id) : null;
        if ($stored !== null) {
            plugin_entry_conflict_check($body, content_types_entry_version($stored));
        }
        return content_types_save($type, $rawValues, $id);
    });
} catch (InvalidArgumentException $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 400);
} catch (Throwable $e) {
    plugin_failure_response('save', $e);
}
if ($newId === 0) {
    // Inzwischen gelöscht: nicht als gespeichert melden.
    json_response(['ok' => false, 'error' => API_TEXT['notFound']], 404);
}
le_activity_log((int) $id > 0 ? 'plugin_entry_updated' : 'plugin_entry_created', $type . ' #' . $newId);

json_response(['ok' => true, 'id' => $newId]);
