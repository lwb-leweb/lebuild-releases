<?php
declare(strict_types=1);

require_auth();

$type = (string) ($_GET['type'] ?? '');
if (!content_types_name_valid($type)) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidType']], 400);
}
// Unbekannter Typ ist ein Fehler der Anfrage (400), eine kaputte Definition einer des Servers.
if (!in_array($type, content_types_list_names(), true)) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidType']], 400);
}

try {
    $def = content_types_load($type);
    // Ohne limit alle Einträge (Backend: jeder Eintrag bearbeitbar, auch nach mehreren Importen), auch noch nicht fällige.
    $rows = content_types_fetch_list($type, isset($_GET['limit']) ? (int) $_GET['limit'] : null, null, $def);
    $schema = content_types_form_columns($def);
    // Stand je Eintrag (nur, wenn der Typ Termine kennt): id → scheduled/expired, fehlt = online.
    $visibility = [];
    if (isset($def['publishField']) || isset($def['expireField'])) {
        $now = db_now();
        foreach ($rows as $row) {
            $state = content_types_visibility($def, $row, $now);
            if ($state !== null) {
                $visibility[$row['id']] = $state;
            }
        }
    }
} catch (Throwable $e) {
    plugin_failure_response('load', $e);
}

json_response([
    'ok' => true,
    'type' => $type,
    'label' => $def['label'],
    'schema' => $schema,
    'rows' => $rows,
    // Liste im Backend: Spalten (Feldnamen) und ob es einen Stand gibt (publishField/expireField).
    'columns' => content_types_admin_columns($def),
    'scheduling' => isset($def['publishField']) || isset($def['expireField']),
    'visibility' => (object) $visibility,
]);
