<?php
declare(strict_types=1);

// Content-Typen: Liste des Shortcodes (data-limit, data-filter, Filterleiste, Seiten, data-id und ihre Adressen).

// Einträge einer Liste: Vorgabe für data-limit und höchstens so viele.
const CONTENT_TYPES_LIST_LIMIT = 20;
const CONTENT_TYPES_LIST_MAX = 500;
// data-filter="<feld>=<wert>": Trennzeichen zwischen Feld und Wert (das erste zählt).
const CONTENT_TYPES_FILTER_SEPARATOR = '=';
// data-filter-by="<feld>" (Auswahlfeld) zeigt die Filterleiste, data-paging mit diesem Wert „Mehr laden“ (data-limit je
// Seite). Eine solche Liste braucht data-id (PLUGIN_SLUG_PATTERN, eindeutig auf der Seite) und liest nur ihre eigenen
// Parameter (content_types_list_param): ?<id>-<feld>=<Slug der Option> (plugin_schema_slugify) und
// ?<id>-<CONTENT_TYPES_PAGE_PARAM>=<n> ab 2. Fehlt die ID, ist sie ungültig oder doppelt: leere Liste, Grund ins Log.
const CONTENT_TYPES_PAGING_ON = 'yes';
const CONTENT_TYPES_PAGE_PARAM = 'seite';
const CONTENT_TYPES_PARAM_SEPARATOR = '-';
// Name des Shortcode-Attributs der ID (data-id; auch in assets/list.js).
const CONTENT_TYPES_LIST_ID_ATTR = 'id';
const CONTENT_TYPES_LIST_ID_TEXT = [
    'invalid' => 'data-id missing or invalid (lowercase letters, digits, -): %s',
    'duplicate' => 'data-id used twice on the page: %s',
];
// Gründe (Log), warum data-filter-by nicht nutzbar ist: kein Auswahlfeld mit Optionen bzw. ein Feld mit dem Namen des
// Seiten-Parameters (Filter und Seite wären derselbe Parameter <id>-<CONTENT_TYPES_PAGE_PARAM>).
const CONTENT_TYPES_FILTER_BY_TEXT = [
    'notSelect' => 'filter-by field is not a select: %s',
    'pageParam' => 'filter-by field has the name of the page parameter: %s',
];

// Ausgabe des Shortcodes statt der Liste, wenn der Typ fehlt, ungültig ist oder die Einträge nicht
// laden (Grund nur im Log, nie auf der Website).
const CONTENT_TYPES_RENDER_FAILED = '<!-- content-types: list unavailable -->';

/** Gespeicherter Wert eines Feldes als Text, wie Filter ihn vergleichen (fehlend ''); null für Listen. */
function content_types_row_text(array $row, string $field): ?string
{
    $value = $row[$field] ?? '';

    return is_scalar($value) ? (string) $value : null;
}

/** Ob ein Eintrag zum Filter [feld, wert] passt (content_types_row_text gleich dem Wert). */
function content_types_row_matches(array $row, array $filter): bool
{
    return content_types_row_text($row, $filter[0]) === $filter[1];
}

/**
 * data-filter einer Liste als [feld, wert]; null ohne Attribut. Wirft, wenn das Trennzeichen fehlt oder
 * das Feld kein einfaches Feld des Typs ist ($schema aus content_types_schema_columns, list zählt nicht).
 */
function content_types_list_filter(array $schema, ?string $raw): ?array
{
    if ($raw === null) {
        return null;
    }
    $parts = explode(CONTENT_TYPES_FILTER_SEPARATOR, $raw, 2);
    $fields = array_column($schema, 'type', 'name');
    if (count($parts) !== 2 || !isset($fields[$parts[0]]) || in_array($fields[$parts[0]], ['list', 'blocks'], true)) {
        throw new InvalidArgumentException('unknown filter field: ' . $parts[0]);
    }

    return $parts;
}

/** data-limit einer Liste: ganze Zahl ab 1, sonst CONTENT_TYPES_LIST_LIMIT; höchstens CONTENT_TYPES_LIST_MAX. */
function content_types_list_limit(?string $raw): int
{
    $limit = filter_var($raw, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);

    return $limit === false ? CONTENT_TYPES_LIST_LIMIT : min($limit, CONTENT_TYPES_LIST_MAX);
}

/**
 * Feld aus data-filter-by einer Liste; null ohne Attribut. Wirft (CONTENT_TYPES_FILTER_BY_TEXT), wenn es kein
 * Auswahlfeld des Typs mit options oder optionsFrom ist ($schema aus content_types_schema_columns) oder wie
 * CONTENT_TYPES_PAGE_PARAM heißt.
 */
function content_types_list_filter_by(array $schema, ?string $name): ?array
{
    if ($name === null) {
        return null;
    }
    $field = array_column($schema, null, 'name')[$name] ?? null;
    if (($field['type'] ?? null) !== 'select' || (!is_array($field['options'] ?? null) && !isset($field['optionsFrom']))) {
        throw new InvalidArgumentException(sprintf(CONTENT_TYPES_FILTER_BY_TEXT['notSelect'], $name));
    }
    if ($name === CONTENT_TYPES_PAGE_PARAM) {
        throw new InvalidArgumentException(sprintf(CONTENT_TYPES_FILTER_BY_TEXT['pageParam'], $name));
    }

    return $field;
}

/**
 * Werte eines Auswahlfeldes in seiner Reihenfolge (plugin_schema_select_options): feste options oder die Titel des
 * Typs aus optionsFrom, diese je Anfrage einmal gelesen (Filterleiste und jede Karte mit ct_filter_href).
 */
function content_types_select_options(array $field): array
{
    static $from = [];
    if (!isset($field['optionsFrom'])) {
        return plugin_schema_select_options($field);
    }

    return $from[(string) $field['optionsFrom']] ??= plugin_schema_select_options(content_types_options_from($field, null));
}

/**
 * Optionen der Filterleiste: die Werte $options von $field (content_types_select_options) mit mindestens einem
 * Eintrag in $rows (Grundmenge der Liste: Typ, data-filter, Zeitfenster), in der Reihenfolge des Feldes.
 */
function content_types_filter_options(array $field, array $options, array $rows): array
{
    $present = [];
    foreach ($rows as $row) {
        $present[content_types_row_text($row, $field['name']) ?? ''] = true;
    }

    return array_values(array_filter($options, static fn (string $option): bool => isset($present[$option])));
}

/**
 * Seite $page (ab 1) der Einträge $rows (in Listenreihenfolge, schon gefiltert) mit je $limit: ['rows' => ihr
 * Ausschnitt, 'more' => ob danach weitere kommen].
 */
function content_types_list_slice(array $rows, int $page, int $limit): array
{
    $offset = ($page - 1) * $limit;

    return ['rows' => array_slice($rows, $offset, $limit), 'more' => count($rows) > $offset + $limit];
}

/** Option, deren Slug (plugin_schema_slugify) $slug ist (Wert aus der Adresse); null, wenn keine passt. */
function content_types_filter_option(array $options, mixed $slug): ?string
{
    foreach ($options as $option) {
        if (is_string($slug) && plugin_schema_slugify($option) === $slug) {
            return $option;
        }
    }

    return null;
}

/**
 * ?seite= einer Liste mit data-paging: ganze Zahl ab 2, sonst Seite 1; ebenso, wenn der Versatz (Seite mal $limit)
 * keine ganze Zahl mehr wäre.
 */
function content_types_list_page(mixed $raw, int $limit): int
{
    $page = is_string($raw) ? filter_var($raw, FILTER_VALIDATE_INT, ['options' => ['min_range' => 2, 'max_range' => intdiv(PHP_INT_MAX, $limit)]]) : false;

    return $page === false ? 1 : $page;
}

/**
 * data-id einer Liste mit data-filter-by bzw. data-paging, vorgemerkt für diese Anfrage (content_types_list_ids).
 * Wirft (CONTENT_TYPES_LIST_ID_TEXT), wenn sie fehlt, ungültig ist oder eine andere Liste der Seite sie schon hat.
 */
function content_types_list_id(?string $id): string
{
    if (in_array(content_types_list_id_check($id), content_types_list_ids($id), true)) {
        throw new InvalidArgumentException(sprintf(CONTENT_TYPES_LIST_ID_TEXT['duplicate'], $id));
    }

    return $id;
}

/** $id, wenn sie als data-id taugt (PLUGIN_SLUG_PATTERN); wirft sonst (CONTENT_TYPES_LIST_ID_TEXT['invalid']). */
function content_types_list_id_check(?string $id): string
{
    if ($id === null || !preg_match(PLUGIN_SLUG_PATTERN, $id)) {
        throw new InvalidArgumentException(sprintf(CONTENT_TYPES_LIST_ID_TEXT['invalid'], (string) $id));
    }

    return $id;
}

/** IDs der Listen dieser Anfrage, die ihre Parameter aus der Adresse lesen; mit $add kommt eine dazu. Liefert die bisherigen. */
function content_types_list_ids(?string $add = null): array
{
    static $ids = [];
    $before = $ids;
    if ($add !== null && !in_array($add, $ids, true)) {
        $ids[] = $add;
    }

    return $before;
}

/** Name des Parameters $name (Feld oder CONTENT_TYPES_PAGE_PARAM) der Liste $id in der Adresse: <id>-<name>. */
function content_types_list_param(string $id, string $name): string
{
    return $id . CONTENT_TYPES_PARAM_SEPARATOR . $name;
}

/** Angefragte Adresse ohne Query (kanonischer Pfad, prozentkodiert wie le_site_request_url). */
function content_types_request_path(): string
{
    return explode('?', le_site_request_url() ?? LE_SITE_HOME_URL, 2)[0];
}

/** Adresse $path mit den Parametern $query (unescaped; ohne Parameter nur der Pfad). */
function content_types_list_href(string $path, array $query): string
{
    return $path . ($query === [] ? '' : '?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986));
}
