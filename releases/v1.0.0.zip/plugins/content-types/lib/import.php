<?php
declare(strict_types=1);

// Content-Typen: Einträge importieren (api/import.php, Startpakete).

// Import (api/import.php): höchstens so viele Einträge und Bytes (Anfrage) auf einmal, Meldungen (Zeile ab 1,
// Feld, Grund ohne Feldnamen; image mit UPLOADS_URL und LE_SITE_FILES_URL, action mit den erlaubten Zielen).
const CONTENT_TYPES_IMPORT_MAX = 500;
const CONTENT_TYPES_IMPORT_MAX_BYTES = 5 * BYTES_PER_MB;
const CONTENT_TYPES_IMPORT_TEXT = [
    'tooLarge' => 'Die Datei ist größer als %d MB.',
    'notList' => 'Die Datei muss eine Liste (JSON-Array) von Einträgen enthalten.',
    'empty' => 'Die Datei enthält keine Einträge.',
    'tooMany' => 'Höchstens %d Einträge auf einmal.',
    'entry' => 'Zeile %d: Kein Eintrag (JSON-Objekt).',
    'line' => 'Zeile %d, %s: %s',
    'action' => 'Dieses Ziel gibt es hier nicht (erlaubt: %s).',
    'image' => 'Nur Bilder und PDFs, die es schon gibt, unter %s oder %s.',
];

/**
 * Importiert $entries (Liste von Einträgen, höchstens CONTENT_TYPES_IMPORT_MAX) ganz oder gar nicht: jeder
 * wird wie beim Speichern geprüft (content_types_values), ein action muss der Typ erlauben (ohne gilt
 * defaultAction), Bilder müssen vorhandene Dateien sein (upload_image_exists). Neue Einträge kommen in
 * dieser Reihenfolge ans Ende; Adressen (slug) sind eindeutig, auch untereinander, weil jeder Eintrag in
 * derselben Transaktion eingefügt ist, bevor der nächste geprüft wird. Liefert die Anzahl.
 * Wirft InvalidArgumentException (Liste, Anzahl, kein Objekt) bzw. PluginFieldException mit entry.
 */
function content_types_import(string $type, mixed $entries): int
{
    if (!content_types_name_valid($type)) {
        throw new InvalidArgumentException(API_TEXT['invalidType']);
    }
    if (!is_array($entries) || array_values($entries) !== $entries) {
        throw new InvalidArgumentException(CONTENT_TYPES_IMPORT_TEXT['notList']);
    }
    if ($entries === []) {
        throw new InvalidArgumentException(CONTENT_TYPES_IMPORT_TEXT['empty']);
    }
    if (count($entries) > CONTENT_TYPES_IMPORT_MAX) {
        throw new InvalidArgumentException(sprintf(CONTENT_TYPES_IMPORT_TEXT['tooMany'], CONTENT_TYPES_IMPORT_MAX));
    }
    $def = content_types_load($type);
    $fields = content_types_schema_columns($def);

    $pdo = db();
    $pdo->beginTransaction();
    try {
        foreach ($entries as $index => $entry) {
            if (!is_array($entry) || ($entry !== [] && array_values($entry) === $entry)) {
                throw new InvalidArgumentException(sprintf(CONTENT_TYPES_IMPORT_TEXT['entry'], $index + 1));
            }
            try {
                content_types_insert($type, content_types_import_values($def, $fields, $entry), true);
            } catch (PluginFieldException $e) {
                $e->entry = $index + 1;
                throw $e;
            }
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }

    return count($entries);
}

/**
 * Werte eines importierten Eintrags: content_types_values, dazu nur erlaubte Ziele (außer action ist ein
 * eigenes Feld des Typs, bei genau einem Ziel erlaubt) und vorhandene Bilder ($fields: content_types_schema_columns).
 * Bilder zählen wie angegeben und bereinigt: Ein Wert, den die Bereinigung leert (data:, ftp: …), wird abgelehnt.
 * Die angegebenen prüft es vor content_types_values: Fehlt ein Upload, gilt diese Meldung, nicht die des Speicherns.
 */
function content_types_import_values(array $def, array $fields, array $entry): array
{
    $ownAction = in_array('action', array_column($fields, 'name'), true);
    if (!$ownAction && array_key_exists('action', $entry) && !content_types_action_allowed($def, $entry['action'])) {
        $message = sprintf(CONTENT_TYPES_IMPORT_TEXT['action'], implode(', ', $def['actions']));
        throw plugin_schema_field_error('action', CONTENT_TYPES_ACTION_FIELDS['action'], $message);
    }
    $requireImages = static function (array $values) use ($fields): void {
        foreach ($fields as $field) {
            foreach (plugin_schema_image_values([$field], $values) as $url) {
                if (trim($url) !== '' && !upload_image_exists(trim($url))) {
                    $message = sprintf(CONTENT_TYPES_IMPORT_TEXT['image'], UPLOADS_URL, LE_SITE_FILES_URL);
                    throw plugin_schema_field_error($field['name'], plugin_schema_field_label($field), $message);
                }
            }
        }
    };
    $requireImages($entry);
    $values = content_types_values($def, $entry, null);
    $requireImages($values);

    return $values;
}

/** Meldung zu einem ungültigen importierten Eintrag: „Zeile 3, Titel: Pflichtfeld ist leer.“ */
function content_types_import_message(PluginFieldException $e): string
{
    return sprintf(CONTENT_TYPES_IMPORT_TEXT['line'], $e->entry, $e->label, $e->reason);
}
