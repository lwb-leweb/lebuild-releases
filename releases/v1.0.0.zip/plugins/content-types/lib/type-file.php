<?php
declare(strict_types=1);

// Content-Typen: die Datei typen.json der Website, die frühere Ablage und die Startpakete (eintraege.json).

// Typen der Website: alle Definitionen in einer Datei, CONTENT_TYPES_FILE (Liste, je Typ ein Objekt mit name). Daneben
// je Typ ein Ordner (unter includes/, von außen nie erreichbar) mit den Vorlagen (lib/render.php) und optional
// eintraege.json: Startpaket wie beim Import, das content_types_seed() einmal in die Datenbank bringt (Typ ohne Einträge)
// und danach löscht. Die Einträge leben nur in der Datenbank.
const CONTENT_TYPES_TEMPLATE_DIR = LE_SITE_ROOT . '/' . LE_SITE_INCLUDES_DIR . '/content-types';
const CONTENT_TYPES_FILE = CONTENT_TYPES_TEMPLATE_DIR . '/typen.json';
const CONTENT_TYPES_SEED_FILE = 'eintraege.json';
// Startpakete, die zuletzt scheiterten (je Zeile ein Typ): Nur Aufrufe mit angemeldeter Editor-Sitzung versuchen sie
// erneut, nie ein Seitenaufruf eines Besuchers (sonst Sperre und Log-Zeile bei jedem Aufruf).
const CONTENT_TYPES_SEED_FAILED_FILE = CACHE_ROOT . '/content-types-seed-failed';
// Frühere Ablage: je Typ private/plugins/content-types/<typ>.json, dazu <typ>/typ.json der Website, die einmal dorthin
// kopiert wurde (übernommene in .website-typen.json). content_types_migrate() fasst sie einmal in CONTENT_TYPES_FILE
// zusammen und löscht sie.
const CONTENT_TYPES_LEGACY_SITE_FILE = 'typ.json';
const CONTENT_TYPES_LEGACY_ADOPTED_FILE = '.website-typen.json';
// Fehler in CONTENT_TYPES_FILE selbst (Hinweis im Backend wie bei ungültigen Typen).
const CONTENT_TYPES_FILE_TEXT = [
    'unreadable' => 'typen.json ist keine Liste von Content-Typen (JSON-Array).',
    'entry' => 'typen.json, Eintrag %d: kein Content-Typ mit gültigem name (Kleinbuchstaben, Ziffern, - und _).',
    'duplicate' => 'typen.json: Den Typ „%s“ gibt es mehrfach.',
    'orphaned' => '„%s“ fehlt in typen.json, seine %d Einträge liegen noch in der Datenbank.',
];

/**
 * Inhalt von CONTENT_TYPES_FILE: ['types' => [Name => Definition, nach Name sortiert], 'problems' => [Text]]
 * (CONTENT_TYPES_FILE_TEXT). Ohne Datei keine Typen. Vorher content_types_prepare(); gelesen wird bei jedem Aufruf,
 * dekodiert nur, wenn sich die Datei geändert hat.
 */
function content_types_file_data(): array
{
    static $cache = [null, null];
    content_types_prepare();
    $json = @file_get_contents(CONTENT_TYPES_FILE);
    if ($json === false) {
        return ['types' => [], 'problems' => []];
    }
    if ($cache[0] === $json) {
        return $cache[1];
    }
    $list = json_decode($json, true);
    $types = [];
    $problems = [];
    if (!is_array($list) || array_values($list) !== $list) {
        $problems[] = CONTENT_TYPES_FILE_TEXT['unreadable'];
        $list = [];
    }
    foreach ($list as $i => $def) {
        $name = is_array($def) ? ($def['name'] ?? null) : null;
        if (!is_string($name) || !content_types_name_valid($name)) {
            $problems[] = sprintf(CONTENT_TYPES_FILE_TEXT['entry'], $i + 1);
        } elseif (isset($types[$name])) {
            $problems[] = sprintf(CONTENT_TYPES_FILE_TEXT['duplicate'], $name);
        } else {
            $types[$name] = $def;
        }
    }
    ksort($types);
    $cache = [$json, ['types' => $types, 'problems' => $problems]];

    return $cache[1];
}

/** Einmal je Request vor dem ersten Lesen der Typen: frühere Ablage zusammenfassen, dann Startpakete einspielen. */
function content_types_prepare(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    // Vor der Arbeit: Import und Prüfung lesen selbst Typen und landen wieder hier.
    $done = true;
    content_types_migrate();
    content_types_seed();
}

/**
 * Fasst die frühere Ablage einmal in CONTENT_TYPES_FILE zusammen, solange es die Datei nicht gibt: Definitionen aus
 * private/plugins/content-types/<typ>.json, dazu <typ>/typ.json der Website, die noch nicht übernommen waren
 * (übernommene ohne Definition unter private/ hatte der Admin gelöscht). Danach sind die alten Dateien weg, ebenso
 * eintraege.json übernommener Typen (deren Einträge sind längst in der Datenbank). Gleiche Dateien ergeben byte-gleich
 * dieselbe typen.json, im Klon wie am Server (deploy führt sie ohne Konflikt zusammen). Unlesbare Definitionen bleiben
 * liegen und fehlen in typen.json (Log). Unter store_lock(), Fehler nur ins Log.
 */
function content_types_migrate(): void
{
    if (is_file(CONTENT_TYPES_FILE)) {
        return;
    }
    $legacyDir = plugin_data_path('content-types');
    $siteFiles = glob(CONTENT_TYPES_TEMPLATE_DIR . '/*/' . CONTENT_TYPES_LEGACY_SITE_FILE) ?: [];
    if ($siteFiles === [] && (glob($legacyDir . '/*.json') ?: []) === []) {
        return;
    }
    $lock = store_lock('content-types-website');
    try {
        if (is_file(CONTENT_TYPES_FILE)) {
            return;
        }
        $adopted = json_decode((string) @file_get_contents($legacyDir . '/' . CONTENT_TYPES_LEGACY_ADOPTED_FILE), true);
        $adopted = is_array($adopted) ? array_values(array_filter($adopted, 'is_string')) : [];
        $sources = [];
        foreach ($siteFiles as $file) {
            $name = basename(dirname($file));
            if (!in_array($name, $adopted, true)) {
                $sources[$name] = $file;
            }
        }
        // Was unter private/ liegt, hat LeBuild bisher genutzt; es gewinnt.
        foreach (glob($legacyDir . '/*.json') ?: [] as $file) {
            $sources[basename($file, '.json')] = $file;
        }
        ksort($sources, SORT_STRING);
        $list = [];
        $done = [];
        foreach ($sources as $name => $file) {
            // Als Objekte dekodiert, damit {} nicht zu [] wird.
            $def = json_decode((string) file_get_contents($file));
            if (!content_types_name_valid((string) $name) || !$def instanceof stdClass || ($def->name ?? null) !== (string) $name) {
                error_log('content-types: ' . le_instance_relative($file) . ' ist kein Content-Typ und bleibt liegen');
                continue;
            }
            $list[] = $def;
            $done[] = $file;
        }
        ensure_dir(CONTENT_TYPES_TEMPLATE_DIR);
        write_file_atomic(CONTENT_TYPES_FILE, json_encode($list, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR) . "\n");
        $remove = [...$done, $legacyDir . '/' . CONTENT_TYPES_LEGACY_ADOPTED_FILE];
        foreach ($siteFiles as $file) {
            $remove[] = $file;
            if (in_array(basename(dirname($file)), $adopted, true)) {
                $remove[] = dirname($file) . '/' . CONTENT_TYPES_SEED_FILE;
            }
        }
        foreach ($remove as $file) {
            if (is_file($file) && !@unlink($file)) {
                error_log('content-types: ' . le_instance_relative($file) . ' lässt sich nicht löschen');
            }
        }
        if (is_dir($legacyDir) && dir_entries($legacyDir) === []) {
            @rmdir($legacyDir);
        }
    } catch (Throwable $e) {
        error_log('content-types: Typen zusammenfassen: ' . $e->getMessage());
    } finally {
        store_unlock($lock);
    }
}

/**
 * Bringt die Startpakete (<typ>/eintraege.json) in die Datenbank, nur bei aktivem Plugin: Hat der Typ noch keine
 * Einträge, kommen sie per content_types_import dazu (ganz oder gar nicht, Bilder müssen existieren); danach ist die
 * Datei weg, auch wenn der Typ schon Einträge hatte. Zwei Durchgänge, weil ein Typ mit optionsFrom die Einträge des
 * anderen braucht. Gescheiterte bleiben liegen und stehen in CONTENT_TYPES_SEED_FAILED_FILE (Log). Ohne Startpakete
 * kostet das nur das Lesen des Ordners. Unter store_lock(), damit gleichzeitige Requests nichts doppelt anlegen.
 */
function content_types_seed(): void
{
    if (content_types_seeds_pending() === [] || !plugin_active('content-types') || !db_available() || db_migration_running()) {
        return;
    }
    // Ohne Anmeldung nie die zuletzt gescheiterten (auch nicht neben einem neuen Startpaket).
    $skip = content_types_seed_retry_allowed() ? [] : content_types_seed_failed();
    if (array_diff(content_types_seeds_pending(), $skip) === []) {
        return;
    }
    // Das Einspielen schreibt Einträge: wie ein schreibender Request die geteilte Sperre halten (ein Umzug wartet).
    if (!db_migration_writer_hold()) {
        return;
    }
    $lock = store_lock('content-types-website');
    try {
        $pending = array_values(array_diff(content_types_seeds_pending(), $skip));
        foreach ([false, true] as $last) {
            $failed = [];
            foreach ($pending as $name) {
                try {
                    content_types_seed_type($name);
                } catch (Throwable $e) {
                    $failed[] = $name;
                    if ($last) {
                        error_log('content-types: Startpaket ' . $name . ': ' . $e->getMessage()
                            . ($e instanceof PluginFieldException ? ' (' . content_types_import_message($e) . ')' : ''));
                    }
                }
            }
            $pending = $failed;
        }
        $stillFailed = array_values(array_unique(array_merge($pending, array_intersect($skip, content_types_seeds_pending()))));
        if ($stillFailed !== []) {
            ensure_dir(dirname(CONTENT_TYPES_SEED_FAILED_FILE));
            write_file_atomic(CONTENT_TYPES_SEED_FAILED_FILE, implode("\n", $stillFailed) . "\n");
        } elseif (is_file(CONTENT_TYPES_SEED_FAILED_FILE)) {
            @unlink(CONTENT_TYPES_SEED_FAILED_FILE);
        }
    } catch (Throwable $e) {
        error_log('content-types: Startpakete: ' . $e->getMessage());
    } finally {
        store_unlock($lock);
    }
}

/** Erneuter Versuch nach einem Fehlschlag: nur mit offener, angemeldeter Editor-Sitzung (nicht der Session der Website). */
function content_types_seed_retry_allowed(): bool
{
    return defined('APP_SESSION_NAME') && session_status() === PHP_SESSION_ACTIVE && session_name() === APP_SESSION_NAME && function_exists('is_logged_in') && is_logged_in();
}

/** Typen der zuletzt gescheiterten Startpakete (CONTENT_TYPES_SEED_FAILED_FILE); ohne Datei keine. */
function content_types_seed_failed(): array
{
    return array_values(array_filter(explode("\n", (string) @file_get_contents(CONTENT_TYPES_SEED_FAILED_FILE))));
}

/** Typen mit Startpaket (<typ>/eintraege.json), sortiert. */
function content_types_seeds_pending(): array
{
    $names = [];
    foreach (dir_entries(CONTENT_TYPES_TEMPLATE_DIR) as $name) {
        if (content_types_name_valid($name) && is_file(CONTENT_TYPES_TEMPLATE_DIR . '/' . $name . '/' . CONTENT_TYPES_SEED_FILE)) {
            $names[] = $name;
        }
    }
    sort($names);

    return $names;
}

/** Spielt das Startpaket eines Typs ein, falls er keine Einträge hat, und löscht es (content_types_seed). */
function content_types_seed_type(string $name): void
{
    $path = CONTENT_TYPES_TEMPLATE_DIR . '/' . $name . '/' . CONTENT_TYPES_SEED_FILE;
    if (content_types_entry_count($name) === 0) {
        content_types_import($name, json_decode((string) file_get_contents($path), true, 512, JSON_THROW_ON_ERROR));
    }
    if (!@unlink($path) && is_file($path)) {
        throw new RuntimeException(CONTENT_TYPES_SEED_FILE . ' lässt sich nicht löschen');
    }
}

/** Namen der Typen in CONTENT_TYPES_FILE, sortiert. */
function content_types_list_names(): array
{
    return array_keys(content_types_file_data()['types']);
}

/** Hinweise auf Typen, die in typen.json fehlen, aber noch Einträge haben (CONTENT_TYPES_FILE_TEXT['orphaned']). */
function content_types_orphaned_problems(): array
{
    if (!db_available() || db_migration_running()) {
        return [];
    }
    $problems = [];
    try {
        $rows = db()->query('SELECT content_type, COUNT(*) AS n FROM content_items GROUP BY content_type ORDER BY content_type')->fetchAll();
    } catch (Throwable $e) {
        return [];
    }
    $names = content_types_list_names();
    foreach ($rows as $row) {
        if (!in_array($row['content_type'], $names, true)) {
            $problems[] = sprintf(CONTENT_TYPES_FILE_TEXT['orphaned'], $row['content_type'], (int) $row['n']);
        }
    }

    return $problems;
}
