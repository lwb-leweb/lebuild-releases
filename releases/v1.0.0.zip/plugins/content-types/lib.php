<?php
declare(strict_types=1);

// Content-Typen: einziger Einstieg, lädt die Teile unter lib/ (beim Laden hängt nur CONTENT_TYPES_FILE an
// CONTENT_TYPES_TEMPLATE_DIR, beide in type-file.php).

require_once __DIR__ . '/lib/types.php';
require_once __DIR__ . '/lib/type-file.php';
require_once __DIR__ . '/lib/fields.php';
require_once __DIR__ . '/lib/entries.php';
require_once __DIR__ . '/lib/list.php';
require_once __DIR__ . '/lib/import.php';
require_once __DIR__ . '/lib/render.php';
require_once __DIR__ . '/lib/template-api.php';
require_once __DIR__ . '/lib/hooks.php';
