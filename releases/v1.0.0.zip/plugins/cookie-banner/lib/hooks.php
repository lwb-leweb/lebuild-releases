<?php
declare(strict_types=1);

// Hook des Cookie-Banners (knowledgebase/hooks.md).

function cookie_banner_filter_site_html(string $html): string
{
    if ($html === '' || stripos($html, '<') === false) {
        return $html;
    }
    $config = cookie_banner_load_config();
    if (empty($config['enabled'])) {
        return $html;
    }
    $html = cookie_banner_rewrite_html($html, $config);
    $html = cookie_banner_inject_banner($html, $config);
    return $html;
}
