<?php
declare(strict_types=1);

// Cookie-Banner: einziger Einstieg, lädt die Teile unter lib/ (Einwilligung, Hook filter_site_html; lib/services.php
// liefert lib/consent.php selbst).

require_once __DIR__ . '/lib/consent.php';
require_once __DIR__ . '/lib/hooks.php';
