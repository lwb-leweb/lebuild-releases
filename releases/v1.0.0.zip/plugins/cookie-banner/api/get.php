<?php
declare(strict_types=1);

require_admin();

$config = cookie_banner_load_config();
$services = [];
foreach (cookie_banner_services() as $key => $svc) {
    $services[] = [
        'key' => $key,
        'category' => (string) ($svc['category'] ?? ''),
        'type' => (string) ($svc['type'] ?? ''),
        'hosts' => is_array($svc['hosts'] ?? null) ? array_values($svc['hosts']) : [],
    ];
}

json_response([
    'ok' => true,
    'config' => $config,
    'services' => $services,
]);
