# Cookie-Banner Plugin

DSGVO/TTDSG-konformer Cookie-Banner. Blockt die Dienste aus der Registry (YouTube, Vimeo, Google Maps, Google Analytics/Tag Manager, Meta-Pixel, Hotjar) so lange, bis der Besucher zustimmt. Erkannt werden `<iframe>`, `<script src>` und Inline-Scripts, deren Code einen Host eines Script-Dienstes nennt (die Standard-Snippets von Meta-Pixel, Hotjar und GTM); das passiert automatisch beim Page-Render. Andere Tracker muss der Entwickler selbst markieren (siehe "Eigene Scripts/Iframes mit Consent koppeln").

## Aktivierung

1. Im Admin auf "Erweiterungen" -> "Cookie-Banner" -> aktivieren.
2. Sidebar-Eintrag "Cookie-Banner" erscheint -- dort Texte, Kategorien und Datenschutz-URL pflegen.
3. Beim Speichern wird `website/private/plugins/cookie-banner/config.json` angelegt.
4. Der Banner erscheint automatisch auf allen Site-Seiten (`/public/site/*`), nicht im Admin.

Keine Datenbanktabelle. Keine Migrationen.

## Was es kann

- Server-seitiges HTML-Rewriting: `<iframe>` und `<script src="...">` von bekannten Diensten werden vor der Auslieferung geblockt, ebenso Inline-Scripts, die einen Host eines Script-Dienstes (GA4/GTM, Meta-Pixel, Hotjar) enthalten.
- Banner als Slide-in unten -- nicht-blockierend, keine "Cookie-Wall".
- Drei gleich prominente Buttons: Ablehnen | Einstellungen | Alle akzeptieren.
- Kategorie-Auswahl mit Deny-by-Default (alle ausser `necessary` standardmaessig aus).
- Granularer "Inhalt laden"-Button am einzelnen Embed-Platzhalter, ohne globalen Consent zu aendern.
- Consent als `localStorage`-Eintrag `cc_consent`, kein Cookie, kein Server-Log.
- Version-Counter: bei Aenderung an Texten/Kategorien manuell hochzaehlen -> alle Besucher muessen erneut zustimmen.
- `cc:consent`-Event fuer andere Plugins (z.B. Tracking-Plugin), wird bei Page-Load und nach Auswahl gefeuert.

## Im Admin verwenden

**Banner-Texte aendern:** Sidebar -> "Cookie-Banner" -> Felder ausfuellen -> "Speichern".

**Datenschutz-URL:** Pfad zur Datenschutzerklaerung (z.B. `/datenschutz` oder `/public/site/impressum.php`), alternativ eine `http(s)://`-Adresse. Andere Schemata (z.B. `javascript:`) weist das Speichern mit 400 ab; ein solcher Wert aus einer alten Konfig wird nicht ausgegeben.

**Feste Kategorien:** `necessary`, `statistics` und `marketing` lassen sich nicht entfernen und ihre ID nicht aendern, nur der Anzeigename. Die erkannten Dienste haengen an diesen IDs. "erforderlich" ist bei `statistics` und `marketing` abwaehlbar (einwilligungspflichtig), bei `necessary` immer an. Fehlen sie in einer gespeicherten Konfig, ergaenzt der Server sie mit Standardnamen, beim Speichern wie beim Laden.

**Neue Kategorie anlegen:** "Kategorie hinzufuegen" -> ID (kebab-case), Label, optional "erforderlich" -> speichern. Tipp: Beim Hinzufuegen oder Aendern von Kategorien zusaetzlich "Version hochzaehlen" anhaken, damit Bestandsbesucher erneut zustimmen.

**Consent neu erzwingen:** Checkbox "Beim Speichern Version hochzaehlen" anhaken -> bei der naechsten Anzeige sehen alle Besucher den Banner erneut.

**Service-Registry:** Read-only. Liste der erkannten Drittanbieter (Plugin-gepflegt). Erweiterungen kommen ueber Plugin-Updates.

## API-Endpoints

Alle Endpoints unter `/plugins/cookie-banner/api/`. Auth: nur Admins (Rolle `admin`), Editoren bekommen 403. Schreib-Endpoints zusaetzlich mit CSRF-Token.

| Endpoint | Methode | Auth | Parameter | Response |
|---|---|---|---|---|
| `get.php` | GET | Admin | -- | `{ok, config, services[]}` |
| `save.php` | POST | Admin + CSRF | JSON `{config, bumpVersion?}` | `{ok, config}` |

**Beispiel -- Konfig speichern und Version hochzaehlen:**

```bash
curl -X POST https://example.com/plugins/cookie-banner/api/save.php \
  -H "Content-Type: application/json" \
  -H "X-CSRF-Token: <token>" \
  -b "session=..." \
  -d '{"config":{"texts":{"intro":"..."}},"bumpVersion":true}'
```

`config` darf ein Teil sein: Was fehlt, bleibt wie gespeichert (`texts` und `placeholder` je Schlüssel), `categories` ersetzt die Liste als Ganzes.

## Shortcodes

### `settings-link` -- Widerruf-/Wieder-Oeffnen-Link

```html
<div data-plugin="cookie-banner" data-view="settings-link" data-label="Cookie-Einstellungen"></div>
```

| Attribut | Type | Default | Beschreibung |
|---|---|---|---|
| `data-label` | string | `Cookie-Einstellungen` | Link-Text |

Output: `<a href="#cookie-settings" class="cc-settings-link" data-cc-settings-link>Cookie-Einstellungen</a>`. Klick oeffnet das Banner mit Kategorie-Auswahl.

## Frontend einbinden

Der Banner selbst muss **nicht** eingebunden werden. Er wird automatisch via `filter_site_html`-Hook vor das letzte `</body>` jeder Site-Seite injiziert (eins in einem `<script>` zaehlt nicht; ohne `</body>` ans Ende des Dokuments, JSON und Teilstuecke ohne `<html>`/`<body>` bleiben ohne Banner), solange das Plugin aktiv und in der Konfig `enabled: true` ist.

Im Footer empfiehlt sich der Settings-Link, damit Besucher ihre Auswahl spaeter widerrufen koennen:

```html
<footer>
  ...
  <div data-plugin="cookie-banner" data-view="settings-link"></div>
</footer>
```

### Eigene Scripts/Iframes mit Consent koppeln

**Automatisch erkannt** werden alle `<iframe>` und `<script src="...">` zu Hosts aus der Registry (YouTube, GA, Maps etc.) und Inline-Scripts (ohne `type` oder mit JavaScript-`type`), deren Code einen Host eines Dienstes vom Typ `script` nennt (z.B. `connect.facebook.net` im Meta-Pixel-Snippet). **`<noscript>`:** `<img>` und `<iframe>` darin, deren `src` einen Host der Registry nennt (Meta-Pixel `https://www.facebook.com/tr?…`, GTM-`ns.html`), werden ganz entfernt: Ohne JavaScript erscheint kein Banner, eine Einwilligung ist also nie möglich. Der übrige Inhalt des `<noscript>` bleibt. Das Inline-Config-Snippet von gtag (`window.dataLayer = ...; gtag('config', ...)`) nennt keinen Host und laeuft sofort, sendet aber nichts, solange `gtag/js` blockiert ist.

**Andere Inline-Scripts** (kein `src`, kein Registry-Host) muessen manuell markiert werden:

```html
<script type="text/plain" data-cc="statistics">
  // dieser Code laeuft erst nach Consent fuer "statistics"
  console.log('Tracking aktiv');
</script>
```

**Eigene Plugins**, die Drittanbieter laden, hoeren auf das Consent-Event:

```js
window.addEventListener('cc:consent', function (event) {
  var cats = event.detail.categories;
  if (cats.statistics) {
    // erst jetzt initialisieren
  }
});
```

Das Event feuert beim Page-Load (wenn gueltiger Consent existiert) und nach jeder Auswahl.

## Konfig-Datei

Liegt unter `website/private/plugins/cookie-banner/config.json`. Struktur:

```json
{
  "enabled": true,
  "version": 1,
  "categories": [
    { "id": "necessary",  "label": "Notwendig",  "required": true },
    { "id": "statistics", "label": "Statistik",  "required": false },
    { "id": "marketing",  "label": "Marketing",  "required": false }
  ],
  "texts": { "title": "...", "intro": "...", "accept": "...", "reject": "...", "settings": "...", "save": "...", "policyLink": "Datenschutzerklaerung" },
  "policyUrl": "/datenschutz",
  "placeholder": {
    "default": "Externer Inhalt blockiert. Klicken, um zu laden.",
    "youtube": "Video laden? Es werden Daten an YouTube uebertragen.",
    "maps": "Karte laden? Es werden Daten an Google uebertragen."
  }
}
```

`version` zaehlt nur `bumpVersion` hoch (Checkbox beim Speichern), damit gespeicherter Consent ungueltig wird. Ein `version` in `config` ignoriert `save.php`, ein alter Tab setzt sie also nicht zurueck.

## Erkannte Drittanbieter

| Service | Kategorie | Typ | Hosts |
|---|---|---|---|
| youtube | marketing | iframe | youtube.com, youtu.be, youtube-nocookie.com |
| vimeo | marketing | iframe | player.vimeo.com, vimeo.com |
| gmaps | marketing | iframe | google.com/maps, maps.google.com |
| ga4 | statistics | script | googletagmanager.com, google-analytics.com |
| meta-pixel | marketing | script | connect.facebook.net, facebook.com/tr |
| hotjar | statistics | script | static.hotjar.com, script.hotjar.com |

Google Fonts ist bewusst **nicht** enthalten -- Fonts werden beim Import lokalisiert.

## Bekannte Einschraenkungen

- Google Tag Manager zaehlt als Statistik: `googletagmanager.com` gehoert zum Dienst `ga4` (Kategorie `statistics`). Ein GTM-Container mit Marketing-Tags (Meta, Google Ads …) feuert damit schon mit der Statistik-Einwilligung, ohne Marketing-Einwilligung; Consent Mode wird nicht gesetzt. Solche Container selbst mit `type="text/plain" data-cc="marketing"` markieren (siehe "Eigene Scripts/Iframes mit Consent koppeln").
- Inline-Scripts ohne Registry-Host im Code (eigene Tracker, Loader mit zusammengesetzter URL, `type="module"`) werden nicht automatisch erkannt -- Entwickler muss `type="text/plain" data-cc="..."` setzen.
- Widerruf entlaedt bereits geladene Scripts nicht; sie laufen bis zum naechsten Seitenaufruf weiter.
- Kein MutationObserver-Fallback fuer Embeds, die per JS nachtraeglich ins DOM kommen.
- Kein Geo-Targeting (Banner zeigt weltweit; das ist rechtlich okay).
- Single-Language: Texte sind ein Set, kein Multi-Lang.
- Kein Server-seitiges Consent-Logging (bewusste Designentscheidung -- weniger Aufwand, datenschutzfreundlicher).

## Für Agenten

### Was das Plugin tut

DSGVO/TTDSG-konformer Cookie-Banner. Blockt Drittanbieter-Inhalte (YouTube, GA, Maps, Pixel...) per Server-seitigem HTML-Rewriting, bis der Besucher zustimmt. Banner laeuft nur im Site-Output, nicht im Admin. Consent liegt ausschliesslich im `localStorage` des Besuchers, kein Server-Logging.

### Was du als KI tun darfst

- Service-Registry in `lib/services.php` erweitern (neue Drittanbieter mit `category`, `hosts`, `type`, `placeholder`).
- Default-Texte und Default-Kategorien in `cookie_banner_default_config()` anpassen.
- Banner-Styles in `templates/banner.php` (inline `<style>`) feintunen.
- Granular-Loading-Logik im Banner-JS verbessern.
- Admin-UI-Felder erweitern, wenn neue Konfig-Werte dazukommen.
- README.md + Changelog bei jeder funktionalen Aenderung pflegen.

### Was du NICHT anfassen darfst

- **Kein Server-Logging des Consents.** Weder DB noch Logfiles fuer Consent-Entscheidungen.
- **Kein Cookie fuer den Consent.** Nur `localStorage`. Cookies waeren wieder zustimmungspflichtig.
- **Service-Registry kein Admin-UI.** Erweiterung ausschliesslich im Plugin-Code.
- **"Akzeptieren" nicht prominenter als "Ablehnen".** Drei gleich grosse Buttons, gleiche Hierarchie.
- **Kein blockierender Modal-Overlay ("Cookie-Wall").** Banner ist Slide-in unten, Seite bleibt nutzbar.
- **Default-Checkboxen nicht-notwendiger Kategorien nicht auf `checked`.** Deny-by-Default.
- **Google Fonts nicht in `necessary` einsortieren**, um Banner zu umgehen -- stattdessen beim Import lokalisieren.
- **Feste Kategorien (`COOKIE_BANNER_FIXED_CATEGORIES`: `necessary`, `statistics`, `marketing`) nicht entfernbar oder umbenennbar machen.** `lib/services.php` ordnet die Dienste diesen IDs zu; `cookie_banner_merge_config()` ergaenzt fehlende, die Admin-UI sperrt ID und "Entfernen" (Liste dort gleich halten).
- **`filter_site_html` nicht fuer Side-Effects** (DB-Writes, Mails) nutzen -- nur Transformation.

### Dateistruktur

- `plugin.json` -- Manifest, Shortcode-Definition fuer `settings-link`, Admin-Sidebar.
- `lib.php` -- Einstieg, laedt `lib/consent.php` und `lib/hooks.php`.
- `lib/consent.php` -- Konfig-Loader, Service-Matching, HTML-Rewriting fuer Iframes, Scripts mit `src` und Inline-Loader, Banner-Injection vor das letzte `</body>` ausserhalb von Skripten und Kommentaren (ohne eins ans Ende des Dokuments; Kernhelfer `le_plugin_insert_html`).
- `lib/hooks.php` -- Hook `filter_site_html`.
- `lib/services.php` -- Service-Registry (Plugin-gepflegt, kein UI), liefert `cookie_banner_services()` per `require`.
- `templates/banner.php` -- Banner-HTML inkl. Inline-CSS und Inline-JS.
- `render/settings-link.php` -- Shortcode-Renderer fuer Widerruf-Link.
- `admin/module.js` -- Admin-UI: Texte, Kategorien, Version-Bump, Service-Liste.
- `api/get.php` / `api/save.php` -- Admin-API fuer Konfig.
- `README.md` -- diese Doku (Nutzer und Agenten).

Konfig-Storage: `website/private/plugins/cookie-banner/config.json` (über `plugin_data_path('cookie-banner')`). Wird beim Speichern automatisch angelegt.

### Datenbank

Keine. Bewusste Entscheidung -- Consent ist Client-Zustand, alles andere ist JSON.

### Haeufige Anpassungen -- wie geht das?

**Neuen Drittanbieter hinzufuegen:**
1. Eintrag in `lib/services.php` ergaenzen mit `category`, `hosts` (Array), `type` (`iframe` oder `script`), optional `placeholder`-Key.
2. Pruefen, dass die Kategorie in `cookie_banner_default_config()` existiert und fest ist (`COOKIE_BANNER_FIXED_CATEGORIES`), sonst kann der Admin sie entfernen und der Dienst laedt nie.
3. README.md unter "Erkannte Drittanbieter" aktualisieren.
4. Plugin-Version in `plugin.json` patchen (Minor bei neuem Service).

**Neue Kategorie hinzufuegen:**
1. Default in `cookie_banner_default_config()` ergaenzen.
2. Hinweis im Admin: Version muss vom Admin manuell hochgezaehlt werden, damit Bestandsbesucher neu zustimmen.

**Banner-Styles aendern:**
1. Inline-`<style>` in `templates/banner.php` anpassen.
2. Klassen-Praefix `cc-` einhalten, damit kein Konflikt mit Site-Styles entsteht.

**Settings-Link irgendwo einbinden:**
- `<div data-plugin="cookie-banner" data-view="settings-link" data-label="Cookie-Einstellungen"></div>` -- rendert einen Link, der `window.cookieBanner.open()` triggert.

### Fehlervermeidung

- `filter_site_html` wird **fuer jede Site-Seite** aufgerufen. Frueh-Exit bei `enabled: false` in der Konfig ist Pflicht.
- HTML-Rewriting ist regex-basiert -- bewusst defensiv (skipt Tags mit bereits gesetzten `data-cc`-Attributen, prueft `about:blank`/`data:`/`javascript:`). `src` und `type` mit und ohne Anfuehrungszeichen (`COOKIE_BANNER_ATTR_VALUE`), sonst rutscht minifiziertes HTML (`<iframe src=https://…>`) durch. Bei iframes zaehlen `src`, `data-src` und `data-lazy-src` (Lazyload), nie `data-src` als `src`; passt eines davon, fallen alle weg und `src` wird `about:blank`. Bei `<script>` genauso (LiteSpeed: `type="litespeed/javascript" data-src=…` ohne `src`): passt eines, wird das Script `text/plain` mit `data-cc-src` und alle drei Attribute fallen weg; ohne Treffer bleibt es byte-gleich.
- Banner-JS muss idempotent gegen mehrfaches Init sein. `applyConsent()` laeuft bei jedem Speichern erneut und ueberspringt Scripts mit `data-cc-loaded`, sonst laden sie doppelt.
- Inline-Scripts (`<script>...</script>` ohne `src`) werden nur erkannt, wenn ihr Code einen Host eines Dienstes vom Typ `script` nennt (`cookie_banner_match_inline_service()`); nur ohne `type` oder mit JavaScript-`type`, nie JSON-Bloecke oder Module. Hosts von `iframe`-Diensten zaehlen dort bewusst nicht (ein Link auf YouTube im Code ist kein Tracker). Alles andere muss der Entwickler manuell mit `<script type="text/plain" data-cc="statistics">...</script>` markieren.
- `iframe`/`script` ohne erkanntes Service-Host werden unveraendert durchgereicht -- nicht versehentlich alles blockieren.
- `policyUrl` landet im `href` des Banners: nur ueber `cookie_banner_policy_url_valid()` (Pfad oder http(s)), beim Speichern abweisen, beim Laden verwerfen.
- Admin-API: `require_admin()` (Editoren 403), `require_csrf()` nur in `save.php`; ob das Plugin aktiv ist, prüft der Router (`require_plugin_active()`).
- Consent-Storage hat `v` (Version) -- wenn der Admin die Version hochzaehlt, wird der gespeicherte Consent ungueltig und das Banner erscheint erneut.

## Changelog

- **2026-11-15** -- Tracker-Pixel und -iframes in `<noscript>` (Meta-Pixel, GTM, Analytics) werden entfernt, bisher luden sie ohne JavaScript ohne Einwilligung. `facebook.com/tr` gehört zu `meta-pixel`.
- **2026-11-14** -- Banner kommt vor das letzte `</body>` ausserhalb von `<script>`; ohne `</body>` ans Ende des Dokuments. Bisher landete er in einem JS-String mit `</body>` oder fehlte ganz, blockierte Einbettungen waren dann nie ladbar.
- **2026-11-14** -- `save.php` uebernimmt `version` nie vom Client, nur `bumpVersion` zaehlt hoch. Bisher setzte ein alter Admin-Tab beim Speichern die Version zurueck, alte Einwilligungen galten wieder.
- **2026-10-28** -- Admin: "Entfernen" behaelt ungespeicherte Aenderungen der anderen Kategorien. Auf dem Handy brechen die Kategorie-Zeilen um, die Dienste-Tabelle scrollt in ihrem Rahmen, nichts laeuft mehr ueber den Rand.
- **2026-10-28** -- `statistics` und `marketing` sind wie `necessary` fest: "Entfernen" gesperrt, ID nicht aenderbar, nur der Name. Fehlen sie in der Konfig, ergaenzt der Server sie mit Standardnamen; bisher luden YouTube, Maps, Pixel usw. ohne sie nie.
- **2026-10-28** -- `src` ohne Anführungszeichen (minifiziert, `<iframe src=https://…>`, `<script async src=https://…>`) wird genauso blockiert. Ungenutztes `serviceCategory` im Banner-JSON entfernt.
- **2026-10-28** -- Scheitert das Speichern der Konfig, kommt eine feste Meldung aus `COOKIE_BANNER_TEXT` (500), der Fehlertext geht ins Log.
- **2026-10-28** -- Inline-Scripts, deren Code einen Host eines Script-Dienstes nennt (Standard-Snippets von Meta-Pixel, Hotjar, GTM), werden wie `<script src>` auf `type="text/plain" data-cc` umgeschrieben und laufen erst nach der Einwilligung. README sagt jetzt genau, was erkannt wird.
- **2026-10-28** -- Erneutes Speichern der Einwilligung laedt bereits freigegebene Scripts nicht noch einmal (`:not([data-cc-loaded])`).
- **2026-10-28** -- Datenschutz-URL nur noch als Pfad oder `http(s)`-Adresse; sonst 400 mit Meldung aus `COOKIE_BANNER_TEXT`.
- **2026-10-28** -- `get.php` und `save.php` nur noch fuer Admins (`require_admin()`), Editoren bekommen 403.
- **2026-10-15** -- Admin-Ansicht nutzt die Token des Design Systems (`var(--le-…)`, keine eigenen Farb- und Maßwerte); Fehlermeldung bei falscher Methode kommt aus `API_TEXT`. Banner auf der Website unverändert.
- **2026-05-22 -- v0.1.0** -- Erstes Release: `filter_site_html`-Hook, Iframe-/Script-Rewriting, Banner mit Inline-CSS+JS, `localStorage`-Consent, Admin-UI fuer Texte/Kategorien/Version, `settings-link`-Shortcode, Service-Registry mit YouTube/Vimeo/Maps/GA4/Meta-Pixel/Hotjar.
