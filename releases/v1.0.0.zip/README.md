# LeBuild

Kleines PHP/Vanilla-JS-Tool, um statische HTML-Seiten nach einem Import ohne Datenbank über JSON zu bearbeiten.

## Start

Mit einem lokalen PHP-Server; jede Anfrage geht an `webroot/index.php` (gleicher Code für Dev und Produktion):

```bash
php -S 127.0.0.1:8000 -t webroot webroot/index.php
```

Dann im Browser öffnen:

- Login: `http://127.0.0.1:8000/login`
- Website (angemeldet mit Editor-Leiste): `http://127.0.0.1:8000/`
- Verwaltung (nur Admins): `http://127.0.0.1:8000/admin`

## Login & Benutzer

Angemeldet wird unter `/login`. Danach zeigt jede Seite der Website unten die Editor-Leiste (Name, Verwaltung für Admins, Abmelden); Texte, Bilder und Links werden direkt auf der Seite angeklickt und bearbeitet. Besucher sehen nichts davon und bekommen kein Cookie. Der Editor nutzt das Session-Cookie `le_session` und lässt eine PHP-Session der Website (Formulare, Mitgliederbereich) unberührt. Die Anmeldung hält 8 Stunden ohne Anfrage an den Server; ihre Dateien liegen in `website/private/cache/sessions/`, damit kein Aufräumen des Servers sie früher löscht.

### Erstinstallation

Einen Standardzugang gibt es nicht. Vor dem Hochladen `website/setup.sample.php` nach `website/setup.php` kopieren und Benutzername und Passwort (8 bis 72 Byte) des ersten Admins eintragen.

- Der erste Login mit diesem Zugang legt den Admin in `website/private/users.json` an (nur als bcrypt-Hash) und leert das Passwort in `setup.php`.
- Lässt sich `setup.php` nicht umschreiben, steht das im PHP-Fehlerprotokoll, und Einstellungen → System sowie das Dashboard erinnern daran, das Passwort per FTP zu leeren.
- Ohne Benutzer und ohne gültige `setup.php` kommt niemand hinein; `/login` zeigt dann statt des Formulars einen Hinweis.
- `setup.php` ist gitignored, nie im Release und nie per HTTP erreichbar; Updates fassen sie nicht an.

Nach 10 Fehlversuchen sperrt der Login eine IP (bei IPv6 das /64-Netz) für 15 Minuten. Nach 10 Fehlversuchen für denselben Benutzer, egal von wo, geht für ihn nur noch ein Versuch alle 10 Sekunden; das gilt nicht in Browsern, in denen er sich schon angemeldet hat (Cookie `le_device_…`, 180 Tage), damit ein Angriff ihn nicht aussperrt. Falsche aktuelle Passwörter beim Passwortwechsel zählen für die IP genauso, dazu je Session, aber nicht für den Benutzer (ein Angriff auf seinen Namen sperrt ihn so nicht aus). Passwörter haben 8 bis 72 Byte (bcrypt nutzt nicht mehr).

Sobald `website/private/users.json` existiert, wird `setup.php` ignoriert — alle weiteren Benutzer werden über das Admin-UI verwaltet (**Benutzer**-Eintrag in der Sidebar). Ist die Datei beschädigt (unlesbar, kein gültiges JSON), meldet sich niemand an, der Fehler steht im PHP-Fehlerprotokoll und die Datei wird nie überschrieben: aus einer Sicherung zurückspielen oder reparieren. Einträge mit unbekannter Rolle können sich nicht anmelden, bleiben aber erhalten.

### Rollen

- **admin** — kann alles: Inhalte bearbeiten, Einstellungen, SMTP, Updates, Plugins, Benutzer anlegen / Rollen ändern / löschen, Aktivitäts-Log (wer hat wann was getan, ohne IP, 90 Tage), Verwaltung unter `/admin`.
- **editor** — sieht nur die Website mit Leiste (`/admin` führt zurück auf die Website): bearbeitet Seiten und Plugin-Listen, nutzt Upload, sieht den Verlauf einer Seite und stellt frühere Stände wieder her. Settings, Plugin-Verwaltung, „Markierungen aktualisieren“, Benutzer und Update-Install sind über die API nicht erreichbar (403). Wurde eine Seitendatei direkt geändert (FTP, Deploy), aktualisiert das Öffnen oder Speichern der Seite ihre Markierungen trotzdem von selbst, auch für Editoren (im Verlauf als „Direkte Änderung“).

Passwörter werden als bcrypt-Hashes in `website/private/users.json` gespeichert. Die Datei ist `.gitignore`d; der Router liefert aus `website/` nur `public/` aus.

## Voraussetzungen

PHP 8.2 oder neuer mit `pdo_sqlite`, `openssl`, `zip`, `curl`, `mbstring`, `dom` und `tokenizer` (fast immer eingebaut), empfohlen `gd` mit WebP (hochgeladene JPG und PNG werden auf 1920 px Breite verkleinert und als WebP gespeichert; ohne werden Fotos (JPG) abgelehnt, weil das Original GPS-Position und Gerät verriete, PNG bleiben unverändert) und `exif` (dreht Handyfotos richtig); Schreibrechte auf `website/private/` und `website/public/` (darin `uploads/` für hochgeladene Bilder). Einstellungen → System und das Dashboard zeigen, was fehlt, und melden auch eine PHP-Version ohne Sicherheitsupdates. Ein Update, das ein neueres PHP braucht, spielt der Editor nicht ein und nennt den Grund.

Webserver: Die Domain zeigt auf `webroot/`, jede Anfrage geht an `webroot/index.php`; was erreichbar ist, entscheidet nur der Router.

- Apache: `webroot/.htaccess` (mod_rewrite). Ohne einstellbaren Webroot leitet die `.htaccess` im Hauptordner alles dorthin (Apache ≥ 2.4.8).
- Nginx: `root` auf `webroot/`, jede Anfrage an `/index.php`, PHP-FPM nur für diese Datei.
- Caddy (mehrere Websites auf einem Server): `ops/deploy/Caddyfile`, siehe [unten](#mehrere-websites-auf-einem-server).

## Env-Variablen

Alle optional, gelesen per `getenv()`:

| Variable | Wirkung |
|---|---|
| `LEBUILD_UPDATES` | `off` (oder `0`, `false`, `no`) schaltet das Auto-Update ab; mit eigenem Kundenordner (`LEBUILD_SITE(S)`) ist es immer aus |
| `LEBUILD_UPDATE_FEED` | andere URL zu `latest.json` (zum Testen), die Signaturprüfung bleibt |
| `LEBUILD_IMAGES_FROM` | nur für eine lokale Kopie: Adresse der echten Website (z. B. `https://kunde.at`); fehlende Bilder der Website (Fotos und Uploads sind nie im Git) leitet LeBuild dorthin um, so sind sie lokal zu sehen |
| `LEBUILD_INDEXNOW` | `off` schaltet die Meldung geänderter Seiten an IndexNow (Bing u. a.) ab; eine http(s)-Adresse ersetzt `api.indexnow.org` (zum Testen) |
| `LEBUILD_HEALTH_TOKEN` | Token für die Einzelprüfungen des [Health-Checks](#health-check) |
| `LEBUILD_SITES` | mehrere Websites auf einem Server: Ordner mit je einem Kundenordner (`setup.php`, `private/`, `public/`) und `domains.json` (`{"kunde.at": "kunde"}`); der Host der Anfrage wählt den Ordner, Unbekanntes bekommt 404 |
| `LEBUILD_PREVIEW_DOMAIN` | dazu die Domain der Vorschau-Adressen `<kurzname>.<domain>` (Antworten mit `X-Robots-Tag: noindex, nofollow`) |
| `LEBUILD_SITE` | genau ein Kundenordner, ohne Blick auf den Host (Kommandozeile, Tests, Dev-Server); hat Vorrang vor `LEBUILD_SITES`, das auf der Kommandozeile ohne `LEBUILD_SITE` abbricht |
| `LEBUILD_REPOS` | Ordner, in dem `ops/tools/sites.php` die Git-Verzeichnisse der Kunden anlegt (`<kurzname>.git`, Arbeitsordner per `core.worktree`); gehört nur dem Benutzer von `sites.php`, nie unter `LEBUILD_SITES` ([Mehrere Websites](#mehrere-websites-auf-einem-server)) |
| `LEBUILD_PHP_USER` | Benutzer, als der `ops/tools/sites.php` die PHP-Prozesse je Kunde startet (`sudo -u`); Pflicht, nie der Benutzer von `sites.php` selbst, sonst bricht es ab ([Mehrere Websites](#mehrere-websites-auf-einem-server)) |

Apache (mod_env) in der vHost-Konfiguration oder dort, wo der Hoster Env-Variablen anbietet; nicht in der `.htaccess` des Projekts, die jedes Update ersetzt:

```
SetEnv LEBUILD_UPDATES off
```

Nginx mit PHP-FPM: `fastcgi_param LEBUILD_UPDATES off;` im PHP-`location`.

## Health-Check

`GET /api/health.php` für Uptime-Monitore, ohne Anmeldung. Er prüft, ob `website/private/` lesbar und beschreibbar ist (samt `users.json`) und `website/public/` beschreibbar, rendert die Startseite wie für Besucher und fragt die Plugin-Datenbank ab (nur, wenn ein aktives Plugin Tabellen hat). Das Ergebnis gilt 10 Sekunden. MySQL hat während der Prüfungen 5 Sekunden je Antwort; eine gleichzeitige Abfrage wartet höchstens 25 Sekunden auf den laufenden Lauf, sonst 503 (`lock`).

- Alles in Ordnung: `200 {"status":"ok","checkedAt":"…"}`; ein Fehler: `503` mit `"status":"error"`, für jeden Aufrufer gleich.
- Die Einzelprüfungen (`checks` mit `name`, `ok`, `error`, `durationMs`, dazu `ageMs`) gibt es nur mit `Authorization: Bearer <Token>`. Ein falsches Token bekommt die öffentliche Antwort.
- Token (z. B. `openssl rand -hex 32`) per `LEBUILD_HEALTH_TOKEN` oder, wo sich keine Env-Variable setzen lässt, in `website/private/config/health.config.php`: `<?php return ['token' => '…'];`
- Monitor: auf `"status":"ok"` prüfen und erst nach zwei, drei Fehlschlägen in Folge alarmieren.

## Ablauf

1. Die Testseite in `website/public/` ganz löschen und die statischen HTML-Dateien des Kunden dorthin legen
2. Unter `/login` anmelden, im Admin (`/admin`) den Import starten
3. Inhalte direkt auf der Website ändern, „Speichern“ übernimmt alle Änderungen auf einmal
4. Änderungen landen in der Seitendatei und in `website/private/cache/pages/*.json`; „Verlauf“ in der Leiste zeigt frühere Stände und stellt sie wieder her

## Speicherorte

Alle Daten liegen unter `website/` (Code nie):

- Seiteninhalt (JSON-Spiegel): `website/private/cache/pages/`
- Backups samt Kurzinfo für den Verlauf: `website/private/cache/backups/`
- Originale: `website/private/cache/originals/`
- Benutzer (bcrypt-Hashes, nicht im Git): `website/private/users.json`
- Zugang des ersten Admins (nicht im Git, Vorlage `website/setup.sample.php`): `website/setup.php`
- Uploads: `website/public/uploads/` (Adresse `/public/site/uploads/…`), bei den übrigen Bildern der Website, aber nie im Git (sie stecken in der Sicherung)
- Aktivitäts-Log (nicht in der Sicherung): `website/private/activity.jsonl`
- Zugangsdaten (0600): `website/private/config/db.config.php`, `website/private/config/mail.config.php`
- Plugin-Daten (SQLite): `website/private/data/site.sqlite`

## Datenbank

Plugin-Daten liegen standardmäßig in SQLite. Admin → Einstellungen → Datenbank richtet MySQL/MariaDB ein und zieht die Daten in beide Richtungen um; Altdaten bleiben im Archiv, nach 30 Tagen erinnert das Dashboard ans Löschen.

## Hinweise

- Keine Datenbank für den Editor selbst; Plugins mit Daten nutzen SQLite (`website/private/data/site.sqlite`), MySQL nur auf Wunsch
- Kein Node.js
- Der Import schreibt `data-edit-id`-Marker byte-genau in die Seitendateien; Speichern ersetzt nur das bearbeitete Feld
- Bestehende Seiten stellt der Admin-Button „Markierungen aktualisieren“ auf neue Markierungen um (IDs und Inhalte bleiben); dabei werden auch Seitentitel und Meta-Beschreibung bearbeitbar
- Speichert jemand anderes dasselbe Feld, bleibt dessen Stand erhalten: Der Editor meldet das Feld, speichert den Rest und behält die eigene Änderung in der Liste
- Eine schreibgeschützte Seitendatei wird nicht ersetzt; Speichern meldet das, statt etwas halb zu schreiben
- Aufbau des Seiten-Editors, Design System und Bausteine: [knowledgebase/seiten-editor.md](knowledgebase/seiten-editor.md)

## Tests

```bash
php tests/run.php                  # alle Dateien tests/**/*.test.php, parallel
php tests/run.php pages ops/sites  # nur Dateien, deren Pfad das enthält
php tests/pages/save.test.php      # eine Datei allein
```

Braucht PHP mit `curl`, `openssl`, `pdo_sqlite`, `zip` und `gd`. Die Tests arbeiten in einer Wegwerf-Kopie unter dem Temp-Verzeichnis. MySQL-Tests laufen nur mit `TEST_MYSQL_DSN` (DSN einer leeren Wegwerf-Datenbank), `TEST_MYSQL_USER`, `TEST_MYSQL_PASS`, sonst werden sie übersprungen; mit Test-Datenbank laufen die Dateien nacheinander.

## Suchmaschinen

LeBuild erzeugt `/robots.txt`, `/sitemap.xml` (braucht die Website-URL unter Einstellungen), eine 404-Seite im Design der Startseite, ein Vorschaubild für Google und Social Media (Einstellung „Vorschaubild“) und strukturierte Daten der Startseite. Alte Adressen leitet `website/private/redirects.json` per 301 weiter (`{"/about": "/ueber-mich", "/faq/*": "/fragen"}`). CSS und JS gehen verkleinert und mit Browser-Cache raus, ohne Build-Step. Eigene Dateien und Tags der Website gehen vor; Details in `knowledgebase/architecture.md`, „Suchmaschinen“.

## Mail / SMTP

Der Core kann E-Mails zentral versenden:

- SMTP-Konfiguration: Admin → Einstellungen → E-Mail / SMTP
- Geschützte Runtime-Datei: `website/private/config/mail.config.php`
- Fallback ohne SMTP: PHP `mail()`, sofern auf dem Hosting verfügbar
- Mails gehen als reiner Text (UTF-8, quoted-printable)

Mail-Plugins wie `contact-form` rufen nur den Core-Mailer auf und kennen keine SMTP-Zugangsdaten.

## Auto-Update

Kunden-Installationen aktualisieren sich automatisch über signierte Releases im öffentlichen Repo `lwb-leweb/lebuild-releases`. Release-Workflow für Maintainer und Update-Verhalten beim Kunden: siehe [knowledgebase/release.md](knowledgebase/release.md).

## Mehrere Websites auf einem Server

Ein Checkout bedient beliebig viele Websites, je Kunde ein Kundenordner unter `sites/`, Webserver ist Caddy. Einrichtung und Betrieb (Server, Docker, Updates, `ops/tools/sites.php`, neuer Kunde, Umzug): [ops/README.md](ops/README.md). Der Ordner `ops/` ist nicht im Release, nur im Checkout am Server.

## Lizenz

Proprietär, nicht Open Source: Nutzung nur für Websites, die LEWEB einrichtet oder betreut. Details in [LICENSE](LICENSE).
