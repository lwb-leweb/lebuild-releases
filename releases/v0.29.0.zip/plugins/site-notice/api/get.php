<?php
declare(strict_types=1);

// Seiten-Editor: der eine Hinweis, unabhängig von der ID (row null, solange keiner angelegt ist).
require_once __DIR__ . '/../lib.php';

require_auth();
require_plugin_active(SITE_NOTICE_PLUGIN);

try {
    $fields = site_notice_fields();
    $row = site_notice_entry();
} catch (Throwable $e) {
    plugin_failure_response('load', $e);
}

json_response($row === null ? ['ok' => true, 'row' => null, 'schema' => $fields] : [
    'ok' => true,
    'row' => plugin_schema_decode_row($fields, $row),
    // Stand beim Laden: save.php meldet 409, wenn der Hinweis inzwischen geändert wurde.
    'version' => plugin_entry_version($row),
    'schema' => $fields,
]);
