<?php
declare(strict_types=1);

// Seiten-Editor: Name und Schema des einen Hinweises (rows: er selbst, falls angelegt).
require_once __DIR__ . '/../lib.php';

require_auth();
require_plugin_active(SITE_NOTICE_PLUGIN);

try {
    $fields = site_notice_fields();
    $row = site_notice_entry();
} catch (Throwable $e) {
    plugin_failure_response('load', $e);
}

json_response([
    'ok' => true,
    'type' => SITE_NOTICE_TYPE,
    'label' => SITE_NOTICE_TEXT['label'],
    'schema' => $fields,
    'rows' => $row === null ? [] : [plugin_schema_decode_row($fields, $row)],
]);
