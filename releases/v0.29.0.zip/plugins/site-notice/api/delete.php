<?php
declare(strict_types=1);

// Pflicht für inlineEdit; die Einzelansicht bietet kein Löschen (Abschalten: Text leeren).
require_once __DIR__ . '/../lib.php';

require_auth();
require_plugin_active(SITE_NOTICE_PLUGIN);
require_csrf();

json_response(['ok' => false, 'error' => API_TEXT['invalidRequest']], 400);
