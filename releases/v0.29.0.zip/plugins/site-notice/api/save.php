<?php
declare(strict_types=1);

// Seiten-Editor: speichert den einen Hinweis (legt ihn beim ersten Mal an), die ID im Aufruf zählt nicht.
require_once __DIR__ . '/../lib.php';

require_auth();
require_plugin_active(SITE_NOTICE_PLUGIN);
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
try {
    $existed = site_notice_entry() !== null;
    $id = site_notice_save($body);
} catch (InvalidArgumentException $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 400);
} catch (Throwable $e) {
    plugin_failure_response('save', $e);
}
le_activity_log($existed ? 'plugin_entry_updated' : 'plugin_entry_created', le_activity_plugin_target(SITE_NOTICE_PLUGIN, $id));

// Kennung der Einzelansicht auf der Seite, damit der Editor sie nach dem Neuladen wiederfindet.
json_response(['ok' => true, 'id' => SITE_NOTICE_ITEM_ID]);
