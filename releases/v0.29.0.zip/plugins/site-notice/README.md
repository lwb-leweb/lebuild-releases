# Info-Hinweis Plugin

Ein kurzer Hinweis auf jeder Seite der Website, z. B. „Wir sind im Betriebsurlaub“ oder „Wir bauen gerade um“. Besucher klicken ihn weg; der Browser merkt sich das.

## Aktivierung

Im Backend unter Plugins aktivieren. Legt die Tabelle `site_notices` an, danach steht „Info-Hinweis“ in der Seitenleiste. Die Website braucht keinen Einbau: Der Hinweis erscheint auf jeder Seite unten links.

## Was es kann

- Genau ein Hinweis; leerer Text heißt: kein Hinweis
- Optional Zeitraum: „Anzeigen ab“ und „Anzeigen bis“ (je einschließlich), leer heißt sofort bzw. ohne Ende
- Wegklicken; wird der Text geändert, sehen ihn alle wieder
- Ohne aktuellen Hinweis bleibt die Seite für Besucher unverändert (kein CSS, kein Skript)

## Bearbeiten

Auf der Website (auch Redakteure): Angemeldete sehen den Hinweis unten links immer, auch weggeklickt, vor oder nach dem Zeitraum (gestrichelt, mit Grund); ohne Text steht dort „+ Info-Hinweis“. Klick öffnet das Formular. In „Ansehen“ ist ausgeblendet, was Besucher nicht sehen. Abschalten: Text leeren oder „Anzeigen bis“ auf gestern setzen.

Im Admin gibt es weiter die generische Liste; zählt dort aber nur der älteste Eintrag.

## API-Endpoints

Seiten-Editor (`inlineEdit`): `api/{list,get,save}.php` arbeiten immer auf dem einen Hinweis (älteste Zeile), `save` legt ihn beim ersten Mal an und antwortet mit der festen Kennung `SITE_NOTICE_ITEM_ID`; `delete` lehnt ab. Das Backend nutzt die generischen Endpoints `/api/plugins/generic/{list,get,save,delete}.php?plugin=site-notice`.

## Frontend einbinden

Nichts einzubauen. Farben passt die Website über CSS-Variablen an:

```css
.site-notices { --site-notice-bg: #0b3d2e; --site-notice-color: #fff; --site-notice-radius: 4px; }
```

Klassen: `.site-notices` (Wurzel, fest unten links, auf dem Handy volle Breite), `.site-notice`, `.site-notice__text`, `.site-notice__close`; nur angemeldet `.site-notice--off`, `.site-notice--add`, `.site-notice__state`.

## Datenbank

`site_notices`: `id`, `title` (Nachricht, mehrzeiliger Text, leer erlaubt), `starts_on`, `ends_on` (`YYYY-MM-DD` oder leer), `created_at`, `updated_at`.

## Bekannte Einschränkungen

- Nur Text, keine Links oder Formatierung.
- Ohne JavaScript erscheint kein Hinweis (versteckt ausgeliefert, damit Weggeklicktes nicht aufblitzt).
- Weggeklickt gilt pro Browser (localStorage), im privaten Fenster bis zum Schließen; sperrt der Browser den Speicher, kommt der Hinweis auf jeder Seite wieder.
- Steht der Cookie-Banner offen, liegt er über dem Hinweis.

## Changelog

- **2026-11-10 — v1.1.0** — Nur noch ein Hinweis, direkt auf der Website bearbeitbar (auch für Redakteure); leerer Text schaltet ihn ab.
- **2026-11-09 — v1.0.0** — Erste Fassung: Hinweise mit optionalem Zeitraum auf jeder Seite, wegklickbar.
