// Zeigt den Info-Hinweis, wenn der Besucher ihn nicht weggeklickt hat, und merkt sich das Wegklicken im Browser.
// Angemeldet (data-site-notice-editor): Weggeklickt bleibt ein Knopf, der ihn wieder aufklappt; nach dem
// Speichern im Seiten-Editor (le-list-reloaded, neue Einzelansicht) gilt der Zustand für den neuen Text.
(function () {
  var STORE = 'site-notice-dismissed';
  var root = document.querySelector('[data-site-notice-root]');
  if (!root) return;
  var editor = root.hasAttribute('data-site-notice-editor');
  var box = editor ? root.querySelector('.site-notice-box') : root.querySelector('.site-notice');
  var opener = root.querySelector('.site-notice-open');

  function read() {
    try {
      var list = JSON.parse(localStorage.getItem(STORE) || '[]');
      return Array.isArray(list) ? list : [];
    } catch (e) {
      return [];
    }
  }

  function write(list) {
    try {
      // Nur die letzten 50 merken, alte Hinweise sind längst gelöscht.
      localStorage.setItem(STORE, JSON.stringify(list.slice(-50)));
    } catch (e) {
      // Ohne Speicher (privates Fenster, gesperrt) bleibt der Hinweis nur auf dieser Seite weg.
    }
  }

  // Kennung des aktuellen Textes; leer, solange der Hinweis keinen Text hat (nur angemeldet: Knopf zum Anlegen).
  function key() {
    var notice = root.querySelector('[data-site-notice]');
    return notice ? notice.getAttribute('data-site-notice') : '';
  }

  function show(visible) {
    box.hidden = !visible;
    if (opener) opener.hidden = visible;
  }

  function update() {
    var current = key();
    show(!current || read().indexOf(current) === -1);
  }

  root.querySelector('.site-notice__close').addEventListener('click', function () {
    var current = key();
    var list = read();
    if (current && list.indexOf(current) === -1) list.push(current);
    write(list);
    show(false);
  });
  if (opener) {
    opener.addEventListener('click', function () {
      var current = key();
      write(read().filter(function (item) { return item !== current; }));
      show(true);
    });
    root.addEventListener('le-list-reloaded', update);
  }
  update();
})();
