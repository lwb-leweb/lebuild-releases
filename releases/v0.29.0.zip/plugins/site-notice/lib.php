<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/db.php';
require_once __DIR__ . '/../../core/plugins.php';
require_once __DIR__ . '/../../core/pluginSchema.php';
require_once __DIR__ . '/../../core/textMarkup.php';

const SITE_NOTICE_PLUGIN = 'site-notice';
const SITE_NOTICE_TABLE = 'site_notices';
// Grundform und Wegklicken auf der Website (per HTTP erreichbar, plugins/.htaccess).
const SITE_NOTICE_STYLE = PLUGINS_URL . 'site-notice/assets/site-notice.css';
const SITE_NOTICE_SCRIPT = PLUGINS_URL . 'site-notice/assets/site-notice.js';
// Wurzelelement der Hinweise; steht es schon in der Seite, fügt der Filter nichts mehr ein.
const SITE_NOTICE_ROOT_ATTR = 'data-site-notice-root';
// Es gibt genau einen Hinweis. Im Seiten-Editor ist er eine Einzelansicht mit fester Kennung, damit sie
// auch vor dem ersten Speichern (noch keine Zeile) und danach dieselbe bleibt; die Endpoints arbeiten
// immer auf site_notice_entry().
const SITE_NOTICE_TYPE = 'notice';
const SITE_NOTICE_ITEM_ID = 1;
// Nur angemeldet: Hinweis, den Besucher gerade nicht sehen (in „Ansehen“ ausgeblendet), und Knopf
// zum Anlegen an seiner Stelle, solange er keinen Text hat.
const SITE_NOTICE_OFF_CLASS = 'site-notice--off';
const SITE_NOTICE_ADD_CLASS = 'site-notice--add';
// Wurzel für Angemeldete: Weggeklickt bleibt ein Knopf, der den Hinweis wieder aufklappt (site-notice.js).
const SITE_NOTICE_EDITOR_ATTR = 'data-site-notice-editor';
const SITE_NOTICE_TEXT = [
    'close' => 'Hinweis schließen',
    'label' => 'Info-Hinweis',
    'edit' => 'Info-Hinweis bearbeiten',
    'create' => 'Info-Hinweis anlegen',
    'add' => '+ Info-Hinweis',
    'off' => 'Besucher sehen ihn nicht.',
    'from' => 'Besucher sehen ihn ab %s.',
    'ended' => 'Besucher sahen ihn bis %s.',
];

/** Der Hinweis (älteste Zeile; weitere aus Version 1.0 bleiben unbeachtet), null ohne. */
function site_notice_entry(): ?array
{
    $row = db()->query('SELECT * FROM ' . SITE_NOTICE_TABLE . ' ORDER BY id ASC LIMIT 1')->fetch();

    return $row ?: null;
}

/**
 * Ob Besucher den Hinweis am Tag $today (YYYY-MM-DD) sehen: Text vorhanden, Beginn leer oder erreicht,
 * Ende leer oder noch nicht vorbei: dann null, sonst der Grund für Angemeldete (SITE_NOTICE_TEXT).
 */
function site_notice_state(?array $row, string $today): ?string
{
    if ($row === null || trim((string) $row['title']) === '') {
        return SITE_NOTICE_TEXT['off'];
    }
    $start = (string) ($row['starts_on'] ?? '');
    $end = (string) ($row['ends_on'] ?? '');
    if ($start !== '' && $start > $today) {
        return sprintf(SITE_NOTICE_TEXT['from'], site_notice_date($start));
    }
    if ($end !== '' && $end < $today) {
        return sprintf(SITE_NOTICE_TEXT['ended'], site_notice_date($end));
    }

    return null;
}

function site_notice_date(string $ymd): string
{
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $ymd);

    return $date ? $date->format('j.n.Y') : $ymd;
}

/**
 * Kennung fürs Wegklicken: ID plus Prüfsumme des Textes. Wer den Text ändert, zeigt den Hinweis
 * allen wieder, die die alte Fassung weggeklickt haben.
 */
function site_notice_key(array $row): string
{
    return (int) $row['id'] . '-' . substr(hash('sha256', (string) $row['title']), 0, 10);
}

/**
 * HTML des Hinweises, versteckt; das Skript zeigt ihn, wenn er nicht weggeklickt ist. Angemeldet als
 * Einzelansicht für den Seiten-Editor, auch außerhalb des Zeitraums (mit dem Grund $state) und ohne Text
 * (Knopf zum Anlegen). Wegklicken und der Knopf zum Wiederaufklappen liegen dann neben der Einzelansicht,
 * sonst öffnete der Klick das Formular; das Neuladen nach dem Speichern tauscht nur die Einzelansicht.
 */
function site_notice_html(?array $row, ?string $state, bool $editor): string
{
    $title = $row === null ? '' : trim((string) $row['title']);
    $key = $title === '' ? '' : ' data-site-notice="' . htmlspecialchars(site_notice_key($row), ENT_QUOTES) . '"';
    $close = '<button type="button" class="site-notice__close" aria-label="' . htmlspecialchars(SITE_NOTICE_TEXT['close'], ENT_QUOTES) . '">&times;</button>';
    $script = '<script src="' . SITE_NOTICE_SCRIPT . '" defer></script>';
    if (!$editor) {
        return '<div class="site-notices" ' . SITE_NOTICE_ROOT_ATTR . '>'
            . '<div class="site-notice" role="status"' . $key . ' hidden><p class="site-notice__text">' . le_text_lines($title) . '</p>' . $close . '</div>'
            . '</div>' . $script;
    }

    if ($title === '') {
        $classes = SITE_NOTICE_OFF_CLASS . ' ' . SITE_NOTICE_ADD_CLASS;
        $label = SITE_NOTICE_TEXT['create'];
        $text = htmlspecialchars(SITE_NOTICE_TEXT['add'], ENT_QUOTES);
    } else {
        $classes = $state === null ? '' : SITE_NOTICE_OFF_CLASS;
        $label = SITE_NOTICE_TEXT['edit'];
        $text = le_text_lines($title) . ($state === null ? '' : '<span class="site-notice__state">' . htmlspecialchars($state, ENT_QUOTES) . '</span>');
    }
    $notice = '<div class="' . trim('site-notice ' . $classes) . '"' . $key . ' '
        . le_single_attrs(SITE_NOTICE_PLUGIN, SITE_NOTICE_TYPE, SITE_NOTICE_ITEM_ID, $label) . '>'
        . '<p class="site-notice__text">' . $text . '</p></div>';

    return '<div class="site-notices" ' . SITE_NOTICE_ROOT_ATTR . ' ' . SITE_NOTICE_EDITOR_ATTR . '>'
        . '<div class="site-notice-box" hidden>' . $notice . $close . '</div>'
        . '<button type="button" class="site-notice-open" hidden>' . htmlspecialchars(SITE_NOTICE_TEXT['label'], ENT_QUOTES) . '</button>'
        . '</div>' . $script;
}

/**
 * Hook: Hinweis vor </body>, CSS vor </head>. Besucher ohne aktuellen Hinweis bekommen die Seite
 * unverändert, Angemeldete immer den Hinweis zum Bearbeiten.
 */
function site_notice_filter_site_html(string $html): string
{
    $body = strripos($html, '</body>');
    if ($body === false || str_contains($html, SITE_NOTICE_ROOT_ATTR)) {
        return $html;
    }
    try {
        $row = site_notice_entry();
    } catch (Throwable $e) {
        // Fehlertext nur ins Log, die Seite kommt ohne Hinweis.
        error_log('site-notice: ' . $e->getMessage());
        return $html;
    }
    $state = site_notice_state($row, date('Y-m-d'));
    $editor = signed_in_user() !== null;
    if ($state !== null && !$editor) {
        return $html;
    }

    $html = substr_replace($html, site_notice_html($row, $state, $editor), $body, 0);
    $head = stripos($html, '</head>');

    return $head === false ? $html : substr_replace($html, '<link rel="stylesheet" href="' . SITE_NOTICE_STYLE . '">', $head, 0);
}

/** Felder fürs Formular (schema.fields). */
function site_notice_fields(): array
{
    return plugin_schema_columns(plugin_manifest(SITE_NOTICE_PLUGIN));
}

/**
 * Speichert den Hinweis aus $body (data, optional version/overwrite wie generic/save.php): ändert die
 * vorhandene Zeile oder legt die erste an. Antwortet bei Konflikt selbst mit 409. Gibt die ID der Zeile zurück.
 */
function site_notice_save(array $body): int
{
    $fields = site_notice_fields();
    $stored = site_notice_entry();
    if ($stored !== null) {
        plugin_entry_conflict_check($body, plugin_entry_version($stored));
    }
    $values = plugin_schema_column_values(plugin_schema_values($fields, is_array($body['data'] ?? null) ? $body['data'] : [], $stored ?? []));
    // Zeitstempel setzt PHP (kein ON UPDATE, SQLite-Zeit wäre UTC).
    $values['updated_at'] = db_now();
    if ($stored === null) {
        $values['created_at'] = $values['updated_at'];
        $keys = array_keys($values);
        db()->prepare('INSERT INTO ' . SITE_NOTICE_TABLE . ' (`' . implode('`, `', $keys) . '`) VALUES (' . implode(', ', array_fill(0, count($keys), '?')) . ')')
            ->execute(array_values($values));

        return (int) db()->lastInsertId();
    }
    $sets = array_map(static fn (string $key): string => "`{$key}` = ?", array_keys($values));
    db()->prepare('UPDATE ' . SITE_NOTICE_TABLE . ' SET ' . implode(', ', $sets) . ' WHERE id = ?')
        ->execute([...array_values($values), (int) $stored['id']]);

    return (int) $stored['id'];
}
