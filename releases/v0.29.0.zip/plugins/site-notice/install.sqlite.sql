CREATE TABLE IF NOT EXISTS site_notices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL CHECK (length(title) <= 65535),
  starts_on TEXT NULL CHECK (starts_on IS NULL OR length(starts_on) = 10),
  ends_on TEXT NULL CHECK (ends_on IS NULL OR length(ends_on) = 10),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
