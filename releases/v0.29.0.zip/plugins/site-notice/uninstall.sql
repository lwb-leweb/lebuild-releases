DROP TABLE IF EXISTS site_notices;
