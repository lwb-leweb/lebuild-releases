# Info-Hinweis Plugin — Anleitung für KI-Agenten

## Was das Plugin tut

Zeigt einen kurzen Hinweis (Betriebsurlaub, Umbau) auf jeder Seite der Website unten links, wegklickbar, bearbeitbar im Seiten-Editor (Einzelansicht mit fester Kennung `SITE_NOTICE_ITEM_ID`). Bedienung: `README.md`.

## Was du als KI tun darfst

- Aussehen in `assets/site-notice.css` ändern; Klassen `site-notice*` und die Variablen `--site-notice-*` bleiben, Websites stylen darauf.
- Texte in `SITE_NOTICE_TEXT` (`lib.php`) anpassen.
- Für eine Website den Hinweis per `api/save.php` (`{type: notice, data}`) setzen.

## Was du NICHT anfassen darfst

- Kein eigenes Admin-Modul: Das Backend kommt aus `schema.fields` (generische Ansicht). Ein Modul erst, wenn das Schema nicht mehr reicht.
- `site_notice_key()` nicht ohne Not ändern: Sonst sehen alle Besucher weggeklickte Hinweise wieder.

## Dateistruktur

- `plugin.json` — Manifest mit Schema (Nachricht, Anzeigen ab/bis), Sidebar ohne Modul
- `lib.php` — der eine Hinweis (`site_notice_entry`, älteste Zeile), Zustand, HTML für Besucher und Angemeldete, Speichern, Hook `filter_site_html`
- `api/` — Endpoints für den Seiten-Editor (`inlineEdit`); `delete` lehnt ab
- `assets/site-notice.css`, `assets/site-notice.js` — Grundform, Anzeigen und Wegklicken (localStorage `site-notice-dismissed`)
- `admin/icon.svg` — Icon in der Seitenleiste
- `install*.sql`, `uninstall*.sql` — Tabelle `site_notices`

## Datenbank

`site_notices` (`id`, `title`, `starts_on`, `ends_on`, `created_at`, `updated_at`). Die Nachricht heißt `title`, damit die generische Liste sie als Titel zeigt (`TITLE_FIELDS` in `entry-form.js`).

## Häufige Anpassungen — wie geht das?

**Neues Feld (z. B. Link):** Feld in `plugin.json` (`schema.fields`), Spalte in beiden `install*.sql` (bestehende Installationen brauchen eine Migration), Ausgabe in `site_notice_html()` escaped, README und Test anpassen, Version hochzählen.

**Andere Position:** nur `assets/site-notice.css` (`.site-notices`).

## Fehlervermeidung

- Text immer über `le_text_lines()` ausgeben (escaped, Umbrüche als `<br>`), nie roh.
- Der Filter läuft auf jeder Seite: ohne aktuelle Hinweise früh zurück, Fehler nur ins Log, die Seite kommt dann ohne Hinweis.
- Datum gegen `date('Y-m-d')` vergleichen (Zeitzone `APP_TIMEZONE`), nicht in SQL rechnen (`CURDATE()` gibt es unter SQLite nicht).
