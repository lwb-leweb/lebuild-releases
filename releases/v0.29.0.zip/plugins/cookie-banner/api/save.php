<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../lib.php';

require_admin();
require_plugin_active('cookie-banner');
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$incoming = is_array($body['config'] ?? null) ? $body['config'] : [];
$bumpVersion = !empty($body['bumpVersion']);

if (isset($incoming['policyUrl']) && (!is_string($incoming['policyUrl']) || !cookie_banner_policy_url_valid(trim($incoming['policyUrl'])))) {
    json_response(['ok' => false, 'error' => COOKIE_BANNER_TEXT['invalidPolicyUrl']], 400);
}

// Lesen → Ändern → Schreiben (Teil-Konfiguration, Version hochzählen): unter Sperre, bis zum Ende des Requests.
$lock = store_lock('cookie-banner');
$current = cookie_banner_load_config();
$incoming = cookie_banner_overlay_config($current, $incoming);
if ($bumpVersion) {
    $incoming['version'] = (int) ($current['version'] ?? 1) + 1;
}

try {
    cookie_banner_save_config($incoming);
} catch (Throwable $e) {
    // Details (Pfade) nur ins Log.
    error_log('cookie-banner save failed: ' . $e->getMessage());
    json_response(['ok' => false, 'error' => COOKIE_BANNER_TEXT['saveFailed']], 500);
}
le_activity_log('plugin_settings_saved', le_activity_plugin_target('cookie-banner'));

json_response(['ok' => true, 'config' => cookie_banner_load_config()]);
