let outletEl = null;
let ctxRef = null;
let currentType = '';
let currentLabel = '';
let currentSchema = [];
// Liste im Backend: alle Einträge, Spalten (Feldnamen aus list.php), Stand je id, Filter der Ansicht.
let allRows = [];
let columns = [];
let scheduling = false;
let visibility = {};
let filters = { search: '', fields: {}, state: '' };

// Texte der Ansicht; die Gründe ungültiger Typen und Fehler beim Import kommen vom Server
// (CONTENT_TYPES_INVALID_TEXT, CONTENT_TYPES_IMPORT_TEXT).
const CT_TEXT = {
  noType: 'Kein Content-Typ ausgewählt.',
  invalid: 'Diese Content-Typen sind ungültig und erscheinen weder hier noch auf der Website:',
  importButton: 'Importieren',
  importInvalid: 'Die Datei enthält kein gültiges JSON.',
  imported: '%s Einträge importiert.',
  importedOne: '1 Eintrag importiert.',
  newEntry: 'Neuer Eintrag',
  edit: 'Bearbeiten',
  remove: 'Löschen',
  empty: 'Noch keine Einträge.',
  noMatch: 'Kein Eintrag passt zu Suche und Filter.',
  reset: 'Filter zurücksetzen',
  search: 'Suchen …',
  title: 'Titel',
  state: 'Stand',
  all: 'alle',
  count: '%s Einträge',
  countOne: '1 Eintrag',
  countOf: '%s von %t Einträgen',
  yes: 'Ja',
  no: 'Nein',
  empty_value: '–'
};
// Stand auf der Website (list.php: visibility je id, fehlt = online) → Text und Farbe (.status--…).
const CT_STATES = {
  online: { label: 'Online', className: 'status--active' },
  scheduled: { label: 'Geplant', className: 'status--installed' },
  expired: { label: 'Abgelaufen', className: 'status--inactive' }
};
const CT_ONLINE = 'online';
// Auswahlfelder, die die Ansicht als Filter oben anbietet (je Feld ein Menü), höchstens so viele.
const FILTER_FIELD_TYPES = ['select', 'boolean'];
const MAX_FIELD_FILTERS = 3;
// Felder, deren Text die Suche durchsucht (dazu der Titel und die Labels von Auswahlfeldern).
const SEARCH_FIELD_TYPES = ['text', 'textarea', 'select', 'url'];
// Dateiauswahl beim Import: JSON-Datei mit einer Liste von Einträgen (api/import.php).
const IMPORT_ACCEPT = '.json,application/json';

const contentTypesModule = {
  id: 'content-types',
  mount(outlet, ctx) {
    outletEl = outlet;
    ctxRef = ctx;
    currentType = ctx.subRoute || '';
    filters = { search: '', fields: {}, state: '' };
    if (!currentType) {
      renderProblems(ctx.info && Array.isArray(ctx.info.problems) ? ctx.info.problems : []);
      return;
    }
    renderShell();
    loadList();
  },
  unmount() {
    if (ctxRef && ctxRef.ui && ctxRef.ui.closeModal) ctxRef.ui.closeModal();
    outletEl = null;
    ctxRef = null;
    currentType = '';
    currentLabel = '';
    currentSchema = [];
    allRows = [];
  }
};

export default contentTypesModule;

// Ohne Typ: Hinweis auf ungültige Typ-Definitionen (Eintrag CONTENT_TYPES_INVALID_LABEL der Seitenleiste).
function renderProblems(problems) {
  const text = problems.length ? CT_TEXT.invalid : CT_TEXT.noType;
  outletEl.innerHTML = '<section class="view-area"><div class="view-card"><p class="message">' + escapeHtml(text) + '</p>'
    + (problems.length ? '<ul>' + problems.map(function (problem) { return '<li>' + escapeHtml(problem) + '</li>'; }).join('') + '</ul>' : '')
    + '</div></section>';
}

function renderShell() {
  outletEl.innerHTML = `
    <section class="view-area content-types-admin">
      <div class="view-card span-12">
        <div class="topbar">
          <div class="entries-head">
            <strong id="ctTitle">${escapeHtml(currentType)}</strong>
            <span id="ctCount" class="entries-head__count"></span>
          </div>
          <div class="form-actions">
            <button type="button" id="ctImportBtn" class="secondary">${CT_TEXT.importButton}</button>
            <input type="file" id="ctImportFile" accept="${IMPORT_ACCEPT}" hidden>
            <button type="button" id="ctNewBtn">${CT_TEXT.newEntry}</button>
          </div>
        </div>
        <div id="ctFilters" class="entries-filters" hidden></div>
        <p id="ctMsg" class="message"></p>
        <div id="ctList"></div>
      </div>
    </section>
  `;
  outletEl.querySelector('#ctNewBtn').addEventListener('click', function () {
    openForm(null);
  });
  const fileInput = outletEl.querySelector('#ctImportFile');
  outletEl.querySelector('#ctImportBtn').addEventListener('click', function () {
    fileInput.click();
  });
  fileInput.addEventListener('change', function () {
    const file = fileInput.files && fileInput.files[0];
    fileInput.value = '';
    if (file) importFile(file);
  });
}

// Import (nur Admins, prüft der Server): Datei lesen, Einträge schicken; ganz oder gar nicht, Meldung
// mit Zeile und Feld vom Server. Danach lädt die Liste neu. Bis zur Antwort ist der Knopf gesperrt,
// damit dieselbe Datei nicht doppelt angehängt wird.
function importFile(file) {
  const button = document.getElementById('ctImportBtn');
  button.disabled = true;
  file.text().then(function (text) {
    let entries;
    try {
      entries = JSON.parse(text);
    } catch (e) {
      throw new Error(CT_TEXT.importInvalid);
    }
    return ctxRef.api('/plugins/content-types/api/import.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: currentType, entries: entries })
    });
  }).then(function (data) {
    showMessage(data.imported === 1 ? CT_TEXT.importedOne : CT_TEXT.imported.replace('%s', data.imported), true);
    loadList();
  }).catch(showError).finally(function () {
    button.disabled = false;
  });
}

function loadList() {
  ctxRef.api('/plugins/content-types/api/list.php?type=' + encodeURIComponent(currentType))
    .then(function (data) {
      currentLabel = data.label || currentType;
      currentSchema = data.schema || [];
      allRows = data.rows || [];
      columns = (data.columns || []).map(fieldOf).filter(Boolean);
      scheduling = Boolean(data.scheduling);
      visibility = data.visibility || {};
      const titleEl = document.getElementById('ctTitle');
      if (titleEl) titleEl.textContent = currentLabel;
      renderFilters();
      renderList();
    })
    .catch(showError);
}

function fieldOf(name) {
  return currentSchema.find(function (field) { return field.name === name; }) || null;
}

function stateOf(row) {
  return visibility[row.id] || CT_ONLINE;
}

// Filter oben: Suche, je Auswahlfeld ein Menü (höchstens MAX_FIELD_FILTERS), mit Terminen der Stand.
// Ohne Einträge keine Filter. Die gewählten Werte bleiben beim Neuladen der Liste (Speichern, Löschen).
function renderFilters() {
  const box = document.getElementById('ctFilters');
  if (!box) return;
  box.hidden = !allRows.length;
  if (!allRows.length) return;
  const fields = currentSchema.filter(function (field) {
    return FILTER_FIELD_TYPES.indexOf(field.type) !== -1 && !field.showWhen && field.name !== 'action';
  }).slice(0, MAX_FIELD_FILTERS);
  let html = '<input type="search" id="ctSearch" class="entries-filters__search" placeholder="' + escapeHtml(CT_TEXT.search)
    + '" aria-label="' + escapeHtml(CT_TEXT.search) + '" value="' + escapeHtml(filters.search) + '">';
  fields.forEach(function (field) {
    const options = field.type === 'boolean' ? [['1', CT_TEXT.yes], ['0', CT_TEXT.no]]
      : (field.options || []).map(function (value) { return [value, optionLabel(field, value)]; });
    html += selectHtml('field:' + field.name, field.label || field.name, filters.fields[field.name] || '',
      [['', (field.label || field.name) + ': ' + CT_TEXT.all]].concat(options));
  });
  if (scheduling) {
    html += selectHtml('state', CT_TEXT.state, filters.state, [['', CT_TEXT.state + ': ' + CT_TEXT.all]].concat(Object.keys(CT_STATES).map(function (key) {
      return [key, CT_STATES[key].label];
    })));
  }
  box.innerHTML = html;
  box.querySelector('#ctSearch').addEventListener('input', function (event) {
    filters.search = event.target.value;
    renderList();
  });
  box.querySelectorAll('select').forEach(function (select) {
    select.addEventListener('change', function () {
      const key = select.dataset.filter;
      if (key === 'state') filters.state = select.value;
      else filters.fields[key.slice(6)] = select.value;
      renderList();
    });
  });
}

function selectHtml(key, label, value, options) {
  return '<select data-filter="' + escapeHtml(key) + '" aria-label="' + escapeHtml(label) + '">'
    + options.map(function (option) {
      return '<option value="' + escapeHtml(option[0]) + '"' + (option[0] === value ? ' selected' : '') + '>' + escapeHtml(option[1]) + '</option>';
    }).join('') + '</select>';
}

function optionLabel(field, value) {
  const labels = field.optionLabels || {};
  return Object.prototype.hasOwnProperty.call(labels, value) ? String(labels[value]) : String(value);
}

function matches(row) {
  if (filters.state && stateOf(row) !== filters.state) return false;
  for (const name in filters.fields) {
    const wanted = filters.fields[name];
    if (wanted === '') continue;
    const field = fieldOf(name);
    const value = row[name];
    const actual = field && field.type === 'boolean' ? (value && value !== '0' ? '1' : '0') : String(value == null ? '' : value);
    if (actual !== wanted) return false;
  }
  const words = filters.search.trim().toLowerCase().split(/\s+/).filter(Boolean);
  if (!words.length) return true;
  const text = [ctxRef.ui.entryTitle(currentSchema, row)].concat(currentSchema.filter(function (field) {
    return SEARCH_FIELD_TYPES.indexOf(field.type) !== -1;
  }).map(function (field) {
    const value = row[field.name];
    if (value == null) return '';
    return field.type === 'select' ? optionLabel(field, value) : String(value);
  })).join(' ').toLowerCase();
  return words.every(function (word) { return text.indexOf(word) !== -1; });
}

// Tabelle: Titel (mit dem ersten Bild der Spalten als Vorschau davor), die übrigen Spalten, mit Terminen
// der Stand, rechts Bearbeiten und Löschen. Ein Klick auf die Zeile öffnet den Eintrag.
function renderList() {
  const list = document.getElementById('ctList');
  if (!list) return;
  const rows = allRows.filter(matches);
  renderCount(rows.length);

  if (!allRows.length) {
    list.innerHTML = '<p class="entries-empty">' + escapeHtml(CT_TEXT.empty) + '</p>';
    return;
  }
  if (!rows.length) {
    list.innerHTML = '<p class="entries-empty">' + escapeHtml(CT_TEXT.noMatch)
      + ' <button type="button" class="secondary" id="ctReset">' + escapeHtml(CT_TEXT.reset) + '</button></p>';
    list.querySelector('#ctReset').addEventListener('click', function () {
      filters = { search: '', fields: {}, state: '' };
      renderFilters();
      renderList();
    });
    return;
  }

  const title = ctxRef.ui.titleField(currentSchema);
  const thumb = columns.find(function (field) { return field.type === 'image'; }) || null;
  const rest = columns.filter(function (field) { return field !== thumb && field.name !== title; });
  const head = '<th>' + escapeHtml(CT_TEXT.title) + '</th>'
    + rest.map(function (field) { return '<th>' + escapeHtml(field.label || field.name) + '</th>'; }).join('')
    + (scheduling ? '<th>' + escapeHtml(CT_TEXT.state) + '</th>' : '')
    + '<th class="entries-table__actions-head"></th>';
  const body = rows.map(function (row) {
    const state = CT_STATES[stateOf(row)];
    const image = thumb ? (row[thumb.name] ? '<img src="' + escapeHtml(row[thumb.name]) + '" alt="" loading="lazy">' : '<span class="entries-table__no-image"></span>') : '';
    return '<tr data-id="' + escapeHtml(row.id) + '">'
      + '<td><div class="entries-table__title">' + image + '<span>' + escapeHtml(ctxRef.ui.entryTitle(currentSchema, row)) + '</span></div></td>'
      + rest.map(function (field) { return '<td class="entries-table__' + field.type + '">' + cellHtml(field, row[field.name]) + '</td>'; }).join('')
      + (scheduling ? '<td><span class="status ' + state.className + '">' + escapeHtml(state.label) + '</span></td>' : '')
      + '<td class="entries-table__actions">'
      + '<button type="button" class="secondary" data-action="edit">' + escapeHtml(CT_TEXT.edit) + '</button>'
      + '<button type="button" class="secondary" data-action="delete">' + escapeHtml(CT_TEXT.remove) + '</button>'
      + '</td></tr>';
  }).join('');
  list.innerHTML = '<div class="entries-table-wrap"><table class="entries-table' + (thumb ? ' entries-table--thumbs' : '') + '"><thead><tr>'
    + head + '</tr></thead><tbody>' + body + '</tbody></table></div>';

  list.querySelectorAll('tbody tr').forEach(function (tr) {
    const id = parseInt(tr.dataset.id, 10);
    tr.addEventListener('click', function (event) {
      const button = event.target.closest('button');
      if (button && button.dataset.action === 'delete') {
        removeEntry(id);
        return;
      }
      openFormFromServer(id);
    });
  });
}

function renderCount(shown) {
  const count = document.getElementById('ctCount');
  if (!count) return;
  const total = allRows.length;
  count.textContent = !total ? '' : shown !== total
    ? CT_TEXT.countOf.replace('%s', shown).replace('%t', total)
    : (total === 1 ? CT_TEXT.countOne : CT_TEXT.count.replace('%s', total));
}

function removeEntry(id) {
  const row = allRows.find(function (entry) { return Number(entry.id) === id; });
  if (!ctxRef.confirm(ctxRef.ui.deleteQuestion(currentSchema, row))) return;
  ctxRef.api('/plugins/content-types/api/delete.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: currentType, id: id })
  }).then(loadList).catch(showError);
}

// Wert einer Spalte lesbar: Datum deutsch, Auswahl mit Label, Kästchen als „Ja“, Link ohne https://, leer „–“.
function cellHtml(field, value) {
  if (value == null || value === '') return '<span class="entries-table__none">' + CT_TEXT.empty_value + '</span>';
  const text = String(value);
  if (field.type === 'date' || field.type === 'datetime') return escapeHtml(formatDate(text));
  if (field.type === 'select') return escapeHtml(optionLabel(field, text));
  if (field.type === 'boolean') return text !== '0' ? escapeHtml(CT_TEXT.yes) : '<span class="entries-table__none">' + CT_TEXT.empty_value + '</span>';
  if (field.type === 'image') return '<img src="' + escapeHtml(text) + '" alt="" loading="lazy">';
  if (field.type === 'url') return escapeHtml(text.replace(/^https?:\/\/(www\.)?/, '').replace(/\/$/, ''));
  return escapeHtml(text);
}

// „2026-11-06“ → „6.11.2026“, „2026-11-06 18:30:00“ → „6.11.2026, 18:30“.
function formatDate(value) {
  const m = /^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2}))?/.exec(value);
  if (!m) return value;
  const day = Number(m[3]) + '.' + Number(m[2]) + '.' + m[1];
  return m[4] ? day + ', ' + m[4] + ':' + m[5] : day;
}

function openFormFromServer(id) {
  ctxRef.api('/plugins/content-types/api/get.php?type=' + encodeURIComponent(currentType) + '&id=' + id)
    .then(function (data) {
      currentSchema = data.schema || currentSchema;
      openForm(data.row || null, data.version);
    })
    .catch(showError);
}

function openForm(row, version) {
  ctxRef.ui.openEntryForm({
    schema: currentSchema,
    row: row,
    save: function (data, extra) {
      const body = Object.assign({ type: currentType, data: data }, extra);
      if (row && row.id) body.id = row.id;
      if (row && version) body.version = version;
      return ctxRef.api('/plugins/content-types/api/save.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
    },
    reload: row ? function () { openFormFromServer(row.id); } : null,
    onSaved: loadList
  });
}

function showError(error) {
  showMessage(error.message || String(error), false);
}

function showMessage(text, ok) {
  const msg = document.getElementById('ctMsg');
  if (!msg) return;
  msg.textContent = text;
  msg.classList.toggle('ok', ok);
}

function escapeHtml(value) {
  return String(value || '').replace(/[&<>"']/g, function (char) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
  });
}
