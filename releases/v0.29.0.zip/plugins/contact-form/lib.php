<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/mail.php';
require_once __DIR__ . '/../../core/utils.php';

// Spamschutz-Konstanten (Ablauf in AGENT.md, „Fehlervermeidung“).
const CONTACT_FORM_HONEYPOT   = 'url';   // verstecktes Feld; nur Bots fuellen es aus
const CONTACT_FORM_RATE_MAX   = 5;       // max. Submits pro IP (IPv6: je /64) und Fenster
const CONTACT_FORM_RATE_WINDOW = 3600;   // Fenster in Sekunden (60 Min)
const CONTACT_FORM_RATE_PRUNE_ODDS = 50; // etwa jede 50. Reservierung raeumt alte Dateien weg

// Antworten von api/submit.php an den Besucher (Klartext).
const CONTACT_FORM_TEXT = [
    'rateLimit' => 'Zu viele Anfragen, bitte später erneut.',
    'missingFields' => 'Fehlende Felder.',
    'invalidEmail' => 'Ungültige E-Mail.',
    'noRecipient' => 'Empfänger-Adresse nicht konfiguriert.',
    'sendFailed' => 'Versand fehlgeschlagen.',
    'sent' => 'Danke, Ihre Nachricht ist angekommen.',
];
// Markierung in der Adresse nach dem Absenden aus dem Browser (?kontakt=…#kontaktformular): Wert → Text der Meldung.
const CONTACT_FORM_RESULT_PARAM = 'kontakt';
const CONTACT_FORM_ANCHOR = 'kontaktformular';
const CONTACT_FORM_RESULTS = [
    'gesendet' => 'sent',
    'fehlende-felder' => 'missingFields',
    'ungueltige-email' => 'invalidEmail',
    'zu-viele' => 'rateLimit',
    'kein-empfaenger' => 'noRecipient',
    'versand' => 'sendFailed',
];

function contact_form_config_recipient(): string
{
    return core_mail_default_recipient();
}

function contact_form_signature(string $recipient): string
{
    return hash_hmac('sha256', 'contact-form-recipient|' . $recipient, app_secret());
}

function contact_form_verified_recipient(string $recipient, string $signature): string
{
    if ($recipient !== '' && filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
        $expected = contact_form_signature($recipient);
        if (hash_equals($expected, $signature)) {
            return $recipient;
        }
    }

    return contact_form_config_recipient();
}

/**
 * Whitelist optionaler Zusatzfelder. Schluessel = POST-Feldname, Wert = Label im
 * Mailtext. Reihenfolge = Reihenfolge im Mailtext. Labels generisch halten; ein
 * site-spezifisches Body-Label ist ein spaeteres, admin-konfigurierbares v2-Thema.
 * Nur Felder aus dieser Liste landen in der Mail -- niemals beliebige $_POST-Keys.
 */
function contact_form_extra_fields(): array
{
    return [
        'company'  => 'Firma',
        'phone'    => 'Telefon',
        'telegram' => 'Telegram',
        'subject'  => 'Betreff',
    ];
}

/** Nachricht wörtlich (kein strip_tags, „a < b“ bleibt): Umbrüche als \n, Steuerzeichen außer Tab und Umbruch fallen weg. */
function contact_form_message_text(string $value): string
{
    return trim(preg_replace(['/\r\n?/', '/[\x00-\x08\x0B-\x1F\x7F]/'], ["\n", ''], $value) ?? '');
}

/**
 * Betreff und Text der Mail (text/plain, nichts wird als HTML gelesen): Name einzeilig, die befüllten
 * Whitelist-Felder (Registry-Reihenfolge), eine Leerzeile, die Nachricht. Alle Werte wörtlich; niemals
 * beliebige $post-Keys. Der Betreff bleibt fest, ein Feld `subject` ist nur ein Body-Feld.
 */
function contact_form_mail(string $name, string $email, string $message, array $post): array
{
    $lines = [
        'Name: ' . $name,
        'E-Mail: ' . $email,
    ];
    foreach (contact_form_extra_fields() as $key => $label) {
        $value = core_mail_clean_header(is_string($post[$key] ?? null) ? $post[$key] : '');
        if ($value !== '') {
            // mb_substr: ein Umlaut an der Grenze darf nicht halbiert werden.
            $lines[] = $label . ': ' . mb_substr($value, 0, 200);
        }
    }

    return [
        'subject' => 'Kontaktformular: ' . mb_substr($name, 0, 60),
        'text' => implode("\n", $lines) . "\n\n" . $message . "\n",
    ];
}

/**
 * Honeypot: ist das versteckte Feld vorhanden UND befuellt, ist es ein Bot.
 * Fehlt das Feld (alte Formulare), wird nicht geblockt.
 */
function contact_form_honeypot_tripped(): bool
{
    return trim((string) ($_POST[CONTACT_FORM_HONEYPOT] ?? '')) !== '';
}

/**
 * Erfolgs-/Honeypot-Antwort: 303-Redirect auf den Referer. Bewusst identisch
 * fuer beide Faelle, damit ein Honeypot-Treffer wie ein Erfolg aussieht. Aus dem
 * Browser abgeschickt (contact_form_navigation) mit Markierung „gesendet“.
 */
function contact_form_submit_redirect(): void
{
    if (contact_form_navigation()) {
        contact_form_back('gesendet');
        return;
    }
    http_response_code(303);
    header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? '/'));
}

/** Abgeschickt als Seitenaufruf des Browsers (normales Formular), nicht per fetch: Antwort ist dann eine Rückleitung. */
function contact_form_navigation(): bool
{
    // Ohne Sec-Fetch-Mode (alte Browser, http): Formulare schicken Accept mit text/html vorne; jQuery & Co. setzen
    // X-Requested-With.
    $mode = (string) ($_SERVER['HTTP_SEC_FETCH_MODE'] ?? '');
    if ($mode !== '') {
        return $mode === 'navigate';
    }
    return !isset($_SERVER['HTTP_X_REQUESTED_WITH']) && str_starts_with(strtolower(trim((string) ($_SERVER['HTTP_ACCEPT'] ?? ''))), 'text/html');
}

/**
 * Zurück auf die Seite des Formulars (Pfad und Query des Referers, nie ein fremder Host) mit ?kontakt=$result
 * (CONTACT_FORM_RESULTS) und Sprung zum Formular.
 */
function contact_form_back(string $result): void
{
    $referer = parse_url((string) ($_SERVER['HTTP_REFERER'] ?? '')) ?: [];
    $path = (string) ($referer['path'] ?? '');
    // Nur ein Pfad dieser Website: kein //host, kein Backslash (Browser lesen /\host wie //host), keine Steuerzeichen.
    if (!preg_match('#^/(?![/\\\\])[^\\\\\x00-\x20\x7f]*$#', $path)) {
        $path = '/';
    }
    // Die übrige Query bleibt wörtlich, nur eine alte Markierung fällt weg.
    $keep = array_filter(explode('&', (string) ($referer['query'] ?? '')), static fn (string $part): bool => $part !== ''
        && !preg_match('/[\x00-\x20\x7f]/', $part) && explode('=', $part, 2)[0] !== CONTACT_FORM_RESULT_PARAM);
    $keep[] = CONTACT_FORM_RESULT_PARAM . '=' . rawurlencode($result);
    http_response_code(303);
    header('Location: ' . $path . '?' . implode('&', $keep) . '#' . CONTACT_FORM_ANCHOR);
}

/** Fehlerantwort: aus dem Browser als Rückleitung mit Markierung, sonst Status mit Text (fetch, curl). */
function contact_form_fail(int $status, string $result): void
{
    if (contact_form_navigation()) {
        contact_form_back($result);
        return;
    }
    http_response_code($status);
    echo CONTACT_FORM_TEXT[CONTACT_FORM_RESULTS[$result]];
}

/** Meldung nach der Rückleitung (?kontakt=…) für das Formular; null ohne oder bei unbekannter Markierung. */
function contact_form_result_notice(): ?array
{
    $result = $_GET[CONTACT_FORM_RESULT_PARAM] ?? '';
    $key = is_string($result) ? (CONTACT_FORM_RESULTS[$result] ?? null) : null;
    return $key === null ? null : ['ok' => $key === 'sent', 'text' => CONTACT_FORM_TEXT[$key]];
}

function contact_form_rate_dir(): string
{
    return CACHE_ROOT . '/contact-form/ratelimit';
}

/**
 * Datei pro IP, IPv6 je /64-Netz wie bei der Login-Sperre (sonst nimmt ein Spammer für jede Anfrage eine neue
 * Adresse aus seinem Netz). Keine Roh-IP speichern -- nur per HMAC mit dem Installations-Schlüssel.
 */
function contact_form_rate_file(): string
{
    $ip = le_login_ip_key((string) ($_SERVER['REMOTE_ADDR'] ?? ''));
    $hash = substr(hash_hmac('sha256', $ip, app_secret()), 0, 32);

    return contact_form_rate_dir() . '/' . $hash . '.json';
}

/**
 * Liest die Timestamps der aktuellen IP und verwirft alles ausserhalb des Fensters.
 */
function contact_form_rate_timestamps(): array
{
    $raw = @file_get_contents(contact_form_rate_file());
    if ($raw === false) {
        return [];
    }

    $data = json_decode($raw, true);
    if (!is_array($data)) {
        return [];
    }

    $cutoff = time() - CONTACT_FORM_RATE_WINDOW;
    $valid = [];
    foreach ($data as $ts) {
        $ts = (int) $ts;
        if ($ts > $cutoff) {
            $valid[] = $ts;
        }
    }

    return $valid;
}

/**
 * false = gesperrt. Prueft nur, schreibt nichts (frueher 429 vor der Validierung).
 * Entscheidend ist contact_form_rate_reserve() direkt vor dem Versand.
 */
function contact_form_rate_check(): bool
{
    return count(contact_form_rate_timestamps()) < CONTACT_FORM_RATE_MAX;
}

/**
 * Fuehrt $fn unter einer exklusiven Sperre fuer alle Rate-Limit-Dateien aus. Ohne Sperre
 * (Verzeichnis nicht beschreibbar) laeuft $fn trotzdem, damit das Formular nicht ausfaellt.
 */
function contact_form_rate_locked(callable $fn): mixed
{
    try {
        ensure_dir(contact_form_rate_dir());
    } catch (Throwable $e) {
        error_log('contact-form rate limit: ' . $e->getMessage());
    }
    $lock = @fopen(contact_form_rate_dir() . '/.lock', 'c');
    if ($lock !== false && !flock($lock, LOCK_EX)) {
        fclose($lock);
        $lock = false;
    }
    try {
        return $fn();
    } finally {
        if ($lock !== false) {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }
}

/** Schreibt die Timestamps der aktuellen IP atomar via tmp + rename. */
function contact_form_rate_write(array $timestamps): void
{
    $file = contact_form_rate_file();
    $tmp = $file . '.' . bin2hex(random_bytes(4)) . '.tmp';
    if (file_put_contents($tmp, json_encode(array_values($timestamps)), LOCK_EX) === false) {
        @unlink($tmp);
        return;
    }
    if (!rename($tmp, $file)) {
        @unlink($tmp);
    }
}

/**
 * Reserviert vor dem Versand einen Slot: Pruefen und Eintragen unter einer Sperre, damit
 * parallele Anfragen das Limit nicht gemeinsam unterlaufen. Liefert den Timestamp des
 * Slots (fuer contact_form_rate_release()) oder null, wenn das Limit erreicht ist.
 * Erst nach Honeypot und Validierung aufrufen -- sonst fuellen Bots das Fenster mit
 * Garbage und sperren echte Nutzer aus.
 */
function contact_form_rate_reserve(): ?int
{
    return contact_form_rate_locked(static function (): ?int {
        $timestamps = contact_form_rate_timestamps();
        if (count($timestamps) >= CONTACT_FORM_RATE_MAX) {
            return null;
        }
        $now = time();
        $timestamps[] = $now;
        contact_form_rate_write($timestamps);
        // Gelegentlich alte Dateien anderer IPs wegraeumen.
        if (random_int(1, CONTACT_FORM_RATE_PRUNE_ODDS) === 1) {
            contact_form_rate_prune();
        }
        return $now;
    });
}

/** Gibt einen Slot wieder frei, wenn der Versand gescheitert ist. */
function contact_form_rate_release(int $slot): void
{
    contact_form_rate_locked(static function () use ($slot): void {
        $timestamps = contact_form_rate_timestamps();
        $pos = array_search($slot, $timestamps, true);
        if ($pos !== false) {
            unset($timestamps[$pos]);
            contact_form_rate_write($timestamps);
        }
    });
}

/**
 * Loescht Rate-Limit-Dateien, die seit einem ganzen Fenster nicht geschrieben wurden (und
 * liegengebliebene .tmp). Laeuft unter der Sperre aus contact_form_rate_reserve().
 */
function contact_form_rate_prune(): int
{
    $dir = contact_form_rate_dir();
    $cutoff = time() - CONTACT_FORM_RATE_WINDOW;
    $removed = 0;
    foreach (array_merge(glob($dir . '/*.json') ?: [], glob($dir . '/*.tmp') ?: []) as $file) {
        $mtime = @filemtime($file);
        if ($mtime !== false && $mtime < $cutoff && @unlink($file)) {
            $removed++;
        }
    }
    return $removed;
}
