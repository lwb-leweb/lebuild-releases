# Kontaktformular Plugin

Rendert ein einfaches Kontaktformular per Shortcode. Der Versand nutzt den zentralen Core-Mailer: SMTP, wenn in den globalen Einstellungen konfiguriert, sonst PHP `mail()`.

## Aktivierung

Im Admin unter "Erweiterungen" das Plugin "Kontaktformular" aktivieren. Es legt keine Datenbanktabellen an.

## Was es kann

- Kontaktformular per Shortcode rendern
- Name, E-Mail und Nachricht validieren
- Standard-Empfaenger aus den globalen Mail-Einstellungen verwenden
- Optional signierten Shortcode-Empfaenger verwenden
- Versand ueber SMTP oder PHP `mail()` via Core-Mailer
- Spamschutz ohne externen Dienst: Honeypot-Feld + datei-basiertes IP-Rate-Limit (max. 5 Submits / 60 Min / IP)
- Optionale Zusatzfelder (Firma, Telefon, Telegram, Betreff) ueber eine Whitelist im Plugin-Code -- werden mit Label oberhalb der Nachricht in den Mailtext aufgenommen

## Im Admin verwenden

SMTP wird nicht im Plugin selbst gepflegt. Die Einstellungen liegen global unter "Einstellungen" -> "E-Mail / SMTP".

## API-Endpoints

| Endpoint | Methode | Auth | Parameter | Response |
|---|---|---|---|---|
| `/plugins/contact-form/api/submit.php` | POST | nein | `name`, `email`, `message`, `recipient`, `recipient_sig`, optional `company`, `phone`, `telegram`, `subject`, Honeypot `url` | siehe Antwort-Codes unten |

Beispiel:

```bash
curl -i -X POST https://example.com/plugins/contact-form/api/submit.php \
  -d 'name=Max' \
  -d 'email=max@example.com' \
  -d 'message=Hallo'
```

### Antwort-Codes

| Fall | Code | Body | AJAX (`res.ok`) |
|---|---|---|---|
| Erfolg | `303` | `Location: Referer` | true (Redirect folgt) |
| Honeypot-Treffer | `303` | `Location: Referer` | true (stiller Drop, keine Mail) |
| Pflichtfeld fehlt | `400` | „Fehlende Felder." | false |
| Ungueltige E-Mail | `400` | „Ungültige E-Mail." | false |
| Rate-Limit | `429` | „Zu viele Anfragen, bitte später erneut." | false |
| Versand-Fehler | `500` | „Versand fehlgeschlagen." | false |

Ein Honeypot-Treffer antwortet bewusst wie ein Erfolg, damit Bots den Mechanismus nicht erkennen.

Normales Absenden aus dem Browser (`Sec-Fetch-Mode: navigate`; ohne diesen Header: `Accept` beginnt mit `text/html` und kein `X-Requested-With`): Erfolg und jeder Fehler leiten per `303` auf die Seite des Formulars zurück (Pfad und Query des Referers wörtlich, nie ein fremder Host), mit `?kontakt=<ergebnis>#kontaktformular` (`gesendet`, `fehlende-felder`, `ungueltige-email`, `zu-viele`, `kein-empfaenger`, `versand`). Das Formular (`id="kontaktformular"`) zeigt dann die Meldung (`p.contact-form__notice--ok` bzw. `--error`); die Eingaben sind nach einem Fehler leer. Per `fetch`/curl bleibt es bei der Tabelle oben.

### Zusatzfelder (Whitelist)

Optionale Felder werden nur uebernommen, wenn ihr Name in der Registry `contact_form_extra_fields()` (`lib.php`) steht -- derzeit `company` (Firma), `phone` (Telefon), `telegram` (Telegram), `subject` (Betreff). Jeder Wert wird auf eine Zeile bereinigt und auf 200 Zeichen gekuerzt; leere Felder werden uebersprungen. `subject` landet nur im Body und setzt den Mail-Betreff nicht (bleibt `Kontaktformular: {name}`). Andere `$_POST`-Keys werden ignoriert.

### Spamschutz

- **Honeypot:** verstecktes Feld `url`. Befuellt -> stiller Drop (`303`), keine Mail.
- **Rate-Limit:** max. 5 Versandversuche pro IP (IPv6 je /64-Netz) und 60-Minuten-Fenster. Der Slot wird nach Honeypot und Validierung unter einer Dateisperre reserviert, bevor die Mail rausgeht; gleichzeitige Anfragen koennen das Limit so nicht gemeinsam unterlaufen. Scheitert der Versand, wird der Slot wieder frei. State liegt unter `content/cache/contact-form/ratelimit/<hash>.json` (gehashte IP, wegwerfbar). Bei Ueberschreitung `429`.

## Shortcodes

```html
<div data-plugin="contact-form" data-view="form"></div>
```

Mit explizitem Empfaenger:

```html
<div data-plugin="contact-form" data-view="form" data-recipient="office@example.com"></div>
```

| Attribut | Bedeutung |
|---|---|
| `recipient` | Optionaler Empfaenger. Wird serverseitig signiert, bevor das Formular ausgegeben wird. |

## Frontend einbinden

Den Shortcode-Marker in eine Seite unter `public/site/` setzen. Der Router ersetzt ihn bei aktiven Plugins durch das Formular mit der CSS-Klasse `contact-form` -- inklusive Honeypot-Feld und der Registry-Felder.

Custom-Formulare (eigenes Markup statt Shortcode) posten die Zusatzfelder direkt unter ihren Registry-Namen (`company`, `phone`, `telegram`, `subject`) und sollten das Honeypot-Feld `url` mitschicken (off-screen, `autocomplete=off`, `tabindex=-1`, `aria-hidden`).

## Bekannte Einschraenkungen

- Kein Captcha (externer Dienst + Keys) -- erst, wenn Honeypot + Rate-Limit nachweislich nicht reichen.
- Rate-Limit nutzt `REMOTE_ADDR`. Hinter Cloudflare/Proxy ist das die Proxy-IP, das Limit greift dann global statt pro Besucher. `X-Forwarded-For` wird bewusst nicht vertraut (spoofbar).
- Rate-Limit-State liegt in `content/cache/` und ist nicht persistent -- beim Leeren des Caches wird das Fenster zurueckgesetzt. Dateien, die eine Stunde nicht geschrieben wurden, loescht `contact_form_rate_prune()` gelegentlich (etwa jede 50. Reservierung).
- Betreff ist nicht vom Client steuerbar (Header-Injection-Schutz); `subject` ist nur ein Body-Feld.
- Nur Textmails, keine Attachments.
- Erfolg fuehrt zurueck zur Referrer-Seite.

## Changelog

- **2026-10-28** -- Name, Nachricht und Zusatzfelder kommen wörtlich in die Mail (kein `strip_tags` mehr, „Ich <3“ und „a < b“ bleiben); die Mail ist `text/plain`. Mailtext baut `contact_form_mail()`.
- **2026-10-28** -- Antworttexte von `submit.php` stehen in `CONTACT_FORM_TEXT` (falsche Methode: `API_TEXT['method']`, jetzt deutsch). Betreff kuerzt den Namen per `mb_substr` (kein halbierter Umlaut). Rate-Limit-Dateien, die eine Stunde nicht geschrieben wurden, raeumt etwa jede 50. Reservierung weg.
- **2026-10-28** -- Rate-Limit reserviert den Slot unter `flock` vor dem Versand (`contact_form_rate_reserve()`, bei Versandfehler `contact_form_rate_release()`), parallele Anfragen kommen nicht mehr ueber 5 pro Stunde.
- **2026-10-13 -- v1.2.1** -- Empfaenger-Signatur und Rate-Limit-Hash per HMAC mit dem Installations-Schluessel (`app_secret()`) statt mit Pfad + Admin-Passwort (war faelschbar).
- **2026-05-23 -- v1.2.0** -- Spamschutz im Plugin: Honeypot-Feld `url` (stiller `303`-Drop) und datei-basiertes IP-Rate-Limit (max. 5 / 60 Min, gehashter State unter `content/cache/`, `429` bei Ueberschreitung). Konfigurierbare Zusatzfelder ueber die Whitelist `contact_form_extra_fields()` (`company`, `phone`, `telegram`, `subject`) -- bereinigt, auf 200 Zeichen gekuerzt, mit Label in den Mailtext. `subject` bleibt ein Body-Feld. Renderer gibt Honeypot- und Registry-Felder aus. Kein Core-Eingriff am Mailer.
- **2026-05-21 -- v1.1.0** -- Versand auf den zentralen Core-Mailer umgestellt. SMTP wird global in den Einstellungen verwaltet; ohne SMTP bleibt PHP `mail()` als Fallback.
- **2026-05-20 -- v1.0.0** -- Erstes Release mit Shortcode-Formular und `mail()`-Versand.
