<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../lib.php';

require_plugin_active('contact-form');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo API_TEXT['method'];
    return;
}

// Honeypot: Treffer sehen aus wie Erfolg (303 auf Referer), damit Bots den
// Mechanismus nicht erkennen. Kein Mailversand.
if (contact_form_honeypot_tripped()) {
    contact_form_submit_redirect();
    return;
}

// Rate-Limit nach Honeypot, vor Validierung. Nur Pruefung -- den Slot reserviert
// contact_form_rate_reserve() unter Sperre direkt vor dem Versand (siehe unten).
if (!contact_form_rate_check()) {
    contact_form_fail(429, 'zu-viele');
    return;
}

// Reiner Text wörtlich (kein strip_tags, „Ich <3“ bleibt); die Mail ist text/plain.
$name = core_mail_clean_header((string) ($_POST['name'] ?? ''));
$email = trim((string) ($_POST['email'] ?? ''));
$message = contact_form_message_text((string) ($_POST['message'] ?? ''));
$recipient = trim((string) ($_POST['recipient'] ?? ''));
$signature = trim((string) ($_POST['recipient_sig'] ?? ''));

if ($name === '' || $email === '' || $message === '') {
    contact_form_fail(400, 'fehlende-felder');
    return;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    contact_form_fail(400, 'ungueltige-email');
    return;
}

$recipient = contact_form_verified_recipient($recipient, $signature);
if ($recipient === '') {
    contact_form_fail(500, 'kein-empfaenger');
    return;
}

// Betreff fest, Body nur aus Name, E-Mail, Whitelist-Feldern und Nachricht (contact_form_mail).
$mail = contact_form_mail($name, $email, $message, $_POST);

// Slot vor dem Versand reservieren: parallele Anfragen sehen ihn sofort.
$slot = contact_form_rate_reserve();
if ($slot === null) {
    contact_form_fail(429, 'zu-viele');
    return;
}

try {
    core_mail_send([
        'to' => $recipient,
        'subject' => $mail['subject'],
        'text' => $mail['text'],
        'replyTo' => $email,
    ]);
} catch (Throwable $e) {
    error_log('contact-form mail failed: ' . $e->getMessage());
    // Gescheiterter Versand zaehlt nicht.
    contact_form_rate_release($slot);
    contact_form_fail(500, 'versand');
    return;
}

contact_form_submit_redirect();
