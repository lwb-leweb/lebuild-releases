<?php
declare(strict_types=1);

require_once __DIR__ . '/plugins.php';
require_once __DIR__ . '/markup.php';

function render_shortcodes_in_html(string $html): string
{
    if (stripos($html, 'data-plugin') === false) {
        return $html;
    }

    $state = load_plugins_state();
    $active = array_flip($state['active']);
    $pattern = '/<(?P<tag>div|span|section|article|aside)\b(?P<attrs>[^>]*\bdata-plugin\s*=\s*["\'][a-z][a-z0-9_-]*["\'][^>]*)>(?P<body>.*?)<\/\1>/is';

    return preg_replace_callback($pattern, static function (array $match) use ($active): string {
        $tag = strtolower($match['tag']);
        $attrsText = $match['attrs'];
        // Nur echte Attribute zählen, kein Text in einem anderen Wert (class="data-plugin='…'" aus einem Textfeld).
        $attrs = shortcode_data_attrs($tag, $attrsText);
        $name = $attrs['plugin'] ?? null;

        if ($name === null || !plugin_name_valid($name)) {
            return $match[0];
        }

        if (!isset($active[$name])) {
            return '<' . $tag . $attrsText . '></' . $tag . '>';
        }

        $view = $attrs['view'] ?? null;
        if ($view === null || !preg_match('/^[a-z0-9_-]+$/', $view)) {
            return '<' . $tag . $attrsText . '><!-- plugin ' . htmlspecialchars($name, ENT_QUOTES) . ': data-view missing --></' . $tag . '>';
        }

        try {
            $manifest = plugin_manifest($name);
        } catch (Throwable $e) {
            return '<' . $tag . $attrsText . '><!-- plugin ' . htmlspecialchars($name, ENT_QUOTES) . ': manifest invalid --></' . $tag . '>';
        }

        $shortcode = $manifest['shortcodes'][$view] ?? null;
        if (!is_array($shortcode) || empty($shortcode['renderer']) || !is_string($shortcode['renderer'])) {
            return '<' . $tag . $attrsText . '><!-- plugin ' . htmlspecialchars($name, ENT_QUOTES) . ': view not registered --></' . $tag . '>';
        }

        try {
            $rendererPath = plugin_path($name, $shortcode['renderer']);
        } catch (Throwable $e) {
            return '<' . $tag . $attrsText . '><!-- plugin ' . htmlspecialchars($name, ENT_QUOTES) . ': renderer path invalid --></' . $tag . '>';
        }

        if (!is_file($rendererPath)) {
            return '<' . $tag . $attrsText . '><!-- plugin ' . htmlspecialchars($name, ENT_QUOTES) . ': renderer missing --></' . $tag . '>';
        }

        unset($attrs['plugin'], $attrs['view']);

        // $hostAttrs: fertig escapte Attribute (z. B. le_list_attrs()), die der Renderer an dieses Element
        // hängt, wenn er selbst kein umschließendes Element ausgibt (Karten direkt im Grid der Website).
        $hostAttrs = '';
        ob_start();
        try {
            (static function (string $__rendererPath, array $attrs, string &$hostAttrs): void {
                require $__rendererPath;
            })($rendererPath, $attrs, $hostAttrs);
        } catch (Throwable $e) {
            ob_end_clean();
            return '<' . $tag . $attrsText . '><!-- plugin ' . htmlspecialchars($name, ENT_QUOTES) . ': renderer error --></' . $tag . '>';
        }
        $rendered = (string) ob_get_clean();

        return '<' . $tag . $attrsText . ($hostAttrs !== '' ? ' ' . $hostAttrs : '') . '>' . $rendered . '</' . $tag . '>';
    }, $html) ?? $html;
}

/**
 * data-*-Attribute des Start-Tags (Name ohne „data-“, klein, Entities aufgelöst), gelesen über markup_parse: nur echte
 * Attribute, nie Text in einem anderen Attributwert. Doppelte Namen: das erste gilt wie im Browser; Attribute ohne Wert
 * fehlen.
 */
function shortcode_data_attrs(string $tag, string $attrsText): array
{
    $doc = markup_parse('<' . $tag . $attrsText . '>');
    $node = $doc['nodes'][$doc['roots'][0] ?? -1] ?? null;
    if (!is_array($node) || $node['type'] !== 'element') {
        return [];
    }
    $attrs = [];
    foreach ($node['attrs'] as $attr) {
        $name = strtolower($attr['name']);
        // Ohne Wert (data-recipient allein) fehlt das Attribut wie bisher, der Renderer nimmt seine Vorgabe.
        if (str_starts_with($name, 'data-') && strlen($name) > 5 && !array_key_exists(substr($name, 5), $attrs)) {
            $attrs[substr($name, 5)] = $attr['value'] === null ? null : markup_attr_text($node, $attr['name']);
        }
    }
    return array_filter($attrs, static fn (?string $value): bool => $value !== null);
}
