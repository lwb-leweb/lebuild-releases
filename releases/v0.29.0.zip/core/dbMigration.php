<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/plugins.php';

// Umzug der Plugin-Daten zwischen SQLite und MySQL. Beide Richtungen nutzen
// denselben Kopier-Ablauf; erst bei gleichen Zeilenzahlen wechselt der Treiber,
// die Altdaten wandern nach content/db-archiv/.

const DB_MIGRATION_BATCH = 500;
// Höchstzahl Platzhalter je INSERT (ältere SQLite-Versionen erlauben 999).
const DB_MIGRATION_MAX_PLACEHOLDERS = 999;
const DB_ARCHIVE_REMIND_DAYS = 30;
const DB_ARCHIVE_STAMP = 'Ymd-His';
// Archiv-Dateinamen je Art; %s ist der Zeitstempel.
const DB_ARCHIVE_FILES = [
    DB_DRIVER_MYSQL  => 'db.config.mysql-%s.php',
    DB_DRIVER_SQLITE => DB_SQLITE_FILE . '-%s',
];
// Eine vorhandene site.sqlite ohne Plugin-Tabellen liegt während des Umzugs
// hier und kommt bei einem Abbruch zurück.
const DB_SQLITE_ASIDE_SUFFIX = '-vor-umzug';
// Name der kurzlebigen Tabelle, an der db_mysql_same_database() dieselbe Datenbank erkennt.
const DB_MYSQL_PROBE_PREFIX = 'wle_probe_';
// Meldungen des Umzugs und der Altdaten an den Browser. %s sind Tabellen- und Dateinamen bzw. ein
// Grund aus DB_TEXT oder einer DbMigrationException (db_error_text); Rohtexte nur im Fehlerprotokoll.
const DB_MIGRATION_TEXT = [
    'notStarted' => 'Umzug nicht gestartet',
    'configNotSaved' => 'Zugangsdaten nicht gespeichert',
    'deleteFailed' => 'Altdaten nicht gelöscht',
    // %1$s: einer der drei Texte oben, %2$s: Grund.
    'lockUnavailable' => '%1$s: %2$s.',
    'targetNotEmpty' => 'Die Zieldatenbank enthält schon Plugin-Tabellen (%s). Umzug abgebrochen, nichts verändert.',
    'sqliteActive' => 'SQLite ist schon aktiv.',
    'mysqlActive' => 'MySQL ist schon aktiv.',
    'sourceUnreachable' => 'Verbindung zur MySQL-Datenbank fehlgeschlagen: %s.',
    'targetUnreachable' => 'Verbindung fehlgeschlagen: %s. SQLite bleibt aktiv.',
    'abortedMysql' => 'Umzug abgebrochen: %s. MySQL bleibt aktiv.',
    'abortedSqlite' => 'Umzug abgebrochen: %s. SQLite bleibt aktiv.',
    'migrationRequired' => 'Plugin-Daten liegen schon in SQLite. Zu MySQL wechseln über Einstellungen → Datenbank → „Nach MySQL umziehen“.',
    'saveFailed' => 'Zugangsdaten nicht gespeichert: %s.',
    'archiveNotFound' => 'Archiv-Eintrag nicht gefunden.',
    'archiveDbFailed' => 'Die Tabellen in der MySQL-Datenbank ließen sich nicht löschen: %s. Die Zugangsdaten bleiben im Archiv.',
    'archiveDeleteFailed' => 'Altdaten nicht gelöscht: %s.',
    'symlinkKept' => 'Die MySQL-Zugangsdaten lagen über einen Symlink in %s. Diese Datei wurde nicht verändert, bitte von Hand löschen.',
    'sqliteNotArchived' => 'MySQL ist aktiv, aber die SQLite-Datei %s ließ sich nicht ins Archiv verschieben. Bitte von Hand löschen, sonst scheitert ein späterer Umzug zurück nach SQLite.',
    // Gründe (DbMigrationException), stehen in den Texten oben für %s.
    'invalidColumn' => 'ungültiger Spaltenname in %s: %s',
    'noIdColumn' => 'Tabelle %s hat keine Spalte id',
    'rowCount' => 'Zeilenzahl in %s weicht ab (%d statt %d)',
    'configUnreadable' => 'db.config.php ließ sich nicht lesen',
    'configNotArchived' => '%s ließ sich nicht ins Archiv verschieben',
    'sqliteAside' => 'die vorhandene site.sqlite ließ sich nicht beiseitelegen',
    'sqliteBusy' => 'die SQLite-Datei ist noch in Benutzung, bitte später erneut versuchen',
    'fileNotDeleted' => '%s ließ sich nicht löschen',
];

/** Tabellen aller installierten Plugins (auch deaktivierte behalten Daten). */
function db_migration_plugins(): array
{
    $plugins = [];
    foreach (load_plugins_state()['installed'] as $name => $meta) {
        if (!empty($meta['tables'])) {
            $plugins[$name] = $meta['tables'];
        }
    }
    return $plugins;
}

/** Fehlt einem Plugin die Schema-Datei des Ziels? */
function db_migration_check_schemas(string $driver, array $plugins): ?array
{
    foreach (array_keys($plugins) as $name) {
        if (!is_file(plugin_sql_path($name, 'install', $driver))) {
            return db_migration_error('schema_missing', plugin_schema_missing_message($name, $driver));
        }
    }
    return null;
}

/** Enthält das Ziel schon eine Plugin-Tabelle? */
function db_migration_check_tables(PDO $to, array $plugins): ?array
{
    $found = [];
    foreach ($plugins as $tables) {
        foreach ($tables as $table) {
            if (db_table_exists($to, $table)) {
                $found[] = $table;
            }
        }
    }
    if ($found) {
        return db_migration_error('target_not_empty', sprintf(DB_MIGRATION_TEXT['targetNotEmpty'], implode(', ', $found)));
    }
    return null;
}

/** Nächste freie id: höchste id + 1, aber nie unter dem Zähler der Tabelle. */
function db_next_id(PDO $pdo, string $driver, string $table): int
{
    $next = (int) $pdo->query("SELECT MAX(id) FROM `{$table}`")->fetchColumn() + 1;
    if ($driver === DB_DRIVER_SQLITE) {
        // sqlite_sequence gibt es nur, sobald eine Tabelle AUTOINCREMENT nutzt.
        if (!db_table_exists($pdo, 'sqlite_sequence')) {
            return $next;
        }
        $stmt = $pdo->prepare('SELECT seq FROM sqlite_sequence WHERE name = ?');
        $stmt->execute([$table]);
        return max($next, (int) $stmt->fetchColumn() + 1);
    }
    // MySQL 8 liefert sonst bis zu 24 h alte Zählerstände; MariaDB kennt die Variable nicht.
    try {
        $pdo->exec('SET SESSION information_schema_stats_expiry = 0');
    } catch (Throwable $e) {
    }
    $stmt = $pdo->prepare('SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?');
    $stmt->execute([$table]);
    return max($next, (int) $stmt->fetchColumn());
}

function db_set_next_id(PDO $pdo, string $driver, string $table, int $next): void
{
    if ($driver === DB_DRIVER_MYSQL) {
        $pdo->exec("ALTER TABLE `{$table}` AUTO_INCREMENT = {$next}");
        return;
    }
    if (!db_table_exists($pdo, 'sqlite_sequence')) {
        return;
    }
    $stmt = $pdo->prepare('UPDATE sqlite_sequence SET seq = ? WHERE name = ?');
    $stmt->execute([$next - 1, $table]);
    if ($stmt->rowCount() === 0) {
        $pdo->prepare('INSERT INTO sqlite_sequence (name, seq) VALUES (?, ?)')->execute([$table, $next - 1]);
    }
}

/**
 * Plugin-Tabellen im Ziel anlegen und Zeilen samt id blockweise kopieren,
 * Zeilenzahlen vergleichen und den id-Zähler übernehmen. $created sammelt
 * angelegte Tabellen (auch bei Fehler), der Aufrufer räumt sie bei Abbruch
 * weg. Liefert [Tabelle => Zeilenzahl].
 */
function db_migration_copy(PDO $from, PDO $to, array $plugins, array &$created): array
{
    // PDO-Treibernamen entsprechen DB_DRIVER_MYSQL / DB_DRIVER_SQLITE.
    $fromDriver = (string) $from->getAttribute(PDO::ATTR_DRIVER_NAME);
    $toDriver = (string) $to->getAttribute(PDO::ATTR_DRIVER_NAME);
    $counts = [];
    foreach ($plugins as $name => $tables) {
        // Scheitert die Schema-Datei, räumt db_run_schema ihre Tabellen selbst weg.
        db_run_schema($to, $toDriver, (string) file_get_contents(plugin_sql_path($name, 'install', $toDriver)), $tables);
        array_push($created, ...$tables);
        db_migration_lock_note(['tables' => $created]);

        foreach ($tables as $table) {
            $counts[$table] = db_migration_copy_table($from, $to, $table);
            db_set_next_id($to, $toDriver, $table, db_next_id($from, $fromDriver, $table));
        }
    }
    return $counts;
}

/** Spalten einer Plugin-Tabelle; Namen geprüft, Spalte id muss es geben. */
function db_migration_columns(PDO $pdo, string $table): array
{
    $columns = db_pdo_columns($pdo, $table);
    foreach ($columns as $column) {
        if (!plugin_table_name_valid($column)) {
            throw new DbMigrationException(sprintf(DB_MIGRATION_TEXT['invalidColumn'], $table, $column));
        }
    }
    if (!in_array('id', $columns, true)) {
        throw new DbMigrationException(sprintf(DB_MIGRATION_TEXT['noIdColumn'], $table));
    }
    return $columns;
}

/**
 * Zeilen blockweise nach id (Keyset-Paging, je Block bis DB_MIGRATION_BATCH
 * Zeilen als Listen in der Reihenfolge von $columns). Für Umzug und Sicherung.
 */
function db_migration_batches(PDO $pdo, string $table, array $columns): Generator
{
    $idIndex = array_search('id', $columns, true);
    $list = '`' . implode('`, `', $columns) . '`';
    $first = $pdo->prepare("SELECT {$list} FROM `{$table}` ORDER BY id LIMIT " . DB_MIGRATION_BATCH);
    $next = $pdo->prepare("SELECT {$list} FROM `{$table}` WHERE id > ? ORDER BY id LIMIT " . DB_MIGRATION_BATCH);
    $lastId = null;
    do {
        $select = $lastId === null ? $first : $next;
        $select->execute($lastId === null ? [] : [$lastId]);
        $rows = $select->fetchAll(PDO::FETCH_NUM);
        if (!$rows) {
            return;
        }
        yield $rows;
        $lastId = $rows[count($rows) - 1][$idIndex];
    } while (count($rows) === DB_MIGRATION_BATCH);
}

/**
 * Funktion, die einen Block Zeilen (Listen in der Reihenfolge von $columns,
 * vorher mit db_migration_columns() geholt) in einer Transaktion einfügt,
 * mehrere je INSERT. Für Umzug und Einspielen einer Sicherung.
 */
function db_migration_inserter(PDO $to, string $table, array $columns): Closure
{
    $list = '`' . implode('`, `', $columns) . '`';
    // Mehrere Zeilen je INSERT; Statements je Zeilenzahl wiederverwenden.
    $rowsPerInsert = max(1, min(DB_MIGRATION_BATCH, intdiv(DB_MIGRATION_MAX_PLACEHOLDERS, count($columns))));
    $placeholders = '(' . implode(', ', array_fill(0, count($columns), '?')) . ')';
    $inserts = [];

    return static function (array $rows) use ($to, $table, $list, $rowsPerInsert, $placeholders, &$inserts): void {
        $to->beginTransaction();
        try {
            foreach (array_chunk($rows, $rowsPerInsert) as $chunk) {
                $n = count($chunk);
                $inserts[$n] = $inserts[$n] ?? $to->prepare("INSERT INTO `{$table}` ({$list}) VALUES " . implode(', ', array_fill(0, $n, $placeholders)));
                $inserts[$n]->execute(array_merge(...$chunk));
            }
            $to->commit();
        } catch (Throwable $e) {
            $to->rollBack();
            throw $e;
        }
    };
}

function db_migration_copy_table(PDO $from, PDO $to, string $table): int
{
    $columns = db_migration_columns($from, $table);
    $insert = db_migration_inserter($to, $table, $columns);
    foreach (db_migration_batches($from, $table, $columns) as $rows) {
        $insert($rows);
    }

    $source = (int) $from->query("SELECT COUNT(*) FROM `{$table}`")->fetchColumn();
    $target = (int) $to->query("SELECT COUNT(*) FROM `{$table}`")->fetchColumn();
    if ($source !== $target) {
        throw new DbMigrationException(sprintf(DB_MIGRATION_TEXT['rowCount'], $table, $target, $source));
    }
    return $target;
}

/** Kennung einer MySQL-Datenbank in den Notizen. */
function db_migration_mysql_ident(array $config): array
{
    return ['host' => (string) $config['host'], 'port' => (int) $config['port'], 'name' => (string) $config['name']];
}

/**
 * Reste-Notizen über die gerade aktive Datenbank bzw. SQLite-Datei verwerfen:
 * Was dort liegt, sind echte Daten, keine Reste. Eine bei SQLite beiseitegelegte
 * Datei ist dann überholt und fällt weg. Liefert die übrigen Reste.
 */
function db_migration_lock_forget_active(): array
{
    $driver = db_driver();
    $config = $driver === DB_DRIVER_MYSQL ? db_load_config() : null;
    $active = $config ? db_migration_mysql_ident($config) : null;
    $stale = [];
    foreach (db_migration_lock_read()['stale'] ?? [] as $note) {
        if (($note['target'] ?? '') !== $driver || ($driver === DB_DRIVER_MYSQL && ($note['mysql'] ?? null) !== $active)) {
            $stale[] = $note;
        } elseif (!empty($note['aside'])) {
            db_sqlite_remove(db_sqlite_path() . DB_SQLITE_ASIDE_SUFFIX);
        }
    }
    db_migration_lock_keep_stale($stale);
    return $stale;
}

/**
 * Lock holen. Liefert ['stale' => Reste abgebrochener Läufe] oder ein
 * Fehler-Array (anderer Umzug läuft, Sperrdatei nicht anlegbar).
 */
function db_migration_start(string $target, string $failed = DB_MIGRATION_TEXT['notStarted']): array
{
    try {
        $stale = db_migration_lock_acquire($target);
    } catch (RuntimeException $e) {
        return db_migration_error('lock_unavailable', sprintf(DB_MIGRATION_TEXT['lockUnavailable'], $failed, db_error_text('db migration lock', $e)));
    }
    return $stale === null ? db_migration_error('migration_running', DB_MIGRATION_RUNNING_MESSAGE) : ['stale' => $stale];
}

function db_archive_path(string $kind): string
{
    return DB_ARCHIVE_ROOT . '/' . sprintf(DB_ARCHIVE_FILES[$kind], date(DB_ARCHIVE_STAMP));
}

/**
 * MySQL-Config ins Archiv, samt der kopierten Tabellen ('tables'), damit das
 * Löschen der Altdaten sie in MySQL droppen kann. Liegt die Config als Symlink
 * (E1 lässt solche am alten Ort), wird der Link entfernt und das Linkziel
 * bleibt unangetastet; dann kommt ein Hinweis zurück.
 */
function db_archive_config(string $archive, array $tables): ?string
{
    $path = db_config_path();
    $config = db_load_config();
    if ($config === null) {
        throw new DbMigrationException(DB_MIGRATION_TEXT['configUnreadable']);
    }
    $real = is_link($path) ? (string) realpath($path) : null;
    db_save_config(['tables' => $tables] + $config, $archive);
    if (!@unlink($path)) {
        @unlink($archive);
        throw new DbMigrationException(sprintf(DB_MIGRATION_TEXT['configNotArchived'], basename($path)));
    }
    return $real === null ? null : sprintf(DB_MIGRATION_TEXT['symlinkKept'], $real);
}

/**
 * MySQL → SQLite. $source nur für Tests (Quelle statt der MySQL-Verbindung);
 * der Endpunkt ruft ohne Argument.
 */
function db_migrate_to_sqlite(?PDO $source = null): array
{
    if (!extension_loaded('pdo_sqlite')) {
        return db_migration_error('database_required', DB_SQLITE_MISSING_MESSAGE);
    }
    $start = db_migration_start(DB_DRIVER_SQLITE);
    if (isset($start['ok'])) {
        return $start;
    }

    $path = db_sqlite_path();
    $aside = $path . DB_SQLITE_ASIDE_SUFFIX;
    $target = null;
    $createdFile = false;
    $movedAside = false;
    try {
        // Erst unter dem Lock prüfen: ein Lauf kurz davor kann schon umgezogen sein.
        if (db_driver() === DB_DRIVER_SQLITE) {
            return db_migration_error('already_active', DB_MIGRATION_TEXT['sqliteActive']);
        }
        $stale = db_migration_lock_forget_active();
        // Reste abgebrochener Läufe: erst halbe Dateien weg, dann beiseitegelegte
        // Dateien zurück (unabhängig davon, ob schon eine Datei angelegt war).
        $mine = array_filter($stale, static fn (array $note): bool => ($note['target'] ?? '') === DB_DRIVER_SQLITE);
        foreach ($mine as $note) {
            if (!empty($note['sqliteCreated'])) {
                db_sqlite_remove($path);
            }
        }
        foreach ($mine as $note) {
            if (!empty($note['aside']) && is_file($aside) && !is_file($path)) {
                rename($aside, $path);
            }
        }
        db_migration_lock_keep_stale(array_values(array_diff_key($stale, $mine)));

        $plugins = db_migration_plugins();
        if ($error = db_migration_check_schemas(DB_DRIVER_SQLITE, $plugins)) {
            return $error;
        }
        if (is_file($path)) {
            // Lässt sich die Datei nicht lesen, bricht der Umzug ab, statt sie zu ersetzen.
            $existing = db_connect_sqlite($path);
            $error = db_migration_check_tables($existing, $plugins);
            $existing = null;
            if ($error) {
                return $error;
            }
        }

        // Schreib-Requests, die die Prüfung knapp vorher passiert haben, zu Ende kommen lassen (sie halten LOCK_SH).
        db_migration_writers_wait();
        try {
            $source = $source ?? db();
        } catch (Throwable $e) {
            return db_migration_error('connection_failed', sprintf(DB_MIGRATION_TEXT['sourceUnreachable'], db_connection_error_text($e)));
        }

        // Eine vorhandene Datei ohne Plugin-Tabellen wird ersetzt; bis zum
        // Erfolg liegt sie beiseite.
        if (is_file($path)) {
            db_migration_lock_note(['aside' => true]);
            if (!@rename($path, $aside)) {
                throw new DbMigrationException(DB_MIGRATION_TEXT['sqliteAside']);
            }
            $movedAside = true;
            db_sqlite_remove($path);
        }
        db_migration_lock_note(['sqliteCreated' => true]);
        $createdFile = true;
        $target = db_connect_sqlite($path);
        $created = [];
        $counts = db_migration_copy($source, $target, $plugins, $created);
        $target = null;

        $archive = db_archive_path(DB_DRIVER_MYSQL);
        ensure_dir(DB_ARCHIVE_ROOT);
        $warning = db_archive_config($archive, array_keys($counts));
        db_migration_lock_forget_created();
        db_migration_lock_forget_active();
        $createdFile = false;
        if ($movedAside) {
            db_sqlite_remove($aside);
            $movedAside = false;
        }
        db_disconnect();

        return ['ok' => true, 'driver' => DB_DRIVER_SQLITE, 'counts' => $counts, 'archive' => basename($archive), 'warning' => $warning];
    } catch (Throwable $e) {
        return db_migration_error('migration_failed', sprintf(DB_MIGRATION_TEXT['abortedMysql'], db_error_text('db migration to sqlite', $e)));
    } finally {
        if ($createdFile) {
            $target = null;
            db_sqlite_remove($path);
        }
        if ($movedAside) {
            @rename($aside, $path);
        }
        db_migration_lock_release();
    }
}

/** Hinweis, wenn die SQLite-Datei nach dem Umzug zu MySQL nicht ins Archiv kam; Pfad relativ zur Website. */
function le_db_migration_sqlite_not_archived(): string
{
    return sprintf(DB_MIGRATION_TEXT['sqliteNotArchived'], le_instance_relative(db_sqlite_path()));
}

/** SQLite → MySQL mit den eingegebenen Zugangsdaten. */
function db_migrate_to_mysql(array $config): array
{
    $start = db_migration_start(DB_DRIVER_MYSQL);
    if (isset($start['ok'])) {
        return $start;
    }

    $target = null;
    $created = [];
    try {
        if (db_driver() === DB_DRIVER_MYSQL) {
            return db_migration_error('already_active', DB_MIGRATION_TEXT['mysqlActive']);
        }
        $stale = db_migration_lock_forget_active();
        $test = db_test_connection($config);
        if (!$test['ok']) {
            return db_migration_error('connection_failed', sprintf(DB_MIGRATION_TEXT['targetUnreachable'], $test['error']));
        }
        $target = db_connect_mysql($config);

        // Tabellen abgebrochener Läufe in dieselbe Datenbank zuerst droppen;
        // Reste in anderen Datenbanken bleiben vermerkt.
        $ident = db_migration_mysql_ident($config);
        $mine = array_filter($stale, static fn (array $note): bool => ($note['target'] ?? '') === DB_DRIVER_MYSQL && ($note['mysql'] ?? null) === $ident);
        foreach ($mine as $note) {
            db_drop_tables($target, plugin_valid_tables($note['tables'] ?? []));
        }
        db_migration_lock_keep_stale(array_values(array_diff_key($stale, $mine)));
        db_migration_lock_note(['mysql' => $ident]);

        $plugins = db_migration_plugins();
        if ($error = db_migration_check_schemas(DB_DRIVER_MYSQL, $plugins)) {
            return $error;
        }
        if ($error = db_migration_check_tables($target, $plugins)) {
            return $error;
        }

        // Schreib-Requests, die die Prüfung knapp vorher passiert haben, zu Ende kommen lassen (sie halten LOCK_SH).
        db_migration_writers_wait();
        $source = db();
        $counts = db_migration_copy($source, $target, $plugins, $created);

        // WAL in die Hauptdatei schreiben, damit das Archiv eine Datei ist.
        $checkpoint = $source->query('PRAGMA wal_checkpoint(TRUNCATE)')->fetch(PDO::FETCH_NUM);
        if ((int) ($checkpoint[0] ?? 1) !== 0) {
            throw new DbMigrationException(DB_MIGRATION_TEXT['sqliteBusy']);
        }
        $source = null;
        db_disconnect();
        $archive = db_archive_path(DB_DRIVER_SQLITE);
        ensure_dir(DB_ARCHIVE_ROOT);

        // Erst die Config (Treiber wechselt), dann archivieren: so legt kein
        // Leser zwischendurch eine leere site.sqlite an.
        db_save_config($config);
        db_migration_lock_forget_created();
        db_migration_lock_forget_active();
        $created = [];

        $result = ['ok' => true, 'driver' => DB_DRIVER_MYSQL, 'counts' => $counts, 'archive' => basename($archive), 'warning' => null];
        if (@rename(db_sqlite_path(), $archive)) {
            db_sqlite_remove(db_sqlite_path());
        } else {
            $result['archive'] = null;
            $result['warning'] = le_db_migration_sqlite_not_archived();
        }
        return $result;
    } catch (Throwable $e) {
        return db_migration_error('migration_failed', sprintf(DB_MIGRATION_TEXT['abortedSqlite'], db_error_text('db migration to mysql', $e)));
    } finally {
        if ($created && $target) {
            try {
                db_drop_tables($target, $created);
            } catch (Throwable $e) {
                // Aufräumen nach bestem Bemühen; der eigentliche Fehler wird gemeldet.
            }
        }
        db_migration_lock_release();
    }
}

/**
 * Eine neue MySQL-Config schaltet den Treiber um; vorhandene SQLite-Daten
 * blieben zurück. Dafür gibt es den Umzug.
 */
function db_config_change_error(): ?array
{
    if (db_driver() === DB_DRIVER_SQLITE && db_migration_plugins()) {
        return db_migration_error('migration_required', DB_MIGRATION_TEXT['migrationRequired']);
    }
    return null;
}

/**
 * MySQL-Config ohne Umzug setzen (DB-Einrichtung). Unter dem Lock, damit kein
 * Umzug dazwischenkommt; Reste-Notizen über die neue Datenbank fallen weg.
 */
function db_save_config_locked(array $config): array
{
    $start = db_migration_start(DB_DRIVER_MYSQL, DB_MIGRATION_TEXT['configNotSaved']);
    if (isset($start['ok'])) {
        return $start;
    }
    try {
        // Erst unter dem Lock prüfen: ein Umzug kurz davor kann schon nach SQLite gewechselt haben.
        if ($error = db_config_change_error()) {
            return $error;
        }
        db_save_config($config);
        db_migration_lock_forget_active();
        return ['ok' => true];
    } catch (Throwable $e) {
        return db_migration_error('save_failed', sprintf(DB_MIGRATION_TEXT['saveFailed'], db_error_text('db config save', $e)));
    } finally {
        db_migration_lock_release();
    }
}

/** Archiv-Einträge (nur Namen nach Muster), neueste zuerst. */
function db_archive_entries(): array
{
    $entries = [];
    foreach (is_dir(DB_ARCHIVE_ROOT) ? (scandir(DB_ARCHIVE_ROOT) ?: []) : [] as $name) {
        foreach (DB_ARCHIVE_FILES as $kind => $format) {
            $pattern = '/^' . str_replace('%s', '(\d{8}-\d{6})', preg_quote($format, '/')) . '$/';
            if (!preg_match($pattern, $name, $m) || !is_file(DB_ARCHIVE_ROOT . '/' . $name)) {
                continue;
            }
            $created = DateTime::createFromFormat('!' . DB_ARCHIVE_STAMP, $m[1]);
            if ($created === false || $created->format(DB_ARCHIVE_STAMP) !== $m[1]) {
                continue;
            }
            $entries[] = [
                'name' => $name,
                'kind' => $kind,
                'createdAt' => $created->format(DB_DATETIME_FORMAT),
                'due' => $created->getTimestamp() < time() - DB_ARCHIVE_REMIND_DAYS * 86400,
            ];
        }
    }
    usort($entries, static fn (array $a, array $b): int => strcmp($b['createdAt'], $a['createdAt']));
    return $entries;
}

/**
 * Löscht einen Archiv-Eintrag; nur Namen aus dem Verzeichnis-Listing. Bei
 * MySQL-Zugangsdaten fallen vorher die beim Umzug kopierten Tabellen in jener
 * Datenbank weg. Scheitert das (z. B. nicht erreichbar), bleibt die Datei,
 * außer mit $force: dann nur die Datei, die Tabellen bleiben.
 * Unter dem Umzugs-Lock, damit kein Umzug in dieselbe Datenbank dazwischenkommt.
 */
function db_archive_delete(string $name, bool $force = false): array
{
    $start = db_migration_start(db_driver(), DB_MIGRATION_TEXT['deleteFailed']);
    if (isset($start['ok'])) {
        return $start;
    }
    try {
        $kinds = array_column(db_archive_entries(), 'kind', 'name');
        if (!isset($kinds[$name])) {
            return db_migration_error('not_found', DB_MIGRATION_TEXT['archiveNotFound']);
        }
        $path = DB_ARCHIVE_ROOT . '/' . $name;
        if ($kinds[$name] === DB_DRIVER_MYSQL && !$force) {
            try {
                db_archive_drop_tables($path);
            } catch (Throwable $e) {
                return db_migration_error('archive_db_failed', sprintf(DB_MIGRATION_TEXT['archiveDbFailed'], $e instanceof PDOException ? db_connection_error_text($e) : db_error_text('db archive drop tables', $e)));
            }
        }
        if (!@unlink($path)) {
            throw new DbMigrationException(sprintf(DB_MIGRATION_TEXT['fileNotDeleted'], $name));
        }
        return ['ok' => true];
    } catch (Throwable $e) {
        return db_migration_error('delete_failed', sprintf(DB_MIGRATION_TEXT['archiveDeleteFailed'], db_error_text('db archive delete', $e)));
    } finally {
        db_migration_lock_release();
    }
}

/**
 * Die im Archiv vermerkten Tabellen in der archivierten MySQL-Datenbank
 * droppen. Ist es die gerade aktive Datenbank (später dorthin zurückgezogen),
 * sind die installierten Tabellen die aktiven Daten und bleiben; nur nicht
 * mehr installierte fallen weg.
 */
function db_archive_drop_tables(string $path): void
{
    $config = require $path;
    $tables = plugin_valid_tables(is_array($config) ? ($config['tables'] ?? []) : []);
    if (!$tables) {
        return;
    }
    $pdo = db_connect_mysql($config);
    if (db_driver() === DB_DRIVER_MYSQL && db_mysql_same_database($pdo, db())) {
        $tables = array_diff($tables, array_merge([], ...array_values(db_migration_plugins())));
    }
    db_drop_tables($pdo, $tables);
}

/**
 * Zeigen beide Verbindungen auf dieselbe Datenbank? Eine Probe-Tabelle in der
 * aktiven muss über die andere sichtbar sein; das gilt unabhängig von
 * Host-Schreibweise (localhost/127.0.0.1) und Cluster-Knoten.
 */
function db_mysql_same_database(PDO $other, PDO $active): bool
{
    $probe = DB_MYSQL_PROBE_PREFIX . bin2hex(random_bytes(4));
    $active->exec("CREATE TABLE `{$probe}` (id INT PRIMARY KEY)");
    try {
        return db_table_exists($other, $probe);
    } finally {
        db_drop_tables($active, [$probe]);
    }
}

/** Dashboard-Erinnerung: nur für Admins, sobald Altdaten zu lange liegen. */
function db_archive_reminder_for_current_user(): ?string
{
    if (!is_admin() || !in_array(true, array_column(db_archive_entries(), 'due'), true)) {
        return null;
    }
    return 'Altdaten eines Datenbank-Umzugs liegen seit über ' . DB_ARCHIVE_REMIND_DAYS . ' Tagen im Archiv. Prüfen und löschen unter Einstellungen → Datenbank.';
}
