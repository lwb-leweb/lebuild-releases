<?php
declare(strict_types=1);

require_once __DIR__ . '/utils.php';
require_once __DIR__ . '/activity.php';

// Releases liegen öffentlich und signiert in einem eigenen Repo. Der Updater
// braucht deshalb keinen GitHub-Token; die RSA-Signatur (OpenSSL) beweist,
// dass das ZIP aus unserem Release-Workflow stammt.
const UPDATER_FEED_URL = 'https://raw.githubusercontent.com/lwb-leweb/lebuild-releases/main/latest.json';
const UPDATER_OPENSSL_PUBLIC_KEY = <<<'PEM'
-----BEGIN PUBLIC KEY-----
MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAvSlRiP1ClK9aRARTq8UN
fWPBJLSGpezaDw8YpDQMNOGwUmu/jfPGpgCZZ73ohIMxeWgfB/YfYIi4gheWntna
HFFhXEcsvW4Q5AYVDKhbqpDgm4GOcPbFBcNy/4GJbFkI+fxov+9+o1uPIqgP+oN2
2ZW4rNSTVxHxVCeolD7h1XoY4BbpjbJrRQgtEX2dwl4G+LqgpHFqzpVZ/Hu6aqsW
gRWA54oI7pehsxBY3O/h6SMTaCwgELee9exFbozSy+/zviW0Q8TwQrlefLsTaCgN
uImiNyAbGGnM7TbaeGdS+SXASCV8ueS2A89uLrMsNXVUumoWa/K+gXu1+gnElfKN
QBdu62/d6MmWLYgbV3a0UqqOQAncgvA4GWlqyg7I8m5rvv2QhKoY+cGV3PRAlTkW
wDEHp6jncX3whrMoQwx08TFN8ax99mQ0nt5+JT+rhXOe/FJeuRXoPAUUs+xbnn2L
v0m5LlyofLaj4HHhfmPRY6aPG6hVN0kS4vjRgJ6mqPL/JGHRxO9nkOai/MwB6XT+
BX7pVB1O2VpYisFOXD0hgmsfzS86WDL+OK5mfnZUfGDuIjy1HiB++oGUXq0vYs25
52R8aowKgnDg2ISAkvYXcMRz/+Ar2joYSL2swaF3VedGFfLiUV0X2wlpMyJyMsLB
/G56M27Q7aYldkKwaCfc0/UCAwEAAQ==
-----END PUBLIC KEY-----
PEM;
// Meldungen von updater_install(), die api/installUpdate.php an den Browser gibt.
const UPDATER_OPENSSL_MISSING_MESSAGE = 'PHP openssl-Erweiterung fehlt.';
const UPDATER_SIGNATURE_INVALID_MESSAGE = 'Signatur des Updates ungültig.';
// Meldungen an den Browser (Einstellungen → Updates); Details stehen im Update-Log.
const UPDATER_TEXT = [
    'disabled' => 'Updater deaktiviert.',
    'zipMissing' => 'PHP ZipArchive-Erweiterung fehlt.',
    'noUpdate' => 'Kein Update verfügbar (zuerst prüfen).',
    'upToDate' => 'Bereits aktuell.',
    'running' => 'Update läuft bereits.',
    'download' => 'Download fehlgeschlagen.',
    'zipOpen' => 'ZIP konnte nicht geöffnet werden.',
    'zipPaths' => 'ZIP enthält ungültige Pfade.',
    'zipExtract' => 'ZIP konnte nicht entpackt werden.',
    'archiveInvalid' => 'Entpacktes Archiv ungültig.',
    'manifestMissing' => 'Release-Manifest fehlt im Archiv.',
    'manifestUnreadable' => 'Release-Manifest unleserlich.',
    'versionMismatch' => 'Version im Update passt nicht.',
    'needsConfirmation' => 'Update muss bestätigt werden.',
    'noPaths' => 'Keine erlaubten Pfade im Manifest.',
    'noBackup' => 'Kein Backup verfügbar.',
    'busy' => 'Update läuft gerade.',
    'unreachable' => 'Konnte Update-Quelle nicht erreichen.',
    'failed' => 'Update fehlgeschlagen, Details im Update-Log.',
    // %s: verwalteter Pfad wie public/admin (aus release.json, keine Server-Pfade).
    'backupFailed' => 'Backup für %s fehlgeschlagen.',
    'swapFailed' => 'Tausch für %s fehlgeschlagen.',
    'rollbackFailed' => 'Rollback für %s fehlgeschlagen.',
];
const UPDATER_CHECK_INTERVAL_SECONDS = 12 * 60 * 60;
const UPDATER_USER_AGENT = 'lebuild-updater';
// So weit zurück (Bytes vom Ende) prüft updater_log_once() auf Wiederholungen.
const UPDATER_LOG_REPEAT_WINDOW_BYTES = 4096;
// Nur diese Pfade tauscht ein Update; config.php im Hauptordner (Zugang des ersten Admins) gehört nie dazu.
const UPDATER_ALLOWED_MANAGED_PATHS = [
    'api',
    'core',
    'public/admin',
    'plugins',
    'index.php',
    '.htaccess',
];
// plugins/ tauscht der Updater je Plugin-Ordner (Namen wie plugin_name_valid()),
// damit Plugins, die nur auf einer Installation liegen, stehen bleiben.
const UPDATER_PLUGIN_DIR_PATTERN = '/^[a-z][a-z0-9_-]*$/';
// Liste der beim Update getauschten Pfade im Backup, für den Rollback.
const UPDATER_BACKUP_PATHS_FILE = 'paths.json';
// Alte Orte der Zugangsdaten. Seit dem Umzug nach content/config/ (siehe
// updater_config_path()) nur noch für Installationen, die noch nicht
// umgezogen sind; entfällt in einem späteren Release.
const UPDATER_PROTECTED_RELATIVE_PATHS = [
    'core/db.config.php',
    'core/mail.config.php',
];

function updater_feed_url(): string
{
    $env = getenv('LEBUILD_UPDATE_FEED');
    return is_string($env) && $env !== '' ? $env : UPDATER_FEED_URL;
}

function updater_manifest_path(): string
{
    return LE_PROJECT_ROOT . '/core/release.json';
}

function updater_cache_path(): string
{
    return CACHE_ROOT . '/update-cache.json';
}

function updater_backup_root(): string
{
    return CACHE_ROOT . '/update-backup';
}

function updater_tmp_root(): string
{
    return CACHE_ROOT . '/update-tmp';
}

function updater_lock_path(): string
{
    return CACHE_ROOT . '/update-lock';
}

function updater_log_path(): string
{
    return CACHE_ROOT . '/update-log.txt';
}

function updater_log(string $message): void
{
    @file_put_contents(
        updater_log_path(),
        '[' . current_iso_time() . '] ' . $message . PHP_EOL,
        FILE_APPEND
    );
}

/**
 * Wie updater_log(), aber ohne Wiederholung: Steht dieselbe Meldung schon im
 * Ende des Logs, entfällt sie. Für Fehler, die sonst jeder Request meldet.
 */
function updater_log_once(string $message): void
{
    $path = updater_log_path();
    $size = is_file($path) ? (int) filesize($path) : 0;
    $offset = max(0, $size - UPDATER_LOG_REPEAT_WINDOW_BYTES);
    $tail = $size > 0 ? (string) @file_get_contents($path, false, null, $offset) : '';
    if (!str_contains($tail, '] ' . $message . PHP_EOL)) {
        updater_log($message);
    }
}

function updater_config_lock_path(): string
{
    return CACHE_ROOT . '/config-move.lock';
}

/**
 * Pfad einer Zugangsdaten-Datei unter content/config/. Liegt sie noch am alten
 * Ort unter core/, wird sie einmal je Request umgezogen: kopieren, Kopie
 * prüfen, erst dann das Original löschen. Liegt sie an beiden Orten, gilt
 * content/config/. Scheitert der Umzug, bleibt das Original und wird genutzt.
 * Der Umzug läuft unter einer Sperre, damit parallele Requests sich nicht
 * gegenseitig die Kopie oder das Original wegnehmen.
 */
function updater_config_path(string $file): string
{
    static $resolved = [];
    if (isset($resolved[$file])) {
        return $resolved[$file];
    }

    $target = CONFIG_ROOT . '/' . $file;
    $legacy = null;
    foreach (UPDATER_PROTECTED_RELATIVE_PATHS as $relative) {
        if (basename($relative) === $file) {
            $legacy = $relative;
        }
    }
    $legacyPath = LE_PROJECT_ROOT . '/' . ($legacy ?? '');
    // Der alte Ort liegt im Code: Mit eigenem Kundenordner gehört er keinem Kunden und wird nie gelesen.
    if ($legacy === null || le_instance_is_multi() || (!is_file($legacyPath) && !is_link($legacyPath))) {
        return $resolved[$file] = $target;
    }
    // Ein Symlink zeigt meist bewusst aus dem Webroot heraus: nicht umziehen.
    if (is_link($legacyPath)) {
        updater_log_once('config move skipped: ' . $legacy . ' is a symlink');
        return $resolved[$file] = $legacyPath;
    }

    $lock = null;
    try {
        $lock = updater_acquire_lock(updater_config_lock_path(), true);
        if (!$lock) {
            throw new RuntimeException('cannot lock');
        }
        // Ein paralleler Request kann inzwischen umgezogen haben.
        if (!is_file($legacyPath)) {
            return $resolved[$file] = $target;
        }
        $content = @file_get_contents($legacyPath);
        if ($content === false) {
            throw new RuntimeException('cannot read original');
        }

        if (is_file($target)) {
            if (!is_readable($target)) {
                throw new RuntimeException('content/config/' . $file . ' not readable');
            }
            if (file_get_contents($target) !== $content) {
                updater_log('config move: ' . $legacy . ' differs from content/config/, content/config/ wins');
            }
        } else {
            try {
                write_private_file($target, $content);
                if (file_get_contents($target) !== $content || !is_array(require $target)) {
                    throw new RuntimeException('copy differs or is no config array');
                }
            } catch (Throwable $e) {
                // Eigene, fehlerhafte Kopie entfernen: Sie darf beim nächsten
                // Request nicht als „an beiden Orten“ gewinnen.
                @unlink($target);
                throw $e;
            }
        }

        if (!@unlink($legacyPath) && is_file($legacyPath)) {
            updater_log_once('config move: could not delete ' . $legacy);
        }
        return $resolved[$file] = $target;
    } catch (Throwable $e) {
        updater_log_once('config move failed: ' . $legacy . ': ' . $e->getMessage());
        return $resolved[$file] = $legacyPath;
    } finally {
        updater_release_lock($lock);
    }
}

/**
 * Auto-Update an? Aus mit LEBUILD_UPDATES=off und immer mit eigenem Kundenordner (le_instance_is_multi): Dort ist
 * der Code ein Git-Checkout für alle Websites, Updates kommen per Tag (README, „Mehrere Websites auf einem Server“).
 */
function updater_enabled(): bool
{
    if (le_instance_is_multi()) {
        return false;
    }
    $flag = getenv('LEBUILD_UPDATES');
    if ($flag === false || $flag === '') {
        return true;
    }
    return !in_array(strtolower($flag), ['off', '0', 'false', 'no'], true);
}

function updater_read_local_manifest(): array
{
    $path = updater_manifest_path();
    if (!is_file($path)) {
        return [
            'version' => '0.0.0',
            'requiresConfirmation' => false,
            'notes' => '',
            'managedPaths' => UPDATER_ALLOWED_MANAGED_PATHS,
        ];
    }
    $data = json_decode((string) file_get_contents($path), true);
    if (!is_array($data)) {
        return [
            'version' => '0.0.0',
            'requiresConfirmation' => false,
            'notes' => '',
            'managedPaths' => UPDATER_ALLOWED_MANAGED_PATHS,
        ];
    }
    return [
        'version' => (string) ($data['version'] ?? '0.0.0'),
        'requiresConfirmation' => !empty($data['requiresConfirmation']),
        'notes' => (string) ($data['notes'] ?? ''),
        'managedPaths' => is_array($data['managedPaths'] ?? null) ? $data['managedPaths'] : UPDATER_ALLOWED_MANAGED_PATHS,
    ];
}

function updater_load_cache(): array
{
    $defaults = [
        'lastCheck' => null,
        'latestVersion' => null,
        'requiresConfirmation' => false,
        'notes' => '',
        'zipUrl' => '',
        'opensslSignature' => '',
        'tag' => '',
        'lastError' => null,
        'skippedVersion' => null,
        // Version, deren automatische Installation gescheitert ist; bis zur nächsten Feed-Prüfung kein neuer Versuch.
        'failedVersion' => null,
    ];
    $path = updater_cache_path();
    $data = is_file($path) ? json_decode((string) file_get_contents($path), true) : null;

    return is_array($data) ? array_merge($defaults, $data) : $defaults;
}

function updater_save_cache(array $cache): void
{
    // Nur ein Cache: Scheitert das Schreiben, prüft der nächste Request wieder.
    try {
        write_file_atomic(updater_cache_path(), json_encode($cache, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . PHP_EOL);
    } catch (RuntimeException $e) {
    }
}

function updater_http_get(string $url, int $timeout = 15, array $extraHeaders = []): ?string
{
    $headers = ['Accept: application/json'];
    foreach ($extraHeaders as $h) {
        if (is_string($h) && $h !== '') {
            $headers[] = $h;
        }
    }

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_USERAGENT => UPDATER_USER_AGENT,
            CURLOPT_HTTPHEADER => $headers,
        ]);
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($body === false || $code < 200 || $code >= 300) {
            return null;
        }
        return (string) $body;
    }

    $headerLines = "User-Agent: " . UPDATER_USER_AGENT . "\r\n";
    foreach ($headers as $h) {
        $headerLines .= $h . "\r\n";
    }
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'header' => $headerLines,
            'timeout' => $timeout,
            'follow_location' => 1,
        ],
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
        ],
    ]);
    $body = @file_get_contents($url, false, $context);
    return $body === false ? null : $body;
}

function updater_http_download(string $url, string $destPath, int $timeout = 60): bool
{
    ensure_dir(dirname($destPath));

    if (function_exists('curl_init')) {
        $fh = @fopen($destPath, 'wb');
        if (!$fh) {
            return false;
        }
        $opts = [
            CURLOPT_FILE => $fh,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_USERAGENT => UPDATER_USER_AGENT,
        ];
        $ch = curl_init($url);
        curl_setopt_array($ch, $opts);
        $ok = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        fclose($fh);
        if (!$ok || $code < 200 || $code >= 300) {
            @unlink($destPath);
            return false;
        }
        return true;
    }

    $body = updater_http_get($url, $timeout);
    if ($body === null) {
        return false;
    }
    return @file_put_contents($destPath, $body) !== false;
}

function updater_fetch_remote(): ?array
{
    $body = updater_http_get(updater_feed_url());
    $feed = $body !== null ? json_decode($body, true) : null;
    if (!is_array($feed) || empty($feed['version']) || empty($feed['zipUrl'])) {
        return null;
    }

    return [
        'tag' => (string) ($feed['tag'] ?? ('v' . $feed['version'])),
        'version' => (string) $feed['version'],
        'requiresConfirmation' => !empty($feed['requiresConfirmation']),
        'notes' => (string) ($feed['notes'] ?? ''),
        'zipUrl' => (string) $feed['zipUrl'],
        // Fehlt sie, lehnt updater_install() das Update ab (mit Eintrag im Log).
        'opensslSignature' => (string) ($feed['opensslSignature'] ?? ''),
    ];
}

/** $publicKey: PEM; ein anderer als der eigene nur beim Signieren (tools/sign-release.php). */
function updater_signature_valid(string $zipPath, string $signature, string $publicKey = UPDATER_OPENSSL_PUBLIC_KEY): bool
{
    if (!function_exists('openssl_verify')) {
        return false;
    }
    $sig = base64_decode($signature, true);
    $key = @openssl_pkey_get_public($publicKey);
    $data = @file_get_contents($zipPath);
    if ($sig === false || $sig === '' || $key === false || $data === false) {
        return false;
    }

    return openssl_verify($data, $sig, $key, OPENSSL_ALGO_SHA256) === 1;
}

function updater_status(): array
{
    $local = updater_read_local_manifest();
    $cache = updater_load_cache();
    $latest = $cache['latestVersion'];
    // Abgeschaltet gibt es kein Update anzubieten, auch wenn der Cache von früher eine neuere Version kennt.
    $hasUpdate = updater_enabled() && $latest !== null && version_compare($latest, $local['version'], '>');

    return [
        'enabled' => updater_enabled(),
        // Mehrfachbetrieb: Der Code ist ein Checkout für alle Websites, die Verwaltung zeigt nur die Version.
        'multiSite' => le_instance_is_multi(),
        'currentVersion' => $local['version'],
        'latestVersion' => $latest,
        'tag' => $cache['tag'] ?? '',
        'hasUpdate' => $hasUpdate,
        'requiresConfirmation' => !empty($cache['requiresConfirmation']),
        'notes' => $cache['notes'] ?? '',
        'lastCheck' => $cache['lastCheck'] ?? null,
        'lastError' => $cache['lastError'] ?? null,
        'skippedVersion' => $cache['skippedVersion'] ?? null,
        'failedVersion' => $cache['failedVersion'] ?? null,
        // Im Mehrfachbetrieb kein Rollback: Er schriebe den Checkout für alle Websites.
        'rollbackAvailable' => !le_instance_is_multi() && is_dir(updater_backup_root()),
    ];
}

function updater_check(bool $force = false): array
{
    if (!updater_enabled()) {
        return updater_status();
    }

    $cache = updater_load_cache();
    $now = time();
    $last = $cache['lastCheck'] ? strtotime((string) $cache['lastCheck']) : 0;
    if (!$force && $last && ($now - $last) < UPDATER_CHECK_INTERVAL_SECONDS) {
        return updater_status();
    }

    $remote = updater_fetch_remote();
    if ($remote === null) {
        $cache['lastCheck'] = current_iso_time();
        $cache['lastError'] = UPDATER_TEXT['unreachable'];
        updater_save_cache($cache);
        updater_log('check failed: remote unreachable');
        return updater_status();
    }

    $cache = array_merge($cache, [
        'lastCheck' => current_iso_time(),
        'latestVersion' => $remote['version'],
        'requiresConfirmation' => $remote['requiresConfirmation'],
        'notes' => $remote['notes'],
        'zipUrl' => $remote['zipUrl'],
        'opensslSignature' => $remote['opensslSignature'],
        'tag' => $remote['tag'],
        'lastError' => null,
        'failedVersion' => null,
    ]);
    updater_save_cache($cache);
    updater_log(sprintf('check ok: latest=%s tag=%s confirm=%s', $remote['version'], $remote['tag'], $remote['requiresConfirmation'] ? 'yes' : 'no'));

    return updater_status();
}

function updater_should_auto_install(): bool
{
    if (!updater_enabled()) {
        return false;
    }
    $cache = updater_load_cache();
    $local = updater_read_local_manifest();
    if (empty($cache['latestVersion'])) {
        return false;
    }
    if (!empty($cache['requiresConfirmation'])) {
        return false;
    }
    // Nach einem Rollback diese Version nicht gleich wieder automatisch
    // einspielen; manuell installieren geht weiterhin.
    if (($cache['skippedVersion'] ?? null) === $cache['latestVersion']) {
        return false;
    }
    if (($cache['failedVersion'] ?? null) === $cache['latestVersion']) {
        return false;
    }
    return version_compare((string) $cache['latestVersion'], $local['version'], '>');
}

/**
 * Beim Login und beim Laden des Backends (api/login.php, api/bootstrap.php): nach Updates sehen
 * und, wo es ohne Bestätigung geht, gleich einspielen. Liefert ['status' => updater_status()
 * oder null, 'installed' => ['previousVersion', 'newVersion'] oder null]; Fehler nur ins Log
 * ($context nennt den Aufrufer).
 */
function updater_auto_update(string $context): array
{
    $flow = ['status' => null, 'installed' => null];
    try {
        updater_check(false);
        if (updater_should_auto_install()) {
            $version = updater_load_cache()['latestVersion'];
            try {
                $result = updater_install(false);
            } catch (Throwable $e) {
                updater_log($context . ' update install failed: ' . $e->getMessage());
                $result = ['ok' => false, 'error' => UPDATER_TEXT['failed']];
            }
            // Gescheitert (nicht nur belegt oder zur Bestätigung zurückgestellt): einmal melden, bis zur nächsten
            // Feed-Prüfung nicht wieder bei jedem Aufruf herunterladen und tauschen. Gilt nur für die versuchte
            // Version; kennt der Cache inzwischen eine neuere, bleibt die frei.
            if (empty($result['ok']) && !in_array($result['error'] ?? null, [UPDATER_TEXT['running'], UPDATER_TEXT['needsConfirmation']], true)) {
                $cache = updater_load_cache();
                if ($cache['latestVersion'] === $version) {
                    $cache['failedVersion'] = $version;
                    $cache['lastError'] = $result['error'] ?? UPDATER_TEXT['failed'];
                    updater_save_cache($cache);
                }
            }
            if (!empty($result['ok'])) {
                le_activity_log('update_installed', ($result['previousVersion'] ?? '?') . ' → ' . ($result['newVersion'] ?? '?'));
                $flow['installed'] = [
                    'previousVersion' => $result['previousVersion'] ?? null,
                    'newVersion' => $result['newVersion'] ?? null,
                ];
            }
        }
        $flow['status'] = updater_status();
    } catch (Throwable $e) {
        updater_log($context . ' update flow failed: ' . $e->getMessage());
    }
    return $flow;
}

function updater_acquire_lock(?string $path = null, bool $wait = false)
{
    ensure_dir(CACHE_ROOT);
    // c+: der Datenumzug liest seine Notiz aus der gehaltenen Sperrdatei.
    $fh = @fopen($path ?? updater_lock_path(), 'c+');
    if (!$fh) {
        return null;
    }
    if (!flock($fh, $wait ? LOCK_EX : LOCK_EX | LOCK_NB)) {
        fclose($fh);
        return null;
    }
    return $fh;
}

// Nur die Update-Sperre wird danach gelöscht. Andere Sperrdateien (Config-,
// Datenumzug) bleiben: An ihnen warten andere Requests bzw. sie tragen Notizen.
function updater_release_lock($fh): void
{
    if (!$fh) {
        return;
    }
    $isUpdateLock = stream_get_meta_data($fh)['uri'] === updater_lock_path();
    flock($fh, LOCK_UN);
    fclose($fh);
    if ($isUpdateLock) {
        @unlink(updater_lock_path());
    }
}

function updater_filtered_managed_paths(array $requested): array
{
    $allowed = [];
    foreach ($requested as $path) {
        if (!is_string($path) || $path === '') {
            continue;
        }
        $normalized = str_replace('\\', '/', $path);
        $normalized = trim($normalized, '/');
        if ($normalized === '' || strpos($normalized, '..') !== false) {
            continue;
        }
        if (in_array($normalized, UPDATER_ALLOWED_MANAGED_PATHS, true)) {
            $allowed[] = $normalized;
        }
    }
    return $allowed;
}

/** 'plugins' wird zu 'plugins/<name>' je Plugin, das das Release mitbringt. */
function updater_expand_plugin_paths(string $sourceRoot, array $managedPaths): array
{
    $expanded = [];
    foreach ($managedPaths as $relative) {
        if ($relative !== 'plugins') {
            $expanded[] = $relative;
            continue;
        }
        $dir = $sourceRoot . '/plugins';
        foreach (is_dir($dir) ? (scandir($dir) ?: []) : [] as $entry) {
            if (preg_match(UPDATER_PLUGIN_DIR_PATTERN, $entry) && is_dir($dir . '/' . $entry)) {
                $expanded[] = 'plugins/' . $entry;
            }
        }
    }
    return $expanded;
}

function updater_save_backup_paths(string $backupRoot, array $paths): void
{
    try {
        write_file_atomic($backupRoot . '/' . UPDATER_BACKUP_PATHS_FILE, (string) json_encode(array_values($paths)));
    } catch (Throwable $e) {
        // Eine alte Liste (etwa vor einem Teil-Rollback) nennt Pfade, die schon zurückliegen; ohne Liste legt der
        // Rollback nur zurück, was noch im Backup liegt.
        @unlink($backupRoot . '/' . UPDATER_BACKUP_PATHS_FILE);
        updater_log('could not write ' . UPDATER_BACKUP_PATHS_FILE . ' in ' . $backupRoot);
    }
}

/**
 * Pfade, die der Rollback zurücklegt: die beim Update getauschten (laut Liste
 * im Backup). Backups ohne lesbare Liste (Update durch eine Version vor dem
 * Tausch je Plugin, Schreiben der Liste gescheitert): jeder verwaltete Pfad,
 * von dem es ein Backup gibt, plugins/ aber je Plugin im Backup, nie als ganzer
 * Ordner (sonst wären Plugins nur dieser Installation weg). Plugins, die erst
 * das Update mitbrachte, bleiben dann liegen.
 */
function updater_backup_paths(string $backupRoot): array
{
    $list = json_decode((string) @file_get_contents($backupRoot . '/' . UPDATER_BACKUP_PATHS_FILE), true);
    if (!is_array($list)) {
        $present = array_values(array_filter(UPDATER_ALLOWED_MANAGED_PATHS, static fn ($relative) => file_exists($backupRoot . '/' . $relative)));
        return updater_expand_plugin_paths($backupRoot, $present);
    }
    return array_values(array_filter($list, static fn ($relative) => is_string($relative) && (
        in_array($relative, UPDATER_ALLOWED_MANAGED_PATHS, true)
        || (str_starts_with($relative, 'plugins/') && preg_match(UPDATER_PLUGIN_DIR_PATTERN, substr($relative, 8)))
    )));
}

function updater_restore_protected_paths(string $backupRoot): void
{
    foreach (UPDATER_PROTECTED_RELATIVE_PATHS as $relative) {
        $backup = $backupRoot . '/' . $relative;
        if (!is_file($backup) && !is_link($backup)) {
            continue;
        }

        $target = LE_PROJECT_ROOT . '/' . $relative;
        ensure_dir(dirname($target));
        if ((is_file($target) || is_link($target)) && !@unlink($target)) {
            updater_log('could not replace protected path: ' . $relative);
            continue;
        }
        if (!updater_copy_protected($backup, $target)) {
            updater_log('could not restore protected path: ' . $relative);
        }
    }
}

/** Kopiert eine geschützte Datei; ein Symlink (bewusst aus dem Webroot heraus) bleibt ein Symlink aufs selbe Ziel. */
function updater_copy_protected(string $from, string $to): bool
{
    if (is_link($from)) {
        $target = readlink($from);
        return $target !== false && @symlink($target, $to);
    }
    return @copy($from, $to);
}

function updater_rrmdir(string $path): bool
{
    if (is_link($path) || is_file($path)) {
        return @unlink($path);
    }
    if (!is_dir($path)) {
        return true;
    }
    $entries = scandir($path) ?: [];
    foreach ($entries as $entry) {
        if ($entry === '.' || $entry === '..') {
            continue;
        }
        updater_rrmdir($path . '/' . $entry);
    }
    return @rmdir($path);
}

function updater_find_extracted_root(string $extractDir): ?string
{
    $entries = array_values(array_filter(scandir($extractDir) ?: [], static fn ($e) => $e !== '.' && $e !== '..'));
    if (count($entries) === 1 && is_dir($extractDir . '/' . $entries[0])) {
        return $extractDir . '/' . $entries[0];
    }
    return $extractDir;
}

/** $confirmed: vom Admin ausgelöst; ohne Bestätigung nur Releases ohne requiresConfirmation. */
function updater_install(bool $confirmed = false): array
{
    if (!updater_enabled()) {
        return ['ok' => false, 'error' => UPDATER_TEXT['disabled']];
    }
    if (!class_exists('ZipArchive')) {
        return ['ok' => false, 'error' => UPDATER_TEXT['zipMissing']];
    }

    $cache = updater_load_cache();
    if (empty($cache['zipUrl']) || empty($cache['latestVersion'])) {
        return ['ok' => false, 'error' => UPDATER_TEXT['noUpdate']];
    }
    $local = updater_read_local_manifest();
    if (version_compare((string) $cache['latestVersion'], $local['version'], '<=')) {
        return ['ok' => false, 'error' => UPDATER_TEXT['upToDate']];
    }

    if (empty($cache['opensslSignature'])) {
        updater_log_once('install refused: missing openssl signature for ' . $cache['latestVersion']);
        return ['ok' => false, 'error' => UPDATER_SIGNATURE_INVALID_MESSAGE];
    }
    if (!function_exists('openssl_verify')) {
        return ['ok' => false, 'error' => UPDATER_OPENSSL_MISSING_MESSAGE];
    }

    $lock = updater_acquire_lock();
    if (!$lock) {
        return ['ok' => false, 'error' => UPDATER_TEXT['running']];
    }

    // Läuft im Login-Request: nicht vom Zeitlimit oder einem geschlossenen
    // Browser-Tab mitten im Austausch abbrechen lassen.
    ignore_user_abort(true);
    @set_time_limit(300);

    try {
        $tmpRoot = updater_tmp_root();
        updater_rrmdir($tmpRoot);
        ensure_dir($tmpRoot);

        $zipPath = $tmpRoot . '/release.zip';
        if (!updater_http_download($cache['zipUrl'], $zipPath, 120)) {
            return ['ok' => false, 'error' => UPDATER_TEXT['download']];
        }
        if (!updater_signature_valid($zipPath, (string) $cache['opensslSignature'])) {
            updater_log('install refused: invalid signature for ' . $cache['latestVersion']);
            return ['ok' => false, 'error' => UPDATER_SIGNATURE_INVALID_MESSAGE];
        }

        $extractDir = $tmpRoot . '/extracted';
        ensure_dir($extractDir);

        $zip = new ZipArchive();
        if ($zip->open($zipPath) !== true) {
            return ['ok' => false, 'error' => UPDATER_TEXT['zipOpen']];
        }

        for ($i = 0; $i < $zip->numFiles; $i++) {
            $entryName = $zip->getNameIndex($i);
            if (!is_string($entryName) || !zip_entry_name_safe($entryName)) {
                $zip->close();
                return ['ok' => false, 'error' => UPDATER_TEXT['zipPaths']];
            }
        }

        if (!$zip->extractTo($extractDir)) {
            $zip->close();
            return ['ok' => false, 'error' => UPDATER_TEXT['zipExtract']];
        }
        $zip->close();

        $sourceRoot = updater_find_extracted_root($extractDir);
        if (!$sourceRoot || !is_dir($sourceRoot)) {
            return ['ok' => false, 'error' => UPDATER_TEXT['archiveInvalid']];
        }

        $remoteManifestPath = $sourceRoot . '/core/release.json';
        if (!is_file($remoteManifestPath)) {
            return ['ok' => false, 'error' => UPDATER_TEXT['manifestMissing']];
        }
        $remoteManifest = json_decode((string) file_get_contents($remoteManifestPath), true);
        if (!is_array($remoteManifest) || empty($remoteManifest['version'])) {
            return ['ok' => false, 'error' => UPDATER_TEXT['manifestUnreadable']];
        }
        // Der Feed ist nicht signiert: Version und Bestätigungspflicht gelten
        // aus dem signierten Manifest. Sonst spielte ein manipulierter Feed ein
        // altes, gültig signiertes Release ein oder umginge die Bestätigung.
        $remoteVersion = (string) $remoteManifest['version'];
        if ($remoteVersion !== (string) $cache['latestVersion'] || version_compare($remoteVersion, $local['version'], '<=')) {
            updater_log_once('install refused: archive version ' . $remoteVersion . ' does not match feed ' . $cache['latestVersion'] . ' or is not newer than ' . $local['version']);
            return ['ok' => false, 'error' => UPDATER_TEXT['versionMismatch']];
        }
        if (!empty($remoteManifest['requiresConfirmation']) && !$confirmed) {
            // Banner zeigen wie bei einem ehrlichen Feed.
            $cache['requiresConfirmation'] = true;
            updater_save_cache($cache);
            updater_log_once('install deferred: ' . $remoteVersion . ' requires confirmation');
            return ['ok' => false, 'error' => UPDATER_TEXT['needsConfirmation']];
        }

        $managedRequested = is_array($remoteManifest['managedPaths'] ?? null)
            ? $remoteManifest['managedPaths']
            : UPDATER_ALLOWED_MANAGED_PATHS;
        $managedPaths = updater_filtered_managed_paths($managedRequested);
        if (empty($managedPaths)) {
            return ['ok' => false, 'error' => UPDATER_TEXT['noPaths']];
        }
        $managedPaths = updater_expand_plugin_paths($sourceRoot, $managedPaths);

        // Das neue Backup entsteht erst neben dem alten: Scheitert der Tausch,
        // bleibt das bisherige Backup und damit der Rollback erhalten.
        $stagedBackup = $tmpRoot . '/backup';
        ensure_dir($stagedBackup);

        $swap = updater_swap_paths($sourceRoot, $managedPaths, $stagedBackup);
        if (!$swap['ok']) {
            // Nicht alles zurückgelegt: Die Reste liegen im neuen Backup, der
            // Rollback in den Einstellungen legt sie zurück.
            if ($swap['incomplete'] !== []) {
                updater_save_backup_paths($stagedBackup, $swap['incomplete']);
                if (!updater_replace_path($stagedBackup, updater_backup_root())) {
                    updater_log('could not keep backup of failed update in ' . $stagedBackup);
                }
            }
            return ['ok' => false, 'error' => $swap['error']];
        }
        $swappedPaths = $swap['swapped'];

        updater_restore_protected_paths($stagedBackup);
        updater_forget_compiled($swappedPaths);
        updater_save_backup_paths($stagedBackup, $swappedPaths);
        if (!updater_replace_path($stagedBackup, updater_backup_root())) {
            updater_log('could not replace update backup, rollback restores the version before the previous update');
        }

        $cache['lastError'] = null;
        $cache['skippedVersion'] = null;
        $cache['failedVersion'] = null;
        $cache['lastCheck'] = current_iso_time();
        updater_save_cache($cache);

        updater_rrmdir($tmpRoot);

        updater_log(sprintf(
            'installed %s -> %s (paths: %s)',
            $local['version'],
            (string) $remoteManifest['version'],
            implode(',', $swappedPaths)
        ));

        return [
            'ok' => true,
            'previousVersion' => $local['version'],
            'newVersion' => (string) $remoteManifest['version'],
            'swappedPaths' => $swappedPaths,
        ];
    } finally {
        updater_release_lock($lock);
    }
}

/**
 * Tauscht die verwalteten Pfade gegen die aus dem Release. Scheitert ein
 * Schritt, wird alles bisher Getauschte zurückgelegt; 'incomplete' nennt, was
 * dabei nicht zurück konnte.
 */
function updater_swap_paths(string $sourceRoot, array $managedPaths, string $backupRoot): array
{
    $swappedPaths = [];
    foreach ($managedPaths as $relative) {
        $source = $sourceRoot . '/' . $relative;
        $target = LE_PROJECT_ROOT . '/' . $relative;
        if (!file_exists($source)) {
            continue;
        }

        if (file_exists($target)) {
            $backup = $backupRoot . '/' . $relative;
            ensure_dir(dirname($backup));
            if (!@rename($target, $backup)) {
                $incomplete = updater_rollback_internal($swappedPaths, $backupRoot);
                return ['ok' => false, 'error' => sprintf(UPDATER_TEXT['backupFailed'], $relative), 'incomplete' => $incomplete];
            }
        }
        // Ab hier gilt der Pfad als angefasst: scheitert der Tausch, muss
        // der Rollback auch dieses Backup zurücklegen.
        $swappedPaths[] = $relative;

        ensure_dir(dirname($target));
        if (!@rename($source, $target)) {
            $incomplete = updater_rollback_internal($swappedPaths, $backupRoot);
            return ['ok' => false, 'error' => sprintf(UPDATER_TEXT['swapFailed'], $relative), 'incomplete' => $incomplete];
        }
    }

    return ['ok' => true, 'swapped' => $swappedPaths];
}

/**
 * Setzt $from an die Stelle von $to, ohne $to vorher zu löschen: $to wird erst
 * beiseite benannt und nur gelöscht, wenn $from an seinem Platz liegt, sonst
 * kommt es zurück. $from null: $to nur entfernen. false, wenn $to unverändert ist.
 */
function updater_replace_path(?string $from, string $to): bool
{
    $aside = null;
    if (file_exists($to) || is_link($to)) {
        $aside = updater_tmp_root() . '/discard-' . bin2hex(random_bytes(4));
        ensure_dir(updater_tmp_root());
        if (!@rename($to, $aside)) {
            return false;
        }
    }
    if ($from !== null) {
        ensure_dir(dirname($to));
        if (!@rename($from, $to)) {
            if ($aside !== null && !@rename($aside, $to)) {
                updater_log('could not put back ' . $to . ' from ' . $aside);
            }
            return false;
        }
    }
    if ($aside !== null && !updater_rrmdir($aside)) {
        updater_log('could not delete ' . $aside);
    }
    return true;
}

/**
 * Legt die Backups der Pfade zurück; Pfade ohne Backup gab es vorher nicht und
 * werden entfernt. Läuft bei einem Fehler weiter und liefert die Pfade, die
 * nicht zurückgelegt sind (ihr Backup bleibt liegen).
 */
function updater_rollback_internal(array $swappedPaths, string $backupRoot): array
{
    $failed = [];
    foreach (array_reverse($swappedPaths) as $relative) {
        $backup = $backupRoot . '/' . $relative;
        if (!updater_replace_path(file_exists($backup) ? $backup : null, LE_PROJECT_ROOT . '/' . $relative)) {
            $failed[] = $relative;
        }
    }
    updater_forget_compiled($swappedPaths);
    if ($failed !== []) {
        updater_log('rollback incomplete: ' . implode(',', $failed));
    }
    return array_reverse($failed);
}

/**
 * Nach dem Tausch von Code (Update, Rollback): OPcache vergisst die PHP-Dateien der verwalteten
 * Pfade, sonst liefe bei opcache.validate_timestamps=0 der alte Code weiter (forget_compiled_tree).
 */
function updater_forget_compiled(array $relatives): void
{
    foreach ($relatives as $relative) {
        forget_compiled_tree(LE_PROJECT_ROOT . '/' . $relative);
    }
}

function updater_rollback(): array
{
    if (le_instance_is_multi()) {
        return ['ok' => false, 'error' => UPDATER_TEXT['disabled']];
    }
    $backupRoot = updater_backup_root();
    if (!is_dir($backupRoot)) {
        return ['ok' => false, 'error' => UPDATER_TEXT['noBackup']];
    }

    $lock = updater_acquire_lock();
    if (!$lock) {
        return ['ok' => false, 'error' => UPDATER_TEXT['busy']];
    }

    try {
        // Seit dem Update geänderte Zugangsdaten nicht mit den alten überschreiben.
        $keepRoot = updater_tmp_root() . '/keep-config';
        updater_rrmdir($keepRoot);
        foreach (UPDATER_PROTECTED_RELATIVE_PATHS as $relative) {
            if (is_file(LE_PROJECT_ROOT . '/' . $relative) || is_link(LE_PROJECT_ROOT . '/' . $relative)) {
                ensure_dir(dirname($keepRoot . '/' . $relative));
                updater_copy_protected(LE_PROJECT_ROOT . '/' . $relative, $keepRoot . '/' . $relative);
            }
        }

        $rolledBackFrom = updater_read_local_manifest()['version'];
        // Scheitert ein Pfad, laufen die übrigen weiter; das Backup bleibt für
        // einen zweiten Versuch liegen, der nur noch die Reste zurücklegt.
        $failed = updater_rollback_internal(updater_backup_paths($backupRoot), $backupRoot);
        updater_restore_protected_paths($keepRoot);
        updater_rrmdir($keepRoot);
        if ($failed === []) {
            updater_rrmdir($backupRoot);
        } else {
            updater_save_backup_paths($backupRoot, $failed);
        }

        $local = updater_read_local_manifest();
        $cache = updater_load_cache();
        $cache['lastCheck'] = current_iso_time();
        // Beim zweiten Versuch nach einem Teil-Rollback ist core/ meist schon zurück.
        if ($rolledBackFrom !== $local['version']) {
            $cache['skippedVersion'] = $rolledBackFrom;
        }
        updater_save_cache($cache);

        if ($failed !== []) {
            return ['ok' => false, 'error' => sprintf(UPDATER_TEXT['rollbackFailed'], implode(', ', $failed))];
        }
        updater_log('rollback to ' . $local['version']);
        return ['ok' => true, 'currentVersion' => $local['version']];
    } finally {
        updater_release_lock($lock);
    }
}
