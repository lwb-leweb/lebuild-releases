<?php
$page = [
    'title'       => 'Anfrage',
    'description' => 'Kontaktformular und Öffnungszeiten der Testseite.',
    'slug'        => 'anfrage',
];
require __DIR__ . '/includes/header.php';
?>

<section class="section">
    <div class="container grid grid--2">
        <div>
            <h1 data-edit-id="container.title" data-edit-label="Anfrage – Überschrift">Anfrage</h1>
            <p class="lead" data-edit-id="container.text" data-edit-label="Anfrage – Absatz">Das Formular schickt die Anfrage an die Adresse aus den Einstellungen.</p>
            <div data-plugin="contact-form" data-view="form"></div>
        </div>
        <div>
            <h2 data-edit-id="container.title_2" data-edit-label="Öffnungszeiten – Überschrift">Öffnungszeiten</h2>
            <div data-plugin="opening-hours" data-view="week"></div>
        </div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
