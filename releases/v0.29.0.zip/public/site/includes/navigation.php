<?php
require_once __DIR__ . '/config.php';
$current = current_page($pageSlug ?? '');
?>
<header class="site-header">
    <div class="container site-header__inner">
        <a class="brand" href="/" data-edit-id="header.link_1.url"><?= e(SITE_NAME) ?></a>

        <button class="nav-toggle" type="button" aria-controls="primary-nav" aria-expanded="false" data-nav-toggle>
            <span class="nav-toggle__bars" aria-hidden="true"></span>
            <span class="visually-hidden" data-edit-id="header.nav_toggle.text">Menü öffnen</span>
        </button>

        <nav id="primary-nav" class="primary-nav" aria-label="Hauptnavigation" data-nav>
            <ul class="primary-nav__list">
                <?php foreach ($NAV_ITEMS as $item): ?>
                    <?php $isActive = $current === $item['href']; ?>
                    <li>
                        <a
                            href="<?= e($item['href']) ?>"
                            class="primary-nav__link<?= $isActive ? ' is-active' : '' ?>"
                            <?= $isActive ? 'aria-current="page"' : '' ?>>
                            <?= e($item['label']) ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>

        <a class="button button--small" href="/anfrage" data-edit-id="header.link_4.url" data-edit-text-id="header.link_4.text">Anfragen</a>
    </div>
</header>
