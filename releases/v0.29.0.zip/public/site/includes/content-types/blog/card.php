<?php
// Karte eines Beitrags: Datum (ohne: angelegt am), Bild, Titel, Kurzfassung; Klick öffnet die eigene Seite.
$datum = (string) ($item['datum'] ?? '') ?: (string) ($item['created_at'] ?? '');
?>
<<?= ct_tag($item) ?> class="card" <?= ct_action_attrs($item) ?>>
    <span class="card__media"><?= ct_image($item, 'bild', 'titel') ?></span>
    <small class="card__meta"><?= $datum !== '' ? date('d.m.Y', strtotime($datum)) : '' ?></small>
    <h3><?= ct_text($item, 'titel') ?></h3>
    <p><?= ct_lines($item, 'kurz') ?></p>
</<?= ct_tag($item) ?>>
