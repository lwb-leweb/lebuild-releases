<?php $datum = (string) ($item['datum'] ?? '') ?: (string) ($item['created_at'] ?? ''); ?>
<article class="section">
    <div class="container prose">
        <a href="/listen#beitraege">← Alle Beiträge</a>
        <p class="card__meta"><?= $datum !== '' ? date('d.m.Y', strtotime($datum)) : '' ?></p>
        <h1><?= ct_text($item, 'titel') ?></h1>
        <p class="lead"><?= ct_lines($item, 'kurz') ?></p>
        <figure><?= ct_image($item, 'bild', 'titel') ?></figure>
        <?= ct_rich($item, 'text') ?>
    </div>
</article>
