    </main>

    <footer class="site-footer">
        <div class="container site-footer__inner">
            <div>
                <h2 class="site-footer__title" data-edit-id="footer.container.title" data-edit-label="Testseite – Überschrift">Testseite</h2>
                <p class="site-footer__text" data-edit-id="footer.container.text" data-edit-label="Testseite – Absatz">Bei der Installation wird sie durch die Website des Kunden ersetzt.</p>
            </div>
            <p>&copy; <?= e((string)date('Y')) ?> <?= e(SITE_NAME) ?><?= SITE_OWNER !== '' ? ' · ' . e(SITE_OWNER) : '' ?></p>
            <nav class="site-footer__legal" aria-label="Rechtliches">
                <a href="/impressum" data-edit-id="footer.link_1.url" data-edit-text-id="footer.link_1.text">Impressum</a>
                <a href="/datenschutz" data-edit-id="footer.link_2.url" data-edit-text-id="footer.link_2.text">Datenschutz</a>
                <a href="../admin/" data-edit-id="footer.link_3.url" data-edit-text-id="footer.link_3.text">Anmelden</a>
            </nav>
        </div>
    </footer>

    <script src="assets/js/main.js" defer></script>
</body>
</html>
