<?php
$page = [
    'title'       => 'Testseite',
    'description' => 'Testseite von LeBuild: Text, Bild, Link, Listen, Öffnungszeiten und Kontaktformular zum Ausprobieren.',
    'slug'        => '',
];
require __DIR__ . '/includes/header.php';
?>

<section class="hero">
    <div class="container hero__inner">
        <div>
            <h1 data-edit-id="container.title" data-edit-label="Eine Testseite für LeBuild – Überschrift">Eine Testseite für LeBuild</h1>
            <p class="lead" data-edit-id="container.text" data-edit-label="Eine Testseite für LeBuild – Absatz">Hier lässt sich alles ausprobieren, was eine Kundenseite braucht: Text, <strong>Auszeichnung</strong>, Bilder und Links direkt auf der Seite ändern.</p>
            <a class="button" href="/listen" data-edit-id="link_1.url" data-edit-text-id="link_1.text" data-edit-label="Eine Testseite für LeBuild – Link">Zu den Listen</a>
        </div>
        <img class="hero__image" src="assets/img/editor.svg" alt="Skizze des Editors" width="640" height="520" data-edit-id="container.image" data-edit-alt-id="container.image_alt" data-edit-label="Eine Testseite für LeBuild – Bild">
    </div>
</section>

<section class="section section--soft">
    <div class="container grid grid--2">
        <div>
            <h2 data-edit-id="container.title_2" data-edit-label="Öffnungszeiten – Überschrift">Öffnungszeiten</h2>
            <p data-edit-id="container.text_2" data-edit-label="Öffnungszeiten – Absatz">Status und Woche kommen aus dem Plugin, die Zeiten pflegt man im Backend oder direkt hier.</p>
            <p><span data-plugin="opening-hours" data-view="status"></span></p>
        </div>
        <div data-plugin="opening-hours" data-view="week"></div>
    </div>
</section>

<section class="section">
    <div class="container">
        <h2 data-edit-id="container.title_3" data-edit-label="Neueste Beiträge – Überschrift">Neueste Beiträge</h2>
        <div class="cards" data-plugin="content-types" data-view="list" data-type="blog" data-limit="3"></div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
