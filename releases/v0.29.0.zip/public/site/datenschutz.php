<?php
$page = [
    'title'       => 'Datenschutz',
    'description' => 'Datenschutzerklärung der Testseite.',
    'slug'        => 'datenschutz',
];
require __DIR__ . '/includes/header.php';
?>

<section class="section">
    <div class="container prose">
        <h1 data-edit-id="container.title" data-edit-label="Datenschutz – Überschrift">Datenschutz</h1>
        <p data-edit-id="container.text" data-edit-label="Datenschutz – Absatz">Diese Testseite liefert LeBuild mit. Auf einer echten Website steht hier die Datenschutzerklärung des Betreibers.</p>
        <h2 data-edit-id="container.title_2" data-edit-label="Cookies – Überschrift">Cookies</h2>
        <p data-edit-id="container.text_2" data-edit-label="Cookies – Absatz">Besucher bekommen keine Cookies. Nur wer sich im Editor anmeldet, erhält ein technisch notwendiges Cookie für die Anmeldung.</p>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
