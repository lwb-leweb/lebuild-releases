<?php
$page = [
    'title'       => 'Impressum',
    'description' => 'Impressum der Testseite.',
    'slug'        => 'impressum',
];
require __DIR__ . '/includes/header.php';
?>

<section class="section">
    <div class="container prose">
        <h1 data-edit-id="container.title" data-edit-label="Impressum – Überschrift">Impressum</h1>
        <p data-edit-id="container.text" data-edit-label="Impressum – Absatz">Diese Testseite liefert LeBuild mit. Auf einer echten Website stehen hier die Angaben des Betreibers.</p>
        <h2 data-edit-id="container.title_2" data-edit-label="Anbieter – Überschrift">Anbieter</h2>
        <p data-edit-id="container.text_2" data-edit-label="Anbieter – Absatz">Musterfirma GmbH<br>Musterstraße 1<br>1010 Wien</p>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
