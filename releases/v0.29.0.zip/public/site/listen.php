<?php
$page = [
    'title'       => 'Listen',
    'description' => 'Listen der Testseite: Fragen zum Aufklappen und Beiträge mit eigener Seite.',
    'slug'        => 'listen',
];
require __DIR__ . '/includes/header.php';
?>

<section class="section">
    <div class="container">
        <h1 data-edit-id="container.title" data-edit-label="Listen – Überschrift">Listen</h1>
        <p class="lead" data-edit-id="container.text" data-edit-label="Listen – Absatz">Einträge pflegt man über ein Formular, die Website zeigt sie mit ihren eigenen Vorlagen.</p>
    </div>
</section>

<section id="faq" class="section section--soft">
    <div class="container">
        <h2 data-edit-id="container.title_2" data-edit-label="Häufige Fragen – Überschrift">Häufige Fragen</h2>
        <div class="faq" data-plugin="content-types" data-view="list" data-type="faq" data-limit="50"></div>
    </div>
</section>

<section id="beitraege" class="section">
    <div class="container">
        <h2 data-edit-id="container.title_3" data-edit-label="Beiträge – Überschrift">Beiträge</h2>
        <div class="cards" data-plugin="content-types" data-view="list" data-type="blog" data-limit="20"></div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
