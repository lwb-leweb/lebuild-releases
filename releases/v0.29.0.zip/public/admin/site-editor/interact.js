import { state } from '../modules/core.js';
import { EDIT_TARGET_SELECTOR, BACKGROUND_SELECTOR, EDIT_ATTR, FIELD_KIND, TEXT_KINDS, editableField, hasNestedField, hasFieldValue, fieldValue } from './page-sync.js';
import { editorHost, fromBar, isPreview, onModeChange, notify } from './bar.js';
import { activeEdit, endEdit, record, pageUploads, isSaving } from './session.js';
import { uploadImage, draggingFiles } from './upload.js';
import { showHover, showActive, CHIP_PLACE } from './overlay.js';
import { editInline } from './text-inline.js';
import { openImage, openBackground, openIcon } from './field-editors.js';
import { ENTRY_TEXT } from './entry-form.js';

// Klicks, Überfahren und Tastatur auf der Seite. Editierbar ist ein Element, dessen Feld der
// Server kennt (state.fieldKinds). Text und Links bearbeitet ein Klick direkt, Bilder öffnen ihren
// Dialog, Icons ihre Auswahl. Hintergrundbilder und Links mit Feldern darin (Bild im Link) lassen sich nicht direkt
// treffen und bekommen einen Knopf am Element. Eine Datei, auf ein Bild oder Hintergrundbild
// gezogen, ersetzt es. Am Handy zeigt das erste Antippen den Rahmen,
// das zweite bearbeitet. Ein Klick in einem Link, der etwas Bearbeitbares trifft (Feld, Plugin-
// Eintrag), navigiert nicht, sondern zeigt Rahmen und „Bearbeiten“/„Öffnen →“, mit Maus wie am
// Handy; Strg/⌘-, Umschalt- und Mittelklick öffnen wie gewohnt. Ist der Eintrag selbst der Link und
// verlangt seine Liste das Formular (formOnly, Content-Typen-Karten), öffnet der Klick wie bei jedem
// Eintrag sein Formular. Mit der Tastatur (Enter) bekommt
// der erste Knopf den Fokus, Esc gibt ihn an den Link zurück. Ereignisse fangen wir in der
// Capture-Phase ab, damit Links nicht navigieren und Skripte der Seite (Lightbox, Slider-Tasten)
// nichts davon mitbekommen.

const CHIP_TEXT = {
  background: 'Hintergrundbild tauschen',
  link: 'Link ändern',
  edit: ENTRY_TEXT.edit,
  image: 'Bild tauschen',
  icon: 'Icon tauschen',
  open: 'Öffnen →'
};
// Schild beim Überfahren: was ein Klick auf das Feld tut.
const TAG_TEXT = {
  heading: 'Überschrift ändern',
  text: 'Text ändern',
  link: 'Link ändern',
  image: 'Bild tauschen',
  icon: 'Icon tauschen',
  drop: 'Bild hier ablegen'
};
const HEADING_SELECTOR = 'h1, h2, h3, h4, h5, h6';
// Während der Textbearbeitung gehen diese Ereignisse nicht an die Seite weiter; input meldet
// Tippen an die Bearbeitung (Speichern und Rückgängig werden aktiv).
const EDIT_EVENTS = ['keydown', 'keyup', 'keypress', 'input', 'paste', 'drop'];
// Eingaben in Leiste und Dialogen bleiben ebenfalls beim Editor.
const EDITOR_EVENTS = ['keydown', 'keyup', 'keypress', 'paste'];
// Während eines Speicherns sperrt der Editor diese Eingaben auf der Seite und in seinen Dialogen,
// Panels und Knöpfen (Text, Richtext, Bild, Link, Plugin-Listen, „Alle Texte“); nur die Leiste bleibt
// bedienbar, Speichern und Rückgängig sind dort gesperrt. Sonst ginge, was in dieser Zeit geändert
// wird, beim Neuladen nach Erfolg oder bei einem Teil-Speichern verloren.
const SAVING_BLOCKED = ['pointerdown', 'mousedown', 'click', 'dblclick', 'keydown', 'keypress', 'beforeinput', 'input', 'paste', 'cut', 'dragover', 'drop'];
const LINK_SELECTOR = 'a[' + EDIT_ATTR.id + ']';
// Links, die navigieren (ohne Ziel navigiert ein <a> nicht).
const NAV_LINK_SELECTOR = 'a[href]';

// Weitere Knöpfe an Elementen der Seite (Plugin-Listen, plugin-lists.js): { anchorFor(el) →
// Element|null (Eintrag oder Liste), chips(anchor) → [{ anchor, place, label, onClick, … }],
// activate(anchor) → Funktion für den Klick auf das Element selbst (Eintrag bearbeiten) oder null,
// formOnly(anchor) (optional) → true: auch ein Link im Eintrag öffnet beim Klick activate statt Link-Knöpfen }.
const chipSources = [];

let pointerType = 'mouse';
let armed = null;
let hovered = null;
let blockClick = false;
// Angeklickter Link mit seinen Knöpfen: { link, target (Feld für „Bearbeiten“ oder null), point,
// anchor und place der Knöpfe (linkChipPlace), focus (erster Knopf bekommt einmal den Fokus) }.
let selected = null;
// Link, dessen Klick „Öffnen →“ auslöst und der durchgeht.
let passLink = null;

function kindOf(path) {
  return state.fieldKinds[path];
}

function fromEditor(event) {
  return event.composedPath().indexOf(editorHost()) !== -1;
}

function elementOf(node) {
  return node && node.nodeType === Node.ELEMENT_NODE ? node : node && node.parentElement;
}

// Lässt sich das Feld per Klick bearbeiten? Nur mit Wert aus getPage (sonst fehlte der alte Wert),
// Text und Link nur ohne weitere Felder darin (sonst scheitert das Speichern bzw. die inneren
// Felder wären nicht erreichbar).
function directlyEditable(el) {
  const path = editableField(el).path;
  const kind = kindOf(path);
  if (!hasFieldValue(path)) return false;
  if (kind === FIELD_KIND.image) return el.tagName.toLowerCase() === 'img';
  if (kind === FIELD_KIND.icon) return el.tagName.toLowerCase() === 'svg';
  return (TEXT_KINDS.indexOf(kind) !== -1 || kind === FIELD_KIND.url) && !hasNestedField(el);
}

// Innerstes direkt editierbares Element über node.
function targetFor(node) {
  let el = elementOf(node);
  el = el && el.closest(EDIT_TARGET_SELECTOR);
  while (el) {
    if (directlyEditable(el)) return el;
    el = el.parentElement && el.parentElement.closest(EDIT_TARGET_SELECTOR);
  }
  return null;
}

// Link mit Ziel-Feld um node, der weitere Felder enthält (Bild im Link): nur über seinen Knopf.
function linkContainer(node) {
  const el = elementOf(node);
  const link = el && el.closest(LINK_SELECTOR);
  const path = link ? link.getAttribute(EDIT_ATTR.id) : '';
  return link && kindOf(path) === FIELD_KIND.url && hasFieldValue(path) && hasNestedField(link) ? link : null;
}

// Element einer Knopf-Quelle um node (Plugin-Eintrag oder Liste); null ohne.
function chipAnchor(node) {
  const el = elementOf(node);
  if (!el) return null;
  for (let i = 0; i < chipSources.length; i++) {
    const anchor = chipSources[i].anchorFor(el);
    if (anchor) return { source: chipSources[i], anchor: anchor };
  }
  return null;
}

// Link um node, dessen Klick etwas Bearbeitbares trifft (Feld am oder um den Klick, Link mit
// Feldern darin, Plugin-Eintrag, Hintergrundbild im Link); null, wenn der Klick navigieren darf oder
// der Eintrag ihn als Ganzes zum Formular macht (formOnly).
function clickedLink(node) {
  const el = elementOf(node);
  const link = el && el.closest(NAV_LINK_SELECTOR);
  if (!link) return null;
  const background = el.closest(BACKGROUND_SELECTOR);
  const found = chipAnchor(el);
  const entry = found && !(found.source.formOnly && found.source.formOnly(found.anchor));
  return targetFor(el) || linkContainer(el) || entry || (background && link.contains(background)) ? link : null;
}

// Knöpfe eines Links stehen in der Gruppe seines Plugin-Eintrags (sonst lägen zwei Gruppen
// übereinander), sonst über dem Link.
function linkChipPlace(link) {
  const found = chipAnchor(link);
  const own = found && found.source.chips(found.anchor).find(function (chip) { return chip.anchor === found.anchor; });
  return own ? { anchor: own.anchor, place: own.place } : { anchor: link, place: CHIP_PLACE.above };
}

// Knöpfe des angeklickten Links: „Bearbeiten“ (wenn der Klick ein Feld traf; bei einem Bild im
// Link „Bild bearbeiten“ und „Link bearbeiten“ für das Ziel), „Öffnen →“.
function selectedChips() {
  if (selected && !selected.link.isConnected) selected = null;
  if (!selected) return [];
  const current = selected;
  const chip = function (label, onClick) {
    return { anchor: current.anchor, place: current.place, label: label, onClick: onClick };
  };
  const container = linkContainer(current.link) === current.link;
  const chips = [];
  if (current.target) {
    const targetKind = kindOf(editableField(current.target).path);
    const label = !container ? CHIP_TEXT.edit : targetKind === FIELD_KIND.image ? CHIP_TEXT.image : targetKind === FIELD_KIND.icon ? CHIP_TEXT.icon : CHIP_TEXT.edit;
    chips.push(chip(label, function () { edit(current.target, current.point); }));
  }
  if (container) chips.push(chip(CHIP_TEXT.link, function () { open(function () { editLink(current.link); }); }));
  chips.push(chip(CHIP_TEXT.open, function () { openLink(current.link); }));
  chips[0].focus = current.focus;
  current.focus = false;
  return chips;
}

// Ziel eines Links mit Feldern darin (Bild im Link) in der Mini-Leiste.
function editLink(link) {
  editInline(link, { textPath: '', urlPath: link.getAttribute(EDIT_ATTR.id) });
}

// Öffnet der Klick wie bei Besuchern? Strg/⌘ (neuer Tab), Umschalt (neues Fenster); Mittelklick
// löst kein click aus.
function opensNatively(event) {
  return event.ctrlKey || event.metaKey || event.shiftKey;
}

// Link auswählen (Rahmen, Knöpfe bis zum nächsten Klick daneben oder Esc) bzw. die Auswahl
// aufheben (link null); node/point: wo die Knöpfe neu gezeigt werden.
function select(link, target, node, point) {
  if (!link && !selected) return;
  // Tastatur (Enter auf dem Link): click ohne Zählung (detail 0) und ohne Punkt.
  const keyboard = Boolean(link) && point.detail === 0;
  selected = link ? Object.assign({ link: link, target: target, point: { clientX: point.clientX, clientY: point.clientY }, focus: keyboard }, linkChipPlace(link)) : null;
  showActive(link);
  if (node) show(node);
  else showHover(null, []);
}

// „Öffnen →“: der Klick auf den Link geht durch (Ziel, target und Skripte der Seite wie bei
// Besuchern); bei ungespeicherten Änderungen warnt der Browser vor dem Verlassen.
function openLink(link) {
  select(null);
  passLink = link;
  link.click();
  passLink = null;
}

// Knöpfe für Felder um node, die kein Klick erreicht, und für Plugin-Einträge (zuerst, damit der
// Rahmen um den Eintrag liegt).
function chipsFor(node) {
  const el = elementOf(node);
  const chips = [];
  if (!el) return chips;
  const found = chipAnchor(el);
  if (found) {
    found.source.chips(found.anchor).forEach(function (chip) {
      chips.push(Object.assign({}, chip, { onClick: function () { open(chip.onClick); } }));
    });
  }
  const background = el.closest(BACKGROUND_SELECTOR);
  if (background) {
    const path = background.getAttribute(EDIT_ATTR.bg);
    if (kindOf(path) === FIELD_KIND.background && hasFieldValue(path)) {
      chips.push({ anchor: background, label: CHIP_TEXT.background, icon: 'image', onClick: function () { open(function () { openBackground(background, path); }); } });
    }
  }
  // Ein Link, der navigiert, zeigt „Link bearbeiten“ erst nach dem Klick bei seinen Knöpfen
  // (selectedChips): Beim Überfahren läge der Knopf über seinem Inhalt (Logo) und finge den Klick ab.
  const link = linkContainer(el);
  if (link && !link.matches(NAV_LINK_SELECTOR)) {
    chips.push({ anchor: link, label: CHIP_TEXT.link, icon: 'link', onClick: function () { open(function () { editLink(link); }); } });
  }
  return chips;
}

// Schild für ein direkt bearbeitbares Element: { icon, text }.
function tagFor(target) {
  const kind = kindOf(editableField(target).path);
  if (kind === FIELD_KIND.image) return { icon: 'image', text: TAG_TEXT.image };
  if (kind === FIELD_KIND.icon) return { icon: 'star', text: TAG_TEXT.icon };
  if (kind === FIELD_KIND.url) return { icon: 'link', text: TAG_TEXT.link };
  return { icon: 'pencil', text: target.matches(HEADING_SELECTOR) ? TAG_TEXT.heading : TAG_TEXT.text };
}

// Leuchten, Schild und Knöpfe für node; über dem Element in Bearbeitung genügt dessen eigener Rahmen.
function show(node) {
  const active = activeEdit();
  const target = targetFor(node);
  const chips = chipsFor(node).concat(selectedChips());
  if (active && target && active.contains(target)) {
    showHover(null, chips);
    return;
  }
  showHover(target || (chips.length ? chips[0].anchor : null), chips, target ? tagFor(target) : null);
}

// Eine laufende Bearbeitung zuerst übernehmen; scheitert das, bleibt sie offen.
function open(start) {
  if (!endEdit(true)) return;
  armed = null;
  selected = null;
  showActive(null);
  // Nach der Bearbeitung zeigt die nächste Mausbewegung den Rahmen wieder, auch im selben Element.
  hovered = null;
  showHover(null, []);
  start();
}

function edit(target, event) {
  const field = editableField(target);
  const kind = kindOf(field.path);
  open(function () {
    if (kind === FIELD_KIND.image) {
      openImage(target, field);
    } else if (kind === FIELD_KIND.icon) {
      openIcon(target, field);
    } else if (kind === FIELD_KIND.url) {
      const textPath = TEXT_KINDS.indexOf(kindOf(field.textPath)) !== -1 && hasFieldValue(field.textPath) ? field.textPath : '';
      editInline(target, { textPath: textPath, urlPath: field.path, x: event.clientX, y: event.clientY });
    } else {
      editInline(target, { textPath: field.path, urlPath: '', x: event.clientX, y: event.clientY });
    }
  });
}

function onPointerMove(event) {
  if (event.pointerType === 'touch' || fromEditor(event) || isPreview()) return;
  if (isSaving()) {
    hovered = null;
    showHover(null, []);
    return;
  }
  if (event.target === hovered) return;
  hovered = event.target;
  show(event.target);
}

// Klick daneben übernimmt die laufende Bearbeitung: mit der Maus schon beim Drücken, damit der
// Klick auf ein anderes Feld gleich dort weitermacht; am Handy erst beim Klick, denn Wischen
// (Scrollen) beginnt auch mit pointerdown, löst aber keinen Klick aus.
function commitOutside(event) {
  const active = activeEdit();
  return !active || active.contains(event.target) || endEdit(true);
}

function onPointerDown(event) {
  pointerType = event.pointerType;
  // Ein gesperrter Klick gilt nur bis zur nächsten Berührung (auch wenn keiner kam, z. B. Ziehen).
  blockClick = false;
  if (fromEditor(event) || pointerType === 'touch' || isPreview()) return;
  if (!commitOutside(event)) blockClick = true;
}

function stop(event) {
  event.preventDefault();
  event.stopPropagation();
}

function onClick(event) {
  if (fromEditor(event) || (passLink && event.target === passLink) || isPreview()) return;
  if (blockClick) {
    blockClick = false;
    stop(event);
    return;
  }
  if (pointerType === 'touch' && !commitOutside(event)) {
    stop(event);
    return;
  }
  const active = activeEdit();
  // Klick im bearbeiteten Element (auch auf einen Link darin) setzt nur den Cursor.
  if (active && active.contains(event.target)) {
    stop(event);
    return;
  }
  // Strg/⌘- und Umschalt-Klick öffnen wie gewohnt; sonst Knöpfe am Link.
  const link = clickedLink(event.target);
  if (link && !opensNatively(event)) {
    stop(event);
    armed = null;
    if (selected && selected.link === link) return;
    select(link, targetFor(event.target), event.target, event);
    return;
  }
  select(null, null, event.target, event);
  if (link) return;
  const target = targetFor(event.target);
  if (!target) {
    // Klick auf einen Plugin-Eintrag öffnet ihn (activate); am Handy zeigt das erste Antippen nur
    // Leuchten und Knöpfe, sie liegen über dem Eintrag (overlay.js), ein Link darin zeigt seine.
    const found = chipAnchor(event.target);
    // Strg/⌘- und Umschalt-Klick auf einen Eintrag, der ein Link ist (formOnly), öffnen wie gewohnt.
    if (found && opensNatively(event) && elementOf(event.target).closest(NAV_LINK_SELECTOR)) return;
    const activate = found && found.source.activate ? found.source.activate(found.anchor) : null;
    if (found && pointerType === 'touch' && armed !== found.anchor) {
      armed = found.anchor;
      stop(event);
      show(event.target);
      return;
    }
    if (activate) {
      stop(event);
      armed = null;
      open(activate);
      return;
    }
    if (!found) armed = null;
    // Ein Link mit Feld darin (Bild im Link) navigiert nicht weg; Rahmen und Knopf „Link“ zeigen.
    if (linkContainer(event.target)) {
      stop(event);
      show(event.target);
      return;
    }
    if (pointerType === 'touch') show(event.target);
    return;
  }
  stop(event);
  if (pointerType === 'touch' && armed !== target) {
    armed = target;
    show(event.target);
    return;
  }
  edit(target, event);
}

function onEditEvent(event) {
  const active = activeEdit();
  if (!active && event.type === 'keydown' && event.key === 'Escape' && selected) {
    // Esc in den Knöpfen gibt den Fokus an den Link zurück.
    const link = selected.link;
    select(null);
    if (fromEditor(event)) link.focus({ preventScroll: true });
  }
  if (!active) return;
  if (event.type === 'keydown' && event.key === 'Escape') {
    // Esc aus der übrigen Oberfläche des Editors gehört dorthin (Rückfrage und Panel schließen sich, die Bearbeitung
    // bleibt); verworfen wird nur bei Esc im Element oder in der Oberfläche der Bearbeitung selbst (Mini-Leiste,
    // Popover, Panel-Feld).
    if (fromEditor(event) && !(active.owns && active.owns(event.composedPath()[0]))) return;
    stop(event);
    if (!active.escape()) endEdit(false);
    return;
  }
  if (fromEditor(event) || !active.contains(event.target)) return;
  if (active.handlers && active.handlers[event.type]) active.handlers[event.type](event);
  event.stopPropagation();
}

// Bildfeld unter node für eine hineingezogene Datei: Bild (img) oder Element mit Hintergrundbild;
// { el, path } oder null.
function dropTargetFor(node) {
  const target = targetFor(node);
  if (target && kindOf(editableField(target).path) === FIELD_KIND.image) {
    return { el: target, path: editableField(target).path };
  }
  const el = elementOf(node);
  const background = el && el.closest(BACKGROUND_SELECTOR);
  const path = background ? background.getAttribute(EDIT_ATTR.bg) : '';
  return background && kindOf(path) === FIELD_KIND.background && hasFieldValue(path) ? { el: background, path: path } : null;
}

// Datei über der Seite: Leuchten und Schild „Bild hier ablegen“ über einem Bildfeld. Abgefangen
// wird jedes Ziehen von Dateien, sonst öffnete der Browser die Datei und die Seite samt
// ungespeicherten Änderungen wäre weg. In einem Text in Bearbeitung entscheidet dieser (text-markup.js).
function onDragOver(event) {
  if (fromEditor(event) || isPreview() || !draggingFiles(event)) return;
  const active = activeEdit();
  if (active && active.contains(event.target)) return;
  event.preventDefault();
  const drop = dropTargetFor(event.target);
  event.dataTransfer.dropEffect = drop ? 'copy' : 'none';
  if (event.target === hovered) return;
  hovered = event.target;
  showHover(drop ? drop.el : null, [], drop ? { icon: 'image', text: TAG_TEXT.drop } : null);
}

// Datei verlässt das Fenster (dragleave ohne neues Ziel).
function onDragLeave(event) {
  if (event.relatedTarget || fromEditor(event)) return;
  hovered = null;
  showHover(null, selectedChips());
}

// Abgelegte Datei: laufende Bearbeitung übernehmen, hochladen, dann ist das neue Bild eine Änderung
// wie aus dem Dialog (Rückgängig, Speichern); der Alt-Text bleibt.
function onDrop(event) {
  if (fromEditor(event) || isPreview() || !draggingFiles(event)) return;
  const active = activeEdit();
  if (active && active.contains(event.target)) return;
  stop(event);
  hovered = null;
  const drop = dropTargetFor(event.target);
  const file = event.dataTransfer.files[0];
  showHover(null, selectedChips());
  if (!drop || !file) return;
  open(function () {
    uploadImage(file, notify, pageUploads).then(function (url) {
      // Inzwischen kann eine neue Bearbeitung laufen (die Seite ist beim Hochladen nicht gesperrt): ihr Text bleibt.
      record([{ path: drop.path, before: fieldValue(drop.path), after: url }], { keepActive: true });
    }).catch(function () { /* Meldung kam über notify */ });
  });
}

// Sperre beim Speichern (SAVING_BLOCKED): Zuhörer am window in der Capture-Phase, vor allen anderen
// des Editors (außer Strg+S, save-key.js, und dem Schließen des Menüs, bar.js); Skripte der Seite
// bekommen nichts davon mit. Eine abgelegte Datei öffnet der Browser auch jetzt nicht.
function blockWhileSaving(event) {
  if (!isSaving() || fromBar(event)) return;
  event.preventDefault();
  event.stopImmediatePropagation();
  if (event.type === 'dragover') event.dataTransfer.dropEffect = 'none';
}

// Neue Knopf-Quelle (siehe chipSources); Klick auf einen ihrer Knöpfe übernimmt vorher eine
// laufende Bearbeitung.
export function addChipSource(source) {
  chipSources.push(source);
}

// „Ansehen“ (bar.js): laufende Bearbeitung übernehmen (scheitert das, bleibt es bei Bearbeiten),
// Auswahl, Leuchten und Knöpfe weg; zurück bei Bearbeiten zeigt die nächste Mausbewegung sie wieder.
function onPreview(preview) {
  if (!preview) return true;
  if (!endEdit(true)) return false;
  armed = null;
  selected = null;
  hovered = null;
  showActive(null);
  showHover(null, []);
  return true;
}

export function attachInteractions() {
  SAVING_BLOCKED.forEach(function (type) {
    window.addEventListener(type, blockWhileSaving, true);
  });
  onModeChange(onPreview);
  window.addEventListener('pointermove', onPointerMove, { capture: true, passive: true });
  window.addEventListener('pointerdown', onPointerDown, true);
  window.addEventListener('click', onClick, true);
  window.addEventListener('dragenter', onDragOver, true);
  window.addEventListener('dragover', onDragOver, true);
  window.addEventListener('dragleave', onDragLeave, true);
  window.addEventListener('drop', onDrop, true);
  document.documentElement.addEventListener('mouseleave', function () {
    hovered = null;
    showHover(null, selectedChips());
  });
  EDIT_EVENTS.forEach(function (type) {
    window.addEventListener(type, onEditEvent, true);
  });
  EDITOR_EVENTS.forEach(function (type) {
    editorHost().addEventListener(type, function (event) { event.stopPropagation(); });
  });
}
