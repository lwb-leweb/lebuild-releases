import { state, labelFor, flatten } from '../modules/core.js';
import { attachTextEditing, sanitizeTextMarkup, cleanLinkTarget, linkTargetMessage } from './text-markup.js';
import { beginEdit, endEdit, activeEdit, record, onContentChange, editChanged } from './session.js';
import { fieldValue, FIELD_KIND, TEXT_KINDS } from './page-sync.js';
import { addMenuButton, notify } from './bar.js';
import { openPanel, closePanel, isPanelOpen } from './panel.js';
import { pageImagePicker, pageImageDropArea } from './field-editors.js';

// „Alle Texte dieser Seite“: Seitenpanel mit allen Feldern der Seite samt Komponenten, auch
// solchen, die man auf der Seite nicht anklicken kann (Seitentitel, Beschreibung, Alt-Texte,
// versteckte Slider-Elemente). Jede Eingabe ist eine laufende Bearbeitung wie am Element:
// Verlassen des Feldes übernimmt sie als eine Änderung (Zähler, Rückgängig, Speichern), Esc verwirft.

const FIELDS_KEY = 'fields';
const FIELDS_TEXT = {
  button: 'Alle Texte dieser Seite',
  buttonNote: 'Auch Google-Titel, Beschreibung und Bildtexte',
  eyebrow: 'Diese Seite',
  title: 'Alle Texte',
  filter: 'Felder filtern',
  empty: 'Diese Seite hat keine Felder.'
};
// Klassen der Text-Bearbeitung im Panel (edit.css).
const PANEL_TEXT_CLASSES = {
  toolbar: 'le-field__toolbar',
  linkRow: 'le-field__link',
  button: 'le-btn le-btn--small',
  secondary: 'le-btn--secondary',
  hidden: 'le-hidden'
};
// Seitentitel und Seitenbeschreibung (Import: meta.page_title, meta.description): Zeichenzähler darunter, ab
// so vielen Zeichen kürzt Google sie in den Suchergebnissen ab.
const SEARCH_LIMITS = { 'meta.page_title': 60, 'meta.description': 160 };
const SEARCH_TEXT = {
  count: '%d von etwa %m Zeichen, die Google zeigt',
  over: '%d Zeichen: Google kürzt nach etwa %m ab',
  empty: 'Leer: Google sucht sich selbst einen Text aus der Seite'
};
const SEARCH_CLASSES = { count: 'le-field__count', over: 'le-field__count--over' };
const IMAGE_KINDS = [FIELD_KIND.image, FIELD_KIND.background];
// Eine Zeile reiner Text: Link-Ziel, Alt-Text und Rohtext wie der Seitentitel (Feldart plain).
const LINE_KINDS = [FIELD_KIND.url, FIELD_KIND.alt, FIELD_KIND.plain];

// Zeilen des offenen Panels: { path, element, haystack(), show() }.
let rows = [];

// Bearbeitung eines Panel-Feldes: beginnt beim Hineingehen, endet beim Verlassen (übernimmt).
// read(): Wert im Feld, write(value): Wert zeigen, accept(value) (optional): gespeicherter Wert
// oder null bei unerlaubtem (die Bearbeitung bleibt dann offen), onOpen/onClose: Leiste zeigen,
// escape() (optional): true, wenn Esc nur etwas im Feld schließt (Link-Zeile) statt zu verwerfen.
// Nach dem Ende verlässt der Cursor das Feld, damit jede neue Eingabe wieder eine Bearbeitung ist.
function trackEditing(row, field, options) {
  let editor = null;
  let leaving = false;
  field.addEventListener('focusin', function () {
    if (editor && activeEdit() === editor) return;
    if (!endEdit(true)) {
      field.blur();
      return;
    }
    const before = fieldValue(row.path);
    editor = {
      contains: function () { return false; },
      owns: function (node) { return row.element.contains(node); },
      handlers: null,
      escape: function () { return options.escape ? options.escape() : false; },
      isDirty: function () { return options.read() !== before; },
      commit: function () {
        const value = options.read();
        const after = value !== before && options.accept ? options.accept(value) : value;
        if (after === null) return false;
        record([{ path: row.path, before: before, after: after }]);
        return true;
      },
      cancel: function () { options.write(before); },
      close: function () {
        if (options.onClose) options.onClose();
        if (!leaving) field.blur();
      }
    };
    beginEdit(editor);
    if (options.onOpen) options.onOpen();
  });
  // Speichern und Rückgängig werden aktiv, sobald im Feld etwas anders ist.
  field.addEventListener('input', function () {
    if (editor && activeEdit() === editor) editChanged();
  });
  row.element.addEventListener('focusout', function (event) {
    // Klicks in die eigene Leiste (Fett, Link-Zeile) beenden die Bearbeitung nicht.
    if (!editor || activeEdit() !== editor || row.element.contains(event.relatedTarget)) return;
    leaving = true;
    endEdit(true);
    leaving = false;
  });
}

// Text und Linktext: bearbeitbare Fläche mit Fett, Kursiv, Link (Leiste nur während der Bearbeitung).
function textEditor(row, kind) {
  const inLink = kind === FIELD_KIND.linktext;
  const area = document.createElement('div');
  area.className = 'le-field__area';
  area.contentEditable = 'true';
  const editing = attachTextEditing(area, { inLink: inLink, classes: PANEL_TEXT_CLASSES, onMessage: notify });
  Object.keys(editing.handlers).forEach(function (type) {
    area.addEventListener(type, editing.handlers[type]);
  });
  editing.toolbar.classList.add(PANEL_TEXT_CLASSES.hidden);
  row.element.appendChild(editing.toolbar);
  if (!inLink) row.element.appendChild(editing.linkRow);
  row.element.appendChild(area);
  const write = function (value) { area.innerHTML = sanitizeTextMarkup(value, inLink); };
  row.show = function () { write(fieldValue(row.path)); };
  trackEditing(row, area, {
    read: function () { return sanitizeTextMarkup(area.innerHTML, inLink); },
    write: write,
    escape: editing.closeLinkRow,
    onOpen: function () { editing.toolbar.classList.remove(PANEL_TEXT_CLASSES.hidden); },
    onClose: function () {
      editing.toolbar.classList.add(PANEL_TEXT_CLASSES.hidden);
      editing.linkRow.classList.add(PANEL_TEXT_CLASSES.hidden);
    }
  });
}

// Link-Ziel, Alt-Text und Klartext (Seitentitel): eine Zeile reiner Text; Enter übernimmt. Ein
// geändertes Link-Ziel muss erlaubt sein (wie am Element), ein unverändertes bleibt.
function lineEditor(row, kind) {
  const input = document.createElement('input');
  input.type = 'text';
  if (kind === FIELD_KIND.url) input.inputMode = 'url';
  input.addEventListener('keydown', function (event) {
    if (event.key !== 'Enter') return;
    event.preventDefault();
    endEdit(true);
  });
  row.element.appendChild(input);
  const count = searchCounter(row, input);
  const write = function (value) { input.value = value; count(); };
  row.show = function () { write(fieldValue(row.path)); };
  trackEditing(row, input, {
    read: function () { return input.value; },
    write: write,
    accept: kind === FIELD_KIND.url ? function (value) {
      const href = cleanLinkTarget(value);
      if (href !== '') return href;
      notify(linkTargetMessage());
      input.focus();
      return null;
    } : null
  });
}

// Zeichenzähler unter Seitentitel und Seitenbeschreibung (SEARCH_LIMITS), zählt bei jeder Eingabe mit; für
// andere Felder nichts. Liefert die Funktion, die ihn auf den Wert im Feld bringt.
function searchCounter(row, input) {
  const limit = SEARCH_LIMITS[row.path.split('.').slice(-2).join('.')];
  if (!limit) return function () {};
  const note = document.createElement('small');
  note.className = SEARCH_CLASSES.count;
  note.setAttribute('aria-live', 'polite');
  row.element.appendChild(note);
  const update = function () {
    const length = Array.from(input.value.trim()).length;
    const text = length === 0 ? SEARCH_TEXT.empty : (length > limit ? SEARCH_TEXT.over : SEARCH_TEXT.count);
    note.textContent = text.replace('%d', String(length)).replace('%m', String(limit));
    note.classList.toggle(SEARCH_CLASSES.over, length > limit || length === 0);
  };
  input.addEventListener('input', update);
  return update;
}

// Bild und Hintergrundbild: Ablagefläche mit Vorschau und Dateiauswahl; das hochgeladene Bild ist
// gleich eine Änderung.
function imageEditor(row) {
  const picker = pageImagePicker(function (url) {
    if (!endEdit(true)) return;
    record([{ path: row.path, before: fieldValue(row.path), after: url }]);
  });
  // Eine laufende Bearbeitung zuerst übernehmen; scheitert das, öffnet keine Dateiauswahl.
  picker.element.addEventListener('click', function (event) {
    if (!endEdit(true)) event.preventDefault();
  });
  const area = pageImageDropArea(picker);
  row.element.append(area.element, picker.element);
  row.show = function () {
    area.show(fieldValue(row.path));
  };
}

function buildRow(path, kind) {
  const element = document.createElement('div');
  element.className = 'le-field le-field--panel';
  const label = document.createElement('span');
  label.className = 'le-field__label';
  label.textContent = labelFor(path);
  element.appendChild(label);
  const row = {
    path: path,
    element: element,
    show: null,
    haystack: function () { return (path + ' ' + labelFor(path) + ' ' + fieldValue(path)).toLowerCase(); }
  };
  if (TEXT_KINDS.indexOf(kind) !== -1) textEditor(row, kind);
  else if (LINE_KINDS.indexOf(kind) !== -1) lineEditor(row, kind);
  else imageEditor(row);
  row.show();
  return row;
}

// Zeigt die aktuellen Werte (nach Rückgängig oder einer Änderung auf der Seite), außer im Feld,
// das gerade bearbeitet wird.
function refresh() {
  rows.forEach(function (row) {
    if (!row.element.contains(row.element.getRootNode().activeElement)) row.show();
  });
}

function applyFilter(query) {
  const needle = query.trim().toLowerCase();
  rows.forEach(function (row) {
    row.element.hidden = needle !== '' && row.haystack().indexOf(needle) === -1;
  });
}

// Felder in der Reihenfolge des Inhalts; nur solche, deren Art der Server kennt (sonst
// ließe sich das Feld nicht speichern).
function openFields() {
  openPanel({
    key: FIELDS_KEY,
    eyebrow: FIELDS_TEXT.eyebrow,
    title: FIELDS_TEXT.title,
    onClose: function () { rows = []; }
  }).then(function (body) {
    if (body) fillFields(body);
  });
}

function fillFields(body) {
  const filter = document.createElement('input');
  filter.type = 'search';
  filter.className = 'le-panel__filter';
  filter.placeholder = FIELDS_TEXT.filter;
  filter.addEventListener('input', function () { applyFilter(filter.value); });
  body.appendChild(filter);

  rows = flatten(state.content)
    .filter(function (entry) {
      const kind = state.fieldKinds[entry.path];
      return TEXT_KINDS.concat(LINE_KINDS, IMAGE_KINDS).indexOf(kind) !== -1;
    })
    .map(function (entry) { return buildRow(entry.path, state.fieldKinds[entry.path]); });
  if (!rows.length) {
    const note = document.createElement('p');
    note.className = 'le-panel__note';
    note.textContent = FIELDS_TEXT.empty;
    body.appendChild(note);
  }
  rows.forEach(function (row) { body.appendChild(row.element); });
}

export function mountAllFields() {
  addMenuButton('list', FIELDS_TEXT.button, FIELDS_TEXT.buttonNote, function () {
    if (isPanelOpen(FIELDS_KEY)) closePanel();
    else openFields();
  });
  onContentChange(refresh);
}
