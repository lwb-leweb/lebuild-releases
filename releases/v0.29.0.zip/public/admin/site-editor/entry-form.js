import { imagePicker, imageDropArea, uploadPending, uploadForm, uploadImage, imageAccept, draggingFiles } from './upload.js';
import { editorButton } from './buttons.js';
import { richTextEditor } from './richtext.js';
import { iconGrid, ICON_TEXT } from './icon-grid.js';
import { icon } from './icons.js';
import { errorNotice, editorPost } from './request.js';

// Formular für einen Plugin-Eintrag aus dem Schema seines Typs (schema.fields bzw. Typ-JSON der
// Content-Typen). Die eine Quelle für Seiten-Editor (Panel im Shadow-DOM, plugin-lists.js) und
// Backend (Modal: generische Plugin-Ansicht, Plugins über ctx.ui.openEntryForm). Gebaut wird per
// DOM (textContent, value), Eintragswerte und Feldnamen können kein Markup einschleusen.

export const ENTRY_TEXT = {
  add: 'Neu',
  edit: 'Bearbeiten',
  save: 'Speichern',
  cancel: 'Abbrechen',
  untitled: '(ohne Titel)',
  // Speichern mit veraltetem Stand (409 conflict, plugin_entry_conflict_check): Rückfrage im Backend-Modal.
  conflictPanel: 'Jemand anderes hat diesen Eintrag gespeichert, seit du ihn geöffnet hast. Deine Fassung überschreibt die andere ganz.',
  conflictAsk: 'Jemand anderes hat diesen Eintrag inzwischen geändert.\n\nOK: deine Fassung speichern (überschreibt die andere).\nAbbrechen: nichts speichern.',
  conflictTheirs: 'Stattdessen die andere Fassung ins Formular laden? Deine Eingaben gehen dabei verloren.',
  emptyOption: '—',
  deleteQuestion: '‚{name}‘ löschen?',
  otherImage: 'Anderes Bild',
  remove: 'Entfernen',
  richtextRequired: '„{name}“ bitte ausfüllen.',
  addRow: '+ {name} hinzufügen',
  addRowFallback: '+ Zeile hinzufügen',
  addOption: '+ {name} hinzufügen',
  addOptionPrompt: '{name} hinzufügen:',
  rowUp: '↑',
  rowDown: '↓',
  rowUpLabel: 'Nach oben',
  rowDownLabel: 'Nach unten',
  slugEdit: 'Adresse ändern',
  slugAuto: 'entsteht beim Speichern aus „{name}“',
  addImages: '+ {name} hinzufügen',
  imagesUploaded: '{count} Bilder hochgeladen.',
  imageReplace: 'Bild ersetzen (ziehen zum Verschieben)',
  imageMissing: 'Bild wählen',
  imageUploading: 'Lädt …',
  imageBefore: 'Nach vorne',
  imageAfter: 'Nach hinten',
  imageRemove: 'Bild entfernen',
  imagesTooMany: 'Höchstens {max} {name}; die übrigen Dateien sind nicht hochgeladen.',
  addBlock: '+ {name}',
  blockCollapse: 'Einklappen',
  blockExpand: 'Aufklappen',
  blockImages: '{count} Fotos',
  blockFiles: '{count} Downloads',
  blockRemove: 'Block entfernen',
  blockMove: 'Ziehen zum Verschieben'
};
// Felder, die einen Eintrag benennen (vor dem ersten Textfeld).
const TITLE_FIELDS = ['name', 'title'];
const TITLE_FALLBACK_TYPE = 'text';
// Feldart → type des <input>; alle übrigen Arten (text, slug, …) sind Textfelder.
const INPUT_TYPES = {
  number: 'number',
  datetime: 'datetime-local',
  date: 'date'
};
const INPUT_TYPE_TEXT = 'text';
// Eingabefelder, die focus() bzw. eine neue Zeile in list zuerst anspricht.
const FOCUS_TARGET = 'input:not([type="file"]):not([type="hidden"]):not([hidden]), select, textarea:not([hidden]), [contenteditable="true"]';
// Feldart → inputmode (Tastatur am Handy); geprüft wird die Adresse auf dem Server.
const INPUT_MODES = {
  url: 'url'
};
// Formular mit split: Felder dieser Arten (Angaben wie Kategorie, Datum, Bild) kommen in die Spalte look.side,
// Zeilen und Blöcke (list, blocks) unter beide Spalten (look.full), die übrigen (Titel, Texte) in look.main; ohne Felder einer
// Gruppe bleibt es einspaltig.
// Eine Adresse (slug) mit from steht ohnehin unter ihrem Quellfeld (meist der Titel).
const SIDE_FIELD_TYPES = ['select', 'datetime', 'date', 'number', 'boolean', 'url', 'image', 'icon'];
// Klassen im Backend-Modal (styles.css).
const BACKEND_LOOK = {
  form: 'settings-form entry-form',
  field: 'field',
  labelTag: 'small',
  label: '',
  checkbox: 'field field--checkbox',
  picker: 'entry-form__picker',
  image: 'entry-form__image',
  imageEmpty: 'entry-form__image-empty',
  imageDrop: 'entry-form__drop',
  imageDropActive: 'entry-form__drop--active',
  imageActions: 'entry-form__image-actions',
  list: 'entry-form__list',
  listRow: 'entry-form__row',
  listRowActions: 'entry-form__row-actions',
  iconGrid: { grid: 'entry-form__icons', item: 'entry-form__icon', empty: 'entry-form__icons-empty' },
  iconButton: 'entry-form__icon-btn',
  slug: 'entry-form__slug',
  slugText: 'entry-form__slug-text',
  slugAuto: 'entry-form__slug-text--auto',
  slugInput: 'entry-form__slug-input',
  gallery: 'entry-form__gallery',
  galleryActive: 'entry-form__gallery--active',
  galleryTile: 'entry-form__tile',
  galleryPending: 'entry-form__tile--pending',
  galleryMedia: 'entry-form__tile-media',
  galleryCaption: 'entry-form__tile-caption',
  galleryActions: 'entry-form__tile-actions',
  blocks: 'entry-form__blocks',
  block: 'entry-form__block',
  blockHead: 'entry-form__block-head',
  blockTitle: 'entry-form__block-title',
  blockSummary: 'entry-form__block-summary',
  blockBody: 'entry-form__block-body',
  blockCollapsed: 'entry-form__block--collapsed',
  blockAdd: 'entry-form__block-add'
};

// Beschriftung eines Feldes: label aus dem Schema, sonst sein Name.
export function fieldLabel(field) {
  return field.label ? field.label : field.name;
}

// Feld, das einen Eintrag benennt: name oder title, sonst das erste Textfeld (null ohne).
export function titleField(schema) {
  const named = schema.find(function (field) { return TITLE_FIELDS.indexOf(field.name) !== -1; });
  if (named) return named.name;
  const text = schema.find(function (field) { return field.type === TITLE_FALLBACK_TYPE; });
  return text ? text.name : null;
}

// Anzeigename eines Eintrags (Listen im Backend, Nachfrage beim Löschen).
export function entryTitle(schema, row) {
  const name = titleField(schema);
  if (!name) return '#' + row.id;
  return row[name] ? String(row[name]) : ENTRY_TEXT.untitled;
}

// „‚Max Muster‘ löschen?“ – als Text für confirm(), nie als HTML.
export function deleteQuestion(schema, row) {
  // Ersatz als Funktion: „$&“ o. Ä. im Namen bleibt wörtlich stehen.
  const title = entryTitle(schema, row);
  return ENTRY_TEXT.deleteQuestion.replace('{name}', function () { return title; });
}

// Wert für das Eingabefeld: Datum aus der Datenbank („2026-10-15 09:30:00“) für datetime-local.
function formatInputValue(field, value) {
  if (field.type === 'datetime' && value) {
    return String(value).replace(' ', 'T').slice(0, 16);
  }
  return value == null ? '' : String(value);
}

function fieldBox(look, field, tag) {
  const box = document.createElement(tag);
  box.className = look.field;
  const label = document.createElement(look.labelTag);
  if (look.label) label.className = look.label;
  label.textContent = fieldLabel(field);
  box.appendChild(label);
  return box;
}

// Wert der Option „+ … hinzufügen“: Steuerzeichen, die in keinem gespeicherten Wert vorkommen (sanitize_plain_text).
const CREATE_OPTION_VALUE = '\u0000create';

// Auswahl: Wert ist die Option, angezeigt wird ihre Beschriftung aus optionLabels, sonst die Option selbst.
// Mit optionsCreate (Content-Typen, optionsFrom) kommt „+ <Feld> hinzufügen“ dazu (createOption).
function selectInput(field, value, notify) {
  const select = document.createElement('select');
  if (!field.required) select.add(new Option(ENTRY_TEXT.emptyOption, ''));
  const labels = field.optionLabels && typeof field.optionLabels === 'object' ? field.optionLabels : {};
  (Array.isArray(field.options) ? field.options : []).forEach(function (option) {
    if (typeof option !== 'string') return;
    select.add(new Option(Object.prototype.hasOwnProperty.call(labels, option) ? labels[option] : option, option));
  });
  const create = field.optionsCreate && typeof field.optionsCreate === 'object' ? new Option('', CREATE_OPTION_VALUE) : null;
  if (create) select.add(create);
  select.value = value;
  // Pflichtfeld ohne passende Option: nichts gewählt (der Browser meldet es), nie „+ … hinzufügen“.
  if (select.value === CREATE_OPTION_VALUE) select.selectedIndex = -1;
  if (create) createOption(field, select, create, notify);
  return select;
}

// „+ <Feld> hinzufügen“ am Ende der Auswahl: fragt nach dem Namen, legt ihn als Eintrag im anderen Typ an
// (optionsCreate: { url, type, field }) und wählt ihn. Gibt es ihn schon, wird er nur gewählt; abgebrochen
// oder fehlgeschlagen (Hinweis über notify) gilt wieder die vorige Auswahl.
function createOption(field, select, option, notify) {
  const create = field.optionsCreate;
  const name = fieldLabel(field);
  const fill = function (text) { return text.replace('{name}', function () { return name; }); };
  option.text = fill(ENTRY_TEXT.addOption);
  let previous = select.value;
  // Wert wählen; gibt es ihn nicht (leer bei Pflicht), ist nichts gewählt.
  const choose = function (value) {
    select.value = value;
    if (select.value !== value) select.selectedIndex = -1;
    previous = select.value;
  };
  select.addEventListener('change', function () {
    if (select.value !== CREATE_OPTION_VALUE) {
      previous = select.value;
      return;
    }
    choose(previous);
    const text = (window.prompt(fill(ENTRY_TEXT.addOptionPrompt)) || '').trim();
    if (!text) return;
    if (Array.prototype.some.call(select.options, function (entry) { return entry !== option && entry.value === text; })) {
      choose(text);
      return;
    }
    const data = {};
    data[create.field] = text;
    select.disabled = true;
    editorPost(create.url, { type: create.type, data: data }).then(function () {
      select.insertBefore(new Option(text, text), option);
      choose(text);
      select.dispatchEvent(new Event('input', { bubbles: true }));
    }).catch(function (error) {
      const notice = errorNotice(error);
      if (notify) notify(notice.message, notice.action);
    }).finally(function () {
      select.disabled = false;
      select.focus();
    });
  });
}

// Bildfeld: Ablagefläche mit Vorschau (ohne Bild der Hinweis zum Hineinziehen), Dateiauswahl mit
// sofortigem Upload und „Entfernen“. Die URL steht im versteckten Eingabefeld; Änderungen melden
// sich als input am Formular (ungespeicherte Eingaben). Hochgeladen wird für das Formular uploads.
function imageField(look, field, input, notify, uploads) {
  const box = fieldBox(look, field, 'div');
  input.type = 'hidden';
  const set = function (url) {
    input.value = url;
    show();
    input.dispatchEvent(new Event('input', { bubbles: true }));
  };
  const picker = imagePicker(set, notify, look.picker, uploads);
  const area = imageDropArea(picker, { drop: look.imageDrop, active: look.imageDropActive, image: look.image, empty: look.imageEmpty });
  const remove = editorButton(ENTRY_TEXT.remove, look.picker, function () { set(''); });
  const chooseText = picker.element.firstChild.nodeValue;
  const show = function () {
    area.show(input.value);
    remove.hidden = !input.value;
    picker.element.firstChild.nodeValue = input.value ? ENTRY_TEXT.otherImage : chooseText;
  };
  show();
  const actions = document.createElement('div');
  actions.className = look.imageActions;
  actions.append(picker.element, remove);
  box.append(input, area.element, actions);
  return box;
}

// Icon-Feld: Suche und Raster aller Icons wie im Seiten-Editor (icon-grid.js); der Name steht im
// versteckten Eingabefeld, ohne Pflicht gibt es „Entfernen“. Änderungen melden sich als input am Formular.
function iconField(look, field, input, notify) {
  const box = fieldBox(look, field, 'div');
  input.type = 'hidden';
  const set = function (name) {
    input.value = name;
    remove.hidden = !name;
    input.dispatchEvent(new Event('input', { bubbles: true }));
  };
  const icons = iconGrid(look.iconGrid, input.value, set);
  icons.search.placeholder = ICON_TEXT.search;
  icons.search.setAttribute('aria-label', ICON_TEXT.search);
  const remove = editorButton(ENTRY_TEXT.remove, look.picker, function () {
    icons.select('');
    set('');
  });
  remove.hidden = !input.value;
  box.append(input, icons.search, icons.grid, icons.empty);
  if (!field.required) box.appendChild(remove);
  icons.ready.catch(function (error) {
    const notice = errorNotice(error);
    if (notify) notify(notice.message, notice.action);
  });
  return box;
}

// Ein Feld des Formulars aus dem Schema: { box, input, read() }; read() = Wert (boolean '1'/'0', list
// die Zeilen). ctx: { look, notify, uploads, editors, beforeCheck, row }; Texteditoren kommen mit ctx.row (Zeile
// eines list-Feldes, sonst undefined) nach ctx.editors (Pflicht prüft check()).
// Knopf nur mit Symbol (icons.js); label für Screenreader und Tooltip.
function symbolButton(name, label, className, onClick) {
  const button = editorButton('', className, onClick);
  button.append(icon(name));
  button.title = label;
  button.setAttribute('aria-label', label);
  return button;
}

// Mehrzeiliges Textfeld wächst mit seinem Inhalt (bis zur Höchsthöhe aus dem CSS, dann scrollt es),
// statt den Text unten abzuschneiden. Gemessen wird erst, wenn es im Dokument steht.
function autoGrow(textarea) {
  const fit = function () {
    if (!textarea.isConnected) return;
    textarea.style.height = 'auto';
    textarea.style.height = (textarea.scrollHeight + textarea.offsetHeight - textarea.clientHeight) + 'px';
  };
  textarea.addEventListener('input', fit);
  textarea.addEventListener('focus', fit);
  window.requestAnimationFrame(fit);
}

// Adresse (slug): als Text unter ihrem Quellfeld (Präfix aus dem Schema, z. B. „/aktuelles/“), erst der
// Stift macht sie zum Eingabefeld; leer steht da, woraus sie beim Speichern entsteht.
function slugField(look, field, input, sourceLabel) {
  const box = document.createElement('div');
  box.className = look.slug;
  const text = document.createElement('span');
  text.className = look.slugText;
  const auto = ENTRY_TEXT.slugAuto.replace('{name}', function () { return sourceLabel || fieldLabel(field); });
  const show = function () {
    text.textContent = input.value ? (field.prefix || '') + input.value : auto;
    text.classList.toggle(look.slugAuto, !input.value);
  };
  let editing = false;
  // Beim Bearbeiten bleibt nur das Präfix als Text vor dem Feld.
  const edit = symbolButton('pencil', ENTRY_TEXT.slugEdit, look.iconButton, function () {
    editing = true;
    text.textContent = field.prefix || '';
    text.classList.remove(look.slugAuto);
    text.hidden = !field.prefix;
    edit.hidden = true;
    input.hidden = false;
    input.focus();
  });
  input.className = look.slugInput;
  input.hidden = true;
  input.setAttribute('aria-label', fieldLabel(field));
  input.addEventListener('input', function () { if (!editing) show(); });
  show();
  box.append(text, edit, input);
  return box;
}

// Bildfeld einer list, die als Raster erscheint (galleryField): genau ein image-Unterfeld, sonst nur Texte.
function galleryImage(field) {
  const subs = Array.isArray(field.fields) ? field.fields : [];
  const images = subs.filter(function (sub) { return sub.type === 'image'; });
  const plain = subs.every(function (sub) { return sub.type === 'image' || sub.type === 'text'; });
  return images.length === 1 && plain ? images[0] : null;
}

// list mit Bildern (galleryImage) als Raster: je Zeile eine Kachel mit Bild (Klick ersetzt es, Ziehen
// verschiebt die Kachel), kleinen Textfeldern für die übrigen Unterfelder, ←/→ und Entfernen. „+ … hinzufügen“
// und auf das Raster gezogene Dateien laden mehrere Bilder auf einmal hoch (höchstens field.max Zeilen),
// jedes wird eine Zeile. Änderungen melden sich als input am Formular; read() wie listField.
function galleryField(field, value, ctx, imageSub) {
  const look = ctx.look;
  const box = fieldBox(look, field, 'div');
  const grid = document.createElement('div');
  grid.className = look.gallery;
  const texts = field.fields.filter(function (sub) { return sub !== imageSub; });
  const max = Number(field.max) > 0 ? Number(field.max) : Infinity;
  const rows = [];
  let dragged = null;
  const changed = function () { grid.dispatchEvent(new Event('input', { bubbles: true })); };
  const refresh = function () {
    rows.forEach(function (row, index) {
      row.before.disabled = index === 0;
      row.after.disabled = index === rows.length - 1;
    });
    add.hidden = rows.length >= max;
  };
  const move = function (row, to) {
    const from = rows.indexOf(row);
    if (to < 0 || to >= rows.length || to === from) return;
    rows.splice(from, 1);
    rows.splice(to, 0, row);
    grid.insertBefore(row.tile, rows[to + 1] ? rows[to + 1].tile : null);
    refresh();
    changed();
  };
  const addTile = function (values) {
    const tile = document.createElement('div');
    tile.className = look.galleryTile;
    const row = { tile: tile, image: values && values[imageSub.name] ? String(values[imageSub.name]) : '', captions: [] };
    const media = editorButton('', look.galleryMedia, function () { replace.input.click(); });
    const img = document.createElement('img');
    img.alt = '';
    img.loading = 'lazy';
    const missing = document.createElement('span');
    missing.textContent = ENTRY_TEXT.imageMissing;
    media.append(img, missing);
    row.missing = missing;
    row.show = function () {
      img.hidden = !row.image;
      missing.hidden = Boolean(row.image);
      if (row.image) img.src = row.image;
      media.title = row.image ? ENTRY_TEXT.imageReplace : ENTRY_TEXT.imageMissing;
      media.setAttribute('aria-label', media.title);
    };
    const replace = imagePicker(function (url) {
      row.image = url;
      row.show();
      changed();
    }, ctx.notify, look.picker, ctx.uploads);
    replace.element.hidden = true;
    // Ziehen nur am Bild, damit Text in den Feldern markierbar bleibt.
    media.addEventListener('pointerdown', function () { tile.draggable = true; });
    tile.addEventListener('dragstart', function (event) {
      dragged = row;
      event.dataTransfer.effectAllowed = 'move';
    });
    tile.addEventListener('dragend', function () {
      tile.draggable = false;
      dragged = null;
    });
    tile.addEventListener('dragover', function (event) {
      if (!dragged || dragged === row) return;
      event.preventDefault();
      event.dataTransfer.dropEffect = 'move';
    });
    tile.addEventListener('drop', function (event) {
      if (!dragged || dragged === row) return;
      event.preventDefault();
      event.stopPropagation();
      move(dragged, rows.indexOf(row));
    });
    tile.append(media, replace.element);
    texts.forEach(function (sub) {
      const input = document.createElement('input');
      input.type = 'text';
      input.name = sub.name;
      input.className = look.galleryCaption;
      input.placeholder = fieldLabel(sub);
      input.setAttribute('aria-label', fieldLabel(sub));
      input.value = values && values[sub.name] != null ? String(values[sub.name]) : '';
      if (sub.required) input.required = true;
      row.captions.push({ field: sub, input: input });
      tile.appendChild(input);
    });
    const actions = document.createElement('div');
    actions.className = look.galleryActions;
    row.before = rowButton('←', ENTRY_TEXT.imageBefore, look.iconButton, function () { move(row, rows.indexOf(row) - 1); });
    row.after = rowButton('→', ENTRY_TEXT.imageAfter, look.iconButton, function () { move(row, rows.indexOf(row) + 1); });
    row.remove = function () {
      const index = rows.indexOf(row);
      if (index === -1) return;
      rows.splice(index, 1);
      tile.remove();
      refresh();
      changed();
    };
    actions.append(row.before, row.after, symbolButton('trash', ENTRY_TEXT.imageRemove, look.iconButton, function () {
      const index = rows.indexOf(row);
      row.remove();
      const next = rows[index] || rows[index - 1];
      (next ? next.tile.querySelector('button') : add).focus();
    }));
    tile.appendChild(actions);
    row.show();
    rows.push(row);
    grid.appendChild(tile);
    refresh();
    return row;
  };
  // Mehrere Dateien: je eine Kachel, die bis zum Upload wartet; scheitert er, fällt sie weg (Meldung über notify).
  const uploadFiles = function (files) {
    const free = max - rows.length;
    const name = fieldLabel(field);
    if (files.length > free) ctx.notify(ENTRY_TEXT.imagesTooMany.replace('{max}', String(max)).replace('{name}', function () { return name; }));
    const jobs = files.slice(0, Math.max(free, 0)).map(function (file) {
      const row = addTile(null);
      row.tile.classList.add(look.galleryPending);
      row.missing.textContent = ENTRY_TEXT.imageUploading;
      return uploadImage(file, ctx.notify, ctx.uploads, true).then(function (url) {
        row.image = url;
        row.tile.classList.remove(look.galleryPending);
        row.show();
        changed();
      }, function (error) {
        row.remove();
        throw error;
      });
    });
    if (!jobs.length) return;
    changed();
    Promise.allSettled(jobs).then(function (results) {
      const done = results.filter(function (result) { return result.status === 'fulfilled'; }).length;
      if (done) ctx.notify(ENTRY_TEXT.imagesUploaded.replace('{count}', String(done)));
    });
  };
  const add = document.createElement('label');
  add.className = look.picker;
  add.textContent = ENTRY_TEXT.addImages.replace('{name}', function () { return fieldLabel(field); });
  const many = document.createElement('input');
  many.type = 'file';
  many.multiple = true;
  many.accept = imageAccept();
  many.hidden = true;
  many.addEventListener('change', function () {
    const files = Array.from(many.files || []);
    many.value = '';
    uploadFiles(files);
  });
  add.appendChild(many);
  // Dateien auf das Raster ziehen (Zähler wie imageDropArea: Kinder melden dragleave am Rahmen).
  let depth = 0;
  grid.addEventListener('dragenter', function (event) {
    if (!draggingFiles(event)) return;
    event.preventDefault();
    if (++depth === 1) grid.classList.add(look.galleryActive);
  });
  grid.addEventListener('dragover', function (event) {
    if (!draggingFiles(event)) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = 'copy';
  });
  grid.addEventListener('dragleave', function () {
    if (depth > 0 && --depth === 0) grid.classList.remove(look.galleryActive);
  });
  grid.addEventListener('drop', function (event) {
    if (!draggingFiles(event)) return;
    event.preventDefault();
    depth = 0;
    grid.classList.remove(look.galleryActive);
    uploadFiles(Array.from(event.dataTransfer.files));
  });
  (Array.isArray(value) ? value : []).forEach(addTile);
  box.append(grid, add);
  refresh();
  return {
    box: box,
    input: null,
    read: function () {
      return rows.map(function (row) {
        const data = {};
        data[imageSub.name] = row.image;
        row.captions.forEach(function (caption) { data[caption.field.name] = caption.input.value; });
        return data;
      });
    }
  };
}

function buildField(field, rawValue, ctx) {
  if (field.type === 'blocks') return blocksField(field, rawValue, ctx);
  if (field.type === 'list') {
    const image = galleryImage(field);
    return image ? galleryField(field, rawValue, ctx, image) : listField(field, rawValue, ctx);
  }
  const look = ctx.look;
  const value = formatInputValue(field, rawValue);
  let input;
  let box;
  if (field.type === 'boolean') {
    input = document.createElement('input');
    input.type = 'checkbox';
    input.checked = value !== '' && value !== '0';
    box = document.createElement('label');
    box.className = look.checkbox;
    const line = document.createElement('span');
    line.append(input, ' ' + fieldLabel(field));
    box.appendChild(line);
  } else if (field.type === 'richtext' || field.type === 'textarea') {
    input = document.createElement('textarea');
    input.value = value;
    if (field.type === 'textarea') autoGrow(input);
  } else if (field.type === 'select') {
    input = selectInput(field, value, ctx.notify);
  } else {
    input = document.createElement('input');
    input.type = Object.prototype.hasOwnProperty.call(INPUT_TYPES, field.type) ? INPUT_TYPES[field.type] : INPUT_TYPE_TEXT;
    if (Object.prototype.hasOwnProperty.call(INPUT_MODES, field.type)) input.inputMode = INPUT_MODES[field.type];
    input.value = value;
  }
  // Beispiel im leeren Feld (placeholder aus dem Schema, z. B. „z. B. 8–12, 14–18“).
  if (field.placeholder && (input.tagName === 'INPUT' || input.tagName === 'TEXTAREA')) input.placeholder = field.placeholder;
  input.name = field.name;
  // Ein verstecktes Pflichtfeld kann der Browser nicht melden; das prüft check().
  if (field.required && field.type !== 'richtext') input.required = true;
  if (field.type === 'image') {
    box = imageField(look, field, input, ctx.notify, ctx.uploads);
  } else if (field.type === 'icon') {
    box = iconField(look, field, input, ctx.notify);
  } else if (field.type === 'slug' && ctx.slugSource && ctx.slugSource(field.from)) {
    box = slugField(look, field, input, ctx.slugSource(field.from));
  } else if (field.type === 'richtext') {
    const editor = richTextEditor(input);
    ctx.editors.push({ field: field, input: input, editor: editor, row: ctx.row });
    box = fieldBox(look, field, 'div');
    box.appendChild(editor.element);
  } else if (!box) {
    box = fieldBox(look, field, 'label');
    box.appendChild(input);
  }
  return {
    box: box,
    input: input,
    read: function () { return field.type === 'boolean' ? (input.checked ? '1' : '0') : input.value; }
  };
}

// Leerer Wert einer Zeile wie auf dem Server (plugin_schema_list_values): leer, leeres Kästchen oder keine Zeile.
function emptyRowValue(field, value) {
  return value === '' || (field.type === 'boolean' && value === '0') || (Array.isArray(value) && value.length === 0);
}

// Erstes Eingabefeld in element fokussieren; liefert, ob es eines gab.
function focusFirst(element) {
  const first = element.querySelector(FOCUS_TARGET);
  if (first) first.focus();
  return Boolean(first);
}

// Knopf einer Zeile mit Zeichen statt Text (↑/↓); label für Screenreader und Tooltip.
function rowButton(text, label, className, onClick) {
  const button = editorButton(text, className, onClick);
  button.title = label;
  button.setAttribute('aria-label', label);
  return button;
}

// Feld der Art list: je Zeile eine Karte mit den Unterfeldern, ↑/↓ (am Rand ausgeblendet) und
// Entfernen, darunter „+ <itemLabel> hinzufügen“. Leere Zeilen fallen wie auf dem Server weg, ihre
// Pflicht-Unterfelder gelten nicht (ctx.beforeCheck, check()); min/max prüft der Server. Änderungen
// melden sich als input am Formular (ungespeicherte Eingaben). read() = Zeilen in der angezeigten Reihenfolge.
function listField(field, value, ctx) {
  const look = ctx.look;
  const box = fieldBox(look, field, 'div');
  const list = document.createElement('div');
  list.className = look.list;
  const rows = [];
  const changed = function () { list.dispatchEvent(new Event('input', { bubbles: true })); };
  const refresh = function () {
    rows.forEach(function (row, index) {
      row.up.hidden = index === 0;
      row.down.hidden = index === rows.length - 1;
    });
  };
  const addRow = function (values) {
    const card = document.createElement('div');
    card.className = look.listRow;
    const row = { card: card };
    const rowCtx = Object.assign({}, ctx, { row: row });
    const fields = (Array.isArray(field.fields) ? field.fields : []).map(function (sub) {
      const built = buildField(sub, values && values[sub.name] != null ? values[sub.name] : '', rowCtx);
      card.appendChild(built.box);
      return { field: sub, built: built };
    });
    row.read = function () {
      const data = {};
      fields.forEach(function (sub) { data[sub.field.name] = sub.built.read(); });
      return data;
    };
    row.empty = function () {
      return fields.every(function (sub) { return emptyRowValue(sub.field, sub.built.read()); });
    };
    // Pflicht nur für Zeilen mit Inhalt; Texteditoren prüft check() über row.empty().
    row.require = function () {
      const filled = !row.empty();
      fields.forEach(function (sub) {
        if (sub.field.required && sub.field.type !== 'richtext') sub.built.input.required = filled;
      });
    };
    const move = function (step, button, other) {
      const from = rows.indexOf(row);
      const to = from + step;
      if (to < 0 || to >= rows.length) return;
      rows.splice(from, 1);
      rows.splice(to, 0, row);
      list.insertBefore(card, step < 0 ? rows[to + 1].card : rows[to - 1].card.nextSibling);
      refresh();
      (button.hidden ? other : button).focus();
      changed();
    };
    const remove = function () {
      const index = rows.indexOf(row);
      rows.splice(index, 1);
      card.remove();
      refresh();
      const next = rows[index] || rows[index - 1];
      if (!next || !focusFirst(next.card)) add.focus();
      changed();
    };
    const actions = document.createElement('div');
    actions.className = look.listRowActions;
    row.up = rowButton(ENTRY_TEXT.rowUp, ENTRY_TEXT.rowUpLabel, look.picker, function () { move(-1, row.up, row.down); });
    row.down = rowButton(ENTRY_TEXT.rowDown, ENTRY_TEXT.rowDownLabel, look.picker, function () { move(1, row.down, row.up); });
    actions.append(row.up, row.down, editorButton(ENTRY_TEXT.remove, look.picker, remove));
    card.appendChild(actions);
    rows.push(row);
    list.appendChild(card);
    refresh();
    return card;
  };
  const name = field.itemLabel;
  const add = editorButton(name ? ENTRY_TEXT.addRow.replace('{name}', function () { return name; }) : ENTRY_TEXT.addRowFallback, look.picker, function () {
    focusFirst(addRow(null));
    changed();
  });
  (Array.isArray(value) ? value : []).forEach(addRow);
  ctx.beforeCheck.push(function () { rows.forEach(function (row) { row.require(); }); });
  box.append(list, add);
  return {
    box: box,
    input: null,
    read: function () { return rows.map(function (row) { return row.read(); }); }
  };
}

// Kurzfassung eines eingeklappten Blocks im Kopf: Anfang des Textes, Bildtext oder Zahl der Fotos/Downloads.
const BLOCK_SUMMARY_LENGTH = 80;
function blockSummary(data) {
  const count = function (text, rows) { return Array.isArray(rows) && rows.length ? text.replace('{count}', String(rows.length)) : ''; };
  if (Array.isArray(data.bilder)) return count(ENTRY_TEXT.blockImages, data.bilder);
  if (Array.isArray(data.dateien)) return count(ENTRY_TEXT.blockFiles, data.dateien);
  // Text über DOMParser: im geparsten Dokument lädt und läuft nichts (auch kein onerror an Bildern).
  const parsed = new DOMParser().parseFromString(String(data.text || ''), 'text/html');
  const text = (parsed.body.textContent || '').replace(/\s+/g, ' ').trim();
  return text.length > BLOCK_SUMMARY_LENGTH ? text.slice(0, BLOCK_SUMMARY_LENGTH - 1) + '…' : text;
}

// Feld der Art blocks (kleiner Builder): je Block eine Karte mit Art, ↑/↓, Entfernen und den Feldern seiner
// Art (field.blockTypes vom Server, z. B. Fotos als Bildraster); Ziehen am Kopf verschiebt die Karte. Darunter
// je erlaubter Art „+ Text“, „+ Bild“ …. Vorhandene Blöcke starten eingeklappt (Kopf mit Kurzfassung, blockSummary). Leere Blöcke fallen wie auf dem Server weg, ihre Pflichtfelder gelten
// nicht (ctx.beforeCheck); min/max prüft der Server. read() = [{ type, feld: wert }] in der angezeigten Reihenfolge.
function blocksField(field, value, ctx) {
  const look = ctx.look;
  const types = field.blockTypes && typeof field.blockTypes === 'object' ? field.blockTypes : {};
  const box = fieldBox(look, field, 'div');
  const list = document.createElement('div');
  list.className = look.blocks;
  const max = Number(field.max) > 0 ? Number(field.max) : Infinity;
  const rows = [];
  let dragged = null;
  const changed = function () { list.dispatchEvent(new Event('input', { bubbles: true })); };
  const refresh = function () {
    rows.forEach(function (row, index) {
      row.up.disabled = index === 0;
      row.down.disabled = index === rows.length - 1;
    });
    adds.hidden = rows.length >= max;
  };
  const move = function (row, to) {
    const from = rows.indexOf(row);
    if (to < 0 || to >= rows.length || to === from) return;
    rows.splice(from, 1);
    rows.splice(to, 0, row);
    list.insertBefore(row.card, rows[to + 1] ? rows[to + 1].card : null);
    refresh();
    changed();
  };
  const addBlock = function (type, values) {
    const def = types[type];
    if (!def || !Array.isArray(def.fields)) return null;
    const card = document.createElement('div');
    card.className = look.block;
    const head = document.createElement('div');
    head.className = look.blockHead;
    head.title = ENTRY_TEXT.blockMove;
    const title = document.createElement('span');
    title.className = look.blockTitle;
    title.textContent = def.label;
    const summary = document.createElement('span');
    summary.className = look.blockSummary;
    const body = document.createElement('div');
    body.className = look.blockBody;
    const row = { card: card, type: type };
    // Einklappen: nur der Kopf mit Kurzfassung bleibt; die Felder gehen trotzdem mit.
    row.collapse = function (on) {
      card.classList.toggle(look.blockCollapsed, on);
      body.hidden = on;
      summary.textContent = on ? blockSummary(row.read()) : '';
      toggle.title = on ? ENTRY_TEXT.blockExpand : ENTRY_TEXT.blockCollapse;
      toggle.setAttribute('aria-label', toggle.title);
      toggle.setAttribute('aria-expanded', String(!on));
    };
    const toggle = symbolButton('chevronDown', ENTRY_TEXT.blockCollapse, look.iconButton, function () { row.collapse(!body.hidden); });
    const rowCtx = Object.assign({}, ctx, { row: row });
    row.up = rowButton(ENTRY_TEXT.rowUp, ENTRY_TEXT.rowUpLabel, look.iconButton, function () { move(row, rows.indexOf(row) - 1); });
    row.down = rowButton(ENTRY_TEXT.rowDown, ENTRY_TEXT.rowDownLabel, look.iconButton, function () { move(row, rows.indexOf(row) + 1); });
    const remove = symbolButton('trash', ENTRY_TEXT.blockRemove, look.iconButton, function () {
      const index = rows.indexOf(row);
      rows.splice(index, 1);
      card.remove();
      refresh();
      const next = rows[index] || rows[index - 1];
      (next ? next.up : adds.querySelector('button')).focus();
      changed();
    });
    head.append(toggle, title, summary, row.up, row.down, remove);
    card.append(head, body);
    title.addEventListener('click', function () { row.collapse(!body.hidden); });
    const fields = def.fields.map(function (sub) {
      const built = buildField(sub, values && values[sub.name] != null ? values[sub.name] : (sub.type === 'list' ? [] : ''), rowCtx);
      body.appendChild(built.box);
      return { field: sub, built: built };
    });
    row.read = function () {
      const data = { type: type };
      fields.forEach(function (sub) { data[sub.field.name] = sub.built.read(); });
      return data;
    };
    row.empty = function () {
      return fields.every(function (sub) { return emptyRowValue(sub.field, sub.built.read()); });
    };
    // Vor dem Prüfen: Ein gefüllter Block mit leerem Pflichtfeld klappt auf, damit der Browser bzw. check() es zeigen kann.
    row.require = function () {
      const filled = !row.empty();
      fields.forEach(function (sub) {
        if (sub.field.required && sub.field.type !== 'richtext' && sub.built.input) sub.built.input.required = filled;
      });
      const missing = filled && fields.some(function (sub) { return sub.field.required && emptyRowValue(sub.field, sub.built.read()); });
      if (missing || (filled && body.querySelector(':invalid'))) row.collapse(false);
    };
    // Ziehen nur am Kopf; Bildraster und Listen im Block ziehen ihre eigenen Kacheln.
    head.addEventListener('pointerdown', function (event) {
      if (!event.target.closest('button') && event.target !== title) card.draggable = true;
    });
    card.addEventListener('dragstart', function (event) {
      if (event.target !== card) return;
      dragged = row;
      event.dataTransfer.effectAllowed = 'move';
    });
    card.addEventListener('dragend', function () {
      card.draggable = false;
      dragged = null;
    });
    card.addEventListener('dragover', function (event) {
      if (!dragged || dragged === row) return;
      event.preventDefault();
      event.dataTransfer.dropEffect = 'move';
    });
    card.addEventListener('drop', function (event) {
      if (!dragged || dragged === row) return;
      event.preventDefault();
      move(dragged, rows.indexOf(row));
    });
    rows.push(row);
    list.appendChild(card);
    // Vorhandene Blöcke starten eingeklappt (Überblick), neu angelegte offen.
    if (values) row.collapse(true);
    refresh();
    return row;
  };
  const adds = document.createElement('div');
  adds.className = look.blockAdd;
  Object.keys(types).forEach(function (type) {
    const label = ENTRY_TEXT.addBlock.replace('{name}', function () { return types[type].label; });
    adds.appendChild(editorButton(label, look.picker, function () {
      const row = addBlock(type, null);
      if (row && !focusFirst(row.card)) row.up.focus();
      changed();
    }));
  });
  (Array.isArray(value) ? value : []).forEach(function (block) {
    if (block && typeof block === 'object') addBlock(block.type, block);
  });
  ctx.beforeCheck.push(function () { rows.forEach(function (row) { row.require(); }); });
  box.append(list, adds);
  refresh();
  return {
    box: box,
    input: null,
    read: function () { return rows.map(function (row) { return row.read(); }); }
  };
}

// Feld nur sichtbar, solange ein anderes Feld einen bestimmten Wert hat (showWhen: { field, value }; nur
// Link und Adresse der Content-Typen je nach „Beim Klick“, aus Schemas entfernt der Server es). Versteckte
// Felder gehen trotzdem mit, damit beim Umschalten nichts verloren geht; ob er sie übernimmt, entscheidet der Server.
function applyShowWhen(schema, fields) {
  schema.forEach(function (field) {
    const when = field.showWhen;
    const source = when ? fields[when.field] : null;
    if (!source) return;
    const box = fields[field.name].box;
    const update = function () { box.hidden = source.read() !== when.value; };
    source.box.addEventListener('change', update);
    update();
  });
}

// Baut das Formular. options: { look (Klassen, siehe BACKEND_LOOK), notify (Hinweise beim Upload),
// onSubmit() (Enter in einem Feld), split (zwei Spalten, SIDE_FIELD_TYPES; Klassen look.split, look.main, look.side, look.full) }. Felder ohne Wert im Eintrag (neu, ältere Einträge) starten mit
// default aus dem Schema, sofern angegeben. Liefert { form, check(), values(), focus(), close() }:
// check() = Pflichtfelder gefüllt (sonst zeigt der Browser die Meldung am Feld; in list nur in Zeilen
// mit Inhalt) und kein Upload läuft (sonst Hinweis über notify), values() = { feldname: wert }
// (boolean '1'/'0', list als Array von { unterfeld: wert }), close() = Formular ist fertig (gespeichert
// oder verworfen): hochgeladene Bilder, die nicht gespeichert sind, löscht der Server (upload.js, uploadForm).
export function buildEntryForm(schema, row, options) {
  const ctx = { look: options.look, notify: options.notify, uploads: uploadForm(), editors: [], beforeCheck: [] };
  const fields = {};
  // Adresse mit Quellfeld (from, meist der Titel): als Text unter diesem (slugField).
  const source = function (name) { return schema.find(function (field) { return field.name === name && field.type !== 'slug'; }); };
  ctx.slugSource = function (name) { const field = source(name); return field ? fieldLabel(field) : null; };
  const form = document.createElement('form');
  form.className = ctx.look.form;

  const isSide = function (field) { return SIDE_FIELD_TYPES.indexOf(field.type) !== -1; };
  const split = options.split && schema.some(isSide) && !schema.every(isSide);
  const columns = { main: form, side: form, full: form };
  if (split) {
    // Angaben zuerst: Tab-Reihenfolge und schmale Ansicht wie einspaltig (Kategorie oben), Zeilen zuletzt.
    form.classList.add(ctx.look.split);
    ['side', 'main', 'full'].forEach(function (name) {
      columns[name] = document.createElement('div');
      columns[name].className = ctx.look[name];
      form.appendChild(columns[name]);
    });
  }
  schema.forEach(function (field) {
    const value = row && row[field.name] != null ? row[field.name] : field.default;
    fields[field.name] = buildField(field, value != null ? value : '', ctx);
    columns[isSide(field) ? 'side' : (field.type === 'list' || field.type === 'blocks' ? 'full' : 'main')].appendChild(fields[field.name].box);
  });
  schema.forEach(function (field) {
    if (field.type === 'slug' && source(field.from)) fields[field.from].box.after(fields[field.name].box);
  });
  applyShowWhen(schema, fields);

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    options.onSubmit();
  });
  // Enter in einem einzeiligen Feld speichert (ohne Absenden-Knopf im Formular tut der Browser das nicht).
  form.addEventListener('keydown', function (event) {
    if (event.key !== 'Enter' || event.target.tagName !== 'INPUT' || event.target.type === 'file') return;
    event.preventDefault();
    options.onSubmit();
  });

  return {
    form: form,
    values: function () {
      const data = {};
      Object.keys(fields).forEach(function (name) { data[name] = fields[name].read(); });
      return data;
    },
    check: function () {
      if (uploadPending(options.notify)) return false;
      ctx.beforeCheck.forEach(function (prepare) { prepare(); });
      if (!form.reportValidity()) return false;
      // Texteditoren entfernter oder leerer Zeilen zählen nicht.
      const empty = ctx.editors.find(function (entry) {
        return entry.field.required && form.contains(entry.input) && !(entry.row && entry.row.empty()) && entry.input.value === '';
      });
      if (!empty) return true;
      options.notify(ENTRY_TEXT.richtextRequired.replace('{name}', function () { return fieldLabel(empty.field); }));
      empty.editor.focus();
      return false;
    },
    focus: function () {
      focusFirst(form);
    },
    close: function () {
      ctx.uploads.close();
    }
  };
}

// code der 409-Antwort, wenn der Eintrag seit dem Laden geändert wurde (PLUGIN_ENTRY_CONFLICT_CODE in core/pluginSchema.php).
export const ENTRY_CONFLICT_CODE = 'conflict';

// Formular im Backend-Modal (ui-modal.js). options: { schema, row, save(data, extra) → Promise,
// onSaved(), notify, reload() }; extra { overwrite: true } nach der Rückfrage zu einem Konflikt (409 conflict);
// reload (optional) öffnet den Eintrag neu mit der anderen Fassung. Titel „Neu“/„Bearbeiten“, Fehler des Servers stehen im Modal. Wie auch immer
// das Modal zugeht (onClose), danach schließt sich das Formular (entry.close), bei laufendem Speichern
// erst, wenn es fertig ist (sonst fehlte dem Eintrag sein neues Bild).
export function openEntryModal(openModal, options) {
  let modal = null;
  let saving = false;
  const submit = function () { modal.submitButton.click(); };
  const entry = buildEntryForm(options.schema, options.row, { look: BACKEND_LOOK, notify: options.notify, onSubmit: submit });
  modal = openModal({
    title: options.row ? ENTRY_TEXT.edit : ENTRY_TEXT.add,
    bodyHtml: '',
    submitLabel: ENTRY_TEXT.save,
    cancelLabel: ENTRY_TEXT.cancel,
    onClose: function () { if (!saving) entry.close(); },
    onSubmit: function (ctx) {
      if (!entry.check()) return;
      saving = true;
      ctx.setBusy(true);
      const values = entry.values();
      let theirs = false;
      options.save(values, {}).catch(function (error) {
        if (error.code !== ENTRY_CONFLICT_CODE) throw error;
        if (window.confirm(ENTRY_TEXT.conflictAsk)) return options.save(values, { overwrite: true });
        // Abbrechen bleibt harmlos: die andere Fassung nur nach eigener Rückfrage laden, sonst bleibt das Formular.
        if (!options.reload || !window.confirm(ENTRY_TEXT.conflictTheirs)) throw error;
        theirs = true;
      }).then(function () {
        if (theirs) {
          saving = false;
          if (ctx.isOpen()) ctx.close('cancel');
          else entry.close();
          options.reload();
          return;
        }
        saving = false;
        if (ctx.isOpen()) ctx.close('submit');
        else entry.close();
        options.onSaved();
      }).catch(function (error) {
        saving = false;
        if (!ctx.isOpen()) entry.close();
        ctx.setBusy(false);
        ctx.setMessage(error.message || String(error), false);
      });
    }
  });
  modal.body.appendChild(entry.form);
  entry.focus();
  return modal;
}
