import { overlayLayer, track, untrack, placeNear, showActive } from './overlay.js';
import { fieldRect } from './page-sync.js';
import { beginEdit, endEdit } from './session.js';
import { editorButton } from './bar.js';

// Kleiner Dialog am Element (Bild, Hintergrundbild) im Shadow-DOM: Titel, Inhalt, Abbrechen und
// Übernehmen. Er ist die laufende Bearbeitung: Klick daneben oder Enter übernimmt, Esc verwirft.

const POPOVER_TEXT = {
  apply: 'Übernehmen',
  cancel: 'Abbrechen'
};

// options: { anchor, title, body (Element), isDirty(), commit() → bool, cancel(), close() }.
// Klicks auf das Element selbst (nicht auf Felder darin) bleiben beim Dialog.
export function openPopover(options) {
  const box = document.createElement('div');
  box.className = 'le-popover';
  box.setAttribute('role', 'dialog');
  const title = document.createElement('div');
  title.className = 'le-popover__title';
  title.textContent = options.title;
  const actions = document.createElement('div');
  actions.className = 'le-popover__actions';
  actions.appendChild(editorButton(POPOVER_TEXT.cancel, 'le-btn le-btn--secondary', function () { endEdit(false); }));
  actions.appendChild(editorButton(POPOVER_TEXT.apply, 'le-btn', function () { endEdit(true); }));
  box.append(title, options.body, actions);
  // Enter übernimmt, außer auf einem Knopf oder der Dateiauswahl (eigene Aktion); der Dialog selbst hat den
  // Fokus, damit das auch ohne Eingabefeld (Hintergrundbild) geht.
  box.tabIndex = -1;
  box.addEventListener('keydown', function (event) {
    if (event.key === 'Enter' && event.target.tagName !== 'BUTTON' && event.target.tagName !== 'LABEL' && event.target.type !== 'file') {
      event.preventDefault();
      endEdit(true);
    }
  });

  overlayLayer().appendChild(box);
  const position = function () {
    placeNear(box, fieldRect(options.anchor), false);
  };
  track(position, box);
  showActive(options.anchor);
  box.focus({ preventScroll: true });

  beginEdit({
    contains: function (node) { return node === options.anchor; },
    owns: function (node) { return box.contains(node); },
    handlers: null,
    escape: function () { return false; },
    isDirty: options.isDirty,
    commit: options.commit,
    cancel: options.cancel,
    close: function () {
      untrack(position);
      box.remove();
      showActive(null);
      options.close();
    }
  });
  return { reposition: position };
}
