import { loadIconSet } from './page-sync.js';
import { editorButton } from './buttons.js';

// Raster aller Icons mit Suche (Name und deutsche Wörter): Feldart icon der Seite (field-editors.js,
// openIcon) und Feld icon eines Plugin-Eintrags (entry-form.js). Gebaut per DOM; die Icons kommen aus
// api/icons.php (loadIconSet), ihr SVG-Inhalt aus dem Satz des Servers.

export const ICON_TEXT = {
  search: 'Icon suchen',
  loading: 'Icons werden geladen …',
  none: 'Kein Icon gefunden.'
};
const SVG_NS = 'http://www.w3.org/2000/svg';

// look: Klassen { grid, item, empty }; selected: Name des gewählten Icons; onChoose(name) bei Klick.
// Liefert { search, grid, empty, select(name), ready } – ready: Promise, sobald die Icons stehen
// (das gewählte ist dann ins Bild gescrollt).
export function iconGrid(look, selected, onChoose) {
  const search = document.createElement('input');
  search.type = 'search';
  const grid = document.createElement('div');
  grid.className = look.grid;
  grid.setAttribute('role', 'listbox');
  const empty = document.createElement('p');
  empty.className = look.empty;
  empty.textContent = ICON_TEXT.loading;
  const buttons = [];

  const select = function (name) {
    buttons.forEach(function (button) { button.setAttribute('aria-selected', String(button.dataset.icon === name)); });
  };
  const filter = function () {
    const words = search.value.trim().toLowerCase().split(/\s+/).filter(Boolean);
    let shown = 0;
    buttons.forEach(function (button) {
      const hit = words.every(function (word) { return button.dataset.words.indexOf(word) !== -1; });
      button.hidden = !hit;
      if (hit) shown++;
    });
    empty.textContent = ICON_TEXT.none;
    empty.hidden = shown > 0;
  };
  search.addEventListener('input', filter);
  // Enter filtert nur: nicht bis zum Formular durchreichen, das bei Enter in einem Feld speichert (entry-form.js).
  search.addEventListener('keydown', function (event) {
    if (event.key !== 'Enter') return;
    event.preventDefault();
    event.stopPropagation();
  });

  const ready = loadIconSet().then(function (set) {
    set.list.forEach(function (entry) {
      const button = editorButton('', look.item, function () {
        select(entry.name);
        onChoose(entry.name);
      });
      button.setAttribute('role', 'option');
      button.setAttribute('aria-label', entry.name);
      button.title = entry.name;
      button.dataset.icon = entry.name;
      button.dataset.words = (entry.name.replace(/-/g, ' ') + ' ' + entry.words).toLowerCase();
      button.setAttribute('aria-selected', String(entry.name === selected));
      const svg = document.createElementNS(SVG_NS, 'svg');
      Object.keys(set.attrs).concat(Object.keys(set.defaults)).forEach(function (name) {
        svg.setAttribute(name, set.attrs[name] || set.defaults[name]);
      });
      svg.setAttribute('aria-hidden', 'true');
      svg.innerHTML = entry.svg;
      button.appendChild(svg);
      buttons.push(button);
      grid.appendChild(button);
    });
    filter();
    const current = grid.querySelector('[aria-selected="true"]');
    if (current) grid.scrollTop = current.offsetTop - (grid.clientHeight - current.offsetHeight) / 2;
  }, function (error) {
    empty.hidden = true;
    throw error;
  });

  return { search: search, grid: grid, empty: empty, select: select, ready: ready };
}
