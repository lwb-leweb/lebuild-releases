<?php
declare(strict_types=1);

// Sicher require_once-bar aus beliebigen PHP-Templates.
// Gibt leere Ergebnisse zurück wenn das Plugin inaktiv oder nicht verfügbar ist.

require_once __DIR__ . '/../../core/plugins.php';

$_state = load_plugins_state();
if (in_array('content-types', $_state['active'] ?? [], true)) {
    require_once __DIR__ . '/lib.php';
}
unset($_state);

function content_types_public_list(string $type, int $limit = 100): array
{
    if (!function_exists('content_types_fetch_list')) {
        return [];
    }
    try {
        // Wie auf der Website: Reihenfolge nach orderBy, noch nicht fällige (publishField) und abgelaufene
        // (expireField) fehlen.
        return content_types_fetch_list($type, $limit, null, content_types_load($type), true);
    } catch (Throwable $e) {
        return [];
    }
}

function content_types_public_get(string $type, int $id): ?array
{
    if (!function_exists('content_types_fetch_by_id')) {
        return null;
    }
    try {
        $row = content_types_fetch_by_id($type, $id);
        // Noch nicht fällig (publishField) oder abgelaufen (expireField): wie ein fehlender Eintrag.
        return $row !== null && content_types_published(content_types_load($type), $row) ? $row : null;
    } catch (Throwable $e) {
        return null;
    }
}
