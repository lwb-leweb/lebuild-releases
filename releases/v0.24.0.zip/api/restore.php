<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/fileStore.php';
require_once __DIR__ . '/../core/importer.php';
require_once __DIR__ . '/../core/phpRewriter.php';

// Auch Editoren: „Verlauf“ im Seiten-Editor stellt frühere Stände wieder her.
require_auth();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$page = safe_page_name((string) ($body['page'] ?? ''));
$backup = basename(sanitize_text_value($body['backup'] ?? ''));

if (!preg_match('/^[0-9]{14}\.json$/', $backup)) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidBackup']], 400);
}

// Dieselbe Sperre wie beim Speichern, für die Seite und alle Komponenten, die der Eintrag
// mit zurücksetzen kann. Den Eintrag samt Komponenten vor dem Abgleich lesen: Dessen Backup räumt
// alte Backups weg, der gewählte (älteste) Stand ginge sonst verloren. Direkt geänderte Dateien
// danach abgleichen (le_sync_request, scheitert es: 422), sonst verdeckte der neue Hash ihre
// unmarkierten Teile.
$entry = [];
[$locks, $sync] = le_sync_request([$page, ...array_keys(shared_components())], static function () use ($page, $backup, &$entry): void {
    $backupPath = BACKUPS_ROOT . '/' . $page . '/' . $backup;
    if (!is_file($backupPath)) {
        json_response(['ok' => false, 'error' => API_TEXT['backupNotFound']], 404);
    }
    $data = le_page_json_content((string) file_get_contents($backupPath));
    if ($data === null) {
        json_response(['ok' => false, 'error' => API_TEXT['backupInvalid']], 500);
    }
    $entry = backup_components($page, $backup) + [$page => $data];
});

// Die Seite aus dem Backup, dazu die Komponenten, die das Speichern dieses Eintrags mitgeschrieben
// hat (backup_components); ganz oder gar nicht wie beim Speichern.
// Nur Felder, die in der Datei noch markiert sind; IDs, die es nicht mehr gibt, werden gezählt.
// Alter Klartext (ohne Auszeichnung) mit gleichem Text behält die Auszeichnung der Datei (wie getPage);
// ein Wert mit Auszeichnung kommt so zurück, wie er im Backup steht.
// Die Live-Seite rendert aus public/site/, nicht aus dem JSON: erst prüfen, dann beides schreiben.
$plans = [];
$errors = [];
$restoredCount = 0;
$skipped = 0;
foreach ($entry as $name => $values) {
    $name = (string) $name; // Seiten wie „404“: PHP macht den Schlüssel zur Zahl.
    // Eine Komponente, deren Datei es nicht mehr gibt oder deren Abgleich gescheitert ist (le_sync_request),
    // blockiert die Seite nicht: ihre Felder zählen als übersprungen. Fehlt die Seite selbst, bleibt es beim Fehler.
    if ($name !== $page && (page_source_path($name) === null || isset($sync['failed'][$name]))) {
        $skipped += count(flatten_content($values));
        continue;
    }
    $doc = page_source_doc($name);
    ['content' => $restored, 'skipped' => $unknown] = known_source_fields($doc, $name, $values);
    $restored = align_text_with_source($doc, $name, $restored, true);
    $plans[$name] = ['doc' => $doc, 'restored' => $restored] + plan_source_rewrite($name, $restored);
    $errors = array_merge($errors, $plans[$name]['errors']);
    $restoredCount += count(flatten_content($restored));
    $skipped += $unknown;
}
if ($errors !== []) {
    json_response(['ok' => false, 'error' => rewrite_error_message($errors), 'fields' => $errors], 422);
}
// Das Backup liegt über dem aktuellen Stand: Felder, die es nicht kennt (z. B. später
// dazugekommene Alt-Texte), bleiben im JSON wie in der Datei.
foreach ($plans as $name => $plan) {
    $name = (string) $name;
    // Eine kaputte aktuelle JSON (unlesbar) ersetzt das Backup ganz: So repariert „Verlauf“ die Seite.
    $plans[$name]['content'] = array_replace_recursive(load_component_content($name) ?? [], $plan['restored']);
    $plans[$name]['kinds'] = page_field_kinds($plan['doc'], $name, $plans[$name]['content']);
}

write_page_plans($page, $plans, true);
unlock_pages($locks);
// Nach den Einträgen des Abgleichs (le_log_after_unlock), der dieses Wiederherstellen ausgelöst hat.
le_log_after_unlock([$page => 'page_restored'], $locks, null);

json_response(['ok' => true, 'page' => $page, 'restored' => $restoredCount, 'skipped' => $skipped] + le_sync_skipped_notice($sync['failed']));
