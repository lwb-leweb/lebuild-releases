<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../../../core/db.php';
require_once __DIR__ . '/../../../core/pluginSchema.php';

require_auth();

$name = (string) ($_GET['plugin'] ?? '');
$id = (int) ($_GET['id'] ?? 0);
if (!plugin_name_valid($name) || $id <= 0) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidRequest']], 400);
}
require_plugin_active($name);

$manifest = le_plugin_manifest_or_fail($name);
$table = plugin_main_table($manifest);
if ($table === null) {
    json_response(['ok' => false, 'error' => API_TEXT['noMainTable']], 400);
}

try {
    $row = plugin_fetch_row($table, $id);
} catch (Throwable $e) {
    plugin_failure_response('load', $e);
}

if (!$row) {
    json_response(['ok' => false, 'error' => API_TEXT['notFound']], 404);
}

$fields = plugin_schema_columns($manifest);
json_response([
    'ok' => true,
    'row' => plugin_schema_decode_row($fields, $row),
    'schema' => $fields,
]);
