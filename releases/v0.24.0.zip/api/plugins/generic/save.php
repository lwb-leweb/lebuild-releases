<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../../../core/db.php';
require_once __DIR__ . '/../../../core/pluginSchema.php';
require_once __DIR__ . '/../../../core/uploads.php';

require_auth();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$name = (string) ($body['plugin'] ?? '');
if (!plugin_name_valid($name)) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidPlugin']], 400);
}
require_plugin_active($name);

$manifest = le_plugin_manifest_or_fail($name);
$table = plugin_main_table($manifest);
if ($table === null) {
    json_response(['ok' => false, 'error' => API_TEXT['noMainTable']], 400);
}

$fields = plugin_schema_columns($manifest);

$rawValues = is_array($body['data'] ?? null) ? $body['data'] : [];
$id = (int) ($body['id'] ?? 0);

// Vom Prüfen der Bilder bis zum Aufräumen ersetzter Bilder nacheinander mit dem Erledigen offener Uploads
// (le_open_uploads_hold), in derselben Reihenfolge wie content_types_save: kein Bild verschwindet mitten im Speichern.
$id = le_open_uploads_hold(static function () use ($table, $fields, $rawValues, $id): int {
    try {
        $stored = $id > 0 ? plugin_fetch_row($table, $id) : [];
    } catch (Throwable $e) {
        plugin_failure_response('save', $e);
    }
    if ($stored === null) {
        // Inzwischen gelöscht: nicht als gespeichert melden.
        json_response(['ok' => false, 'error' => API_TEXT['notFound']], 404);
    }
    try {
        $values = plugin_schema_column_values(plugin_schema_values($fields, $rawValues, $stored));
    } catch (InvalidArgumentException $e) {
        json_response(['ok' => false, 'error' => $e->getMessage()], 400);
    } catch (Throwable $e) {
        plugin_failure_response('save', $e);
    }

    if (!$values) {
        json_response(['ok' => false, 'error' => API_TEXT['noValidFields']], 400);
    }

    $replaced = [];
    try {
        // Zeitstempel setzt PHP selbst (kein ON UPDATE, SQLite-Zeit wäre UTC),
        // aber nur für Spalten, die die Tabelle hat und das Schema nicht liefert.
        $columns = db_table_columns($table);
        $stamps = $id > 0 ? ['updated_at'] : ['created_at', 'updated_at'];
        foreach ($stamps as $stamp) {
            if (in_array($stamp, $columns, true) && !array_key_exists($stamp, $values)) {
                $values[$stamp] = db_now();
            }
        }

        if ($id > 0) {
            $sets = [];
            $params = [];
            foreach ($values as $key => $value) {
                $sets[] = "`{$key}` = ?";
                $params[] = $value;
            }
            $params[] = $id;
            db()->prepare("UPDATE `{$table}` SET " . implode(', ', $sets) . ' WHERE `id` = ?')->execute($params);
            // Bilder, die der Eintrag nicht mehr nutzt (ersetzt, Zeile entfernt), wenn sie sonst nirgends vorkommen.
            $replaced = array_diff(plugin_schema_image_values($fields, $stored), plugin_schema_image_values($fields, $values + $stored));
        } else {
            $keys = array_keys($values);
            $placeholders = implode(', ', array_fill(0, count($keys), '?'));
            $sql = "INSERT INTO `{$table}` (`" . implode('`, `', $keys) . "`) VALUES ({$placeholders})";
            db()->prepare($sql)->execute(array_values($values));
            $id = (int) db()->lastInsertId();
        }
    } catch (Throwable $e) {
        plugin_failure_response('save', $e);
    }
    delete_unused_uploads($replaced);

    return $id;
});
le_activity_log((int) ($body['id'] ?? 0) > 0 ? 'plugin_entry_updated' : 'plugin_entry_created', le_activity_plugin_target($name, $id));

json_response(['ok' => true, 'id' => $id]);
