<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../../../core/db.php';
require_once __DIR__ . '/../../../core/pluginSchema.php';

require_auth();

$name = (string) ($_GET['plugin'] ?? '');
if (!plugin_name_valid($name)) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidPlugin']], 400);
}
require_plugin_active($name);

$manifest = le_plugin_manifest_or_fail($name);
$table = plugin_main_table($manifest);
if ($table === null) {
    json_response(['ok' => false, 'error' => API_TEXT['noMainTable']], 400);
}

$columns = plugin_schema_field_names($manifest);
$select = '`id`' . ($columns ? ', `' . implode('`, `', $columns) . '`' : '');

try {
    $rows = db()->query("SELECT {$select} FROM `{$table}` ORDER BY `id` DESC")->fetchAll();
} catch (Throwable $e) {
    plugin_failure_response('load', $e);
}

$fields = plugin_schema_columns($manifest);
json_response([
    'ok' => true,
    'rows' => array_map(static fn (array $row): array => plugin_schema_decode_row($fields, $row), $rows),
    'schema' => $fields,
]);
