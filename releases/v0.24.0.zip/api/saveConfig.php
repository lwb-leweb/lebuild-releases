<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/fileStore.php';
require_once __DIR__ . '/../core/seo.php';

require_admin();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$allowed = ['name', 'tagline', 'url', 'email', 'owner', 'locale', 'image'];
$input = [];
foreach ($allowed as $key) {
    if (isset($body[$key])) {
        $input[$key] = trim((string) $body[$key]);
    }
}
// Leer ist erlaubt; sonst eine echte Adresse (E-Mail dient auch als Empfänger für Formulare).
if (($input['email'] ?? '') !== '' && !filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidEmail']], 400);
}
if (($input['url'] ?? '') !== '' && (!filter_var($input['url'], FILTER_VALIDATE_URL) || !preg_match('#^https?://#i', $input['url']))) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidUrl']], 400);
}
// Vorschaubild: Adresse auf der Website oder https-Adresse (core/seo.php).
if (($input['image'] ?? '') !== '' && !preg_match(LE_SEO_IMAGE_PATTERN, $input['image'])) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidImage']], 400);
}

// Lesen → Ändern → Schreiben unter Sperre; atomic_write antwortet bei einem Fehler 500.
$lock = store_lock('config');
$cfg = array_merge(le_site_config(), $input);

$json = json_encode($cfg, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
if ($json === false) {
    json_response(['ok' => false, 'error' => API_TEXT['encodeFailed']], 500);
}
atomic_write(LE_SITE_CONFIG_FILE, $json . PHP_EOL);
le_activity_log('settings_saved');

json_response(['ok' => true]);
