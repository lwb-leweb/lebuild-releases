import { state, dom, pageRoute } from './core.js';
import { navigate } from './router.js';
import { readEditorConfig } from '../site-editor/config.js';

export function pageKey(page) {
  return typeof page === 'string' ? page : page.page;
}

function findPageInfo(page) {
  return state.pageInfo.find(function (p) { return pageKey(p) === page; });
}

export function pageExt(page) {
  const info = findPageInfo(page);
  return (info && info.ext) || 'html';
}

// Seite mit JSON, aber ohne Seitendatei: steht in der Liste, lässt sich aber nicht öffnen.
export function pageMissing(page) {
  const info = typeof page === 'string' ? findPageInfo(page) : page;
  return !!(info && info.missing);
}

// Erste Seite, die sich öffnen lässt (Startansicht, nach dem Import); null, wenn es keine gibt.
export function firstOpenablePage() {
  const info = state.pageInfo.find(function (p) { return !pageMissing(p); });
  return info ? pageKey(info) : null;
}

export function pageLabel(page) {
  if (typeof page === 'string') return page;
  const name = page.page;
  return name.charAt(0).toUpperCase() + name.slice(1);
}

export function pageMeta(page) {
  if (typeof page === 'string' || !page.updatedAt) return '';
  try {
    return new Date(page.updatedAt).toLocaleString();
  } catch (e) {
    return page.updatedAt;
  }
}

// Zahl am Punkt „Seiten“ der Seitenleiste: Seiten, die sich öffnen lassen; ohne keine Zahl.
export function renderPagesCount() {
  const count = state.pageInfo.filter(function (p) { return !pageMissing(p); }).length;
  dom.pagesCount.hidden = !count;
  dom.pagesCount.textContent = String(count);
}

// Klick in der Liste der Seiten (Ansicht „Seiten“): über den Router in die Seitenansicht.
export function openPage(page) {
  navigate(pageRoute(page));
}

// Zeigt eine Seite im iframe; bearbeitet wird sie dort mit dem Seiten-Editor (wie auf der Website).
// Dieselbe Seite lädt neu (nach dem Import). Markierung und Adresse folgen erst, wenn sie geladen
// ist (syncPageFromFrame): lehnt man im iframe die Warnung beim Verlassen ab, zeigen beide weiter
// die Seite, die dort steht, und ein erneuter Klick fragt wieder.
export function loadPage(page) {
  if (!dom.previewFrame || pageMissing(page)) return;
  requestedPage = page;
  showInFrame('/public/site/' + encodeURIComponent(page) + '.' + pageExt(page));
}

// Seite, die loadPage angefordert hat; ihr Laden bekommt einen eigenen Eintrag im Browser-Verlauf.
let requestedPage = '';

// Lädt url in den iframe, ohne dass der iframe selbst einen Eintrag im Browser-Verlauf anlegt
// (location.replace statt src); den Eintrag setzt syncPageFromFrame.
export function showInFrame(url) {
  dom.previewFrame.contentWindow.location.replace(url);
}

// Nach jedem Laden im iframe (auch nach Klick auf einen Link der Seite, Speichern oder
// Wiederherstellen): Eintrag der Seite (aus dem JSON-Block: Titel, zuletzt gespeichert) und
// Adresse zeigen die Seite im iframe. Eine über die Liste angeforderte Seite bekommt einen Eintrag
// im Browser-Verlauf; nach einem Link in der Seite hat ihn schon der iframe angelegt, dann wird
// die Adresse nur ersetzt (Zurück geht so in beiden Fällen eine Seite zurück). Andere Dokumente (Unterordner, Plugin-Seiten, fremde Adressen) haben keine Seite; dann ist
// keine gesetzt.
export function syncPageFromFrame() {
  let config = null;
  try {
    config = readEditorConfig(dom.previewFrame.contentDocument);
  } catch (e) {
    config = null;
  }
  const info = config !== null ? config.pageInfo : null;
  const page = info !== null ? info.page : '';
  const index = state.pageInfo.findIndex(function (p) { return pageKey(p) === page; });
  if (index !== -1) state.pageInfo[index] = info;
  state.currentPage = page;
  const requested = page !== '' && page === requestedPage;
  requestedPage = '';
  if (page) navigate(pageRoute(page), { replace: !requested });
}
