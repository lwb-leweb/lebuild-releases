import { state, dom, api, applyEditLists, isAdmin, logout, ADMIN_URL, LOGIN_URL, SITE_HOME_URL } from './core.js';
import { renderPagesCount } from './pages.js';
import { navigate, initRouter, showToast } from './router.js';
import { setUpdateStatus, showInstalledToast } from './update.js';
import { attachSaveKey } from './save-key.js';

// Symbol der Einträge von Erweiterungen in der Seitenleiste (Content-Typen, Öffnungszeiten …): eine Liste.
const PLUGIN_ICON = '<svg class="nav-icon" width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">'
  + '<path d="M6.5 4.5h8M6.5 9h8M6.5 13.5h8" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/>'
  + '<circle cx="3.5" cy="4.5" r="1" fill="currentColor"/><circle cx="3.5" cy="9" r="1" fill="currentColor"/>'
  + '<circle cx="3.5" cy="13.5" r="1" fill="currentColor"/></svg>';

function showEditor(data) {
  state.pages = data.pages || [];
  state.pageInfo = data.pages || [];
  state.csrfToken = data.csrfToken || state.csrfToken;
  state.activePlugins = data.activePlugins || [];
  state.systemProblems = data.systemProblems || [];
  state.dbArchiveReminder = data.dbArchiveReminder || null;
  state.siteBackup = data.siteBackup || null;
  state.username = data.username || null;
  state.importPending = !data.importStatus;
  dom.editorView.classList.remove('hidden');
  renderPagesCount();
  renderPluginNav(state.activePlugins);
  renderUser(state.username);
  initRouter();
  setUpdateStatus(data.updateStatus || null);
  if (data.updateInstalled) {
    showInstalledToast(data.updateInstalled.previousVersion, data.updateInstalled.newVersion);
  }
}

// Punkte der Seitenleiste mit data-view: der erste Name ist die Ansicht, die übrigen markieren ihn mit
// (Seiten: auch die Seitenansicht einer Seite, router.js syncSidebar).
document.querySelectorAll('.sidebar-nav .nav-item[data-view]').forEach(function (button) {
  button.addEventListener('click', function () {
    navigate(button.dataset.view.split(' ')[0]);
  });
});
// „Zur Website“: die Seite, die gerade in der Seitenansicht steht, sonst die Startseite.
dom.siteLink.addEventListener('click', function () {
  const frame = dom.previewFrame;
  let path = SITE_HOME_URL;
  try {
    if (frame && frame.isConnected) path = frame.contentWindow.location.pathname + frame.contentWindow.location.search;
  } catch (e) { /* fremde Adresse im iframe: Startseite */ }
  if (path === 'blank' || path.indexOf(ADMIN_URL) === 0) path = SITE_HOME_URL;
  dom.siteLink.href = path;
});
dom.logoutButton.addEventListener('click', function () {
  logout().catch(function (error) { showToast(error.message); });
});

// Mit vielen Erweiterungen ist die Leiste höher als der Schirm: Sie scrollt und läuft an der Seite
// weich aus, auf der es weitergeht (fade-start, fade-end in styles.css).
const navEl = document.querySelector('.sidebar-nav');
function syncNavEdges() {
  navEl.classList.toggle('fade-start', navEl.scrollTop > 0);
  navEl.classList.toggle('fade-end', navEl.scrollTop + navEl.clientHeight < navEl.scrollHeight - 1);
}
navEl.addEventListener('scroll', syncNavEdges, { passive: true });
window.addEventListener('resize', syncNavEdges);
new ResizeObserver(syncNavEdges).observe(navEl);

const sidebarEl = document.querySelector('.sidebar');
const sidebarCollapseBtn = document.getElementById('sidebarCollapse');
if (sidebarCollapseBtn && sidebarEl) {
  sidebarCollapseBtn.addEventListener('click', function () {
    sidebarEl.classList.toggle('collapsed');
  });
}

// Angemeldeter Benutzer unten in der Seitenleiste: Anfangsbuchstabe als Avatar, Name, Abmelden.
function renderUser(name) {
  const text = name || '';
  dom.userName.textContent = text;
  dom.userAvatar.textContent = text.charAt(0).toUpperCase();
}

// Je aktiver Erweiterung mit Ansicht ein Punkt unter „Inhalte“ (Content-Typen je Typ).
function renderPluginNav(plugins) {
  if (!dom.pluginsActiveList) return;
  dom.pluginsActiveList.textContent = '';
  (plugins || []).forEach(function (plugin) {
    const route = plugin.route || plugin.name;
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'nav-item plugin-entry';
    button.dataset.plugin = plugin.name;
    button.dataset.route = route;
    button.innerHTML = PLUGIN_ICON;
    const label = document.createElement('span');
    label.className = 'nav-label';
    label.textContent = plugin.label || plugin.name;
    button.appendChild(label);
    button.title = label.textContent;
    button.addEventListener('click', function () {
      navigate('plugin/' + route);
    });
    dom.pluginsActiveList.appendChild(button);
  });
}

// Die Shell bekommen nur angemeldete Admins (index.php). Ist die Session inzwischen abgelaufen
// (oder liefert ein Server wie Nginx die Shell direkt aus), geht es zur Login-Seite und danach zurück,
// Editoren gehen wie bei index.php auf die Website.
function boot() {
  api('/api/bootstrap.php')
    .then(function (data) {
      applyEditLists(data);
      if (!data.authenticated) {
        window.location.replace(LOGIN_URL + '?next=' + encodeURIComponent(window.location.pathname));
        return;
      }
      state.role = data.role || null;
      if (!isAdmin()) {
        window.location.replace(SITE_HOME_URL);
        return;
      }
      state.csrfToken = data.csrfToken || '';
      showEditor(data);
    })
    .catch(function (error) {
      showToast(error.message);
    });
}

// Strg+S: Speichern-Knopf des sichtbaren Formulars, nie der Speichern-Dialog des Browsers.
attachSaveKey();
boot();
