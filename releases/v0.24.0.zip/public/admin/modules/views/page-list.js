import { state, api, escapeHtml, formatDate, pageRoute } from '../core.js';
import { pageKey, pageLabel, pageMissing, pageExt, openPage, firstOpenablePage, renderPagesCount } from '../pages.js';
import { navigate, showToast } from '../router.js';

// Ansicht „Seiten“: alle Seiten der Website als Tabelle (Name, Datei, zuletzt gespeichert) mit Suche,
// dazu „Markierungen aktualisieren“ und vor dem ersten Import der Hinweis „Import starten“. Ein Klick
// öffnet die Seite in der Seitenansicht (iframe mit dem Seiten-Editor).
const LIST_TEXT = {
  title: 'Seiten',
  count: '%s Seiten',
  countOne: '1 Seite',
  countOf: '%s von %t Seiten',
  search: 'Seiten suchen …',
  page: 'Seite',
  file: 'Datei',
  saved: 'Zuletzt gespeichert',
  open: 'Öffnen',
  missingFile: 'Seitendatei fehlt',
  empty: 'Noch keine Seiten.',
  noMatch: 'Keine Seite passt zur Suche.',
  importTitle: 'Website erkannt',
  importText: 'Die Dateien unter public/site sind noch nicht importiert. Der Import macht Texte, Bilder und Links bearbeitbar.',
  importButton: 'Import starten',
  refreshButton: 'Markierungen aktualisieren',
  // Texte zu Import und „Markierungen aktualisieren“ (als Hinweis, showToast); den Grund für eine
  // übersprungene Datei liefert der Server (IMPORT_SKIP_REASONS).
  refreshConfirm: 'Markierungen aktualisieren liest alle Seiten und Komponenten neu aus den Dateien unter public/site: Markierungen werden nach den aktuellen Regeln gesetzt, bestehende IDs bleiben, Inhalte im Editor kommen aus den Dateien. Sicherungen werden vorher angelegt. Fortfahren?',
  imported: 'Import abgeschlossen.',
  refreshed: 'Markierungen aktualisiert.',
  skippedFiles: 'Übersprungen'
};

let root = null;
let query = '';

export function mount(outlet) {
  query = '';
  outlet.innerHTML = `
    <section class="view-area">
      <div class="view-card span-12">
        <div class="topbar">
          <div class="entries-head">
            <strong>${LIST_TEXT.title}</strong>
            <span class="entries-head__count" data-ref="count"></span>
          </div>
          <div class="form-actions">
            <button type="button" class="secondary" data-ref="refresh">${LIST_TEXT.refreshButton}</button>
          </div>
        </div>
        <div class="notice import-notice" data-ref="import" hidden>
          <div>
            <strong>${LIST_TEXT.importTitle}</strong>
            <p>${LIST_TEXT.importText}</p>
          </div>
          <button type="button" data-ref="importButton">${LIST_TEXT.importButton}</button>
        </div>
        <div class="entries-filters">
          <input type="search" class="entries-filters__search" data-ref="search" placeholder="${LIST_TEXT.search}" aria-label="${LIST_TEXT.search}">
        </div>
        <div data-ref="list"></div>
      </div>
    </section>
  `;
  root = outlet;
  ref('search').addEventListener('input', function (event) {
    query = event.target.value.trim().toLowerCase();
    renderList();
  });
  ref('importButton').addEventListener('click', function () { runImport(false); });
  ref('refresh').addEventListener('click', function () {
    if (window.confirm(LIST_TEXT.refreshConfirm)) runImport(true);
  });
  render();
}

export function unmount() {
  root = null;
}

function ref(name) {
  return root.querySelector('[data-ref="' + name + '"]');
}

function render() {
  ref('import').hidden = !state.importPending;
  // Vor dem ersten Import gibt es nichts zu aktualisieren, der Hinweis bietet den Import an.
  ref('refresh').hidden = state.importPending;
  renderList();
}

function pages() {
  return state.pageInfo.length ? state.pageInfo : state.pages;
}

function savedText(page) {
  return typeof page === 'string' || !page.updatedAt ? '–' : formatDate(page.updatedAt);
}

function renderList() {
  const all = pages();
  const shown = all.filter(function (page) {
    if (!query) return true;
    return (pageLabel(page) + ' ' + pageKey(page) + '.' + pageExt(pageKey(page))).toLowerCase().indexOf(query) !== -1;
  });
  const count = ref('count');
  count.textContent = !all.length ? '' : shown.length !== all.length
    ? LIST_TEXT.countOf.replace('%s', shown.length).replace('%t', all.length)
    : (all.length === 1 ? LIST_TEXT.countOne : LIST_TEXT.count.replace('%s', all.length));

  const list = ref('list');
  if (!shown.length) {
    list.innerHTML = '<p class="entries-empty">' + escapeHtml(all.length ? LIST_TEXT.noMatch : LIST_TEXT.empty) + '</p>';
    return;
  }
  list.innerHTML = '<div class="entries-table-wrap"><table class="entries-table"><thead><tr>'
    + '<th>' + LIST_TEXT.page + '</th><th>' + LIST_TEXT.file + '</th><th>' + LIST_TEXT.saved + '</th><th class="entries-table__actions-head"></th>'
    + '</tr></thead><tbody>' + shown.map(function (page) {
      const key = pageKey(page);
      const missing = pageMissing(page);
      return '<tr data-page="' + escapeHtml(key) + '"' + (missing ? ' class="entries-table__row--missing"' : '') + '>'
        + '<td class="entries-table__title">' + escapeHtml(pageLabel(page)) + '</td>'
        + '<td class="entries-table__file">' + escapeHtml(key + '.' + pageExt(key)) + '</td>'
        + '<td class="entries-table__date">' + (missing ? '<span class="entries-table__warning">' + LIST_TEXT.missingFile + '</span>' : escapeHtml(savedText(page))) + '</td>'
        + '<td class="entries-table__actions">' + (missing ? '' : '<button type="button" class="secondary">' + LIST_TEXT.open + '</button>') + '</td>'
        + '</tr>';
    }).join('') + '</tbody></table></div>';
  list.querySelectorAll('tbody tr:not(.entries-table__row--missing)').forEach(function (row) {
    row.addEventListener('click', function () { openPage(row.dataset.page); });
  });
}

// Import bzw. „Markierungen aktualisieren“ (force): Ergebnis als Hinweis, danach die erste Seite
// in der Seitenansicht; ohne Seite bleibt die Liste.
function runImport(force) {
  api('/api/import.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ force: !!force })
  })
    .then(function (data) {
      state.pages = data.pages || [];
      state.pageInfo = data.pages || [];
      state.importPending = false;
      renderPagesCount();
      showToast((force ? LIST_TEXT.refreshed : LIST_TEXT.imported) + skippedFilesNote(data.status.skippedFiles));
      const first = firstOpenablePage();
      if (!force && first !== null) {
        state.currentPage = '';
        navigate(pageRoute(first));
      } else if (root) {
        render();
      }
    })
    .catch(function (error) {
      showToast(error.message);
    });
}

// „ Übersprungen (nicht UTF-8): a.html, b.php.“ je Grund; leer, wenn keine Datei übersprungen wurde.
function skippedFilesNote(files) {
  const byReason = {};
  files.forEach(function (f) {
    (byReason[f.reason] = byReason[f.reason] || []).push(f.file);
  });
  return Object.keys(byReason).map(function (reason) {
    return ' ' + LIST_TEXT.skippedFiles + ' (' + reason + '): ' + byReason[reason].join(', ') + '.';
  }).join('');
}
