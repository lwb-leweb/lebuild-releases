<?php
require_once __DIR__ . '/config.php';

foreach (load_plugins_state()['active'] ?? [] as $_plugin_name) {
    $_pub = PROJECT_ROOT . '/plugins/' . $_plugin_name . '/public.php';
    if (is_file($_pub)) {
        require_once $_pub;
    }
}
unset($_plugin_name, $_pub);

// Erwartete Variablen: $page = ['title' => ..., 'description' => ..., 'slug' => ..., 'demos' => bool]
// demos: lädt die Vorführungen der Startseite (demos.css, demos.js).
$pageTitle       = $page['title']       ?? SITE_NAME;
$pageDescription = $page['description'] ?? SITE_TAGLINE;
$pageSlug        = $page['slug']        ?? '';

// Markenname nur einmal: Steht er schon im Seitentitel, wird er nicht noch einmal angehängt.
$fullTitle = match (true) {
    $pageTitle === SITE_NAME => SITE_NAME . ' – ' . SITE_TAGLINE,
    str_contains($pageTitle, SITE_NAME) => $pageTitle,
    default => $pageTitle . ' | ' . SITE_NAME,
};
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($fullTitle) ?></title>
    <meta name="description" content="<?= e($pageDescription) ?>">
<?php if (SITE_OWNER !== ''): ?>
    <meta name="author" content="<?= e(SITE_OWNER) ?>">
<?php endif; ?>
    <meta name="theme-color" content="#00aaa0">

    <meta property="og:type" content="website">
    <meta property="og:locale" content="<?= e(SITE_LOCALE) ?>">
    <meta property="og:site_name" content="<?= e(SITE_NAME) ?>">
    <meta property="og:title" content="<?= e($fullTitle) ?>">
    <meta property="og:description" content="<?= e($pageDescription) ?>">
<?php if (SITE_URL !== ''): ?>
    <meta property="og:url" content="<?= e(SITE_URL . '/' . $pageSlug) ?>">
<?php endif; ?>

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= e($fullTitle) ?>">
    <meta name="twitter:description" content="<?= e($pageDescription) ?>">

<?php if (SITE_URL !== ''): ?>
    <link rel="canonical" href="<?= e(SITE_URL . '/' . $pageSlug) ?>">
<?php endif; ?>
    <script>try { if ((new URLSearchParams(location.search).get('theme') || localStorage.getItem('theme')) === 'dark') document.documentElement.dataset.theme = 'dark'; } catch (e) {}</script>
    <link rel="stylesheet" href="assets/css/style.css">
<?php if (!empty($page['demos'])): ?>
    <link rel="stylesheet" href="assets/css/demos.css">
<?php endif; ?>
    <link rel="icon" href="assets/img/favicon.svg" type="image/svg+xml">
</head>
<body>
    <a class="skip-link" href="#main">Zum Inhalt springen</a>

    <?php require __DIR__ . '/navigation.php'; ?>

    <main id="main">
