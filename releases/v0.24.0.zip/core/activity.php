<?php
declare(strict_types=1);

require_once __DIR__ . '/utils.php';

// Aktivitäts-Log (Verwaltung → Aktivität, nur Admins): wer hat wann was getan. JSON-Lines, je Zeile
// {time, user, action, target}, nie eine IP. Einträge älter als LE_ACTIVITY_RETENTION_DAYS fallen weg.
const LE_ACTIVITY_FILE = CONTENT_ROOT . '/activity.jsonl';
const LE_ACTIVITY_RETENTION_DAYS = 90;
// Umgeschrieben wird erst, wenn der älteste Eintrag einen Tag über der Frist liegt: höchstens einmal am Tag.
const LE_ACTIVITY_PRUNE_GRACE = 86400;
const LE_ACTIVITY_TEXT_MAX = 200;
const LE_ACTIVITY_PAGE_SIZE = 50;
const LE_ACTIVITY_PAGE_MAX = 200;
const LE_ACTIVITY_READ_FAILED_TEXT = 'Das Aktivitäts-Log ließ sich nicht lesen.';

// Aktionen als Schlüssel, Anzeige-Texte für die Ansicht „Aktivität“.
const LE_ACTIVITY_LABELS = [
    'login' => 'Angemeldet',
    'login_failed' => 'Anmeldung fehlgeschlagen',
    'logout' => 'Abgemeldet',
    'page_saved' => 'Seite gespeichert',
    'page_restored' => 'Seite wiederhergestellt',
    'upload' => 'Datei hochgeladen',
    'media_deleted' => 'Bilder gelöscht',
    'media_cleaned' => 'Unbenutzte Uploads aufgeräumt',
    'plugin_entry_created' => 'Eintrag angelegt',
    'plugin_entry_updated' => 'Eintrag geändert',
    'plugin_entry_deleted' => 'Eintrag gelöscht',
    'plugin_entries_imported' => 'Einträge importiert',
    'plugin_data_applied' => 'Plugin-Daten eingespielt',
    'plugin_settings_saved' => 'Plugin-Einstellungen gespeichert',
    'settings_saved' => 'Einstellungen gespeichert',
    'mail_settings_saved' => 'Mail-Einstellungen gespeichert',
    'mail_settings_deleted' => 'Mail-Einstellungen entfernt',
    'db_settings_saved' => 'Datenbank-Zugang gespeichert',
    'db_migrated' => 'Datenbank umgezogen',
    'db_archive_deleted' => 'Altdaten gelöscht',
    'user_created' => 'Benutzer angelegt',
    'user_updated' => 'Benutzer geändert',
    'user_password_changed' => 'Passwort geändert',
    'user_deleted' => 'Benutzer gelöscht',
    'plugin_activated' => 'Plugin aktiviert',
    'plugin_deactivated' => 'Plugin deaktiviert',
    'plugin_uninstalled' => 'Plugin deinstalliert',
    'update_installed' => 'Update installiert',
    'update_rolled_back' => 'Update zurückgenommen',
    'import' => 'Website importiert',
    'markers_refreshed' => 'Markierungen aktualisiert',
    'backup_downloaded' => 'Sicherung heruntergeladen',
    'backup_key_created' => 'Backup-Schlüssel erzeugt',
];

/**
 * Hängt einen Eintrag an. Der Benutzer kommt aus der Session; $user nur ohne Anmeldung (fehlgeschlagener
 * Login: der eingegebene Name) oder für Änderungen, die nicht der Angemeldete gemacht hat (Abgleich: LE_SYNC_AUTHOR). Ohne Benutzer wird nichts vermerkt. Ein Fehler geht nur ins Fehlerprotokoll,
 * die eigentliche Aktion scheitert nie daran.
 */
function le_activity_log(string $action, string $target = '', ?string $user = null): void
{
    try {
        if (!isset(LE_ACTIVITY_LABELS[$action])) {
            throw new InvalidArgumentException('unknown action ' . $action);
        }
        $user ??= function_exists('current_user') ? (string) (current_user()['username'] ?? '') : '';
        $user = le_activity_clip($user);
        if ($user === '') {
            return;
        }
        $line = json_encode([
            'time' => current_iso_time(),
            'user' => $user,
            'action' => $action,
            'target' => le_activity_clip($target),
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR) . "\n";

        // Anhängen und Aufräumen unter derselben Sperre: Das Aufräumen ersetzt die Datei (rename),
        // ein gleichzeitiges Anhängen an die alte ginge sonst verloren.
        $lock = store_lock('activity');
        try {
            try {
                le_activity_prune_if_due();
            } catch (Throwable $e) {
                error_log('activity log prune: ' . $e->getMessage());
            }
            $new = !is_file(LE_ACTIVITY_FILE);
            $fh = @fopen(LE_ACTIVITY_FILE, 'ab');
            if ($fh === false) {
                throw new RuntimeException('Cannot open ' . basename(LE_ACTIVITY_FILE));
            }
            $written = fwrite($fh, $line);
            fclose($fh);
            if ($written !== strlen($line)) {
                throw new RuntimeException('Cannot write ' . basename(LE_ACTIVITY_FILE));
            }
            if ($new) {
                @chmod(LE_ACTIVITY_FILE, PRIVATE_FILE_MODE);
            }
        } finally {
            store_unlock($lock);
        }
    } catch (Throwable $e) {
        error_log('activity log: ' . $e->getMessage());
    }
}

/** Objekt eines Plugin-Eintrags für das Log: „Öffnungszeiten #3“ (Name aus plugin.json, sonst der Plugin-Name), ohne $id nur der Name. */
function le_activity_plugin_target(string $plugin, ?int $id = null): string
{
    try {
        $label = function_exists('plugin_manifest') ? (string) (plugin_manifest($plugin)['label'] ?? '') : '';
    } catch (Throwable $e) {
        $label = '';
    }
    return ($label !== '' ? $label : $plugin) . ($id !== null ? ' #' . $id : '');
}

/** Eine Zeile ohne Steuerzeichen, gekürzt auf LE_ACTIVITY_TEXT_MAX Zeichen. */
function le_activity_clip(string $text): string
{
    $text = trim((string) preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $text));
    return mb_substr($text, 0, LE_ACTIVITY_TEXT_MAX);
}

/** Grenze: Einträge vor diesem Zeitpunkt sind abgelaufen. */
function le_activity_cutoff(?int $now = null): int
{
    return ($now ?? time()) - LE_ACTIVITY_RETENTION_DAYS * 86400;
}

/** Einträge der Datei in Schreibreihenfolge (älteste zuerst), ohne abgelaufene und unlesbare Zeilen. */
function le_activity_entries(?int $now = null): array
{
    $raw = is_file(LE_ACTIVITY_FILE) ? @file_get_contents(LE_ACTIVITY_FILE) : '';
    if ($raw === false) {
        throw new RuntimeException('Cannot read ' . basename(LE_ACTIVITY_FILE));
    }
    $cutoff = le_activity_cutoff($now);
    $entries = [];
    foreach (explode("\n", $raw) as $line) {
        $entry = $line === '' ? null : json_decode($line, true);
        if (!is_array($entry) || !is_string($entry['time'] ?? null) || !is_string($entry['action'] ?? null)) {
            continue;
        }
        $time = strtotime($entry['time']);
        if ($time === false || $time < $cutoff) {
            continue;
        }
        $entries[] = [
            'time' => $entry['time'],
            'user' => (string) ($entry['user'] ?? ''),
            'action' => $entry['action'],
            'target' => (string) ($entry['target'] ?? ''),
        ];
    }
    return $entries;
}

/**
 * Schreibt die Datei ohne abgelaufene Einträge neu (atomar), aber nur, wenn der älteste einen Tag über
 * der Frist liegt; sonst liest es nur die erste Zeile. Der Aufrufer hält store_lock('activity').
 */
function le_activity_prune_if_due(?int $now = null): void
{
    $fh = is_file(LE_ACTIVITY_FILE) ? @fopen(LE_ACTIVITY_FILE, 'rb') : false;
    if ($fh === false) {
        return;
    }
    $first = json_decode((string) fgets($fh), true);
    fclose($fh);
    $oldest = is_array($first) && is_string($first['time'] ?? null) ? strtotime($first['time']) : false;
    // Eine unlesbare erste Zeile räumt ebenfalls auf.
    if ($oldest !== false && $oldest >= le_activity_cutoff($now) - LE_ACTIVITY_PRUNE_GRACE) {
        return;
    }
    $lines = array_map(static fn (array $entry): string => json_encode($entry, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n", le_activity_entries($now));
    write_private_file(LE_ACTIVITY_FILE, implode('', $lines));
}

/**
 * Seite der Ansicht „Aktivität“: neueste zuerst, optional nur eines Benutzers. Liefert entries (mit
 * label), total (Treffer insgesamt) und users (alle Benutzer im Log, ohne Namen fehlgeschlagener Logins).
 */
function le_activity_page(string $user = '', int $offset = 0, int $limit = LE_ACTIVITY_PAGE_SIZE, ?int $now = null): array
{
    $all = array_reverse(le_activity_entries($now));
    $users = array_values(array_unique(array_column(array_filter($all, static fn (array $e): bool => $e['action'] !== 'login_failed'), 'user')));
    natcasesort($users);
    $matches = $user === '' ? $all : array_values(array_filter($all, static fn (array $e): bool => $e['user'] === $user));
    $limit = max(1, min(LE_ACTIVITY_PAGE_MAX, $limit));
    $page = array_map(
        static fn (array $e): array => $e + ['label' => LE_ACTIVITY_LABELS[$e['action']] ?? $e['action']],
        array_slice($matches, max(0, $offset), $limit)
    );
    return ['entries' => $page, 'total' => count($matches), 'users' => array_values($users)];
}
