<?php
declare(strict_types=1);

// Versionsnummer an Dateien der Website (?v=…): Seiten für Besucher hängen sie an Stylesheets, Skripte, Bilder und
// Schriften, Stylesheets an ihre url(). Mit der aktuellen Nummer darf der Browser die Datei ein Jahr behalten
// (immutable); ändert sich die Datei, ändert sich die Nummer und damit die Adresse, der Browser lädt sie neu.
// Die Nummer eines Stylesheets enthält die seiner url()-Dateien: Ändert sich eine Schrift, bekommt auch das
// Stylesheet eine neue Adresse. Angemeldete (Seiten-Editor) bekommen Adressen ohne Nummer, damit sie nie in
// eine Seitendatei gespeichert wird.

const LE_ASSET_VERSION_PARAM = 'v';
const LE_ASSET_VERSION_MAX_AGE = 31536000;
const LE_ASSET_VERSION_LENGTH = 10;
// Elemente und Attribute, deren Adressen eine Nummer bekommen (srcset: Liste aus Adresse und Breite).
const LE_ASSET_VERSION_ATTRS = ['link' => ['href'], 'script' => ['src'], 'img' => ['src', 'srcset'], 'source' => ['src', 'srcset'], 'video' => ['src', 'poster'], 'audio' => ['src']];
const LE_ASSET_CODE_EXTENSIONS = ['css', 'js', 'mjs'];
// url(…) in CSS, mit oder ohne Anführungszeichen.
const LE_ASSET_CSS_URL_PATTERN = '/url\(\s*([\'"]?)([^\'")\s]+)\1\s*\)/i';

/**
 * Versionsnummer der Datei $file: aus Datum und Größe, bei Stylesheets samt den Nummern ihrer url()-Dateien.
 * Dient zugleich als ETag.
 */
function le_asset_version(string $file): string
{
    static $memo = [];
    if (isset($memo[$file])) {
        return $memo[$file];
    }
    $parts = dechex((int) @filemtime($file)) . '-' . dechex((int) @filesize($file));
    if (strtolower(pathinfo($file, PATHINFO_EXTENSION)) === 'css') {
        // Schutz gegen Stylesheets, die sich gegenseitig einbinden.
        $memo[$file] = '';
        foreach (le_asset_css_refs((string) @file_get_contents($file), $file) as $ref) {
            $parts .= ' ' . le_asset_version($ref);
        }
    }

    return $memo[$file] = substr(md5($parts), 0, LE_ASSET_VERSION_LENGTH);
}

/** Ob $version die aktuelle Nummer von $file ist (Anfrage mit ?v=…). */
function le_asset_version_matches(string $file, mixed $version): bool
{
    return is_string($version) && $version !== '' && hash_equals(le_asset_version($file), $version);
}

/** Seite für Besucher: Adressen eigener Dateien in LE_ASSET_VERSION_ATTRS bekommen ?v=…; $path: Adresse der Seite. */
function le_asset_versioned_html(string $html, string $path): string
{
    $doc = markup_parse($html);
    $base = $path;
    $baseIndex = markup_find_tag($doc, 'base');
    if ($baseIndex !== null) {
        $base = le_asset_resolve(markup_attr_text($doc['nodes'][$baseIndex], 'href'), $path) ?? $path;
    }
    $edits = [];
    foreach ($doc['nodes'] as $i => $node) {
        if ($node['type'] !== 'element' || !isset(LE_ASSET_VERSION_ATTRS[$node['tag']])) {
            continue;
        }
        foreach (LE_ASSET_VERSION_ATTRS[$node['tag']] as $name) {
            if (markup_attr($node, $name) === null) {
                continue;
            }
            $value = markup_attr_text($node, $name);
            $versioned = $name === 'srcset'
                ? implode(',', array_map(static fn (string $candidate): string => preg_replace_callback('/^(\s*)(\S+)/', static fn (array $m): string => $m[1] . le_asset_versioned_url($m[2], $base), $candidate), explode(',', $value)))
                : le_asset_versioned_url($value, $base);
            if ($versioned !== $value) {
                $edits[] = markup_set_attr($doc, $i, $name, markup_attr_escape($versioned));
            }
        }
    }

    return $edits === [] ? $html : markup_apply($html, $edits);
}

/** Stylesheet $css (Inhalt von $file, auch verkleinert): url() eigener Dateien bekommen ?v=…. */
function le_asset_versioned_css(string $css, string $file): string
{
    $base = le_asset_url_of($file);
    if ($base === null) {
        return $css;
    }

    return (string) preg_replace_callback(LE_ASSET_CSS_URL_PATTERN, static function (array $m) use ($base): string {
        $versioned = le_asset_versioned_url($m[2], $base);
        return $versioned === $m[2] ? $m[0] : 'url(' . $m[1] . $versioned . $m[1] . ')';
    }, $css);
}

/** Dateien, auf die die url() im Stylesheet $css (Datei $file) zeigen und die eine Nummer bekommen. */
function le_asset_css_refs(string $css, string $file): array
{
    $base = le_asset_url_of($file);
    if ($base === null || !preg_match_all(LE_ASSET_CSS_URL_PATTERN, $css, $m)) {
        return [];
    }
    $refs = [];
    foreach ($m[2] as $url) {
        $path = le_asset_resolve($url, $base);
        $ref = $path !== null ? le_asset_file($path) : null;
        if ($ref !== null) {
            $refs[$ref] = true;
        }
    }

    return array_keys($refs);
}

/** $url mit ?v=…, wenn sie auf eine eigene Datei zeigt (relativ zu $base aufgelöst), sonst unverändert. */
function le_asset_versioned_url(string $url, string $base): string
{
    $path = le_asset_resolve($url, $base);
    $file = $path !== null ? le_asset_file($path) : null;

    return $file === null ? $url : $url . '?' . LE_ASSET_VERSION_PARAM . '=' . le_asset_version($file);
}

/**
 * Adresse $url als Pfad dieser Website, aufgelöst gegen den Pfad $base ("/a/b" → Ordner /a/); null für fremde
 * Hosts, data:, Anker und Adressen mit Query oder Anker (schon versioniert oder ein Teil wie icons.svg#x).
 */
function le_asset_resolve(string $url, string $base): ?string
{
    $url = trim($url);
    if ($url === '' || strpbrk($url, '?#') !== false || preg_match('#^(?!https?://)[a-z][a-z0-9+.-]*:#i', $url)) {
        return null;
    }
    if (preg_match('#^(?:https?:)?//([^/]+)(/.*)?$#i', $url, $m)) {
        if (!in_array(strtolower($m[1]), le_asset_own_hosts(), true)) {
            return null;
        }
        $url = $m[2] ?? '/';
    } elseif (!str_starts_with($url, '/')) {
        $url = substr($base, 0, (int) strrpos($base, '/') + 1) . $url;
    }
    $segments = [];
    foreach (explode('/', rawurldecode($url)) as $part) {
        if ($part === '..') {
            if (array_pop($segments) === null) {
                return null;
            }
        } elseif ($part !== '' && $part !== '.') {
            $segments[] = $part;
        }
    }

    return '/' . implode('/', $segments);
}

/** Hosts dieser Website: aus der Einstellung „Website-URL“ und der Anfrage. */
function le_asset_own_hosts(): array
{
    $hosts = [];
    $base = le_site_base_url();
    if ($base !== null) {
        $hosts[] = strtolower((string) parse_url($base, PHP_URL_HOST));
    }
    if (isset($_SERVER['HTTP_HOST'])) {
        $hosts[] = strtolower((string) $_SERVER['HTTP_HOST']);
    }

    return $hosts;
}

/**
 * Datei hinter dem Pfad $path, die eine Nummer bekommt: Datei der Website (keine Seite, kein Upload; Uploads
 * bekommen ohnehin bei jedem Hochladen einen neuen Namen) oder CSS/JS eines Plugins; sonst null.
 */
function le_asset_file(string $path): ?string
{
    $extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    if (!in_array($extension, [...LE_ASSET_CODE_EXTENSIONS, ...LE_STATIC_MEDIA_EXTENSIONS], true)) {
        return null;
    }
    if (preg_match(LE_PLUGIN_ASSET_CODE_PATTERN, $path, $m)) {
        $file = LE_PROJECT_ROOT . '/plugins/' . $m[1] . '/assets/' . $m[2];
        return is_file($file) ? $file : null;
    }
    $file = le_site_request_file($path);
    $uploads = realpath(UPLOADS_ROOT);
    $real = $file !== null ? realpath($file) : false;

    return $real !== false && ($uploads === false || !str_starts_with($real, $uploads . '/')) ? $file : null;
}

/** Adresse, unter der die Datei $file ausgeliefert wird (Website: /public/site/…, Plugin: /plugins/…); null sonst. */
function le_asset_url_of(string $file): ?string
{
    $real = realpath($file);
    foreach ([[LE_SITE_ROOT, LE_SITE_FILES_URL], [LE_PROJECT_ROOT . '/plugins', '/plugins/']] as [$root, $url]) {
        $root = realpath($root);
        if ($real !== false && $root !== false && str_starts_with($real, $root . '/')) {
            return $url . substr($real, strlen($root) + 1);
        }
    }

    return null;
}
