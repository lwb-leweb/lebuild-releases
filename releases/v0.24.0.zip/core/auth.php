<?php
declare(strict_types=1);

require_once __DIR__ . '/utils.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/activity.php';

const LOGIN_MAX_FAILURES = 10;
const LOGIN_FAILURE_WINDOW = 900;
// Antwort bei Sperre; gilt für den Login und den Sicherungs-Abruf (gleicher Zähler).
const LOGIN_THROTTLED_MESSAGE = 'Zu viele Fehlversuche, bitte in ' . LOGIN_FAILURE_WINDOW / 60 . ' Minuten erneut versuchen.';
const LOGIN_THROTTLED_STATUS = 429;
// Je Benutzername (klein geschrieben, von jeder Adresse): Nach LOGIN_MAX_FAILURES Fehlversuchen im Fenster nur noch ein
// Versuch je so viele Sekunden. Bremst verteilte Angriffe. Ein Angreifer kann diese Versuche besetzen; deshalb gilt die
// Bremse nicht für Geräte, auf denen sich der Benutzer schon angemeldet hat (Cookie LE_LOGIN_DEVICE_COOKIE_PREFIX…).
const LE_LOGIN_USER_SLOW_SECONDS = 10;
// Bekanntes Gerät: signiertes Cookie je Benutzer nach erfolgreichem Login, so lange gültig.
const LE_LOGIN_DEVICE_COOKIE_PREFIX = 'le_device_';
const LE_LOGIN_DEVICE_DAYS = 180;
const LE_LOGIN_USER_SLOWED_MESSAGE = 'Zu viele Fehlversuche für diesen Benutzer, bitte in ' . LE_LOGIN_USER_SLOW_SECONDS . ' Sekunden erneut versuchen.';
// Feste Hashes eines Wegwerf-Passworts: Unbekannte Benutzernamen prüfen dagegen, damit die Antwortzeit
// nicht verrät, welche Namen es gibt. Je Kosten einer, passend zum password_hash dieses PHP (10 bis 8.3, 12 ab 8.4).
const LE_LOGIN_DUMMY_HASHES = [
    '$2y$10$h9Mwc0hXBxu/mFks5pinvu.FiYkUoHU2u4V0ZheIu.7RCWVc5mz7K',
    '$2y$12$ackoGkS4amPtsuoQrbVm3eOXmEKh.07n1t/ghVuws7URCofAieJpa',
];
// Login-Seite (index.php); `?next=` nennt das Ziel nach dem Login, siehe safe_redirect_path().
const LOGIN_URL = '/login';
// Ziel, wenn `next` fehlt oder nicht auf diese Website zeigt; Editoren landen von /admin aus hier.
const LE_SITE_HOME_URL = '/';
// Alter Name für Kundenseiten, die ihn nutzen; der Kern nutzt LE_SITE_HOME_URL.
if (!defined('SITE_HOME_URL')) {
    define('SITE_HOME_URL', LE_SITE_HOME_URL);
}
// Zugang des ersten Admins wie die wp-config.php von WordPress: Vorlage config.sample.php, ausgefüllt als
// config.php im Hauptordner. Gilt nur, solange es content/users.json nicht gibt (login_user).
const LE_SETUP_CONFIG_FILE = LE_INSTANCE_ROOT . '/config.php';
// Formulare in public/admin/login.html; ohne Benutzer und config.php steht dort der Hinweis (index.php).
const LE_LOGIN_FORMS_START = '<!-- le:login-forms -->';
const LE_LOGIN_FORMS_END = '<!-- /le:login-forms -->';

// Eigener Name für die Session des Editors: Sie teilt sich nie die PHP-Session der Kundenseite
// (PHPSESSID oder was Site-PHP nutzt). Login, Erkennung auf der Website, Abmelden und das Verwerfen
// leerer Sessions betreffen nur diese; die Session der Website wird nie gelesen, geleert oder verworfen.
const APP_SESSION_NAME = 'le_session';
// Kennung der Antwort auf ein ungültiges CSRF-Token (require_csrf); der Seiten-Editor erkennt daran
// eine inzwischen erneuerte Anmeldung (CSRF_ERROR_CODE in public/admin/site-editor/request.js).
const CSRF_ERROR_CODE = 'csrf';
// Eigener Ordner für die Session-Dateien des Editors: Den gemeinsamen Ordner des Servers räumen andere
// (Ubuntu per Cron nach 24 Minuten, andere Programme mit eigener Laufzeit) unvorhersehbar auf.
// Ohne Anfrage an den Server (Tippen zählt nicht) endet die Anmeldung nach LE_SESSION_IDLE Sekunden.
const LE_SESSION_DIR = CACHE_ROOT . '/sessions';
const LE_SESSION_IDLE = 8 * 3600;
// Fehlerprotokoll, wenn LE_SESSION_DIR im Mehrfachbetrieb nicht nutzbar ist (le_app_session_open).
const LE_SESSION_DIR_TEXT = 'Eigener Session-Ordner ' . LE_SESSION_DIR . ' ist nicht beschreibbar oder der Session-Handler ist nicht „files“; im Mehrfachbetrieb gibt es keinen gemeinsamen Ordner.';

/**
 * Führt $open (session_start, session_regenerate_id: beide öffnen die Datei) mit eigenem Ordner, eigener
 * Laufzeit und eigenem Aufräumen aus. Solange eine Session läuft, lässt PHP diese Werte nicht ändern (Warnung):
 * Sie werden nur ohne laufende Session gesetzt und zurückgesetzt. session_regenerate_id läuft so mit den Werten
 * vom Öffnen. Ist unsere Session offen, gelten sie bis zum Ende der Anfrage, auch nach session_write_close oder
 * session_destroy; zurückgesetzt wird nur, wenn das Öffnen scheitert. In index.php startet die Session der
 * Kundenseite vorher (Website-PHP rendert vor signed_in_user, start_app_session schließt sie) und behält den
 * Ordner des Servers; startet Code der Kundenseite seine Session erst nach unserer (nach signed_in_user oder
 * require_auth), landet sie im Editor-Ordner mit dessen Laufzeit.
 * Mit anderem Handler (z. B. Redis des Hosters) oder nicht beschreibbarem Ordner bleibt alles beim Server.
 * Nicht im Mehrfachbetrieb: Dort teilen sich alle Kunden den Ordner des Servers, ein Cookie von A gälte
 * bei einer Kopie von A; dann RuntimeException (500) statt einer Session.
 */
function le_app_session_open(callable $open): void
{
    $previous = [];
    $own = ini_get('session.save_handler') === 'files' && (is_dir(LE_SESSION_DIR) || @mkdir(LE_SESSION_DIR, 0700, true)) && is_writable(LE_SESSION_DIR);
    if (!$own && le_instance_is_multi()) {
        throw new RuntimeException(LE_SESSION_DIR_TEXT);
    }
    if ($own && session_status() !== PHP_SESSION_ACTIVE) {
        $settings = ['session.save_path' => LE_SESSION_DIR, 'session.gc_maxlifetime' => (string) LE_SESSION_IDLE, 'session.gc_probability' => '1', 'session.gc_divisor' => '100'];
        foreach ($settings as $key => $value) {
            $previous[$key] = (string) ini_get($key);
            ini_set($key, $value);
        }
    }
    try {
        $open();
    } finally {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            foreach ($previous as $key => $value) {
                ini_set($key, $value);
            }
        }
    }
}

// $quiet: ohne Cache-Header von PHP (Fortsetzen auf der Website, resume_app_session).
function start_app_session(bool $quiet = false): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        if (session_name() === APP_SESSION_NAME) {
            return;
        }
        // Site-PHP hat im selben Request (index.php) seine Session gestartet: so gespeichert und
        // geschlossen, wie sie ist; danach läuft unsere mit unserer ID.
        session_write_close();
        session_id(is_string($_COOKIE[APP_SESSION_NAME] ?? null) ? $_COOKIE[APP_SESSION_NAME] : '');
    }

    session_name(APP_SESSION_NAME);
    if ($quiet) {
        session_cache_limiter('');
    }
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
    le_app_session_open('session_start');
}

// Bestehende Anmeldung fortsetzen, aber nie eine neue Session anfangen: nur wenn der Browser
// unser Session-Cookie (APP_SESSION_NAME) mitschickt. Besucher der Website bekommen so kein Cookie.
// Ohne Cache-Header von PHP: ein fremdes oder abgelaufenes Cookie macht die Seite nicht uncachebar,
// persönliche Antworten setzen no-store selbst (index.php). Eine leere Session (abgelaufen, fremde
// ID) wird verworfen: keine leere Session-Datei, und mit session.use_strict_mode kein neues Cookie
// (PHP vergibt dort für eine unbekannte ID eine neue und schickt sie).
function resume_app_session(): bool
{
    if (!isset($_COOKIE[APP_SESSION_NAME])) {
        return false;
    }
    if (session_status() === PHP_SESSION_ACTIVE && session_name() === APP_SESSION_NAME) {
        return is_logged_in();
    }
    start_app_session(true);
    if ($_SESSION === []) {
        session_destroy();
        remove_session_cookie_header();
        return false;
    }
    return is_logged_in();
}

// Nimmt unser Session-Cookie aus den Antwort-Headern; andere Cookies (z. B. aus Site-PHP) bleiben.
function remove_session_cookie_header(): void
{
    $prefix = 'set-cookie: ' . strtolower(APP_SESSION_NAME) . '=';
    $cookies = array_filter(headers_list(), static fn (string $header): bool => stripos($header, 'set-cookie:') === 0);
    header_remove('Set-Cookie');
    foreach ($cookies as $cookie) {
        if (!str_starts_with(strtolower($cookie), $prefix)) {
            header($cookie, false);
        }
    }
}

/**
 * Inhalt von config.php und config.sample.php (gleiches Format): Nach dem Anlegen des Admins schreibt
 * le_setup_clear_password() die Datei neu, statt sie zu bearbeiten; Werte nur über var_export.
 */
function le_setup_config_source(string $username, string $password): string
{
    return "<?php\n"
        . "// Zugang des ersten Admins. Vor dem Hochladen nach config.php kopieren und ausfüllen.\n"
        . "// Beim ersten Login legt der Editor daraus den Admin an und leert das Passwort hier.\n"
        . "// Sobald es Benutzer gibt (content/users.json), gilt diese Datei nicht mehr.\n"
        . "return [\n"
        . sprintf("    // %d bis %d Zeichen: Buchstaben, Ziffern, Punkt, Unterstrich, Bindestrich.\n", USERNAME_MIN_LENGTH, USERNAME_MAX_LENGTH)
        . "    'username' => " . var_export($username, true) . ",\n"
        . sprintf("    // Mindestens %d Zeichen.\n", PASSWORD_MIN_LENGTH)
        . "    'password' => " . var_export($password, true) . ",\n"
        . "];\n";
}

/** Array aus config.php; null ohne Datei, bei Fehlern (ins Fehlerprotokoll) und ohne Array. */
function le_setup_config_read(): ?array
{
    if (!is_file(LE_SETUP_CONFIG_FILE)) {
        return null;
    }
    // Per FTP hochgeladen oder geändert: nie eine alte, übersetzte Fassung aus OPcache.
    forget_compiled_file(LE_SETUP_CONFIG_FILE);
    try {
        $config = (static fn () => include LE_SETUP_CONFIG_FILE)();
    } catch (Throwable $e) {
        users_log_once('config.php cannot be read: ' . $e->getMessage());
        return null;
    }
    return is_array($config) ? $config : null;
}

/** Benutzername und Passwort aus config.php, wenn beide gelten (users_validate_*); sonst null. */
function le_setup_credentials(): ?array
{
    $config = le_setup_config_read() ?? [];
    $username = is_string($config['username'] ?? null) ? trim($config['username']) : '';
    $password = is_string($config['password'] ?? null) ? $config['password'] : '';
    if (users_validate_username($username) !== null || users_validate_password($password) !== null) {
        return null;
    }
    return ['username' => $username, 'password' => $password];
}

/** Weder Benutzer noch ein brauchbares config.php: Niemand kommt hinein, /login zeigt den Hinweis. */
function le_setup_missing(): bool
{
    return !is_file(users_path()) && le_setup_credentials() === null;
}

/** Benutzer gibt es, aber in config.php steht noch ein Passwort (Systemprüfung). */
function le_setup_password_left(): bool
{
    $password = is_file(users_path()) ? (le_setup_config_read()['password'] ?? '') : '';
    return is_string($password) && $password !== '';
}

/** config.php ohne Passwort neu schreiben (atomar); scheitert es, bleibt der Admin und es steht im Fehlerprotokoll. */
function le_setup_clear_password(string $username): void
{
    try {
        write_file_atomic(LE_SETUP_CONFIG_FILE, le_setup_config_source($username, ''));
    } catch (RuntimeException $e) {
        error_log('lebuild: first admin created, but config.php still holds the password: ' . $e->getMessage());
    }
}

function auth_bootstrap_admin(string $username, string $password): ?array
{
    $now = current_iso_time();
    $hash = password_hash($password, PASSWORD_BCRYPT);
    if (!is_string($hash) || $hash === '') {
        return null;
    }
    $user = [
        'id' => users_generate_id(),
        'username' => $username,
        'passwordHash' => $hash,
        'role' => USER_ROLE_ADMIN,
        'createdAt' => $now,
        'updatedAt' => $now,
    ];
    // Unter der Sperre: Zwei gleichzeitige Erst-Logins legen nicht zwei Admins an.
    return users_update(static function (array &$store) use ($user): ?array {
        if (is_file(users_path())) {
            return null;
        }
        $store['users'][] = $user;
        return $user;
    });
}

/** Dummy-Hash mit denselben Kosten wie neue Hashes (users_needs_rehash bringt alte Konten dorthin). */
function le_login_dummy_hash(): string
{
    foreach (LE_LOGIN_DUMMY_HASHES as $hash) {
        if (!password_needs_rehash($hash, PASSWORD_BCRYPT)) {
            return $hash;
        }
    }
    return LE_LOGIN_DUMMY_HASHES[count(LE_LOGIN_DUMMY_HASHES) - 1];
}

function auth_complete_login(array $user): void
{
    le_app_session_open(static fn () => session_regenerate_id(true));
    $_SESSION['logged_in'] = true;
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['session_version'] = users_session_version($user);
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

/**
 * Nach der eigenen Passwortänderung: Die laufende Session bleibt angemeldet, bekommt aber eine
 * neue ID, ein neues CSRF-Token und den neuen Stand ($user aus users.json); alle anderen Sessions
 * des Benutzers enden (current_user).
 */
function auth_renew_session(array $user): void
{
    le_app_session_open(static fn () => session_regenerate_id(true));
    $_SESSION['session_version'] = users_session_version($user);
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

function login_user(string $username, string $password): bool
{
    $username = trim($username);
    if ($username === '' || $password === '') {
        return false;
    }

    // Mit kaputter users.json meldet sich niemand an (auch nicht mit config.php, users_load).
    if (!empty(users_load()['broken'])) {
        return false;
    }
    // config.php gilt nur, solange es users.json gar nicht gibt (Erst-Setup); danach ohne Passwort.
    if (!is_file(users_path())) {
        $setup = le_setup_credentials();
        if ($setup === null || !hash_equals($setup['username'], $username) || !hash_equals($setup['password'], $password)) {
            return false;
        }
        $bootstrapped = auth_bootstrap_admin($setup['username'], $setup['password']);
        if ($bootstrapped === null) {
            return false;
        }
        le_setup_clear_password($setup['username']);
        auth_complete_login($bootstrapped);
        return true;
    }

    $user = users_find_by_username($username);
    if ($user === null) {
        password_verify($password, le_login_dummy_hash());
        return false;
    }
    if (!users_verify_password($user, $password)) {
        return false;
    }

    if (users_needs_rehash($user)) {
        $newHash = password_hash($password, PASSWORD_BCRYPT);
        if (is_string($newHash) && $newHash !== '') {
            $user = users_update(static function (array &$store) use ($user, $newHash): array {
                foreach ($store['users'] as &$candidate) {
                    if ($candidate['id'] === $user['id']) {
                        $candidate['passwordHash'] = $newHash;
                        $candidate['updatedAt'] = current_iso_time();
                        return $candidate;
                    }
                }
                return $user;
            });
        }
    }

    auth_complete_login($user);
    return true;
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(APP_SESSION_NAME, '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}

function is_logged_in(): bool
{
    return !empty($_SESSION['logged_in']);
}

function current_user(): ?array
{
    if (!is_logged_in()) {
        return null;
    }
    $id = $_SESSION['user_id'] ?? null;
    if (!is_string($id) || $id === '') {
        return null;
    }
    $user = users_find_by_id($id);
    // Passwort seit dem Login geändert (selbst oder durch einen Admin): Diese Session gilt nicht mehr.
    if ($user === null || (int) ($_SESSION['session_version'] ?? 0) !== users_session_version($user)) {
        return null;
    }

    return $user;
}

// Benutzer der laufenden Session; eine Session ohne existierenden Benutzer (gelöscht) wird beendet.
function session_user(): ?array
{
    $user = current_user();
    if ($user === null && is_logged_in()) {
        logout_user();
    }
    return $user;
}

// Fertig angemeldeter Benutzer für Website, /login und /admin (index.php): Cookie mitgeschickt,
// Benutzer existiert, kein offener Passwortwechsel. Startet für Besucher keine Session.
function signed_in_user(): ?array
{
    if (!resume_app_session()) {
        return null;
    }
    $user = session_user();
    return $user !== null && empty($user['mustChangePassword']) ? $user : null;
}

// Ziel nach dem Login: nur ein Pfad dieser Website. Genau ein führender Slash, kein Backslash
// (Browser lesen ihn als Slash, `/\evil` wäre fremd) und keine Steuerzeichen; sonst LE_SITE_HOME_URL.
function safe_redirect_path(mixed $next): string
{
    if (!is_string($next) || !preg_match('#^/(?![/\\\\])[^\\\\\x00-\x1F\x7F]*$#D', $next)) {
        return LE_SITE_HOME_URL;
    }
    return $next;
}

// Hinweis „Update installiert“ aus dem Login (api/login.php) für Admins, bis das Backend
// (api/bootstrap.php) oder der Seiten-Editor (core/siteEditor.php) ihn einmal zeigt.
const UPDATE_NOTICE_SESSION_KEY = 'updateInstalled';

function remember_update_notice(?array $installed): void
{
    if ($installed !== null && is_admin()) {
        $_SESSION[UPDATE_NOTICE_SESSION_KEY] = $installed;
    }
}

/** Gemerkter Hinweis, nur einmal; null ohne oder für Nicht-Admins. */
function take_update_notice(): ?array
{
    $notice = $_SESSION[UPDATE_NOTICE_SESSION_KEY] ?? null;
    unset($_SESSION[UPDATE_NOTICE_SESSION_KEY]);
    return is_array($notice) && is_admin() ? $notice : null;
}

// Pfad der Seite dieser Website, von der die Anfrage kam (Referer mit gleichem Host), für die
// Rückkehr nach dem Login; null ohne, bei fremden Hosts, unsicheren Pfaden und der Login-Seite selbst.
function referer_path(): ?string
{
    $referer = parse_url((string) ($_SERVER['HTTP_REFERER'] ?? ''));
    if (!is_array($referer) || !isset($referer['host'])) {
        return null;
    }
    $host = $referer['host'] . (isset($referer['port']) ? ':' . $referer['port'] : '');
    if (strcasecmp($host, (string) ($_SERVER['HTTP_HOST'] ?? '')) !== 0) {
        return null;
    }
    $path = ($referer['path'] ?? '/') . (isset($referer['query']) ? '?' . $referer['query'] : '');
    return safe_redirect_path($path) === $path && rtrim((string) ($referer['path'] ?? ''), '/') !== LOGIN_URL ? $path : null;
}

function current_role(): ?string
{
    // Rolle immer aus users.json, nie aus der Session: gelöschte oder
    // herabgestufte Benutzer verlieren ihre Rechte sofort.
    return current_user()['role'] ?? null;
}

// Offener Passwortwechsel: nur noch Konten aus dem früheren Erst-Login mit admin/admin (vor config.php).
function must_change_password(): bool
{
    return !empty(current_user()['mustChangePassword']);
}

function is_admin(): bool
{
    return current_role() === USER_ROLE_ADMIN;
}

function require_auth(bool $allowPendingPasswordChange = false): void
{
    start_app_session();
    if (session_user() === null) {
        json_response(['ok' => false, 'error' => API_TEXT['notAuthenticated']], 401);
    }
    if (!$allowPendingPasswordChange && must_change_password()) {
        json_response(['ok' => false, 'error' => API_TEXT['passwordChange']], 403);
    }
}

function require_admin(): void
{
    require_auth();
    if (!is_admin()) {
        json_response(['ok' => false, 'error' => API_TEXT['forbidden']], 403);
    }
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf'];
}

function require_csrf(): void
{
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!is_string($token) || !hash_equals(csrf_token(), $token)) {
        json_response(['ok' => false, 'error' => API_TEXT['csrf'], 'code' => CSRF_ERROR_CODE], 403);
    }
}

/** Schlüssel der Login-Sperre für eine Adresse: IPv6 je /64-Netz (so viel bekommt jeder Anschluss), IPv4 je Adresse. */
function le_login_ip_key(string $ip): string
{
    $bin = @inet_pton($ip);
    if ($bin === false || strlen($bin) !== 16) {
        return $ip;
    }
    if (str_starts_with($bin, str_repeat("\0", 10) . "\xff\xff")) {
        return (string) inet_ntop(substr($bin, 12));
    }
    return bin2hex(substr($bin, 0, 8)) . '::/64';
}

function login_throttle_path(): string
{
    $ip = le_login_ip_key((string) ($_SERVER['REMOTE_ADDR'] ?? ''));
    return CACHE_ROOT . '/login-throttle/' . substr(hash_hmac('sha256', $ip, app_secret()), 0, 32) . '.json';
}

/** Zähler je Benutzername (u- davor, damit er neben denen der Adressen liegt); klein wie login_user() vergleicht (strcasecmp). */
function le_login_user_throttle_path(string $username): string
{
    return CACHE_ROOT . '/login-throttle/u-' . substr(hash_hmac('sha256', 'user:' . strtolower($username), app_secret()), 0, 32) . '.json';
}

/**
 * Verbucht einen Versuch für $username wie login_attempt_begin für die Adresse. false (nichts verbucht): Es gab schon
 * LOGIN_MAX_FAILURES Versuche im Fenster und der letzte ist keine LE_LOGIN_USER_SLOW_SECONDS her.
 */
function le_login_user_attempt_begin(string $username): bool
{
    $allowed = true;
    login_change_failures(static function (array $failures) use (&$allowed): ?array {
        if (count($failures) >= LOGIN_MAX_FAILURES && time() - max($failures) < LE_LOGIN_USER_SLOW_SECONDS) {
            $allowed = false;
            return null;
        }
        $failures[] = time();
        return $failures;
    }, le_login_user_throttle_path($username));
    return $allowed;
}

function le_login_device_cookie_name(string $username): string
{
    return LE_LOGIN_DEVICE_COOKIE_PREFIX . substr(hash_hmac('sha256', 'device-name:' . strtolower($username), app_secret()), 0, 16);
}

/**
 * Wert des Geräte-Cookies: Ausstellungszeit und Signatur über Benutzer-ID, sessionVersion und Zeit. Ein neues Passwort
 * (sessionVersion) oder ein neu angelegter Benutzer gleichen Namens macht alte Cookies ungültig.
 */
function le_login_device_value(string $username, int $issued): string
{
    $user = users_find_by_username($username);
    $bind = $user === null ? 'unbekannt' : $user['id'] . ':' . users_session_version($user);
    return $issued . '.' . hash_hmac('sha256', 'device:' . $bind . ':' . $issued, app_secret());
}

/** Hat sich $username in diesem Browser schon angemeldet (gültiges, nicht abgelaufenes Geräte-Cookie)? */
function le_login_device_known(string $username): bool
{
    $value = $username === '' ? null : ($_COOKIE[le_login_device_cookie_name($username)] ?? null);
    if (!is_string($value) || !preg_match('/^(\d{1,12})\.[0-9a-f]{64}$/', $value, $m)) {
        return false;
    }
    $issued = (int) $m[1];
    return $issued > time() - LE_LOGIN_DEVICE_DAYS * 86400 && $issued <= time() && hash_equals(le_login_device_value($username, $issued), $value);
}

/** Merkt das Gerät nach einem erfolgreichen Login (HttpOnly, wie das Session-Cookie). */
function le_login_device_remember(string $username): void
{
    $now = time();
    setcookie(le_login_device_cookie_name($username), le_login_device_value($username, $now), [
        'expires' => $now + LE_LOGIN_DEVICE_DAYS * 86400,
        // Nur der Login braucht es; die Seiten der Website bekommen es nicht.
        'path' => '/api/login.php',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
}

/** Nimmt den mit le_login_user_attempt_begin verbuchten Versuch zurück (Passwort richtig). */
function le_login_user_attempt_forget(string $username): void
{
    login_change_failures(static function (array $failures): array {
        array_pop($failures);
        return $failures;
    }, le_login_user_throttle_path($username));
}

/** Versuche im Fenster aus dem Inhalt einer Zähler-Datei (JSON-Liste von Zeitstempeln). */
function login_failures_in_window(string $raw): array
{
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        return [];
    }
    $cutoff = time() - LOGIN_FAILURE_WINDOW;
    return array_values(array_filter(array_map('intval', $data), static fn (int $ts): bool => $ts > $cutoff));
}

function login_recent_failures(): array
{
    return login_failures_in_window((string) @file_get_contents(login_throttle_path()));
}

/** Nur lesen, ohne zu verbuchen (api/backup.php vor allem anderen). */
function login_throttled(): bool
{
    return count(login_recent_failures()) >= LOGIN_MAX_FAILURES;
}

/**
 * Verbucht einen Versuch dieser IP, bevor Passwort oder Sicherungs-Schlüssel geprüft werden;
 * false (nichts verbucht), wenn schon LOGIN_MAX_FAILURES Versuche im Fenster liegen. Lesen und
 * Schreiben laufen unter flock auf der Zähler-Datei: Auch gleichzeitige Versuche zählen alle.
 * Ein gelungener Versuch nimmt nur sich selbst zurück (login_attempt_forget), frühere Fehlversuche
 * bleiben: Ein eigenes Konto setzt den Zähler für fremde Passwörter nicht zurück. Lässt
 * sich die Datei nicht anlegen, bleibt der Login möglich (wie ohne Zähler).
 */
function login_attempt_begin(): bool
{
    $allowed = true;
    login_change_failures(static function (array $failures) use (&$allowed): ?array {
        if (count($failures) >= LOGIN_MAX_FAILURES) {
            $allowed = false;
            return null;
        }
        $failures[] = time();
        return $failures;
    });
    return $allowed;
}

/** Nimmt einen mit login_attempt_begin verbuchten Versuch zurück (Login oder Sicherungs-Schlüssel richtig); es zählt nur die Zahl. */
function login_attempt_forget(): void
{
    login_change_failures(static function (array $failures): array {
        array_pop($failures);
        return $failures;
    });
}

/** Zähler-Datei unter flock lesen, $change anwenden (null: nicht schreiben) und zurückschreiben. */
function login_change_failures(callable $change, ?string $path = null): void
{
    $path ??= login_throttle_path();
    try {
        ensure_dir(dirname($path));
    } catch (RuntimeException $e) {
        error_log('login throttle: ' . $e->getMessage());
        return;
    }
    $handle = @fopen($path, 'c+');
    if ($handle === false || !flock($handle, LOCK_EX)) {
        error_log('login throttle: cannot lock ' . $path);
        if ($handle !== false) {
            fclose($handle);
        }
        return;
    }
    $failures = $change(login_failures_in_window((string) stream_get_contents($handle)));
    if ($failures !== null) {
        ftruncate($handle, 0);
        rewind($handle);
        fwrite($handle, (string) json_encode($failures));
        fflush($handle);
    }
    flock($handle, LOCK_UN);
    fclose($handle);
}
