<?php
declare(strict_types=1);

require_once __DIR__ . '/utils.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/textMarkup.php';

define('PLUGINS_ROOT', LE_PROJECT_ROOT . '/plugins');
// URL-Pfad, unter dem Plugin-Dateien (api/*.php) erreichbar sind.
const PLUGINS_URL = '/plugins/';
// Schema-Dateien je Treiber: install.sql / install.sqlite.sql usw.
const PLUGIN_SQL_SUFFIX = [
    DB_DRIVER_MYSQL  => '.sql',
    DB_DRIVER_SQLITE => '.sqlite.sql',
];
// plugin.json „inlineEdit“: Endpoints für Plugin-Listen auf der Seite; Wert = Pflicht.
const PLUGIN_INLINE_EDIT_ENDPOINTS = ['list' => true, 'get' => true, 'save' => true, 'delete' => true, 'sort' => false];
// Markierungen, an denen der Seiten-Editor Plugin-Listen und ihre Einträge erkennt.
const LE_LIST_ATTR = 'data-le-list';
const LE_ITEM_ATTR = 'data-le-item';
const LE_SINGLE_ATTR = 'data-le-single';
// Am Listen-Element: Ein Klick auf einen Eintrag öffnet beim Bearbeiten immer sein Formular, auch wenn
// der Eintrag ein Link ist (sonst zeigt ein Link „Öffnen →“). Setzen Plugins, deren Einträge als Ganzes
// verlinken (Content-Typen mit Vorlage).
const LE_ITEM_FORM_ATTR = 'data-le-item-form';
// Am Listen-Element: Die Reihenfolge ergibt sich aus den Einträgen (z. B. nach Datum), ↑/↓ entfällt.
const LE_FIXED_ORDER_ATTR = 'data-le-fixed-order';
// Ereignisse zwischen Seiten-Editor und Skripten der Website (CustomEvent, Namen auch in
// plugins/content-types/assets/modal.js; ein Test hält sie gleich):
// - LE_LIST_RELOADED_EVENT: am neu geladenen Listen-Element (bubbelt), nachdem der Editor es getauscht hat;
// - LE_ITEM_DIALOG_EVENT: an document, wenn ein Skript einen Eintrag in einem Dialog zeigt (detail.item:
//   Element im Eintrag) oder ihn schließt (detail.item: null); die Leiste bietet dann „Bearbeiten“.
const LE_LIST_RELOADED_EVENT = 'le-list-reloaded';
const LE_ITEM_DIALOG_EVENT = 'le-item-dialog';
// Beschriftung des Knopfes an der Einzelansicht; das Plugin gibt sie mit, sonst LE_SINGLE_LABEL.
const LE_SINGLE_LABEL_ATTR = 'data-le-single-label';
const LE_SINGLE_LABEL = 'Diesen Beitrag bearbeiten';
// Wert der Markierung: "<plugin>/<typ>" (Plugin bis zum ersten Trenner).
const LE_KEY_SEPARATOR = '/';
// Richtungen beim Sortieren (inlineEdit „sort“: {type, id, direction}).
const INLINE_EDIT_SORT_UP = 'up';
const INLINE_EDIT_SORT_DOWN = 'down';
// Antwort des Hooks site_page, wenn die Adresse dem Plugin gehört, es dort aber nichts gibt (404-Seite der Website).
const PLUGIN_SITE_PAGE_NOT_FOUND = ['notFound' => true];

function plugin_name_valid(string $name): bool
{
    return (bool) preg_match('/^[a-z][a-z0-9_-]*$/', $name);
}

function plugin_table_name_valid(string $name): bool
{
    return (bool) preg_match('/^[a-z][a-z0-9_]*$/', $name);
}

function plugin_path(string $name, string $sub = ''): string
{
    if (!plugin_name_valid($name)) {
        throw new InvalidArgumentException('Invalid plugin name: ' . $name);
    }

    $base = PLUGINS_ROOT . '/' . $name;
    if ($sub === '') {
        return $base;
    }

    $normalized = str_replace('\\', '/', ltrim($sub, '/'));
    if ($normalized === '' || str_contains($normalized, '..')) {
        throw new InvalidArgumentException('Invalid plugin path: ' . $sub);
    }

    return $base . '/' . $normalized;
}

/** Pfad der install-/uninstall-Datei für den aktiven (oder angegebenen) Treiber. */
function plugin_sql_path(string $name, string $kind, ?string $driver = null): string
{
    if ($kind !== 'install' && $kind !== 'uninstall') {
        throw new InvalidArgumentException('Invalid sql kind: ' . $kind);
    }
    return plugin_path($name, $kind . PLUGIN_SQL_SUFFIX[$driver ?? db_driver()]);
}

/** Meldung, wenn einem Plugin die install-Datei für einen Treiber fehlt. */
function plugin_schema_missing_message(string $name, string $driver): string
{
    return 'Dem Plugin ' . $name . ' fehlt ' . basename(plugin_sql_path($name, 'install', $driver)) . ' für die Datenbank ' . $driver . '.';
}

function plugin_manifest(string $name): array
{
    static $cache = [];

    if (!plugin_name_valid($name)) {
        throw new InvalidArgumentException('Invalid plugin name: ' . $name);
    }
    if (isset($cache[$name])) {
        return $cache[$name];
    }

    $path = plugin_path($name, 'plugin.json');
    if (!is_file($path)) {
        throw new RuntimeException('Plugin manifest not found: ' . $name);
    }

    $data = json_decode((string) file_get_contents($path), true);
    if (!is_array($data)) {
        throw new RuntimeException('Invalid plugin manifest JSON: ' . $name);
    }
    if (($data['name'] ?? '') !== $name) {
        throw new RuntimeException('Plugin manifest name mismatch: ' . $name);
    }
    foreach (['label', 'version', 'requires'] as $required) {
        if (!array_key_exists($required, $data)) {
            throw new RuntimeException('Missing plugin manifest key "' . $required . '": ' . $name);
        }
    }

    $data['requires'] = array_merge(
        ['database' => false, 'mail' => false, 'uploads' => false],
        is_array($data['requires']) ? $data['requires'] : []
    );
    $data['tables'] = plugin_valid_tables($data['tables'] ?? []);
    if (array_key_exists('inlineEdit', $data)) {
        $data['inlineEdit'] = plugin_valid_inline_edit($name, $data['inlineEdit']);
    }

    $cache[$name] = $data;
    return $data;
}

function plugin_valid_tables(mixed $tables): array
{
    if (!is_array($tables)) {
        return [];
    }

    $valid = [];
    foreach ($tables as $table) {
        if (is_string($table) && plugin_table_name_valid($table)) {
            $valid[] = $table;
        }
    }

    return array_values(array_unique($valid));
}

/**
 * inlineEdit aus plugin.json: je Aktion ein Pfad „api/<datei>.php“ (optional mit fester Query),
 * der im Plugin existiert. list, get, save, delete sind Pflicht, sort nur bei Plugins mit Reihenfolge.
 */
function plugin_valid_inline_edit(string $name, mixed $inlineEdit): array
{
    $error = new RuntimeException('Invalid plugin manifest key "inlineEdit": ' . $name);
    if (!is_array($inlineEdit) || array_diff_key($inlineEdit, PLUGIN_INLINE_EDIT_ENDPOINTS) !== []) {
        throw $error;
    }

    $valid = [];
    foreach (PLUGIN_INLINE_EDIT_ENDPOINTS as $action => $required) {
        $endpoint = $inlineEdit[$action] ?? null;
        if ($endpoint === null && !$required) {
            continue;
        }
        if (!is_string($endpoint) || !preg_match('#^api/[a-z0-9_-]+\.php(\?[a-z0-9_=&-]+)?$#i', $endpoint)
            || !is_file(plugin_path($name, (string) strtok($endpoint, '?')))) {
            throw $error;
        }
        $valid[$action] = $endpoint;
    }

    return $valid;
}

/** URLs der inlineEdit-Endpoints aller aktiven Plugins, die mitmachen: [Plugin => [Aktion => URL]]. */
function plugin_inline_edit_config(): array
{
    $config = [];
    foreach (load_plugins_state()['active'] as $name) {
        try {
            $inlineEdit = plugin_manifest($name)['inlineEdit'] ?? null;
        } catch (Throwable $e) {
            continue;
        }
        if ($inlineEdit === null) {
            continue;
        }
        $config[$name] = array_map(static fn (string $endpoint): string => PLUGINS_URL . $name . '/' . $endpoint, $inlineEdit);
    }

    return $config;
}

/**
 * Was der Seiten-Editor für Plugin-Listen braucht: Endpoints, Markierungen, Trenner, Sortier-Richtungen,
 * Ereignisse und die Beschriftung des Knopfes an Einzelansichten ohne eigene (LE_SINGLE_LABEL).
 */
function plugin_lists_config(): array
{
    return [
        'endpoints' => plugin_inline_edit_config(),
        'attrs' => ['list' => LE_LIST_ATTR, 'item' => LE_ITEM_ATTR, 'single' => LE_SINGLE_ATTR, 'singleLabel' => LE_SINGLE_LABEL_ATTR, 'itemForm' => LE_ITEM_FORM_ATTR, 'fixedOrder' => LE_FIXED_ORDER_ATTR],
        'separator' => LE_KEY_SEPARATOR,
        'directions' => ['up' => INLINE_EDIT_SORT_UP, 'down' => INLINE_EDIT_SORT_DOWN],
        'singleLabel' => LE_SINGLE_LABEL,
        'events' => ['listReloaded' => LE_LIST_RELOADED_EVENT, 'itemDialog' => LE_ITEM_DIALOG_EVENT],
    ];
}

/** Attribut, das eine Plugin-Liste für den Seiten-Editor markiert (escaped, auch für Besucher). */
function le_list_attrs(string $plugin, string $type): string
{
    return LE_LIST_ATTR . '="' . markup_attr_escape(le_key($plugin, $type)) . '"';
}

/** Wert der Markierung einer Liste oder Einzelansicht (unescaped). */
function le_key(string $plugin, string $type): string
{
    return $plugin . LE_KEY_SEPARATOR . $type;
}

/** Attribut, das einen Eintrag einer Plugin-Liste markiert. */
function le_item_attrs(int $id): string
{
    return LE_ITEM_ATTR . '="' . $id . '"';
}

/** Markiert die Ausgabe einer Vorlage als Eintrag einer Liste (le_mark mit le_item_attrs()). */
function le_item_mark(string $html, int $id): string
{
    return le_mark($html, [LE_ITEM_ATTR => (string) $id]);
}

/** Markiert die Ausgabe einer Vorlage als Einzelansicht eines Eintrags (le_mark mit le_single_values()). */
function le_single_mark(string $html, string $plugin, string $type, int $id, string $label = LE_SINGLE_LABEL): string
{
    return le_mark($html, le_single_values($plugin, $type, $id, $label));
}

/**
 * Markiert die Ausgabe einer Vorlage ohne zusätzliches Element: die Attribute $attrs (Name → Wert, roh)
 * kommen ins einzige Wurzelelement (z. B. die Karte im Grid der Website). Hat die Ausgabe mehrere
 * Elemente oder Text außerhalb, wird sie in ein markiertes <div> gehüllt.
 */
function le_mark(string $html, array $attrs): string
{
    $doc = markup_parse($html);
    $element = null;
    foreach ($doc['roots'] as $index) {
        $node = $doc['nodes'][$index];
        if ($node['type'] === 'comment' || ($node['type'] === 'text' && trim(substr($html, $node['start'], $node['end'] - $node['start'])) === '')) {
            continue;
        }
        if ($node['type'] !== 'element' || $element !== null) {
            $element = false;
            break;
        }
        $element = $index;
    }
    if (!is_int($element)) {
        return '<div ' . le_attrs($attrs) . '>' . $html . '</div>';
    }

    return markup_apply($html, array_map(static fn (string $name, string $value): array => markup_set_attr($doc, $element, $name, markup_attr_escape($value)), array_keys($attrs), $attrs));
}

/**
 * Attribute für die Einzelansicht eines Eintrags (z. B. eigene Seite eines Content-Typ-Eintrags): bearbeitbar wie ein Listeneintrag,
 * aber keine Liste (kein „+ Hinzufügen“). $label: Beschriftung des Knopfes (Konstante des Plugins), ohne
 * LE_SINGLE_LABEL.
 */
function le_single_attrs(string $plugin, string $type, int $id, string $label = LE_SINGLE_LABEL): string
{
    return le_attrs(le_single_values($plugin, $type, $id, $label));
}

/** Markierung der Einzelansicht als [Name => Wert], roh (le_single_attrs, le_single_mark). */
function le_single_values(string $plugin, string $type, int $id, string $label): array
{
    return [LE_SINGLE_ATTR => le_key($plugin, $type), LE_ITEM_ATTR => (string) $id, LE_SINGLE_LABEL_ATTR => $label];
}

/** Attribute aus [Name => Wert] als Text: Werte escaped, durch Leerzeichen getrennt (le_mark, Vorlagen der Plugins). */
function le_attrs(array $attrs): string
{
    $out = [];
    foreach ($attrs as $name => $value) {
        $out[] = $name . '="' . markup_attr_escape((string) $value) . '"';
    }

    return implode(' ', $out);
}

function list_plugin_dirs(): array
{
    if (!is_dir(PLUGINS_ROOT)) {
        return [];
    }

    $names = [];
    foreach (scandir(PLUGINS_ROOT) ?: [] as $entry) {
        if ($entry === '.' || $entry === '..' || !plugin_name_valid($entry)) {
            continue;
        }
        if (!is_dir(PLUGINS_ROOT . '/' . $entry)) {
            continue;
        }
        if (!is_file(PLUGINS_ROOT . '/' . $entry . '/plugin.json')) {
            continue;
        }
        $names[] = $entry;
    }
    sort($names);

    return $names;
}

function plugins_state_path(): string
{
    return CONTENT_ROOT . '/active-plugins.json';
}

function plugin_data_path(string $name): string
{
    if (!plugin_name_valid($name)) {
        throw new InvalidArgumentException('Invalid plugin name: ' . $name);
    }
    return CONTENT_ROOT . '/plugins/' . $name;
}

function load_plugins_state(): array
{
    $path = plugins_state_path();
    if (!is_file($path)) {
        return ['active' => [], 'installed' => []];
    }

    $data = json_decode((string) file_get_contents($path), true);
    return plugins_state_normalize(is_array($data) ? $data : []);
}

/** Beim Lesen und Schreiben: nur gültige Plugin-Namen, active ohne Doppelte, installed mit geprüften Tabellennamen. */
function plugins_state_normalize(array $state): array
{
    $active = [];
    foreach (is_array($state['active'] ?? null) ? $state['active'] : [] as $name) {
        if (is_string($name) && plugin_name_valid($name)) {
            $active[] = $name;
        }
    }
    $installed = [];
    foreach (is_array($state['installed'] ?? null) ? $state['installed'] : [] as $name => $meta) {
        if (is_string($name) && plugin_name_valid($name) && is_array($meta)) {
            $meta['tables'] = plugin_valid_tables($meta['tables'] ?? []);
            $installed[$name] = $meta;
        }
    }
    return ['active' => array_values(array_unique($active)), 'installed' => $installed];
}

function save_plugins_state(array $state): void
{
    $path = plugins_state_path();
    $payload = plugins_state_normalize($state);
    // Leer als {} statt [], wie bisher in active-plugins.json.
    if ($payload['installed'] === []) {
        $payload['installed'] = new stdClass();
    }

    $json = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        throw new RuntimeException('Cannot encode active-plugins.json');
    }

    write_file_atomic($path, $json . PHP_EOL);
}

function plugin_active(string $name): bool
{
    if (!plugin_name_valid($name)) {
        return false;
    }

    $state = load_plugins_state();
    return in_array($name, $state['active'], true);
}

/** plugin_manifest() für API-Endpoints: Ist plugin.json fehlerhaft, antwortet der Request mit 500 und fester Meldung (Details ins Log). */
function le_plugin_manifest_or_fail(string $name): array
{
    try {
        return plugin_manifest($name);
    } catch (Throwable $e) {
        error_log('plugin manifest ' . $name . ': ' . $e->getMessage());
        json_response(['ok' => false, 'error' => API_TEXT['pluginInvalid']], 500);
    }
}

function require_plugin_active(string $name): void
{
    if (!plugin_active($name)) {
        json_response(['ok' => false, 'error' => API_TEXT['pluginNotActive']], 404);
    }
    // Zentrale Sperre während eines Datenumzugs: schreibende Requests von
    // Plugins mit Datenbank → 503, Lesen läuft weiter aus der alten Quelle.
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if ($method !== 'GET' && $method !== 'HEAD' && !empty(le_plugin_manifest_or_fail($name)['requires']['database'])) {
        require_no_db_migration();
    }
}

function plugin_installed(string $name): bool
{
    if (!plugin_name_valid($name)) {
        return false;
    }

    $state = load_plugins_state();
    return isset($state['installed'][$name]);
}

/**
 * Tabellen installierter Plugins, die in der Datenbank fehlen, aus install.sql
 * neu anlegen. Passiert, wenn active-plugins.json ohne die Datenbank ankommt
 * (frische Installation aus dem Repo, gelöschte site.sqlite, neue MySQL-DB).
 * Fehler landen im Log; der eigentliche Request meldet dann „no such table“.
 * Nicht auf der Kommandozeile: Restore und Umzug legen Tabellen selbst an.
 */
function plugin_restore_missing_tables(PDO $pdo): void
{
    if (PHP_SAPI === 'cli' || db_migration_running()) {
        return;
    }
    $driver = db_driver();
    foreach (load_plugins_state()['installed'] as $name => $meta) {
        try {
            le_plugin_create_missing_tables($pdo, $driver, $name, $meta['tables'] ?? []);
        } catch (Throwable $e) {
            error_log('plugin ' . $name . ': ' . $e->getMessage());
        }
    }
}

/**
 * Fehlende Tabellen $tables des Plugins $name aus seiner install-Datei für $driver anlegen; liefert die angelegten.
 * Wirft, wenn die Datei fehlt (plugin_schema_missing_message) oder scheitert (dann bleibt keine halbe Tabelle, db_run_schema).
 */
function le_plugin_create_missing_tables(PDO $pdo, string $driver, string $name, array $tables): array
{
    $missing = array_values(array_filter($tables, static fn (string $table): bool => !db_table_exists($pdo, $table)));
    if ($missing === []) {
        return [];
    }
    $sqlPath = plugin_sql_path($name, 'install', $driver);
    if (!is_file($sqlPath)) {
        throw new RuntimeException(plugin_schema_missing_message($name, $driver));
    }
    try {
        db_run_schema($pdo, $driver, (string) file_get_contents($sqlPath), $tables);
    } catch (Throwable $e) {
        throw new RuntimeException(sprintf(API_TEXT['installSqlFailed'], basename($sqlPath), $e->getMessage()), 0, $e);
    }

    return $missing;
}

function plugin_has_admin_sidebar(array $manifest): bool
{
    return is_array($manifest['admin']['sidebar'] ?? null);
}

function active_plugin_admin_info(): array
{
    $state = load_plugins_state();
    $info = [];

    foreach ($state['active'] as $name) {
        try {
            $manifest = plugin_manifest($name);
        } catch (Throwable $e) {
            continue;
        }
        if (!plugin_has_admin_sidebar($manifest)) {
            continue;
        }

        $extra = plugin_extra_sidebar_entries($name);
        if ($extra !== null) {
            foreach ($extra as $entry) {
                $info[] = $entry;
            }
            continue;
        }

        $sidebar = $manifest['admin']['sidebar'];
        $module = plugin_admin_module_path($manifest);
        $info[] = [
            'name' => $name,
            'route' => $name,
            'label' => (string) ($sidebar['label'] ?? $manifest['label'] ?? $name),
            'hasAdminModule' => $module !== null,
            'hasSchema' => isset($manifest['schema']['fields']) && is_array($manifest['schema']['fields']),
        ];
    }

    return $info;
}

/** Hook-Funktion „<plugin>_<hook>“ aus der lib.php des Plugins (siehe knowledgebase/hooks.md), null ohne. */
function plugin_hook_function(string $name, string $hook): ?string
{
    if (!plugin_name_valid($name)) {
        return null;
    }
    $libPath = plugin_path($name, 'lib.php');
    if (!is_file($libPath)) {
        return null;
    }
    require_once $libPath;
    $fn = str_replace('-', '_', $name) . '_' . $hook;

    return function_exists($fn) ? $fn : null;
}

function plugin_extra_sidebar_entries(string $name): ?array
{
    $fn = plugin_hook_function($name, 'admin_sidebar_entries');
    if ($fn === null) {
        return null;
    }

    try {
        $entries = $fn();
    } catch (Throwable $e) {
        return null;
    }
    if (!is_array($entries)) {
        return null;
    }

    $valid = [];
    foreach ($entries as $entry) {
        if (!is_array($entry)) {
            continue;
        }
        $route = $entry['route'] ?? null;
        $label = $entry['label'] ?? null;
        if (!is_string($route) || !is_string($label) || $label === '') {
            continue;
        }
        if (!preg_match('/^[a-z][a-z0-9_-]*(\/[a-z][a-z0-9_-]+)*$/', $route)) {
            continue;
        }
        $entry['name'] = $name;
        $entry['route'] = $route;
        $entry['label'] = $label;
        $entry['hasAdminModule'] = !empty($entry['hasAdminModule']);
        $entry['hasSchema'] = !empty($entry['hasSchema']);
        $valid[] = $entry;
    }

    return $valid;
}

function plugin_admin_module_path(array $manifest): ?string
{
    $module = $manifest['admin']['sidebar']['module'] ?? null;
    if (!is_string($module) || trim($module) === '') {
        return null;
    }
    if (str_contains(str_replace('\\', '/', $module), '..')) {
        return null;
    }

    return $module;
}

function filter_site_html(string $html): string
{
    $state = load_plugins_state();
    foreach ($state['active'] as $name) {
        $fn = plugin_hook_function($name, 'filter_site_html');
        if ($fn === null) {
            continue;
        }
        try {
            $next = $fn($html);
        } catch (Throwable $e) {
            error_log('filter_site_html ' . $name . ' failed: ' . $e->getMessage());
            continue;
        }
        if (is_string($next)) {
            $html = $next;
        }
    }

    return $html;
}

/**
 * Seite eines Plugins unter einer Adresse, die keine Datei der Website ist (Abfrage-Hook site_page,
 * z. B. /<pfad>/<slug> von Content-Typen): ein Dokument wie le_site_document() (index.php bindet es auf oberster
 * Ebene ein) oder PLUGIN_SITE_PAGE_NOT_FOUND; null, wenn die Adresse keinem aktiven Plugin gehört.
 */
function plugin_site_page(string $path): ?array
{
    foreach (load_plugins_state()['active'] as $name) {
        $fn = plugin_hook_function($name, 'site_page');
        if ($fn === null) {
            continue;
        }
        try {
            $page = $fn($path);
        } catch (Throwable $e) {
            error_log('site_page ' . $name . ' failed: ' . $e->getMessage());
            continue;
        }
        if (is_array($page)) {
            return $page;
        }
    }

    return null;
}

/**
 * Titel bzw. Adresse einer Rohzeile der Tabelle $table des Plugins $plugin für Meldungen (Abfrage-Hook entry_label,
 * z. B. Konfliktliste beim Einspielen von Plugin-Daten); '' ohne Hook oder wenn er wirft.
 */
function le_plugin_entry_label(string $plugin, string $table, array $row): string
{
    $fn = plugin_hook_function($plugin, 'entry_label');
    try {
        $label = $fn !== null ? $fn($table, $row) : '';
    } catch (Throwable $e) {
        error_log('entry_label ' . $plugin . ' failed: ' . $e->getMessage());
        return '';
    }

    return is_string($label) ? $label : '';
}

/**
 * Grund, warum eine eben geschriebene Rohzeile (mit id) der Tabelle $table so nicht bleiben darf (Abfrage-Hook
 * entry_problem, z. B. Adresse schon vergeben, Typ unbekannt); null ohne. Läuft in der Transaktion des Schreibens,
 * sieht also den neuen Stand. Eine Exception geht weiter (der Aufrufer bricht ab).
 */
function le_plugin_entry_problem(string $plugin, string $table, array $row): ?string
{
    $fn = plugin_hook_function($plugin, 'entry_problem');
    $problem = $fn !== null ? $fn($table, $row) : null;

    return is_string($problem) && $problem !== '' ? $problem : null;
}

/**
 * Aktion entry_updated: Zeile $before der Tabelle $table ist jetzt $after (beide Rohzeilen), geändert außerhalb des
 * Speicherns des Plugins (Einspielen von Plugin-Daten). Jedes aktive Plugin kann nachziehen (z. B. Verweise auf einen
 * umbenannten Eintrag), in derselben Transaktion; eine Exception geht weiter und alles wird zurückgenommen.
 */
function le_action_entry_updated(string $table, array $before, array $after): void
{
    foreach (load_plugins_state()['active'] as $name) {
        $fn = plugin_hook_function($name, 'action_entry_updated');
        if ($fn !== null) {
            $fn($table, $before, $after);
        }
    }
}

// Adresse aus dem Hook sitemap_urls: Pfad auf der Website, Sonderzeichen kodiert (rawurlencode).
const PLUGIN_SITEMAP_PATH_PATTERN = '#^/[A-Za-z0-9._~/%@-]*$#';

/**
 * Eigene Adressen der aktiven Plugins für die Sitemap (Abfrage-Hook sitemap_urls, z. B. Eintragsseiten von
 * Content-Typen) als [Pfad => Zeitstempel der letzten Änderung oder null]. Der Hook liefert eine Liste von
 * ['path' => '/beitraege/x', 'lastmod' => Zeitstempel, Datumstext oder null]; ungültige Pfade fallen weg,
 * ein werfender Hook zählt nicht (Log).
 */
function plugin_sitemap_urls(): array
{
    $urls = [];
    foreach (load_plugins_state()['active'] as $name) {
        $fn = plugin_hook_function($name, 'sitemap_urls');
        if ($fn === null) {
            continue;
        }
        try {
            $list = $fn();
        } catch (Throwable $e) {
            error_log('sitemap_urls ' . $name . ' failed: ' . $e->getMessage());
            continue;
        }
        foreach (is_array($list) ? $list : [] as $url) {
            $path = is_array($url) ? ($url['path'] ?? null) : null;
            if (!is_string($path) || !preg_match(PLUGIN_SITEMAP_PATH_PATTERN, $path) || str_contains($path, '..')) {
                continue;
            }
            $lastmod = $url['lastmod'] ?? null;
            $urls[$path] = match (true) {
                is_int($lastmod) => $lastmod,
                is_string($lastmod) && $lastmod !== '' => strtotime($lastmod) ?: null,
                default => null,
            };
        }
    }

    return $urls;
}

function plugin_sanitize_richtext(string $html): string
{
    $allowed = '<p><br><strong><b><em><i><u><ul><ol><li><a><blockquote><h2><h3><h4>';
    $clean = strip_tags($html, $allowed);
    // Start-Tags über den Zerleger neu aufbauen, damit jede Schreibweise (ohne Anführungszeichen,
    // ohne Leerraum zwischen Attributen) gleich behandelt wird.
    $clean = preg_replace_callback('/<[a-z](?:[^>"\']|"[^"]*"|\'[^\']*\')*>/i', static fn (array $m): string => plugin_richtext_tag($m[0]), $clean) ?? '';

    return trim($clean);
}

/**
 * Ein Start-Tag ohne on*- und style-Attribute; href nach derselben Regel wie Textfelder
 * (core/textMarkup.php), ein unerlaubtes Schema verliert das href.
 */
function plugin_richtext_tag(string $tag): string
{
    $doc = markup_parse($tag);
    $node = $doc['nodes'][$doc['roots'][0]];
    $out = '<' . $node['tag'];
    $seen = [];
    foreach ($node['attrs'] as $attr) {
        $name = strtolower($attr['name']);
        if (isset($seen[$name]) || $attr['has_php'] || str_starts_with($name, 'on') || $name === 'style' || !preg_match('/^[a-z][a-z0-9_:.-]*$/', $name)) {
            continue;
        }
        $seen[$name] = true;
        // Erstes Attribut dieses Namens (Doppelte übersprungen); ohne Wert (hidden, download) leer.
        $value = markup_attr_text($node, $name);
        if ($name === 'href') {
            $value = sanitize_url($value, TEXT_LINK_SCHEMES);
            if ($value === '') {
                continue;
            }
        }
        $out .= ' ' . $name . '="' . markup_attr_escape($value) . '"';
    }
    return $out . '>';
}
