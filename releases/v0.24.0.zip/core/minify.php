<?php
declare(strict_types=1);

// CSS und JS der Website gehen verkleinert an den Browser, ohne Build-Step: index.php liefert statt der Datei eine
// verkleinerte Kopie aus LE_MINIFY_ROOT, die beim ersten Abruf nach jeder Änderung entsteht. Die Quelldatei bleibt,
// wie sie ist. Verkleinert wird vorsichtig (Kommentare, Einrückung, Leerraum um Satzzeichen); im Zweifel bleibt
// ein Zeichen stehen. Schlägt etwas fehl, geht die Quelldatei unverändert raus.

require_once __DIR__ . '/utils.php';

const LE_MINIFY_ROOT = CACHE_ROOT . '/min';
const LE_MINIFY_EXTENSIONS = ['css', 'js', 'mjs'];
// CSS und JS der Plugins für die Website, die index.php verkleinert ausliefert: /plugins/<name>/assets/<pfad>; keine
// Punkt-Stücke (Caddy und .htaccess leiten dieselbe Form an index.php).
const LE_PLUGIN_ASSET_CODE_PATTERN = '#^/plugins/([a-z][a-z0-9_-]*)/assets/((?:[A-Za-z0-9_-][A-Za-z0-9._-]*/)*[A-Za-z0-9_-][A-Za-z0-9._-]*\.(?:css|js|mjs))$#i';

/**
 * Verkleinerte Kopie von $file (CSS, JS) als Pfad; null für andere Dateien, schon verkleinerte (*.min.css,
 * *.min.js) und wenn die Kopie sich nicht anlegen lässt. Der Name hängt an Pfad, Datum und Größe der Quelle; ältere
 * Kopien derselben Quelle fallen beim Anlegen weg.
 */
function le_minified_file(string $file): ?string
{
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    $real = realpath($file);
    if (!in_array($ext, LE_MINIFY_EXTENSIONS, true) || $real === false || str_ends_with(strtolower($file), '.min.' . $ext)) {
        return null;
    }
    $key = sha1($real);
    $target = LE_MINIFY_ROOT . '/' . $key . '-' . dechex((int) filemtime($real)) . '-' . dechex((int) filesize($real)) . '.' . $ext;
    if (is_file($target)) {
        return $target;
    }
    try {
        $source = (string) file_get_contents($real);
        $min = $ext === 'css' ? le_minify_css($source) : le_minify_js($source);
        if (!is_dir(LE_MINIFY_ROOT) && !@mkdir(LE_MINIFY_ROOT, 0777 & ~umask(), true) && !is_dir(LE_MINIFY_ROOT)) {
            return null;
        }
        foreach (glob(LE_MINIFY_ROOT . '/' . $key . '-*') ?: [] as $old) {
            @unlink($old);
        }
        write_file_atomic($target, $min);
    } catch (Throwable $e) {
        error_log('minify ' . $file . ': ' . $e->getMessage());
        return null;
    }

    return $target;
}

/**
 * CSS ohne Kommentare und überflüssigen Leerraum: Leerraum wird zu einem Leerzeichen, fällt um { } ; , > ~ und nach
 * : weg, das letzte ; vor } ebenso. Zeichenketten und url(…) bleiben, wie sie sind; um + und - bleibt Leerraum
 * (calc), vor : auch (Selektor „a :hover“). Kommentare mit /*! bleiben (Lizenzen).
 */
function le_minify_css(string $css): string
{
    $out = '';
    $len = strlen($css);
    $space = false;
    for ($i = 0; $i < $len; $i++) {
        $c = $css[$i];
        if ($c === '/' && ($css[$i + 1] ?? '') === '*') {
            $end = strpos($css, '*/', $i + 2);
            $end = $end === false ? $len : $end + 2;
            if (($css[$i + 2] ?? '') === '!') {
                $out .= substr($css, $i, $end - $i);
            }
            $i = $end - 1;
            continue;
        }
        if ($c === '"' || $c === "'") {
            $j = $i + 1;
            while ($j < $len && $css[$j] !== $c) {
                $j += $css[$j] === '\\' ? 2 : 1;
            }
            $out .= le_minify_css_space($out, $space) . substr($css, $i, $j - $i + 1);
            $space = false;
            $i = $j;
            continue;
        }
        if (($c === 'u' || $c === 'U') && strtolower(substr($css, $i, 4)) === 'url(' && !preg_match('/[A-Za-z0-9_-]$/', $out)) {
            $j = strpos($css, ')', $i);
            $j = $j === false ? $len - 1 : $j;
            $out .= le_minify_css_space($out, $space) . substr($css, $i, $j - $i + 1);
            $space = false;
            $i = $j;
            continue;
        }
        if (ctype_space($c)) {
            $space = true;
            continue;
        }
        if (str_contains('{};,>~', $c)) {
            $out = rtrim($out);
            if ($c === '}' && str_ends_with($out, ';')) {
                $out = substr($out, 0, -1);
            }
            $out .= $c;
            $space = false;
            continue;
        }
        $out .= le_minify_css_space($out, $space) . $c;
        $space = false;
    }

    return trim($out);
}

/** Ein Leerzeichen, wenn vorher Leerraum war und das letzte Zeichen es nicht überflüssig macht. */
function le_minify_css_space(string $out, bool $space): string
{
    return $space && $out !== '' && !str_contains('{};,>~:(', $out[-1]) ? ' ' : '';
}

/**
 * JS ohne Kommentare, Einrückung und Leerraum, der nichts trennt. Zeilenumbrüche bleiben (einer je Stelle), damit
 * die automatische Semikolon-Einfügung gleich bleibt; Leerzeichen bleiben nur zwischen zwei Namen bzw. Zahlen und
 * bei + + und - -. Zeichenketten, Template-Literale (samt ${…}) und reguläre Ausdrücke bleiben wörtlich. Kommentare
 * mit /*! bleiben (Lizenzen).
 */
function le_minify_js(string $js): string
{
    $out = '';
    $len = strlen($js);
    $space = false;
    $newline = false;
    // Offene Template-Literale: Tiefe der { je ${, damit } das richtige schließt.
    $templates = [];
    $word = static fn (string $ch): bool => $ch !== '' && (ctype_alnum($ch) || $ch === '_' || $ch === '$' || ord($ch) > 127 || $ch === '\\');
    $emit = static function (string $text) use (&$out, &$space, &$newline, $word): void {
        if ($newline && $out !== '') {
            $out = rtrim($out, ' ') . "\n";
        } elseif ($space && $out !== '') {
            $prev = $out[-1];
            $next = $text[0];
            if (($word($prev) && $word($next)) || ($prev === '+' && $next === '+') || ($prev === '-' && $next === '-')) {
                $out .= ' ';
            }
        }
        $out .= $text;
        $space = false;
        $newline = false;
    };
    // Ob ein / hier einen regulären Ausdruck beginnt: nach Satzzeichen, am Anfang oder nach Schlüsselwörtern.
    $regexAllowed = static function () use (&$out): bool {
        $trim = rtrim($out);
        if ($trim === '') {
            return true;
        }
        if (preg_match('/(?:^|[^A-Za-z0-9_$])(return|typeof|instanceof|in|of|new|delete|void|throw|case|do|else|yield|await)$/', $trim)) {
            return true;
        }
        return str_contains('(,=:[!&|?{};+-*%<>~^', $trim[-1]);
    };
    $scanTemplate = static function (int $i) use ($js, $len): int {
        // Bis zum schließenden ` oder zum ${ ab $i (nach dem ` bzw. }), liefert die Position des Endzeichens.
        while ($i < $len) {
            if ($js[$i] === '\\') {
                $i += 2;
                continue;
            }
            if ($js[$i] === '`' || ($js[$i] === '$' && ($js[$i + 1] ?? '') === '{')) {
                return $i;
            }
            $i++;
        }
        return $len;
    };

    for ($i = 0; $i < $len; $i++) {
        $c = $js[$i];
        $n = $js[$i + 1] ?? '';
        if ($c === '/' && $n === '/') {
            $end = strpos($js, "\n", $i);
            $i = ($end === false ? $len : $end) - 1;
            continue;
        }
        if ($c === '/' && $n === '*') {
            $end = strpos($js, '*/', $i + 2);
            $end = $end === false ? $len : $end + 2;
            if (($js[$i + 2] ?? '') === '!') {
                $emit(substr($js, $i, $end - $i));
            } elseif (str_contains(substr($js, $i, $end - $i), "\n")) {
                $newline = true;
            } else {
                $space = true;
            }
            $i = $end - 1;
            continue;
        }
        if ($c === "\n" || $c === "\r") {
            $newline = true;
            continue;
        }
        if ($c === ' ' || $c === "\t" || $c === "\f" || $c === "\v") {
            $space = true;
            continue;
        }
        if ($c === '"' || $c === "'") {
            $j = $i + 1;
            while ($j < $len && $js[$j] !== $c && $js[$j] !== "\n") {
                $j += $js[$j] === '\\' ? 2 : 1;
            }
            $emit(substr($js, $i, $j - $i + 1));
            $i = $j;
            continue;
        }
        if ($c === '`' || ($c === '}' && $templates !== [] && end($templates) === 0)) {
            // Anfang eines Template-Literals oder Ende eines ${…} darin: wörtlich bis ` oder zum nächsten ${.
            if ($c === '}') {
                array_pop($templates);
            }
            $j = $scanTemplate($i + 1);
            if (($js[$j] ?? '') === '`') {
                $emit(substr($js, $i, $j - $i + 1));
                $i = $j;
            } else {
                $emit(substr($js, $i, $j - $i + 2));
                $templates[] = 0;
                $i = $j + 1;
            }
            continue;
        }
        if ($c === '{' && $templates !== []) {
            $templates[count($templates) - 1]++;
        } elseif ($c === '}' && $templates !== []) {
            $templates[count($templates) - 1]--;
        }
        if ($c === '/' && $regexAllowed()) {
            $j = $i + 1;
            $class = false;
            while ($j < $len && $js[$j] !== "\n" && ($class || $js[$j] !== '/')) {
                if ($js[$j] === '\\') {
                    $j++;
                } elseif ($js[$j] === '[') {
                    $class = true;
                } elseif ($js[$j] === ']') {
                    $class = false;
                }
                $j++;
            }
            while ($j + 1 < $len && ctype_alpha($js[$j + 1])) {
                $j++;
            }
            $emit(substr($js, $i, $j - $i + 1));
            $i = $j;
            continue;
        }
        $emit($c);
    }

    return trim($out);
}
