<?php
declare(strict_types=1);

// Aufbau des Sicherungs-ZIPs (siehe knowledgebase/backup.md). Bewusst ohne
// weitere require: Das Abhol-Skript in tools/ läuft damit ohne Installation.

// Manifest im ZIP-Root: version, created, driver, fingerprint, files[{path, size, sha256}].
const SITE_BACKUP_MANIFEST = 'backup.json';
// Größer wird das Manifest nicht entpackt (rund 150 Bytes je Datei, reicht für weit über 100 000 Dateien).
const LE_SITE_BACKUP_MANIFEST_MAX_BYTES = 32 * 1024 * 1024;

/** Summe der Größen im Manifest über der Grenze von le_site_backup_verify_zip(); der Aufrufer nennt die Grenze. */
final class SiteBackupUnpackedTooBig extends RuntimeException
{
}
// Ordner für den MySQL-Export im ZIP: schema.json plus je Plugin-Tabelle
// eine Datei <tabelle>.jsonl, eine Zeile je Datensatz.
const SITE_BACKUP_DB_DIR = 'database';
const SITE_BACKUP_DB_SCHEMA = 'schema.json';
const SITE_BACKUP_DB_ROWS_SUFFIX = '.jsonl';
// So viel bleibt immer frei, wenn eine Sicherung abgeholt (tools/backup-pull.php) oder eingespielt
// (le_site_backup_restore) wird, damit eine Website nicht die Platte der anderen füllt.
const LE_SITE_BACKUP_FREE_RESERVE = 512 * 1024 * 1024;

/**
 * Größe und SHA-256 eines ZIP-Eintrags, gestreamt (große Dateien ohne Speicher);
 * Manifest-Erstellung und Abhol-Skript rechnen damit dieselbe Prüfsumme.
 */
function site_backup_entry_digest(ZipArchive $zip, string $name, ?int $maxBytes = null): array
{
    $stream = $zip->getStream($name);
    if (!$stream) {
        throw new RuntimeException($name . ' ließ sich nicht aus dem ZIP lesen');
    }
    $hash = hash_init('sha256');
    // $maxBytes: höchstens so viel entpacken (ein Byte mehr zeigt, dass der Eintrag größer ist); die Größe im
    // ZIP-Verzeichnis kann lügen, gelesen wird bis zum Ende der komprimierten Daten.
    $size = $maxBytes === null ? hash_update_stream($hash, $stream) : hash_update_stream($hash, $stream, $maxBytes + 1);
    fclose($stream);
    return ['size' => $size, 'sha256' => hash_final($hash)];
}

/**
 * Prüft ein Sicherungs-ZIP gegen sein Manifest: jede Datei vorhanden, Größe und SHA-256 stimmen,
 * keine zusätzlichen oder doppelten Einträge, keine Pfade, die beim Entpacken ausbrechen
 * (zip_entry_name_safe aus core/utils.php). Liefert das Manifest; Fehler als RuntimeException.
 * Abhol-Skript und Einspielen in einen Kundenordner (le_site_backup_restore) prüfen damit.
 */
function le_site_backup_verify_zip(ZipArchive $zip, ?int $maxUnpackedBytes = null): array
{
    // Größen aus dem ZIP-Verzeichnis vor dem Entpacken: Ein ZIP, das sich stark aufbläht, hält sonst die Prüfung auf.
    $manifestStat = $zip->statName(SITE_BACKUP_MANIFEST);
    $manifestSmall = is_array($manifestStat) && $manifestStat['size'] <= LE_SITE_BACKUP_MANIFEST_MAX_BYTES;
    $manifest = $manifestSmall ? json_decode((string) $zip->getFromName(SITE_BACKUP_MANIFEST), true) : null;
    if (!is_array($manifest) || !isset($manifest['files']) || !is_array($manifest['files'])) {
        throw new RuntimeException('Manifest ' . SITE_BACKUP_MANIFEST . ' fehlt oder ist ungültig');
    }
    $expected = [];
    foreach ($manifest['files'] as $file) {
        $path = $file['path'] ?? null;
        $size = $file['size'] ?? null;
        if (!is_string($path) || !is_int($size) || $size < 0 || $size === PHP_INT_MAX || !is_string($file['sha256'] ?? null) || isset($expected[$path])) {
            throw new RuntimeException('Manifest ' . SITE_BACKUP_MANIFEST . ' ist ungültig');
        }
        $expected[$path] = $file;
    }
    // Vor dem ersten Entpacken: Summe der Größen laut Manifest (mehr entpackt die Prüfung nie, siehe unten).
    if ($maxUnpackedBytes !== null && array_sum(array_column($expected, 'size')) > $maxUnpackedBytes) {
        throw new SiteBackupUnpackedTooBig('Sicherung entpackt größer als erlaubt');
    }

    $seen = [SITE_BACKUP_MANIFEST => true];
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $stat = $zip->statIndex($i);
        $name = is_array($stat) ? (string) $stat['name'] : '';
        if (!zip_entry_name_safe($name)) {
            throw new RuntimeException('ZIP enthält ungültige Pfade');
        }
        if ($name === SITE_BACKUP_MANIFEST && $i === $zip->locateName(SITE_BACKUP_MANIFEST)) {
            continue;
        }
        if (!isset($expected[$name]) || isset($seen[$name])) {
            throw new RuntimeException('Eintrag nicht im Manifest: ' . $name);
        }
        $seen[$name] = true;
        if ($stat['size'] !== $expected[$name]['size']) {
            throw new RuntimeException('Prüfsumme falsch: ' . $name);
        }
        $digest = site_backup_entry_digest($zip, $name, $expected[$name]['size']);
        if ($digest['size'] !== $expected[$name]['size'] || !hash_equals($expected[$name]['sha256'], $digest['sha256'])) {
            throw new RuntimeException('Prüfsumme falsch: ' . $name);
        }
    }
    $missing = array_diff(array_keys($expected), array_keys($seen));
    if ($missing) {
        throw new RuntimeException('Fehlt im ZIP: ' . implode(', ', $missing));
    }
    return $manifest;
}
