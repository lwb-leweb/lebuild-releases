<?php
declare(strict_types=1);

require_once __DIR__ . '/dbMigration.php';
require_once __DIR__ . '/pluginSchema.php';
require_once __DIR__ . '/uploads.php';

// Plugin-Daten zwischen einer Kunden-Website und ihrem Klon abgleichen (README, „Arbeiten an einer Kunden-Website“):
// Export aller Tabellen der aktiven Plugins, lokal holen (Ausgangsstand), Änderungsliste bilden und online einspielen.
// Generisch über die Tabellen aus active-plugins.json; was ein Plugin dazu weiß (Titel, Adressen, Verweise), liefern
// die Hooks entry_label, entry_problem und action_entry_updated (knowledgebase/hooks.md).

// Stand der Online-Daten beim letzten Holen; Vergleichsbasis für die Änderungsliste (DATA_ROOT ist privat, gitignored).
// Seine Kennung (le_data_baseline_id) schreibt der Diff als baseline in die Änderungsliste: Prüfsumme der Tabellen und der
// zuletzt online eingespielten Kennung (applied im Export). Derselbe alte Export behält sie, ein Holen nach jedem
// Einspielen bekommt eine neue, auch wenn die Tabellen wieder genau so stehen wie vorher (eingespielte Einträge
// gelöscht, MySQL zurückgespielt).
const LE_DATA_BASELINE_FILE = DATA_ROOT . '/.ausgangsstand.json';
const LE_DATA_BASELINE_ALGO = 'sha256';
// Gültige Kennung in einer Änderungsliste: Hex-Prüfsumme nach LE_DATA_BASELINE_ALGO.
const LE_DATA_BASELINE_PATTERN = '/^[0-9a-f]{64}\z/';
// Online: Kennungen der Ausgangsstände, aus denen schon eingespielt wurde (neueste zuletzt, höchstens
// LE_DATA_APPLIED_KEEP). Eine zweite Liste aus demselben Stand (dieselbe noch einmal nach abgebrochener Verbindung,
// oder um eine Zeile erweitert) legte neue Zeilen doppelt an und wird abgelehnt: erst neu holen.
const LE_DATA_APPLIED_FILE = DATA_ROOT . '/.eingespielt.json';
const LE_DATA_APPLIED_KEEP = 100;
// Spalten, die die Datenbank bzw. das Einspielen setzt: id und created_at gehen bei insert nicht mit, updated_at setzt
// das Einspielen auf jetzt und zählt beim Vergleich zweier Zeilen nicht.
const LE_DATA_ID_COLUMN = 'id';
const LE_DATA_CREATED_COLUMN = 'created_at';
const LE_DATA_UPDATED_COLUMN = 'updated_at';
const LE_DATA_OPS = ['insert', 'update', 'delete'];
// Was das Einspielen verhindert, je Art (le_data_apply).
const LE_DATA_FOUND = ['conflicts' => [], 'problems' => [], 'missingImages' => [], 'notConflicts' => []];
// Zeile als „tabelle:id“ (Konfliktliste, --lokal-gewinnt), mehrere mit Komma getrennt.
const LE_DATA_REF_SEPARATOR = ':';
const LE_DATA_REF_LIST_SEPARATOR = ',';
// Option von lebuild-sites data-apply mit solchen Zeilen: Im Konflikt gilt die lokale Fassung.
const LE_DATA_LOCAL_WINS_OPTION = '--lokal-gewinnt';
// Urheber im Aktivitäts-Log beim Einspielen (kein Benutzer der Website).
const LE_DATA_ACTIVITY_USER = 'LEWEB';
const LE_DATA_JSON_FLAGS = JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR;
// Zähler je Art (Diff, Log-Zeile des Einspielens).
const LE_DATA_COUNTS_TEXT = '%d angelegt, %d geändert, %d gelöscht';
// Geänderter Schlüssel einer Spalte mit JSON-Objekt in der Konfliktliste: data.text.
const LE_DATA_KEY_SEPARATOR = '.';
// Meldungen für LEWEB auf der Kommandozeile (tools/data.php, tools/sites.php).
const LE_DATA_TEXT = [
    'noBaseline' => 'Kein Ausgangsstand (%s). Erst holen: php tools/data.php pull <datei>',
    'invalidExport' => 'Keine gültige Datei mit Plugin-Daten (JSON mit tables, applied als Kennung oder null).',
    'invalidRows' => 'Tabelle %s: Zeilen ungültig (Liste von Objekten mit id).',
    'unknownTable' => 'Tabelle %s gehört zu keinem aktiven Plugin.',
    'columns' => 'Spalten von %s passen nicht (%s), andere Plugin-Version?',
    'invalidUsers' => 'users in der Datei ist kein gültiger Benutzer-Stand.',
    'invalidList' => 'Keine gültige Änderungsliste (JSON mit changes als Liste).',
    'invalidChange' => 'Änderung %d: %s',
    'invalidOp' => 'Art muss insert, update oder delete sein',
    'invalidId' => 'id fehlt oder ist ungültig',
    'invalidRow' => '%s fehlt oder ist kein Objekt',
    'invalidColumn' => 'Spalte %s gibt es in %s nicht',
    'invalidValue' => 'Spalte %s: Wert ist kein Text und keine Zahl',
    'duplicate' => 'Zeile %s steht mehrfach in der Liste',
    'invalidRef' => 'Ungültige Zeile „%s“ (Schreibweise tabelle:id, z. B. content_items:12).',
    'busy' => 'Gerade speichert jemand Bilder (oder der Cache ist nicht beschreibbar), bitte gleich noch einmal.',
    'alreadyApplied' => 'Aus diesem Ausgangsstand ist schon eingespielt, nichts eingespielt (sonst entstünden neue Zeilen doppelt). Erst neu holen (data-pull, tools/data.php pull), dann ändern und den Diff neu bilden. Achtung: Holen ersetzt alles, was im Klon seit dem letzten Holen geändert wurde; diese Änderungen vorher sichern bzw. danach neu machen.',
    'noBaselineId' => 'Die Änderungsliste nennt keinen gültigen Ausgangsstand (baseline). Neu holen und mit php tools/data.php diff bilden.',
    'failed' => 'Einspielen fehlgeschlagen: %s',
    'empty' => 'Keine Änderungen, nichts eingespielt.',
    'summary' => 'Einträge: ' . LE_DATA_COUNTS_TEXT,
    // Konfliktgrund: was online anders ist, dazu was lokal geschah (LE_DATA_TEXT['local'][Art]).
    'changedOnline' => 'online geändert (%s), lokal %s',
    'deletedOnline' => 'online gelöscht, lokal geändert',
    'local' => ['update' => 'geändert', 'delete' => 'gelöscht'],
    'newRow' => '%s (neu)',
    // %1$s: tabelle:id bzw. „tabelle (neu)“, %2$s: „ „Titel““ oder leer, %3$s: Grund bzw. Pfad des Bildes.
    'conflict' => 'Konflikt %1$s%2$s: %3$s',
    'problem' => 'Nicht möglich %1$s%2$s: %3$s',
    'label' => ' „%s“',
    'missingImage' => 'Bild fehlt online %1$s%2$s: %3$s (nur Bilder, die es online gibt, unter ' . UPLOADS_URL . ' oder ' . LE_SITE_FILES_URL . ')',
    'notConflict' => '%s ist kein Konflikt (' . LE_DATA_LOCAL_WINS_OPTION . ')',
    'resolve' => 'Nichts eingespielt. Konflikte mit ' . LE_DATA_LOCAL_WINS_OPTION . ' <tabelle:id,…> lösen (die lokale Fassung gilt) oder die Zeile lokal anpassen (unverändert lassen oder genau wie online) und den Diff neu bilden. Nicht neu holen, das verwirft die lokale Arbeit.',
    'notApplied' => 'Nichts eingespielt.',
    'pulled' => '%s: %d Zeilen',
    'pulledUsers' => 'Benutzer übernommen (%s)',
    'baseline' => 'Ausgangsstand: %s',
    'diff' => LE_DATA_COUNTS_TEXT,
];

/** Tabellen der aktiven Plugins: [Tabelle => Plugin], in der Reihenfolge von active-plugins.json. */
function le_data_tables(): array
{
    $state = load_plugins_state();
    $tables = [];
    foreach ($state['active'] as $name) {
        foreach ($state['installed'][$name]['tables'] ?? [] as $table) {
            $tables[$table] = $name;
        }
    }
    return $tables;
}

/** id einer Zeile als Zahl > 0 (auch als Ziffern-Text, wie MySQL sie liefern kann); null für alles andere. */
function le_data_id(mixed $value): ?int
{
    if (is_string($value) && preg_match('/^[1-9][0-9]*$/', $value)) {
        $value = (int) $value;
    }
    return is_int($value) && $value > 0 ? $value : null;
}

/** „tabelle:id“ einer Zeile. */
function le_data_ref(string $table, int $id): string
{
    return $table . LE_DATA_REF_SEPARATOR . $id;
}

/**
 * Zeilen aus „content_items:12,opening_hours:3“ (Leerzeichen erlaubt, Doppelte einmal); wirft
 * InvalidArgumentException (LE_DATA_TEXT['invalidRef']) bei einer falsch geschriebenen.
 */
function le_data_parse_refs(string $text): array
{
    $refs = [];
    foreach (explode(LE_DATA_REF_LIST_SEPARATOR, $text) as $part) {
        $part = trim($part);
        if ($part === '') {
            continue;
        }
        [$table, $id] = array_pad(explode(LE_DATA_REF_SEPARATOR, $part, 2), 2, '');
        if (!plugin_table_name_valid($table) || le_data_id($id) === null) {
            throw new InvalidArgumentException(sprintf(LE_DATA_TEXT['invalidRef'], $part));
        }
        $refs[] = le_data_ref($table, le_data_id($id));
    }
    return array_values(array_unique($refs));
}

/**
 * Alle Tabellen der aktiven Plugins aus einem Stand (eine Transaktion): ['tables' => [Tabelle => [Zeile …]], 'applied' =>
 * zuletzt eingespielte Kennung oder null], Zeilen nach id. Mit $withUsers dazu 'users' (Inhalt von content/users.json,
 * falls vorhanden) für das Holen in den Klon.
 */
function le_data_export(bool $withUsers = false): array
{
    $pdo = db();
    $driver = db_driver();
    $active = le_data_tables();
    foreach ($active as $table => $plugin) {
        le_plugin_create_missing_tables($pdo, $driver, $plugin, [$table]);
    }
    $tables = [];
    $pdo->beginTransaction();
    try {
        foreach (array_keys($active) as $table) {
            $columns = db_migration_columns($pdo, $table);
            $tables[$table] = [];
            foreach (db_migration_batches($pdo, $table, $columns) as $rows) {
                foreach ($rows as $row) {
                    $tables[$table][] = array_combine($columns, $row);
                }
            }
        }
    } finally {
        $pdo->rollBack();
    }
    $applied = le_data_applied();
    $export = ['tables' => $tables, 'applied' => $applied === [] ? null : end($applied)];
    if ($withUsers && is_file(LE_USERS_FILE)) {
        $users = json_decode((string) file_get_contents(LE_USERS_FILE), true);
        if (!is_array($users) || !is_array($users['users'] ?? null)) {
            throw new RuntimeException(LE_DATA_TEXT['invalidUsers']);
        }
        $export['users'] = $users;
    }
    return $export;
}

function le_data_json(array $data): string
{
    return json_encode($data, LE_DATA_JSON_FLAGS) . "\n";
}

/**
 * Spalten, in denen sich zwei Zeilen unterscheiden (ohne updated_at). Werte zählen als Text, null nur gleich null;
 * enthalten beide Seiten ein JSON-Objekt (z. B. data der Content-Typen), zählt der Inhalt (MySQL ordnet ihn um) und
 * die geänderten Schlüssel erscheinen als „data.text“.
 */
function le_data_row_changes(array $a, array $b): array
{
    $changed = [];
    foreach (array_unique(array_merge(array_keys($a), array_keys($b))) as $column) {
        if ($column === LE_DATA_UPDATED_COLUMN) {
            continue;
        }
        $x = $a[$column] ?? null;
        $y = $b[$column] ?? null;
        $xJson = is_string($x) ? json_decode($x, true) : null;
        $yJson = is_string($y) ? json_decode($y, true) : null;
        if (is_array($xJson) && is_array($yJson) && $xJson !== array_values($xJson) && $yJson !== array_values($yJson)) {
            // Sortiert: MySQL ordnet die Schlüssel einer JSON-Spalte selbst, die Meldung soll überall gleich lauten.
            $keys = array_unique(array_merge(array_keys($xJson), array_keys($yJson)));
            sort($keys, SORT_STRING);
            foreach ($keys as $key) {
                if (le_data_canonical($xJson[$key] ?? null) !== le_data_canonical($yJson[$key] ?? null)) {
                    $changed[] = $column . LE_DATA_KEY_SEPARATOR . $key;
                }
            }
        } elseif ($x === null || $y === null ? $x !== $y : (string) $x !== (string) $y) {
            $changed[] = (string) $column;
        }
    }
    return $changed;
}

/** Wert als JSON mit sortierten Schlüsseln aller Objekte, zum Vergleich unabhängig von der Reihenfolge. */
function le_data_canonical(mixed $value): string
{
    $sort = static function (mixed $value) use (&$sort): mixed {
        if (!is_array($value)) {
            return $value;
        }
        if ($value !== array_values($value)) {
            ksort($value);
        }
        return array_map($sort, $value);
    };
    return (string) json_encode($sort($value), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
}

/** Ob ein Spaltenwert so in die Datenbank kann: Text, Zahl, Wahrheitswert oder null (kein Array, kein Objekt). */
function le_data_value_valid(mixed $value): bool
{
    return $value === null || is_scalar($value);
}

/**
 * Prüft die Tabellen einer Export-Datei gegen die aktiven Plugins und ihre Spalten (fehlende Tabellen legt es an).
 * Wirft RuntimeException mit Meldung aus LE_DATA_TEXT.
 */
function le_data_check_export(PDO $pdo, mixed $export): void
{
    if (!is_array($export) || !is_array($export['tables'] ?? null)) {
        throw new RuntimeException(LE_DATA_TEXT['invalidExport']);
    }
    $active = le_data_tables();
    foreach ($export['tables'] as $table => $rows) {
        if (!is_string($table) || !isset($active[$table])) {
            throw new RuntimeException(sprintf(LE_DATA_TEXT['unknownTable'], (string) $table));
        }
        if (!is_array($rows) || array_values($rows) !== $rows) {
            throw new RuntimeException(sprintf(LE_DATA_TEXT['invalidRows'], $table));
        }
        le_plugin_create_missing_tables($pdo, db_driver(), $active[$table], [$table]);
        $columns = db_migration_columns($pdo, $table);
        foreach ($rows as $row) {
            if (!is_array($row) || le_data_id($row[LE_DATA_ID_COLUMN] ?? null) === null) {
                throw new RuntimeException(sprintf(LE_DATA_TEXT['invalidRows'], $table));
            }
            $keys = array_keys($row);
            if (count($keys) !== count($columns) || array_diff($keys, $columns)) {
                throw new RuntimeException(sprintf(LE_DATA_TEXT['columns'], $table, implode(', ', $keys)));
            }
            foreach ($row as $column => $value) {
                if (!le_data_value_valid($value)) {
                    throw new RuntimeException($table . ': ' . sprintf(LE_DATA_TEXT['invalidValue'], $column));
                }
            }
        }
    }
    $applied = $export['applied'] ?? null;
    if ($applied !== null && (!is_string($applied) || preg_match(LE_DATA_BASELINE_PATTERN, $applied) !== 1)) {
        throw new RuntimeException(LE_DATA_TEXT['invalidExport']);
    }
    if (isset($export['users']) && (!is_array($export['users']) || !is_array($export['users']['users'] ?? null))) {
        throw new RuntimeException(LE_DATA_TEXT['invalidUsers']);
    }
}

/** INSERT einer Zeile mit genau ihren Spalten (Namen vorher geprüft); liefert die id. */
function le_data_insert(PDO $pdo, string $table, array $row): int
{
    $columns = array_keys($row);
    $list = '`' . implode('`, `', $columns) . '`';
    $placeholders = implode(', ', array_fill(0, count($columns), '?'));
    $pdo->prepare("INSERT INTO `{$table}` ({$list}) VALUES ({$placeholders})")->execute(array_values($row));
    return isset($row[LE_DATA_ID_COLUMN]) ? (int) $row[LE_DATA_ID_COLUMN] : (int) $pdo->lastInsertId();
}

/**
 * Lokal holen (tools/data.php pull): Die Tabellen der Export-Datei ersetzen den Inhalt der lokalen Tabellen (ids
 * bleiben), in einer Transaktion; 'users' wird content/users.json; die Tabellen werden der Ausgangsstand
 * (LE_DATA_BASELINE_FILE, ohne Benutzer). Liefert Meldungszeilen, wirft mit Meldung.
 */
function le_data_pull(mixed $export): array
{
    if (db_migration_running()) {
        throw new RuntimeException(DB_MIGRATION_RUNNING_MESSAGE);
    }
    $pdo = db();
    le_data_check_export($pdo, $export);
    $lines = [];
    $pdo->beginTransaction();
    try {
        foreach ($export['tables'] as $table => $rows) {
            $pdo->exec("DELETE FROM `{$table}`");
            foreach ($rows as $row) {
                le_data_insert($pdo, $table, $row);
            }
            $lines[] = sprintf(LE_DATA_TEXT['pulled'], $table, count($rows));
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    // Erst nach den Daten: Scheitert der Ausgangsstand, zeigt der nächste Diff Online-Änderungen als lokale, und das
    // Einspielen meldet sie als Konflikt, statt sie zu überschreiben.
    write_private_file(LE_DATA_BASELINE_FILE, le_data_json(['tables' => $export['tables'], 'applied' => $export['applied'] ?? null]));
    $lines[] = sprintf(LE_DATA_TEXT['baseline'], le_instance_relative(LE_DATA_BASELINE_FILE));
    if (isset($export['users'])) {
        users_update(static function (array &$store) use ($export): void {
            $store = $export['users'];
        });
        $lines[] = sprintf(LE_DATA_TEXT['pulledUsers'], le_instance_relative(LE_USERS_FILE));
    }
    return $lines;
}

/**
 * Änderungsliste (tools/data.php diff): {baseline: Kennung des Ausgangsstands, changes: [...]}, lokale Tabellen gegen den
 * Ausgangsstand, je Zeile {table, op: insert, row} (ohne id, created_at), {table, op: update, id, before, row} oder
 * {table, op: delete, id, before}. Eine lokale Tabelle ohne Ausgangsstand zählt als leer. Wirft mit Meldung.
 */
function le_data_diff(): array
{
    if (!is_file(LE_DATA_BASELINE_FILE)) {
        throw new RuntimeException(sprintf(LE_DATA_TEXT['noBaseline'], le_instance_relative(LE_DATA_BASELINE_FILE)));
    }
    $baseline = json_decode((string) file_get_contents(LE_DATA_BASELINE_FILE), true);
    le_data_check_export(db(), $baseline);
    $local = le_data_export()['tables'];
    $changes = [];
    foreach ($local as $table => $rows) {
        $before = array_column($baseline['tables'][$table] ?? [], null, LE_DATA_ID_COLUMN);
        $now = array_column($rows, null, LE_DATA_ID_COLUMN);
        foreach ($now as $id => $row) {
            if (!isset($before[$id])) {
                unset($row[LE_DATA_ID_COLUMN], $row[LE_DATA_CREATED_COLUMN]);
                $changes[] = ['table' => $table, 'op' => 'insert', 'row' => $row];
            } elseif (le_data_row_changes($before[$id], $row) !== []) {
                $changes[] = ['table' => $table, 'op' => 'update', 'id' => (int) $id, 'before' => $before[$id], 'row' => $row];
            }
        }
        foreach (array_diff_key($before, $now) as $id => $row) {
            $changes[] = ['table' => $table, 'op' => 'delete', 'id' => (int) $id, 'before' => $row];
        }
    }
    return ['baseline' => le_data_baseline_id($baseline['tables'], $baseline['applied'] ?? null), 'changes' => $changes];
}

/**
 * Kennung eines Ausgangsstands: Prüfsumme seiner Tabellen und der zuletzt online eingespielten Kennung ($applied),
 * unabhängig von der Reihenfolge der Schlüssel.
 */
function le_data_baseline_id(array $tables, ?string $applied = null): string
{
    return hash(LE_DATA_BASELINE_ALGO, le_data_canonical(['tables' => $tables, 'applied' => $applied]));
}

/** Online: Kennungen der Ausgangsstände, aus denen schon eingespielt wurde (LE_DATA_APPLIED_FILE), neueste zuletzt; kaputte Einträge zählen nicht. */
function le_data_applied(): array
{
    $applied = json_decode((string) @file_get_contents(LE_DATA_APPLIED_FILE), true);
    $valid = static fn (mixed $id): bool => is_string($id) && preg_match(LE_DATA_BASELINE_PATTERN, $id) === 1;
    return is_array($applied) ? array_values(array_filter($applied, $valid)) : [];
}

/** Zähler einer Änderungsliste bzw. eines Einspielens je Art. */
function le_data_counts(array $changes): array
{
    $counts = array_fill_keys(LE_DATA_OPS, 0);
    foreach ($changes as $change) {
        $counts[$change['op']]++;
    }
    return $counts;
}

/** Fehler in einer Änderungsliste (Aufbau, Tabellen, Spalten) als Meldungen; $columns: [Tabelle => Spalten]. */
function le_data_check_changes(array $changes, array $tables, array $columns): array
{
    $errors = [];
    $refs = [];
    foreach ($changes as $index => $change) {
        $problem = null;
        $table = is_array($change) ? ($change['table'] ?? null) : null;
        $op = is_array($change) ? ($change['op'] ?? null) : null;
        if (!is_string($table) || !isset($tables[$table])) {
            $problem = sprintf(LE_DATA_TEXT['unknownTable'], is_string($table) ? $table : '?');
        } elseif (!in_array($op, LE_DATA_OPS, true)) {
            $problem = LE_DATA_TEXT['invalidOp'];
        } elseif ($op !== 'insert' && le_data_id($change['id'] ?? null) === null) {
            $problem = LE_DATA_TEXT['invalidId'];
        } else {
            foreach ($op === 'insert' ? ['row'] : ($op === 'update' ? ['before', 'row'] : ['before']) as $key) {
                if (!is_array($change[$key] ?? null) || ($change[$key] !== [] && array_values($change[$key]) === $change[$key])) {
                    $problem = sprintf(LE_DATA_TEXT['invalidRow'], $key);
                    break;
                }
                foreach ($change[$key] as $column => $value) {
                    if (!in_array($column, $columns[$table], true)) {
                        $problem = sprintf(LE_DATA_TEXT['invalidColumn'], (string) $column, $table);
                        break 2;
                    }
                    if (!le_data_value_valid($value)) {
                        $problem = sprintf(LE_DATA_TEXT['invalidValue'], $column);
                        break 2;
                    }
                }
            }
            $ref = $op === 'insert' ? null : le_data_ref($table, le_data_id($change['id']));
            if ($problem === null && $ref !== null && isset($refs[$ref])) {
                $problem = sprintf(LE_DATA_TEXT['duplicate'], $ref);
            }
            $refs[$ref] = true;
        }
        if ($problem !== null) {
            $errors[] = sprintf(LE_DATA_TEXT['invalidChange'], $index + 1, $problem);
        }
    }
    return $errors;
}

/**
 * Spielt eine Änderungsliste (le_data_diff) ein, ganz oder gar nicht in einer Transaktion. $localWins (le_data_parse_refs):
 * Zeilen „tabelle:id“, für die bei einem Konflikt die lokale Fassung gilt (online gelöscht und lokal geändert: neu
 * angelegt; online geändert und lokal gelöscht: gelöscht). Benutzer, Zugangsdaten und content/config/ bleiben unberührt.
 *
 * Erfolg: ['ok' => true, 'counts' => [insert, update, delete], 'message']; danach eine Zeile im Aktivitäts-Log
 * (LE_DATA_ACTIVITY_USER), außer wenn nichts zu tun war (leere Liste, online schon so). Eine zweite Liste aus demselben
 * Ausgangsstand (baseline) lehnt es ab (LE_DATA_APPLIED_FILE). Zeilen liest es unter MySQL mit Sperre (FOR UPDATE).
 * Sonst ['ok' => false] mit 'errors' (Meldungen), 'conflicts' (online anders als im Ausgangsstand, per $localWins
 * lösbar), 'problems' (Hook entry_problem, z. B. Adresse vergeben, Typ unbekannt; nicht lösbar), 'missingImages'
 * (Bilder, die online fehlen) und 'notConflicts' (Zeilen aus $localWins ohne Konflikt); Einträge von
 * conflicts/problems/missingImages: {table, ref (tabelle:id, null bei neuen), label, reason (bei missingImages der Pfad)}.
 * Ausgabe für die Kommandozeile: le_data_apply_lines().
 */
function le_data_apply(mixed $list, array $localWins = []): array
{
    $changes = is_array($list) ? ($list['changes'] ?? null) : null;
    if (!is_array($changes) || array_values($changes) !== $changes) {
        return le_data_failure([LE_DATA_TEXT['invalidList']]);
    }
    if ($changes === []) {
        return ['ok' => true, 'counts' => array_fill_keys(LE_DATA_OPS, 0), 'message' => LE_DATA_TEXT['empty']];
    }
    $baseline = $list['baseline'] ?? null;
    if (!is_string($baseline) || preg_match(LE_DATA_BASELINE_PATTERN, $baseline) !== 1) {
        return le_data_failure([LE_DATA_TEXT['noBaselineId']]);
    }
    if (db_migration_running()) {
        return le_data_failure([DB_MIGRATION_RUNNING_MESSAGE]);
    }
    try {
        $pdo = db();
        $tables = le_data_tables();
        $columns = [];
        foreach ($changes as $change) {
            $table = is_array($change) ? ($change['table'] ?? null) : null;
            if (is_string($table) && isset($tables[$table]) && !isset($columns[$table])) {
                le_plugin_create_missing_tables($pdo, db_driver(), $tables[$table], [$table]);
                $columns[$table] = db_migration_columns($pdo, $table);
            }
        }
        $errors = le_data_check_changes($changes, $tables, $columns);
        if ($errors !== []) {
            return le_data_failure($errors);
        }
        $result = le_open_uploads_hold(static fn (): array => le_data_apply_locked($pdo, $baseline, $changes, $localWins, $tables, $columns), false);
    } catch (Throwable $e) {
        // Kein error_log: Die Meldung geht an LEWEB auf der Kommandozeile (dort landete das Protokoll ein zweites Mal).
        return le_data_failure([sprintf(LE_DATA_TEXT['failed'], $e->getMessage())]);
    }
    if ($result === null) {
        return le_data_failure([LE_DATA_TEXT['busy']]);
    }
    if ($result['ok'] && array_sum($result['counts']) > 0) {
        le_activity_log('plugin_data_applied', $result['message'], LE_DATA_ACTIVITY_USER);
    }
    return $result;
}

function le_data_failure(array $errors, array $found = LE_DATA_FOUND): array
{
    return ['ok' => false, 'errors' => $errors] + $found;
}

/** le_data_apply unter der Sperre der offenen Uploads: prüfen, schreiben, nachziehen, prüfen, dann committen oder zurück. */
function le_data_apply_locked(PDO $pdo, string $baseline, array $changes, array $localWins, array $tables, array $columns): array
{
    // Lesen und Schreiben der verbrauchten Ausgangsstände unter derselben Sperre wie das ganze Einspielen.
    $applied = le_data_applied();
    if (in_array($baseline, $applied, true)) {
        return le_data_failure([LE_DATA_TEXT['alreadyApplied']]);
    }
    $found = LE_DATA_FOUND;
    $counts = array_fill_keys(LE_DATA_OPS, 0);
    $now = db_now();
    $unused = [];
    $pdo->beginTransaction();
    try {
        // 1. Konflikte: Online-Zeile gegen den Ausgangsstand, bevor irgendetwas geschrieben ist (nachgezogene
        // Verweise aus Schritt 3 zählten sonst als Änderung des Kunden).
        $plan = [];
        $won = [];
        foreach ($changes as $change) {
            $table = $change['table'];
            if ($change['op'] === 'insert') {
                $plan[] = ['insert', $table, $change['row'], null, null];
                continue;
            }
            $id = le_data_id($change['id']);
            $ref = le_data_ref($table, $id);
            // Mit Sperre (MySQL: FOR UPDATE), sonst könnte der Kunde die Zeile zwischen Prüfen und Schreiben ändern.
            $online = plugin_fetch_row($table, $id, true);
            // Online schon so, wie es sein soll (auch gelöscht bzw. dieselbe Änderung): nichts zu tun, kein Konflikt.
            if ($online === null ? $change['op'] === 'delete' : $change['op'] === 'update' && le_data_row_changes($online, $change['row']) === []) {
                continue;
            }
            $diff = $online === null ? null : le_data_row_changes($online, $change['before']);
            if ($diff !== []) {
                if (!in_array($ref, $localWins, true)) {
                    $found['conflicts'][] = [
                        'table' => $table,
                        'ref' => $ref,
                        'label' => le_plugin_entry_label($tables[$table], $table, $online ?? $change['before']),
                        'reason' => $diff === null ? LE_DATA_TEXT['deletedOnline'] : sprintf(LE_DATA_TEXT['changedOnline'], implode(', ', $diff), LE_DATA_TEXT['local'][$change['op']]),
                    ];
                    continue;
                }
                $won[] = $ref;
            }
            $plan[] = [$online === null ? 'insert' : $change['op'], $table, $change['row'] ?? null, $online, $ref];
        }
        $found['notConflicts'] = array_values(array_diff($localWins, $won));

        // 2. Schreiben; created_at/updated_at setzt das Einspielen.
        $written = [];
        foreach ($plan as [$op, $table, $row, $online, $ref]) {
            if ($op === 'delete') {
                $pdo->prepare("DELETE FROM `{$table}` WHERE `" . LE_DATA_ID_COLUMN . '` = ?')->execute([$online[LE_DATA_ID_COLUMN]]);
                $unused = array_merge($unused, le_data_row_images($tables[$table], $table, $online));
                $counts['delete']++;
                continue;
            }
            unset($row[LE_DATA_ID_COLUMN], $row[LE_DATA_CREATED_COLUMN]);
            if (in_array(LE_DATA_UPDATED_COLUMN, $columns[$table], true)) {
                $row[LE_DATA_UPDATED_COLUMN] = $now;
            }
            if ($op === 'update') {
                $id = (int) $online[LE_DATA_ID_COLUMN];
                if ($row !== []) {
                    $set = implode(', ', array_map(static fn (string $column): string => "`{$column}` = ?", array_keys($row)));
                    $pdo->prepare("UPDATE `{$table}` SET {$set} WHERE `" . LE_DATA_ID_COLUMN . '` = ?')->execute([...array_values($row), $id]);
                }
            } else {
                if (in_array(LE_DATA_CREATED_COLUMN, $columns[$table], true)) {
                    $row[LE_DATA_CREATED_COLUMN] = $now;
                }
                $id = le_data_insert($pdo, $table, $row);
            }
            $written[] = [$table, plugin_fetch_row($table, $id), $op === 'update' ? $online : null, $ref];
            $counts[$op]++;
        }

        // 3. Plugins ziehen nach (z. B. Verweise auf umbenannte Einträge).
        foreach ($written as [$table, $after, $before]) {
            if ($before !== null) {
                le_action_entry_updated($table, $before, $after);
            }
        }

        // 4. Neuer Stand: Adressen, Typen (Hook entry_problem) und Bilder, die online liegen müssen (wie beim Import:
        // nur vorhandene Dateien dieser Website, fremde Adressen nicht).
        foreach ($written as [$table, $after, $before, $ref]) {
            $plugin = $tables[$table];
            $entry = ['table' => $table, 'ref' => $ref, 'label' => le_plugin_entry_label($plugin, $table, $after)];
            $problem = le_plugin_entry_problem($plugin, $table, $after);
            if ($problem !== null) {
                $found['problems'][] = $entry + ['reason' => $problem];
            }
            $old = $before === null ? [] : le_data_row_images($plugin, $table, $before);
            $new = le_data_row_images($plugin, $table, $after);
            foreach (array_unique(array_map('trim', array_diff($new, $old))) as $url) {
                if ($url !== '' && !upload_image_exists($url)) {
                    $found['missingImages'][] = $entry + ['reason' => $url];
                }
            }
            $unused = array_merge($unused, array_diff($old, $new));
        }

        if (array_filter($found) !== []) {
            $pdo->rollBack();
            return le_data_failure([], $found);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
    if (array_sum($counts) === 0) {
        return ['ok' => true, 'counts' => $counts, 'message' => LE_DATA_TEXT['empty']];
    }
    try {
        $applied[] = $baseline;
        write_private_file(LE_DATA_APPLIED_FILE, le_data_json(array_slice($applied, -LE_DATA_APPLIED_KEEP)));
    } catch (Throwable $e) {
        error_log('le_data_apply: ' . $e->getMessage()); // eingespielt ist schon; nur der Schutz vor Doppeltem fehlt
    }
    // Wie beim Löschen und Speichern im Admin: Bilder, die nichts mehr verwendet, fallen weg.
    delete_unused_uploads($unused);

    return ['ok' => true, 'counts' => $counts, 'message' => sprintf(LE_DATA_TEXT['summary'], $counts['insert'], $counts['update'], $counts['delete'])];
}

/** Bildwerte einer Rohzeile, nur für die Haupttabelle des Plugins (Hook image_values bzw. schema.fields). */
function le_data_row_images(string $plugin, string $table, array $row): array
{
    return plugin_main_table(plugin_manifest($plugin)) === $table ? le_plugin_entry_images($plugin, $row) : [];
}

/** Meldungszeilen zum Ergebnis von le_data_apply für die Kommandozeile. */
function le_data_apply_lines(array $result): array
{
    if ($result['ok']) {
        return [$result['message']];
    }
    $lines = $result['errors'];
    $row = static function (array $entry): array {
        $ref = $entry['ref'] ?? sprintf(LE_DATA_TEXT['newRow'], $entry['table']);
        return [$ref, $entry['label'] !== '' ? sprintf(LE_DATA_TEXT['label'], $entry['label']) : '', $entry['reason']];
    };
    foreach ($result['conflicts'] as $entry) {
        $lines[] = sprintf(LE_DATA_TEXT['conflict'], ...$row($entry));
    }
    foreach ($result['problems'] as $entry) {
        $lines[] = sprintf(LE_DATA_TEXT['problem'], ...$row($entry));
    }
    foreach ($result['missingImages'] as $entry) {
        $lines[] = sprintf(LE_DATA_TEXT['missingImage'], ...$row($entry));
    }
    foreach ($result['notConflicts'] as $ref) {
        $lines[] = sprintf(LE_DATA_TEXT['notConflict'], $ref);
    }
    $lines[] = $result['conflicts'] !== [] ? LE_DATA_TEXT['resolve'] : LE_DATA_TEXT['notApplied'];
    return $lines;
}
