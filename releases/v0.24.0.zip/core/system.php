<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/images.php';

// Systemprüfung: einzige Quelle für die Voraussetzungen des Editors. Admin →
// Einstellungen → System und der Hinweis im Dashboard lesen beide hier.

const SYSTEM_MIN_PHP_VERSION = '8.0';
// Ende der Sicherheitsupdates je PHP-Version (php.net/supported-versions). Danach meldet die
// Systemprüfung einen Mangel, der Editor läuft weiter; fehlende (neuere) Versionen gelten als versorgt.
const SYSTEM_PHP_SECURITY_UNTIL = [
    '8.0' => '2023-11-26',
    '8.1' => '2025-12-31',
    '8.2' => '2026-12-31',
    '8.3' => '2027-12-31',
    '8.4' => '2028-12-31',
    '8.5' => '2029-12-31',
];

function system_php_version_ok(string $version): bool
{
    return version_compare($version, SYSTEM_MIN_PHP_VERSION, '>=');
}

/** Bekommt diese PHP-Version am Tag $today (Y-m-d, sonst heute) noch Sicherheitsupdates? */
function system_php_security_supported(string $version, ?string $today = null): bool
{
    $until = SYSTEM_PHP_SECURITY_UNTIL[implode('.', array_slice(explode('.', $version), 0, 2))] ?? null;
    return $until === null || ($today ?? date('Y-m-d')) <= $until;
}

/**
 * Prüfliste mit key, label, ok und purpose (wofür es gebraucht wird).
 * $extensions/$phpVersion vorgeben nur für Tests; ohne Angabe gilt die
 * laufende PHP-Umgebung.
 */
function system_checks(?array $extensions = null, string $phpVersion = PHP_VERSION): array
{
    $loaded = array_map('strtolower', $extensions ?? get_loaded_extensions());

    $versionOk = system_php_version_ok($phpVersion);
    $checks = [[
        'key' => 'php',
        'label' => 'PHP ' . $phpVersion . ' (mind. ' . SYSTEM_MIN_PHP_VERSION . ')',
        'ok' => $versionOk && system_php_security_supported($phpVersion),
        'purpose' => $versionOk
            ? 'PHP-Version – PHP ' . $phpVersion . ' bekommt keine Sicherheitsupdates mehr, bitte beim Hoster eine neuere Version einstellen.'
            : 'PHP-Version – unter ' . SYSTEM_MIN_PHP_VERSION . ' läuft der Editor nicht.',
    ]];

    $extensionPurposes = [
        'openssl' => 'openssl – ohne sie werden keine Updates installiert.',
        'pdo_sqlite' => DB_SQLITE_MISSING_MESSAGE,
        'zip' => 'zip – ohne sie werden keine Updates entpackt und installiert und keine Sicherungen erstellt.',
        'curl' => 'curl – ohne sie lädt der Editor Updates nur, wenn der Hoster allow_url_fopen erlaubt.',
        'mbstring' => 'mbstring – ohne sie brechen Import und Bearbeiten von Texten mit einem Fehler ab.',
        'dom' => 'dom – ohne sie lassen sich keine SVG-Bilder hochladen.',
        'tokenizer' => 'tokenizer – ohne sie sind Texte in PHP-Seiten nicht bearbeitbar (PHP-Code wird nicht sicher erkannt).',
    ];
    foreach ($extensionPurposes as $name => $purpose) {
        $checks[] = [
            'key' => $name,
            'label' => 'PHP-Erweiterung ' . $name,
            'ok' => in_array($name, $loaded, true),
            'purpose' => $purpose,
        ];
    }

    // Mit vorgegebenen Erweiterungen (Tests) zählt gd als WebP-fähig.
    $checks[] = [
        'key' => 'gd',
        'label' => 'PHP-Erweiterung gd mit WebP',
        'ok' => in_array('gd', $loaded, true) && ($extensions !== null || le_image_webp_supported()),
        'purpose' => 'gd mit WebP – ohne sie werden hochgeladene Bilder nicht verkleinert und nicht als WebP gespeichert, sondern unverändert.',
    ];

    $writablePaths = [
        'content' => [CONTENT_ROOT, 'ohne Schreibrechte werden keine Inhalte, Benutzer oder Einstellungen gespeichert.'],
        'site' => [LE_SITE_ROOT, 'ohne Schreibrechte werden Änderungen nicht in die Seiten der Website geschrieben.'],
        'uploads' => [UPLOADS_ROOT, 'ohne Schreibrechte lassen sich keine Bilder hochladen.'],
    ];
    foreach ($writablePaths as $key => [$path, $purpose]) {
        $relative = le_instance_relative($path) . '/';
        $checks[] = [
            'key' => 'writable_' . $key,
            'label' => 'Schreibrechte ' . $relative,
            'ok' => system_path_writable($path),
            'purpose' => $relative . ' – ' . $purpose,
        ];
    }

    $siteHtaccess = le_instance_relative(LE_SITE_ROOT) . '/.htaccess';
    $checks[] = [
        'key' => 'site_rewrite',
        'label' => 'Keine Rewrite-Regeln in ' . $siteHtaccess,
        'ok' => !system_has_rewrite_rules(LE_SITE_ROOT . '/.htaccess'),
        'purpose' => $siteHtaccess . ' – eigene Rewrite-Regeln heben auf Apache die des Editors auf: Seiten unter /'
            . dirname($siteHtaccess) . '/ laufen dann ohne Shortcodes und Cookie-Banner und zeigen Fehler roh. Die Regeln in die .htaccess im Hauptordner verschieben.',
    ];

    $checks[] = [
        'key' => 'setup_password',
        'label' => 'Kein Passwort in config.php',
        'ok' => !le_setup_password_left(),
        'purpose' => 'config.php – dort steht noch das Passwort des ersten Admins im Klartext. Den Admin gibt es schon: das Passwort in config.php per FTP leeren oder die Datei löschen.',
    ];

    return $checks;
}

/** Ob die .htaccess $file eine Rewrite-Anweisung enthält (auch RewriteEngine Off ersetzt die geerbten Regeln). */
function system_has_rewrite_rules(string $file): bool
{
    $content = is_file($file) ? (string) @file_get_contents($file) : '';

    return preg_match('/^[ \t]*Rewrite[A-Za-z]+\b/mi', $content) === 1;
}

/** Ein fehlender Ordner zählt als beschreibbar, wenn ensure_dir() ihn anlegen kann. */
function system_path_writable(string $path): bool
{
    return is_dir($path) ? is_writable($path) : !file_exists($path) && is_writable(dirname($path));
}

/** Nur die Einträge, die fehlen. */
function system_problems(array $checks): array
{
    return array_values(array_filter($checks, static fn (array $check): bool => !$check['ok']));
}

/** Mängel für den Dashboard-Hinweis: nur Admins bekommen sie, sonst leer. */
function system_problems_for_current_user(): array
{
    return is_admin() ? system_problems(system_checks()) : [];
}
