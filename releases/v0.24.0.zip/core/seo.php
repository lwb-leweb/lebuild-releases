<?php
declare(strict_types=1);

// Was jede Website für Suchmaschinen braucht, ohne dass sie es selbst mitbringt: robots.txt, sitemap.xml,
// Vorschaubild (og:image) und strukturierte Daten der Startseite. Eigene Dateien der Website gehen vor
// (public/site/robots.txt, public/site/sitemap.xml), eigene Tags im Kopf ebenso.

require_once __DIR__ . '/siteRoutes.php';
require_once __DIR__ . '/plugins.php';

const LE_SEO_ROBOTS_URL = '/robots.txt';
const LE_SEO_SITEMAP_URL = '/sitemap.xml';
// Adressen, die keine Suchmaschine braucht (Backend, Login, Endpoints).
const LE_SEO_ROBOTS_DISALLOW = [LE_ADMIN_PATH . '/', LOGIN_URL, '/api/'];
// Ordner unter public/site ohne Seiten für die Sitemap (Teile der Website, Uploads).
const LE_SEO_SKIP_DIRS = [LE_SITE_INCLUDES_DIR, LE_SITE_UPLOADS_DIR];
// Einstellung „Vorschaubild“ (Schlüssel image): Adresse auf der Website (/assets/share.jpg) oder https-Adresse.
const LE_SEO_IMAGE_PATTERN = '#^(?:/[A-Za-z0-9._~/%-]+|https://[A-Za-z0-9.-]+(?::\d+)?/[A-Za-z0-9._~/%-]*)$#';

/** Website-Adresse aus den Einstellungen ohne „/“ am Ende; null ohne gültige eigene (die Vorgabe zählt nicht). */
function le_seo_base_url(): ?string
{
    $url = le_site_base_url();

    return $url !== null && $url !== rtrim(LE_SITE_CONFIG_DEFAULTS['url'], '/') ? $url : null;
}

/** Absolute Adresse für $path (/x oder https://…); null ohne Website-Adresse bei einem Pfad. */
function le_seo_absolute(string $path): ?string
{
    if (str_starts_with($path, 'https://') || str_starts_with($path, 'http://')) {
        return $path;
    }
    $base = le_seo_base_url();

    return $base === null ? null : $base . '/' . ltrim($path, '/');
}

/** robots.txt: alles erlaubt außer LE_SEO_ROBOTS_DISALLOW, mit Website-Adresse der Hinweis auf die Sitemap. */
function le_seo_robots_txt(): string
{
    $lines = ['User-agent: *'];
    foreach (LE_SEO_ROBOTS_DISALLOW as $path) {
        $lines[] = 'Disallow: ' . $path;
    }
    $sitemap = le_seo_absolute(LE_SEO_SITEMAP_URL);
    if ($sitemap !== null) {
        $lines[] = '';
        $lines[] = 'Sitemap: ' . $sitemap;
    }

    return implode("\n", $lines) . "\n";
}

/** sitemap.xml mit allen Adressen aus le_seo_sitemap_urls; null ohne Website-Adresse (Sitemaps brauchen absolute Adressen). */
function le_seo_sitemap_xml(): ?string
{
    $base = le_seo_base_url();
    if ($base === null) {
        return null;
    }
    $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
    foreach (le_seo_sitemap_urls() as $path => $lastmod) {
        $xml .= '<url><loc>' . htmlspecialchars($base . $path, ENT_XML1 | ENT_QUOTES, 'UTF-8') . '</loc>'
            . ($lastmod !== null ? '<lastmod>' . gmdate('Y-m-d', $lastmod) . '</lastmod>' : '') . "</url>\n";
    }

    return $xml . "</urlset>\n";
}

/**
 * Adressen der Sitemap als [Pfad => Zeitstempel der letzten Änderung oder null]: jede Seite der Website
 * (le_seo_site_pages), dazu die der Plugins (Hook sitemap_urls), sortiert.
 */
function le_seo_sitemap_urls(): array
{
    $urls = le_seo_site_pages() + plugin_sitemap_urls();
    ksort($urls, SORT_STRING);

    return $urls;
}

/**
 * Seiten der Website unter ihrer Adresse ohne Endung (/, /impressum, /a/): Dokumente unter public/site samt
 * Unterordnern außer LE_SEO_SKIP_DIRS und Punktordnern; nicht die 404-Seite, Hilfsdateien mit „_“ am Anfang,
 * Adressen, unter denen eine andere Datei kommt oder die index.php selbst belegt, und Seiten mit noindex.
 */
function le_seo_site_pages(): array
{
    $pages = [];
    $root = realpath(LE_SITE_ROOT);
    if ($root === false) {
        return [];
    }
    $reserved = array_map('strtolower', le_site_reserved_names());
    $walk = static function (string $dir, string $prefix) use (&$walk, &$pages, $reserved): void {
        foreach (scandir($dir) ?: [] as $entry) {
            $file = $dir . '/' . $entry;
            if ($entry[0] === '.' || is_link($file)) {
                continue;
            }
            if (is_dir($file)) {
                if (!($prefix === '' && in_array(strtolower($entry), LE_SEO_SKIP_DIRS, true))) {
                    $walk($file, $prefix . $entry . '/');
                }
                continue;
            }
            $stem = pathinfo($entry, PATHINFO_FILENAME);
            if (!le_site_is_document($entry) || str_starts_with($entry, '_') || !preg_match(LE_SITE_PATH_PATTERN, $prefix . $entry)) {
                continue;
            }
            $path = '/' . $prefix . ($stem === 'index' ? '' : $stem);
            $first = strtolower(explode('/', ltrim($path, '/'))[0]);
            if ($path === LE_SITE_NOT_FOUND_PAGE || ($first !== '' && in_array($first, $reserved, true))
                || realpath((string) le_site_request_file($path)) !== realpath($file) || le_seo_source_noindex($file)) {
                continue;
            }
            $pages[$path] = filemtime($file) ?: null;
        }
    };
    $walk($root, '');

    return $pages;
}

/** Ob die Quelldatei einer Seite selbst <meta name="robots"> mit noindex hat (dann nicht in die Sitemap). */
function le_seo_source_noindex(string $file): bool
{
    $source = (string) file_get_contents($file);
    if (stripos($source, 'noindex') === false) {
        return false;
    }
    $doc = markup_parse($source);
    foreach ($doc['nodes'] as $node) {
        if ($node['type'] === 'element' && $node['tag'] === 'meta' && strtolower(trim(markup_attr_text($node, 'name'))) === 'robots'
            && str_contains(strtolower(markup_attr_text($node, 'content')), LE_SITE_NOINDEX)) {
            return true;
        }
    }

    return false;
}

/**
 * Ergänzt den Kopf einer ausgelieferten Seite ($path kanonisch, $status ihr HTTP-Status): og:image aus der
 * Einstellung „Vorschaubild“, wenn die Seite keins hat; auf der Startseite (Status 200) strukturierte Daten
 * zu Website und Betreiber (le_seo_site_json_ld), wenn die Seite keine hat. Ohne <head> unverändert.
 */
function le_seo_head(string $html, string $path, int $status): string
{
    $doc = markup_parse($html);
    $headIndex = markup_find_tag($doc, 'head');
    if ($headIndex === null) {
        return $html;
    }
    $hasImage = false;
    $hasJsonLd = false;
    foreach ($doc['nodes'][$headIndex]['children'] as $i) {
        $node = $doc['nodes'][$i];
        if ($node['type'] !== 'element') {
            continue;
        }
        $name = strtolower(trim(markup_attr_text($node, 'property') ?: markup_attr_text($node, 'name')));
        $hasImage = $hasImage || ($node['tag'] === 'meta' && $name === 'og:image');
        $hasJsonLd = $hasJsonLd || ($node['tag'] === 'script' && strtolower(trim(markup_attr_text($node, 'type'))) === 'application/ld+json');
    }
    // Strukturierte Daten können auch im <body> stehen.
    $hasJsonLd = $hasJsonLd || stripos($html, 'application/ld+json') !== false;

    $add = '';
    $image = le_seo_config_image();
    if (!$hasImage && $image !== null) {
        $add .= '<meta property="og:image" content="' . markup_attr_escape($image) . '">';
    }
    if (!$hasJsonLd && $status === 200 && $path === LE_SITE_HOME_URL) {
        $add .= le_seo_json_ld_tag(le_seo_site_json_ld($image));
    }
    if ($add === '') {
        return $html;
    }
    $end = $doc['nodes'][$headIndex]['inner_end'];

    return markup_apply($html, [['start' => $end, 'end' => $end, 'text' => $add]]);
}

/** $tags ans Ende des <head> von $html; ohne <head> oder ohne Tags unverändert. */
function le_seo_head_append(string $html, string $tags): string
{
    if ($tags === '') {
        return $html;
    }
    $doc = markup_parse($html);
    $headIndex = markup_find_tag($doc, 'head');
    if ($headIndex === null) {
        return $html;
    }
    $end = $doc['nodes'][$headIndex]['inner_end'];

    return markup_apply($html, [['start' => $end, 'end' => $end, 'text' => $tags]]);
}

/** Vorschaubild aus den Einstellungen als absolute Adresse; null ohne, bei ungültigem Wert oder ohne Website-Adresse. */
function le_seo_config_image(): ?string
{
    $image = le_site_config()['image'] ?? '';
    $image = is_string($image) ? trim($image) : '';

    return $image !== '' && preg_match(LE_SEO_IMAGE_PATTERN, $image) ? le_seo_absolute($image) : null;
}

/**
 * Strukturierte Daten der Startseite (schema.org): WebSite und Organization aus den Einstellungen (Name, Adresse,
 * E-Mail, Vorschaubild); ohne Website-Adresse [] (schema.org braucht absolute Adressen).
 */
function le_seo_site_json_ld(?string $image): array
{
    $base = le_seo_base_url();
    if ($base === null) {
        return [];
    }
    $config = le_site_config();
    $text = static fn (string $key): string => is_string($config[$key] ?? null) ? trim($config[$key]) : '';
    $name = $text('name') !== '' ? $text('name') : LE_SITE_CONFIG_DEFAULTS['name'];
    $organization = ['@type' => 'Organization', '@id' => $base . '/#organization', 'name' => $name, 'url' => $base . '/'];
    if ($text('email') !== '' && $text('email') !== LE_SITE_CONFIG_DEFAULTS['email'] && filter_var($text('email'), FILTER_VALIDATE_EMAIL)) {
        $organization['email'] = $text('email');
    }
    if ($image !== null) {
        $organization['image'] = $image;
    }
    $website = ['@type' => 'WebSite', '@id' => $base . '/#website', 'name' => $name, 'url' => $base . '/', 'publisher' => ['@id' => $organization['@id']]];
    if ($text('tagline') !== '') {
        $website['description'] = $text('tagline');
    }
    $locale = $text('locale');
    if (preg_match('/^[a-z]{2}(?:_[A-Z]{2})?$/', $locale)) {
        $website['inLanguage'] = str_replace('_', '-', $locale);
    }

    return ['@context' => 'https://schema.org', '@graph' => [$website, $organization]];
}

/** <script type="application/ld+json"> mit $data; '' bei leeren Daten. JSON_HEX_TAG: kein </script> aus Texten. */
function le_seo_json_ld_tag(array $data): string
{
    if ($data === []) {
        return '';
    }
    $json = json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP);

    return $json === false ? '' : '<script type="application/ld+json">' . $json . '</script>';
}
