// Zeigt die Info-Hinweise, die der Besucher noch nicht weggeklickt hat, und merkt sich das Wegklicken im Browser.
(function () {
  var STORE = 'site-notice-dismissed';
  var root = document.querySelector('[data-site-notice-root]');
  if (!root) return;

  function read() {
    try {
      var list = JSON.parse(localStorage.getItem(STORE) || '[]');
      return Array.isArray(list) ? list : [];
    } catch (e) {
      return [];
    }
  }

  function write(list) {
    try {
      localStorage.setItem(STORE, JSON.stringify(list));
    } catch (e) {
      // Ohne Speicher (privates Fenster, gesperrt) bleibt der Hinweis nur auf dieser Seite weg.
    }
  }

  var dismissed = read();
  root.querySelectorAll('[data-site-notice]').forEach(function (notice) {
    var key = notice.getAttribute('data-site-notice');
    if (dismissed.indexOf(key) === -1) notice.hidden = false;
    notice.querySelector('.site-notice__close').addEventListener('click', function () {
      notice.hidden = true;
      var list = read();
      if (list.indexOf(key) === -1) list.push(key);
      // Nur die letzten 50 merken, alte Hinweise sind längst gelöscht.
      write(list.slice(-50));
    });
  });
})();
