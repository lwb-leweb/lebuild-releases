# Info-Hinweis Plugin

Kurze Nachrichten auf jeder Seite der Website, z. B. „Wir sind im Betriebsurlaub“ oder „Wir bauen gerade um“. Besucher klicken sie weg; der Browser merkt sich das.

## Aktivierung

Im Backend unter Plugins aktivieren. Legt die Tabelle `site_notices` an, danach steht „Info-Hinweis“ in der Seitenleiste. Die Website braucht keinen Einbau: Der Hinweis erscheint auf jeder Seite unten links.

## Was es kann

- Beliebig viele Hinweise, untereinander in der Reihenfolge, in der sie angelegt wurden
- Optional Zeitraum: „Anzeigen ab“ und „Anzeigen bis“ (je einschließlich), leer heißt sofort bzw. ohne Ende
- Wegklicken je Hinweis; wird der Text geändert, sehen ihn alle wieder
- Ohne aktuellen Hinweis bleibt die Seite unverändert (kein CSS, kein Skript)

## Im Admin verwenden

„Info-Hinweis“ → „Neu“, Nachricht schreiben, bei Bedarf Zeitraum setzen, speichern. Abschalten: löschen oder „Anzeigen bis“ auf gestern setzen.

## API-Endpoints

Keine eigenen; das Backend nutzt die generischen Endpoints `/api/plugins/generic/{list,get,save,delete}.php?plugin=site-notice`.

## Frontend einbinden

Nichts einzubauen. Farben passt die Website über CSS-Variablen an:

```css
.site-notices { --site-notice-bg: #0b3d2e; --site-notice-color: #fff; --site-notice-radius: 4px; }
```

Klassen: `.site-notices` (Wurzel, fest unten links, auf dem Handy volle Breite), `.site-notice`, `.site-notice__text`, `.site-notice__close`.

## Datenbank

`site_notices`: `id`, `title` (Nachricht, mehrzeiliger Text), `starts_on`, `ends_on` (`YYYY-MM-DD` oder leer), `created_at`, `updated_at`.

## Bekannte Einschränkungen

- Nur Text, keine Links oder Formatierung.
- Ohne JavaScript erscheint kein Hinweis (versteckt ausgeliefert, damit Weggeklicktes nicht aufblitzt).
- Weggeklickt gilt pro Browser (localStorage), im privaten Fenster bis zum Schließen; sperrt der Browser den Speicher, kommt der Hinweis auf jeder Seite wieder.
- Steht der Cookie-Banner offen, liegt er über dem Hinweis.

## Changelog

- **2026-11-09 — v1.0.0** — Erste Fassung: Hinweise mit optionalem Zeitraum auf jeder Seite, wegklickbar.
