<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/db.php';
require_once __DIR__ . '/../../core/plugins.php';
require_once __DIR__ . '/../../core/textMarkup.php';

// Grundform und Wegklicken auf der Website (per HTTP erreichbar, plugins/.htaccess).
const SITE_NOTICE_STYLE = PLUGINS_URL . 'site-notice/assets/site-notice.css';
const SITE_NOTICE_SCRIPT = PLUGINS_URL . 'site-notice/assets/site-notice.js';
// Wurzelelement der Hinweise; steht es schon in der Seite, fügt der Filter nichts mehr ein.
const SITE_NOTICE_ROOT_ATTR = 'data-site-notice-root';
const SITE_NOTICE_TEXT = [
    'close' => 'Hinweis schließen',
];

/**
 * Hinweise, die am Tag $today (YYYY-MM-DD) gelten: Beginn leer oder erreicht, Ende leer oder noch nicht vorbei.
 * Älteste zuerst, so stehen sie in der Reihenfolge, in der sie angelegt wurden.
 */
function site_notice_current(string $today): array
{
    $stmt = db()->prepare('SELECT id, title, starts_on, ends_on FROM site_notices'
        . ' WHERE (starts_on IS NULL OR starts_on <= ?) AND (ends_on IS NULL OR ends_on >= ?) ORDER BY id ASC');
    $stmt->execute([$today, $today]);

    return array_values(array_filter($stmt->fetchAll(), static fn (array $row): bool => trim((string) $row['title']) !== ''));
}

/**
 * Kennung fürs Wegklicken: ID plus Prüfsumme des Textes. Wer den Text ändert, zeigt den Hinweis
 * allen wieder, die die alte Fassung weggeklickt haben.
 */
function site_notice_key(array $row): string
{
    return (int) $row['id'] . '-' . substr(hash('sha256', (string) $row['title']), 0, 10);
}

/** HTML der Hinweise (versteckt; das Skript zeigt die an, die der Besucher nicht weggeklickt hat). */
function site_notice_html(array $rows): string
{
    $items = '';
    foreach ($rows as $row) {
        $items .= '<div class="site-notice" role="status" data-site-notice="' . htmlspecialchars(site_notice_key($row), ENT_QUOTES) . '" hidden>'
            . '<p class="site-notice__text">' . le_text_lines((string) $row['title']) . '</p>'
            . '<button type="button" class="site-notice__close" aria-label="' . htmlspecialchars(SITE_NOTICE_TEXT['close'], ENT_QUOTES) . '">&times;</button>'
            . '</div>';
    }

    return '<div class="site-notices" ' . SITE_NOTICE_ROOT_ATTR . '>' . $items . '</div>'
        . '<script src="' . SITE_NOTICE_SCRIPT . '" defer></script>';
}

/** Hook: Hinweise vor </body>, CSS vor </head>. Ohne aktuelle Hinweise bleibt die Seite unverändert. */
function site_notice_filter_site_html(string $html): string
{
    $body = strripos($html, '</body>');
    if ($body === false || str_contains($html, SITE_NOTICE_ROOT_ATTR)) {
        return $html;
    }
    try {
        $rows = site_notice_current(date('Y-m-d'));
    } catch (Throwable $e) {
        // Fehlertext nur ins Log, die Seite kommt ohne Hinweis.
        error_log('site-notice: ' . $e->getMessage());
        return $html;
    }
    if ($rows === []) {
        return $html;
    }

    $html = substr_replace($html, site_notice_html($rows), $body, 0);
    $head = stripos($html, '</head>');

    return $head === false ? $html : substr_replace($html, '<link rel="stylesheet" href="' . SITE_NOTICE_STYLE . '">', $head, 0);
}
