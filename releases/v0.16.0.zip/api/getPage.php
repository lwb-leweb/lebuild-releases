<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/fileStore.php';
require_once __DIR__ . '/../core/labels.php';
require_once __DIR__ . '/../core/phpRewriter.php';

require_auth();

$page = safe_page_name((string) ($_GET['page'] ?? ''));

// Felder samt Komponenten, Feldart je Pfad (Bild, Link, Linktext, Alt-Text, Hintergrund) und
// Namen; dieselbe Form vergleicht das Speichern als Stand beim Laden (merge_save_content).
['content' => $content, 'fieldKinds' => $fieldKinds, 'docs' => $docs] = page_editor_content($page);

json_response([
    'ok' => true,
    'page' => $page,
    'content' => $content,
    'labels' => build_labels_for_content($content, $docs),
    'fieldKinds' => $fieldKinds,
]);
