<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/fileStore.php';
require_once __DIR__ . '/../core/phpRewriter.php';

require_auth();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$page = safe_page_name((string) ($body['page'] ?? ''));
$content = $body['content'] ?? null;
// Stand beim Laden (getPage) für die Prüfung je Feld (merge_save_content); ohne ihn gilt der
// geschickte Inhalt ganz (Aufrufe ohne geladenen Stand).
$base = $body['base'] ?? null;

if (!is_array($content) || ($base !== null && !is_array($base))) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidContent']], 400);
}

// Ganz oder gar nicht: erst alle Ersetzungen (Komponenten und Seite) berechnen,
// dann JSON mit Backup und Seitendateien schreiben. Die Sperre hält über den ganzen Ablauf,
// damit gleichzeitige Saves keinen Stand verlieren und der Verlauf jeden Stand richtig zuordnet.
// Mit Stand beim Laden kommen alle Komponenten aus dem Stand jetzt dazu, also sind alle gesperrt.
$locks = lock_pages([$page, ...array_keys($base === null ? array_intersect_key($content, shared_components()) : shared_components())]);
// Von jemand anderem seit dem Laden geänderte Felder bleiben, wie sie sind, die übrigen Änderungen
// werden gespeichert (ganz oder gar nicht); ohne übrige Änderung wird nichts geschrieben.
$conflicts = [];
if ($base !== null) {
    $editor = page_editor_content($page);
    ['content' => $content, 'saved' => $saved, 'conflicts' => $conflictIds] = merge_save_content($editor['content'], $content, $base);
    $conflicts = save_conflict_fields($conflictIds, $editor['docs']);
    if ($conflicts !== [] && $saved === []) {
        json_response(['ok' => false, 'error' => save_conflict_message($conflicts, false), 'fields' => $conflicts], 409);
    }
}
$plans = split_page_content($page, $content);

$errors = [];
foreach ($plans as $name => $planContent) {
    $plans[$name] = ['content' => $planContent] + plan_source_rewrite($name, $planContent);
    $errors = array_merge($errors, $plans[$name]['errors']);
}
if ($errors !== []) {
    json_response(['ok' => false, 'error' => rewrite_error_message($errors), 'fields' => $errors], 422);
}

write_page_plans($page, $plans);
// Bei Konflikten lädt der Editor nicht neu: Er bekommt die gespeicherten Werte so, wie getPage sie
// liefert, als neuen Stand beim Laden.
$response = ['ok' => true, 'page' => $page, 'updatedAt' => page_updated_at($page), 'conflicts' => $conflicts];
if ($conflicts !== []) {
    $stored = flatten_content(page_editor_content($page)['content']);
    $response['message'] = save_conflict_message($conflicts, true);
    $response['saved'] = array_intersect_key($stored, array_flip($saved));
}
unlock_pages($locks);

json_response($response);
