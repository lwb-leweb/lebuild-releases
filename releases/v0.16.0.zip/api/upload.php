<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/fileStore.php';

require_auth();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

// Über post_max_size verwirft PHP den ganzen Body, $_FILES bleibt leer.
if (empty($_FILES['file']) || !is_array($_FILES['file'])) {
    $tooLarge = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > upload_max_bytes();
    json_response(['ok' => false, 'error' => $tooLarge ? upload_too_large_message() : UPLOAD_TEXT['noFile']], 400);
}

$file = $_FILES['file'];
$error = $file['error'] ?? UPLOAD_ERR_NO_FILE;
if (($error === UPLOAD_ERR_INI_SIZE || $error === UPLOAD_ERR_FORM_SIZE) || ($error === UPLOAD_ERR_OK && ($file['size'] ?? 0) > upload_max_bytes())) {
    json_response(['ok' => false, 'error' => upload_too_large_message()], 400);
}
if ($error !== UPLOAD_ERR_OK) {
    json_response(['ok' => false, 'error' => UPLOAD_TEXT['failed']], 400);
}

$originalName = (string) ($file['name'] ?? '');
$extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
if (!isset(UPLOAD_MIME_TYPES[$extension])) {
    json_response(['ok' => false, 'error' => sprintf(UPLOAD_TEXT['type'], implode(', ', array_keys(UPLOAD_MIME_TYPES)))], 400);
}

$tmp = (string) ($file['tmp_name'] ?? '');
$mime = mime_content_type($tmp) ?: '';
// Endung und tatsächlicher Inhalt müssen zusammenpassen (UPLOAD_MIME_TYPES).
if (!in_array($mime, UPLOAD_MIME_TYPES[$extension], true)) {
    json_response(['ok' => false, 'error' => UPLOAD_TEXT['content']], 400);
}
if ($extension === 'svg' && !svg_is_safe((string) file_get_contents($tmp))) {
    json_response(['ok' => false, 'error' => UPLOAD_TEXT['svg']], 400);
}

prepare_storage();
$safeName = preg_replace('/[^a-zA-Z0-9._-]/', '-', pathinfo($originalName, PATHINFO_FILENAME));
$safeName = trim((string) $safeName, '-_.') ?: 'upload';
$targetName = $safeName . '-' . bin2hex(random_bytes(6)) . '.' . $extension;
$targetPath = UPLOADS_ROOT . '/' . $targetName;

if (!move_uploaded_file($tmp, $targetPath)) {
    json_response(['ok' => false, 'error' => UPLOAD_TEXT['store']], 500);
}

json_response(['ok' => true, 'url' => UPLOADS_URL . $targetName]);
