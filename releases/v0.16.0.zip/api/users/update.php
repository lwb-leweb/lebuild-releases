<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/users.php';

require_admin();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$id = trim((string) ($body['id'] ?? ''));
if ($id === '') {
    json_response(['ok' => false, 'error' => API_TEXT['userIdRequired']], 400);
}

$store = users_load();
$index = null;
foreach ($store['users'] as $i => $user) {
    if ($user['id'] === $id) {
        $index = $i;
        break;
    }
}
if ($index === null) {
    json_response(['ok' => false, 'error' => API_TEXT['userNotFound']], 404);
}

$current = $store['users'][$index];
$updated = $current;
$changed = false;

if (array_key_exists('username', $body)) {
    $newUsername = trim((string) $body['username']);
    if ($error = users_validate_username($newUsername)) {
        json_response(['ok' => false, 'error' => $error], 400);
    }
    if (strcasecmp($newUsername, $current['username']) !== 0) {
        foreach ($store['users'] as $other) {
            if ($other['id'] !== $id && strcasecmp($other['username'], $newUsername) === 0) {
                json_response(['ok' => false, 'error' => API_TEXT['usernameTaken']], 409);
            }
        }
    }
    $updated['username'] = $newUsername;
    $changed = $changed || $newUsername !== $current['username'];
}

if (array_key_exists('role', $body)) {
    $newRole = (string) $body['role'];
    if ($error = users_validate_role($newRole)) {
        json_response(['ok' => false, 'error' => $error], 400);
    }
    if ($newRole !== $current['role']) {
        if ($current['role'] === USER_ROLE_ADMIN && $newRole !== USER_ROLE_ADMIN) {
            if (users_count_admins($id) === 0) {
                json_response(['ok' => false, 'error' => API_TEXT['lastAdminDemote']], 400);
            }
        }
        $updated['role'] = $newRole;
        $changed = true;
    }
}

if ($changed) {
    $updated['updatedAt'] = current_iso_time();
    $store['users'][$index] = $updated;
    users_save($store);
}

json_response(['ok' => true, 'user' => users_public_view($updated)]);
