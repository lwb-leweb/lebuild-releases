<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/users.php';

// Auch während eines erzwungenen Passwortwechsels erreichbar.
require_auth(true);
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$newPassword = (string) ($body['newPassword'] ?? '');
$currentPassword = (string) ($body['currentPassword'] ?? '');
$targetId = trim((string) ($body['id'] ?? ''));

$self = current_user();
if ($self === null) {
    json_response(['ok' => false, 'error' => API_TEXT['notAuthenticated']], 401);
}

if ($targetId === '' || $targetId === $self['id']) {
    $isSelf = true;
    $targetId = $self['id'];
} else {
    $isSelf = false;
    if (!is_admin()) {
        json_response(['ok' => false, 'error' => API_TEXT['forbidden']], 403);
    }
}

if ($error = users_validate_password($newPassword)) {
    json_response(['ok' => false, 'error' => $error], 400);
}
if ($newPassword === DEFAULT_ADMIN_PASSWORD) {
    json_response(['ok' => false, 'error' => API_TEXT['samePassword']], 400);
}

$store = users_load();
$index = null;
foreach ($store['users'] as $i => $user) {
    if ($user['id'] === $targetId) {
        $index = $i;
        break;
    }
}
if ($index === null) {
    json_response(['ok' => false, 'error' => API_TEXT['userNotFound']], 404);
}

// Beim erzwungenen Wechsel nach dem Erst-Login ist das alte Passwort das
// bekannte Standardpasswort; die frische Session reicht als Nachweis.
if ($isSelf && empty($store['users'][$index]['mustChangePassword'])) {
    if (!users_verify_password($store['users'][$index], $currentPassword)) {
        json_response(['ok' => false, 'error' => API_TEXT['wrongPassword']], 400);
    }
}

$store['users'][$index]['passwordHash'] = password_hash($newPassword, PASSWORD_BCRYPT);
$store['users'][$index]['updatedAt'] = current_iso_time();
if ($isSelf) {
    unset($store['users'][$index]['mustChangePassword']);
}
users_save($store);

json_response(['ok' => true]);
