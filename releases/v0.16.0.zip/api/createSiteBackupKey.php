<?php
declare(strict_types=1);

// Neuen Schlüssel für api/backup.php erzeugen; der alte gilt dann nicht mehr.
// Der Klartext steht nur in dieser Antwort.

require_once __DIR__ . '/../core/siteBackup.php';

require_admin();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

try {
    $key = site_backup_create_key();
} catch (Throwable $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 500);
}

header('Cache-Control: no-store');
json_response(['ok' => true, 'key' => $key] + site_backup_admin_status());
