<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/fileStore.php';
require_once __DIR__ . '/../core/phpRewriter.php';

// Auch Editoren: „Verlauf“ im Seiten-Editor stellt frühere Stände wieder her.
require_auth();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$page = safe_page_name((string) ($body['page'] ?? ''));
$backup = basename(sanitize_text_value($body['backup'] ?? ''));

if (!preg_match('/^[0-9]{14}\.json$/', $backup)) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidBackup']], 400);
}

// Dieselbe Sperre wie beim Speichern, für die Seite und alle Komponenten, die der Eintrag
// mit zurücksetzen kann.
$locks = lock_pages([$page, ...array_keys(shared_components())]);
$backupPath = BACKUPS_ROOT . '/' . $page . '/' . $backup;
if (!is_file($backupPath)) {
    json_response(['ok' => false, 'error' => API_TEXT['backupNotFound']], 404);
}

$data = json_decode((string) file_get_contents($backupPath), true);
if (!is_array($data)) {
    json_response(['ok' => false, 'error' => API_TEXT['backupInvalid']], 500);
}

// Die Seite aus dem Backup, dazu die Komponenten, die das Speichern dieses Eintrags mitgeschrieben
// hat (backup_components); ganz oder gar nicht wie beim Speichern.
// Nur Felder, die in der Datei noch markiert sind; IDs, die es nicht mehr gibt, werden gezählt.
// Alter Klartext (ohne Auszeichnung) mit gleichem Text behält die Auszeichnung der Datei (wie getPage);
// ein Wert mit Auszeichnung kommt so zurück, wie er im Backup steht.
// Die Live-Seite rendert aus public/site/, nicht aus dem JSON: erst prüfen, dann beides schreiben.
$plans = [];
$errors = [];
$restoredCount = 0;
$skipped = 0;
foreach (backup_components($page, $backup) + [$page => $data] as $name => $values) {
    // Eine Komponente, deren Datei es nicht mehr gibt, blockiert die Seite nicht: ihre Felder
    // zählen als übersprungen. Fehlt die Seite selbst, bleibt es beim Fehler.
    if ($name !== $page && page_source_path($name) === null) {
        $skipped += count(flatten_content($values));
        continue;
    }
    $doc = page_source_doc($name);
    ['content' => $restored, 'skipped' => $unknown] = known_source_fields($doc, $name, $values);
    $restored = align_text_with_source($doc, $name, $restored, true);
    $plans[$name] = ['doc' => $doc, 'restored' => $restored] + plan_source_rewrite($name, $restored);
    $errors = array_merge($errors, $plans[$name]['errors']);
    $restoredCount += count(flatten_content($restored));
    $skipped += $unknown;
}
if ($errors !== []) {
    json_response(['ok' => false, 'error' => rewrite_error_message($errors), 'fields' => $errors], 422);
}
// Das Backup liegt über dem aktuellen Stand: Felder, die es nicht kennt (z. B. später
// dazugekommene Alt-Texte), bleiben im JSON wie in der Datei.
foreach ($plans as $name => $plan) {
    // Eine kaputte aktuelle JSON (unlesbar) ersetzt das Backup ganz: So repariert „Verlauf“ die Seite.
    $plans[$name]['content'] = array_replace_recursive(load_component_content($name) ?? [], $plan['restored']);
    $plans[$name]['kinds'] = page_field_kinds($plan['doc'], $name, $plans[$name]['content']);
}

write_page_plans($page, $plans, true);
unlock_pages($locks);

json_response(['ok' => true, 'page' => $page, 'restored' => $restoredCount, 'skipped' => $skipped]);
