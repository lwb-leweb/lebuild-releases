<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/plugins.php';
require_once __DIR__ . '/../../core/db.php';

require_auth();

$state = load_plugins_state();
$plugins = [];

foreach (list_plugin_dirs() as $name) {
    try {
        $manifest = plugin_manifest($name);
        $adminModule = plugin_admin_module_path($manifest);
        $plugins[] = [
            'name' => $name,
            'label' => (string) ($manifest['label'] ?? $name),
            'version' => (string) ($manifest['version'] ?? '0.0.0'),
            'description' => (string) ($manifest['description'] ?? ''),
            'requires' => $manifest['requires'],
            'active' => in_array($name, $state['active'], true),
            'installed' => isset($state['installed'][$name]),
            'installedVersion' => $state['installed'][$name]['version'] ?? null,
            'hasAdminSidebar' => plugin_has_admin_sidebar($manifest),
            'hasAdminModule' => $adminModule !== null,
            'hasSchema' => isset($manifest['schema']['fields']) && is_array($manifest['schema']['fields']),
        ];
    } catch (Throwable $e) {
        $plugins[] = [
            'name' => $name,
            'error' => $e->getMessage(),
        ];
    }
}

json_response([
    'ok' => true,
    'plugins' => $plugins,
    'dbAvailable' => db_available(),
    'dbMessage' => db_available() ? '' : DB_UNAVAILABLE_MESSAGE,
]);
