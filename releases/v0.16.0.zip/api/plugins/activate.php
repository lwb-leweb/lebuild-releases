<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/plugins.php';
require_once __DIR__ . '/../../core/db.php';
require_once __DIR__ . '/../../core/mail.php';

require_admin();
require_csrf();
require_no_db_migration();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$name = (string) ($body['name'] ?? '');
if (!plugin_name_valid($name)) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidPlugin']], 400);
}
if (!is_file(plugin_path($name, 'plugin.json'))) {
    json_response(['ok' => false, 'error' => API_TEXT['pluginNotFound']], 404);
}

try {
    $manifest = plugin_manifest($name);
} catch (Throwable $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 500);
}

$state = load_plugins_state();

if (!empty($manifest['requires']['database']) && !db_available()) {
    json_response(db_migration_error('database_required', DB_UNAVAILABLE_MESSAGE), DB_MIGRATION_ERROR_STATUS['database_required']);
}

if (!empty($manifest['requires']['uploads']) && (!is_dir(UPLOADS_ROOT) || !is_writable(UPLOADS_ROOT))) {
    json_response([
        'ok' => false,
        'error' => 'uploads_unwritable',
        'message' => 'Uploads-Verzeichnis nicht beschreibbar.',
    ], 409);
}

if (!empty($manifest['requires']['mail']) && !core_mail_available()) {
    json_response([
        'ok' => false,
        'error' => 'mail_unavailable',
        'message' => 'Kein Mailversand verfügbar. Bitte SMTP in den Einstellungen konfigurieren.',
    ], 409);
}

if (!empty($manifest['requires']['database']) && !isset($state['installed'][$name])) {
    $sqlPath = plugin_sql_path($name, 'install');
    if (!is_file($sqlPath)) {
        json_response(db_migration_error('schema_missing', plugin_schema_missing_message($name, db_driver())), DB_MIGRATION_ERROR_STATUS['schema_missing']);
    }

    try {
        db_run_schema(db(), db_driver(), (string) file_get_contents($sqlPath), $manifest['tables']);
    } catch (Throwable $e) {
        json_response(['ok' => false, 'error' => sprintf(API_TEXT['installSqlFailed'], basename($sqlPath), $e->getMessage())], 500);
    }

    $state['installed'][$name] = [
        'version' => (string) ($manifest['version'] ?? '0.0.0'),
        'installedAt' => current_iso_time(),
        'tables' => $manifest['tables'] ?? [],
    ];
}

if (!in_array($name, $state['active'], true)) {
    $state['active'][] = $name;
}

try {
    save_plugins_state($state);
} catch (Throwable $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 500);
}

json_response(['ok' => true, 'name' => $name, 'state' => load_plugins_state()]);
