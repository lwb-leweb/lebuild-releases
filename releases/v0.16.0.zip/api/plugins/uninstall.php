<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/plugins.php';
require_once __DIR__ . '/../../core/db.php';

require_admin();
require_csrf();
require_no_db_migration();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$name = (string) ($body['name'] ?? '');
if (!plugin_name_valid($name)) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidPlugin']], 400);
}

$state = load_plugins_state();
if (!isset($state['installed'][$name])) {
    json_response(['ok' => false, 'error' => API_TEXT['pluginNotInstalled']], 404);
}

$manifest = null;
try {
    $manifest = plugin_manifest($name);
} catch (Throwable $e) {
    $manifest = null;
}

if ($manifest !== null && !empty($manifest['requires']['database'])) {
    $sqlPath = plugin_sql_path($name, 'uninstall');
    try {
        if (is_file($sqlPath)) {
            db()->exec((string) file_get_contents($sqlPath));
        } else {
            // Ohne Datei für den aktiven Treiber die beim Installieren gemerkten
            // Tabellen entfernen, damit keine Daten liegen bleiben.
            $tables = plugin_valid_tables($state['installed'][$name]['tables'] ?? []);
            if ($tables) {
                db_drop_tables(db(), $tables);
            }
        }
    } catch (Throwable $e) {
        json_response(['ok' => false, 'error' => sprintf(API_TEXT['uninstallFailed'], $e->getMessage())], 500);
    }
    // SQLite gibt den Platz gelöschter Tabellen erst mit VACUUM frei. Scheitert
    // es, bleibt die Datei nur größer; die Deinstallation gilt trotzdem.
    if (db_driver() === DB_DRIVER_SQLITE) {
        try {
            db()->exec('VACUUM');
        } catch (Throwable $e) {
        }
    }
}

unset($state['installed'][$name]);
$state['active'] = array_values(array_diff($state['active'], [$name]));

try {
    save_plugins_state($state);
} catch (Throwable $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 500);
}

json_response(['ok' => true, 'name' => $name, 'state' => load_plugins_state()]);
