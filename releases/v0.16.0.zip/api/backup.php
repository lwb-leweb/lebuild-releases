<?php
declare(strict_types=1);

// Sicherungs-Abruf für das Abhol-Skript: Schlüssel statt Session, daher ohne
// CSRF. Falsche Schlüssel zählen in die Login-Sperre.

require_once __DIR__ . '/../core/siteBackup.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

// Reihenfolge: Sperre vor allem anderen, damit ein gesperrter Client nicht
// einmal erfährt, ob ein Schlüssel eingerichtet ist.
if (login_throttled()) {
    json_response(['ok' => false, 'error' => LOGIN_THROTTLED_MESSAGE], LOGIN_THROTTLED_STATUS);
}

$state = site_backup_state();
if ($state['key_hash'] === null) {
    json_response(['ok' => false, 'error' => SITE_BACKUP_NO_KEY_MESSAGE], 404);
}

// Ohne Header wurde kein Schlüssel geraten: 401, aber kein Fehlversuch.
$key = site_backup_request_key();
if ($key === null) {
    json_response(['ok' => false, 'error' => SITE_BACKUP_NO_HEADER_MESSAGE], 401);
}
if (!site_backup_key_valid($state, $key)) {
    login_record_failure();
    json_response(['ok' => false, 'error' => SITE_BACKUP_WRONG_KEY_MESSAGE], 401);
}

site_backup_require_ready();
@set_time_limit(SITE_BACKUP_TIME_LIMIT);

try {
    $prepared = site_backup_prepare();
    $fingerprint = $prepared['fingerprint'];
    $known = (string) ($_SERVER['HTTP_IF_NONE_MATCH'] ?? '');
    if ($fingerprint !== null && $known !== '' && site_backup_etag_matches($known, $fingerprint)) {
        site_backup_record_pull();
        http_response_code(304);
        header('ETag: "' . $fingerprint . '"');
        exit;
    }
    $complete = site_backup_stream(site_backup_build_zip($prepared), $fingerprint);
} catch (Throwable $e) {
    json_response(['ok' => false, 'error' => SITE_BACKUP_FAILED_MESSAGE . ': ' . $e->getMessage()], 500);
}

// Der Download ist schon beim Client; ein Fehler beim Vermerken darf ihn nicht verfälschen.
try {
    if ($complete) {
        site_backup_record_pull();
    }
} catch (Throwable $e) {
    error_log('backup: last_pull not recorded: ' . $e->getMessage());
}
