<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/updater.php';

require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}
require_csrf();

$result = updater_install();
if (empty($result['ok'])) {
    json_response(['ok' => false, 'error' => $result['error'] ?? 'Update fehlgeschlagen', 'status' => updater_status()], 500);
}

json_response([
    'ok' => true,
    'previousVersion' => $result['previousVersion'] ?? null,
    'newVersion' => $result['newVersion'] ?? null,
    'swappedPaths' => $result['swappedPaths'] ?? [],
    'status' => updater_status(),
]);
