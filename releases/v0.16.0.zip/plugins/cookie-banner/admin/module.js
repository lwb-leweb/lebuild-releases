let outletEl = null;
let ctxRef = null;
let config = null;
let services = [];

const cookieBannerModule = {
  id: 'cookie-banner',
  mount(outlet, ctx) {
    outletEl = outlet;
    ctxRef = ctx;
    renderShell();
    loadConfig();
  },
  unmount() {
    outletEl = null;
    ctxRef = null;
    config = null;
    services = [];
  }
};

export default cookieBannerModule;

function renderShell() {
  outletEl.innerHTML = `
    <section class="view-area cookie-banner-admin">
      <div class="view-card span-12">
        <div class="topbar">
          <strong>Cookie-Banner</strong>
        </div>
        <p id="cbMsg" class="message"></p>
        <div id="cbForm"></div>
      </div>
    </section>
  `;
}

function loadConfig() {
  ctxRef.api('/plugins/cookie-banner/api/get.php')
    .then(function (data) {
      config = data.config || null;
      services = data.services || [];
      renderForm();
    })
    .catch(showError);
}

function renderForm() {
  const form = document.getElementById('cbForm');
  if (!form || !config) return;

  form.innerHTML = `
    <form id="cbFormEl" class="settings-form">
      <label class="field field--checkbox">
        <span><input type="checkbox" id="cbEnabled" ${config.enabled ? 'checked' : ''}> Banner aktiv</span>
      </label>

      <h3>Texte</h3>
      ${textFields()}

      <label class="field">
        <small>Datenschutz-URL</small>
        <input type="text" id="cbPolicyUrl" value="${escapeAttr(config.policyUrl || '')}" placeholder="/datenschutz">
      </label>

      <h3>Kategorien</h3>
      <p class="message">Die Kategorie "necessary" ist immer aktiv und wird automatisch gepflegt.</p>
      <div id="cbCategories">${categoryRows()}</div>
      <button type="button" id="cbAddCat" class="secondary">Kategorie hinzufügen</button>

      <h3>Platzhalter-Texte für geblockte Embeds</h3>
      ${placeholderFields()}

      <h3>Consent-Version</h3>
      <p class="message">Aktuelle Version: <strong>${escapeHtml(String(config.version))}</strong>. Bei Änderungen an Texten oder Kategorien Version hochzählen — alle Besucher müssen dann erneut zustimmen.</p>
      <label class="field field--checkbox">
        <span><input type="checkbox" id="cbBumpVersion"> Beim Speichern Version hochzählen und neuen Consent erzwingen</span>
      </label>

      <h3>Erkannte Drittanbieter (Registry)</h3>
      <p class="message">Diese Dienste werden automatisch erkannt und geblockt, bis die Kategorie zugestimmt wird. Die Liste wird im Plugin-Code gepflegt.</p>
      ${serviceTable()}

      <div class="form-actions">
        <button type="submit">Speichern</button>
      </div>
      <p id="cbFormMsg" class="message"></p>
    </form>
  `;

  form.querySelector('#cbAddCat').addEventListener('click', addCategory);
  form.querySelector('#cbFormEl').addEventListener('submit', onSubmit);
  bindCategoryEvents();
}

function textFields() {
  const fields = [
    ['title', 'Titel'],
    ['intro', 'Einleitungstext'],
    ['accept', 'Button: Alle akzeptieren'],
    ['reject', 'Button: Ablehnen'],
    ['settings', 'Button: Einstellungen'],
    ['save', 'Button: Auswahl speichern'],
    ['policyLink', 'Link-Text Datenschutz'],
  ];
  return fields.map(function (entry) {
    const key = entry[0];
    const label = entry[1];
    const value = (config.texts && config.texts[key]) || '';
    if (key === 'intro') {
      return `<label class="field"><small>${escapeHtml(label)}</small><textarea data-cb-text="${escapeAttr(key)}" rows="3">${escapeHtml(value)}</textarea></label>`;
    }
    return `<label class="field"><small>${escapeHtml(label)}</small><input type="text" data-cb-text="${escapeAttr(key)}" value="${escapeAttr(value)}"></label>`;
  }).join('');
}

function categoryRows() {
  return (config.categories || []).map(function (cat, index) {
    const isNecessary = cat.id === 'necessary';
    return `
      <div class="cb-cat-row" data-index="${index}" style="display:grid;grid-template-columns:1fr 1fr auto auto;gap:var(--le-space-2);align-items:center;margin:var(--le-space-2) 0;">
        <input type="text" data-cb-cat-id placeholder="id (kebab)" value="${escapeAttr(cat.id || '')}" ${isNecessary ? 'readonly' : ''}>
        <input type="text" data-cb-cat-label placeholder="Label" value="${escapeAttr(cat.label || '')}">
        <label><input type="checkbox" data-cb-cat-required ${cat.required ? 'checked' : ''} ${isNecessary ? 'disabled' : ''}> erforderlich</label>
        <button type="button" data-cb-cat-remove class="secondary" ${isNecessary ? 'disabled' : ''}>Entfernen</button>
      </div>
    `;
  }).join('');
}

function bindCategoryEvents() {
  const wrap = document.getElementById('cbCategories');
  if (!wrap) return;
  wrap.querySelectorAll('[data-cb-cat-remove]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const row = btn.closest('.cb-cat-row');
      if (!row) return;
      const index = parseInt(row.dataset.index, 10);
      config.categories.splice(index, 1);
      document.getElementById('cbCategories').innerHTML = categoryRows();
      bindCategoryEvents();
    });
  });
}

function addCategory() {
  config = readForm();
  config.categories.push({ id: '', label: '', required: false });
  renderForm();
}

function placeholderFields() {
  const placeholders = config.placeholder || {};
  const keys = Object.keys(placeholders);
  if (keys.indexOf('default') === -1) keys.unshift('default');
  if (keys.indexOf('youtube') === -1) keys.push('youtube');
  if (keys.indexOf('maps') === -1) keys.push('maps');
  return keys.map(function (key) {
    return `<label class="field"><small>${escapeHtml(key)}</small><input type="text" data-cb-placeholder="${escapeAttr(key)}" value="${escapeAttr(placeholders[key] || '')}"></label>`;
  }).join('');
}

function serviceTable() {
  if (!services.length) return '<p class="message">Keine Dienste registriert.</p>';
  return `<table class="cb-services" style="width:100%;border-collapse:collapse;font-size:var(--le-fs-klein);">
    <thead><tr><th style="text-align:left;padding:var(--le-space-1);">Service</th><th style="text-align:left;padding:var(--le-space-1);">Kategorie</th><th style="text-align:left;padding:var(--le-space-1);">Typ</th><th style="text-align:left;padding:var(--le-space-1);">Hosts</th></tr></thead>
    <tbody>${services.map(function (svc) {
      return `<tr>
        <td style="padding:var(--le-space-1);border-top:var(--le-line) solid var(--le-border);">${escapeHtml(svc.key)}</td>
        <td style="padding:var(--le-space-1);border-top:var(--le-line) solid var(--le-border);">${escapeHtml(svc.category)}</td>
        <td style="padding:var(--le-space-1);border-top:var(--le-line) solid var(--le-border);">${escapeHtml(svc.type)}</td>
        <td style="padding:var(--le-space-1);border-top:var(--le-line) solid var(--le-border);">${escapeHtml((svc.hosts || []).join(', '))}</td>
      </tr>`;
    }).join('')}</tbody>
  </table>`;
}

function readForm() {
  const enabled = document.getElementById('cbEnabled').checked;
  const policyUrl = document.getElementById('cbPolicyUrl').value;
  const texts = {};
  document.querySelectorAll('[data-cb-text]').forEach(function (input) {
    texts[input.getAttribute('data-cb-text')] = input.value;
  });
  const placeholder = {};
  document.querySelectorAll('[data-cb-placeholder]').forEach(function (input) {
    placeholder[input.getAttribute('data-cb-placeholder')] = input.value;
  });
  const categories = [];
  document.querySelectorAll('.cb-cat-row').forEach(function (row) {
    categories.push({
      id: row.querySelector('[data-cb-cat-id]').value.trim(),
      label: row.querySelector('[data-cb-cat-label]').value.trim(),
      required: row.querySelector('[data-cb-cat-required]').checked,
    });
  });
  return {
    enabled: enabled,
    version: config ? config.version : 1,
    texts: texts,
    policyUrl: policyUrl,
    categories: categories,
    placeholder: placeholder,
  };
}

function onSubmit(event) {
  event.preventDefault();
  const next = readForm();
  const bumpVersion = document.getElementById('cbBumpVersion').checked;
  const payload = { config: next, bumpVersion: bumpVersion };

  ctxRef.api('/plugins/cookie-banner/api/save.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  }).then(function (data) {
    config = data.config || next;
    renderForm();
    const msg = document.getElementById('cbFormMsg');
    if (msg) msg.textContent = 'Gespeichert.';
  }).catch(function (error) {
    const msg = document.getElementById('cbFormMsg');
    if (msg) msg.textContent = error.message || String(error);
  });
}

function showError(error) {
  const msg = document.getElementById('cbMsg');
  if (msg) msg.textContent = error.message || String(error);
}

function escapeHtml(value) {
  return String(value == null ? '' : value).replace(/[&<>"']/g, function (char) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
  });
}

function escapeAttr(value) {
  return escapeHtml(value);
}
