let outletEl = null;
let ctxRef = null;
let currentSchema = [];
// Beitrag ohne Datum: ist sofort öffentlich (blog_fetch_list zeigt published IS NULL).
const NO_DATE_TEXT = 'ohne Datum, sichtbar';

const blogModule = {
  id: 'blog',
  mount(outlet, ctx) {
    outletEl = outlet;
    ctxRef = ctx;
    renderShell();
    loadList();
  },
  unmount() {
    if (ctxRef && ctxRef.ui && ctxRef.ui.closeModal) ctxRef.ui.closeModal();
    outletEl = null;
    ctxRef = null;
    currentSchema = [];
  }
};

export default blogModule;

function renderShell() {
  outletEl.innerHTML = `
    <section class="view-area blog-admin">
      <div class="view-card span-12">
        <div class="topbar">
          <strong>Blog</strong>
          <button type="button" id="blogNewBtn">Neuen Post anlegen</button>
        </div>
        <p id="blogMsg" class="message"></p>
        <div id="blogList" class="generic-list"></div>
      </div>
    </section>
  `;
  document.getElementById('blogNewBtn').addEventListener('click', function () {
    openForm(null);
  });
}

function loadList() {
  ctxRef.api('/plugins/blog/api/list.php?admin=1')
    .then(function (data) {
      currentSchema = data.schema || [];
      renderList(data.rows || []);
    })
    .catch(showError);
}

function renderList(posts) {
  const list = document.getElementById('blogList');
  if (!posts.length) {
    list.innerHTML = '<p class="message">Noch keine Posts.</p>';
    return;
  }
  list.innerHTML = '<ul>' + posts.map(function (post) {
    return `
      <li class="generic-list__row" data-id="${post.id}">
        <span class="generic-list__title">
          <strong>${escapeHtml(post.title)}</strong>
          <small>${escapeHtml(post.published || NO_DATE_TEXT)}</small>
        </span>
        <div class="generic-list__actions">
          <button type="button" data-action="edit" data-id="${post.id}">Bearbeiten</button>
          <button type="button" data-action="delete" data-id="${post.id}" class="secondary">Löschen</button>
        </div>
      </li>
    `;
  }).join('') + '</ul>';

  list.querySelectorAll('button[data-action="edit"]').forEach(function (button) {
    button.addEventListener('click', function () {
      ctxRef.api('/plugins/blog/api/get.php?id=' + parseInt(button.dataset.id, 10))
        .then(function (data) {
          currentSchema = data.schema || currentSchema;
          openForm(data.row);
        })
        .catch(showError);
    });
  });
  list.querySelectorAll('button[data-action="delete"]').forEach(function (button) {
    button.addEventListener('click', function () {
      const id = parseInt(button.dataset.id, 10);
      const post = posts.find(function (entry) { return Number(entry.id) === id; });
      if (!ctxRef.confirm(ctxRef.ui.deleteQuestion(currentSchema, post))) return;
      ctxRef.api('/plugins/blog/api/delete.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: id })
      }).then(loadList).catch(showError);
    });
  });
}

// Formular aus schema.fields (plugin.json), wie auf der Website.
function openForm(post) {
  ctxRef.ui.openEntryForm({
    schema: currentSchema,
    row: post,
    save: function (data) {
      const body = { data: data };
      if (post && post.id) body.id = post.id;
      return ctxRef.api('/plugins/blog/api/save.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
    },
    onSaved: loadList
  });
}

function showError(error) {
  const message = document.getElementById('blogMsg');
  if (message) message.textContent = error.message || String(error);
}

function escapeHtml(value) {
  return String(value || '').replace(/[&<>"']/g, function (char) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
  });
}
