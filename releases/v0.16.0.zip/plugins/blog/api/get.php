<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../lib.php';

require_plugin_active('blog');

$slug = trim((string) ($_GET['slug'] ?? ''));
$id = (int) ($_GET['id'] ?? 0);

if ($id > 0) {
    // Laden zum Bearbeiten (Backend, inlineEdit): Antwort wie bei den anderen Plugins.
    require_auth();
    $post = blog_fetch_by_id($id);
    if (!$post) {
        json_response(['ok' => false, 'error' => API_TEXT['notFound']], 404);
    }
    json_response(['ok' => true, 'row' => $post, 'schema' => blog_schema_columns()]);
}

$post = $slug !== '' ? blog_fetch_by_slug($slug, true) : null;
if (!$post) {
    json_response(['ok' => false, 'error' => API_TEXT['notFound']], 404);
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok' => true, 'post' => $post], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
