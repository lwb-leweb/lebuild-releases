<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../lib.php';

require_plugin_active('blog');

$admin = !empty($_GET['admin']);
if ($admin) {
    require_auth();
}

// Admin-Abruf (Backend, inlineEdit): Antwort wie bei den anderen Plugins (rows, schema), ohne Kappung auf 10.
$limit = (int) ($_GET['limit'] ?? ($admin ? BLOG_LIST_LIMIT_MAX : 10));
$posts = blog_fetch_list($limit, !$admin);

if ($admin) {
    json_response(['ok' => true, 'rows' => $posts, 'schema' => blog_schema_columns()]);
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok' => true, 'posts' => $posts], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
