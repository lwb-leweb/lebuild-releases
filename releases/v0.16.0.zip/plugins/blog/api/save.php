<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../lib.php';

require_auth();
require_csrf();
require_plugin_active('blog');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
try {
    $id = blog_save(is_array($body['data'] ?? null) ? $body['data'] : [], isset($body['id']) ? (int) $body['id'] : null);
} catch (InvalidArgumentException $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 400);
} catch (Throwable $e) {
    // z. B. zu lange Werte (Spaltenlänge); ohne Datenbank-Meldung.
    plugin_failure_response('save', $e);
}

json_response(['ok' => true, 'id' => $id]);
