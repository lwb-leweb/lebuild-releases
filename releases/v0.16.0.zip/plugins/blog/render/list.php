<?php
require_once __DIR__ . '/../lib.php';

$limit = (int) ($attrs['limit'] ?? 10);
$posts = blog_fetch_list($limit, true);
?>
<ul class="blog-list" <?= le_list_attrs('blog', BLOG_LIST_TYPE) ?>>
  <?php foreach ($posts as $post): ?>
    <li class="blog-list__item" <?= le_item_attrs((int) $post['id']) ?>>
      <?php if (!empty($post['image'])): ?>
        <img src="<?= htmlspecialchars($post['image']) ?>" alt="">
      <?php endif ?>
      <h3>
        <a href="/blog-post.html?slug=<?= htmlspecialchars(urlencode($post['slug'])) ?>">
          <?= htmlspecialchars($post['title']) ?>
        </a>
      </h3>
      <?php if (!empty($post['published'])): ?>
        <time><?= htmlspecialchars($post['published']) ?></time>
      <?php endif ?>
    </li>
  <?php endforeach ?>
</ul>
