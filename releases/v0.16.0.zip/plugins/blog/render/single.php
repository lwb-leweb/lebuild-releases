<?php
require_once __DIR__ . '/../lib.php';

$slug = (string) ($attrs['slug'] ?? ($_GET['slug'] ?? ''));
$post = $slug !== '' ? blog_fetch_by_slug($slug, true) : null;

if (!$post) {
    echo '<p>Beitrag nicht gefunden.</p>';
    return;
}
?>
<article class="blog-post" <?= le_single_attrs('blog', BLOG_LIST_TYPE, (int) $post['id']) ?>>
  <h1><?= htmlspecialchars($post['title']) ?></h1>
  <?php if (!empty($post['image'])): ?>
    <img src="<?= htmlspecialchars($post['image']) ?>" alt="">
  <?php endif ?>
  <?php if (!empty($post['published'])): ?>
    <time><?= htmlspecialchars($post['published']) ?></time>
  <?php endif ?>
  <div class="blog-post__body">
    <?= plugin_sanitize_richtext((string) ($post['body'] ?? '')) ?>
  </div>
</article>
