<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/db.php';
require_once __DIR__ . '/../../core/plugins.php';
require_once __DIR__ . '/../../core/pluginSchema.php';
require_once __DIR__ . '/../../core/uploads.php';

// Typ im data-le-list der Blog-Liste und der Einzelansicht („blog/posts“).
const BLOG_LIST_TYPE = 'posts';
// Höchstzahl Beiträge je Abruf; das Backend und inlineEdit holen ohne limit so viele.
const BLOG_LIST_LIMIT_MAX = 100;

/** Felder aus plugin.json (schema.fields), z. B. für Formulare und Bildfelder. */
function blog_schema_columns(): array
{
    return plugin_schema_columns(plugin_manifest('blog'));
}

function blog_fetch_list(int $limit = 10, bool $publicOnly = true): array
{
    $limit = max(1, min(BLOG_LIST_LIMIT_MAX, $limit));
    $where = $publicOnly ? 'WHERE published IS NULL OR published <= ?' : '';
    $stmt = db()->prepare(
        "SELECT id, title, slug, image, published FROM blog_posts {$where} ORDER BY COALESCE(published, created_at) DESC LIMIT {$limit}"
    );
    $stmt->execute($publicOnly ? [db_now()] : []);

    return $stmt->fetchAll();
}

function blog_fetch_by_slug(string $slug, bool $publicOnly = true): ?array
{
    $where = $publicOnly ? ' AND (published IS NULL OR published <= ?)' : '';
    $stmt = db()->prepare("SELECT * FROM blog_posts WHERE slug = ?{$where} LIMIT 1");
    $stmt->execute($publicOnly ? [$slug, db_now()] : [$slug]);
    $row = $stmt->fetch();

    return $row ?: null;
}

function blog_fetch_by_id(int $id): ?array
{
    $stmt = db()->prepare('SELECT * FROM blog_posts WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);
    $row = $stmt->fetch();

    return $row ?: null;
}

function blog_save(array $data, ?int $id = null): int
{
    // Felder nach schema.fields (eine Regel mit Content-Typen und generischen Plugins): fehlende
    // gelten als leer, ein leerer Slug kommt aus dem Titel und wird eindeutig gemacht.
    $fields = blog_schema_columns();
    $stored = $id !== null && $id > 0 ? blog_fetch_by_id($id) : null;
    $values = plugin_schema_values($fields, $data + array_fill_keys(array_column($fields, 'name'), ''), $stored ?? []);
    $values['slug'] = plugin_unique_slug('blog_posts', 'slug', $values['slug'], $id);
    $values['image'] = $values['image'] !== '' ? $values['image'] : null;

    $now = db_now();
    if ($id !== null && $id > 0) {
        $stmt = db()->prepare('UPDATE blog_posts SET title = ?, slug = ?, image = ?, body = ?, published = ?, updated_at = ? WHERE id = ?');
        $stmt->execute([$values['title'], $values['slug'], $values['image'], $values['body'], $values['published'], $now, $id]);

        return $id;
    }

    $stmt = db()->prepare('INSERT INTO blog_posts (title, slug, image, body, published, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([$values['title'], $values['slug'], $values['image'], $values['body'], $values['published'], $now, $now]);

    return (int) db()->lastInsertId();
}

/** Löscht den Beitrag samt Bild, sofern es sonst nirgends verwendet wird (core/uploads.php). */
function blog_delete(int $id): void
{
    plugin_delete_entry('blog', $id);
}
