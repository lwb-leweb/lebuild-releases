# Blog Plugin

Blog-Posts mit Titel, Slug, Bild, Richtext-Body und Veröffentlichungsdatum. Unterstützt terminierte Posts (Zukunftsdatum) und Live-Posts. Rendering via Shortcode oder PHP-Direktzugriff.

## Aktivierung

1. Im Admin auf "Plugins" → "Blog" → aktivieren
2. Beim Aktivieren wird die Tabelle `blog_posts` angelegt
3. Sidebar-Eintrag "Blog" erscheint → Einträge anlegen, bearbeiten, löschen

## Was es kann

- Blog-Posts anlegen mit Titel, Slug (auto-generiert aus Titel), Bild, Richtext-Body, Veröffentlichungsdatum
- Post ohne Datum ist sofort öffentlich sichtbar
- Terminierung: Post mit Zukunftsdatum = wird erst dann öffentlich
- Listen-Shortcode für Übersichtsseite
- Single-Shortcode für Detailseite (by URL-Slug)
- PHP-Direktzugriff für eigenes Rendering

## Im Admin verwenden

**Post anlegen:** Sidebar → "Blog" → "Neuer Eintrag" → Felder ausfüllen → "Speichern"

**Veröffentlichen:** Datum setzen → Post erscheint sobald Datum erreicht ist

**Bearbeiten:** In der Liste → "Bearbeiten" → ändern → "Speichern"

**Löschen:** In der Liste → "Löschen" → bestätigen. Das Bild wird mit gelöscht, wenn es sonst nirgends verwendet wird.

**Auf der Website:** Angemeldete sehen an der Liste "+ Hinzufügen" und an jedem Beitrag "Bearbeiten" und "Löschen" (Formular aus dem Schema, wie im Admin); in der Einzelansicht "Bearbeiten". Ändert sich der Slug, stimmt die URL der Einzelansicht nicht mehr.

## API-Endpoints

Alle Endpoints unter `/plugins/blog/api/`. Auth: gültige Admin-Session. Schreib-Endpoints zusätzlich mit CSRF-Token.

| Endpoint | Methode | Auth | Parameter | Response |
|---|---|---|---|---|
| `list.php` | GET | öffentlich | `?limit=<n>` (default 10) | `{ok, posts[]}` |
| `list.php` | GET | Session | `?admin=1&limit=<n>` | `{ok, rows[], schema}` (auch Beiträge mit Zukunftsdatum) |
| `get.php` | GET | öffentlich | `?slug=<slug>` | `{ok, post}` oder 404 |
| `get.php` | GET | Session | `?id=<int>` | `{ok, row, schema}` oder 404 |
| `save.php` | POST | Session + CSRF | JSON-Body `{data: {title, slug?, image?, body?, published?}, id?}` | `{ok, id}`; leerer Slug kommt aus dem Titel und wird eindeutig (-2, -3), Pflichtfelder mit deutscher Meldung (400) |
| `delete.php` | POST | Session + CSRF | JSON-Body `{id}` | `{ok}` |

**Beispiel — Post erstellen:**

```bash
curl -X POST https://example.com/plugins/blog/api/save.php \
  -H "Content-Type: application/json" \
  -H "X-CSRF-Token: <token>" \
  -b "session=..." \
  -d '{"data":{"title":"Mein erster Post","body":"<p>Hallo Welt.</p>","published":"2026-05-21 09:00:00"}}'
```

## Shortcodes

### `list` — Post-Liste

```html
<div data-plugin="blog" data-view="list" data-limit="10"></div>
```

| Attribut | Type | Default | Beschreibung |
|---|---|---|---|
| `data-limit` | int | 10 | Max. Anzahl Posts |

Zeigt nur veröffentlichte Posts (`published` leer oder nicht nach der aktuellen PHP-Zeit `db_now()`).

**Output:**

```html
<ul class="blog-list" data-le-list="blog/posts">
  <li class="blog-list__item" data-le-item="<id>">
    <img src="..." alt="">
    <h3><a href="/blog-post.html?slug=<slug>">Titel</a></h3>
    <time>2026-05-21 09:00:00</time>
  </li>
</ul>
```

### `single` — Einzelner Post

```html
<div data-plugin="blog" data-view="single" data-slug="mein-post"></div>
```

Liest `data-slug` aus dem Attribut, fallback auf `$_GET['slug']`. Zeigt "Beitrag nicht gefunden." wenn kein Match.

**Output:**

```html
<article class="blog-post" data-le-single="blog/posts" data-le-item="<id>">
  <h1>Titel</h1>
  <img src="..." alt="">
  <time>...</time>
  <div class="blog-post__body">...sanitized HTML...</div>
</article>
```

## Frontend einbinden

### Shortcode (HTML)

Übersichtsseite `public/site/blog.html`:

```html
<div data-plugin="blog" data-view="list" data-limit="10"></div>
```

Detailseite `public/site/blog-post.html`:

```html
<div data-plugin="blog" data-view="single"></div>
```

Slug wird per `?slug=mein-post` als GET-Parameter übergeben.

### PHP-Direktzugriff

Für eigenes Rendering oder wenn nur bestimmte Felder gebraucht werden:

```php
// Liste der neuesten Posts
$posts = blog_public_list(10);

// Einzelner Post by Slug
$post = blog_public_get('mein-post');
```

`public.php` wird vom Site-Header automatisch geladen — kein `require_once` nötig.

Gibt `[]` bzw. `null` zurück wenn das Plugin inaktiv ist — kein Crash.

## Datenbank

**Tabelle `blog_posts`:**

| Spalte | Typ | Beschreibung |
|---|---|---|
| `id` | `INT UNSIGNED AUTO_INCREMENT PK` | — |
| `title` | `VARCHAR(255) NOT NULL` | Titel |
| `slug` | `VARCHAR(255) NOT NULL UNIQUE` | URL-Slug |
| `image` | `VARCHAR(255)` | Pfad oder leer |
| `body` | `MEDIUMTEXT` | Sanitized HTML |
| `published` | `DATETIME` | `NULL` = sofort sichtbar |
| `created_at` | `DATETIME` | Setzt `blog_save()` beim Anlegen |
| `updated_at` | `DATETIME` | Setzt `blog_save()` bei jeder Änderung |

Standard ist SQLite (`install.sqlite.sql`, Datei `content/data/site.sqlite`): dort sind die Spalten `TEXT` mit `CHECK (length(...) <= 255)` für `title`, `slug`, `image`. Mit MySQL-Zugangsdaten gilt `install.sql`.

## Bekannte Einschränkungen

- Das Admin-Formular kommt aus `schema.fields` in `plugin.json`; die Liste auf der Website hat keine Sortierung (Reihenfolge nach Datum)
- Keine Kategorien oder Tags
- Keine Pagination im Shortcode — nur `limit`

## Changelog

- **2026-10-15** — Beiträge sind auf der Website bearbeitbar: `inlineEdit` in `plugin.json`, Markierungen `data-le-list`/`data-le-item` (Liste) und `data-le-single` (Einzelansicht). `get.php?id=` antwortet `{row, schema}`, `list.php?admin=1` mit `rows` und `schema`. Formular im Admin aus dem Schema mit Beschriftungen; leerer Slug wird aus dem Titel gebildet und eindeutig (Umlaute: ae/oe/ue), Pflichtfelder melden sich deutsch, Datenbankfehler nie im Wortlaut. Löschen entfernt das Bild, wenn es sonst nirgends verwendet wird. Save-Body trägt die Felder unter `data`.
- **2026-10-13** — SQLite als Standard-Datenbank: `install.sqlite.sql`/`uninstall.sqlite.sql`, Veröffentlichung wird mit der PHP-Zeit statt `NOW()` verglichen, `created_at`/`updated_at` setzt `blog_save()` (kein `ON UPDATE` mehr). Doku: Posts ohne Datum sind sichtbar (es gab nie einen Entwurfsmodus).
- **2026-05-21 — v1.0.0** — Erstes Release: Tabelle `blog_posts`, `lib.php` (fetch_list, fetch_by_slug, save, delete), 4 CRUD-API-Endpoints, Admin-Modul mit Slug-Generator, List- und Single-Shortcode, `public.php` für PHP-Direktzugriff, AGENT.md, README.md.
