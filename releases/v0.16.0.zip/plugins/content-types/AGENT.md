# Content-Types Plugin — Anleitung für KI-Agenten

Dieses Plugin verwaltet kundenspezifische Content-Typen. Wenn der User dich bittet, einen neuen Content-Typ anzulegen, folge dieser Anleitung exakt.

## Was du tust

Du legst **eine JSON-Datei** unter `content/plugins/content-types/<typname>.json` an. Sonst nichts.

**Du fasst NICHT an:**

- `plugins/content-types/lib.php` oder andere PHP-Dateien
- `plugins/content-types/install.sql`, `install.sqlite.sql` (und die uninstall-Dateien)
- Die DB direkt
- Andere Plugins

## Workflow

1. User nennt dir Typ-Namen + gewünschte Felder
2. Schau in `plugins/content-types/presets/` nach einer passenden Vorlage
3. Wenn eine passt: kopiere sie nach `content/plugins/content-types/<name>.json` und passe sie an
4. Wenn keine passt: lege eine neue JSON-Datei nach unten stehendem Schema an

## Datei-Schema

```json
{
  "name": "<typname>",
  "label": "<Lesbarer Name>",
  "fields": [
    { "name": "<feldname>", "label": "<Label>", "type": "<typ>", "required": <true|false> }
  ]
}
```

### Regeln für `name`

- **Datei-Name** = `<name>.json` — beide müssen exakt gleich sein
- Erlaubte Zeichen: kleinbuchstaben, Ziffern, `-`, `_`
- Muss mit einem Buchstaben anfangen
- Beispiele: `referenzen`, `leistungen`, `fakten`, `case-studies`

### Regeln für `fields[].name`

- Erlaubte Zeichen: kleinbuchstaben, Ziffern, `_` (KEIN Bindestrich)
- Muss mit einem Buchstaben anfangen
- Beispiele: `title`, `kunde`, `logo_url`, `published_at`

### Verfügbare Feld-Typen

| Type | Verwendung | Input-Render |
|------|------------|--------------|
| `text` | Kurzer Text | `<input type="text">` |
| `richtext` | HTML-Editor (eingeschränkt, sicher) | `<textarea>` |
| `image` | Pfad zu einem Bild in `/public/uploads/...` | `<input type="text">` mit Placeholder |
| `datetime` | Datum + Uhrzeit | `<input type="datetime-local">` |
| `number` | Zahl | `<input type="number">` |
| `boolean` | Ja/Nein | `<input type="checkbox">` |
| `slug` | URL-Slug, aus anderem Feld generiert via `from` | `<input type="text">` |
| `select` | Auswahl aus festen Werten (Pflicht-Attribut: `options: [...]`) | `<select>` |

### `required: true`

Optional. Wenn `true`, blockiert das Speichern wenn der Wert leer ist.

## Beispiel: Neuen Typ "Standorte" anlegen

User sagt: "Leg mir einen Content-Typ 'Standorte' an, mit Stadt, Adresse, Telefonnummer und einem Bild."

Du schreibst `content/plugins/content-types/standorte.json`:

```json
{
  "name": "standorte",
  "label": "Standorte",
  "fields": [
    { "name": "city", "label": "Stadt", "type": "text", "required": true },
    { "name": "address", "label": "Adresse", "type": "text" },
    { "name": "phone", "label": "Telefon", "type": "text" },
    { "name": "image", "label": "Bild", "type": "image" }
  ]
}
```

Mehr brauchst du nicht. Beim nächsten Admin-Login erscheint "Standorte" als Sidebar-Eintrag und der Kunde kann Einträge anlegen.

## Aktivierung im Frontend

**Via Shortcode** (Standard-Rendering, kein PHP nötig):

```html
<div data-plugin="content-types" data-view="list" data-type="standorte" data-limit="20"></div>
```

**Via PHP-Direktzugriff** (eigenes Rendering, volle Datenkontrolle):

```php
$eintraege = content_types_public_list('standorte', 20);
$einzeln   = content_types_public_get('standorte', $id);
```

`public.php` ist sicher require_once-bar — gibt `[]` / `null` zurück wenn das Plugin inaktiv ist, statt zu crashen. Nur verwenden wenn eigenes Markup oder eigene Datenverarbeitung nötig ist; sonst Shortcode bevorzugen.

Das macht der User selber oder du, wenn er dich explizit darum bittet. **Keine** URL-Routen pro Eintrag — Detail-Seiten sind statisch, falls überhaupt nötig.

## Wenn der User ein Preset will

Wenn der User sagt "nimm das Standard-Leistungen-Preset", dann:

1. Lies `plugins/content-types/presets/leistungen.json`
2. Schreib exakt den gleichen Inhalt nach `content/plugins/content-types/leistungen.json`
3. Frag NICHT nach — der User hat schon "Standard" gesagt

Wenn der User Abweichungen will ("Leistungen, aber mit zusätzlichem Feld 'Preis'"), dann lade das Preset, pass die `fields`-Liste an und speichere.

## Fehlervermeidung

- Datei-Name und `name`-Feld müssen identisch sein (vor `.json`)
- `fields` darf nicht leer sein
- JSON muss valide sein — kein trailing comma, korrekte Quotes
- Wenn du dir unsicher bist welche Feldtypen passen, frag den User
