let outletEl = null;
let ctxRef = null;
let currentType = '';
let currentLabel = '';
let currentSchema = [];

const contentTypesModule = {
  id: 'content-types',
  mount(outlet, ctx) {
    outletEl = outlet;
    ctxRef = ctx;
    currentType = ctx.subRoute || '';
    if (!currentType) {
      outlet.innerHTML = '<section class="view-area"><div class="view-card"><p class="message">Kein Content-Typ ausgewählt.</p></div></section>';
      return;
    }
    renderShell();
    loadList();
  },
  unmount() {
    if (ctxRef && ctxRef.ui && ctxRef.ui.closeModal) ctxRef.ui.closeModal();
    outletEl = null;
    ctxRef = null;
    currentType = '';
    currentLabel = '';
    currentSchema = [];
  }
};

export default contentTypesModule;

function renderShell() {
  outletEl.innerHTML = `
    <section class="view-area content-types-admin">
      <div class="view-card span-12">
        <div class="topbar">
          <strong id="ctTitle">${escapeHtml(currentType)}</strong>
          <button type="button" id="ctNewBtn">Neuer Eintrag</button>
        </div>
        <p id="ctMsg" class="message"></p>
        <div id="ctList" class="generic-list"></div>
      </div>
    </section>
  `;
  outletEl.querySelector('#ctNewBtn').addEventListener('click', function () {
    openForm(null);
  });
}

function loadList() {
  ctxRef.api('/plugins/content-types/api/list.php?type=' + encodeURIComponent(currentType))
    .then(function (data) {
      currentLabel = data.label || currentType;
      currentSchema = data.schema || [];
      const titleEl = document.getElementById('ctTitle');
      if (titleEl) titleEl.textContent = currentLabel;
      renderList(data.rows || []);
    })
    .catch(showError);
}

function renderList(rows) {
  const list = document.getElementById('ctList');
  if (!list) return;

  if (!rows.length) {
    list.innerHTML = '<p class="message">Noch keine Einträge.</p>';
    return;
  }

  list.innerHTML = '<ul>' + rows.map(function (row) {
    const title = ctxRef.ui.entryTitle(currentSchema, row);
    return `
      <li class="generic-list__row" data-id="${row.id}">
        <span class="generic-list__title">${escapeHtml(title)}</span>
        <div class="generic-list__actions">
          <button type="button" data-action="edit" data-id="${row.id}">Bearbeiten</button>
          <button type="button" data-action="delete" data-id="${row.id}" class="secondary">Löschen</button>
        </div>
      </li>
    `;
  }).join('') + '</ul>';

  list.querySelectorAll('button[data-action="edit"]').forEach(function (button) {
    button.addEventListener('click', function () {
      openFormFromServer(parseInt(button.dataset.id, 10));
    });
  });
  list.querySelectorAll('button[data-action="delete"]').forEach(function (button) {
    button.addEventListener('click', function () {
      const id = parseInt(button.dataset.id, 10);
      const row = rows.find(function (entry) { return Number(entry.id) === id; });
      if (!ctxRef.confirm(ctxRef.ui.deleteQuestion(currentSchema, row))) return;
      ctxRef.api('/plugins/content-types/api/delete.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: currentType, id: id })
      }).then(loadList).catch(showError);
    });
  });
}

function openFormFromServer(id) {
  ctxRef.api('/plugins/content-types/api/get.php?type=' + encodeURIComponent(currentType) + '&id=' + id)
    .then(function (data) {
      currentSchema = data.schema || currentSchema;
      openForm(data.row || null);
    })
    .catch(showError);
}

function openForm(row) {
  ctxRef.ui.openEntryForm({
    schema: currentSchema,
    row: row,
    save: function (data) {
      const body = { type: currentType, data: data };
      if (row && row.id) body.id = row.id;
      return ctxRef.api('/plugins/content-types/api/save.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
    },
    onSaved: loadList
  });
}

function showError(error) {
  const msg = document.getElementById('ctMsg');
  if (msg) msg.textContent = error.message || String(error);
}

function escapeHtml(value) {
  return String(value || '').replace(/[&<>"']/g, function (char) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
  });
}
