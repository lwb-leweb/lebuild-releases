<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../lib.php';

require_auth();
require_csrf();
require_plugin_active('content-types');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$type = (string) ($body['type'] ?? '');
if (!content_types_name_valid($type)) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidType']], 400);
}

$rawValues = is_array($body['data'] ?? null) ? $body['data'] : [];
$id = isset($body['id']) ? (int) $body['id'] : null;

try {
    $newId = content_types_save($type, $rawValues, $id);
} catch (InvalidArgumentException $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 400);
} catch (Throwable $e) {
    plugin_failure_response('save', $e);
}

json_response(['ok' => true, 'id' => $newId]);
