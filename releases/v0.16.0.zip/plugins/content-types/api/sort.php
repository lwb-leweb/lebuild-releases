<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../../../core/pluginSchema.php';
require_once __DIR__ . '/../lib.php';

require_auth();
require_csrf();
require_plugin_active('content-types');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$type = (string) ($body['type'] ?? '');
$id = (int) ($body['id'] ?? 0);
$direction = (string) ($body['direction'] ?? '');
if (!content_types_name_valid($type) || $id <= 0 || !isset(CONTENT_TYPES_SORT_STEPS[$direction])) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidRequest']], 400);
}

try {
    $moved = content_types_move($type, $id, CONTENT_TYPES_SORT_STEPS[$direction]);
} catch (Throwable $e) {
    plugin_failure_response('sort', $e);
}

json_response(['ok' => true, 'moved' => $moved]);
