<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/db.php';
require_once __DIR__ . '/../../core/plugins.php';
require_once __DIR__ . '/../../core/pluginSchema.php';
require_once __DIR__ . '/../../core/uploads.php';

// Reihenfolge der Einträge eines Typs; vor dem ersten Sortieren haben alle sort_order 0.
const CONTENT_TYPES_ORDER = 'sort_order ASC, id DESC';
// Sortieren (↑/↓): Richtung → Schritt in der Liste.
const CONTENT_TYPES_SORT_STEPS = [INLINE_EDIT_SORT_UP => -1, INLINE_EDIT_SORT_DOWN => 1];

function content_types_dir(): string
{
    return plugin_data_path('content-types');
}

function content_types_name_valid(string $name): bool
{
    return (bool) preg_match('/^[a-z][a-z0-9_-]*$/', $name);
}

function content_types_list_names(): array
{
    $dir = content_types_dir();
    if (!is_dir($dir)) {
        return [];
    }

    $names = [];
    foreach (scandir($dir) ?: [] as $entry) {
        if (!is_string($entry) || !str_ends_with($entry, '.json')) {
            continue;
        }
        $name = substr($entry, 0, -5);
        if (!content_types_name_valid($name)) {
            continue;
        }
        if (!is_file($dir . '/' . $entry)) {
            continue;
        }
        $names[] = $name;
    }
    sort($names);

    return $names;
}

function content_types_load(string $name): array
{
    if (!content_types_name_valid($name)) {
        throw new InvalidArgumentException(API_TEXT['invalidType']);
    }
    $path = content_types_dir() . '/' . $name . '.json';
    if (!is_file($path)) {
        throw new RuntimeException('Content-type not found: ' . $name);
    }

    $data = json_decode((string) file_get_contents($path), true);
    if (!is_array($data)) {
        throw new RuntimeException('Invalid JSON for content-type: ' . $name);
    }
    if (($data['name'] ?? '') !== $name) {
        throw new RuntimeException('Content-type name mismatch: ' . $name);
    }
    if (!is_string($data['label'] ?? null) || trim($data['label']) === '') {
        throw new RuntimeException('Content-type missing label: ' . $name);
    }
    if (!is_array($data['fields'] ?? null) || empty($data['fields'])) {
        throw new RuntimeException('Content-type has no fields: ' . $name);
    }

    return $data;
}

function content_types_admin_sidebar_entries(): array
{
    $entries = [];
    foreach (content_types_list_names() as $name) {
        try {
            $def = content_types_load($name);
        } catch (Throwable $e) {
            continue;
        }
        $entries[] = [
            'name' => 'content-types',
            'route' => 'content-types/' . $name,
            'label' => (string) $def['label'],
            'hasAdminModule' => true,
            'hasSchema' => true,
            'type' => $name,
        ];
    }

    return $entries;
}

function content_types_schema_columns(string $type): array
{
    $def = content_types_load($type);
    $columns = [];
    foreach ($def['fields'] as $field) {
        if (!is_array($field)) {
            continue;
        }
        $name = $field['name'] ?? null;
        if (!is_string($name) || !preg_match('/^[a-z][a-z0-9_]*$/', $name)) {
            continue;
        }
        $field['type'] = is_string($field['type'] ?? null) ? $field['type'] : 'text';
        $columns[] = $field;
    }

    return $columns;
}

function content_types_fetch_list(string $type, int $limit = 100): array
{
    if (!content_types_name_valid($type)) {
        return [];
    }
    $limit = max(1, min(500, $limit));
    $stmt = db()->prepare(
        "SELECT id, data, sort_order, created_at, updated_at
         FROM content_items
         WHERE content_type = ?
         ORDER BY " . CONTENT_TYPES_ORDER . "
         LIMIT {$limit}"
    );
    $stmt->execute([$type]);
    $rows = $stmt->fetchAll();

    return array_map('content_types_expand_row', $rows);
}

function content_types_fetch_by_id(string $type, int $id): ?array
{
    if (!content_types_name_valid($type) || $id <= 0) {
        return null;
    }
    $stmt = db()->prepare(
        'SELECT id, data, sort_order, created_at, updated_at
         FROM content_items WHERE content_type = ? AND id = ? LIMIT 1'
    );
    $stmt->execute([$type, $id]);
    $row = $stmt->fetch();

    return $row ? content_types_expand_row($row) : null;
}

function content_types_expand_row(array $row): array
{
    $data = json_decode((string) ($row['data'] ?? '{}'), true);
    if (!is_array($data)) {
        $data = [];
    }
    unset($row['data']);
    return $row + $data;
}

function content_types_save(string $type, array $rawValues, ?int $id = null): int
{
    if (!content_types_name_valid($type)) {
        throw new InvalidArgumentException(API_TEXT['invalidType']);
    }
    // Validate type exists
    content_types_load($type);

    $stored = $id !== null && $id > 0 ? content_types_fetch_by_id($type, $id) : null;
    $values = plugin_schema_values(content_types_schema_columns($type), $rawValues, $stored ?? []);
    $json = json_encode($values, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        throw new RuntimeException('Cannot encode item data');
    }

    $now = db_now();
    if ($id !== null && $id > 0) {
        $stmt = db()->prepare('UPDATE content_items SET data = ?, updated_at = ? WHERE content_type = ? AND id = ?');
        $stmt->execute([$json, $now, $type, $id]);
        return $id;
    }

    // Neue Einträge landen am Ende der Liste.
    $stmt = db()->prepare('SELECT MAX(sort_order) FROM content_items WHERE content_type = ?');
    $stmt->execute([$type]);
    $max = $stmt->fetchColumn();
    $sortOrder = $max === null ? 0 : (int) $max + 1;

    $stmt = db()->prepare('INSERT INTO content_items (content_type, data, sort_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$type, $json, $sortOrder, $now, $now]);
    return (int) db()->lastInsertId();
}

/**
 * Tauscht einen Eintrag mit seinem Nachbarn ($step -1 = nach oben, 1 = nach unten) und nummeriert
 * den Typ dabei durch. Liefert false, wenn es den Eintrag nicht gibt oder er schon am Rand steht.
 */
function content_types_move(string $type, int $id, int $step): bool
{
    if (!content_types_name_valid($type) || $id <= 0) {
        return false;
    }
    $stmt = db()->prepare('SELECT id FROM content_items WHERE content_type = ? ORDER BY ' . CONTENT_TYPES_ORDER);
    $stmt->execute([$type]);
    $ids = array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));

    $pos = array_search($id, $ids, true);
    $target = $pos === false ? -1 : $pos + $step;
    if ($target < 0 || $target >= count($ids)) {
        return false;
    }
    [$ids[$pos], $ids[$target]] = [$ids[$target], $ids[$pos]];

    $pdo = db();
    $update = $pdo->prepare('UPDATE content_items SET sort_order = ? WHERE content_type = ? AND id = ?');
    $pdo->beginTransaction();
    try {
        foreach ($ids as $index => $itemId) {
            $update->execute([$index, $type, $itemId]);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }

    return true;
}

/** Löscht den Eintrag samt seinen Bildern, sofern sie sonst nirgends verwendet werden (core/uploads.php). */
function content_types_delete(string $type, int $id): void
{
    if (!content_types_name_valid($type) || $id <= 0) {
        return;
    }
    plugin_delete_entry('content-types', $id, ['content_type' => $type]);
}

/** Hook image_values (core/uploads.php): Bildwerte einer Zeile aus content_items laut Typ-Definition. */
function content_types_image_values(array $row): array
{
    return plugin_schema_image_values(content_types_schema_columns((string) $row['content_type']), content_types_expand_row($row));
}

/** Hook upload_in_use (core/uploads.php): verweist ein Eintrag irgendeines Typs auf die Upload-Datei? */
function content_types_upload_in_use(string $file): bool
{
    $stmt = db()->prepare('SELECT 1 FROM content_items WHERE INSTR(data, ?) > 0 LIMIT 1');
    $stmt->execute([$file]);

    return $stmt->fetchColumn() !== false;
}
