<?php
declare(strict_types=1);

require_once __DIR__ . '/fileStore.php';
require_once __DIR__ . '/phpRewriter.php';
require_once __DIR__ . '/labels.php';

// Elemente, die als Ganzes zu einem Textfeld werden können (dazu jedes Element mit vorhandener data-edit-id).
const IMPORT_CANDIDATE_TAGS = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'li', 'dt', 'dd', 'td', 'th', 'figcaption', 'blockquote', 'label', 'button', 'summary', 'div', 'span', 'a'];
const IMPORT_HEADING_TAGS = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'];
// Wrapper, die keine Abschnittsgrenze für Überschriften sind, auch wenn sie id oder class tragen.
const IMPORT_HEADING_WRAPPER_TAGS = ['header', 'hgroup'];
// Kinder, die statt des Elternteils markiert werden, wenn es sonst keinen eigenen Text hat.
const IMPORT_CHILD_TAGS = ['a', 'span'];
// Tag liefert den Abschnittsnamen, wenn id und class fehlen.
const IMPORT_STRUCTURE_TAGS = ['header', 'main', 'section', 'article', 'aside', 'footer', 'nav'];
// Ganzer Teilbaum wird weder markiert noch durchlaufen.
const IMPORT_SKIP_TAGS = ['script', 'style', 'template', 'svg', 'noscript'];
// Rest der Encoding-Anweisung, den der frühere DOMDocument-Import hinterließ.
const IMPORT_XML_REMNANT = '/(?:<\?xml encoding="UTF-8"\??>|<!--\?xml encoding="UTF-8"\??-->)\n?/';
// Gründe, warum eine Datei unverändert übersprungen wird (Import-Ergebnis „skippedFiles“).
const IMPORT_SKIP_REASONS = ['encoding' => 'nicht UTF-8'];
// <meta name="…" content="…">, die ein Feld werden (Wert im content-Attribut, reiner Text wie der
// Seitentitel; je Name die erste): name → ID ohne Präfix. Der Feldname ist LABEL_KINDS[name], ohne Überschrift.
const IMPORT_META_FIELDS = ['description' => 'meta.description'];
// <title> wird ebenso ein Feld (reiner Text, der erste, ohne PHP) mit dieser ID und dem Namen
// LABEL_KINDS[IMPORT_TITLE_KIND]. Die ID endet nicht auf .title: Die Seitenliste nimmt ihren
// Titel weiter aus der ersten Überschrift (page_title_from_content).
const IMPORT_TITLE_ID = 'meta.page_title';
const IMPORT_TITLE_KIND = 'pageTitle';
// Felder im <head>: heißen nur nach ihrer Art (import_label_kind), ohne Überschrift.
const IMPORT_HEAD_FIELD_TAGS = ['meta', 'title'];

function run_import(bool $force = false): array
{
    prepare_storage();

    if (!$force && import_status() !== null) {
        return ['imported' => false, 'skipped' => true, 'pages' => list_pages(), 'skippedFiles' => []];
    }

    $files = array_merge(
        glob(SITE_ROOT . '/*.html') ?: [],
        glob(SITE_ROOT . '/*.php') ?: []
    );
    // Files starting with "_" are runtime/utility endpoints, not editable pages.
    $files = array_values(array_filter(
        $files,
        static fn (string $f): bool => !str_starts_with(basename($f), '_')
    ));
    sort($files);
    $pages = [];
    $skippedFiles = [];

    foreach ($files as $file) {
        $page = pathinfo($file, PATHINFO_FILENAME);
        $reason = import_file($file, $page);
        if ($reason === null) {
            $pages[] = $page;
        } else {
            $skippedFiles[] = ['file' => basename($file), 'reason' => IMPORT_SKIP_REASONS[$reason]];
        }
    }

    foreach (shared_components() as $name => $file) {
        $reason = is_file($file) ? import_file($file, $name, $name) : null;
        if ($reason !== null) {
            $skippedFiles[] = ['file' => basename($file), 'reason' => IMPORT_SKIP_REASONS[$reason]];
        }
    }

    $status = [
        'imported' => true,
        'importedAt' => current_iso_time(),
        'pages' => $pages,
        'skippedFiles' => $skippedFiles,
    ];
    save_import_status($status);

    return $status;
}

/**
 * Markiert eine Seite oder Komponente ($prefix header/footer) neu und liest ihre Werte ins JSON.
 * Eine Datei, die kein gültiges UTF-8 ist, bleibt unverändert: Rückgabe ist dann der Schlüssel
 * aus IMPORT_SKIP_REASONS, sonst null.
 */
function import_file(string $file, string $name, string $prefix = ''): ?string
{
    // Dieselbe Sperre wie Speichern und Wiederherstellen (Lesen → JSON → Datei).
    $locks = lock_pages([$name]);
    $source = (string) file_get_contents($file);
    if (!mb_check_encoding($source, 'UTF-8')) {
        unlock_pages($locks);
        return 'encoding';
    }
    if ($prefix === '') {
        $originalPath = ORIGINALS_ROOT . '/' . basename($file);
        if (!is_file($originalPath)) {
            copy($file, $originalPath);
        }
    }

    $result = import_source($source, $prefix, import_issued_ids($name));
    // Kurzinfo mit den Namen aus der neuen Quelle (neue IDs heißen wie im Editor), ein Baum für beides.
    $doc = markup_parse($result['source']);
    save_page_content($name, $result['content'], page_field_kinds($doc, $name, $result['content']), ['doc' => $doc]);
    if ($result['source'] !== $source) {
        snapshot_original_file($file);
        atomic_write($file, $result['source']);
    }
    prune_backups($name);
    unlock_pages($locks);
    return null;
}

/**
 * IDs, die eine Seite oder Komponente schon vergeben hat (wie in der Datei, mit Präfix): Felder
 * ihres JSON und ihrer Backups sowie ihre Namens-Overrides. Der Import gibt sie keinem anderen
 * Element, sonst schriebe ein altes Backup fremden Text hinein.
 */
function import_issued_ids(string $name): array
{
    $pre = field_id_prefix($name);
    $issued = array_fill_keys(array_keys(load_label_overrides($name)), true);
    foreach ([page_json_path($name), ...page_backup_files($name)] as $file) {
        $data = is_file($file) ? json_decode((string) file_get_contents($file), true) : null;
        foreach (array_keys(flatten_content(is_array($data) ? $data : [])) as $id) {
            $issued[$pre . $id] = true;
        }
    }
    return $issued;
}

/**
 * Ein Importweg für HTML und PHP: Markierungen entscheiden, vorhandene IDs behalten,
 * fehlende vergeben (nie eine aus $issued, import_issued_ids), Marker byte-genau setzen oder
 * entfernen und die Werte aus demselben Baum lesen. ['source' => neue Datei, 'content' => Werte ohne Präfix]
 */
function import_source(string $source, string $prefix = '', array $issued = []): array
{
    $source = preg_replace(IMPORT_XML_REMNANT, '', $source) ?? $source;
    $doc = markup_parse($source);
    $state = ['marks' => [], 'headings' => [], 'meta' => []];
    $heading = null;
    foreach ($doc['roots'] as $root) {
        import_walk($doc, $root, [], $state, $heading);
    }
    $pre = field_id_prefix($prefix);
    $marks = import_assign_labels(import_assign_ids($doc, $state['marks'], $pre, $issued), $state['headings']);

    $edits = [];
    $content = [];
    $marked = [];
    foreach ($marks as $mark) {
        $marked[$mark['index']] = true;
        import_sync_attributes($doc, $mark['index'], $mark['attrs'], $edits);
        foreach (import_mark_values($doc, $mark) as $id => $value) {
            set_nested_value($content, str_starts_with($id, $pre) ? substr($id, strlen($pre)) : $id, $value);
        }
    }
    foreach ($doc['nodes'] as $index => $node) {
        if ($node['type'] === 'element' && !isset($marked[$index])) {
            import_sync_attributes($doc, $index, [], $edits);
        }
    }

    return ['source' => markup_apply($source, $edits), 'content' => $content];
}

/** Marker, die der Import setzt und an nicht (mehr) markierten Elementen entfernt. */
function import_edit_attributes(): array
{
    return [...array_keys(EDIT_MARKERS), 'data-edit-label'];
}

/**
 * Durchlauf: entscheidet je Element, ob es Text, Link, Bild oder Hintergrund wird.
 * Markierung: index, tag, field (title|text|url|image|Name aus IMPORT_META_FIELDS|null), text (eigenes Textfeld, bei Links der Linktext),
 * alt, bg, group (Abschnittsname), heading (Knoten der zuständigen Überschrift).
 * $heading ist die im aktuellen Abschnitt geltende Überschrift: Ein benannter Block (id, class,
 * Strukturtag außer header/hgroup) beginnt ohne; beim Verlassen gilt die äußere wieder.
 */
function import_walk(array $doc, int $index, array $ancestors, array &$state, ?int &$heading): void
{
    $node = $doc['nodes'][$index];
    if ($node['type'] !== 'element' || in_array($node['tag'], IMPORT_SKIP_TAGS, true) || markup_attr($node, 'data-plugin') !== null) {
        return;
    }
    $tag = $node['tag'];
    $mark = [
        'index' => $index,
        'tag' => $tag,
        'field' => null,
        'text' => false,
        'alt' => false,
        'bg' => false,
        'group' => closest_context_name($doc, $ancestors),
        'heading' => $heading,
        'attrs' => [],
    ];
    $descend = true;

    if (!import_is_hidden($node)) {
        $mark['bg'] = import_target_readable($node, 'background');
        if ($tag === 'img') {
            if (import_target_readable($node, 'src')) {
                $mark['field'] = 'image';
                // Ein alt mit PHP-Block ist nicht zurückschreibbar und wird kein Feld; ohne alt schon.
                $mark['alt'] = edit_target_problem($node, 'alt') === null;
            }
        } elseif ($tag === 'title') {
            // Es gilt das erste <title> (wie im Browser); mit PHP darin gibt es kein Feld.
            if (!isset($state['meta'][IMPORT_TITLE_KIND]) && !markup_inner_has_php($doc, $index)) {
                $mark['field'] = IMPORT_TITLE_KIND;
                $mark['heading'] = null;
            }
            $state['meta'][IMPORT_TITLE_KIND] = true;
            $descend = false;
        } elseif ($tag === 'meta') {
            // Nur bekannte Namen mit content-Attribut ohne PHP; ohne content keine Beschreibung, kein
            // Feld. Je Name nur die erste Angabe (die gilt auch im Browser).
            $name = strtolower(trim(markup_attr_text($node, 'name')));
            if (isset(IMPORT_META_FIELDS[$name]) && !isset($state['meta'][$name]) && import_target_readable($node, 'content')) {
                $state['meta'][$name] = true;
                $mark['field'] = $name;
                $mark['heading'] = null;
            }
        } elseif (in_array($tag, IMPORT_CANDIDATE_TAGS, true) || markup_attr($node, 'data-edit-id') !== null) {
            $shape = import_content_shape($doc, $index);
            if ($tag === 'a' && import_target_value($doc, $index, 'href') !== '') {
                $mark['field'] = 'url';
                $mark['text'] = $shape === 'text';
                $descend = !$mark['text'];
            } elseif ($tag === 'a') {
                // Ohne speicherbares Ziel nur ein Textfeld (data-edit-text-id), wie ein span.
                $mark['text'] = $shape === 'text';
                $descend = !$mark['text'];
            } elseif ($shape === 'text') {
                $mark['field'] = semantic_field($tag);
                $descend = false;
            }
        }
        if (in_array($tag, IMPORT_HEADING_TAGS, true) && !markup_inner_has_php($doc, $index)) {
            $text = label_heading_text(markup_inner_html($doc, $index));
            if ($text !== '') {
                $state['headings'][$index] = $text;
                $heading = $index;
                $mark['heading'] = $index;
            }
        }
    }

    $markPos = null;
    if ($mark['field'] !== null || $mark['text'] || $mark['bg']) {
        $markPos = count($state['marks']);
        $state['marks'][] = $mark;
    }
    if ($descend) {
        $ancestors[] = $index;
        $boundary = !in_array($tag, IMPORT_HEADING_WRAPPER_TAGS, true) && context_name_from_element($node) !== '';
        $inner = null;
        foreach ($node['children'] as $child) {
            if ($boundary) {
                import_walk($doc, $child, $ancestors, $state, $inner);
            } else {
                import_walk($doc, $child, $ancestors, $state, $heading);
            }
        }
        // Ein reines Hintergrund-Element, das einen Abschnitt beginnt, heißt nach dessen erster
        // Überschrift, wie tief sie auch liegt (sie steht erst nach dem Element selbst).
        $first = $boundary && $markPos !== null && import_label_kind($mark) === 'background' ? import_first_heading($doc, $index, $state['headings']) : null;
        if ($first !== null) {
            $state['marks'][$markPos]['heading'] = $first;
        }
    }
}

/** Erste Überschrift (Knoten aus $headings, wie import_walk sie erkennt) im Teilbaum von $index; null ohne. */
function import_first_heading(array $doc, int $index, array $headings): ?int
{
    foreach (array_keys($headings) as $heading) {
        if ($heading > $index && $doc['nodes'][$heading]['start'] < $doc['nodes'][$index]['end']) {
            return $heading;
        }
    }
    return null;
}

/**
 * Form des Inhalts eines Kandidaten:
 * 'text'     – nur Text und Inline-Elemente (rekursiv), mit Text, ohne PHP, ohne Icon;
 * 'children' – kein eigener Text, nur a/span-Kinder → die Kinder werden markiert;
 * 'mixed'    – alles andere (Block-Kinder, Bilder, Icons, PHP, leer).
 */
function import_content_shape(array $doc, int $index): string
{
    $node = $doc['nodes'][$index];
    if ($node['self_closing'] || markup_inner_has_php($doc, $index)) {
        return 'mixed';
    }
    $directText = false;
    $childTags = [];
    foreach ($node['children'] as $child) {
        $childNode = $doc['nodes'][$child];
        if ($childNode['type'] === 'text') {
            $directText = $directText || import_has_text(substr($doc['source'], $childNode['start'], $childNode['end'] - $childNode['start']));
        } elseif ($childNode['type'] === 'element') {
            $childTags[] = $childNode['tag'];
        }
    }
    if ($node['tag'] !== 'a' && !in_array($node['tag'], IMPORT_HEADING_TAGS, true) && !$directText && $childTags !== [] && array_diff($childTags, IMPORT_CHILD_TAGS) === []) {
        return 'children';
    }
    if (import_is_inline_content($doc, $index) && import_has_text(strip_tags(markup_inner_html($doc, $index)))) {
        return 'text';
    }
    return 'mixed';
}

/** Alle Nachkommen sind Inline-Elemente; Inline-Elemente außer <br> ohne Text gelten als Icon. */
function import_is_inline_content(array $doc, int $index): bool
{
    foreach ($doc['nodes'][$index]['children'] as $child) {
        $childNode = $doc['nodes'][$child];
        if ($childNode['type'] !== 'element') {
            continue;
        }
        if (!in_array($childNode['tag'], TEXT_ALLOWED_TAGS, true)) {
            return false;
        }
        if ($childNode['tag'] !== 'br' && (!import_has_text(strip_tags(markup_inner_html($doc, $child))) || !import_is_inline_content($doc, $child))) {
            return false;
        }
    }
    return true;
}

/** Enthält der rohe Text (mit Entities) etwas anderes als Leerraum? */
function import_has_text(string $raw): bool
{
    return (bool) preg_match('/[^\s\x{A0}]/u', html_entity_decode($raw, ENT_HTML5 | ENT_QUOTES, 'UTF-8'));
}

function import_is_hidden(array $node): bool
{
    if (markup_attr($node, 'hidden') !== null) {
        return true;
    }
    return (bool) preg_match('/display\s*:\s*none|visibility\s*:\s*hidden/i', markup_attr_text($node, 'style'));
}

/**
 * Attributwert für Namen (id, class); leer, wenn er einen PHP-Block enthält.
 */
function import_attr_value(array $node, string $name): string
{
    $attr = markup_attr($node, $name);
    return $attr === null || $attr['has_php'] ? '' : sanitize_text_value(markup_attr_text($node, $name));
}

/**
 * Ziel (src, href, background) steht in der Datei und ist zurückschreibbar (edit_target_problem,
 * dieselbe Regel wie beim Speichern). Ob ein Bild- oder Hintergrundfeld entsteht, hängt daran,
 * nicht am Wert: ein geleertes Bild (src="", url()) oder ein data:-Wert bleibt ein Feld (Wert ''
 * nach der Bereinigung), sonst ginge es beim Re-Import verloren.
 */
function import_target_readable(array $node, string $target): bool
{
    return markup_attr($node, edit_target_attr($target)) !== null && edit_target_problem($node, $target) === null;
}

/**
 * Bereinigter Wert eines Ziels wie beim Speichern (source_field_value); leer, wenn es nicht
 * lesbar ist. Ein Link mit leerem Wert (auch javascript:) hat kein speicherbares Ziel und wird
 * nur Text (Entscheidung 11).
 */
function import_target_value(array $doc, int $index, string $target): string
{
    return import_target_readable($doc['nodes'][$index], $target) ? source_field_value($doc, $index, $target) : '';
}

/** Marker, die eine Markierung trägt (Name → gewünscht). */
function import_mark_markers(array $mark): array
{
    return array_keys(array_filter([
        'data-edit-id' => $mark['field'] !== null,
        'data-edit-text-id' => $mark['text'],
        'data-edit-alt-id' => $mark['alt'],
        'data-edit-bg-id' => $mark['bg'],
    ]));
}

/**
 * Vorhandene IDs bleiben, und zwar das erste Vorkommen: erst die IDs, die schon so in der Datei
 * stehen, dann die, die in Komponenten erst das Präfix $pre bekommen. Danach sind auch die früher
 * vergebenen ($issued) gesperrt; weitere Vorkommen (z. B. per FTP kopiert) und neue Elemente
 * bekommen eine ID, die es nie gab – so nimmt kein Element die ID eines anderen.
 */
function import_assign_ids(array $doc, array $marks, string $pre, array $issued = []): array
{
    $assigned = [];
    $take = static function (string $id) use (&$assigned, $pre): string {
        $id = unique_edit_id($pre === '' ? import_page_id($id) : $id, $assigned);
        $assigned[$id] = true;
        return $id;
    };

    $copies = [];
    foreach ([true, false] as $exact) {
        foreach ($marks as $m => $mark) {
            foreach (import_existing_ids($doc['nodes'][$mark['index']], $mark) as $name => $existing) {
                if (str_starts_with($existing, $pre) !== $exact) {
                    continue;
                }
                $id = $exact ? $existing : $pre . $existing;
                if (isset($assigned[$id])) {
                    $copies[] = [$m, $name, $id];
                } else {
                    $assigned[$id] = true;
                    $marks[$m]['attrs'][$name] = $id;
                }
            }
        }
    }
    $assigned += $issued;
    foreach ($copies as [$m, $name, $id]) {
        $marks[$m]['attrs'][$name] = $take($id);
    }

    $counts = [];
    foreach ($marks as &$mark) {
        $tag = $mark['tag'];
        if ($mark['field'] !== null && !isset($mark['attrs']['data-edit-id'])) {
            $id = match ($tag) {
                'meta' => IMPORT_META_FIELDS[$mark['field']],
                'title' => IMPORT_TITLE_ID,
                default => generate_edit_id($tag, $mark['group'], $counts, $assigned, $pre),
            };
            $mark['attrs']['data-edit-id'] = $take($pre . $id);
        }
        if ($mark['text'] && !isset($mark['attrs']['data-edit-text-id'])) {
            // Ohne data-edit-id (Link ohne Ziel) ein eigenes Textfeld, benannt wie ein span.
            $mark['attrs']['data-edit-text-id'] = $take(isset($mark['attrs']['data-edit-id'])
                ? edit_base_from_id($mark['attrs']['data-edit-id']) . '.text'
                : $pre . generate_edit_id('span', $mark['group'], $counts, $assigned, $pre));
        }
        if ($mark['alt'] && !isset($mark['attrs']['data-edit-alt-id'])) {
            $mark['attrs']['data-edit-alt-id'] = $take($mark['attrs']['data-edit-id'] . '_alt');
        }
        if ($mark['bg'] && !isset($mark['attrs']['data-edit-bg-id'])) {
            $base = context_name_from_element($doc['nodes'][$mark['index']]) ?: $mark['group'] ?: fallback_base($tag, $counts);
            $mark['attrs']['data-edit-bg-id'] = $take($pre . $base . '.background');
        }
    }
    unset($mark);

    return $marks;
}

/**
 * Neue Seiten-IDs beginnen nie mit dem Präfix einer Komponente (id_component), damit Seite und
 * Komponente sich keine ID teilen: Der Abschnitt bekommt die Nummer wie ein Duplikat
 * (unique_edit_id, header.image → header_2.image). Vorhandene IDs bleiben, wie sie sind (eine ID
 * wechselt nie); Speichern ordnet sie über die Datei der Seite zu (split_page_content).
 */
function import_page_id(string $id): string
{
    $component = id_component($id);
    return $component === null ? $id : unique_edit_id($component, [$component => true]) . substr($id, strlen($component));
}

/** Vorhandene IDs einer Markierung in der Datei (Marker → ID wie dort, ggf. ohne Präfix). */
function import_existing_ids(array $node, array $mark): array
{
    $ids = [];
    foreach (import_mark_markers($mark) as $name) {
        $existing = markup_attr($node, $name)['value'] ?? '';
        // Ein Link ohne Ziel trägt sein Textfeld als data-edit-text-id; eine vorhandene
        // data-edit-id daran (außer einer Link-ID) ist dieses Feld und bleibt.
        if ($existing === '' && $name === 'data-edit-text-id' && $mark['field'] === null) {
            $existing = markup_attr($node, 'data-edit-id')['value'] ?? '';
            if (edit_field_from_id($existing) === semantic_field('a')) {
                $existing = '';
            }
        }
        if ($existing !== '') {
            $ids[$name] = $existing;
        }
    }
    return $ids;
}

/**
 * data-edit-label „<Überschrift> – <Art>[ Nr]“; Nummer nur bei mehreren derselben Art unter
 * derselben Überschrift. Felder im <head> heißen nur nach ihrer Art („Seitentitel“, „Seitenbeschreibung“).
 */
function import_assign_labels(array $marks, array $headings): array
{
    $totals = [];
    foreach ($marks as $mark) {
        if ($mark['heading'] !== null) {
            $key = $mark['heading'] . '|' . import_label_kind($mark);
            $totals[$key] = ($totals[$key] ?? 0) + 1;
        }
    }
    $seen = [];
    foreach ($marks as &$mark) {
        if (in_array($mark['tag'], IMPORT_HEAD_FIELD_TAGS, true)) {
            $mark['attrs']['data-edit-label'] = LABEL_KINDS[import_label_kind($mark)];
        }
        if ($mark['heading'] === null) {
            continue;
        }
        $kind = import_label_kind($mark);
        $key = $mark['heading'] . '|' . $kind;
        $seen[$key] = ($seen[$key] ?? 0) + 1;
        $mark['attrs']['data-edit-label'] = label_for_heading($headings[$mark['heading']], $kind, $totals[$key] > 1 ? $seen[$key] : 0);
    }
    unset($mark);

    return $marks;
}

/** Art einer Markierung (Schlüssel aus LABEL_KINDS). */
function import_label_kind(array $mark): string
{
    if ($mark['field'] === null) {
        return $mark['text'] ? 'text' : 'background';
    }
    return match (true) {
        in_array($mark['tag'], IMPORT_HEAD_FIELD_TAGS, true) => $mark['field'],
        in_array($mark['tag'], IMPORT_HEADING_TAGS, true) => 'heading',
        $mark['field'] === 'url' => 'url',
        $mark['field'] === 'image' => 'image',
        $mark['tag'] === 'p' => 'paragraph',
        $mark['tag'] === 'li' => 'item',
        default => 'text',
    };
}

/** Gleicht die Edit-Attribute eines Elements mit $wanted (Name → Wert) ab: setzen, ersetzen, entfernen. */
function import_sync_attributes(array $doc, int $index, array $wanted, array &$edits): void
{
    $node = $doc['nodes'][$index];
    foreach (import_edit_attributes() as $name) {
        $attr = markup_attr($node, $name);
        if (!isset($wanted[$name])) {
            if ($attr !== null) {
                $edits[] = markup_remove_attr($doc, $index, $name);
            }
        } elseif ($attr === null || markup_attr_text($node, $name) !== $wanted[$name]) {
            $edits[] = markup_set_attr($doc, $index, $name, markup_attr_escape($wanted[$name]));
        }
    }
}

/** Werte einer Markierung (ID wie in der Datei → Wert), gelesen wie beim Speichern (source_field_value). */
function import_mark_values(array $doc, array $mark): array
{
    $node = $doc['nodes'][$mark['index']];
    $values = [];
    foreach (array_intersect_key($mark['attrs'], EDIT_MARKERS) as $marker => $id) {
        $values[$id] = source_field_value($doc, $mark['index'], edit_marker_target($marker, $node));
    }
    return $values;
}

/**
 * Neue ID (ohne Präfix $pre). Gezählte Basen (link_N, block_N, …) überspringen schon vergebene
 * IDs aus $assigned; Gruppen-IDs bekommen beim Vergeben _2 (unique_edit_id).
 */
function generate_edit_id(string $tag, string $group, array &$counts, array $assigned = [], string $pre = ''): string
{
    $counted = $tag === 'a' || $group === '';
    do {
        $id = ($counted ? fallback_base($tag, $counts) : $group) . '.' . semantic_field($tag);
    } while ($counted && isset($assigned[$pre . $id]));
    return $id;
}

function unique_edit_id(string $id, array $assignedIds): string
{
    if (!isset($assignedIds[$id])) {
        return $id;
    }
    $suffix = 2;
    while (isset($assignedIds[$id . '_' . $suffix])) {
        $suffix++;
    }
    return $id . '_' . $suffix;
}

function edit_base_from_id(string $id): string
{
    $parts = explode('.', $id);
    array_pop($parts);
    return implode('.', $parts);
}

function semantic_field(string $tag): string
{
    return match (true) {
        in_array($tag, IMPORT_HEADING_TAGS, true) => 'title',
        $tag === 'a' => 'url',
        $tag === 'img' => 'image',
        default => 'text',
    };
}

/** Name des nächsten Vorfahren mit id, class oder Strukturtag; leer ohne. */
function closest_context_name(array $doc, array $ancestors): string
{
    for ($i = count($ancestors) - 1; $i >= 0; $i--) {
        $name = context_name_from_element($doc['nodes'][$ancestors[$i]]);
        if ($name !== '') {
            return $name;
        }
    }
    return '';
}

function context_name_from_element(array $node): string
{
    $id = clean_name(import_attr_value($node, 'id'));
    if ($id !== '') {
        return $id;
    }

    foreach (preg_split('/\s+/', import_attr_value($node, 'class')) ?: [] as $class) {
        $clean = clean_name($class);
        if ($clean !== '') {
            return $clean;
        }
    }

    return in_array($node['tag'], IMPORT_STRUCTURE_TAGS, true) ? $node['tag'] : '';
}

function fallback_base(string $tag, array &$counts): string
{
    $counts[$tag] = ($counts[$tag] ?? 0) + 1;
    return match (true) {
        in_array($tag, IMPORT_HEADING_TAGS, true) => $counts[$tag] === 1 ? 'hero' : 'section_' . ($counts[$tag] - 1),
        $tag === 'a' => 'link_' . $counts[$tag],
        $tag === 'img' => $counts[$tag] === 1 ? 'hero' : 'image_' . $counts[$tag],
        default => $counts[$tag] === 1 ? 'block' : 'block_' . $counts[$tag],
    };
}

function clean_name(string $value): string
{
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9]+/', '_', $value) ?? '';
    return trim($value, '_');
}
