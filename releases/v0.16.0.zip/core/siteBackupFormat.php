<?php
declare(strict_types=1);

// Aufbau des Sicherungs-ZIPs (siehe knowledgebase/backup.md). Bewusst ohne
// weitere require: Das Abhol-Skript in tools/ läuft damit ohne Installation.

// Manifest im ZIP-Root: version, created, driver, fingerprint, files[{path, size, sha256}].
const SITE_BACKUP_MANIFEST = 'backup.json';
// Ordner für den MySQL-Export im ZIP: schema.json plus je Plugin-Tabelle
// eine Datei <tabelle>.jsonl, eine Zeile je Datensatz.
const SITE_BACKUP_DB_DIR = 'database';
const SITE_BACKUP_DB_SCHEMA = 'schema.json';
const SITE_BACKUP_DB_ROWS_SUFFIX = '.jsonl';

/**
 * Größe und SHA-256 eines ZIP-Eintrags, gestreamt (große Dateien ohne Speicher);
 * Manifest-Erstellung und Abhol-Skript rechnen damit dieselbe Prüfsumme.
 */
function site_backup_entry_digest(ZipArchive $zip, string $name): array
{
    $stream = $zip->getStream($name);
    if (!$stream) {
        throw new RuntimeException($name . ' ließ sich nicht aus dem ZIP lesen');
    }
    $hash = hash_init('sha256');
    $size = hash_update_stream($hash, $stream);
    fclose($stream);
    return ['size' => $size, 'sha256' => hash_final($hash)];
}
