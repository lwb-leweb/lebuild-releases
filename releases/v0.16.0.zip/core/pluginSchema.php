<?php
declare(strict_types=1);

require_once __DIR__ . '/plugins.php';

function plugin_main_table(array $manifest): ?string
{
    $tables = $manifest['tables'] ?? [];
    if (!is_array($tables) || empty($tables)) {
        return null;
    }

    $name = $tables[0];
    if (!is_string($name) || !plugin_table_name_valid($name)) {
        return null;
    }

    return $name;
}

function plugin_schema_columns(array $manifest): array
{
    $fields = $manifest['schema']['fields'] ?? [];
    if (!is_array($fields)) {
        return [];
    }

    $columns = [];
    foreach ($fields as $field) {
        if (!is_array($field)) {
            continue;
        }
        $name = $field['name'] ?? null;
        if (!is_string($name) || !plugin_table_name_valid($name)) {
            continue;
        }
        $field['type'] = is_string($field['type'] ?? null) ? $field['type'] : 'text';
        $columns[] = $field;
    }

    return $columns;
}

function plugin_schema_field_names(array $manifest): array
{
    return array_map(static fn (array $field): string => $field['name'], plugin_schema_columns($manifest));
}

/** Werte der Bildfelder eines Eintrags (Upload-Pfade), z. B. zum Aufräumen beim Löschen. */
function plugin_schema_image_values(array $fields, array $row): array
{
    $values = [];
    foreach ($fields as $field) {
        $value = $row[$field['name']] ?? null;
        if (($field['type'] ?? '') === 'image' && is_string($value) && $value !== '') {
            $values[] = $value;
        }
    }

    return $values;
}

/** Zeile $id der Haupttabelle $table eines Plugins (generische Plugins), null ohne. */
function plugin_fetch_row(string $table, int $id): ?array
{
    $stmt = db()->prepare("SELECT * FROM `{$table}` WHERE `id` = ? LIMIT 1");
    $stmt->execute([$id]);
    $row = $stmt->fetch();

    return $row ?: null;
}

/**
 * Ob eine Spalte aus schema.fields der Haupttabelle die Upload-Datei $file enthält (Bildfeld oder Verweis
 * im Text). Gilt für jedes Plugin mit Schema, auch ohne lib.php (generisches Admin-Formular).
 */
function plugin_schema_upload_in_use(array $manifest, string $file): bool
{
    $table = plugin_main_table($manifest);
    $columns = plugin_schema_field_names($manifest);
    if ($table === null || $columns === []) {
        return false;
    }
    $where = implode(' OR ', array_map(static fn (string $column): string => "INSTR(`{$column}`, ?) > 0", $columns));
    $stmt = db()->prepare("SELECT 1 FROM `{$table}` WHERE {$where} LIMIT 1");
    $stmt->execute(array_fill(0, count($columns), $file));

    return $stmt->fetchColumn() !== false;
}

// Slug: Umlaute werden umgeschrieben, alles außer a–z und 0–9 wird zu „-“; bleibt nichts übrig, gilt die Vorgabe.
const PLUGIN_SLUG_TRANSLITERATION = ['ä' => 'ae', 'ö' => 'oe', 'ü' => 'ue', 'ß' => 'ss'];
const PLUGIN_SLUG_FALLBACK = 'item';
// Höchstlänge eines Slugs aus slugify: Spaltenlänge (VARCHAR(255)) abzüglich Platz für „-n“
// aus plugin_unique_slug; die Umschreibung (ä → ae) kann Text verlängern.
const PLUGIN_SLUG_MAX_LENGTH = 240;
// Meldung für ein leeres Pflichtfeld (Beschriftung wie im Formular: label, sonst Name).
const PLUGIN_SCHEMA_REQUIRED_MESSAGE = 'Bitte „%s“ ausfüllen.';
// Meldungen und Status, wenn ein Plugin-Eintrag an der Datenbank oder an seiner Definition scheitert
// (plugin_failure_response; Details nur ins Server-Log, nie Rohtext an den Browser).
const PLUGIN_FAILED_TEXT = [
    'load' => 'Die Einträge konnten nicht geladen werden.',
    'save' => 'Der Eintrag konnte nicht gespeichert werden.',
    'delete' => 'Der Eintrag konnte nicht gelöscht werden.',
    'sort' => 'Die Reihenfolge konnte nicht geändert werden.',
];
const PLUGIN_FAILED_STATUS = 500;

/** Antwort, wenn $action ('load', 'save', 'delete', 'sort') an $e scheitert: Meldung aus PLUGIN_FAILED_TEXT, Fehler ins Log. */
function plugin_failure_response(string $action, Throwable $e): void
{
    error_log('plugin ' . $action . ': ' . $e->getMessage());
    json_response(['ok' => false, 'error' => PLUGIN_FAILED_TEXT[$action]], PLUGIN_FAILED_STATUS);
}

function plugin_schema_slugify(string $value): string
{
    $value = strtr(mb_strtolower(trim($value), 'UTF-8'), PLUGIN_SLUG_TRANSLITERATION);
    $value = preg_replace('/[^a-z0-9]+/', '-', $value) ?? '';
    $value = trim(substr(trim($value, '-'), 0, PLUGIN_SLUG_MAX_LENGTH), '-');

    return $value !== '' ? $value : PLUGIN_SLUG_FALLBACK;
}

/** Slug, der in $table.$column noch frei ist, sonst mit -2, -3 …; die Zeile $id selbst zählt nicht. */
function plugin_unique_slug(string $table, string $column, string $slug, ?int $id): string
{
    $stmt = db()->prepare("SELECT 1 FROM `{$table}` WHERE `{$column}` = ? AND `id` <> ? LIMIT 1");
    $candidate = $slug;
    for ($n = 2; ; $n++) {
        $stmt->execute([$candidate, $id ?? 0]);
        if ($stmt->fetchColumn() === false) {
            return $candidate;
        }
        $stmt->closeCursor();
        $candidate = $slug . '-' . $n;
    }
}

function plugin_schema_required_message(array $field): string
{
    return sprintf(PLUGIN_SCHEMA_REQUIRED_MESSAGE, is_string($field['label'] ?? null) && $field['label'] !== '' ? $field['label'] : $field['name']);
}

/**
 * Werte eines Eintrags nach schema.fields: nur Felder, die in $rawValues stehen, normalisiert;
 * ein fehlendes oder leeres Pflichtfeld wirft InvalidArgumentException mit deutscher Meldung.
 * $stored ist die gespeicherte Zeile beim Bearbeiten (leer beim Anlegen): Ein unverändert
 * mitgeschickter Slug bleibt, wie er ist (auch älter und länger als PLUGIN_SLUG_MAX_LENGTH).
 */
function plugin_schema_values(array $fields, array $rawValues, array $stored = []): array
{
    $values = [];
    foreach ($fields as $field) {
        $key = $field['name'];
        if (!array_key_exists($key, $rawValues)) {
            if (!empty($field['required'])) {
                throw new InvalidArgumentException(plugin_schema_required_message($field));
            }
            continue;
        }
        if (($field['type'] ?? '') === 'slug' && is_string($stored[$key] ?? null) && $stored[$key] !== '' && $rawValues[$key] === $stored[$key]) {
            $values[$key] = $stored[$key];
            continue;
        }
        $normalized = plugin_schema_normalize_value($field, $rawValues[$key], $rawValues);
        if (!empty($field['required']) && ($normalized === '' || $normalized === null)) {
            throw new InvalidArgumentException(plugin_schema_required_message($field));
        }
        $values[$key] = $normalized;
    }

    return $values;
}

function plugin_schema_normalize_value(array $field, mixed $value, array $allValues): mixed
{
    $type = (string) ($field['type'] ?? 'text');

    if ($type === 'slug') {
        $text = trim(strip_tags((string) $value));
        if ($text === '' && is_string($field['from'] ?? null)) {
            $text = trim(strip_tags((string) ($allValues[$field['from']] ?? '')));
        }
        return plugin_schema_slugify($text);
    }

    if ($type === 'richtext') {
        return plugin_sanitize_richtext((string) $value);
    }

    if ($type === 'boolean') {
        return !empty($value) && $value !== '0' && $value !== 'false' ? '1' : '0';
    }

    if ($type === 'number') {
        return is_numeric($value) ? (string) $value : null;
    }

    if ($type === 'datetime') {
        $text = trim((string) $value);
        if ($text === '') {
            return null;
        }
        $text = str_replace('T', ' ', $text);
        if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $text)) {
            $text .= ':00';
        }
        return preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $text) ? $text : null;
    }

    // Bilder wie Bildfelder der Seiten (sanitize_field_value): nur http(s) und Pfade, kein javascript: oder data:.
    if ($type === 'image') {
        return sanitize_field_value('image', trim(strip_tags((string) $value)));
    }

    if ($type === 'select') {
        $text = trim(strip_tags((string) $value));
        if ($text === '') {
            return '';
        }
        $options = is_array($field['options'] ?? null)
            ? array_values(array_filter($field['options'], 'is_string'))
            : [];
        return in_array($text, $options, true) ? $text : '';
    }

    return trim(strip_tags((string) $value));
}
