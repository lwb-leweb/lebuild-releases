<?php
declare(strict_types=1);

require_once __DIR__ . '/utils.php';
require_once __DIR__ . '/users.php';

const DEFAULT_ADMIN_USER = 'admin';
const DEFAULT_ADMIN_PASSWORD = 'admin';
const LOGIN_MAX_FAILURES = 10;
const LOGIN_FAILURE_WINDOW = 900;
// Antwort bei Sperre; gilt für den Login und den Sicherungs-Abruf (gleicher Zähler).
const LOGIN_THROTTLED_MESSAGE = 'Zu viele Fehlversuche, bitte in ' . LOGIN_FAILURE_WINDOW / 60 . ' Minuten erneut versuchen.';
const LOGIN_THROTTLED_STATUS = 429;
// Login-Seite (index.php); `?next=` nennt das Ziel nach dem Login, siehe safe_redirect_path().
const LOGIN_URL = '/login';
// Ziel, wenn `next` fehlt oder nicht auf diese Website zeigt; Editoren landen von /admin aus hier.
const SITE_HOME_URL = '/';

// Eigener Name für die Session des Editors: Sie teilt sich nie die PHP-Session der Kundenseite
// (PHPSESSID oder was Site-PHP nutzt). Login, Erkennung auf der Website, Abmelden und das Verwerfen
// leerer Sessions betreffen nur diese; die Session der Website wird nie gelesen, geleert oder verworfen.
const APP_SESSION_NAME = 'le_session';
// Kennung der Antwort auf ein ungültiges CSRF-Token (require_csrf); der Seiten-Editor erkennt daran
// eine inzwischen erneuerte Anmeldung (CSRF_ERROR_CODE in public/admin/site-editor/request.js).
const CSRF_ERROR_CODE = 'csrf';

// $quiet: ohne Cache-Header von PHP (Fortsetzen auf der Website, resume_app_session).
function start_app_session(bool $quiet = false): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        if (session_name() === APP_SESSION_NAME) {
            return;
        }
        // Site-PHP hat im selben Request (index.php) seine Session gestartet: so gespeichert und
        // geschlossen, wie sie ist; danach läuft unsere mit unserer ID.
        session_write_close();
        session_id(is_string($_COOKIE[APP_SESSION_NAME] ?? null) ? $_COOKIE[APP_SESSION_NAME] : '');
    }

    session_name(APP_SESSION_NAME);
    if ($quiet) {
        session_cache_limiter('');
    }
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
    session_start();
}

// Bestehende Anmeldung fortsetzen, aber nie eine neue Session anfangen: nur wenn der Browser
// unser Session-Cookie (APP_SESSION_NAME) mitschickt. Besucher der Website bekommen so kein Cookie.
// Ohne Cache-Header von PHP: ein fremdes oder abgelaufenes Cookie macht die Seite nicht uncachebar,
// persönliche Antworten setzen no-store selbst (index.php). Eine leere Session (abgelaufen, fremde
// ID) wird verworfen: keine leere Session-Datei, und mit session.use_strict_mode kein neues Cookie
// (PHP vergibt dort für eine unbekannte ID eine neue und schickt sie).
function resume_app_session(): bool
{
    if (!isset($_COOKIE[APP_SESSION_NAME])) {
        return false;
    }
    if (session_status() === PHP_SESSION_ACTIVE && session_name() === APP_SESSION_NAME) {
        return is_logged_in();
    }
    start_app_session(true);
    if ($_SESSION === []) {
        session_destroy();
        remove_session_cookie_header();
        return false;
    }
    return is_logged_in();
}

// Nimmt unser Session-Cookie aus den Antwort-Headern; andere Cookies (z. B. aus Site-PHP) bleiben.
function remove_session_cookie_header(): void
{
    $prefix = 'set-cookie: ' . strtolower(APP_SESSION_NAME) . '=';
    $cookies = array_filter(headers_list(), static fn (string $header): bool => stripos($header, 'set-cookie:') === 0);
    header_remove('Set-Cookie');
    foreach ($cookies as $cookie) {
        if (!str_starts_with(strtolower($cookie), $prefix)) {
            header($cookie, false);
        }
    }
}

function configured_admin_user(): string
{
    return getenv('LIVE_EDITOR_USER') ?: DEFAULT_ADMIN_USER;
}

function configured_admin_password(): string
{
    return getenv('LIVE_EDITOR_PASSWORD') ?: DEFAULT_ADMIN_PASSWORD;
}

function auth_bootstrap_admin(string $username, string $password): ?array
{
    $now = current_iso_time();
    $hash = password_hash($password, PASSWORD_BCRYPT);
    if (!is_string($hash) || $hash === '') {
        return null;
    }
    $user = [
        'id' => users_generate_id(),
        'username' => $username,
        'passwordHash' => $hash,
        'role' => USER_ROLE_ADMIN,
        'createdAt' => $now,
        'updatedAt' => $now,
    ];
    // Mit dem eingebauten Standardpasswort darf niemand dauerhaft arbeiten.
    if ($password === DEFAULT_ADMIN_PASSWORD) {
        $user['mustChangePassword'] = true;
    }
    $store = users_load();
    $store['users'][] = $user;
    users_save($store);

    return $user;
}

function auth_complete_login(array $user): void
{
    session_regenerate_id(true);
    $_SESSION['logged_in'] = true;
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

function login_user(string $username, string $password): bool
{
    $username = trim($username);
    if ($username === '' || $password === '') {
        return false;
    }

    if (!users_has_admin()) {
        $expectedUser = configured_admin_user();
        $expectedPassword = configured_admin_password();
        if (!hash_equals($expectedUser, $username) || !hash_equals($expectedPassword, $password)) {
            return false;
        }
        $bootstrapped = auth_bootstrap_admin($expectedUser, $expectedPassword);
        if ($bootstrapped === null) {
            return false;
        }
        auth_complete_login($bootstrapped);
        return true;
    }

    $user = users_find_by_username($username);
    if ($user === null) {
        return false;
    }
    if (!users_verify_password($user, $password)) {
        return false;
    }

    if (users_needs_rehash($user)) {
        $newHash = password_hash($password, PASSWORD_BCRYPT);
        if (is_string($newHash) && $newHash !== '') {
            $store = users_load();
            foreach ($store['users'] as &$candidate) {
                if ($candidate['id'] === $user['id']) {
                    $candidate['passwordHash'] = $newHash;
                    $candidate['updatedAt'] = current_iso_time();
                    $user = $candidate;
                    break;
                }
            }
            unset($candidate);
            users_save($store);
        }
    }

    auth_complete_login($user);
    return true;
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(APP_SESSION_NAME, '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}

function is_logged_in(): bool
{
    return !empty($_SESSION['logged_in']);
}

function current_user(): ?array
{
    if (!is_logged_in()) {
        return null;
    }
    $id = $_SESSION['user_id'] ?? null;
    if (!is_string($id) || $id === '') {
        return null;
    }

    return users_find_by_id($id);
}

// Benutzer der laufenden Session; eine Session ohne existierenden Benutzer (gelöscht) wird beendet.
function session_user(): ?array
{
    $user = current_user();
    if ($user === null && is_logged_in()) {
        logout_user();
    }
    return $user;
}

// Fertig angemeldeter Benutzer für Website, /login und /admin (index.php): Cookie mitgeschickt,
// Benutzer existiert, kein offener Passwortwechsel. Startet für Besucher keine Session.
function signed_in_user(): ?array
{
    if (!resume_app_session()) {
        return null;
    }
    $user = session_user();
    return $user !== null && empty($user['mustChangePassword']) ? $user : null;
}

// Ziel nach dem Login: nur ein Pfad dieser Website. Genau ein führender Slash, kein Backslash
// (Browser lesen ihn als Slash, `/\evil` wäre fremd) und keine Steuerzeichen; sonst SITE_HOME_URL.
function safe_redirect_path(mixed $next): string
{
    if (!is_string($next) || !preg_match('#^/(?![/\\\\])[^\\\\\x00-\x1F\x7F]*$#D', $next)) {
        return SITE_HOME_URL;
    }
    return $next;
}

// Hinweis „Update installiert“ aus dem Login (api/login.php) für Admins, bis das Backend
// (api/bootstrap.php) oder der Seiten-Editor (core/siteEditor.php) ihn einmal zeigt.
const UPDATE_NOTICE_SESSION_KEY = 'updateInstalled';

function remember_update_notice(?array $installed): void
{
    if ($installed !== null && is_admin()) {
        $_SESSION[UPDATE_NOTICE_SESSION_KEY] = $installed;
    }
}

/** Gemerkter Hinweis, nur einmal; null ohne oder für Nicht-Admins. */
function take_update_notice(): ?array
{
    $notice = $_SESSION[UPDATE_NOTICE_SESSION_KEY] ?? null;
    unset($_SESSION[UPDATE_NOTICE_SESSION_KEY]);
    return is_array($notice) && is_admin() ? $notice : null;
}

// Pfad der Seite dieser Website, von der die Anfrage kam (Referer mit gleichem Host), für die
// Rückkehr nach dem Login; null ohne, bei fremden Hosts, unsicheren Pfaden und der Login-Seite selbst.
function referer_path(): ?string
{
    $referer = parse_url((string) ($_SERVER['HTTP_REFERER'] ?? ''));
    if (!is_array($referer) || !isset($referer['host'])) {
        return null;
    }
    $host = $referer['host'] . (isset($referer['port']) ? ':' . $referer['port'] : '');
    if (strcasecmp($host, (string) ($_SERVER['HTTP_HOST'] ?? '')) !== 0) {
        return null;
    }
    $path = ($referer['path'] ?? '/') . (isset($referer['query']) ? '?' . $referer['query'] : '');
    return safe_redirect_path($path) === $path && rtrim((string) ($referer['path'] ?? ''), '/') !== LOGIN_URL ? $path : null;
}

function current_role(): ?string
{
    // Rolle immer aus users.json, nie aus der Session: gelöschte oder
    // herabgestufte Benutzer verlieren ihre Rechte sofort.
    return current_user()['role'] ?? null;
}

function must_change_password(): bool
{
    return !empty(current_user()['mustChangePassword']);
}

function is_admin(): bool
{
    return current_role() === USER_ROLE_ADMIN;
}

function require_auth(bool $allowPendingPasswordChange = false): void
{
    start_app_session();
    if (session_user() === null) {
        json_response(['ok' => false, 'error' => API_TEXT['notAuthenticated']], 401);
    }
    if (!$allowPendingPasswordChange && must_change_password()) {
        json_response(['ok' => false, 'error' => API_TEXT['passwordChange']], 403);
    }
}

function require_admin(): void
{
    require_auth();
    if (!is_admin()) {
        json_response(['ok' => false, 'error' => API_TEXT['forbidden']], 403);
    }
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf'];
}

function require_csrf(): void
{
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!is_string($token) || !hash_equals(csrf_token(), $token)) {
        json_response(['ok' => false, 'error' => API_TEXT['csrf'], 'code' => CSRF_ERROR_CODE], 403);
    }
}

function login_throttle_path(): string
{
    $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
    return CACHE_ROOT . '/login-throttle/' . substr(hash_hmac('sha256', $ip, app_secret()), 0, 32) . '.json';
}

function login_recent_failures(): array
{
    $data = json_decode((string) @file_get_contents(login_throttle_path()), true);
    if (!is_array($data)) {
        return [];
    }
    $cutoff = time() - LOGIN_FAILURE_WINDOW;
    return array_values(array_filter(array_map('intval', $data), static fn (int $ts): bool => $ts > $cutoff));
}

function login_throttled(): bool
{
    return count(login_recent_failures()) >= LOGIN_MAX_FAILURES;
}

function login_record_failure(): void
{
    $failures = login_recent_failures();
    $failures[] = time();
    $path = login_throttle_path();
    ensure_dir(dirname($path));
    @file_put_contents($path, json_encode($failures), LOCK_EX);
}

function login_clear_failures(): void
{
    @unlink(login_throttle_path());
}
