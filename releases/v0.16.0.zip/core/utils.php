<?php
declare(strict_types=1);

define('PROJECT_ROOT', dirname(__DIR__));
define('PUBLIC_ROOT', PROJECT_ROOT . '/public');
define('SITE_ROOT', PUBLIC_ROOT . '/site');
define('CONTENT_ROOT', PROJECT_ROOT . '/content');
// Persistente Konfiguration bleibt direkt unter content/ (users.json,
// plugins.json, config.json, content-types/, labels/). Alles, was sich aus
// public/site/ + dem Importer rekonstruieren lässt — Seiten-JSON, Backups,
// Originale, Import-Status, Updater-Runtime-State — landet unter
// content/cache/ und ist gefahrlos wegwerfbar.
define('CACHE_ROOT', CONTENT_ROOT . '/cache');
define('PAGES_ROOT', CACHE_ROOT . '/pages');
define('BACKUPS_ROOT', CACHE_ROOT . '/backups');
define('ORIGINALS_ROOT', CACHE_ROOT . '/originals');
define('UPLOADS_ROOT', PUBLIC_ROOT . '/uploads');
// URL-Pfad, unter dem api/upload.php hochgeladene Dateien ausliefert (Bildfelder speichern ihn so).
const UPLOADS_URL = '/public/uploads/';
// Erlaubte Endungen für Uploads (siehe AGENTS.md, Upload-Whitelist) mit den MIME-Typen, die der
// Inhalt dazu haben muss (sonst landet z. B. ein SVG als .jpg an der Skript-Prüfung vorbei).
const UPLOAD_MIME_TYPES = [
    'jpg' => ['image/jpeg'],
    'jpeg' => ['image/jpeg'],
    'png' => ['image/png'],
    'webp' => ['image/webp'],
    'svg' => ['image/svg+xml', 'text/xml', 'application/xml'],
];
// Eigene Obergrenze für Uploads; wirksam ist das Minimum mit der PHP-Konfiguration (upload_max_bytes()).
const UPLOAD_MAX_BYTES = 5 * 1024 * 1024;
// Meldungen von api/upload.php (auch im Browser: upload_config()).
const UPLOAD_TEXT = [
    'noFile' => 'Es wurde keine Datei hochgeladen.',
    'failed' => 'Das Hochladen ist fehlgeschlagen.',
    'tooLarge' => 'Das Bild ist größer als %s MB.',
    'type' => 'Dieser Dateityp ist nicht erlaubt (erlaubt: %s).',
    'content' => 'Der Inhalt der Datei passt nicht zu ihrer Endung.',
    'svg' => 'SVG enthält Skripte oder externe Verweise und wurde abgelehnt.',
    'store' => 'Das Bild konnte nicht gespeichert werden.',
];
const BYTES_PER_MB = 1024 * 1024;
// Meldungen der API-Endpoints und des Kerns (json_response 'error'), wie der Browser sie zeigt.
// %s: Datei bzw. Fehler der Gegenstelle, nie ein Serverpfad.
const API_TEXT = [
    'method' => 'Diese Anfrage-Methode ist hier nicht erlaubt.',
    'invalidRequest' => 'Ungültige Anfrage.',
    'invalidJson' => 'Die Anfrage enthält kein gültiges JSON.',
    'invalidPageName' => 'Ungültiger Seitenname.',
    'invalidContent' => 'Ungültige Inhalte.',
    'invalidType' => 'Unbekannter Typ.',
    'invalidId' => 'Ungültige ID.',
    'invalidTarget' => 'Ungültiges Ziel.',
    'notFound' => 'Nicht gefunden.',
    'notAuthenticated' => 'Du bist nicht mehr angemeldet. Bitte melde dich neu an.',
    'passwordChange' => 'Bitte lege zuerst ein neues Passwort fest.',
    'forbidden' => 'Dafür fehlen dir die Rechte.',
    'csrf' => 'Die Anmeldung wurde erneuert. Bitte lade die Seite neu.',
    'invalidCredentials' => 'Benutzername oder Passwort ist falsch.',
    'userNotFound' => 'Benutzer nicht gefunden.',
    'usernameTaken' => 'Dieser Benutzername ist schon vergeben.',
    'userIdRequired' => 'Benutzer-ID fehlt.',
    'wrongPassword' => 'Das aktuelle Passwort stimmt nicht.',
    'lastAdminDemote' => 'Der letzte Administrator kann nicht herabgestuft werden.',
    'lastAdminDelete' => 'Der letzte Administrator kann nicht gelöscht werden.',
    'deleteSelf' => 'Das eigene Konto kann nicht gelöscht werden.',
    'pageNotFound' => 'Seite nicht gefunden.',
    'pageInvalid' => 'Die gespeicherten Inhalte dieser Seite sind beschädigt.',
    'invalidBackup' => 'Ungültiger Name eines gespeicherten Stands.',
    'backupNotFound' => 'Diesen gespeicherten Stand gibt es nicht mehr.',
    'backupInvalid' => 'Dieser gespeicherte Stand ist beschädigt.',
    'backupFailed' => 'Der bisherige Stand ließ sich nicht sichern.',
    // Server lässt nicht schreiben (write_failed_message): vorab erkannt mit den betroffenen Namen
    // (writeFailedNames), mittendrin ohne; dazu, wer helfen kann (contactSupport).
    'writeFailed' => 'Nichts gespeichert: Der Server lässt keine Änderung zu%s.',
    'writeFailedNames' => ' (%s)',
    'contactSupport' => 'Bitte gib LEWEB Bescheid.',
    'lockFailed' => 'Die Seite ließ sich nicht sperren.',
    'encodeFailed' => 'Die Inhalte ließen sich nicht speichern.',
    'importStatusFailed' => 'Der Import-Status ließ sich nicht speichern.',
    'invalidPlugin' => 'Ungültiger Plugin-Name.',
    'pluginNotFound' => 'Plugin nicht gefunden.',
    'pluginNotInstalled' => 'Das Plugin ist nicht installiert.',
    'pluginNotActive' => 'Das Plugin ist nicht aktiv.',
    'noMainTable' => 'Das Plugin hat keine Haupttabelle.',
    'noValidFields' => 'Keine gültigen Felder.',
    'uninstallFailed' => 'Deinstallieren fehlgeschlagen: %s',
    'dbFieldsRequired' => 'Host, Datenbankname und Benutzer sind Pflicht.',
    'connectionFailed' => 'Verbindung fehlgeschlagen: %s',
    // %1$s: SQL-Datei des Plugins, %2$s: Fehler der Datenbank.
    'installSqlFailed' => '%1$s ist fehlgeschlagen: %2$s',
    'testRecipient' => 'Gültige Test-Empfänger-Adresse erforderlich.',
    'samePassword' => 'Bitte ein anderes Passwort wählen.',
];
// Zugangsdaten (db.config.php, mail.config.php): unter content/, damit Backups
// sie erfassen und Updates sie nicht anfassen.
define('CONFIG_ROOT', CONTENT_ROOT . '/config');
// Plugin-Daten in SQLite (Standard, solange keine MySQL-Config existiert).
define('DATA_ROOT', CONTENT_ROOT . '/data');
// Altdaten nach einem Treiber-Umzug (nicht im Cache, damit sie im Backup landen).
define('DB_ARCHIVE_ROOT', CONTENT_ROOT . '/db-archiv');
// Zeitzone für Veröffentlichungszeiten und Zeitstempel, falls der Hoster im
// php.ini keine setzt. PHP < 8.4 meldet dann '', ab 8.4 den Standard 'UTC' –
// beides gilt als „nicht gesetzt“.
const APP_TIMEZONE = 'Europe/Vienna';
// Rechte für Dateien mit Geheimnissen (Zugangsdaten, Schlüssel, Benutzer, SQLite).
const PRIVATE_FILE_MODE = 0600;
if (in_array((string) ini_get('date.timezone'), ['', 'UTC'], true)) {
    date_default_timezone_set(APP_TIMEZONE);
}
// Zeitangaben für Menschen (day_time_label): Kalendertag als heute, gestern oder Datum, dazu die Uhrzeit.
const DAY_LABEL_TODAY = 'heute';
const DAY_LABEL_YESTERDAY = 'gestern';
const DAY_LABEL_DATE_FORMAT = 'd.m.Y';
const DAY_LABEL_TIME_FORMAT = 'H:i';

/** „heute, 03:12“, „gestern, 03:12“ oder „12.10.2026, 03:12“ – Kalendertage in der App-Zeitzone. */
function day_time_label(int $ts, int $now): string
{
    $zone = new DateTimeZone(date_default_timezone_get());
    $time = (new DateTimeImmutable('@' . $ts))->setTimezone($zone);
    $today = (new DateTimeImmutable('@' . $now))->setTimezone($zone);
    $day = $time->format('Y-m-d');
    if ($day === $today->format('Y-m-d')) {
        $label = DAY_LABEL_TODAY;
    } elseif ($day === $today->modify('-1 day')->format('Y-m-d')) {
        $label = DAY_LABEL_YESTERDAY;
    } else {
        $label = $time->format(DAY_LABEL_DATE_FORMAT);
    }
    return $label . ', ' . $time->format(DAY_LABEL_TIME_FORMAT);
}

/** Größe aus der php.ini („2M“, „512K“, „1G“, Bytes) in Bytes; null ohne Grenze („0“, leer). */
function ini_size_bytes(string $value): ?int
{
    $value = trim($value);
    $factors = ['k' => 1024, 'm' => 1024 ** 2, 'g' => 1024 ** 3];
    $bytes = (int) $value * ($factors[strtolower(substr($value, -1))] ?? 1);
    return $bytes > 0 ? $bytes : null;
}

/** Größte Datei, die tatsächlich ankommt: UPLOAD_MAX_BYTES, upload_max_filesize und post_max_size. */
function upload_max_bytes(): int
{
    $limits = [UPLOAD_MAX_BYTES];
    foreach (['upload_max_filesize', 'post_max_size'] as $setting) {
        $bytes = ini_size_bytes((string) ini_get($setting));
        if ($bytes !== null) {
            $limits[] = $bytes;
        }
    }
    return min($limits);
}

/** „Das Bild ist größer als 2 MB.“ mit der wirksamen Grenze (eine Nachkommastelle, deutsches Komma). */
function upload_too_large_message(): string
{
    $megabytes = rtrim(rtrim(number_format(upload_max_bytes() / BYTES_PER_MB, 1, ',', ''), '0'), ',');
    return sprintf(UPLOAD_TEXT['tooLarge'], $megabytes);
}

/** Für die Dateiauswahl im Browser: accept, Größenprüfung vor dem Upload und ihre Meldung. */
function upload_config(): array
{
    return [
        'extensions' => array_keys(UPLOAD_MIME_TYPES),
        'maxBytes' => upload_max_bytes(),
        'tooLarge' => upload_too_large_message(),
    ];
}

function ensure_dir(string $path): void
{
    if (!is_dir($path) && !mkdir($path, 0775, true) && !is_dir($path)) {
        throw new RuntimeException('Cannot create directory: ' . $path);
    }
}

/**
 * Nach dem Schreiben einer Datei: OPcache vergisst ihre übersetzte Fassung, damit der nächste Aufruf
 * die neue ausführt. Seiten, Kopf-/Fußzeile und Konfigurationen sind PHP; Hoster prüfen die
 * Zeitstempel oft selten oder nie (opcache.validate_timestamps=0). Ohne OPcache tut es nichts.
 */
function forget_compiled_file(string $path): void
{
    if (function_exists('opcache_invalidate')) {
        @opcache_invalidate($path, true);
    }
}

/** forget_compiled_file für eine Datei bzw. alle PHP-Dateien eines Ordners (Auto-Update tauscht ganze Ordner). */
function forget_compiled_tree(string $path): void
{
    if (!is_dir($path)) {
        forget_compiled_file($path);
        return;
    }
    foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS)) as $file) {
        if ($file->isFile() && strtolower($file->getExtension()) === 'php') {
            forget_compiled_file($file->getPathname());
        }
    }
}

/** Schreibt eine Datei atomar und nur für den Eigentümer lesbar (PRIVATE_FILE_MODE). */
function write_private_file(string $path, string $content): void
{
    ensure_dir(dirname($path));
    $tmp = $path . '.' . bin2hex(random_bytes(4)) . '.tmp';
    // Erst leer anlegen und Rechte setzen, dann schreiben: Der Inhalt ist
    // nie mit den Standardrechten lesbar.
    if (!@touch($tmp) || !@chmod($tmp, PRIVATE_FILE_MODE) || @file_put_contents($tmp, $content, LOCK_EX) === false) {
        @unlink($tmp);
        throw new RuntimeException('Cannot write ' . basename($path));
    }
    if (!@rename($tmp, $path)) {
        @unlink($tmp);
        throw new RuntimeException('Cannot finalize ' . basename($path));
    }
    @chmod($path, PRIVATE_FILE_MODE);
    forget_compiled_file($path);
}

/** Namen der Einträge eines Ordners (ohne . und ..); leer, wenn es ihn nicht gibt. */
function dir_entries(string $dir): array
{
    return is_dir($dir) ? array_values(array_diff(scandir($dir) ?: [], ['.', '..'])) : [];
}

/** Darf ein ZIP-Eintrag so entpackt werden (kein Ausbruch aus dem Zielordner)? */
function zip_entry_name_safe(string $name): bool
{
    if ($name === '' || str_contains($name, '\\') || str_contains($name, ':')) {
        return false;
    }
    // Nur ganze Pfad-Segmente zählen: „wien..jpg“ ist ein gültiger Dateiname.
    // Ein Schrägstrich am Ende kennzeichnet einen Ordner-Eintrag.
    return !array_intersect(explode('/', rtrim($name, '/')), ['..', '.', '']);
}

function json_response(array $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function read_json_body(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return [];
    }

    $data = json_decode($raw, true);
    if (!is_array($data)) {
        json_response(['ok' => false, 'error' => API_TEXT['invalidJson']], 400);
    }

    return $data;
}

/** Seitenname nach der Whitelist (Buchstaben, Ziffern, _ und -), ohne die Anfrage abzubrechen. */
function is_safe_page_name(string $page): bool
{
    return preg_match('/^[a-zA-Z0-9_-]+$/', $page) === 1;
}

function safe_page_name(string $page): string
{
    $page = trim($page);
    if (!is_safe_page_name($page)) {
        json_response(['ok' => false, 'error' => API_TEXT['invalidPageName']], 400);
    }

    return $page;
}

function sanitize_text_value(mixed $value): string
{
    if (!is_scalar($value)) {
        return '';
    }

    $clean = strip_tags((string) $value, '<br>');
    // strip_tags keeps attributes on allowed tags — normalize <br foo="…"> to plain <br>
    $clean = preg_replace('/<br\b[^>]*>/i', '<br>', $clean) ?? $clean;
    return trim($clean);
}

function flatten_content(array $content, string $prefix = ''): array
{
    $flat = [];
    foreach ($content as $key => $value) {
        $path = $prefix === '' ? (string) $key : $prefix . '.' . $key;
        if (is_array($value)) {
            $flat += flatten_content($value, $path);
        } else {
            $flat[$path] = $value;
        }
    }

    return $flat;
}

/** Gegenstück zu flatten_content: Pfad → Wert wird wieder ein Baum. */
function unflatten_content(array $flat): array
{
    $tree = [];
    foreach ($flat as $path => $value) {
        set_nested_value($tree, (string) $path, $value);
    }
    return $tree;
}

function set_nested_value(array &$target, string $path, mixed $value): void
{
    $parts = explode('.', $path);
    $cursor = &$target;
    foreach ($parts as $index => $part) {
        if ($index === count($parts) - 1) {
            $cursor[$part] = $value;
            return;
        }

        if (!isset($cursor[$part]) || !is_array($cursor[$part])) {
            $cursor[$part] = [];
        }
        $cursor = &$cursor[$part];
    }
}

/**
 * Zufälliger Schlüssel pro Installation (HMAC für Formular-Signaturen,
 * Rate-Limit-Dateinamen). Wird beim ersten Aufruf erzeugt und liegt in
 * content/, das weder ausgeliefert noch vom Update angefasst wird.
 */
function app_secret(): string
{
    static $secret = null;
    if ($secret !== null) {
        return $secret;
    }

    $path = CONTENT_ROOT . '/secret.key';
    $existing = is_file($path) ? trim((string) file_get_contents($path)) : '';
    if (strlen($existing) >= 64) {
        return $secret = $existing;
    }

    ensure_dir(CONTENT_ROOT);
    $new = bin2hex(random_bytes(32));
    $tmp = $path . '.' . bin2hex(random_bytes(4)) . '.tmp';
    if (file_put_contents($tmp, $new) === false || !rename($tmp, $path)) {
        @unlink($tmp);
        throw new RuntimeException('Cannot create app secret: ' . $path);
    }
    @chmod($path, PRIVATE_FILE_MODE);

    return $secret = $new;
}

function current_iso_time(): string
{
    return gmdate('Y-m-d\TH:i:s\Z');
}

// Namen der Komponenten für Kunden (Nachfrage beim Wiederherstellen im Verlauf).
const COMPONENT_LABELS = ['header' => 'Kopfzeile', 'footer' => 'Fußzeile'];

function shared_components(): array
{
    return [
        'header' => SITE_ROOT . '/includes/navigation.php',
        'footer' => SITE_ROOT . '/includes/footer.php',
    ];
}

/**
 * SVG darf nur rein, wenn es nichts Ausführbares enthält. Lieber zu streng
 * als zu lax: abgelehnt wird, was nicht nach reiner Grafik aussieht.
 */
function svg_is_safe(string $svg): bool
{
    if (stripos($svg, '<!ENTITY') !== false || stripos($svg, '<!DOCTYPE') !== false) {
        return false;
    }

    $doc = new DOMDocument();
    $previous = libxml_use_internal_errors(true);
    $loaded = $doc->loadXML($svg, LIBXML_NONET);
    libxml_clear_errors();
    libxml_use_internal_errors($previous);
    if (!$loaded || $doc->documentElement === null || strtolower($doc->documentElement->localName) !== 'svg') {
        return false;
    }

    $forbiddenElements = ['script', 'foreignobject', 'iframe', 'embed', 'object', 'handler', 'listener'];
    foreach ($doc->getElementsByTagName('*') as $element) {
        $name = strtolower($element->localName);
        if (in_array($name, $forbiddenElements, true)) {
            return false;
        }
        foreach ($element->attributes as $attr) {
            $attrName = strtolower($attr->localName);
            $value = strtolower((string) preg_replace('/[\s\x00-\x1f]+/', '', $attr->value));
            if (str_starts_with($attrName, 'on')) {
                return false;
            }
            if (str_contains($value, 'javascript:') || str_contains($value, 'data:text') || str_contains($value, 'data:image/svg')) {
                return false;
            }
            // Verweise nur innerhalb der Datei (#id) oder auf eingebettete Rastergrafiken.
            if ($attrName === 'href' && $value !== '' && !str_starts_with($value, '#') && !preg_match('#^data:image/(png|jpe?g|gif|webp);#', $value)) {
                return false;
            }
            // <animate attributeName="href" …> könnte einen Link nachträglich umbiegen.
            if ($attrName === 'attributename' && str_contains($value, 'href')) {
                return false;
            }
        }
    }

    return true;
}

const UPLOADS_HTACCESS = <<<'HTACCESS'
# Vom Live-Editor angelegt. Uploads sind reine Dateien: nichts ausführen,
# SVGs ohne Skripte ausliefern.
<IfModule mod_headers.c>
  Header set X-Content-Type-Options "nosniff"
  <FilesMatch "(?i)\.svg$">
    Header set Content-Security-Policy "default-src 'none'; img-src data:; style-src 'unsafe-inline'; sandbox"
  </FilesMatch>
</IfModule>
<FilesMatch "(?i)\.(php[0-9]?|phtml|phar|cgi|pl|py|sh)$">
  <IfModule mod_authz_core.c>
    Require all denied
  </IfModule>
  <IfModule !mod_authz_core.c>
    Order deny,allow
    Deny from all
  </IfModule>
</FilesMatch>

HTACCESS;

