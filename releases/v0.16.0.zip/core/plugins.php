<?php
declare(strict_types=1);

require_once __DIR__ . '/utils.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/textMarkup.php';

define('PLUGINS_ROOT', PROJECT_ROOT . '/plugins');
// URL-Pfad, unter dem Plugin-Dateien (api/*.php) erreichbar sind.
const PLUGINS_URL = '/plugins/';
// Schema-Dateien je Treiber: install.sql / install.sqlite.sql usw.
const PLUGIN_SQL_SUFFIX = [
    DB_DRIVER_MYSQL  => '.sql',
    DB_DRIVER_SQLITE => '.sqlite.sql',
];
// plugin.json „inlineEdit“: Endpoints für Plugin-Listen auf der Seite; Wert = Pflicht.
const PLUGIN_INLINE_EDIT_ENDPOINTS = ['list' => true, 'get' => true, 'save' => true, 'delete' => true, 'sort' => false];
// Markierungen, an denen der Seiten-Editor Plugin-Listen und ihre Einträge erkennt.
const LE_LIST_ATTR = 'data-le-list';
const LE_ITEM_ATTR = 'data-le-item';
const LE_SINGLE_ATTR = 'data-le-single';
// Wert der Markierung: "<plugin>/<typ>" (Plugin bis zum ersten Trenner).
const LE_KEY_SEPARATOR = '/';
// Richtungen beim Sortieren (inlineEdit „sort“: {type, id, direction}).
const INLINE_EDIT_SORT_UP = 'up';
const INLINE_EDIT_SORT_DOWN = 'down';

function plugin_name_valid(string $name): bool
{
    return (bool) preg_match('/^[a-z][a-z0-9_-]*$/', $name);
}

function plugin_table_name_valid(string $name): bool
{
    return (bool) preg_match('/^[a-z][a-z0-9_]*$/', $name);
}

function plugin_path(string $name, string $sub = ''): string
{
    if (!plugin_name_valid($name)) {
        throw new InvalidArgumentException('Invalid plugin name: ' . $name);
    }

    $base = PLUGINS_ROOT . '/' . $name;
    if ($sub === '') {
        return $base;
    }

    $normalized = str_replace('\\', '/', ltrim($sub, '/'));
    if ($normalized === '' || str_contains($normalized, '..')) {
        throw new InvalidArgumentException('Invalid plugin path: ' . $sub);
    }

    return $base . '/' . $normalized;
}

/** Pfad der install-/uninstall-Datei für den aktiven (oder angegebenen) Treiber. */
function plugin_sql_path(string $name, string $kind, ?string $driver = null): string
{
    if ($kind !== 'install' && $kind !== 'uninstall') {
        throw new InvalidArgumentException('Invalid sql kind: ' . $kind);
    }
    return plugin_path($name, $kind . PLUGIN_SQL_SUFFIX[$driver ?? db_driver()]);
}

/** Meldung, wenn einem Plugin die install-Datei für einen Treiber fehlt. */
function plugin_schema_missing_message(string $name, string $driver): string
{
    return 'Dem Plugin ' . $name . ' fehlt ' . basename(plugin_sql_path($name, 'install', $driver)) . ' für die Datenbank ' . $driver . '.';
}

function plugin_manifest(string $name): array
{
    static $cache = [];

    if (!plugin_name_valid($name)) {
        throw new InvalidArgumentException('Invalid plugin name: ' . $name);
    }
    if (isset($cache[$name])) {
        return $cache[$name];
    }

    $path = plugin_path($name, 'plugin.json');
    if (!is_file($path)) {
        throw new RuntimeException('Plugin manifest not found: ' . $name);
    }

    $data = json_decode((string) file_get_contents($path), true);
    if (!is_array($data)) {
        throw new RuntimeException('Invalid plugin manifest JSON: ' . $name);
    }
    if (($data['name'] ?? '') !== $name) {
        throw new RuntimeException('Plugin manifest name mismatch: ' . $name);
    }
    foreach (['label', 'version', 'requires'] as $required) {
        if (!array_key_exists($required, $data)) {
            throw new RuntimeException('Missing plugin manifest key "' . $required . '": ' . $name);
        }
    }

    $data['requires'] = array_merge(
        ['database' => false, 'mail' => false, 'uploads' => false],
        is_array($data['requires']) ? $data['requires'] : []
    );
    $data['tables'] = plugin_valid_tables($data['tables'] ?? []);
    if (array_key_exists('inlineEdit', $data)) {
        $data['inlineEdit'] = plugin_valid_inline_edit($name, $data['inlineEdit']);
    }

    $cache[$name] = $data;
    return $data;
}

function plugin_valid_tables(mixed $tables): array
{
    if (!is_array($tables)) {
        return [];
    }

    $valid = [];
    foreach ($tables as $table) {
        if (is_string($table) && plugin_table_name_valid($table)) {
            $valid[] = $table;
        }
    }

    return array_values(array_unique($valid));
}

/**
 * inlineEdit aus plugin.json: je Aktion ein Pfad „api/<datei>.php“ (optional mit fester Query),
 * der im Plugin existiert. list, get, save, delete sind Pflicht, sort nur bei Plugins mit Reihenfolge.
 */
function plugin_valid_inline_edit(string $name, mixed $inlineEdit): array
{
    $error = new RuntimeException('Invalid plugin manifest key "inlineEdit": ' . $name);
    if (!is_array($inlineEdit) || array_diff_key($inlineEdit, PLUGIN_INLINE_EDIT_ENDPOINTS) !== []) {
        throw $error;
    }

    $valid = [];
    foreach (PLUGIN_INLINE_EDIT_ENDPOINTS as $action => $required) {
        $endpoint = $inlineEdit[$action] ?? null;
        if ($endpoint === null && !$required) {
            continue;
        }
        if (!is_string($endpoint) || !preg_match('#^api/[a-z0-9_-]+\.php(\?[a-z0-9_=&-]+)?$#i', $endpoint)
            || !is_file(plugin_path($name, (string) strtok($endpoint, '?')))) {
            throw $error;
        }
        $valid[$action] = $endpoint;
    }

    return $valid;
}

/** URLs der inlineEdit-Endpoints aller aktiven Plugins, die mitmachen: [Plugin => [Aktion => URL]]. */
function plugin_inline_edit_config(): array
{
    $config = [];
    foreach (load_plugins_state()['active'] as $name) {
        try {
            $inlineEdit = plugin_manifest($name)['inlineEdit'] ?? null;
        } catch (Throwable $e) {
            continue;
        }
        if ($inlineEdit === null) {
            continue;
        }
        $config[$name] = array_map(static fn (string $endpoint): string => PLUGINS_URL . $name . '/' . $endpoint, $inlineEdit);
    }

    return $config;
}

/** Was der Seiten-Editor für Plugin-Listen braucht: Endpoints, Markierungen, Trenner, Sortier-Richtungen. */
function plugin_lists_config(): array
{
    return [
        'endpoints' => plugin_inline_edit_config(),
        'attrs' => ['list' => LE_LIST_ATTR, 'item' => LE_ITEM_ATTR, 'single' => LE_SINGLE_ATTR],
        'separator' => LE_KEY_SEPARATOR,
        'directions' => ['up' => INLINE_EDIT_SORT_UP, 'down' => INLINE_EDIT_SORT_DOWN],
    ];
}

/** Attribut, das eine Plugin-Liste für den Seiten-Editor markiert (escaped, auch für Besucher). */
function le_list_attrs(string $plugin, string $type): string
{
    return LE_LIST_ATTR . '="' . markup_attr_escape($plugin . LE_KEY_SEPARATOR . $type) . '"';
}

/** Attribut, das einen Eintrag einer Plugin-Liste markiert. */
function le_item_attrs(int $id): string
{
    return LE_ITEM_ATTR . '="' . $id . '"';
}

/**
 * Attribute für die Einzelansicht eines Eintrags (z. B. Blog-Beitrag): bearbeitbar wie ein Listeneintrag,
 * aber keine Liste (kein „+ Hinzufügen“).
 */
function le_single_attrs(string $plugin, string $type, int $id): string
{
    return LE_SINGLE_ATTR . '="' . markup_attr_escape($plugin . LE_KEY_SEPARATOR . $type) . '" ' . le_item_attrs($id);
}

function list_plugin_dirs(): array
{
    if (!is_dir(PLUGINS_ROOT)) {
        return [];
    }

    $names = [];
    foreach (scandir(PLUGINS_ROOT) ?: [] as $entry) {
        if ($entry === '.' || $entry === '..' || !plugin_name_valid($entry)) {
            continue;
        }
        if (!is_dir(PLUGINS_ROOT . '/' . $entry)) {
            continue;
        }
        if (!is_file(PLUGINS_ROOT . '/' . $entry . '/plugin.json')) {
            continue;
        }
        $names[] = $entry;
    }
    sort($names);

    return $names;
}

function plugins_state_path(): string
{
    return CONTENT_ROOT . '/active-plugins.json';
}

function plugin_data_path(string $name): string
{
    if (!plugin_name_valid($name)) {
        throw new InvalidArgumentException('Invalid plugin name: ' . $name);
    }
    return CONTENT_ROOT . '/plugins/' . $name;
}

function load_plugins_state(): array
{
    $path = plugins_state_path();
    if (!is_file($path)) {
        return ['active' => [], 'installed' => []];
    }

    $data = json_decode((string) file_get_contents($path), true);
    if (!is_array($data)) {
        return ['active' => [], 'installed' => []];
    }

    $active = [];
    foreach (($data['active'] ?? []) as $name) {
        if (is_string($name) && plugin_name_valid($name)) {
            $active[] = $name;
        }
    }

    $installed = [];
    if (is_array($data['installed'] ?? null)) {
        foreach ($data['installed'] as $name => $meta) {
            if (!is_string($name) || !plugin_name_valid($name) || !is_array($meta)) {
                continue;
            }
            $meta['tables'] = plugin_valid_tables($meta['tables'] ?? []);
            $installed[$name] = $meta;
        }
    }

    return [
        'active' => array_values(array_unique($active)),
        'installed' => $installed,
    ];
}

function save_plugins_state(array $state): void
{
    $path = plugins_state_path();

    $active = [];
    foreach (($state['active'] ?? []) as $name) {
        if (is_string($name) && plugin_name_valid($name)) {
            $active[] = $name;
        }
    }

    $installed = [];
    if (is_array($state['installed'] ?? null)) {
        foreach ($state['installed'] as $name => $meta) {
            if (!is_string($name) || !plugin_name_valid($name) || !is_array($meta)) {
                continue;
            }
            $meta['tables'] = plugin_valid_tables($meta['tables'] ?? []);
            $installed[$name] = $meta;
        }
    }

    $payload = [
        'active' => array_values(array_unique($active)),
        'installed' => empty($installed) ? new stdClass() : $installed,
    ];

    ensure_dir(dirname($path));
    $json = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        throw new RuntimeException('Cannot encode active-plugins.json');
    }

    $tmp = $path . '.tmp';
    if (file_put_contents($tmp, $json . PHP_EOL, LOCK_EX) === false) {
        throw new RuntimeException('Cannot write active-plugins.json');
    }
    if (!rename($tmp, $path)) {
        @unlink($tmp);
        throw new RuntimeException('Cannot finalize active-plugins.json');
    }
}

function plugin_active(string $name): bool
{
    if (!plugin_name_valid($name)) {
        return false;
    }

    $state = load_plugins_state();
    return in_array($name, $state['active'], true);
}

function require_plugin_active(string $name): void
{
    if (!plugin_active($name)) {
        json_response(['ok' => false, 'error' => API_TEXT['pluginNotActive']], 404);
    }
    // Zentrale Sperre während eines Datenumzugs: schreibende Requests von
    // Plugins mit Datenbank → 503, Lesen läuft weiter aus der alten Quelle.
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if ($method !== 'GET' && $method !== 'HEAD' && !empty(plugin_manifest($name)['requires']['database'])) {
        require_no_db_migration();
    }
}

function plugin_installed(string $name): bool
{
    if (!plugin_name_valid($name)) {
        return false;
    }

    $state = load_plugins_state();
    return isset($state['installed'][$name]);
}

/**
 * Tabellen installierter Plugins, die in der Datenbank fehlen, aus install.sql
 * neu anlegen. Passiert, wenn active-plugins.json ohne die Datenbank ankommt
 * (frische Installation aus dem Repo, gelöschte site.sqlite, neue MySQL-DB).
 * Fehler landen im Log; der eigentliche Request meldet dann „no such table“.
 * Nicht auf der Kommandozeile: Restore und Umzug legen Tabellen selbst an.
 */
function plugin_restore_missing_tables(PDO $pdo): void
{
    if (PHP_SAPI === 'cli' || db_migration_running()) {
        return;
    }
    $driver = db_driver();
    foreach (load_plugins_state()['installed'] as $name => $meta) {
        $tables = $meta['tables'] ?? [];
        $missing = array_filter($tables, static fn (string $table): bool => !db_table_exists($pdo, $table));
        if ($missing === []) {
            continue;
        }
        $sqlPath = plugin_sql_path($name, 'install', $driver);
        if (!is_file($sqlPath)) {
            error_log(plugin_schema_missing_message($name, $driver));
            continue;
        }
        try {
            db_run_schema($pdo, $driver, (string) file_get_contents($sqlPath), $tables);
        } catch (Throwable $e) {
            error_log('plugin ' . $name . ': ' . sprintf(API_TEXT['installSqlFailed'], basename($sqlPath), $e->getMessage()));
        }
    }
}

function plugin_has_admin_sidebar(array $manifest): bool
{
    return is_array($manifest['admin']['sidebar'] ?? null);
}

function active_plugin_admin_info(): array
{
    $state = load_plugins_state();
    $info = [];

    foreach ($state['active'] as $name) {
        try {
            $manifest = plugin_manifest($name);
        } catch (Throwable $e) {
            continue;
        }
        if (!plugin_has_admin_sidebar($manifest)) {
            continue;
        }

        $extra = plugin_extra_sidebar_entries($name);
        if ($extra !== null) {
            foreach ($extra as $entry) {
                $info[] = $entry;
            }
            continue;
        }

        $sidebar = $manifest['admin']['sidebar'];
        $module = plugin_admin_module_path($manifest);
        $info[] = [
            'name' => $name,
            'route' => $name,
            'label' => (string) ($sidebar['label'] ?? $manifest['label'] ?? $name),
            'hasAdminModule' => $module !== null,
            'hasSchema' => isset($manifest['schema']['fields']) && is_array($manifest['schema']['fields']),
        ];
    }

    return $info;
}

/** Hook-Funktion „<plugin>_<hook>“ aus der lib.php des Plugins (siehe knowledgebase/hooks.md), null ohne. */
function plugin_hook_function(string $name, string $hook): ?string
{
    if (!plugin_name_valid($name)) {
        return null;
    }
    $libPath = plugin_path($name, 'lib.php');
    if (!is_file($libPath)) {
        return null;
    }
    require_once $libPath;
    $fn = str_replace('-', '_', $name) . '_' . $hook;

    return function_exists($fn) ? $fn : null;
}

function plugin_extra_sidebar_entries(string $name): ?array
{
    $fn = plugin_hook_function($name, 'admin_sidebar_entries');
    if ($fn === null) {
        return null;
    }

    try {
        $entries = $fn();
    } catch (Throwable $e) {
        return null;
    }
    if (!is_array($entries)) {
        return null;
    }

    $valid = [];
    foreach ($entries as $entry) {
        if (!is_array($entry)) {
            continue;
        }
        $route = $entry['route'] ?? null;
        $label = $entry['label'] ?? null;
        if (!is_string($route) || !is_string($label) || $label === '') {
            continue;
        }
        if (!preg_match('/^[a-z][a-z0-9_-]*(\/[a-z][a-z0-9_-]+)*$/', $route)) {
            continue;
        }
        $entry['name'] = $name;
        $entry['route'] = $route;
        $entry['label'] = $label;
        $entry['hasAdminModule'] = !empty($entry['hasAdminModule']);
        $entry['hasSchema'] = !empty($entry['hasSchema']);
        $valid[] = $entry;
    }

    return $valid;
}

function plugin_admin_module_path(array $manifest): ?string
{
    $module = $manifest['admin']['sidebar']['module'] ?? null;
    if (!is_string($module) || trim($module) === '') {
        return null;
    }
    if (str_contains(str_replace('\\', '/', $module), '..')) {
        return null;
    }

    return $module;
}

function filter_site_html(string $html): string
{
    $state = load_plugins_state();
    foreach ($state['active'] as $name) {
        $fn = plugin_hook_function($name, 'filter_site_html');
        if ($fn === null) {
            continue;
        }
        try {
            $next = $fn($html);
        } catch (Throwable $e) {
            error_log('filter_site_html ' . $name . ' failed: ' . $e->getMessage());
            continue;
        }
        if (is_string($next)) {
            $html = $next;
        }
    }

    return $html;
}

function plugin_sanitize_richtext(string $html): string
{
    $allowed = '<p><br><strong><b><em><i><u><ul><ol><li><a><blockquote><h2><h3><h4>';
    $clean = strip_tags($html, $allowed);
    // Start-Tags über den Zerleger neu aufbauen, damit jede Schreibweise (ohne Anführungszeichen,
    // ohne Leerraum zwischen Attributen) gleich behandelt wird.
    $clean = preg_replace_callback('/<[a-z](?:[^>"\']|"[^"]*"|\'[^\']*\')*>/i', static fn (array $m): string => plugin_richtext_tag($m[0]), $clean) ?? '';

    return trim($clean);
}

/**
 * Ein Start-Tag ohne on*- und style-Attribute; href nach derselben Regel wie Textfelder
 * (core/textMarkup.php), ein unerlaubtes Schema verliert das href.
 */
function plugin_richtext_tag(string $tag): string
{
    $doc = markup_parse($tag);
    $node = $doc['nodes'][$doc['roots'][0]];
    $out = '<' . $node['tag'];
    $seen = [];
    foreach ($node['attrs'] as $attr) {
        $name = strtolower($attr['name']);
        if (isset($seen[$name]) || $attr['has_php'] || str_starts_with($name, 'on') || $name === 'style' || !preg_match('/^[a-z][a-z0-9_:.-]*$/', $name)) {
            continue;
        }
        $seen[$name] = true;
        // Erstes Attribut dieses Namens (Doppelte übersprungen); ohne Wert (hidden, download) leer.
        $value = markup_attr_text($node, $name);
        if ($name === 'href') {
            $value = sanitize_url($value, TEXT_LINK_SCHEMES);
            if ($value === '') {
                continue;
            }
        }
        $out .= ' ' . $name . '="' . markup_attr_escape($value) . '"';
    }
    return $out . '>';
}
