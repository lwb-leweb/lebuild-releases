<?php
declare(strict_types=1);

// Hochgeladene Dateien wieder entfernen, sobald nichts mehr auf sie verweist
// (z. B. beim Löschen eines Plugin-Eintrags). Verweise zählen als Treffer des
// Dateinamens (zufälliger Suffix aus api/upload.php). Im Zweifel bleibt die
// Datei liegen: ein falscher Treffer, eine unlesbare Datei oder ein Fehler bei
// der Suche zählen als „verwendet“.

require_once __DIR__ . '/utils.php';
require_once __DIR__ . '/plugins.php';
require_once __DIR__ . '/pluginSchema.php';

// Hier können Seiten auf Uploads verweisen: Seiten-JSON, Seiten-Backups, Snapshots der Quelldateien, Site-Dateien.
const UPLOAD_REFERENCE_ROOTS = [PAGES_ROOT, BACKUPS_ROOT, ORIGINALS_ROOT, SITE_ROOT];
// Binärdateien mit diesen Endungen werden nicht durchsucht; alle anderen Dateien gelten als Text.
const UPLOAD_REFERENCE_SKIP_EXTENSIONS = [
    'jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'ico', 'bmp', 'tif', 'tiff',
    'mp4', 'mov', 'webm', 'm4v', 'avi', 'mkv', 'mp3', 'wav', 'ogg', 'm4a',
    'woff', 'woff2', 'ttf', 'otf', 'eot', 'pdf', 'zip', 'gz', 'tar', '7z', 'rar',
];
// Größere Dateien werden nicht eingelesen, sondern zählen als Verwendung (im Zweifel behalten).
const UPLOAD_REFERENCE_MAX_BYTES = 5 * 1024 * 1024;

/**
 * Dateiname in UPLOADS_ROOT zu einem Bildwert wie „/public/uploads/x.png“; null für alles andere
 * (fremde Pfade, Unterordner, Traversal, versteckte Dateien, Endungen außerhalb der Upload-Whitelist).
 */
function upload_file_name(string $url): ?string
{
    if (!str_starts_with($url, UPLOADS_URL)) {
        return null;
    }
    $file = substr($url, strlen(UPLOADS_URL));
    if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]*$/', $file)
        || !isset(UPLOAD_MIME_TYPES[strtolower(pathinfo($file, PATHINFO_EXTENSION))])) {
        return null;
    }

    return $file;
}

/**
 * Ob eine Seite, ein Backup, eine Site-Datei oder ein Plugin die Upload-Datei $file noch verwendet.
 * Im Zweifel ja: bei Fehlern, unlesbaren oder zu großen Textdateien und Ordner-Links (werden nicht verfolgt).
 */
function upload_in_use(string $file): bool
{
    try {
        foreach (UPLOAD_REFERENCE_ROOTS as $root) {
            if (!is_dir($root)) {
                continue;
            }
            $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
            foreach ($files as $entry) {
                if ($entry->isLink() && $entry->isDir()) {
                    return true;
                }
                if (!$entry->isFile() || in_array(strtolower($entry->getExtension()), UPLOAD_REFERENCE_SKIP_EXTENSIONS, true)) {
                    continue;
                }
                if ($entry->getSize() > UPLOAD_REFERENCE_MAX_BYTES) {
                    return true;
                }
                $content = @file_get_contents($entry->getPathname());
                if ($content === false || str_contains($content, $file)) {
                    return true;
                }
            }
        }

        return plugins_upload_in_use($file);
    } catch (Throwable $e) {
        error_log('upload_in_use failed: ' . $e->getMessage());
        return true;
    }
}

/**
 * Plugin-Daten: Spalten aus schema.fields der Haupttabelle (jedes Plugin mit Schema) und der Hook
 * „<plugin>_upload_in_use(string $file): bool“ für alles andere (z. B. JSON-Spalten der Content-Typen).
 * Gilt für installierte Plugins, aktiv oder nicht (die Daten bleiben). Wirft bei Fehlern.
 */
function plugins_upload_in_use(string $file): bool
{
    $state = load_plugins_state();
    foreach (array_unique(array_merge($state['active'], array_keys($state['installed']))) as $name) {
        if (plugin_schema_upload_in_use(plugin_manifest($name), $file)) {
            return true;
        }
        $fn = plugin_hook_function($name, 'upload_in_use');
        if ($fn !== null && $fn($file) !== false) {
            return true;
        }
    }

    return false;
}

/**
 * Löscht die Upload-Dateien zu den Bildwerten $urls, die nirgends mehr verwendet werden. Aufruf erst,
 * nachdem der Eintrag selbst gelöscht ist; wirft nie (der Eintrag ist dann schon weg), Fehler lassen
 * die Datei liegen. Liefert die gelöschten Dateinamen.
 */
function delete_unused_uploads(array $urls): array
{
    $deleted = [];
    foreach (array_unique(array_filter($urls, 'is_string')) as $url) {
        try {
            $file = upload_file_name($url);
            $uploadsDir = realpath(UPLOADS_ROOT);
            if ($file === null || $uploadsDir === false) {
                continue;
            }
            $path = UPLOADS_ROOT . '/' . $file;
            $real = realpath($path);
            // Nur echte Dateien direkt in UPLOADS_ROOT, keine Links nach draußen.
            if ($real === false || is_link($path) || !is_file($real) || dirname($real) !== $uploadsDir || upload_in_use($file)) {
                continue;
            }
            if (@unlink($real)) {
                $deleted[] = $file;
            }
        } catch (Throwable $e) {
            error_log('delete_unused_uploads failed: ' . $e->getMessage());
        }
    }

    return $deleted;
}

/**
 * Löscht den Eintrag $id aus der Haupttabelle des Plugins samt Bildern, die sonst nirgends verwendet werden:
 * lesen, Bildwerte bestimmen, löschen, aufräumen. $where schränkt zusätzlich ein (Spalte => Wert).
 * Bildwerte liefert der Hook „<plugin>_image_values(array $row): array“, sonst die image-Felder aus
 * schema.fields. Kann er sie nicht bestimmen, bleiben die Dateien liegen. Liefert, ob es den Eintrag gab.
 */
function plugin_delete_entry(string $plugin, int $id, array $where = []): bool
{
    $manifest = plugin_manifest($plugin);
    $table = plugin_main_table($manifest);
    if ($table === null) {
        throw new RuntimeException('Plugin has no main table');
    }
    $conditions = ['`id` = ?'];
    $params = [$id];
    foreach ($where as $column => $value) {
        if (!is_string($column) || !plugin_table_name_valid($column)) {
            throw new InvalidArgumentException('Invalid column: ' . $column);
        }
        $conditions[] = "`{$column}` = ?";
        $params[] = $value;
    }
    $condition = implode(' AND ', $conditions);

    $stmt = db()->prepare("SELECT * FROM `{$table}` WHERE {$condition} LIMIT 1");
    $stmt->execute($params);
    $row = $stmt->fetch();
    if (!$row) {
        return false;
    }
    try {
        $fn = plugin_hook_function($plugin, 'image_values');
        $images = $fn !== null ? $fn($row) : plugin_schema_image_values(plugin_schema_columns($manifest), $row);
    } catch (Throwable $e) {
        $images = [];
    }
    db()->prepare("DELETE FROM `{$table}` WHERE {$condition}")->execute($params);
    delete_unused_uploads(is_array($images) ? $images : []);

    return true;
}
