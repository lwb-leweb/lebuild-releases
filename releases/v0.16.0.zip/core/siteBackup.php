<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/dbMigration.php';
require_once __DIR__ . '/updater.php';
require_once __DIR__ . '/siteBackupFormat.php';

// Sicherung der ganzen Installation als ZIP (Inhalte, Website, Uploads,
// Plugin-Daten). Nicht verwechseln mit den Seiten-Revisionen von fileStore
// (BACKUPS_ROOT). Abruf über api/backup.php mit Schlüssel; der Schlüssel-Hash
// und der letzte Abruf stehen in content/backup.json.

// Gesicherte Ordner; content/cache/ ist wiederherstellbar und bleibt draußen.
const SITE_BACKUP_ROOTS = [CONTENT_ROOT, SITE_ROOT, UPLOADS_ROOT];
const SITE_BACKUP_EXCLUDED = [CACHE_ROOT];
const SITE_BACKUP_KEY_BYTES = 32;
// Reste abgebrochener Läufe, die älter sind, räumt der nächste Lauf weg.
const SITE_BACKUP_TMP_MAX_AGE = 3600;
const SITE_BACKUP_TIME_LIMIT = 600;
const SITE_BACKUP_STREAM_CHUNK = 65536;
const SITE_BACKUP_FILENAME = 'backup-%s.zip';
const SITE_BACKUP_FILENAME_STAMP = 'Y-m-d-His';
// VACUUM INTO gibt es erst ab dieser SQLite-Version.
const SITE_BACKUP_SQLITE_MIN_VERSION = '3.27.0';
const SITE_BACKUP_ZIP_MISSING_MESSAGE = 'Die PHP-Erweiterung zip fehlt, ohne sie lassen sich keine Sicherungen erstellen.';
const SITE_BACKUP_NO_KEY_MESSAGE = 'Kein Backup-Schlüssel eingerichtet.';
const SITE_BACKUP_NO_HEADER_MESSAGE = 'Authorization-Header fehlt (Authorization: Bearer <Schlüssel>).';
const SITE_BACKUP_WRONG_KEY_MESSAGE = 'Falscher Schlüssel.';
const SITE_BACKUP_FAILED_MESSAGE = 'Sicherung fehlgeschlagen';
// Dashboard: Hinweis an Admins, wenn der letzte Abruf länger zurückliegt.
const SITE_BACKUP_REMIND_DAYS = 3;
const SITE_BACKUP_NEVER_LABEL = 'noch keine';

function site_backup_state_path(): string
{
    return CONTENT_ROOT . '/backup.json';
}

function site_backup_state_lock_path(): string
{
    return CACHE_ROOT . '/backup-state.lock';
}

function site_backup_tmp_root(): string
{
    return CACHE_ROOT . '/backup-tmp';
}

/** Pfad relativ zum Installations-Root, wie er im ZIP steht. */
function site_backup_relative(string $path): string
{
    return substr($path, strlen(PROJECT_ROOT) + 1);
}

/** Stand aus content/backup.json: key_hash, key_created, last_pull (je null, wenn nicht gesetzt). */
function site_backup_state(): array
{
    $data = json_decode((string) @file_get_contents(site_backup_state_path()), true);
    $data = is_array($data) ? $data : [];
    $state = [];
    foreach (['key_hash', 'key_created', 'last_pull'] as $key) {
        $state[$key] = is_string($data[$key] ?? null) ? $data[$key] : null;
    }
    return $state;
}

/**
 * Stand ändern: lesen, $change anwenden, schreiben, unter einer Sperre. So
 * überschreibt ein gleichzeitiger Abruf keinen gerade neu erzeugten Schlüssel.
 */
function site_backup_update_state(callable $change): array
{
    $lock = updater_acquire_lock(site_backup_state_lock_path(), true);
    if (!$lock) {
        throw new RuntimeException('Die Sperre für content/backup.json ließ sich nicht holen');
    }
    try {
        $state = $change(site_backup_state());
        write_private_file(site_backup_state_path(), json_encode($state, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . PHP_EOL);
        return $state;
    } finally {
        updater_release_lock($lock);
    }
}

/**
 * Neuen Schlüssel erzeugen; nur sein Hash wird gespeichert, der alte gilt
 * nicht mehr. Liefert den Klartext (einmal anzeigen). last_pull bleibt.
 */
function site_backup_create_key(): string
{
    $key = bin2hex(random_bytes(SITE_BACKUP_KEY_BYTES));
    site_backup_update_state(static fn (array $state): array => array_merge($state, ['key_hash' => hash('sha256', $key), 'key_created' => current_iso_time()]));
    return $key;
}

/** Passt der Schlüssel zum gespeicherten Hash? $state aus site_backup_state(), einmal je Request gelesen. */
function site_backup_key_valid(array $state, string $key): bool
{
    return $state['key_hash'] !== null && hash_equals($state['key_hash'], hash('sha256', $key));
}

/** Erfolgreichen Abruf über den Schlüssel vermerken (nicht beim Admin-Download). */
function site_backup_record_pull(): void
{
    site_backup_update_state(static fn (array $state): array => array_merge($state, ['last_pull' => current_iso_time()]));
}

/** Zeitstempel aus einem ISO-Wert von content/backup.json; null, wenn leer oder unlesbar. */
function site_backup_timestamp(?string $iso): ?int
{
    $ts = $iso === null ? false : strtotime($iso);
    return $ts === false ? null : $ts;
}

/** Zeile „Letzte Sicherung“: null ohne Schlüssel, sonst Zeitpunkt des letzten Abrufs oder „noch keine“. */
function site_backup_last_label(array $state, int $now): ?string
{
    if ($state['key_hash'] === null) {
        return null;
    }
    $pulled = site_backup_timestamp($state['last_pull']);
    return $pulled === null ? SITE_BACKUP_NEVER_LABEL : day_time_label($pulled, $now);
}

/**
 * Hinweis, wenn ein Schlüssel eingerichtet ist und der letzte Abruf (nie
 * abgerufen: das Erzeugen des Schlüssels) mehr als SITE_BACKUP_REMIND_DAYS zurückliegt.
 */
function site_backup_reminder(array $state, int $now): ?string
{
    $since = site_backup_timestamp($state['last_pull'] ?? $state['key_created']);
    if ($state['key_hash'] === null || $since === null || $since >= $now - SITE_BACKUP_REMIND_DAYS * 86400) {
        return null;
    }
    $check = ' Abhol-Skript prüfen; Schlüssel und Download unter Einstellungen → Backup.';
    return $state['last_pull'] === null
        ? 'Der Backup-Schlüssel ist seit über ' . SITE_BACKUP_REMIND_DAYS . ' Tagen eingerichtet, abgeholt wurde aber noch keine Sicherung.' . $check
        : 'Die letzte Sicherung liegt über ' . SITE_BACKUP_REMIND_DAYS . ' Tage zurück.' . $check;
}

/** Zeile für alle Angemeldeten, Hinweis nur für Admins – aus einem gelesenen Stand. */
function site_backup_dashboard_for_user(array $state, int $now): array
{
    return [
        'lastBackup' => current_user() !== null ? site_backup_last_label($state, $now) : null,
        'backupReminder' => is_admin() ? site_backup_reminder($state, $now) : null,
    ];
}

/** Für Login und Bootstrap. */
function site_backup_dashboard_for_current_user(): array
{
    return site_backup_dashboard_for_user(site_backup_state(), time());
}

/** Stand für die Karte Einstellungen → Backup; nie Schlüssel oder Hash. */
function site_backup_admin_status(): array
{
    $state = site_backup_state();
    $now = time();
    $created = $state['key_hash'] !== null ? site_backup_timestamp($state['key_created']) : null;
    return [
        'configured' => $state['key_hash'] !== null,
        'keyCreated' => $created !== null ? day_time_label($created, $now) : null,
        'siteBackup' => site_backup_dashboard_for_user($state, $now),
    ];
}

/** Schlüssel aus „Authorization: Bearer …“; null, wenn der Header fehlt oder kein Bearer ist. */
function site_backup_request_key(): ?string
{
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? null;
    if ($header === null && function_exists('getallheaders')) {
        foreach (getallheaders() as $name => $value) {
            if (strcasecmp((string) $name, 'Authorization') === 0) {
                $header = $value;
            }
        }
    }
    if (!is_string($header) || !preg_match('/^Bearer\s+(\S+)\s*$/i', $header, $m)) {
        return null;
    }
    return $m[1];
}

/** Passt If-None-Match (mit oder ohne Anführungszeichen) zum Fingerprint? */
function site_backup_etag_matches(string $header, string $fingerprint): bool
{
    return trim(trim($header), '"') === $fingerprint;
}

/** Bricht mit 500 (zip fehlt) bzw. 503 (Datenumzug läuft) ab, wenn jetzt keine Sicherung möglich ist. */
function site_backup_require_ready(): void
{
    if (!class_exists('ZipArchive')) {
        json_response(['ok' => false, 'error' => SITE_BACKUP_ZIP_MISSING_MESSAGE], 500);
    }
    require_no_db_migration();
}

/**
 * Gesicherte Dateien [relativer Pfad => absoluter Pfad], sortiert. Ohne
 * content/cache/ und bei SQLite ohne die laufende Datei samt -wal/-shm (die
 * kommt als Kopie dazu, siehe site_backup_build_zip()). Bei MySQL ist eine
 * liegengebliebene site.sqlite eine ruhende Datei und kommt so mit. Symlinks
 * werden übersprungen; ein unlesbarer Ordner wirft eine RuntimeException.
 */
function site_backup_files(): array
{
    $live = db_sqlite_path();
    $skip = array_merge(SITE_BACKUP_EXCLUDED, db_driver() === DB_DRIVER_SQLITE ? [$live, $live . '-wal', $live . '-shm'] : []);
    $files = [];
    $walk = static function (string $dir) use (&$walk, &$files, $skip): void {
        // Ein unlesbarer Ordner darf nicht still fehlen, sonst gilt ein lückenhaftes ZIP als vollständig.
        $entries = @scandir($dir);
        if ($entries === false) {
            throw new RuntimeException(site_backup_relative($dir) . ' lässt sich nicht lesen');
        }
        foreach ($entries as $entry) {
            $path = $dir . '/' . $entry;
            // Symlinks bleiben draußen: ihr Ziel kann außerhalb der Installation liegen.
            if ($entry === '.' || $entry === '..' || in_array($path, $skip, true) || is_link($path)) {
                continue;
            }
            if (is_dir($path)) {
                $walk($path);
            } elseif (is_file($path)) {
                $files[site_backup_relative($path)] = $path;
            }
        }
    };
    clearstatcache();
    foreach (SITE_BACKUP_ROOTS as $root) {
        if (is_dir($root)) {
            $walk($root);
        }
    }
    ksort($files, SORT_STRING);
    return $files;
}

function site_backup_sqlite_connect(): PDO
{
    if (!extension_loaded('pdo_sqlite')) {
        throw new RuntimeException(DB_SQLITE_MISSING_MESSAGE);
    }
    return db_connect_sqlite(db_sqlite_path());
}

/**
 * WAL in die Hauptdatei schreiben und die Verbindung schließen. Danach ändert
 * nur noch ein echter Schreibzugriff site.sqlite oder legt -wal an; sonst
 * würde das Schließen der Verbindung beim Bauen den Fingerprint verschieben.
 */
function site_backup_sqlite_settle(): void
{
    if (!is_file(db_sqlite_path())) {
        return;
    }
    db_disconnect();
    $pdo = site_backup_sqlite_connect();
    $pdo->query('PRAGMA wal_checkpoint(TRUNCATE)')->fetchAll();
    $pdo = null;
}

/**
 * SHA-256 über Pfad, Größe und Änderungszeit aller gesicherten Dateien samt
 * site.sqlite und site.sqlite-wal, ohne content/backup.json (das jeder Abruf
 * schreibt). site.sqlite geht zusätzlich mit ihrem Inhalt ein: SQLite schreibt
 * Seiten an Ort und Stelle, Größe und Sekunde allein übersehen Änderungen.
 * Eine leere -wal enthält keine Änderung und bleibt draußen: hält ein anderer
 * Request die Verbindung, kürzt der Checkpoint sie nur auf 0 Byte und setzt
 * dabei ihre Änderungszeit neu.
 */
function site_backup_fingerprint(array $files): string
{
    $state = site_backup_relative(site_backup_state_path());
    $live = db_sqlite_path();
    $lines = [];
    foreach ($files as $relative => $path) {
        if ($relative !== $state) {
            $lines[] = $relative . "\0" . (int) @filesize($path) . "\0" . (int) @filemtime($path);
        }
    }
    foreach ([$live, $live . '-wal'] as $path) {
        if (is_file($path) && ($path === $live || (int) @filesize($path) > 0)) {
            $lines[] = site_backup_relative($path) . "\0" . (int) @filesize($path) . "\0" . (int) @filemtime($path)
                . ($path === $live ? "\0" . hash_file('sha256', $path) : '');
        }
    }
    return hash('sha256', implode("\n", $lines));
}

/**
 * Stand für eine Sicherung festhalten: Dateiliste und Fingerprint (null bei
 * MySQL, dort gibt es kein 304). Vor dem Bauen, damit eine Änderung zwischen
 * Fingerprint und Kopie höchstens einen weiteren vollen Abruf auslöst. Räumt
 * zuerst Reste abgebrochener Läufe weg, auch wenn danach nur ein 304 folgt.
 */
function site_backup_prepare(): array
{
    site_backup_cleanup_tmp();
    $sqlite = db_driver() === DB_DRIVER_SQLITE;
    if ($sqlite) {
        site_backup_sqlite_settle();
    }
    $files = site_backup_files();
    return ['files' => $files, 'fingerprint' => $sqlite ? site_backup_fingerprint($files) : null];
}

/** Konsistente Kopie der SQLite-Datei per VACUUM INTO, auch während geschrieben wird. */
function site_backup_sqlite_copy(string $target): void
{
    $pdo = site_backup_sqlite_connect();
    $version = (string) $pdo->query('SELECT sqlite_version()')->fetchColumn();
    if (version_compare($version, SITE_BACKUP_SQLITE_MIN_VERSION, '<')) {
        throw new RuntimeException('SQLite ' . $version . ' ist zu alt für eine Sicherung (mind. ' . SITE_BACKUP_SQLITE_MIN_VERSION . ')');
    }
    $pdo->exec('VACUUM INTO ' . $pdo->quote($target));
}

/**
 * Tabellen der installierten Plugins als <tabelle>.jsonl (eine Zeile je
 * Datensatz) plus schema.json (je Tabelle Plugin, Spalten, höchste id und
 * nächste id) nach $dir. Liefert [Pfad im ZIP => Datei].
 */
function site_backup_mysql_export(string $dir): array
{
    $pdo = db();
    $entries = [];
    $schema = [];
    // Eine Transaktion: alle Tabellen aus demselben Stand (InnoDB-Snapshot).
    $pdo->beginTransaction();
    try {
        foreach (db_migration_plugins() as $plugin => $tables) {
            foreach ($tables as $table) {
                $columns = db_migration_columns($pdo, $table);
                $path = $dir . '/' . $table . SITE_BACKUP_DB_ROWS_SUFFIX;
                $fh = fopen($path, 'wb');
                if (!$fh) {
                    throw new RuntimeException('Exportdatei für ' . $table . ' ließ sich nicht anlegen');
                }
                foreach (db_migration_batches($pdo, $table, $columns) as $rows) {
                    foreach ($rows as $row) {
                        fwrite($fh, json_encode(array_combine($columns, $row), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR) . "\n");
                    }
                }
                fclose($fh);
                $schema[$table] = [
                    'plugin' => $plugin,
                    'columns' => $columns,
                    'max_id' => (int) $pdo->query("SELECT MAX(id) FROM `{$table}`")->fetchColumn(),
                    'next_id' => db_next_id($pdo, DB_DRIVER_MYSQL, $table),
                ];
                $entries[SITE_BACKUP_DB_DIR . '/' . $table . SITE_BACKUP_DB_ROWS_SUFFIX] = $path;
            }
        }
    } finally {
        $pdo->rollBack();
    }
    $schemaPath = $dir . '/' . SITE_BACKUP_DB_SCHEMA;
    file_put_contents($schemaPath, json_encode((object) $schema, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . PHP_EOL);
    $entries[SITE_BACKUP_DB_DIR . '/' . SITE_BACKUP_DB_SCHEMA] = $schemaPath;
    return $entries;
}

/** Reste abgebrochener Läufe (älter als SITE_BACKUP_TMP_MAX_AGE) entfernen. */
function site_backup_cleanup_tmp(): void
{
    $root = site_backup_tmp_root();
    $cutoff = time() - SITE_BACKUP_TMP_MAX_AGE;
    foreach (is_dir($root) ? (scandir($root) ?: []) : [] as $entry) {
        $path = $root . '/' . $entry;
        if ($entry !== '.' && $entry !== '..' && (int) @filemtime($path) < $cutoff) {
            updater_rrmdir($path);
        }
    }
}

/**
 * Baut das ZIP unter content/cache/backup-tmp/ und liefert seinen Pfad. ZIP
 * und Arbeitsdateien verschwinden am Ende des Requests, auch bei Abbruch.
 * $prepared kommt aus site_backup_prepare().
 */
function site_backup_build_zip(array $prepared): string
{
    $root = site_backup_tmp_root();
    $id = bin2hex(random_bytes(16));
    $zipPath = $root . '/' . $id . '.zip';
    $work = $root . '/' . $id;
    register_shutdown_function(static function () use ($zipPath, $work): void {
        @unlink($zipPath);
        updater_rrmdir($work);
    });
    ensure_dir($work);

    $entries = $prepared['files'];
    if (db_driver() === DB_DRIVER_SQLITE && is_file(db_sqlite_path())) {
        $copy = $work . '/' . DB_SQLITE_FILE;
        site_backup_sqlite_copy($copy);
        $entries[site_backup_relative(db_sqlite_path())] = $copy;
    }
    if (db_driver() === DB_DRIVER_MYSQL) {
        $entries += site_backup_mysql_export($work);
    }
    ksort($entries, SORT_STRING);

    $zip = new ZipArchive();
    if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::EXCL) !== true) {
        throw new RuntimeException('ZIP ließ sich nicht anlegen');
    }
    foreach ($entries as $name => $path) {
        if (!$zip->addFile($path, $name)) {
            throw new RuntimeException($name . ' ließ sich nicht ins ZIP legen');
        }
    }
    if (!$zip->close()) {
        throw new RuntimeException('ZIP ließ sich nicht schreiben');
    }

    // Prüfsummen aus dem fertigen ZIP: Ändert sich eine Datei beim Packen,
    // passt das Manifest trotzdem zu dem, was im ZIP steht.
    if ($zip->open($zipPath) !== true) {
        throw new RuntimeException('ZIP ließ sich nicht wieder öffnen');
    }
    $files = [];
    foreach (array_keys($entries) as $name) {
        $files[] = ['path' => $name] + site_backup_entry_digest($zip, $name);
    }
    $manifest = [
        'version' => updater_read_local_manifest()['version'],
        'created' => current_iso_time(),
        'driver' => db_driver(),
        'fingerprint' => $prepared['fingerprint'],
        'files' => $files,
    ];
    $zip->addFromString(SITE_BACKUP_MANIFEST, json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . PHP_EOL);
    if (!$zip->close()) {
        throw new RuntimeException('Manifest ließ sich nicht ins ZIP schreiben');
    }
    updater_rrmdir($work);
    return $zipPath;
}

/**
 * ZIP als Download senden (ETag nur mit Fingerprint). true, wenn es ganz
 * beim Client ankam; bricht der Client ab, endet das Senden mit false.
 */
function site_backup_stream(string $zipPath, ?string $fingerprint): bool
{
    $size = filesize($zipPath);
    $fh = fopen($zipPath, 'rb');
    if ($size === false || !$fh) {
        throw new RuntimeException('ZIP ließ sich nicht lesen');
    }
    ignore_user_abort(true);
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    // Sonst komprimiert PHP den Body und Content-Length stimmt nicht mehr.
    ini_set('zlib.output_compression', '0');
    header('Content-Type: application/zip');
    header('Content-Length: ' . $size);
    header('Content-Disposition: attachment; filename="' . sprintf(SITE_BACKUP_FILENAME, date(SITE_BACKUP_FILENAME_STAMP)) . '"');
    header('Cache-Control: no-store');
    if ($fingerprint !== null) {
        header('ETag: "' . $fingerprint . '"');
    }
    $sent = 0;
    while (!feof($fh)) {
        $chunk = (string) fread($fh, SITE_BACKUP_STREAM_CHUNK);
        echo $chunk;
        flush();
        $sent += strlen($chunk);
        if (connection_aborted()) {
            break;
        }
    }
    fclose($fh);
    return $sent === $size && !connection_aborted();
}
