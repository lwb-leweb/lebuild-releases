<?php
declare(strict_types=1);

require_once __DIR__ . '/utils.php';

const USER_ROLE_EDITOR = 'editor';
const USER_ROLE_ADMIN = 'admin';
const USERS_STORE_VERSION = 1;

function users_path(): string
{
    return CONTENT_ROOT . '/users.json';
}

function users_empty_store(): array
{
    return ['version' => USERS_STORE_VERSION, 'users' => []];
}

function users_load(): array
{
    $path = users_path();
    if (!is_file($path)) {
        return users_empty_store();
    }

    $raw = @file_get_contents($path);
    if ($raw === false || trim($raw) === '') {
        return users_empty_store();
    }

    $data = json_decode($raw, true);
    if (!is_array($data) || !isset($data['users']) || !is_array($data['users'])) {
        return users_empty_store();
    }

    $store = [
        'version' => is_int($data['version'] ?? null) ? $data['version'] : USERS_STORE_VERSION,
        'users' => [],
    ];

    foreach ($data['users'] as $user) {
        if (!is_array($user)) {
            continue;
        }
        if (empty($user['id']) || empty($user['username']) || empty($user['passwordHash']) || empty($user['role'])) {
            continue;
        }
        if (!in_array($user['role'], [USER_ROLE_EDITOR, USER_ROLE_ADMIN], true)) {
            continue;
        }
        $entry = [
            'id' => (string) $user['id'],
            'username' => (string) $user['username'],
            'passwordHash' => (string) $user['passwordHash'],
            'role' => (string) $user['role'],
            'createdAt' => (string) ($user['createdAt'] ?? current_iso_time()),
            'updatedAt' => (string) ($user['updatedAt'] ?? current_iso_time()),
        ];
        if (!empty($user['mustChangePassword'])) {
            $entry['mustChangePassword'] = true;
        }
        $store['users'][] = $entry;
    }

    return $store;
}

function users_save(array $store): void
{
    ensure_dir(CONTENT_ROOT);
    $path = users_path();
    $tmp = $path . '.tmp';

    $store['version'] = USERS_STORE_VERSION;
    if (!isset($store['users']) || !is_array($store['users'])) {
        $store['users'] = [];
    }

    $encoded = json_encode($store, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if ($encoded === false) {
        throw new RuntimeException('Failed to encode users store');
    }

    if (file_put_contents($tmp, $encoded, LOCK_EX) === false) {
        throw new RuntimeException('Failed to write users store');
    }
    @chmod($tmp, PRIVATE_FILE_MODE);
    if (!rename($tmp, $path)) {
        @unlink($tmp);
        throw new RuntimeException('Failed to commit users store');
    }
    @chmod($path, PRIVATE_FILE_MODE);
}

function users_find_by_username(string $username): ?array
{
    $username = trim($username);
    if ($username === '') {
        return null;
    }
    $store = users_load();
    foreach ($store['users'] as $user) {
        if (strcasecmp($user['username'], $username) === 0) {
            return $user;
        }
    }

    return null;
}

function users_find_by_id(string $id): ?array
{
    if ($id === '') {
        return null;
    }
    $store = users_load();
    foreach ($store['users'] as $user) {
        if ($user['id'] === $id) {
            return $user;
        }
    }

    return null;
}

function users_verify_password(array $user, string $password): bool
{
    if (empty($user['passwordHash']) || !is_string($user['passwordHash'])) {
        return false;
    }

    return password_verify($password, $user['passwordHash']);
}

function users_needs_rehash(array $user): bool
{
    if (empty($user['passwordHash']) || !is_string($user['passwordHash'])) {
        return false;
    }

    return password_needs_rehash($user['passwordHash'], PASSWORD_BCRYPT);
}

function users_generate_id(): string
{
    return 'u_' . bin2hex(random_bytes(6));
}

function users_validate_username(string $username): ?string
{
    $username = trim($username);
    if ($username === '') {
        return 'Username required';
    }
    if (strlen($username) < 3) {
        return 'Username must be at least 3 characters';
    }
    if (strlen($username) > 64) {
        return 'Username must be at most 64 characters';
    }
    if (!preg_match('/^[a-zA-Z0-9._-]+$/', $username)) {
        return 'Username may only contain letters, numbers, dot, underscore and dash';
    }

    return null;
}

function users_validate_password(string $password): ?string
{
    if (strlen($password) < 8) {
        return 'Password must be at least 8 characters';
    }
    if (strlen($password) > 512) {
        return 'Password is too long';
    }

    return null;
}

function users_validate_role(string $role): ?string
{
    if (!in_array($role, [USER_ROLE_EDITOR, USER_ROLE_ADMIN], true)) {
        return 'Invalid role';
    }

    return null;
}

function users_has_admin(): bool
{
    $store = users_load();
    foreach ($store['users'] as $user) {
        if (($user['role'] ?? null) === USER_ROLE_ADMIN) {
            return true;
        }
    }

    return false;
}

function users_count_admins(?string $excludeId = null): int
{
    $store = users_load();
    $count = 0;
    foreach ($store['users'] as $user) {
        if (($user['role'] ?? null) !== USER_ROLE_ADMIN) {
            continue;
        }
        if ($excludeId !== null && $user['id'] === $excludeId) {
            continue;
        }
        $count++;
    }

    return $count;
}

function users_public_view(array $user): array
{
    return [
        'id' => $user['id'],
        'username' => $user['username'],
        'role' => $user['role'],
        'createdAt' => $user['createdAt'] ?? null,
        'updatedAt' => $user['updatedAt'] ?? null,
    ];
}
