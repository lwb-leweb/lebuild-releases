<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/phpRewriter.php';
require_once __DIR__ . '/fileStore.php';
require_once __DIR__ . '/plugins.php';

// Seiten-Editor auf der Website: index.php hängt ihn für angemeldete Benutzer vor </body> ein.
// Dateien liegen unter public/admin/site-editor/ und werden über /admin/… ausgeliefert.
const SITE_EDITOR_URL = '/admin/site-editor/';
const SITE_EDITOR_SCRIPT = 'main.js';
// Regeln außerhalb des Shadow-DOM (Platz für die Leiste); Rahmen um Elemente liegen im Shadow-DOM (edit.css).
const SITE_EDITOR_STYLE = 'page.css';
// Token des LEWEB Design Systems (Farben, Schrift, Maße). Im Dokument nötig, weil @font-face im
// Shadow-DOM nicht greift; site-editor/bar.js hängt dieselbe Datei zusätzlich in den Shadow-Root.
const SITE_EDITOR_TOKENS = '/admin/design/tokens.css';
// Name des <meta> mit dem CSRF-Token und id des JSON-Blocks; site-editor/main.js liest beide
// (CSRF_META, CONFIG_ID; ein Test prüft, dass die Namen übereinstimmen).
const SITE_EDITOR_CSRF_META = 'le-csrf-token';
const SITE_EDITOR_CONFIG_ID = 'le-site-editor-config';

// Seitenname einer ausgelieferten Datei: nur eine importierte Seite direkt unter public/site,
// deren Quelldatei genau diese Datei ist. Sonst null (Unterordner, Plugin-Seiten): dort gibt es
// nichts zu bearbeiten, der Editor zeigt nur die Leiste.
function site_editor_page(string $file): ?string
{
    $name = pathinfo($file, PATHINFO_FILENAME);
    $real = realpath($file);
    if ($real === false || dirname($real) !== realpath(SITE_ROOT) || !is_safe_page_name($name)
        || !in_array($name, list_pages(), true)) {
        return null;
    }
    $source = page_source_path($name);
    return $source !== null && realpath($source) === $real ? $name : null;
}

// Was der Editor sonst aus api/bootstrap.php holen würde, aus denselben Quellen, dazu die Seite
// der Datei $file (getPage/savePage) mit ihrem Eintrag der Seitenliste.
function site_editor_config(array $user, string $file): array
{
    $page = site_editor_page($file);
    return [
        'username' => $user['username'],
        'role' => $user['role'],
        'page' => $page,
        // Eintrag der Seitenliste (Titel, zuletzt gespeichert); das Backend übernimmt ihn nach jedem Laden im iframe.
        'pageInfo' => $page === null ? null : page_info($page),
        // „Update installiert“ aus dem Login, falls der Admin auf der Website landet (einmal).
        'updateInstalled' => take_update_notice(),
        'textMarkup' => text_markup_config(),
        'imageVariants' => image_variant_config(),
        'upload' => upload_config(),
        // Plugin-Listen auf der Seite (site-editor/plugin-lists.js).
        'pluginLists' => plugin_lists_config(),
    ];
}

function site_editor_tags(array $user, string $file): string
{
    // JSON_HEX_*: kein `</script>` oder `<!--` aus Benutzernamen im Skript-Block.
    $config = json_encode(site_editor_config($user, $file), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    return '<meta name="' . SITE_EDITOR_CSRF_META . '" content="' . htmlspecialchars(csrf_token(), ENT_QUOTES) . '">'
        . '<script type="application/json" id="' . SITE_EDITOR_CONFIG_ID . '">' . $config . '</script>'
        . '<link rel="stylesheet" href="' . SITE_EDITOR_TOKENS . '">'
        . '<link rel="stylesheet" href="' . SITE_EDITOR_URL . SITE_EDITOR_STYLE . '">'
        . '<script type="module" src="' . SITE_EDITOR_URL . SITE_EDITOR_SCRIPT . '"></script>';
}

// Nur in HTML-Dokumente, vor das letzte </body>. Antworten ohne </body> (JSON, nachgeladene
// Teilstücke aus Site-PHP) bleiben unverändert; null heißt: nichts eingehängt.
// $file: die ausgelieferte Seitendatei.
function inject_site_editor(string $html, array $user, string $file): ?string
{
    $pos = strripos($html, '</body>');
    return $pos === false ? null : substr_replace($html, site_editor_tags($user, $file), $pos, 0);
}
