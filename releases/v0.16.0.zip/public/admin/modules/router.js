import { state, dom, clearViewDom, api, ADMIN_URL, pageRoute } from './core.js';
import { pageKey } from './pages.js';
import { openModal, closeModal } from './ui-modal.js';
import { showToast as showToastIn } from '../site-editor/toast.js';
import { openEntryModal, entryTitle, deleteQuestion } from '../site-editor/entry-form.js';
import * as DashboardView from './views/dashboard.js';
import * as SettingsView from './views/settings.js';
import * as PageView from './views/page.js';
import * as PluginsView from './views/plugins.js';
import * as UsersView from './views/users.js';

export const BASE_PATH = ADMIN_URL + '/';

const views = {
  dashboard: DashboardView,
  settings: SettingsView,
  page: PageView,
  plugins: PluginsView,
  users: UsersView,
  plugin: createPluginViewProxy()
};

let currentName = null;
let currentView = null;

function parsePath(path) {
  if (path === BASE_PATH || path === BASE_PATH.slice(0, -1)) {
    path = '';
  } else if (path.startsWith(BASE_PATH)) {
    path = path.slice(BASE_PATH.length);
  }
  const slash = path.indexOf('/');
  return {
    name: slash === -1 ? path : path.slice(0, slash),
    param: slash === -1 ? '' : path.slice(slash + 1)
  };
}

// Darf die aktuelle Ansicht für name verlassen werden? Eine Ansicht mit leave(retry) entscheidet
// selbst (Seitenansicht: erst nach der Warnung des Seiten-Editors im iframe) und ruft retry auf,
// sobald es geht. Ein Wechsel innerhalb derselben Ansicht ist immer erlaubt.
function mayLeave(name, retry) {
  return name === currentName || !currentView || typeof currentView.leave !== 'function' || currentView.leave(retry);
}

export function navigate(route, options) {
  const url = BASE_PATH + route;
  // Adresse und Browser-Verlauf ändern sich erst, wenn die Ansicht wirklich wechselt.
  if (!mayLeave(parsePath(url).name, function () { navigate(route, options); })) return;
  if (window.location.pathname !== url) {
    if (options && options.replace) {
      history.replaceState(null, '', url);
    } else {
      history.pushState(null, '', url);
    }
  }
  renderView();
}

function renderView() {
  const { name, param } = parsePath(window.location.pathname);
  // Zurück/Vor im Browser: die Adresse steht schon, die Ansicht wechselt erst, wenn es geht.
  if (!mayLeave(name, renderView)) return;

  if (!views[name] || (name === 'page' && !param)) {
    if (state.pageInfo.length) {
      navigate(pageRoute(pageKey(state.pageInfo[0])), { replace: true });
    } else {
      navigate('dashboard', { replace: true });
    }
    return;
  }

  if (name === currentName && currentView && typeof currentView.update === 'function') {
    currentView.update(param);
    syncSidebar(name);
    return;
  }

  if (currentView && typeof currentView.unmount === 'function') {
    currentView.unmount();
  }
  clearViewDom();
  dom.viewOutlet.textContent = '';

  currentView = views[name];
  currentName = name;
  currentView.mount(dom.viewOutlet, param);
  syncSidebar(name);
}

function syncSidebar(name) {
  document.querySelectorAll('.sidebar-nav .nav-item').forEach(function (btn) {
    btn.classList.remove('active');
  });
  if (dom.pluginsManageButton) {
    dom.pluginsManageButton.classList.remove('active');
  }
  if (name === 'dashboard' && dom.dashboardButton) {
    dom.dashboardButton.classList.add('active');
  }
  if (name === 'settings' && dom.settingsButton) {
    dom.settingsButton.classList.add('active');
  }
  if (name === 'plugins' && dom.pluginsManageButton) {
    dom.pluginsManageButton.classList.add('active');
  }
  document.querySelectorAll('#pluginsActiveList .page-entry').forEach(function (btn) {
    btn.classList.remove('active');
    if (name === 'plugin') {
      const parsed = parsePath(window.location.pathname);
      if (btn.dataset.route === parsed.param) {
        btn.classList.add('active');
      }
    }
  });
}

function createPluginViewProxy() {
  let loadedModule = null;

  return {
    async mount(outlet, route) {
      const segments = String(route || '').split('/').filter(Boolean);
      const pluginName = segments[0] || '';
      const subRoute = segments.slice(1).join('/');

      if (!pluginName || !/^[a-z][a-z0-9_-]*$/.test(pluginName)) {
        outlet.innerHTML = '<section class="view-area"><div class="view-card"><p class="message">Ungültiger Plugin-Name.</p></div></section>';
        return;
      }

      const info = (state.activePlugins || []).find(function (plugin) {
        const expected = plugin.route || plugin.name;
        return expected === route || plugin.name === pluginName;
      });
      if (!info) {
        outlet.innerHTML = '<section class="view-area"><div class="view-card"><p class="message">Plugin ist nicht aktiv.</p></div></section>';
        return;
      }

      try {
        if (info.hasAdminModule) {
          const mod = await import('/plugins/' + pluginName + '/admin/module.js');
          loadedModule = mod.default;
        } else if (info.hasSchema) {
          const mod = await import('./views/plugin-generic.js');
          loadedModule = mod.default;
        } else {
          outlet.innerHTML = '<section class="view-area"><div class="view-card"><p>Dieses Plugin hat keine Admin-Oberfläche.</p></div></section>';
          return;
        }

        if (!loadedModule || (loadedModule.id !== pluginName && loadedModule.id !== '__generic__')) {
          throw new Error('Plugin-Modul passt nicht zum Plugin.');
        }
        await loadedModule.mount(outlet, buildPluginContext(pluginName, subRoute, info));
      } catch (error) {
        outlet.innerHTML = '<section class="view-area"><div class="view-card"><p class="message">Plugin-Modul konnte nicht geladen werden: ' + escapeHtml(error.message || String(error)) + '</p></div></section>';
      }
    },
    unmount() {
      if (loadedModule && typeof loadedModule.unmount === 'function') {
        try {
          loadedModule.unmount();
        } catch (e) {
        }
      }
      loadedModule = null;
    }
  };
}

function buildPluginContext(pluginName, subRoute, info) {
  return {
    pluginName: pluginName,
    subRoute: subRoute || '',
    info: info || null,
    api: api,
    navigate: navigate,
    state: state,
    confirm: function (message) { return window.confirm(message); },
    toast: function (message) { window.alert(message); },
    ui: {
      openModal: openModal,
      closeModal: closeModal,
      // Formular für einen Eintrag aus dem Schema (site-editor/entry-form.js, auch auf der Website).
      openEntryForm: function (options) {
        return openEntryModal(openModal, Object.assign({ notify: showToast }, options));
      },
      entryTitle: entryTitle,
      deleteQuestion: deleteQuestion
    }
  };
}

function escapeHtml(value) {
  return String(value || '').replace(/[&<>"']/g, function (char) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
  });
}

export function showToast(message) {
  showToastIn(message, document.body);
}

let initialized = false;
export function initRouter() {
  if (!initialized) {
    window.addEventListener('popstate', renderView);
    initialized = true;
  }
  renderView();
}
