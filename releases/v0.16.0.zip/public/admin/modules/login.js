import { state, postJson, setMessage, logout } from './core.js';

// Login-Seite /login. Nach dem Login lädt sie neu: der Server (index.php) leitet Angemeldete
// dann zum sicheren Ziel aus ?next= weiter, das Ziel prüft nur er.
const LOGIN_TEXT = {
  mismatch: 'Die Passwörter stimmen nicht überein.'
};

const loginForm = document.getElementById('loginForm');
const loginMessage = document.getElementById('loginMessage');
const passwordForm = document.getElementById('passwordForm');
const passwordMessage = document.getElementById('passwordMessage');

function continueToTarget() {
  window.location.reload();
}

loginForm.addEventListener('submit', function (event) {
  event.preventDefault();
  postJson('/api/login.php', {
    username: loginForm.elements.username.value,
    password: loginForm.elements.password.value
  })
    .then(function (data) {
      if (!data.mustChangePassword) {
        continueToTarget();
        return;
      }
      // Erst-Login mit dem Standardpasswort: der Server sperrt alles außer dem Passwortwechsel.
      state.csrfToken = data.csrfToken;
      loginForm.classList.add('hidden');
      passwordForm.classList.remove('hidden');
      passwordForm.elements.password.focus();
    })
    .catch(function (error) {
      setMessage(loginMessage, error.message, false);
    });
});

passwordForm.addEventListener('submit', function (event) {
  event.preventDefault();
  const password = passwordForm.elements.password.value;
  if (password !== passwordForm.elements.repeat.value) {
    setMessage(passwordMessage, LOGIN_TEXT.mismatch, false);
    return;
  }
  postJson('/api/users/changePassword.php', { newPassword: password })
    .then(continueToTarget)
    .catch(function (error) {
      setMessage(passwordMessage, error.message, false);
    });
});

document.getElementById('passwordCancel').addEventListener('click', function () {
  logout().catch(function (error) {
    setMessage(passwordMessage, error.message, false);
  });
});
