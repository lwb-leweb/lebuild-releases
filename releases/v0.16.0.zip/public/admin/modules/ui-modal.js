// Zentraler Modal-Dialog für das Admin-Backend.
// Plugins greifen über ctx.ui.openModal() darauf zu (siehe knowledgebase/admin-ui.md).

let hostEl = null;
let currentClose = null;
// Kennung des offenen Modals: ctx-Aufrufe eines schon ersetzten Modals laufen ins Leere.
let currentToken = null;
// Solange das offene Modal busy ist, schließen es weder X, Escape noch Hintergrund.
let currentBusy = false;
// Mit opts.keepOnUnmount schließt auch closeModal() von außen (z. B. unmount
// beim Routenwechsel) ein busy-Modal nicht.
let currentKeep = false;
let escHandler = null;

function ensureHost() {
  if (hostEl) return hostEl;
  hostEl = document.createElement('div');
  hostEl.className = 'admin-modal hidden';
  hostEl.setAttribute('role', 'dialog');
  hostEl.setAttribute('aria-modal', 'true');
  hostEl.innerHTML = `
    <div class="admin-modal__panel" role="document">
      <div class="admin-modal__head">
        <strong class="admin-modal__title"></strong>
        <button type="button" class="admin-modal__close" aria-label="Schliessen">×</button>
      </div>
      <div class="admin-modal__body"></div>
      <p class="admin-modal__message message"></p>
      <div class="admin-modal__actions form-actions">
        <button type="button" class="admin-modal__cancel secondary">Abbrechen</button>
        <button type="button" class="admin-modal__submit">Speichern</button>
      </div>
    </div>
  `;
  document.body.appendChild(hostEl);

  hostEl.addEventListener('click', function (event) {
    if (event.target === hostEl) {
      if (currentClose) currentClose('backdrop');
    }
  });
  hostEl.querySelector('.admin-modal__close').addEventListener('click', function () {
    if (currentClose) currentClose('close');
  });
  return hostEl;
}

export function openModal(opts) {
  if (currentClose) currentClose('replaced');
  const host = ensureHost();
  const title = opts && opts.title ? String(opts.title) : '';
  const bodyHtml = opts && opts.bodyHtml != null ? String(opts.bodyHtml) : '';
  const submitLabel = opts && opts.submitLabel ? String(opts.submitLabel) : 'Speichern';
  const cancelLabel = opts && opts.cancelLabel ? String(opts.cancelLabel) : 'Abbrechen';
  const showActions = !(opts && opts.hideActions);

  host.querySelector('.admin-modal__title').textContent = title;
  const body = host.querySelector('.admin-modal__body');
  body.innerHTML = bodyHtml;
  const messageEl = host.querySelector('.admin-modal__message');
  messageEl.textContent = '';
  messageEl.classList.remove('ok');

  const actionsEl = host.querySelector('.admin-modal__actions');
  const submitBtn = host.querySelector('.admin-modal__submit');
  const cancelBtn = host.querySelector('.admin-modal__cancel');
  submitBtn.textContent = submitLabel;
  cancelBtn.textContent = cancelLabel;
  actionsEl.classList.toggle('hidden', !showActions);

  host.classList.remove('hidden');
  document.body.classList.add('admin-modal-open');

  const token = {};
  currentToken = token;
  currentKeep = !!(opts && opts.keepOnUnmount);
  const closeBtn = host.querySelector('.admin-modal__close');
  const ctx = {
    body: body,
    message: messageEl,
    submitButton: submitBtn,
    cancelButton: cancelBtn,
    isOpen() {
      return currentToken === token;
    },
    setMessage(text, ok) {
      if (!ctx.isOpen()) return;
      messageEl.textContent = text || '';
      messageEl.classList.toggle('ok', !!ok);
    },
    close() {
      if (ctx.isOpen()) detach();
    },
    // Solange busy, schließen weder X, Escape noch Klick auf den Hintergrund.
    setBusy(value) {
      if (!ctx.isOpen()) return;
      currentBusy = !!value;
      submitBtn.disabled = currentBusy;
      cancelBtn.disabled = currentBusy;
      closeBtn.disabled = currentBusy;
    }
  };

  function handleSubmit() {
    if (typeof opts.onSubmit === 'function') {
      try { opts.onSubmit(ctx); } catch (e) { ctx.setMessage(e.message || String(e), false); }
    } else {
      closeModal('submit');
    }
  }
  function handleCancel(reason) {
    if (typeof opts.onCancel === 'function') {
      try { opts.onCancel(reason || 'cancel'); } catch (e) { /* ignore */ }
    }
    closeModal(reason || 'cancel');
  }

  submitBtn.onclick = handleSubmit;
  cancelBtn.onclick = function () { handleCancel('cancel'); };

  // Erste fokussierbare Eingabe fokussieren
  const focusable = body.querySelector('input, select, textarea, button');
  if (focusable) {
    try { focusable.focus(); } catch (e) { /* ignore */ }
  }

  currentClose = function (reason) {
    if (currentBusy && reason !== 'replaced') return;
    if (reason === 'submit') {
      handleSubmit();
      return;
    }
    if (reason === 'replaced') {
      // wird durch nächsten openModal-Aufruf ersetzt
      detach();
      return;
    }
    handleCancel(reason);
  };

  if (!escHandler) {
    escHandler = function (event) {
      if (event.key === 'Escape' && currentClose) {
        event.preventDefault();
        currentClose('escape');
      }
    };
    document.addEventListener('keydown', escHandler);
  }

  return ctx;
}

export function closeModal(reason) {
  if (!hostEl || (currentBusy && currentKeep)) return;
  detach();
}

function detach() {
  if (!hostEl) return;
  currentToken = null;
  currentBusy = false;
  currentKeep = false;
  hostEl.querySelector('.admin-modal__close').disabled = false;
  hostEl.classList.add('hidden');
  document.body.classList.remove('admin-modal-open');
  hostEl.querySelector('.admin-modal__body').innerHTML = '';
  hostEl.querySelector('.admin-modal__message').textContent = '';
  const submitBtn = hostEl.querySelector('.admin-modal__submit');
  const cancelBtn = hostEl.querySelector('.admin-modal__cancel');
  submitBtn.disabled = false;
  cancelBtn.disabled = false;
  submitBtn.classList.remove('hidden');
  submitBtn.onclick = null;
  cancelBtn.onclick = null;
  currentClose = null;
  if (escHandler) {
    document.removeEventListener('keydown', escHandler);
    escHandler = null;
  }
}
