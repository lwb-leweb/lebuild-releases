export const state = {
  csrfToken: '',
  pages: [],
  pageInfo: [],
  currentPage: '',
  content: {},
  labels: {},
  // Feldart je ID aus getPage (text|linktext|url|image|alt|background), bestimmt die Bearbeitung im Seiten-Editor.
  fieldKinds: {},
  pageQuery: '',
  updateStatus: null,
  updateDismissed: false,
  activePlugins: [],
  systemProblems: [],
  dbArchiveReminder: null,
  // Sicherung: { lastBackup, backupReminder } vom Server (Dashboard-Zeile und Hinweis).
  siteBackup: null,
  // Karte, zu der die Einstellungen nach dem Laden scrollen (aus Dashboard-Hinweisen).
  settingsFocus: null,
  // Listen für Textwerte aus dem JSON-Block des Seiten-Editors (text_markup_config); leer = nichts erlaubt.
  textMarkup: { tags: [], dropTags: [], blockTags: [], trimEdges: [], linkSchemes: [] },
  // Was beim Bildtausch wegfällt (image_variant_config); leer = nichts.
  imageVariants: { attrs: [], picture: '', source: '' },
  // Upload (upload_config): Endungen für die Dateiauswahl (leer = nur image/*), wirksame
  // Größengrenze und ihre Meldung (ohne Grenze prüft nur der Server).
  upload: { extensions: [], maxBytes: Infinity, tooLarge: '' },
  role: null,
  username: null
};

// Inhalte einer Seite aus api/getPage.php (Seiten-Editor).
export function applyPageContent(page, data) {
  state.currentPage = page;
  state.content = data.content || {};
  state.labels = data.labels || {};
  state.fieldKinds = data.fieldKinds;
}

// Listen für Bearbeitung: im Seiten-Editor aus seinem JSON-Block (Text, Bilder, Upload), im Backend
// aus api/bootstrap.php (nur Upload fürs Formular). Was fehlt, behält die leere Vorgabe.
export function applyEditLists(data) {
  if (data.textMarkup) state.textMarkup = data.textMarkup;
  if (data.imageVariants) state.imageVariants = data.imageVariants;
  if (data.upload) state.upload = data.upload;
}

export function isAdmin() {
  return state.role === 'admin';
}

// Shell elements (always present). View-internal refs (previewFrame,
// settingsForm, ...) are registered by view modules via
// updateDom() when they mount, and cleared via clearViewDom() on unmount.
export const dom = {
  editorView: document.getElementById('editorView'),
  viewOutlet: document.getElementById('viewOutlet'),
  pageList: document.getElementById('pageList'),
  pageSearch: document.getElementById('pageSearch'),
  importNotice: document.getElementById('importNotice'),
  importButton: document.getElementById('importButton'),
  refreshMarkersButton: document.getElementById('refreshMarkersButton'),
  extensionsGroup: document.getElementById('extensionsGroup'),
  extensionsNavToggle: document.getElementById('extensionsNavToggle'),
  pluginsManageButton: document.getElementById('pluginsManageButton'),
  pluginsActiveList: document.getElementById('pluginsActiveList'),
  pluginsEmptyHint: document.getElementById('pluginsEmptyHint'),
  usersButton: document.getElementById('usersButton'),
  settingsButton: document.getElementById('settingsButton'),
  dashboardButton: document.getElementById('dashboardButton'),
  logoutButton: document.getElementById('logoutButton'),
  siteLink: document.getElementById('siteLink'),
  updateBanner: document.getElementById('updateBanner'),

  // View-internal refs — populated by view modules on mount
  previewFrame: null,
  settingsPanel: null,
  settingsForm: null,
  settingsSaveButton: null,
  settingsMessage: null,
  dashboardPanel: null,
  pageView: null
};

const VIEW_DOM_KEYS = [
  'previewFrame',
  'settingsPanel', 'settingsForm', 'settingsSaveButton', 'settingsMessage',
  'dashboardPanel', 'pageView'
];

export function updateDom(refs) {
  Object.assign(dom, refs);
}

export function clearViewDom() {
  VIEW_DOM_KEYS.forEach(function (key) { dom[key] = null; });
}

export function labelFor(path) {
  return (state.labels && state.labels[path]) || path;
}

// Gemeinsam für api() und download(): Cookies mitschicken, CSRF-Token bei Nicht-GET.
function withSession(options) {
  options.credentials = 'same-origin';
  options.headers = options.headers || {};
  if (state.csrfToken && options.method && options.method !== 'GET') {
    options.headers['X-CSRF-Token'] = state.csrfToken;
  }
  return options;
}

// Meldungen, wenn der Server keine eigene liefert (keine JSON-Antwort, z. B. ein PHP-Fehler).
const REQUEST_TEXT = {
  failed: 'Die Anfrage ist fehlgeschlagen (HTTP %s).',
  offline: 'Keine Verbindung zum Server. Bitte gleich noch einmal versuchen.'
};

// Antwort als JSON lesen; Fehler (HTTP oder ok:false) als Error mit code/status/data werfen.
function readJson(res) {
  return res.text().then(function (text) {
    let data = {};
    try {
      data = text ? JSON.parse(text) : {};
    } catch (e) {
      data = { ok: res.ok };
    }
    if (!res.ok || data.ok === false) {
      const error = new Error(data.message || data.error || REQUEST_TEXT.failed.replace('%s', res.status));
      error.code = data.code || data.error || null;
      error.status = res.status;
      error.data = data;
      throw error;
    }
    return data;
  });
}

// Ohne Verbindung (fetch scheitert selbst) eine deutsche Meldung statt der des Browsers.
export function api(path, options = {}) {
  return fetch(path, withSession(options))
    .catch(function () { throw new Error(REQUEST_TEXT.offline); })
    .then(readJson);
}

export function postJson(path, body) {
  return api(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
}

// Login-Seite und Ziel für Editoren (LOGIN_URL, SITE_HOME_URL in core/auth.php), Backend (index.php).
export const LOGIN_URL = '/login';
export const SITE_HOME_URL = '/';
export const ADMIN_URL = '/admin';

// Route der Backend-Seitenansicht einer Seite (relativ zu ADMIN_URL + '/', router.js).
export function pageRoute(page) {
  return 'page/' + page;
}

// „Update installiert. 1.4 → 1.5“: Banner im Backend (update.js) und Hinweis im Seiten-Editor.
export const UPDATE_TEXT = {
  installed: 'Update installiert.'
};

export function versionStep(previousVersion, newVersion) {
  return (previousVersion ? previousVersion + ' → ' : '') + (newVersion || '');
}

// Abmelden und neu laden: ohne Session leitet der Server /admin zur Login-Seite um, die Website
// kommt ohne Editor. Fehler zeigt der Aufrufer.
export function logout() {
  return api('/api/logout.php', { method: 'POST' }).then(function () {
    window.location.reload();
  });
}

// So lange bleibt der Blob eines Downloads im Speicher.
const DOWNLOAD_REVOKE_MS = 60000;

// Datei laden und als Download speichern, mit Session und CSRF-Header wie api()
// (ein normaler Link schickt den Header nicht). Dateiname aus Content-Disposition,
// Fehler kommen als JSON und werden wie bei api() geworfen.
export function download(path, options = {}) {
  return fetch(path, withSession(options)).then(function (res) {
    if (!res.ok) return readJson(res);
    return res.blob().then(function (blob) {
      const name = /filename="([^"]+)"/.exec(res.headers.get('Content-Disposition') || '');
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = name ? name[1] : '';
      document.body.appendChild(link);
      link.click();
      link.remove();
      // Erst freigeben, wenn der Browser den Download übernommen hat.
      setTimeout(function () { URL.revokeObjectURL(link.href); }, DOWNLOAD_REVOKE_MS);
    });
  });
}

// Inhalt eines Eingabefelds kopieren. navigator.clipboard gibt es nur über HTTPS
// oder localhost und kann die Berechtigung verweigern; dann über die Markierung im Feld.
export function copyToClipboard(input) {
  input.select();
  const fallback = function () {
    return document.execCommand('copy')
      ? Promise.resolve()
      : Promise.reject(new Error('Kopieren nicht möglich – der Text ist markiert, bitte selbst kopieren.'));
  };
  if (navigator.clipboard && window.isSecureContext) {
    return navigator.clipboard.writeText(input.value).catch(fallback);
  }
  return fallback();
}

export function setMessage(el, text, ok) {
  if (!el) return;
  el.textContent = text || '';
  el.classList.toggle('ok', !!ok);
}

export function flatten(data, prefix, rows) {
  rows = rows || [];
  Object.keys(data || {}).forEach(function (key) {
    const path = prefix ? prefix + '.' + key : key;
    if (data[key] && typeof data[key] === 'object' && !Array.isArray(data[key])) {
      flatten(data[key], path, rows);
    } else {
      rows.push({ path: path, value: String(data[key] || '') });
    }
  });
  return rows;
}

export function setNested(target, path, value) {
  const parts = path.split('.');
  let cursor = target;
  parts.forEach(function (part, index) {
    if (index === parts.length - 1) {
      cursor[part] = value;
      return;
    }
    cursor[part] = cursor[part] || {};
    cursor = cursor[part];
  });
}

export function getContentPath(path) {
  return path.split('.').reduce(function (cursor, part) {
    return cursor && Object.prototype.hasOwnProperty.call(cursor, part) ? cursor[part] : undefined;
  }, state.content);
}

// Nach jeder Änderung an state.content zeigt die Seite den neuen Wert (Seiten-Editor, session.js).
let pageSyncCallback = null;
export function registerPageSync(fn) { pageSyncCallback = fn; }

export function updateContentPath(path, value) {
  setNested(state.content, path, value);
  if (pageSyncCallback) pageSyncCallback();
}
