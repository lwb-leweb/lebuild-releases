import { state, dom, updateDom } from '../core.js';
import { onUpdateStatusChange } from '../update.js';
import { navigate } from '../router.js';

const TEMPLATE = `
  <section class="view-area">
    <div class="card-grid">
      <div id="dashboardSystemCheck" class="view-card span-12 hidden">
        <h3 class="view-title">Systemprüfung</h3>
        <div class="notice">
          <div class="notice__lines"></div>
          <div class="update-card__actions">
            <button type="button">Einstellungen → System</button>
          </div>
        </div>
      </div>
      <div id="dashboardDbArchive" class="view-card span-12 hidden">
        <h3 class="view-title">Datenbank-Altdaten</h3>
        <div class="notice">
          <div class="notice__lines"></div>
          <div class="update-card__actions">
            <button type="button">Einstellungen → Datenbank</button>
          </div>
        </div>
      </div>
      <div id="dashboardBackup" class="view-card span-12 hidden">
        <h3 class="view-title">Backup</h3>
        <div class="notice">
          <div class="notice__lines"></div>
          <div class="update-card__actions">
            <button type="button">Einstellungen → Backup</button>
          </div>
        </div>
      </div>
      <div class="view-card span-8">
        <h2 class="view-title">Dashboard</h2>
        <p class="view-lead">Willkommen im Live Editor. Wähle links eine Seite oder die Einstellungen.</p>
      </div>
      <div class="view-card span-4">
        <h3 class="view-title">System</h3>
        <div id="dashboardUpdate" class="update-card"></div>
      </div>
    </div>
  </section>
`;

let unsubscribe = null;

export function mount(outlet) {
  outlet.innerHTML = TEMPLATE;
  updateDom({ dashboardPanel: outlet.querySelector('.view-area') });
  renderUpdateBlock();
  renderSystemProblems(outlet);
  renderDbArchiveReminder(outlet);
  renderBackupReminder(outlet);
  if (!unsubscribe) {
    onUpdateStatusChange(renderUpdateBlock);
    unsubscribe = true;
  }
}

export function unmount() {
}

function formatDate(iso) {
  if (!iso) return '–';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleString('de-DE');
}

function renderUpdateBlock() {
  const el = document.getElementById('dashboardUpdate');
  if (!el) return;
  const status = state.updateStatus;
  el.innerHTML = '';

  if (!status) {
    el.appendChild(rowEl('Version', '–'));
    appendBackupRow(el);
    return;
  }
  el.appendChild(rowEl('Version', status.currentVersion || '–'));
  el.appendChild(rowEl('Aktualisierungen', status.enabled ? 'aktiviert' : 'deaktiviert'));
  el.appendChild(rowEl('Letzte Prüfung', formatDate(status.lastCheck)));
  appendBackupRow(el);

  if (status.hasUpdate) {
    const pill = document.createElement('div');
    pill.className = 'update-card__notes';
    pill.textContent = 'Neue Version verfügbar: ' + status.latestVersion +
      (status.requiresConfirmation ? ' — Bestätigung nötig (siehe Banner)'
        : status.skippedVersion === status.latestVersion ? ' — nach Rollback ausgesetzt, manuell in den Einstellungen installierbar'
        : ' — wird beim nächsten Login installiert');
    el.appendChild(pill);
  } else if (status.lastError) {
    const note = document.createElement('div');
    note.className = 'update-card__notes';
    note.textContent = status.lastError;
    el.appendChild(note);
  } else {
    const ok = document.createElement('div');
    ok.className = 'update-card__notes';
    ok.textContent = 'Auf dem neuesten Stand.';
    el.appendChild(ok);
  }
}

// Hinweis-Karte mit Zeilen und Knopf zur passenden Karte in den Einstellungen.
// settings.js scrollt dorthin, sobald seine Karten geladen sind.
function renderNotice(outlet, cardId, lines, settingsCardId) {
  const card = outlet.querySelector('#' + cardId);
  const list = card.querySelector('.notice__lines');
  lines.forEach(function (text) {
    const line = document.createElement('p');
    line.textContent = text;
    list.appendChild(line);
  });
  card.querySelector('button').addEventListener('click', function () {
    state.settingsFocus = settingsCardId;
    navigate('settings');
  });
  card.classList.remove('hidden');
}

// Hinweis nur, wenn die Systemprüfung etwas vermisst (der Server liefert ihn nur Admins).
function renderSystemProblems(outlet) {
  const problems = state.systemProblems;
  if (!problems.length) return;
  renderNotice(outlet, 'dashboardSystemCheck', problems.map(function (problem) { return problem.purpose; }), 'settingsSystemCard');
}

// Erinnerung an alte Umzugs-Altdaten; Text und Regel kommen vom Server.
function renderDbArchiveReminder(outlet) {
  if (!state.dbArchiveReminder) return;
  renderNotice(outlet, 'dashboardDbArchive', [state.dbArchiveReminder], 'settingsDbCard');
}

// Erinnerung an eine ausbleibende Sicherung; Text und Regel kommen vom Server.
function renderBackupReminder(outlet) {
  if (!state.siteBackup || !state.siteBackup.backupReminder) return;
  renderNotice(outlet, 'dashboardBackup', [state.siteBackup.backupReminder], 'settingsBackupCard');
}

// „Letzte Sicherung: gestern, 03:12“ (Text vom Server), nur mit eingerichtetem Schlüssel.
function appendBackupRow(el) {
  if (!state.siteBackup || !state.siteBackup.lastBackup) return;
  el.appendChild(rowEl('Letzte Sicherung', state.siteBackup.lastBackup));
}

function rowEl(label, value) {
  const row = document.createElement('div');
  row.className = 'update-card__row';
  const a = document.createElement('small');
  a.textContent = label;
  const b = document.createElement('span');
  b.textContent = value;
  row.appendChild(a);
  row.appendChild(b);
  return row;
}
