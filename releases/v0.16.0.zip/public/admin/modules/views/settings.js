import { state, dom, api, download, copyToClipboard, setMessage, updateDom } from '../core.js';
import { forceRemoteCheck, rollback, onUpdateStatusChange } from '../update.js';
import { openModal, closeModal } from '../ui-modal.js';
import { DB_FORM_FIELDS, readDbForm } from '../dbForm.js';

const SETTINGS_KEYS = ['name', 'tagline', 'url', 'email', 'owner', 'locale'];

const TEMPLATE = `
  <section class="view-area">
    <div class="card-grid">
      <div class="view-card span-6">
        <div class="topbar">
          <strong>Einstellungen</strong>
          <p id="settingsMessage" class="message"></p>
          <button id="settingsSaveButton" type="button">Speichern</button>
        </div>
        <form id="settingsForm" class="settings-form">
          <label class="field"><small>Name</small><input name="name" type="text"></label>
          <label class="field"><small>Tagline</small><input name="tagline" type="text"></label>
          <label class="field"><small>Website-URL</small><input name="url" type="url"></label>
          <label class="field"><small>E-Mail</small><input name="email" type="email"></label>
          <label class="field"><small>Inhaber</small><input name="owner" type="text"></label>
          <label class="field"><small>Locale</small><input name="locale" type="text"></label>
        </form>
      </div>
      <div class="view-card span-6">
        <div class="topbar">
          <strong>Updates</strong>
          <p id="updateMessage" class="message"></p>
        </div>
        <div id="updateSection" class="update-card"></div>
      </div>
      <div id="settingsSystemCard" class="view-card span-12">
        <div class="topbar">
          <strong>System</strong>
          <p id="systemMessage" class="message"></p>
        </div>
        <div id="systemChecks" class="update-card"></div>
      </div>
      <div id="settingsDbCard" class="view-card span-12">
        <div class="topbar">
          <strong>Datenbank</strong>
          <p id="dbSettingsMessage" class="message"></p>
        </div>
        <div id="dbSettingsStatus" class="update-card"></div>
        <div id="dbArchive" class="generic-list"></div>
      </div>
      <div id="settingsBackupCard" class="view-card span-12">
        <div class="topbar">
          <strong>Backup</strong>
          <p id="backupMessage" class="message"></p>
        </div>
        <div id="backupStatus" class="update-card"></div>
      </div>
      <div class="view-card span-12">
        <div class="topbar">
          <strong>E-Mail / SMTP</strong>
          <p id="mailSettingsMessage" class="message"></p>
        </div>
        <form id="mailSettingsForm" class="settings-form">
          <label class="field"><small>Host</small><input name="host" type="text" autocomplete="off"></label>
          <label class="field"><small>Port</small><input name="port" type="number" min="1" max="65535" value="587"></label>
          <label class="field"><small>Verschlüsselung</small>
            <select name="encryption">
              <option value="tls">STARTTLS</option>
              <option value="ssl">SSL/TLS</option>
              <option value="none">Keine</option>
            </select>
          </label>
          <label class="field"><small>Benutzer</small><input name="username" type="text" autocomplete="username"></label>
          <label class="field"><small>Passwort</small><input name="password" type="password" autocomplete="new-password" placeholder="Leer lassen: bestehendes Passwort behalten"></label>
          <label class="field"><small>Absender-E-Mail</small><input name="fromEmail" type="email"></label>
          <label class="field"><small>Absender-Name</small><input name="fromName" type="text"></label>
          <label class="field"><small>Standard-Empfänger</small><input name="defaultRecipient" type="email"></label>
          <label class="field"><small>Test-Empfänger</small><input name="testRecipient" type="email"></label>
        </form>
        <p id="mailSettingsStatus" class="mail-status"></p>
        <div class="form-actions">
          <button id="mailSettingsSaveButton" type="button">SMTP speichern</button>
          <button id="mailSettingsTestButton" type="button" class="secondary">Test senden</button>
          <button id="mailSettingsDeleteButton" type="button" class="secondary">SMTP deaktivieren</button>
        </div>
      </div>
    </div>
  </section>
`;

let unsubscribed = false;

export function mount(outlet) {
  outlet.innerHTML = TEMPLATE;
  updateDom({
    settingsPanel: outlet.querySelector('.view-card'),
    settingsForm: outlet.querySelector('#settingsForm'),
    settingsSaveButton: outlet.querySelector('#settingsSaveButton'),
    settingsMessage: outlet.querySelector('#settingsMessage')
  });
  dom.settingsSaveButton.addEventListener('click', saveConfig);
  outlet.querySelector('#mailSettingsSaveButton').addEventListener('click', saveMailConfig);
  outlet.querySelector('#mailSettingsTestButton').addEventListener('click', sendTestMail);
  outlet.querySelector('#mailSettingsDeleteButton').addEventListener('click', deleteMailConfig);
  loadConfig();
  loadMailConfig();
  // Sprungziel aus dem Dashboard erst anfahren, wenn die Karten darüber gefüllt sind.
  Promise.all([loadSystemChecks(), loadDbStatus(), loadBackupStatus()]).then(scrollToFocus);
  renderUpdates();
  if (!unsubscribed) {
    onUpdateStatusChange(renderUpdates);
    unsubscribed = true;
  }
}

export function unmount() {
  stopMigrationPoll();
  closeModal();
}

function loadConfig() {
  api('/api/getConfig.php')
    .then(function (data) {
      const cfg = data.config || {};
      SETTINGS_KEYS.forEach(function (key) {
        const input = dom.settingsForm.elements[key];
        if (input) input.value = cfg[key] || '';
      });
      setMessage(dom.settingsMessage, '', true);
    })
    .catch(function (error) {
      setMessage(dom.settingsMessage, error.message, false);
    });
}

function saveConfig() {
  const cfg = {};
  SETTINGS_KEYS.forEach(function (key) {
    const input = dom.settingsForm.elements[key];
    if (input) cfg[key] = input.value;
  });
  api('/api/saveConfig.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(cfg)
  })
    .then(function () {
      setMessage(dom.settingsMessage, 'Gespeichert.', true);
    })
    .catch(function (error) {
      setMessage(dom.settingsMessage, error.message, false);
    });
}

function loadMailConfig() {
  api('/api/getMailConfig.php')
    .then(function (data) {
      fillMailForm(data.config || {});
      renderMailStatus(data.status || {}, data.config || {});
      setMailMessage('', true);
    })
    .catch(function (error) {
      setMailMessage(error.message, false);
    });
}

function fillMailForm(cfg) {
  const form = document.getElementById('mailSettingsForm');
  if (!form) return;
  form.elements.host.value = cfg.host || '';
  form.elements.port.value = cfg.port || 587;
  form.elements.encryption.value = cfg.encryption || 'tls';
  form.elements.username.value = cfg.username || '';
  form.elements.password.value = '';
  form.elements.fromEmail.value = cfg.fromEmail || '';
  form.elements.fromName.value = cfg.fromName || '';
  form.elements.defaultRecipient.value = cfg.defaultRecipient || '';
  form.elements.testRecipient.value = cfg.defaultRecipient || cfg.resolvedRecipient || '';
  form.elements.password.placeholder = cfg.passwordSet
    ? 'Gespeichertes Passwort behalten'
    : 'SMTP-Passwort';
}

function mailPayload() {
  const form = document.getElementById('mailSettingsForm');
  const fields = form.elements;
  return {
    host: fields.host.value,
    port: parseInt(fields.port.value, 10) || 587,
    encryption: fields.encryption.value,
    username: fields.username.value,
    password: fields.password.value,
    fromEmail: fields.fromEmail.value,
    fromName: fields.fromName.value,
    defaultRecipient: fields.defaultRecipient.value
  };
}

function saveMailConfig() {
  const button = document.getElementById('mailSettingsSaveButton');
  if (button) button.disabled = true;
  api('/api/saveMailConfig.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(mailPayload())
  })
    .then(function (data) {
      fillMailForm(data.config || {});
      renderMailStatus(data.status || {}, data.config || {});
      setMailMessage('SMTP gespeichert.', true);
    })
    .catch(function (error) {
      setMailMessage(error.message, false);
    })
    .finally(function () {
      if (button) button.disabled = false;
    });
}

function deleteMailConfig() {
  if (!window.confirm('SMTP-Einstellungen löschen und auf PHP mail() zurückfallen?')) return;
  const button = document.getElementById('mailSettingsDeleteButton');
  if (button) button.disabled = true;
  api('/api/deleteMailConfig.php', { method: 'POST' })
    .then(function (data) {
      fillMailForm(data.config || {});
      renderMailStatus(data.status || {}, data.config || {});
      setMailMessage('SMTP deaktiviert.', true);
    })
    .catch(function (error) {
      setMailMessage(error.message, false);
    })
    .finally(function () {
      if (button) button.disabled = false;
    });
}

function sendTestMail() {
  const form = document.getElementById('mailSettingsForm');
  const button = document.getElementById('mailSettingsTestButton');
  const payload = mailPayload();
  const testRecipient = form.elements.testRecipient.value;
  const shouldSave = !!(payload.host || payload.username || payload.password || payload.fromEmail || payload.fromName || payload.defaultRecipient);
  const send = function () {
    return api('/api/testMailConfig.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ to: testRecipient })
    });
  };
  if (button) button.disabled = true;
  (shouldSave
    ? api('/api/saveMailConfig.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
    .then(function (data) {
      fillMailForm(data.config || {});
      form.elements.testRecipient.value = testRecipient;
      renderMailStatus(data.status || {}, data.config || {});
      return send();
    })
    : send())
    .then(function (data) {
      setMailMessage('Testmail versendet (' + (data.transport || 'Mail') + ').', true);
    })
    .catch(function (error) {
      setMailMessage(error.message, false);
    })
    .finally(function () {
      if (button) button.disabled = false;
    });
}

function renderMailStatus(status, cfg) {
  const el = document.getElementById('mailSettingsStatus');
  if (!el) return;
  if (status.configured) {
    el.textContent = 'SMTP aktiv: ' + (cfg.host || 'Host') + ':' + (cfg.port || 587);
    el.className = 'mail-status ok';
    return;
  }
  if (status.mailFallback) {
    el.textContent = 'Fallback aktiv: PHP mail() wird genutzt, solange kein SMTP gespeichert ist.';
    el.className = 'mail-status ok';
    return;
  }
  if (status.mailFunction) {
    el.textContent = 'PHP mail() ist vorhanden, aber lokal ist kein Sendmail-Binary erreichbar. SMTP-Daten speichern.';
    el.className = 'mail-status';
    return;
  }
  el.textContent = 'Kein Mailversand verfügbar. SMTP-Daten speichern, bevor Mail-Plugins aktiviert werden.';
  el.className = 'mail-status';
}

function setMailMessage(text, ok) {
  setMessage(document.getElementById('mailSettingsMessage'), text, ok);
}

const MIGRATION_PROGRESS = 'Umzug wird ausgeführt…';
// Läuft beim Laden ein Umzug (z. B. aus einem anderen Tab), fragt die Karte so oft nach.
const MIGRATION_POLL_MS = 3000;
const DB_DRIVER_LABELS = { sqlite: 'SQLite', mysql: 'MySQL' };
const DB_ARCHIVE_LABELS = { sqlite: 'SQLite-Datei vom ', mysql: 'MySQL-Daten vom ' };
const DB_ARCHIVE_CONFIRM = {
  sqlite: ' endgültig löschen?',
  mysql: ' endgültig löschen? Dabei werden auch die Plugin-Tabellen in dieser MySQL-Datenbank gelöscht.'
};
let migrationPoll = null;

function setDbMessage(text, ok) {
  setMessage(document.getElementById('dbSettingsMessage'), text, ok);
}

function loadDbStatus() {
  return api('/api/getDbStatus.php')
    .then(renderDbStatus)
    .catch(function (error) {
      setDbMessage(error.message, false);
    });
}

function renderDbStatus(data) {
  const el = document.getElementById('dbSettingsStatus');
  if (!el) return;
  el.innerHTML = '';
  state.dbArchiveReminder = data.dbArchiveReminder || null;
  el.appendChild(row('Aktiver Treiber', DB_DRIVER_LABELS[data.driver] || data.driver));
  // Warum der Knopf gesperrt ist: laufender Umzug bzw. fehlendes pdo_sqlite.
  const reason = data.migrationRunning || (data.driver === 'mysql' && data.sqliteMissing ? 'Nach SQLite umziehen geht nicht: ' + data.sqliteMissing : null);
  if (reason) {
    const note = document.createElement('div');
    note.className = 'update-card__notes';
    note.textContent = reason;
    el.appendChild(note);
  }

  const actions = document.createElement('div');
  actions.className = 'update-card__actions';
  const button = document.createElement('button');
  button.type = 'button';
  button.disabled = !!reason;
  if (data.driver === 'mysql') {
    button.textContent = 'Nach SQLite umziehen';
    button.addEventListener('click', migrateToSqlite);
  } else {
    button.textContent = 'Nach MySQL umziehen';
    button.addEventListener('click', openMysqlMigration);
  }
  actions.appendChild(button);
  el.appendChild(actions);

  renderDbArchive(data.archive || []);
  if (data.migrationRunning) startMigrationPoll(data.driver);
}

function startMigrationPoll(driverBefore) {
  if (migrationPoll) return;
  migrationPoll = setInterval(function () {
    api('/api/getDbStatus.php')
      .then(function (data) {
        if (!migrationPoll || data.migrationRunning) return;
        stopMigrationPoll();
        const label = DB_DRIVER_LABELS[data.driver] || data.driver;
        // Das Ergebnis kennt nur der Tab, der umgezogen hat. Ohne Treiberwechsel
        // war es ein gescheiterter Umzug oder das Löschen von Altdaten: neutral melden.
        setDbMessage(data.driver !== driverBefore
          ? 'Umzug abgeschlossen. Aktiver Treiber: ' + label + '.'
          : 'Sperre aufgehoben, Treiber unverändert: ' + label + '.', true);
        renderDbStatus(data);
      })
      .catch(function (error) {
        if (migrationPoll) setDbMessage(error.message, false);
      });
  }, MIGRATION_POLL_MS);
}

function stopMigrationPoll() {
  clearInterval(migrationPoll);
  migrationPoll = null;
}

function renderDbArchive(entries) {
  const el = document.getElementById('dbArchive');
  if (!el) return;
  el.innerHTML = '';
  if (!entries.length) return;
  const heading = document.createElement('h4');
  heading.className = 'db-archive__title';
  heading.textContent = 'Altdaten früherer Umzüge';
  el.appendChild(heading);
  const list = document.createElement('ul');
  entries.forEach(function (entry) {
    const item = document.createElement('li');
    item.className = 'generic-list__row';
    const title = document.createElement('span');
    title.className = 'generic-list__title';
    title.textContent = (DB_ARCHIVE_LABELS[entry.kind] || '') + formatDate(entry.createdAt.replace(' ', 'T')) +
      (entry.due ? ' – bitte prüfen und löschen' : '');
    const actions = document.createElement('div');
    actions.className = 'generic-list__actions';
    const del = document.createElement('button');
    del.type = 'button';
    del.className = 'secondary';
    del.textContent = 'Löschen';
    del.addEventListener('click', function () { deleteDbArchive(entry, del); });
    actions.appendChild(del);
    item.appendChild(title);
    item.appendChild(actions);
    list.appendChild(item);
  });
  el.appendChild(list);
}

function migrationText(data) {
  const counts = Object.keys(data.counts || {}).map(function (table) {
    return table + ': ' + data.counts[table];
  }).join(', ');
  const done = 'Umzug abgeschlossen' + (counts ? ' (' + counts + ' Zeilen)' : '') + '.';
  return data.warning ? done + ' ' + data.warning : done;
}

function migrationDone(data) {
  // Ein Hinweis (z. B. Altdaten nicht archiviert) braucht Handarbeit: als Warnung zeigen.
  setDbMessage(migrationText(data), !data.warning);
  return loadDbStatus();
}

// Fehler immer auch in der Karte zeigen und den Stand neu laden (z. B. nach einem Timeout).
function migrationFailed(error) {
  setDbMessage(error.message, false);
  return loadDbStatus();
}

function migrateToSqlite(event) {
  if (!window.confirm('Plugin-Daten von MySQL nach SQLite umziehen? Plugins können währenddessen nicht speichern.')) return;
  event.currentTarget.disabled = true;
  setDbMessage(MIGRATION_PROGRESS, true);
  api('/api/migrateDb.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ target: 'sqlite' })
  })
    .then(migrationDone)
    .catch(migrationFailed);
}

function openMysqlMigration() {
  const modal = openModal({
    title: 'Nach MySQL umziehen',
    bodyHtml: `<form id="dbMigrateForm" class="settings-form">${DB_FORM_FIELDS}
      <div class="form-actions"><button type="button" class="secondary" data-action="test">Verbindung testen</button></div>
    </form>`,
    submitLabel: 'Umziehen',
    // Der Umzug läuft weiter, wenn die Ansicht wechselt: Dialog bleibt bis zum Ergebnis.
    keepOnUnmount: true,
    onSubmit(modalCtx) {
      const form = modalCtx.body.querySelector('#dbMigrateForm');
      if (!window.confirm('Plugin-Daten von SQLite nach MySQL umziehen? Plugins können währenddessen nicht speichern.')) return;
      modalCtx.setBusy(true);
      modalCtx.setMessage(MIGRATION_PROGRESS, true);
      setDbMessage(MIGRATION_PROGRESS, true);
      api('/api/migrateDb.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({ target: 'mysql' }, readDbForm(form)))
      })
        .then(function (data) {
          modalCtx.setBusy(false);
          // Ansicht inzwischen verlassen (Dialog blieb offen): Ergebnis im Dialog
          // zeigen, umgezogen ist schon – nur noch „Schließen“ anbieten.
          if (!document.getElementById('settingsDbCard')) {
            // Inzwischen ersetzt: Die Knöpfe gehören schon dem neuen Dialog.
            if (!modalCtx.isOpen()) return;
            modalCtx.setMessage(migrationText(data), !data.warning);
            form.classList.add('hidden');
            modalCtx.submitButton.classList.add('hidden');
            modalCtx.cancelButton.textContent = 'Schließen';
            return;
          }
          modalCtx.close('submit');
          return migrationDone(data);
        })
        .catch(function (error) {
          modalCtx.setBusy(false);
          modalCtx.setMessage(error.message, false);
          migrationFailed(error);
        });
    }
  });
  const form = modal.body.querySelector('#dbMigrateForm');
  form.addEventListener('submit', function (event) {
    event.preventDefault();
    modal.submitButton.click();
  });
  form.querySelector('[data-action="test"]').addEventListener('click', function () {
    modal.setMessage('Teste Verbindung…', true);
    api('/api/plugins/testDb.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(readDbForm(form))
    })
      .then(function () { modal.setMessage('Verbindung klappt.', true); })
      .catch(function (error) { modal.setMessage(error.message, false); });
  });
}

function deleteDbArchive(entry, button) {
  if (!window.confirm('Altdaten „' + entry.name + '“' + (DB_ARCHIVE_CONFIRM[entry.kind] || DB_ARCHIVE_CONFIRM.sqlite))) return;
  sendDbArchiveDelete(entry, button, false);
}

// MySQL der Altdaten nicht erreichbar: Die Zeile bietet dann an, nur die Datei zu löschen.
function offerForceDelete(entry, button) {
  const actions = button.parentNode;
  if (!actions || actions.querySelector('[data-action="force"]')) return;
  const force = document.createElement('button');
  force.type = 'button';
  force.className = 'secondary';
  force.dataset.action = 'force';
  force.textContent = 'Nur Zugangsdaten löschen';
  force.addEventListener('click', function () {
    if (!window.confirm('Nur die Zugangsdaten „' + entry.name + '“ löschen? Die Tabellen bleiben dann in MySQL und müssen von Hand gelöscht werden.')) return;
    sendDbArchiveDelete(entry, force, true);
  });
  actions.insertBefore(force, button);
}

function sendDbArchiveDelete(entry, button, force) {
  button.disabled = true;
  api('/api/deleteDbArchive.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: entry.name, force: force })
  })
    .then(function (data) {
      state.dbArchiveReminder = data.dbArchiveReminder || null;
      renderDbArchive(data.archive || []);
      setDbMessage('Gelöscht.', true);
    })
    .catch(function (error) {
      setDbMessage(error.message, false);
      button.disabled = false;
      if (error.code === 'archive_db_failed') offerForceDelete(entry, button);
    });
}

const BACKUP_KEY_CONFIRM = 'Neuen Backup-Schlüssel erzeugen? Der bisherige gilt sofort nicht mehr, das Abhol-Skript braucht dann den neuen.';

function setBackupMessage(text, ok) {
  setMessage(document.getElementById('backupMessage'), text, ok);
}

function loadBackupStatus() {
  return api('/api/getSiteBackupStatus.php')
    .then(renderBackupStatus)
    .catch(function (error) {
      setBackupMessage(error.message, false);
    });
}

function renderBackupStatus(data) {
  const el = document.getElementById('backupStatus');
  if (!el) return;
  el.innerHTML = '';
  state.siteBackup = data.siteBackup || null;
  el.appendChild(row('Backup-Schlüssel', !data.configured ? 'nicht eingerichtet'
    : data.keyCreated ? 'eingerichtet seit ' + data.keyCreated : 'eingerichtet'));
  if (data.configured) el.appendChild(row('Letzte Sicherung', data.siteBackup.lastBackup));
  const note = document.createElement('div');
  note.className = 'update-card__notes';
  note.textContent = 'Mit dem Schlüssel holt das Abhol-Skript die Sicherung jede Nacht ab. Herunterladen geht auch ohne Schlüssel.';
  el.appendChild(note);

  const actions = document.createElement('div');
  actions.className = 'update-card__actions';
  const create = document.createElement('button');
  create.type = 'button';
  create.textContent = data.configured ? 'Neuen Backup-Schlüssel erzeugen' : 'Backup-Schlüssel erzeugen';
  create.addEventListener('click', function () { createBackupKey(create, data.configured); });
  const get = document.createElement('button');
  get.type = 'button';
  get.className = 'secondary';
  get.textContent = 'Backup herunterladen';
  get.addEventListener('click', function () { downloadBackup(get); });
  actions.appendChild(create);
  actions.appendChild(get);
  el.appendChild(actions);
}

function createBackupKey(button, replace) {
  if (replace && !window.confirm(BACKUP_KEY_CONFIRM)) return;
  button.disabled = true;
  api('/api/createSiteBackupKey.php', { method: 'POST' })
    .then(function (data) {
      renderBackupStatus(data);
      setBackupMessage('Backup-Schlüssel erzeugt.', true);
      showBackupKey(data.key);
    })
    .catch(function (error) {
      setBackupMessage(error.message, false);
      button.disabled = false;
    });
}

// Klartext nur in diesem Dialog; beim Schließen leert das Modal seinen Inhalt.
function showBackupKey(key) {
  const modal = openModal({
    title: 'Backup-Schlüssel',
    bodyHtml: '<p>Diesen Schlüssel jetzt ins Abhol-Skript übernehmen. Er wird nicht noch einmal angezeigt; geht er verloren, einfach einen neuen erzeugen.</p>' +
      '<label class="field"><small>Schlüssel</small><input type="text" readonly spellcheck="false" autocomplete="off"></label>',
    submitLabel: 'Kopieren',
    cancelLabel: 'Schließen',
    onSubmit: function (ctx) {
      copyToClipboard(input)
        .then(function () { ctx.setMessage('Kopiert.', true); })
        .catch(function (error) { ctx.setMessage(error.message, false); });
    }
  });
  const input = modal.body.querySelector('input');
  input.value = key;
  input.select();
}

function downloadBackup(button) {
  button.disabled = true;
  setBackupMessage('Sicherung wird erstellt…', true);
  download('/api/downloadSiteBackup.php', { method: 'POST' })
    .then(function () {
      setBackupMessage('Sicherung heruntergeladen.', true);
    })
    .catch(function (error) {
      setBackupMessage(error.message, false);
    })
    .finally(function () {
      button.disabled = false;
    });
}

function scrollToFocus() {
  const card = state.settingsFocus && document.getElementById(state.settingsFocus);
  state.settingsFocus = null;
  if (card) card.scrollIntoView();
}

function loadSystemChecks() {
  return api('/api/getSystemChecks.php')
    .then(function (data) {
      renderSystemChecks(data.checks || []);
      setMessage(document.getElementById('systemMessage'), '', true);
    })
    .catch(function (error) {
      setMessage(document.getElementById('systemMessage'), error.message, false);
    });
}

function renderSystemChecks(checks) {
  const el = document.getElementById('systemChecks');
  if (!el) return;
  el.innerHTML = '';
  checks.forEach(function (check) {
    const r = row(check.label, check.ok ? 'OK' : 'Mangel');
    r.lastChild.className = check.ok ? 'message ok' : 'message';
    el.appendChild(r);
    if (!check.ok) {
      const purpose = document.createElement('small');
      purpose.className = 'message';
      purpose.textContent = check.purpose;
      el.appendChild(purpose);
    }
  });
}

function formatDate(iso) {
  if (!iso) return '–';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleString('de-DE');
}

function row(label, value) {
  const r = document.createElement('div');
  r.className = 'update-card__row';
  const a = document.createElement('small');
  a.textContent = label;
  const b = document.createElement('span');
  b.textContent = value;
  r.appendChild(a);
  r.appendChild(b);
  return r;
}

function renderUpdates() {
  const el = document.getElementById('updateSection');
  if (!el) return;
  el.innerHTML = '';
  const status = state.updateStatus;
  if (!status) {
    el.appendChild(row('Status', 'Unbekannt'));
    return;
  }

  el.appendChild(row('Aktuelle Version', status.currentVersion || '–'));
  el.appendChild(row('Verfügbar', status.latestVersion || '–'));
  el.appendChild(row('Letzte Prüfung', formatDate(status.lastCheck)));
  el.appendChild(row('Auto-Update', status.enabled ? 'aktiviert' : 'deaktiviert'));

  if (status.lastError) {
    const errNote = document.createElement('div');
    errNote.className = 'update-card__notes';
    errNote.textContent = status.lastError;
    el.appendChild(errNote);
  }

  if (status.hasUpdate && status.notes) {
    const notes = document.createElement('div');
    notes.className = 'update-card__notes';
    notes.textContent = status.notes;
    el.appendChild(notes);
  }

  const actions = document.createElement('div');
  actions.className = 'update-card__actions';

  const checkBtn = document.createElement('button');
  checkBtn.type = 'button';
  checkBtn.className = 'secondary';
  checkBtn.textContent = 'Jetzt prüfen';
  checkBtn.addEventListener('click', function () {
    checkBtn.disabled = true;
    setMessage(document.getElementById('updateMessage'), 'Prüfe…', true);
    forceRemoteCheck()
      .then(function () {
        setMessage(document.getElementById('updateMessage'), 'Prüfung abgeschlossen.', true);
      })
      .catch(function (e) {
        setMessage(document.getElementById('updateMessage'), e.message, false);
      })
      .finally(function () { checkBtn.disabled = false; });
  });
  actions.appendChild(checkBtn);

  if (status.hasUpdate) {
    const installBtn = document.createElement('button');
    installBtn.type = 'button';
    installBtn.textContent = 'Update ' + status.latestVersion + ' installieren';
    installBtn.addEventListener('click', function () {
      installBtn.disabled = true;
      installBtn.textContent = 'Installiere…';
      api('/api/installUpdate.php', { method: 'POST' })
        .then(function (data) {
          setMessage(document.getElementById('updateMessage'),
            'Installiert: ' + (data.previousVersion || '?') + ' → ' + (data.newVersion || '?'), true);
          state.updateStatus = data.status || null;
          renderUpdates();
        })
        .catch(function (e) {
          setMessage(document.getElementById('updateMessage'), e.message, false);
          installBtn.disabled = false;
        });
    });
    actions.appendChild(installBtn);
  }

  if (status.rollbackAvailable) {
    const rb = document.createElement('button');
    rb.type = 'button';
    rb.className = 'secondary';
    rb.textContent = 'Rollback';
    rb.addEventListener('click', function () {
      if (!window.confirm('Letzte Aktualisierung zurücknehmen?')) return;
      rb.disabled = true;
      rollback()
        .then(function (data) {
          setMessage(document.getElementById('updateMessage'),
            'Zurückgesetzt auf ' + (data.currentVersion || '?'), true);
          renderUpdates();
        })
        .catch(function (e) {
          setMessage(document.getElementById('updateMessage'), e.message, false);
          rb.disabled = false;
        });
    });
    actions.appendChild(rb);
  }

  el.appendChild(actions);
}
