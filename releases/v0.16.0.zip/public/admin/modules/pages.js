import { state, dom, pageRoute } from './core.js';
import { navigate } from './router.js';
import { readEditorConfig } from '../site-editor/config.js';

export function pageKey(page) {
  return typeof page === 'string' ? page : page.page;
}

export function pageExt(page) {
  const info = state.pageInfo.find(function (p) { return pageKey(p) === page; });
  return (info && info.ext) || 'html';
}

export function pageLabel(page) {
  if (typeof page === 'string') return page;
  const name = page.page;
  return name.charAt(0).toUpperCase() + name.slice(1);
}

export function pageMeta(page) {
  if (typeof page === 'string' || !page.updatedAt) return '';
  try {
    return new Date(page.updatedAt).toLocaleString();
  } catch (e) {
    return page.updatedAt;
  }
}

export function renderPages() {
  dom.pageList.textContent = '';
  (state.pageInfo.length ? state.pageInfo : state.pages).forEach(function (page) {
    const label = pageLabel(page);
    const metaText = pageMeta(page) || pageKey(page) + '.' + (page.ext || 'html');
    const haystack = (label + ' ' + metaText + ' ' + pageKey(page)).toLowerCase();
    if (state.pageQuery && haystack.indexOf(state.pageQuery) === -1) {
      return;
    }

    const button = document.createElement('button');
    button.type = 'button';
    const title = document.createElement('strong');
    title.textContent = label;
    const meta = document.createElement('span');
    meta.textContent = metaText;
    button.className = pageKey(page) === state.currentPage ? 'active page-entry' : 'page-entry';
    button.appendChild(title);
    button.appendChild(meta);
    button.addEventListener('click', function () {
      openPage(pageKey(page));
    });
    dom.pageList.appendChild(button);
  });
}

export function applyPageFilter() {
  state.pageQuery = (dom.pageSearch.value || '').trim().toLowerCase();
  renderPages();
}

// Klick in der Seitenliste: In der Seitenansicht wechselt nur der iframe, Adresse und Browser-Verlauf
// folgen erst nach dem Laden (syncPageFromFrame); ein abgelehnter Wechsel hinterlässt nichts.
// Aus anderen Ansichten geht es über den Router in die Seitenansicht.
function openPage(page) {
  if (!dom.previewFrame) {
    navigate(pageRoute(page));
  } else if (page !== state.currentPage) {
    loadPage(page);
  }
}

// Zeigt eine Seite im iframe; bearbeitet wird sie dort mit dem Seiten-Editor (wie auf der Website).
// Dieselbe Seite lädt neu (nach dem Import). Markierung und Adresse folgen erst, wenn sie geladen
// ist (syncPageFromFrame): lehnt man im iframe die Warnung beim Verlassen ab, zeigen beide weiter
// die Seite, die dort steht, und ein erneuter Klick fragt wieder.
export function loadPage(page) {
  if (!dom.previewFrame) return;
  requestedPage = page;
  showInFrame('/public/site/' + encodeURIComponent(page) + '.' + pageExt(page));
}

// Seite, die loadPage angefordert hat; ihr Laden bekommt einen eigenen Eintrag im Browser-Verlauf.
let requestedPage = '';

// Lädt url in den iframe, ohne dass der iframe selbst einen Eintrag im Browser-Verlauf anlegt
// (location.replace statt src); den Eintrag setzt syncPageFromFrame.
export function showInFrame(url) {
  dom.previewFrame.contentWindow.location.replace(url);
}

// Nach jedem Laden im iframe (auch nach Klick auf einen Link der Seite, Speichern oder
// Wiederherstellen): Seitenliste (Eintrag aus dem JSON-Block: Titel, zuletzt gespeichert) und
// Adresse zeigen die Seite im iframe. Eine über die Liste angeforderte Seite bekommt einen Eintrag
// im Browser-Verlauf; nach einem Link in der Seite hat ihn schon der iframe angelegt, dann wird
// die Adresse nur ersetzt (Zurück geht so in beiden Fällen eine Seite zurück). Andere Dokumente (Unterordner, Plugin-Seiten, fremde Adressen) haben keine Seite; dann ist
// keine markiert, ein Klick in der Liste lädt wieder.
export function syncPageFromFrame() {
  let config = null;
  try {
    config = readEditorConfig(dom.previewFrame.contentDocument);
  } catch (e) {
    config = null;
  }
  const info = config !== null ? config.pageInfo : null;
  const page = info !== null ? info.page : '';
  const index = state.pageInfo.findIndex(function (p) { return pageKey(p) === page; });
  if (index !== -1) state.pageInfo[index] = info;
  state.currentPage = page;
  renderPages();
  const requested = page !== '' && page === requestedPage;
  requestedPage = '';
  if (page) navigate(pageRoute(page), { replace: !requested });
}
