import { editorRoot, iconButton } from './bar.js';
import { askConfirm } from './confirm.js';

// Seitenpanel: schwebende Karte rechts über die ganze Höhe, über der Leiste (am Handy über die
// ganze Ansicht), im Shadow-DOM: Verlauf, „Alle Texte dieser Seite“ und das Formular für
// Plugin-Einträge. Kopf mit Überzeile und Titel, Inhalt scrollt, Fuß (panelFooter) bleibt stehen.
// Es ist immer höchstens eins offen.

const PANEL_TEXT = {
  close: 'Schließen',
  discardTitle: 'Eingaben verwerfen?',
  discardText: 'Was du hier eingegeben hast, ist noch nicht gespeichert.',
  discard: 'Verwerfen'
};

let current = null;

// Schließt das offene Panel; onClose des Panels läuft dabei.
export function closePanel() {
  if (!current) return;
  const panel = current;
  current = null;
  panel.element.remove();
  if (panel.scrim) panel.scrim.remove();
  if (panel.onClose) panel.onClose();
}

// Schließen über ×, Esc oder Klick daneben: mit ungespeicherten Eingaben (isDirty) erst nachfragen.
function requestClose() {
  if (!current) return;
  const panel = current;
  if (!panel.isDirty || !panel.isDirty()) {
    closePanel();
    return;
  }
  askConfirm({ title: PANEL_TEXT.discardTitle, text: PANEL_TEXT.discardText, confirm: PANEL_TEXT.discard, danger: true }).then(function (yes) {
    if (yes && current === panel) closePanel();
  });
}

// Ist das Panel mit diesem Schlüssel offen?
export function isPanelOpen(key) {
  return current !== null && current.key === key;
}

// Fuß des offenen Panels (Knöpfe wie Speichern/Abbrechen); leer bleibt er unsichtbar.
export function panelFooter() {
  return current ? current.foot : null;
}

// Öffnet ein Panel (ein offenes anderes schließt vorher) und liefert seinen Inhaltsbereich.
// options: { key, title, eyebrow (Überzeile, z. B. „Mitarbeiter“), dim (Seite abdunkeln, für
// Formulare), isDirty() (ungespeicherte Eingaben: vor dem Schließen nachfragen), onClose }.
// Esc schließt, wenn gerade nichts bearbeitet wird (interact.js fängt Esc während einer
// Bearbeitung vorher ab).
export function openPanel(options) {
  closePanel();
  const element = document.createElement('section');
  element.className = 'le-panel';
  element.setAttribute('role', 'dialog');
  element.setAttribute('aria-label', options.title);

  const head = document.createElement('div');
  head.className = 'le-panel__head';
  const titles = document.createElement('div');
  titles.className = 'le-panel__titles';
  if (options.eyebrow) {
    const eyebrow = document.createElement('span');
    eyebrow.className = 'le-panel__eyebrow';
    eyebrow.textContent = options.eyebrow;
    titles.appendChild(eyebrow);
  }
  const title = document.createElement('strong');
  title.className = 'le-panel__title';
  title.textContent = options.title;
  titles.appendChild(title);
  head.append(titles, iconButton('close', PANEL_TEXT.close, 'le-icon-btn', requestClose));

  const body = document.createElement('div');
  body.className = 'le-panel__body';
  const foot = document.createElement('div');
  foot.className = 'le-panel__foot';
  element.append(head, body, foot);
  element.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') requestClose();
  });

  let scrim = null;
  if (options.dim) {
    scrim = document.createElement('div');
    scrim.className = 'le-scrim';
    scrim.addEventListener('click', requestClose);
    editorRoot().appendChild(scrim);
  }
  // Nach der Leiste einhängen: das Panel liegt über ihr.
  editorRoot().appendChild(element);
  current = { key: options.key, element: element, scrim: scrim, foot: foot, isDirty: options.isDirty, onClose: options.onClose };
  return body;
}
