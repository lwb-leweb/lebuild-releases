import { state, labelFor } from '../modules/core.js';
import { setImageSource, setBackgroundImage, fieldValue, hasFieldValue, FIELD_KIND } from './page-sync.js';
import { imagePicker as uploadPicker, imageDropArea, uploadPending } from './upload.js';
import { record, resync, editChanged } from './session.js';
import { openPopover } from './popover.js';
import { notify } from './bar.js';

// Bild und Hintergrundbild am Element: Dialog mit dem Bild als Ablagefläche (hineinziehen oder
// klicken), der Upload läuft gleich (api/upload.php) und das neue Bild ist sofort zu sehen. Übernehmen macht daraus eine Änderung;
// Abbrechen zeigt wieder den bisherigen Wert. Verworfene Uploads bleiben liegen.

const IMAGE_TEXT = {
  alt: 'Alt-Text'
};

// Knopf der Dateiauswahl im Seiten-Editor (edit.css); auch „Alle Texte“ und Plugin-Formular.
export const PICKER_CLASS = 'le-btn le-btn--secondary le-picker';

// Ablagefläche eines Bildfeldes im Seiten-Editor (edit.css); auch Plugin-Formular (PAGE_LOOK).
const DROP_CLASSES = {
  drop: 'le-field__drop',
  active: 'le-field__drop--active',
  image: 'le-field__image',
  empty: 'le-field__image-empty'
};

// Dateiauswahl mit Upload (upload.js) im Aussehen des Seiten-Editors.
export function pageImagePicker(onUrl) {
  return uploadPicker(onUrl, notify, PICKER_CLASS);
}

// Ablagefläche zur Dateiauswahl picker (pageImagePicker): Vorschau, Hineinziehen, Klick.
export function pageImageDropArea(picker) {
  return imageDropArea(picker, DROP_CLASSES);
}

// Dialog für ein Bild-Feld (path) oder Hintergrund-Feld; altPath nur bei Bildern.
function openImageDialog(el, path, altPath, preview) {
  const before = fieldValue(path);
  const draft = { value: before, closed: false };
  const altBefore = altPath ? fieldValue(altPath) : '';
  const body = document.createElement('div');
  body.className = 'le-popover__body';
  let altInput = null;
  let popover = null;
  const picker = pageImagePicker(function (url) {
    if (draft.closed) return;
    draft.value = url;
    preview(url);
    area.show(url);
    popover.reposition();
    editChanged();
  });
  // Hineinziehen geht auch, wenn die Dateiauswahl schon zu ist.
  const area = pageImageDropArea(picker);
  area.show(before);
  area.element.querySelector('img').addEventListener('load', function () {
    if (popover) popover.reposition();
  });
  body.append(area.element, picker.element);
  if (altPath) {
    const altLabel = document.createElement('label');
    altLabel.className = 'le-field';
    altLabel.appendChild(document.createElement('span')).textContent = IMAGE_TEXT.alt;
    altInput = document.createElement('input');
    altInput.type = 'text';
    altInput.value = altBefore;
    altInput.addEventListener('input', function () {
      el.alt = altInput.value;
      editChanged();
    });
    altLabel.appendChild(altInput);
    body.appendChild(altLabel);
  }

  popover = openPopover({
    anchor: el,
    title: labelFor(path),
    body: body,
    isDirty: function () {
      return draft.value !== before || (altInput !== null && altInput.value !== altBefore);
    },
    commit: function () {
      if (uploadPending(notify)) return false;
      const values = [{ path: path, before: before, after: draft.value }];
      if (altInput) values.push({ path: altPath, before: altBefore, after: altInput.value });
      record(values);
      return true;
    },
    cancel: function () {},
    close: function () {
      draft.closed = true;
      resync();
    }
  });
}

// Bild (img): Datei und Alt-Text, wenn das Bild ein Alt-Feld hat.
export function openImage(el, field) {
  const altPath = state.fieldKinds[field.altPath] === FIELD_KIND.alt && hasFieldValue(field.altPath) ? field.altPath : '';
  openImageDialog(el, field.path, altPath, function (url) { setImageSource(el, url); });
}

// Hintergrundbild eines Elements (Knopf am Element).
export function openBackground(el, path) {
  openImageDialog(el, path, '', function (url) { setBackgroundImage(el, url); });
}
