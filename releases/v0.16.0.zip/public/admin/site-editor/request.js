import { state, api, LOGIN_URL } from '../modules/core.js';

// Alle Aufrufe des Seiten-Editors an die API (Laden, Speichern, Wiederherstellen, Upload,
// Plugin-Einträge) gehen hierüber. Ist die Anmeldung abgelaufen (401) oder woanders erneuert (403,
// CSRF), bleibt auf der Seite alles stehen; der nächste Aufruf holt zuerst das Token der neuen
// Anmeldung (api/csrfToken.php, ohne die Seite samt Kunden-PHP neu abzurufen). errorNotice
// formuliert den Hinweis dazu.

export const AUTH_TEXT = {
  login: 'Neu anmelden',
  renewed: 'Die Anmeldung wurde inzwischen erneuert. Bitte noch einmal versuchen.'
};
const AUTH_LOST_STATUS = { expired: 401, renewed: 403 };
// Wie CSRF_ERROR_CODE in core/auth.php: nur dieses 403 heißt „Anmeldung erneuert“.
const CSRF_ERROR_CODE = 'csrf';
const CSRF_TOKEN_URL = '/api/csrfToken.php';

let tokenStale = false;

function isRenewed(error) {
  return error.status === AUTH_LOST_STATUS.renewed && error.code === CSRF_ERROR_CODE;
}

function isAuthLost(error) {
  return error.status === AUTH_LOST_STATUS.expired || isRenewed(error);
}

// Token der aktuellen Anmeldung; ohne Anmeldung bleibt das alte (der Aufruf meldet dann 401).
function refreshCsrfToken() {
  return api(CSRF_TOKEN_URL).then(function (data) { state.csrfToken = data.csrfToken; }, function () {});
}

// Wie api() aus core.js, mit Token-Auffrischung nach verlorener Anmeldung.
export function editorApi(path, options) {
  const ready = tokenStale ? refreshCsrfToken() : Promise.resolve();
  return ready
    .then(function () { return api(path, options); })
    .then(function (data) {
      tokenStale = false;
      return data;
    }, function (error) {
      if (isAuthLost(error)) tokenStale = true;
      throw error;
    });
}

export function editorPost(path, body) {
  return editorApi(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
}

// Hinweis zu einem Fehler: { message, action } (action: { label, onClick } oder null). Abgelaufen
// bietet „Neu anmelden“ (Login-Seite in einem neuen Tab, danach zurück auf diese Seite).
export function errorNotice(error) {
  if (error.status === AUTH_LOST_STATUS.expired) {
    return { message: error.message, action: { label: AUTH_TEXT.login, onClick: function () { window.open(LOGIN_URL, '_blank'); } } };
  }
  return { message: isRenewed(error) ? AUTH_TEXT.renewed : error.message, action: null };
}
