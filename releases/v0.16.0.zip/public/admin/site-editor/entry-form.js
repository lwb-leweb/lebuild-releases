import { imagePicker, imageDropArea, uploadPending } from './upload.js';
import { editorButton } from './buttons.js';
import { richTextEditor } from './richtext.js';

// Formular für einen Plugin-Eintrag aus dem Schema seines Typs (schema.fields bzw. Typ-JSON der
// Content-Typen). Die eine Quelle für Seiten-Editor (Panel im Shadow-DOM, plugin-lists.js) und
// Backend (Modal: generische Plugin-Ansicht, Plugins über ctx.ui.openEntryForm). Gebaut wird per
// DOM (textContent, value), Eintragswerte und Feldnamen können kein Markup einschleusen.

export const ENTRY_TEXT = {
  add: 'Neu',
  edit: 'Bearbeiten',
  save: 'Speichern',
  cancel: 'Abbrechen',
  untitled: '(ohne Titel)',
  emptyOption: '—',
  deleteQuestion: '‚{name}‘ löschen?',
  otherImage: 'Anderes Bild',
  removeImage: 'Entfernen',
  richtextRequired: '„{name}“ bitte ausfüllen.'
};
// Felder, die einen Eintrag benennen (vor dem ersten Textfeld).
const TITLE_FIELDS = ['name', 'title'];
const TITLE_FALLBACK_TYPE = 'text';
// Feldart → type des <input>; alle übrigen Arten (text, slug, …) sind Textfelder.
const INPUT_TYPES = {
  number: 'number',
  datetime: 'datetime-local'
};
const INPUT_TYPE_TEXT = 'text';
// Klassen im Backend-Modal (styles.css).
const BACKEND_LOOK = {
  form: 'settings-form entry-form',
  field: 'field',
  labelTag: 'small',
  label: '',
  checkbox: 'field field--checkbox',
  picker: 'entry-form__picker',
  image: 'entry-form__image',
  imageEmpty: 'entry-form__image-empty',
  imageDrop: 'entry-form__drop',
  imageDropActive: 'entry-form__drop--active',
  imageActions: 'entry-form__image-actions'
};

// Beschriftung eines Feldes: label aus dem Schema, sonst sein Name.
export function fieldLabel(field) {
  return field.label ? field.label : field.name;
}

// Feld, das einen Eintrag benennt: name oder title, sonst das erste Textfeld (null ohne).
export function titleField(schema) {
  const named = schema.find(function (field) { return TITLE_FIELDS.indexOf(field.name) !== -1; });
  if (named) return named.name;
  const text = schema.find(function (field) { return field.type === TITLE_FALLBACK_TYPE; });
  return text ? text.name : null;
}

// Anzeigename eines Eintrags (Listen im Backend, Nachfrage beim Löschen).
export function entryTitle(schema, row) {
  const name = titleField(schema);
  if (!name) return '#' + row.id;
  return row[name] ? String(row[name]) : ENTRY_TEXT.untitled;
}

// „‚Max Muster‘ löschen?“ – als Text für confirm(), nie als HTML.
export function deleteQuestion(schema, row) {
  // Ersatz als Funktion: „$&“ o. Ä. im Namen bleibt wörtlich stehen.
  const title = entryTitle(schema, row);
  return ENTRY_TEXT.deleteQuestion.replace('{name}', function () { return title; });
}

// Wert für das Eingabefeld: Datum aus der Datenbank („2026-10-15 09:30:00“) für datetime-local.
function formatInputValue(field, value) {
  if (field.type === 'datetime' && value) {
    return String(value).replace(' ', 'T').slice(0, 16);
  }
  return value == null ? '' : String(value);
}

function fieldBox(look, field, tag) {
  const box = document.createElement(tag);
  box.className = look.field;
  const label = document.createElement(look.labelTag);
  if (look.label) label.className = look.label;
  label.textContent = fieldLabel(field);
  box.appendChild(label);
  return box;
}

function selectInput(field, value) {
  const select = document.createElement('select');
  if (!field.required) select.add(new Option(ENTRY_TEXT.emptyOption, ''));
  (Array.isArray(field.options) ? field.options : []).forEach(function (option) {
    if (typeof option === 'string') select.add(new Option(option, option));
  });
  select.value = value;
  return select;
}

// Bildfeld: Ablagefläche mit Vorschau (ohne Bild der Hinweis zum Hineinziehen), Dateiauswahl mit
// sofortigem Upload und „Entfernen“. Die URL steht im versteckten Eingabefeld; Änderungen melden
// sich als input am Formular (ungespeicherte Eingaben).
function imageField(look, field, input, notify) {
  const box = fieldBox(look, field, 'div');
  input.type = 'hidden';
  const set = function (url) {
    input.value = url;
    show();
    input.dispatchEvent(new Event('input', { bubbles: true }));
  };
  const picker = imagePicker(set, notify, look.picker);
  const area = imageDropArea(picker, { drop: look.imageDrop, active: look.imageDropActive, image: look.image, empty: look.imageEmpty });
  const remove = editorButton(ENTRY_TEXT.removeImage, look.picker, function () { set(''); });
  const chooseText = picker.element.firstChild.nodeValue;
  const show = function () {
    area.show(input.value);
    remove.hidden = !input.value;
    picker.element.firstChild.nodeValue = input.value ? ENTRY_TEXT.otherImage : chooseText;
  };
  show();
  const actions = document.createElement('div');
  actions.className = look.imageActions;
  actions.append(picker.element, remove);
  box.append(input, area.element, actions);
  return box;
}

// Baut das Formular. options: { look (Klassen, siehe BACKEND_LOOK), notify (Hinweise beim Upload),
// onSubmit() (Enter in einem Feld) }. Liefert { form, check(), values(), focus() }:
// check() = Pflichtfelder gefüllt (sonst zeigt der Browser die Meldung am Feld) und kein Upload
// läuft (sonst Hinweis über notify), values() = { feldname: wert } (boolean '1'/'0').
export function buildEntryForm(schema, row, options) {
  const look = options.look;
  const inputs = {};
  // Texteditoren (richtext.js) je Feldname: Pflicht prüft check(), focus() setzt den Cursor hinein.
  const editors = {};
  const form = document.createElement('form');
  form.className = look.form;

  schema.forEach(function (field) {
    const value = formatInputValue(field, row && row[field.name] != null ? row[field.name] : '');
    let input;
    let box;
    if (field.type === 'boolean') {
      input = document.createElement('input');
      input.type = 'checkbox';
      input.checked = value !== '' && value !== '0';
      box = document.createElement('label');
      box.className = look.checkbox;
      const line = document.createElement('span');
      line.append(input, ' ' + fieldLabel(field));
      box.appendChild(line);
    } else if (field.type === 'richtext') {
      input = document.createElement('textarea');
      input.value = value;
    } else if (field.type === 'select') {
      input = selectInput(field, value);
    } else {
      input = document.createElement('input');
      input.type = Object.prototype.hasOwnProperty.call(INPUT_TYPES, field.type) ? INPUT_TYPES[field.type] : INPUT_TYPE_TEXT;
      input.value = value;
    }
    input.name = field.name;
    // Ein verstecktes Pflichtfeld kann der Browser nicht melden; das prüft check().
    if (field.required && field.type !== 'richtext') input.required = true;
    if (field.type === 'image') {
      box = imageField(look, field, input, options.notify);
    } else if (field.type === 'richtext') {
      editors[field.name] = richTextEditor(input);
      box = fieldBox(look, field, 'div');
      box.appendChild(editors[field.name].element);
    } else if (!box) {
      box = fieldBox(look, field, 'label');
      box.appendChild(input);
    }
    inputs[field.name] = { field: field, input: input };
    form.appendChild(box);
  });

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    options.onSubmit();
  });
  // Enter in einem einzeiligen Feld speichert (ohne Absenden-Knopf im Formular tut der Browser das nicht).
  form.addEventListener('keydown', function (event) {
    if (event.key !== 'Enter' || event.target.tagName !== 'INPUT' || event.target.type === 'file') return;
    event.preventDefault();
    options.onSubmit();
  });

  return {
    form: form,
    values: function () {
      const data = {};
      Object.keys(inputs).forEach(function (name) {
        const entry = inputs[name];
        data[name] = entry.field.type === 'boolean' ? (entry.input.checked ? '1' : '0') : entry.input.value;
      });
      return data;
    },
    check: function () {
      if (uploadPending(options.notify)) return false;
      if (!form.reportValidity()) return false;
      const empty = Object.keys(editors).find(function (name) {
        return inputs[name].field.required && inputs[name].input.value === '';
      });
      if (!empty) return true;
      options.notify(ENTRY_TEXT.richtextRequired.replace('{name}', function () { return fieldLabel(inputs[empty].field); }));
      editors[empty].focus();
      return false;
    },
    focus: function () {
      const first = form.querySelector('input:not([type="file"]):not([hidden]), select, textarea:not([hidden]), [contenteditable="true"]');
      if (first) first.focus();
    }
  };
}

// Formular im Backend-Modal (ui-modal.js). options: { schema, row, save(data) → Promise,
// onSaved(), notify }. Titel „Neu“/„Bearbeiten“, Fehler des Servers stehen im Modal.
export function openEntryModal(openModal, options) {
  let modal = null;
  const submit = function () { modal.submitButton.click(); };
  const entry = buildEntryForm(options.schema, options.row, { look: BACKEND_LOOK, notify: options.notify, onSubmit: submit });
  modal = openModal({
    title: options.row ? ENTRY_TEXT.edit : ENTRY_TEXT.add,
    bodyHtml: '',
    submitLabel: ENTRY_TEXT.save,
    cancelLabel: ENTRY_TEXT.cancel,
    onSubmit: function (ctx) {
      if (!entry.check()) return;
      ctx.setBusy(true);
      options.save(entry.values()).then(function () {
        ctx.close('submit');
        options.onSaved();
      }).catch(function (error) {
        ctx.setBusy(false);
        ctx.setMessage(error.message || String(error), false);
      });
    }
  });
  modal.body.appendChild(entry.form);
  entry.focus();
  return modal;
}
