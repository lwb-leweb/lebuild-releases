import { icon } from './icons.js';
import { selectionOf, selectedRange } from './selection.js';
import { editorButton, keepSelection } from './buttons.js';

// Texteditor für Felder der Art richtext (entry-form.js), im Seiten-Editor wie im Backend: eine
// Werkzeugleiste (Überschrift, Fett, Kursiv, Aufzählung, Nummerierung, Zitat, Link) über einem
// bearbeitbaren Bereich. Niemand sieht HTML. Der Wert steht als HTML im Textfeld des Formulars
// (versteckt), values() liest es wie jedes andere Feld; der Server bereinigt ihn
// (plugin_sanitize_richtext). Eingefügt wird nur Text, damit aus Word oder Webseiten keine fremden
// Formate mitkommen. Stil in richtext.css.

const RTE_TEXT = {
  heading: 'Zwischenüberschrift',
  bold: 'Fett (Strg+B)',
  italic: 'Kursiv (Strg+I)',
  bullets: 'Aufzählung',
  numbers: 'Nummerierte Liste',
  quote: 'Zitat',
  link: 'Link setzen oder ändern',
  linkPlaceholder: 'https://… oder /seite',
  linkApply: 'Übernehmen',
  linkRemove: 'Link entfernen',
  selectFirst: 'Erst den Text markieren, der verlinkt werden soll.'
};
// Block für Zwischenüberschriften (der Seitentitel ist h1, Abschnitte meist h2).
const HEADING_TAG = 'h3';
const QUOTE_TAG = 'blockquote';
const PARAGRAPH_TAG = 'p';
// Leere Werte, wie der Browser sie hinterlässt, wenn alles gelöscht wurde.
const EMPTY_VALUES = ['', '<br>', '<p></p>', '<p><br></p>'];
// Was der Editor aus einem gespeicherten Wert übernimmt (wie plugin_sanitize_richtext im Server);
// alles andere wird zu seinem Text.
const ALLOWED_TAGS = ['p', 'br', 'strong', 'b', 'em', 'i', 'u', 'ul', 'ol', 'li', 'a', 'blockquote', 'h2', 'h3', 'h4'];
const LINK_PATTERN = /^(https?:|mailto:|tel:|\/|#)/i;

function toolButton(content, label, onClick) {
  // Klick lässt die Auswahl im Text stehen.
  const button = keepSelection(editorButton('', 'le-rte__btn', onClick));
  button.setAttribute('aria-label', label);
  button.title = label;
  button.append(content);
  return button;
}

function letter(text, tag) {
  const el = document.createElement(tag);
  el.textContent = text;
  return el;
}

// Gespeicherten Wert als Knoten nachbauen (DOMParser legt nichts an, was lädt oder läuft):
// erlaubte Elemente, bei Links nur ein harmloses href, sonst Text.
function copyNodes(nodes, target) {
  Array.prototype.forEach.call(nodes, function (node) {
    if (node.nodeType === Node.TEXT_NODE) {
      target.appendChild(document.createTextNode(node.nodeValue));
      return;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return;
    const tag = node.tagName.toLowerCase();
    if (ALLOWED_TAGS.indexOf(tag) === -1) {
      copyNodes(node.childNodes, target);
      return;
    }
    const el = document.createElement(tag);
    const href = tag === 'a' ? (node.getAttribute('href') || '').trim() : '';
    if (href && LINK_PATTERN.test(href)) el.setAttribute('href', href);
    copyNodes(node.childNodes, el);
    target.appendChild(el);
  });
}

// Block, in dem der Cursor steht (h3, blockquote, p …), innerhalb von area.
function currentBlock(area) {
  const range = selectedRange(area);
  let node = range ? range.startContainer : null;
  while (node && node !== area) {
    if (node.nodeType === Node.ELEMENT_NODE && /^(H[2-4]|BLOCKQUOTE|P|LI)$/.test(node.tagName)) return node.tagName.toLowerCase();
    node = node.parentNode;
  }
  return '';
}

// Listen, Zitate und Überschriften, die der Browser in einen Absatz gesetzt hat (<p><ul>…), aus ihm
// herausholen; ein dann leerer Absatz fällt weg.
function liftBlocks(area) {
  Array.prototype.forEach.call(area.querySelectorAll('p'), function (p) {
    const blocks = Array.prototype.filter.call(p.children, function (child) { return /^(UL|OL|BLOCKQUOTE|H[2-4]|P)$/.test(child.tagName); });
    if (!blocks.length) return;
    while (p.firstChild) p.parentNode.insertBefore(p.firstChild, p);
    p.remove();
  });
}

function cleanValue(html) {
  const trimmed = html.trim();
  return EMPTY_VALUES.indexOf(trimmed) === -1 ? trimmed : '';
}

// Macht aus textarea (Formularfeld mit HTML-Wert) einen Texteditor; liefert das Element, das ins
// Formular kommt, und focus(). Die textarea bleibt im Formular, versteckt, und trägt den Wert.
export function richTextEditor(textarea) {
  const box = document.createElement('div');
  box.className = 'le-rte';
  const area = document.createElement('div');
  area.className = 'le-rte__area';
  area.contentEditable = 'true';
  area.setAttribute('role', 'textbox');
  area.setAttribute('aria-multiline', 'true');
  copyNodes(new DOMParser().parseFromString(textarea.value, 'text/html').body.childNodes, area);
  textarea.hidden = true;

  const sync = function () {
    liftBlocks(area);
    textarea.value = cleanValue(area.innerHTML);
    refresh();
  };
  const run = function (command, value) {
    area.focus();
    document.execCommand('defaultParagraphSeparator', false, PARAGRAPH_TAG);
    document.execCommand(command, false, value);
    sync();
  };
  const toggleBlock = function (tag) {
    run('formatBlock', currentBlock(area) === tag ? PARAGRAPH_TAG : tag);
  };

  // Link: Zeile unter der Leiste mit Ziel, Übernehmen und Entfernen; die Auswahl wird gemerkt,
  // weil der Fokus ins Eingabefeld wandert.
  let savedRange = null;
  const linkRow = document.createElement('div');
  linkRow.className = 'le-rte__link';
  linkRow.hidden = true;
  const linkInput = document.createElement('input');
  linkInput.type = 'text';
  linkInput.placeholder = RTE_TEXT.linkPlaceholder;
  const restore = function () {
    area.focus();
    if (!savedRange) return;
    const selection = selectionOf(area);
    selection.removeAllRanges();
    selection.addRange(savedRange);
  };
  const applyLink = function () {
    const url = linkInput.value.trim();
    restore();
    if (url) run('createLink', url);
    else run('unlink');
    linkRow.hidden = true;
  };
  const apply = editorButton(RTE_TEXT.linkApply, 'le-rte__text-btn', applyLink);
  const remove = editorButton(RTE_TEXT.linkRemove, 'le-rte__text-btn', function () {
    restore();
    run('unlink');
    linkRow.hidden = true;
  });
  linkInput.addEventListener('keydown', function (event) {
    if (event.key === 'Enter') {
      event.preventDefault();
      event.stopPropagation();
      applyLink();
    } else if (event.key === 'Escape') {
      event.stopPropagation();
      linkRow.hidden = true;
      restore();
    }
  });
  linkRow.append(linkInput, apply, remove);

  const openLink = function () {
    let range = selectedRange(area);
    if (range && !area.contains(range.startContainer)) range = null;
    let node = range ? range.startContainer : null;
    while (node && node !== area && !(node.nodeType === Node.ELEMENT_NODE && node.tagName === 'A')) node = node.parentNode;
    const existing = node && node !== area ? node : null;
    if (!existing && (!range || range.collapsed)) {
      hint.textContent = RTE_TEXT.selectFirst;
      hint.hidden = false;
      return;
    }
    savedRange = range;
    if (existing) {
      // Ganzen Link auswählen, damit „Übernehmen“ ihn ersetzt.
      savedRange = document.createRange();
      savedRange.selectNodeContents(existing);
    }
    linkInput.value = existing ? existing.getAttribute('href') || '' : '';
    linkRow.hidden = false;
    linkInput.focus();
  };

  const buttons = {
    heading: toolButton(letter('H', 'span'), RTE_TEXT.heading, function () { toggleBlock(HEADING_TAG); }),
    bold: toolButton(letter('B', 'b'), RTE_TEXT.bold, function () { run('bold'); }),
    italic: toolButton(letter('I', 'i'), RTE_TEXT.italic, function () { run('italic'); }),
    bullets: toolButton(icon('listBullets'), RTE_TEXT.bullets, function () { run('insertUnorderedList'); }),
    numbers: toolButton(icon('listNumbers'), RTE_TEXT.numbers, function () { run('insertOrderedList'); }),
    quote: toolButton(icon('quote'), RTE_TEXT.quote, function () { toggleBlock(QUOTE_TAG); }),
    link: toolButton(icon('link'), RTE_TEXT.link, openLink)
  };
  const bar = document.createElement('div');
  bar.className = 'le-rte__bar';
  bar.setAttribute('role', 'toolbar');
  Object.keys(buttons).forEach(function (key) { bar.appendChild(buttons[key]); });

  const hint = document.createElement('div');
  hint.className = 'le-rte__hint';
  hint.hidden = true;

  // Knöpfe zeigen, was an der Cursorstelle gilt.
  function refresh() {
    if (!area.contains(document.activeElement) && document.activeElement !== area) return;
    const block = currentBlock(area);
    const states = {
      heading: block === HEADING_TAG,
      bold: document.queryCommandState('bold'),
      italic: document.queryCommandState('italic'),
      bullets: document.queryCommandState('insertUnorderedList'),
      numbers: document.queryCommandState('insertOrderedList'),
      quote: block === QUOTE_TAG
    };
    Object.keys(states).forEach(function (key) {
      buttons[key].setAttribute('aria-pressed', String(Boolean(states[key])));
    });
  }

  area.addEventListener('input', function () {
    hint.hidden = true;
    sync();
  });
  area.addEventListener('keyup', refresh);
  area.addEventListener('mouseup', refresh);
  area.addEventListener('focus', function () {
    box.classList.add('le-rte--focus');
    refresh();
  });
  area.addEventListener('blur', function () { box.classList.remove('le-rte--focus'); });
  // Nur Text einfügen; Absätze bleiben Absätze.
  area.addEventListener('paste', function (event) {
    event.preventDefault();
    const text = event.clipboardData ? event.clipboardData.getData('text/plain') : '';
    document.execCommand('insertText', false, text);
    sync();
  });
  // Strg/⌘+K setzt einen Link wie in Textprogrammen.
  area.addEventListener('keydown', function (event) {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      openLink();
    }
  });

  box.append(bar, linkRow, area, hint, textarea);
  return {
    element: box,
    area: area,
    focus: function () { area.focus(); }
  };
}
