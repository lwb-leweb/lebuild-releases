import { editorRoot, isNarrow, editorButton, keepSelection } from './bar.js';
import { fieldRect } from './page-sync.js';
import { icon } from './icons.js';

// Leuchten und Knöpfe über Elementen der Seite, das Schild „Text ändern“ beim Überfahren, Leisten
// an Plugin-Listen, Mini-Leisten und Dialoge am Element. Alles liegt im Shadow-DOM über der Seite;
// am Kundenelement selbst ändert sich nichts.

// Abstand zum Rand der Ansicht (auch für edit.css als --le-edge) und zwischen Element und Mini-Leiste/Dialog.
const EDGE = 16;
const EDGE_VAR = '--le-edge';
const GAP = 8;
// Rahmen etwas größer als der Inhalt.
const FRAME_PAD = 3;
// Höhe der Leiste unten (page.css), die nichts verdecken soll.
const BAR_HEIGHT_VAR = '--le-bar-height';

// Lage einer Knopf-Gruppe am Element (placeGroup); ohne Angabe links oben.
export const CHIP_PLACE = {
  corner: 'corner',
  above: 'above'
};

let layer = null;
let hoverFrame = null;
let activeFrame = null;
let hoverTag = null;
let chipBox = null;
let pinBox = null;
// Fest angeheftete Elemente unter Plugin-Listen (pin): [{ anchor, element }].
const pins = [];
let hoverTarget = null;
let activeTarget = null;
let chips = [];
const trackers = [];
// Positionierung → ResizeObserver ihres Elements (track mit box).
const boxObservers = new Map();
let scheduled = false;
let frameObserver = null;

function frame(parent, className) {
  const el = document.createElement('div');
  el.className = className;
  el.hidden = true;
  parent.appendChild(el);
  return el;
}

export function mountLayer() {
  // Rahmen und Schild in einer eigenen Ebene ganz vorn im Shadow-Root: Leiste, Menü, Hinweis,
  // Panel und Dialoge liegen damit immer darüber, auch wenn ein Rahmen bis unter die Leiste reicht.
  const frames = document.createElement('div');
  frames.className = 'le-layer';
  hoverFrame = frame(frames, 'le-frame');
  activeFrame = frame(frames, 'le-frame le-frame--active');
  hoverTag = frame(frames, 'le-tag');
  editorRoot().prepend(frames);

  layer = document.createElement('div');
  layer.className = 'le-layer';
  layer.style.setProperty(EDGE_VAR, EDGE + 'px');
  pinBox = document.createElement('div');
  layer.appendChild(pinBox);
  chipBox = document.createElement('div');
  layer.appendChild(chipBox);
  editorRoot().appendChild(layer);

  const schedule = function () {
    if (scheduled) return;
    scheduled = true;
    window.requestAnimationFrame(function () {
      scheduled = false;
      refresh();
    });
  };
  frameObserver = new ResizeObserver(schedule);
  window.addEventListener('scroll', schedule, { capture: true, passive: true });
  window.addEventListener('resize', schedule);
  if (window.visualViewport) {
    window.visualViewport.addEventListener('resize', schedule);
    window.visualViewport.addEventListener('scroll', schedule);
  }
}

// Mini-Leisten und Dialoge hängen hier ein.
export function overlayLayer() {
  return layer;
}

// Positionierungen, die bei Scrollen und Größenänderung neu laufen (Mini-Leiste, Dialog); box: das
// platzierte Element, ändert sich seine Größe (Link-Zeile klappt auf), läuft fn ebenfalls, damit es
// nicht über das Element wächst, an dem es steht.
export function track(fn, box) {
  trackers.push(fn);
  if (box) {
    const observer = new ResizeObserver(function () { fn(); });
    observer.observe(box);
    boxObservers.set(fn, observer);
  }
  fn();
}

export function untrack(fn) {
  const index = trackers.indexOf(fn);
  if (index !== -1) trackers.splice(index, 1);
  const observer = boxObservers.get(fn);
  if (observer) {
    observer.disconnect();
    boxObservers.delete(fn);
  }
}

function placeFrame(el, target) {
  el.hidden = !target;
  if (!target) return;
  const rect = fieldRect(target);
  el.style.left = (rect.left - FRAME_PAD) + 'px';
  el.style.top = (rect.top - FRAME_PAD) + 'px';
  el.style.width = (rect.width + FRAME_PAD * 2) + 'px';
  el.style.height = (rect.height + FRAME_PAD * 2) + 'px';
}

// Gruppe von Knöpfen an ihrem Element: ohne place links oben im Element (Hintergrundbild, Link);
// corner (Plugin-Einträge) rechts bündig direkt über dem Element, mit Maus wie am Handy: nichts von
// ihm verdeckt, die Maus erreicht die Knöpfe, ohne es zu verlassen. Lägen sie dort über einem
// Nachbarn (Einträge untereinander) oder außerhalb der Ansicht, stehen sie rechts oben im Element,
// auf seine Breite umbrochen; above über dem Element wie eine Mini-Leiste (angeklickter Link:
// „Bearbeiten“, „Öffnen →“).
function placeGroup(chip) {
  // Wie der Rahmen: bei einem Link um ein Bild zählt das Bild, nicht die Zeilenbox des Links.
  const rect = fieldRect(chip.anchor);
  if (chip.place === CHIP_PLACE.above) {
    placeNear(chip.group, rect, true);
    return;
  }
  if (chip.place === CHIP_PLACE.corner && placeAbove(chip, rect)) return;
  const width = chip.group.offsetWidth;
  const height = chip.group.offsetHeight;
  const maxLeft = document.documentElement.clientWidth - GAP - width;
  const left = chip.place === CHIP_PLACE.corner ? rect.left + rect.width - GAP - width : rect.left + GAP;
  chip.group.style.left = Math.max(GAP, Math.min(left, maxLeft)) + 'px';
  chip.group.style.top = Math.max(GAP, Math.min(rect.top + GAP, viewBottom() - GAP - height)) + 'px';
}

function overlaps(a, b) {
  return a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom;
}

// Liegt box über einem sichtbaren Nachbarn von anchor (anderes Kind desselben Elternelements, z. B.
// anderer Eintrag der Liste)?
function coversNeighbor(anchor, box) {
  const parent = anchor.parentElement;
  return Boolean(parent) && Array.prototype.some.call(parent.children, function (el) {
    if (el === anchor) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && overlaps(box, rect);
  });
}

// corner direkt über dem Element, wenn dort Platz ist (siehe placeGroup); sonst false und die
// Gruppe bleibt auf die Breite des Elements begrenzt.
function placeAbove(chip, rect) {
  chip.group.style.maxWidth = '';
  const width = chip.group.offsetWidth;
  const height = chip.group.offsetHeight;
  const left = Math.max(GAP, Math.min(rect.left + rect.width - width, document.documentElement.clientWidth - GAP - width));
  const box = { left: left, top: rect.top - height, right: left + width, bottom: rect.top };
  if (box.top >= GAP && !coversNeighbor(chip.anchor, box)) {
    chip.group.style.left = box.left + 'px';
    chip.group.style.top = box.top + 'px';
    return true;
  }
  chip.group.style.maxWidth = Math.max(0, rect.width - GAP * 2) + 'px';
  return false;
}

function placeChips() {
  chips.forEach(placeGroup);
}

// Schild über dem überfahrenen Element, links bündig; ohne Platz darüber oben im Element.
function placeTag() {
  if (hoverTag.hidden || !hoverTarget) return;
  const rect = fieldRect(hoverTarget);
  const height = hoverTag.offsetHeight;
  const above = rect.top - FRAME_PAD - GAP - height;
  hoverTag.style.left = Math.max(GAP, Math.min(rect.left - FRAME_PAD, document.documentElement.clientWidth - GAP - hoverTag.offsetWidth)) + 'px';
  hoverTag.style.top = (above >= GAP ? above : rect.top + GAP) + 'px';
}

// Angeheftetes Element direkt unter seiner Liste, links bündig (der Platz dort ist frei, page.css).
function placePins() {
  pins.forEach(function (pinned) {
    if (!pinned.anchor.isConnected) return;
    const rect = pinned.anchor.getBoundingClientRect();
    const maxLeft = document.documentElement.clientWidth - GAP - pinned.element.offsetWidth;
    pinned.element.hidden = rect.width === 0 && rect.height === 0;
    pinned.element.style.left = Math.max(GAP, Math.min(rect.left, maxLeft)) + 'px';
    pinned.element.style.top = (rect.bottom + GAP) + 'px';
  });
}

// Heftet element unter anchor (Leiste einer Plugin-Liste); liefert eine Funktion zum Lösen.
export function pin(anchor, element) {
  const pinned = { anchor: anchor, element: element };
  element.classList.add('le-pin');
  pins.push(pinned);
  pinBox.appendChild(element);
  placePins();
  return function () {
    const index = pins.indexOf(pinned);
    if (index !== -1) pins.splice(index, 1);
    element.remove();
  };
}

function refresh() {
  placeFrame(hoverFrame, hoverTarget);
  placeFrame(activeFrame, activeTarget);
  placeTag();
  placePins();
  placeChips();
  trackers.forEach(function (fn) { fn(); });
}

// Knopf am Element (le-chip); die Auswahl in einem gerade bearbeiteten Text bleibt bis zum Klick stehen.
// chip: { label, onClick, icon (Symbol aus icons.js), iconOnly (nur Symbol, label als aria-label),
// tone ('primary' Hauptaktion, 'danger' Löschen) }.
function chipButton(chip) {
  const button = keepSelection(editorButton(chip.iconOnly ? '' : chip.label, 'le-chip' + (chip.tone ? ' le-chip--' + chip.tone : ''), chip.onClick));
  if (chip.icon) button.prepend(icon(chip.icon));
  if (chip.iconOnly) {
    button.setAttribute('aria-label', chip.label);
    button.title = chip.label;
  }
  return button;
}

// Leuchten beim Überfahren bzw. ersten Antippen (null = aus), das Schild darüber (tag: Text wie
// „Text ändern“, null ohne) und die Knöpfe für Felder, die sich nicht direkt anklicken lassen
// (Hintergrundbild, Link um ein Bild) bzw. für Plugin-Einträge: [{ anchor, label, onClick, place,
// focus, icon, iconOnly, tone }] (place siehe CHIP_PLACE, focus: Knopf bekommt den Fokus, Rest
// chipButton). Knöpfe am selben Element und Ort stehen nebeneinander in einer Gruppe.
export function showHover(target, chipList, tag) {
  let focusButton = null;
  hoverTarget = target;
  hoverTag.hidden = !target || !tag;
  hoverTag.textContent = '';
  if (target && tag) hoverTag.append(icon(tag.icon), tag.text);
  chipBox.textContent = '';
  chips = [];
  chipList.forEach(function (chip) {
    let entry = chips.find(function (known) { return known.anchor === chip.anchor && known.place === chip.place; });
    if (!entry) {
      const group = document.createElement('div');
      group.className = 'le-chips';
      chipBox.appendChild(group);
      entry = { anchor: chip.anchor, place: chip.place, group: group };
      chips.push(entry);
    }
    const button = entry.group.appendChild(chipButton(chip));
    if (chip.focus) focusButton = button;
  });
  observeFrames();
  refresh();
  if (focusButton) focusButton.focus({ preventScroll: true });
}

// Rahmen um das Element in Bearbeitung (null = aus).
export function showActive(target) {
  activeTarget = target;
  observeFrames();
  refresh();
}

// Rahmen folgen der Größe ihres Elements (Text wächst beim Tippen, Bild lädt nach).
function observeFrames() {
  frameObserver.disconnect();
  [hoverTarget, activeTarget].forEach(function (target) {
    if (target) frameObserver.observe(target);
  });
}

function barHeight() {
  return parseFloat(window.getComputedStyle(document.documentElement).getPropertyValue(BAR_HEIGHT_VAR)) || 0;
}

// Unterkante des sichtbaren Bereichs über der Leiste.
function viewBottom() {
  return window.innerHeight - barHeight();
}

// Setzt ein fixiertes Element (Mini-Leiste, Dialog) an ein Rechteck der Seite: bevorzugt darüber
// (above) oder darunter, sonst auf die andere Seite; nie unter die Leiste oder aus der Ansicht.
export function placeNear(box, rect, above) {
  const viewWidth = document.documentElement.clientWidth;
  const bottom = viewBottom();
  const narrow = isNarrow();
  box.style.width = narrow ? (viewWidth - EDGE * 2) + 'px' : '';
  const width = box.offsetWidth;
  const height = box.offsetHeight;
  const topAbove = rect.top - GAP - height;
  const topBelow = rect.top + rect.height + GAP;
  const fitsAbove = topAbove >= EDGE;
  const fitsBelow = topBelow + height <= bottom - EDGE;
  let top = above ? (fitsAbove || !fitsBelow ? topAbove : topBelow) : (fitsBelow || !fitsAbove ? topBelow : topAbove);
  top = Math.min(Math.max(EDGE, top), Math.max(EDGE, bottom - EDGE - height));
  const left = narrow ? EDGE : Math.min(Math.max(EDGE, rect.left), Math.max(EDGE, viewWidth - EDGE - width));
  box.style.left = left + 'px';
  box.style.top = top + 'px';
}
