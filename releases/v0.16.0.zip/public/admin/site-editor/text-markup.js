import { state } from '../modules/core.js';
import { editorButton, keepSelection } from './bar.js';
import { selectionOf, selectedRange } from './selection.js';

// Knöpfe und Meldungen der Text-Bearbeitung (am Element und im Panel „Alle Texte“).
const TEXT = {
  bold: 'Fett',
  boldTitle: 'Fett (Strg+B)',
  italic: 'Kursiv',
  italicTitle: 'Kursiv (Strg+I)',
  link: 'Link',
  linkTitle: 'Link setzen oder ändern',
  linkPlaceholder: 'https://… oder /seite',
  apply: 'Übernehmen',
  remove: 'Entfernen',
  selectFirst: 'Erst den Text markieren, der verlinkt werden soll.',
  selectFormat: 'Erst den Text markieren, der fett oder kursiv werden soll.',
  badTarget: 'Link-Ziel fehlt oder ist nicht erlaubt'
};

// Textwerte sind bereinigte HTML-Fragmente (erlaubte Inline-Tags, a[href]).
// Bereinigung wie sanitize_text_markup() im Server; die Listen kommen aus dem
// JSON-Block des Seiten-Editors (state.textMarkup). Der Server bereinigt immer nochmal.

// inLink: Text eines Links (Feldart linktext), eigene Links werden ausgepackt.
export function sanitizeTextMarkup(html, inLink) {
  const doc = new DOMParser().parseFromString(String(html == null ? '' : html), 'text/html');
  return trimEdges(render(doc.body.childNodes, !!inLink));
}

// Wie text_markup_trim(): trimEdges an beiden Enden weg, ohne Regex.
function trimEdges(html) {
  const edges = state.textMarkup.trimEdges;
  let start = 0;
  let end = html.length;
  let moved = true;
  while (moved) {
    moved = false;
    edges.forEach(function (edge) {
      while (end - start >= edge.length && html.startsWith(edge, start)) {
        start += edge.length;
        moved = true;
      }
      while (end - start >= edge.length && html.slice(end - edge.length, end) === edge) {
        end -= edge.length;
        moved = true;
      }
    });
  }
  return html.slice(start, end);
}

// Wie text_markup_break(): an einer Blockgrenze <br>, außer am Anfang oder direkt nach einem Umbruch.
function addBreak(out) {
  let end = out.length;
  while (end > 0 && ' \t\n\r\v\0'.indexOf(out[end - 1]) !== -1) end--;
  return end === 0 || out.slice(end - 4, end) === '<br>' ? out : out + '<br>';
}

// URL mit erlaubtem Schema oder relativ, sonst leer (Steuerzeichen zählen wie im Browser nicht).
// Getrimmt wird wie PHP-trim() im Server (nur ASCII-Leerraum), damit Vorschau und Datei gleich sind.
export function sanitizeUrl(url, schemes) {
  const clean = String(url == null ? '' : url).replace(/^[ \t\n\r\0\v]+|[ \t\n\r\0\v]+$/g, '');
  const match = /^([a-z][a-z0-9+.-]*):/i.exec(clean.replace(/[\x00-\x20]+/g, ''));
  return match && schemes.indexOf(match[1].toLowerCase()) === -1 ? '' : clean;
}

function escapeText(text) {
  return String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// Kanonische Ausgabe: Kommentare und fremde Attribute fallen weg, fremde Tags
// werden ausgepackt (Blöcke zwischen <br>), TEXT_DROP_TAGS samt Inhalt entfernt,
// ein Link in einem Link ausgepackt.
function render(nodes, inLink) {
  const cfg = state.textMarkup;
  let out = '';
  Array.prototype.forEach.call(nodes, function (node) {
    if (node.nodeType === Node.TEXT_NODE) {
      out += escapeText(node.data);
      return;
    }
    if (node.nodeType !== Node.ELEMENT_NODE || cfg.dropTags.indexOf(node.localName) !== -1) {
      return;
    }
    const tag = node.localName;
    const inner = render(node.childNodes, inLink || tag === 'a');
    if (cfg.tags.indexOf(tag) === -1) {
      const block = cfg.blockTags.indexOf(tag) !== -1;
      out = (block ? addBreak(out) : out) + inner;
      out = block ? addBreak(out) : out;
      return;
    }
    if (tag === 'br') {
      out += '<br>';
      return;
    }
    if (inner === '') {
      return;
    }
    if (tag === 'a') {
      const href = inLink ? '' : sanitizeUrl(node.getAttribute('href'), cfg.linkSchemes);
      out += href === '' ? inner : '<a href="' + escapeText(href) + '">' + inner + '</a>';
      return;
    }
    out += '<' + tag + '>' + inner + '</' + tag + '>';
  });
  return out;
}

function closestAnchor(node, area) {
  while (node && node !== area) {
    if (node.nodeType === Node.ELEMENT_NODE && node.localName === 'a') return node;
    node = node.parentNode;
  }
  return null;
}

// Meldung, wenn ein Link-Ziel fehlt oder ein nicht erlaubtes Schema hat (Text-Links und Link-Felder).
export function linkTargetMessage() {
  return TEXT.badTarget + ' (' + state.textMarkup.linkSchemes.join(', ') + ' oder ein Pfad).';
}

// Erlaubtes Link-Ziel oder leer (dann linkTargetMessage zeigen).
export function cleanLinkTarget(value) {
  return sanitizeUrl(value, state.textMarkup.linkSchemes);
}

// Text als Fragment mit <br> statt Zeilenumbrüchen (Einfügen und Ablegen nehmen nur Text).
function plainTextHtml(text) {
  return escapeText(text).replace(/\r?\n/g, '<br>');
}

// Fett und Kursiv: welche Tags im Feld als solche zählen und welches Tag neu gesetzt wird.
const FORMATS = {
  bold: { tags: ['strong', 'b'], tag: 'strong' },
  italic: { tags: ['em', 'i'], tag: 'em' }
};

// Äußerstes Format-Element um node im Feld (bei <strong><b>…</b></strong> aus Word oder CMS das
// <strong>), damit Herauslösen in einem Schritt wirkt und kein inneres Element abgehängt wird.
function outermostFormat(node, tags, area) {
  let found = null;
  while (node && node !== area) {
    if (node.nodeType === Node.ELEMENT_NODE && tags.indexOf(node.localName) !== -1) found = node;
    node = node.parentNode;
  }
  return found;
}

// Fett/Kursiv-Hüllen ohne Inhalt (bleiben von extractContents an den Rändern der Auswahl) entfernen.
function removeEmptyFormats(area) {
  const tags = FORMATS.bold.tags.concat(FORMATS.italic.tags).join(',');
  area.querySelectorAll(tags).forEach(function (el) {
    if (el.textContent === '' && !el.querySelector('br')) el.remove();
  });
}

function unwrap(el) {
  while (el.firstChild) el.parentNode.insertBefore(el.firstChild, el);
  el.remove();
}

// Teil eines aufgeteilten Format-Elements; leer (ohne Text und Umbruch) fällt weg.
function formatPart(source, fragment) {
  if (fragment.textContent === '' && !fragment.querySelector('br')) return null;
  const el = document.createElement(source.localName);
  el.appendChild(fragment);
  return el;
}

function selectBetween(first, last) {
  const range = document.createRange();
  range.setStartBefore(first);
  range.setEndAfter(last);
  const selection = selectionOf(first);
  selection.removeAllRanges();
  selection.addRange(range);
}

// Format-Elemente um die ausgewählten Textstücke; null, wenn ein Stück keins hat.
function formatsInRange(range, area, tags) {
  const walker = document.createTreeWalker(area, NodeFilter.SHOW_TEXT);
  const found = [];
  let node;
  while ((node = walker.nextNode())) {
    const start = node === range.startContainer ? range.startOffset : 0;
    const end = node === range.endContainer ? range.endOffset : node.data.length;
    if (!range.intersectsNode(node) || start >= end || node.data.slice(start, end).trim() === '') continue;
    const outer = outermostFormat(node, tags, area);
    if (!outer) return null;
    if (found.indexOf(outer) === -1) found.push(outer);
  }
  return found.length ? found : null;
}

// Löst die Auswahl aus den Format-Elementen heraus; Teile davor und danach bleiben formatiert.
function removeFormat(range, outers, tags) {
  let first = null;
  let last = null;
  outers.forEach(function (outer) {
    const inner = document.createRange();
    inner.selectNodeContents(outer);
    if (range.compareBoundaryPoints(Range.START_TO_START, inner) > 0) inner.setStart(range.startContainer, range.startOffset);
    if (range.compareBoundaryPoints(Range.END_TO_END, inner) < 0) inner.setEnd(range.endContainer, range.endOffset);
    const before = document.createRange();
    before.setStart(outer, 0);
    before.setEnd(inner.startContainer, inner.startOffset);
    const after = document.createRange();
    after.setStart(inner.endContainer, inner.endOffset);
    after.setEnd(outer, outer.childNodes.length);
    const middle = inner.cloneContents();
    middle.querySelectorAll(tags.join(',')).forEach(unwrap);
    first = first || middle.firstChild;
    last = middle.lastChild || last;
    [formatPart(outer, before.cloneContents()), middle, formatPart(outer, after.cloneContents())].forEach(function (part) {
      if (part) outer.parentNode.insertBefore(part, outer);
    });
    outer.remove();
  });
  if (first && last) selectBetween(first, last);
}

// Fett/Kursiv als Umschalter nach der Auszeichnung im Feld, nicht nach dem berechneten Stil
// (execCommand nähme in fett gesetzten Überschriften die Fettung weg und hinterließe ein <span>).
// Ist jedes ausgewählte Textstück schon formatiert, wird es herausgelöst, sonst alles eingepackt.
// false ohne Auswahl.
function toggleFormat(area, format) {
  const range = selectedRange(area);
  if (!range || range.collapsed || !area.contains(range.commonAncestorContainer)) return false;
  const outers = formatsInRange(range, area, format.tags);
  if (outers) {
    removeFormat(range, outers, format.tags);
  } else {
    const content = range.extractContents();
    content.querySelectorAll(format.tags.join(',')).forEach(unwrap);
    const el = document.createElement(format.tag);
    el.appendChild(content);
    range.insertNode(el);
    selectBetween(el, el);
  }
  removeEmptyFormats(area);
  return true;
}

// Cursor an einen Punkt der Ansicht setzen, wenn er in area liegt (Klick, Ablegen).
export function placeCaret(area, x, y) {
  let range = null;
  if (document.caretRangeFromPoint) {
    range = document.caretRangeFromPoint(x, y);
  } else if (document.caretPositionFromPoint) {
    const position = document.caretPositionFromPoint(x, y);
    if (position) {
      range = document.createRange();
      range.setStart(position.offsetNode, position.offset);
    }
  }
  if (!range || !area.contains(range.startContainer)) return;
  const selection = window.getSelection();
  selection.removeAllRanges();
  selection.addRange(range);
}

// Text-Bearbeitung an einem contenteditable-Element (area): Knöpfe Fett, Kursiv und – außer bei
// Linktext (inLink) – Link mit Zielzeile. Einfügen und Ablegen übernehmen nur reinen Text,
// Enter fügt einen Zeilenumbruch ein. Die Elemente bekommen die Klassen aus classes
// ({ toolbar, linkRow, button, secondary, hidden }), damit Mini-Leiste und Panel ihr eigenes CSS haben.
// onInput (optional) bekommt bei jeder Änderung das bereinigte Fragment, onMessage(text, ok) Hinweise.
// Liefert { toolbar, linkRow, handlers, closeLinkRow }; handlers (input, keydown, paste, drop) hängt
// der Aufrufer an, das Panel an die Fläche, die Seite in der Capture-Phase, damit Kunden-Skripte
// nichts mitbekommen. closeLinkRow() schließt eine offene Link-Zeile (true, wenn sie offen war).
export function attachTextEditing(area, options) {
  const classes = options.classes;
  const inLink = !!options.inLink;
  const toolbar = document.createElement('div');
  toolbar.className = classes.toolbar;
  const linkRow = document.createElement('div');
  linkRow.className = classes.linkRow + ' ' + classes.hidden;

  function sync() {
    if (options.onInput) options.onInput(sanitizeTextMarkup(area.innerHTML, inLink));
  }
  function command(name, arg) {
    area.focus();
    const done = document.execCommand(name, false, arg);
    sync();
    return done;
  }
  // mousedown würde die Auswahl im Textfeld aufheben (keepSelection).
  function button(label, title, secondary, onClick) {
    const el = keepSelection(editorButton(label, classes.button + (secondary ? ' ' + classes.secondary : ''), onClick));
    if (title) el.title = title;
    return el;
  }
  function addButton(label, title, onClick) {
    return toolbar.appendChild(button(label, title, true, onClick));
  }

  function format(kind) {
    if (!toggleFormat(area, kind)) {
      options.onMessage(TEXT.selectFormat, false);
      return;
    }
    options.onMessage('', true);
    sync();
  }

  addButton(TEXT.bold, TEXT.boldTitle, function () { format(FORMATS.bold); });
  addButton(TEXT.italic, TEXT.italicTitle, function () { format(FORMATS.italic); });

  // Schließt eine offene Link-Zeile (Esc); true, wenn sie offen war.
  let closeLinkRow = function () { return false; };

  if (!inLink) {
    const linkInput = document.createElement('input');
    linkInput.type = 'url';
    linkInput.placeholder = TEXT.linkPlaceholder;
    const applyButton = button(TEXT.apply, '', false, applyLink);
    const removeButton = button(TEXT.remove, '', true, removeLink);
    linkRow.appendChild(linkInput);
    linkRow.appendChild(applyButton);
    linkRow.appendChild(removeButton);

    let savedRange = null;
    let savedAnchor = null;

    // Auswahl wiederherstellen; ein Cursor in einem Link meint den ganzen Link.
    function restoreSelection() {
      const selection = selectionOf(area);
      selection.removeAllRanges();
      if (savedRange.collapsed && savedAnchor) {
        savedRange.selectNodeContents(savedAnchor);
      }
      selection.addRange(savedRange);
    }
    function hideLinkRow() {
      savedRange = null;
      savedAnchor = null;
      linkRow.classList.add(classes.hidden);
      options.onMessage('', true);
    }

    addButton(TEXT.link, TEXT.linkTitle, function () {
      const range = selectedRange(area);
      const anchor = range && area.contains(range.commonAncestorContainer) ? closestAnchor(range.commonAncestorContainer, area) : null;
      // Ohne gültige Auswahl schließt die Link-Zeile, damit kein altes Ziel übernommen wird.
      if (!range || !area.contains(range.commonAncestorContainer) || (range.collapsed && !anchor)) {
        hideLinkRow();
        options.onMessage(TEXT.selectFirst, false);
        return;
      }
      savedRange = range;
      savedAnchor = anchor;
      linkInput.value = savedAnchor ? savedAnchor.getAttribute('href') : '';
      linkRow.classList.remove(classes.hidden);
      linkInput.focus();
    });
    function applyLink() {
      if (!savedRange) return;
      const href = cleanLinkTarget(linkInput.value);
      if (href === '') {
        options.onMessage(linkTargetMessage(), false);
        return;
      }
      restoreSelection();
      command('createLink', href);
      hideLinkRow();
    }
    function removeLink() {
      if (!savedRange) return;
      restoreSelection();
      command('unlink');
      hideLinkRow();
    }
    closeLinkRow = function () {
      if (linkRow.classList.contains(classes.hidden)) return false;
      hideLinkRow();
      return true;
    };
    linkInput.addEventListener('keydown', function (event) {
      if (event.key === 'Enter') {
        event.preventDefault();
        applyButton.click();
      }
    });
  }

  const handlers = {
    input: sync,
    keydown: function (event) {
      // Strg/Cmd+B und +I wie die Knöpfe; +U gäbe ein <u>, das nicht erlaubt ist.
      const key = event.key.toLowerCase();
      if ((event.ctrlKey || event.metaKey) && !event.altKey && (key === 'b' || key === 'i' || key === 'u')) {
        event.preventDefault();
        if (key !== 'u') format(key === 'b' ? FORMATS.bold : FORMATS.italic);
        return;
      }
      if (event.key !== 'Enter') return;
      event.preventDefault();
      if (!command('insertLineBreak')) {
        command('insertHTML', '<br>');
      }
    },
    // Formatierter Text aus der Zwischenablage (Word, Webseiten) kommt nur als Text an.
    paste: function (event) {
      if (!event.clipboardData) return;
      event.preventDefault();
      command('insertHTML', plainTextHtml(event.clipboardData.getData('text/plain')));
    },
    // Abgelegter Text ebenso; die Einfügestelle ist der Punkt unter der Maus.
    drop: function (event) {
      if (!event.dataTransfer) return;
      event.preventDefault();
      placeCaret(area, event.clientX, event.clientY);
      command('insertHTML', plainTextHtml(event.dataTransfer.getData('text/plain')));
    }
  };

  return { toolbar: toolbar, linkRow: linkRow, handlers: handlers, closeLinkRow: function () { return closeLinkRow(); } };
}
