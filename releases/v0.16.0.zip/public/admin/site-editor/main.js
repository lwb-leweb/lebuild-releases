import { state, applyEditLists, UPDATE_TEXT, versionStep } from '../modules/core.js';
import { mountBar, addEditorStyle, notify } from './bar.js';
import { readEditorConfig, readCsrfToken } from './config.js';
import { mountLayer } from './overlay.js';
import { startSession } from './session.js';
import { attachInteractions } from './interact.js';
import { mountHistory } from './history.js';
import { mountAllFields } from './all-fields.js';
import { mountPluginLists } from './plugin-lists.js';

// Seiten-Editor: index.php hängt dieses Modul für angemeldete Benutzer vor </body> ein
// (core/siteEditor.php), dazu CSRF-Token und Daten (Name, Rolle aus users.json, Seite, Listen für
// Text, Bilder und Upload wie in api/bootstrap.php). Kein eigener Abruf beim Seitenaufruf.
// Die Backend-Seitenansicht zeigt die Seite im iframe, auch dort mit diesem Editor.

const EDIT_STYLE = new URL('edit.css', import.meta.url).href;
// Texteditor in Formularen von Plugin-Einträgen (richtext.js), dieselbe Datei wie im Backend.
const RICHTEXT_STYLE = new URL('richtext.css', import.meta.url).href;
const MAIN_TEXT = {
  loadFailed: 'Texte und Bilder dieser Seite lassen sich gerade nicht bearbeiten:'
};

function start() {
  const config = readEditorConfig(document);
  state.csrfToken = readCsrfToken(document);
  state.username = config.username;
  state.role = config.role;
  applyEditLists(config);
  mountBar(config.page);
  addEditorStyle(EDIT_STYLE);
  addEditorStyle(RICHTEXT_STYLE);
  mountLayer();
  // Plugin-Listen gibt es auch ohne Seite (Blog-Einzelansicht, Unterordner) und auch, wenn die
  // Inhalte der Seite nicht laden: Ihre Knöpfe brauchen nur attachInteractions.
  mountPluginLists(config);
  if (config.updateInstalled) {
    notify(UPDATE_TEXT.installed + ' ' + versionStep(config.updateInstalled.previousVersion, config.updateInstalled.newVersion));
  }
  // Ohne Inhalte (getPage scheitert, z. B. kaputte Seiten-JSON) bleibt „Verlauf“: Ein früherer
  // Stand repariert die Seite. „Alle Texte“ braucht die Inhalte.
  const loaded = config.page === null ? Promise.resolve() : startSession(config.page).then(function () {
    mountHistory();
    mountAllFields();
  }, function (error) {
    state.currentPage = config.page;
    notify(MAIN_TEXT.loadFailed + ' ' + error.message);
    mountHistory();
  });
  loaded.finally(attachInteractions).catch(function (error) { notify(error.message); });
}

start();
