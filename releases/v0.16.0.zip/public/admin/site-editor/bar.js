import { state, isAdmin, logout, ADMIN_URL, pageRoute } from '../modules/core.js';
import { showToast } from './toast.js';
import { errorNotice } from './request.js';
import { icon } from './icons.js';
import { ENTRY_TEXT } from './entry-form.js';
import { editorButton, keepSelection } from './buttons.js';

export { editorButton, keepSelection };

// Leiste unten auf der Website: eine schwebende Pille mit dem Schalter Bearbeiten (an/aus = Ansehen), dem Stand
// („Alles gespeichert“, „2 Änderungen nicht gespeichert“), Rückgängig, Speichern und „Mehr“ (Verlauf,
// „Alle Texte“, Hilfe, Verwaltung, Abmelden). Sie lebt in einem Shadow-DOM, damit Kunden-CSS und
// Editor-CSS sich nicht gegenseitig verändern; alle Klassen tragen das Präfix le-. Beim ersten
// Besuch erklärt ein Hinweis über der Leiste, wie es geht.
const BAR_TAG = 'le-site-editor';
// Token des Design Systems (core/siteEditor.php SITE_EDITOR_TOKENS, dort auch im Dokument für die Schrift).
const TOKENS_STYLE = new URL('../design/tokens.css', import.meta.url).href;
const BAR_STYLE = new URL('bar.css', import.meta.url).href;
const TOAST_STYLE = new URL('toast.css', import.meta.url).href;
// Klasse am <html>, solange die Leiste da ist; page.css hält damit unten Platz frei.
const PAGE_CLASS = 'le-editing';
// Klasse an <html> und am Host in der Ansicht „Ansehen“: die Seite wie Besucher sie sehen.
const PREVIEW_CLASS = 'le-preview';
const BAR_TEXT = {
  label: 'Website bearbeiten',
  edit: ENTRY_TEXT.edit,
  view: 'Ansehen',
  admin: 'Verwaltung',
  adminHint: 'Benutzer, Einstellungen, Plugins',
  logout: 'Abmelden',
  logoutHint: 'Angemeldet als ',
  help: 'Hilfe',
  helpHint: 'Die kurze Anleitung noch einmal zeigen',
  more: 'Mehr',
  clean: 'Alles gespeichert',
  editing: 'Wird bearbeitet',
  change: 'Änderung nicht gespeichert',
  changes: 'Änderungen nicht gespeichert',
  hintTitle: 'So einfach geht’s',
  hintMouse: 'Fahre mit der Maus über die Seite: Alles, was grün aufleuchtet, kannst du anklicken und ändern. Danach auf „Speichern“ – dann ist es sofort online.',
  hintTouch: 'Tippe auf einen Text oder ein Bild: Es leuchtet grün auf, ein zweites Antippen ändert es. Danach auf „Speichern“ – dann ist es sofort online.',
  hintOk: 'Verstanden'
};
// Hinweis beim ersten Besuch: einmal je Browser (localStorage), über „Hilfe“ wieder.
const HINT_KEY = 'le-site-editor-hint-seen';
// Bis zu dieser Breite (Handy) zeigt der Schalter Bearbeiten nur Haken oder X, der Stand nur Punkt und
// Zahl, und Dialoge und Seitenpanel gehen über die ganze Breite (overlay.js). Die einzige Stelle für
// die Grenze: bar.css und edit.css richten sich nach der Klasse am Host (:host(.le-narrow)), nicht
// nach einer eigenen Media Query.
const NARROW_MAX = 480;
const NARROW_CLASS = 'le-narrow';
const narrowQuery = window.matchMedia('(max-width: ' + NARROW_MAX + 'px)');
const touchQuery = window.matchMedia('(hover: none)');

export function isNarrow() {
  return narrowQuery.matches;
}

let actions = null;
let menu = null;
// Erster fester Eintrag im Menü (Hilfe); Einträge über addMenuButton kommen davor.
let menuFixed = null;
let more = null;
let status = null;
let hint = null;
let modeButton = null;
let host = null;
let root = null;
let preview = false;
// Wer beim Wechsel Bearbeiten/Ansehen etwas tun muss (interact.js): fn(preview) → false hält den Wechsel auf.
const modeListeners = [];

// Knopf nur mit Symbol; label als aria-label und Tooltip.
export function iconButton(name, label, className, onClick) {
  const button = editorButton('', className, onClick);
  button.append(icon(name));
  button.setAttribute('aria-label', label);
  button.title = label;
  return button;
}

// Knopf mit Symbol vor dem Text.
export function labeledButton(name, label, className, onClick) {
  const button = editorButton('', className, onClick);
  const text = document.createElement('span');
  text.textContent = label;
  button.append(icon(name), text);
  return button;
}

// In der Backend-Seitenansicht (iframe in einer Seite derselben Website) haben Verwaltung und
// Abmelden ihren Platz im Backend; Abmelden lüde dort nur den iframe neu.
function inBackendFrame() {
  try {
    return window.top !== window && window.top.location.origin === window.location.origin;
  } catch (e) {
    return false;
  }
}

function logoutFromSite() {
  logout().catch(function (error) { notify(error.message); });
}

function link(href, className) {
  const el = document.createElement('link');
  el.rel = 'stylesheet';
  el.href = href;
  if (className) el.className = className;
  return el;
}

// Eintrag im Menü „Mehr“: Symbol, Titel, eine Zeile Erklärung darunter.
function menuEntry(name, label, note, tag) {
  const entry = document.createElement(tag || 'button');
  entry.className = 'le-menu__entry';
  if (entry.tagName === 'BUTTON') entry.type = 'button';
  const text = document.createElement('span');
  text.className = 'le-menu__text';
  const title = document.createElement('span');
  title.append(label);
  text.appendChild(title);
  if (note) {
    const small = document.createElement('small');
    small.textContent = note;
    text.appendChild(small);
  }
  entry.append(icon(name), text);
  return entry;
}

function storedHintSeen() {
  try {
    return window.localStorage.getItem(HINT_KEY) === '1';
  } catch (e) {
    return false;
  }
}

function buildHint() {
  const box = document.createElement('div');
  box.className = 'le-hint';
  box.setAttribute('role', 'note');
  const badge = document.createElement('span');
  badge.className = 'le-hint__icon';
  badge.appendChild(icon('pointer'));
  const text = document.createElement('div');
  const title = document.createElement('strong');
  title.textContent = BAR_TEXT.hintTitle;
  const body = document.createElement('p');
  body.textContent = touchQuery.matches ? BAR_TEXT.hintTouch : BAR_TEXT.hintMouse;
  const ok = editorButton(BAR_TEXT.hintOk, 'le-btn le-btn--secondary le-btn--small', hideHint);
  text.append(title, body, ok);
  box.append(badge, text);
  box.hidden = true;
  return box;
}

export function showHint() {
  closeMenu();
  hint.hidden = false;
}

function hideHint() {
  hint.hidden = true;
  try { window.localStorage.setItem(HINT_KEY, '1'); } catch (e) { /* ohne Speicher kommt er beim nächsten Mal wieder */ }
}

// Bearbeiten/Ansehen; ein Zuhörer kann den Wechsel aufhalten (Bearbeitung lässt sich nicht übernehmen).
function setPreview(value) {
  if (value === preview) return;
  if (modeListeners.some(function (fn) { return fn(value) === false; })) return;
  preview = value;
  host.classList.toggle(PREVIEW_CLASS, value);
  document.documentElement.classList.toggle(PREVIEW_CLASS, value);
  showModeState();
  closeMenu();
  if (value) hint.hidden = true;
}

export function isPreview() {
  return preview;
}

export function onModeChange(fn) {
  modeListeners.push(fn);
}

// Ein Schalter für beide Ansichten: „Bearbeiten“ mit Haken (an) oder X (aus, also „Ansehen“).
function showModeState() {
  modeButton.setAttribute('aria-checked', String(!preview));
  modeButton.title = preview ? BAR_TEXT.view : BAR_TEXT.edit;
  const mark = document.createElement('span');
  mark.className = 'le-mode__mark';
  mark.appendChild(icon(preview ? 'close' : 'check'));
  modeButton.firstChild.replaceWith(mark);
}

function buildModeSwitch() {
  modeButton = editorButton('', 'le-mode', function () { setPreview(!preview); });
  modeButton.setAttribute('role', 'switch');
  modeButton.setAttribute('aria-label', BAR_TEXT.edit);
  const text = document.createElement('span');
  text.className = 'le-mode__text';
  text.textContent = BAR_TEXT.edit;
  modeButton.append(document.createElement('span'), text);
  showModeState();
  return modeButton;
}

// page: Seite dieser Datei (null ohne); „Verwaltung“ öffnet sie im Backend.
export function mountBar(page) {
  host = document.createElement(BAR_TAG);
  root = host.attachShadow({ mode: 'open' });

  const bar = document.createElement('div');
  bar.className = 'le-bar';
  bar.setAttribute('role', 'toolbar');
  bar.setAttribute('aria-label', BAR_TEXT.label);

  status = document.createElement('span');
  status.className = 'le-bar__status';
  status.setAttribute('role', 'status');

  actions = document.createElement('div');
  actions.className = 'le-bar__actions';

  menu = document.createElement('div');
  menu.className = 'le-menu';
  menu.hidden = true;
  const help = menuEntry('help', BAR_TEXT.help, BAR_TEXT.helpHint);
  help.addEventListener('click', showHint);
  menu.appendChild(help);
  menuFixed = help;
  if (!inBackendFrame()) {
    menu.appendChild(document.createElement('hr'));
    if (isAdmin()) {
      const admin = menuEntry('settings', BAR_TEXT.admin, BAR_TEXT.adminHint, 'a');
      admin.href = page === null ? ADMIN_URL : ADMIN_URL + '/' + pageRoute(encodeURIComponent(page));
      menu.appendChild(admin);
    }
    const out = menuEntry('logout', BAR_TEXT.logout, BAR_TEXT.logoutHint + state.username);
    out.addEventListener('click', logoutFromSite);
    menu.appendChild(out);
  }

  more = iconButton('more', BAR_TEXT.more, 'le-icon-btn le-bar__more', function () {
    if (menu.hidden) {
      menu.hidden = false;
      hint.hidden = true;
      more.setAttribute('aria-expanded', 'true');
    } else {
      closeMenu();
    }
  });
  more.setAttribute('aria-expanded', 'false');
  hint = buildHint();

  const applyWidth = function () {
    host.classList.toggle(NARROW_CLASS, isNarrow());
    closeMenu();
  };
  narrowQuery.addEventListener('change', applyWidth);
  // Tipp oder Klick daneben schließt das Menü.
  window.addEventListener('pointerdown', function (event) {
    const path = event.composedPath();
    if (path.indexOf(more) === -1 && path.indexOf(menu) === -1) closeMenu();
  }, true);
  applyWidth();

  bar.append(buildModeSwitch(), status, actions, more);
  root.append(link(TOKENS_STYLE), link(BAR_STYLE), link(TOAST_STYLE), hint, menu, bar);
  document.body.appendChild(host);
  document.documentElement.classList.add(PAGE_CLASS);
  setBarStatus(0, false);
  if (!storedHintSeen()) hint.hidden = false;
}

function closeMenu() {
  menu.hidden = true;
  more.setAttribute('aria-expanded', 'false');
}

// Stand in der Leiste: count gespeicherte Änderungen, editing eine laufende geänderte Bearbeitung.
export function setBarStatus(count, editing) {
  status.textContent = '';
  const clean = !count && !editing;
  status.classList.toggle('le-bar__status--dirty', !clean);
  if (clean) {
    status.append(icon('check'));
  } else {
    const dot = document.createElement('span');
    dot.className = 'le-bar__dot';
    status.append(dot);
  }
  const text = document.createElement('span');
  const word = document.createElement('span');
  word.className = 'le-bar__wide';
  if (clean) {
    word.textContent = BAR_TEXT.clean;
  } else if (count) {
    text.append(String(count) + ' ');
    word.textContent = count === 1 ? BAR_TEXT.change : BAR_TEXT.changes;
  } else {
    word.textContent = BAR_TEXT.editing;
  }
  text.append(word);
  status.append(text);
}

// Knopf hinten in der Leiste (Rückgängig mit Symbol, Speichern); className aus bar.css.
export function addBarButton(button) {
  return actions.appendChild(button);
}

// Eintrag im Menü „Mehr“ vor Hilfe, Verwaltung und Abmelden (Verlauf, „Alle Texte“); schließt das
// Menü beim Klick. name: Symbol (icons.js), note: eine Zeile Erklärung.
export function addMenuButton(name, label, note, onClick) {
  const entry = menuEntry(name, label, note);
  entry.addEventListener('click', function () {
    closeMenu();
    onClick();
  });
  menu.insertBefore(entry, menuFixed);
  return entry;
}

// Element der Seite, in dem der Editor lebt (Ereignisse daraus gehören nicht zur Website).
export function editorHost() {
  return host;
}

// Shadow-DOM für Rahmen, Mini-Leisten und Dialoge des Editors.
export function editorRoot() {
  return root;
}

// Weiteres Stylesheet im Shadow-DOM (URL relativ zum aufrufenden Modul auflösen), vor dem Hinweis.
export function addEditorStyle(href) {
  root.insertBefore(link(href), hint);
}

// Hinweis unten über der Leiste; ohne Text keiner. action (optional): { label, onClick } als Knopf darin.
export function notify(message, action) {
  if (message) showToast(message, root, action ? editorButton(action.label, 'le-btn le-btn--small', action.onClick) : null);
}

// Hinweis zu einem Fehler eines Aufrufs (errorNotice: bei abgelaufener Anmeldung mit „Neu anmelden“).
export function notifyError(error) {
  const notice = errorNotice(error);
  notify(notice.message, notice.action);
}
