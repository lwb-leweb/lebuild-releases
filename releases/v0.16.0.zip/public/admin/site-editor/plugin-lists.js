import { notify, notifyError, editorButton, labeledButton } from './bar.js';
import { editorApi, editorPost } from './request.js';
import { SESSION_TEXT } from './session.js';
import { showHover, pin, CHIP_PLACE } from './overlay.js';
import { addChipSource } from './interact.js';
import { askConfirm } from './confirm.js';
import { icon } from './icons.js';
import { openPanel, closePanel, panelFooter } from './panel.js';
import { buildEntryForm, deleteQuestion, entryTitle, ENTRY_TEXT } from './entry-form.js';
import { PICKER_CLASS } from './field-editors.js';

// Plugin-Listen auf der Seite: Renderer markieren Liste, Eintrag und Einzelansicht
// (le_list_attrs/le_item_attrs/le_single_attrs, Namen aus dem JSON-Block). Für Plugins mit
// inlineEdit in plugin.json steht unter jeder Liste beim Bearbeiten immer ihre Leiste
// („Mitarbeiter · 5 Einträge“, „+ Neuer Eintrag“; page.css hält dort Platz frei). Ein Klick auf
// einen Eintrag öffnet sein Formular, beim Überfahren (Handy: erstes Antippen) zeigt er seine
// Knöpfe (Bearbeiten, ↑/↓ mit sort-Endpoint, Löschen). Einträge speichern sofort über ihr Formular
// (entry-form.js) und gehören nicht zu Speichern/Rückgängig der Seite; danach wird nur die Liste
// aus der neu abgerufenen Seite getauscht, Ungespeichertes auf der Seite bleibt.

const LIST_TEXT = {
  add: 'Neuer Eintrag',
  entryEyebrow: 'Eintrag',
  edit: ENTRY_TEXT.edit,
  remove: 'Löschen',
  removeNote: 'Das lässt sich nicht rückgängig machen.',
  up: 'Nach vorne',
  down: 'Nach hinten',
  entry: 'Eintrag',
  entries: 'Einträge',
  editSingle: 'Diesen Beitrag bearbeiten',
  saved: SESSION_TEXT.saved,
  deleted: 'Gelöscht.',
  hidden: SESSION_TEXT.saved + ' Der Eintrag ist in dieser Liste nicht zu sehen.',
  singleGone: SESSION_TEXT.saved + ' Der Beitrag ist unter dieser Adresse nicht mehr zu sehen.',
  reloadFailed: 'Die Liste lässt sich nicht neu laden. Bitte die Seite neu laden.'
};
// Panel-Schlüssel des Formulars (panel.js).
const FORM_KEY = 'entry';
// Platz unter Listen (page.css): eigener Abstand der Website unter der Liste (hier gemessen) und
// Klasse an <html>, die die Abstandsregel zum Messen aussetzt.
const LIST_SPACE = {
  ownMarginVar: '--le-list-own-margin',
  measuringClass: 'le-list-measuring'
};
// Klassen des Formulars im Shadow-DOM (edit.css).
const PAGE_LOOK = {
  form: 'le-form',
  field: 'le-field le-field--panel',
  labelTag: 'span',
  label: 'le-field__label',
  checkbox: 'le-field le-field--checkbox',
  picker: PICKER_CLASS,
  image: 'le-field__image',
  imageEmpty: 'le-field__image-empty',
  imageDrop: 'le-field__drop',
  imageDropActive: 'le-field__drop--active',
  imageActions: 'le-field__image-actions'
};

// plugin_lists_config() (core/plugins.php): { endpoints je Plugin, attrs, separator, directions }.
let lists = null;
let attrs = null;
// Ein Abruf (Laden, Löschen, Sortieren) zur Zeit.
let busy = false;
// Name der Liste je Schlüssel („Mitarbeiter“), aus dem list-Endpoint; null, solange unbekannt.
const listLabels = new Map();
// Lösen der Leisten unter den Listen (overlay.js pin).
let unpinBars = [];

function attrSelector(attr, value) {
  return value === undefined ? '[' + attr + ']' : '[' + attr + '="' + CSS.escape(value) + '"]';
}

function withQuery(url, params) {
  const target = new URL(url, window.location.origin);
  Object.keys(params).forEach(function (name) { target.searchParams.set(name, params[name]); });
  return target.pathname + target.search;
}

// Liste oder Einzelansicht mit Plugin, Typ und Endpoints; null, wenn das Plugin nicht mitmacht.
function placeOf(container) {
  const single = container.hasAttribute(attrs.single);
  const key = container.getAttribute(single ? attrs.single : attrs.list);
  const cut = key.indexOf(lists.separator);
  const plugin = cut > 0 ? key.slice(0, cut) : '';
  if (!plugin || !Object.prototype.hasOwnProperty.call(lists.endpoints, plugin)) return null;
  return { container: container, single: single, key: key, type: key.slice(cut + lists.separator.length), urls: lists.endpoints[plugin] };
}

function containerOf(item) {
  return item.closest(attrSelector(attrs.list) + ',' + attrSelector(attrs.single));
}

function idOf(item) {
  return parseInt(item.getAttribute(attrs.item), 10);
}

// Einträge genau dieser Liste (nicht die einer Liste darin).
function itemsOf(place) {
  return Array.prototype.filter.call(place.container.querySelectorAll(attrSelector(attrs.item)), function (item) {
    return containerOf(item) === place.container;
  });
}

// Listen mitmachender Plugins auf der Seite.
function listsOnPage() {
  return Array.prototype.filter.call(document.querySelectorAll(attrSelector(attrs.list)), function (list) {
    return placeOf(list) !== null;
  });
}

// Eigenen Abstand der Website unter jeder Liste messen (ohne die Regel aus page.css) und an der
// Liste ablegen: page.css nimmt den größeren davon und den Platz für „+ Hinzufügen“. Neu nach dem
// Neuladen einer Liste und bei Größenänderung (Media Queries der Website).
function measureListSpace() {
  const found = document.querySelectorAll(attrSelector(attrs.list));
  const root = document.documentElement;
  const scrollX = window.scrollX;
  const scrollY = window.scrollY;
  root.classList.add(LIST_SPACE.measuringClass);
  const margins = Array.prototype.map.call(found, function (list) { return window.getComputedStyle(list).marginBottom; });
  root.classList.remove(LIST_SPACE.measuringClass);
  Array.prototype.forEach.call(found, function (list, index) { list.style.setProperty(LIST_SPACE.ownMarginVar, margins[index]); });
  // Ohne die Regel ist die Seite kurz kürzer; der Browser kann dabei die Scrollposition kappen.
  if (window.scrollX !== scrollX || window.scrollY !== scrollY) window.scrollTo({ left: scrollX, top: scrollY, behavior: 'instant' });
}

function run(task) {
  if (busy) return;
  busy = true;
  task()
    .catch(notifyError)
    .finally(function () { busy = false; });
}

// Holt die Seite neu und tauscht die Liste (bei mehreren gleichen per Reihenfolge) bzw. die
// Einzelansicht; id: gespeicherter Eintrag, der danach zu sehen sein sollte (null ohne).
function reload(place, id, message) {
  const selector = place.single
    ? attrSelector(attrs.single, place.key) + attrSelector(attrs.item, String(idOf(place.container)))
    : attrSelector(attrs.list, place.key);
  const index = Array.prototype.indexOf.call(document.querySelectorAll(selector), place.container);
  return fetch(window.location.href, { credentials: 'same-origin', cache: 'no-store' })
    .then(function (response) {
      if (!response.ok) throw new Error(LIST_TEXT.reloadFailed);
      return response.text();
    })
    .then(function (html) {
      const fresh = index === -1 ? null : new DOMParser().parseFromString(html, 'text/html').querySelectorAll(selector)[index];
      if (!fresh) {
        notify(place.single ? LIST_TEXT.singleGone : LIST_TEXT.reloadFailed);
        return;
      }
      const node = document.importNode(fresh, true);
      place.container.replaceWith(node);
      measureListSpace();
      mountListBars();
      showHover(null, []);
      const shown = id === null || node.matches(attrSelector(attrs.item, String(id))) || node.querySelector(attrSelector(attrs.item, String(id))) !== null;
      if (message) notify(shown ? message : LIST_TEXT.hidden);
    })
    .catch(function () { notify(LIST_TEXT.reloadFailed); });
}

// Formular im Seitenpanel (panel.js); Speichern schließt es und lädt die Liste neu.
function openForm(place, schema, row) {
  let dirty = false;
  const body = openPanel({
    key: FORM_KEY,
    eyebrow: listLabels.get(place.key) || LIST_TEXT.entryEyebrow,
    title: row ? entryTitle(schema, row) : LIST_TEXT.add,
    dim: true,
    isDirty: function () { return dirty; }
  });
  let saving = false;
  let saveButton = null;
  const submit = function () {
    if (saving || !entry.check()) return;
    saving = true;
    saveButton.disabled = true;
    const payload = { type: place.type, data: entry.values() };
    if (row) payload.id = row.id;
    editorPost(place.urls.save, payload)
      .then(function (data) {
        if (body.isConnected) closePanel();
        return reload(place, Number(data.id), LIST_TEXT.saved);
      }, function (error) {
        saving = false;
        saveButton.disabled = false;
        notifyError(error);
      });
  };
  const entry = buildEntryForm(schema, row, { look: PAGE_LOOK, notify: notify, onSubmit: submit });
  // Bild-Upload und Texteditor melden Änderungen ebenfalls über input.
  entry.form.addEventListener('input', function () { dirty = true; });
  entry.form.addEventListener('change', function () { dirty = true; });
  saveButton = editorButton(ENTRY_TEXT.save, 'le-btn le-panel__primary', submit);
  panelFooter().append(saveButton, editorButton(ENTRY_TEXT.cancel, 'le-btn le-btn--secondary', closePanel));
  body.append(entry.form);
  entry.focus();
}

function add(place) {
  run(function () {
    return editorApi(withQuery(place.urls.list, { type: place.type })).then(function (data) {
      openForm(place, data.schema, null);
    });
  });
}

function loadEntry(place, id) {
  return editorApi(withQuery(place.urls.get, { type: place.type, id: id }));
}

function edit(place, id) {
  run(function () {
    return loadEntry(place, id).then(function (data) {
      openForm(place, data.schema, data.row);
    });
  });
}

// Fragt einmal nach („‚Max Muster‘ löschen?“), der Server entfernt auch ungenutzte Bilder.
function remove(place, id) {
  run(function () {
    return loadEntry(place, id).then(function (data) {
      return askConfirm({ title: deleteQuestion(data.schema, data.row), text: LIST_TEXT.removeNote, confirm: LIST_TEXT.remove, danger: true });
    }).then(function (yes) {
      if (!yes) return null;
      return editorPost(place.urls.delete, { type: place.type, id: id }).then(function () {
        return reload(place, null, LIST_TEXT.deleted);
      });
    });
  });
}

function move(place, id, direction) {
  run(function () {
    return editorPost(place.urls.sort, { type: place.type, id: id, direction: direction }).then(function () {
      return reload(place, null, null);
    });
  });
}

// Knopf-Quelle für interact.js: Eintrag (bzw. Einzelansicht) oder Liste eines mitmachenden Plugins.
const entrySource = {
  anchorFor: function (el) {
    const item = el.closest(attrSelector(attrs.item));
    const container = item ? containerOf(item) : el.closest(attrSelector(attrs.list));
    return container && placeOf(container) ? item || container : null;
  },
  chips: function (anchor) {
    if (!anchor.hasAttribute(attrs.item)) return [];
    const place = placeOf(containerOf(anchor));
    const id = idOf(anchor);
    if (place.single) {
      return [{ anchor: anchor, place: CHIP_PLACE.corner, label: LIST_TEXT.editSingle, icon: 'pencil', tone: 'primary', onClick: function () { edit(place, id); } }];
    }
    return itemChips(place, anchor);
  },
  // Klick auf einen Eintrag (nicht auf die Liste daneben) öffnet sein Formular.
  activate: function (anchor) {
    if (!anchor.hasAttribute(attrs.item)) return null;
    const place = placeOf(containerOf(anchor));
    const id = idOf(anchor);
    return function () { edit(place, id); };
  }
};

function itemChips(place, item) {
  const id = idOf(item);
  const chip = function (label, name, onClick, extra) {
    return Object.assign({ anchor: item, place: CHIP_PLACE.corner, label: label, icon: name, iconOnly: true, onClick: onClick }, extra);
  };
  const chips = [chip(LIST_TEXT.edit, 'pencil', function () { edit(place, id); }, { iconOnly: false, tone: 'primary' })];
  if (place.urls.sort) {
    const items = itemsOf(place);
    const index = items.indexOf(item);
    if (index > 0) chips.push(chip(LIST_TEXT.up, 'moveUp', function () { move(place, id, lists.directions.up); }));
    if (index < items.length - 1) chips.push(chip(LIST_TEXT.down, 'moveDown', function () { move(place, id, lists.directions.down); }));
  }
  chips.push(chip(LIST_TEXT.remove, 'trash', function () { remove(place, id); }, { tone: 'danger' }));
  return chips;
}

function countText(n) {
  return n + ' ' + (n === 1 ? LIST_TEXT.entry : LIST_TEXT.entries);
}

// Leiste unter einer Liste: Name (sobald bekannt), Zahl der Einträge, „+ Neuer Eintrag“.
function listBar(place) {
  const bar = document.createElement('div');
  bar.className = 'le-listbar';
  const label = document.createElement('span');
  label.className = 'le-listbar__label';
  const name = document.createElement('strong');
  const count = document.createElement('span');
  const fill = function () {
    const known = listLabels.get(place.key);
    name.textContent = known ? known + ' · ' : '';
    count.textContent = countText(itemsOf(place).length);
  };
  fill();
  label.append(name, count);
  bar.append(icon('items'), label, labeledButton('plus', LIST_TEXT.add, 'le-btn le-btn--small', function () { add(place); }));
  if (!listLabels.has(place.key)) {
    listLabels.set(place.key, null);
    editorApi(withQuery(place.urls.list, { type: place.type })).then(function (data) {
      listLabels.set(place.key, typeof data.label === 'string' ? data.label : null);
      mountListBars();
    }, function () { /* ohne Namen bleibt die Zahl */ });
  }
  return bar;
}

// Leisten unter allen Listen neu anheften (beim Start und nachdem eine Liste neu geladen wurde).
function mountListBars() {
  unpinBars.forEach(function (unpin) { unpin(); });
  unpinBars = listsOnPage().map(function (list) {
    return pin(list, listBar(placeOf(list)));
  });
}

export function mountPluginLists(config) {
  lists = config.pluginLists;
  attrs = lists.attrs;
  addChipSource(entrySource);
  measureListSpace();
  mountListBars();
  let scheduled = false;
  window.addEventListener('resize', function () {
    if (scheduled) return;
    scheduled = true;
    window.requestAnimationFrame(function () {
      scheduled = false;
      measureListSpace();
    });
  });
}
