<?php
$page = [
    'title'       => 'Mitarbeiter',
    'description' => 'Unsere Mitarbeiter.',
    'slug'        => 'data.php',
];
require __DIR__ . '/includes/header.php';

$mitarbeiter = content_types_public_list('mitarbeiter');
?>

<section class="section">
    <div class="container">
        <header class="section__header">
            <h1 data-edit-id="section_header.title" data-edit-label="Mitarbeiter – Überschrift">Mitarbeiter</h1>
            <p class="section__lead"><?= count($mitarbeiter) ?> Einträge direkt aus der Datenbank – kein JS, kein HTTP-Request.</p>
        </header>

        <div <?= le_list_attrs('content-types', 'mitarbeiter') ?>>
        <?php if (empty($mitarbeiter)): ?>
            <p data-edit-id="container.text" data-edit-label="Mitarbeiter – Absatz">Keine Mitarbeiter gefunden.</p>
        <?php else: ?>
            <div class="card-grid card-grid--3">
                <?php foreach ($mitarbeiter as $person): ?>
                    <article class="feature-card" <?= le_item_attrs((int) $person['id']) ?>>
                        <h3><?= e((string) ($person['name'] ?? '–')) ?></h3>
                        <?php if (!empty($person['position'])): ?>
                            <p><?= e((string) $person['position']) ?></p>
                        <?php endif; ?>
                        <?php if (!empty($person['email'])): ?>
                            <p><a href="mailto:<?= e((string) $person['email']) ?>"><?= e((string) $person['email']) ?></a></p>
                        <?php endif; ?>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        </div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
