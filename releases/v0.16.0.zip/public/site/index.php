<?php
$page = [
    'title'       => 'Live Editor – Statische Websites bearbeiten ohne Datenbank',
    'description' => 'Der Live Editor verwandelt jede statische HTML- oder PHP-Website in eine Seite, die du direkt im Browser pflegst – ohne Datenbank, ohne CMS, auf jedem PHP-Hoster.',
    'slug'        => '',
];
require __DIR__ . '/includes/header.php';
?>

<section id="hero" class="hero">
    <div class="container">
        <div class="hero__grid">
            <div class="hero__content">
                <span class="hero__eyebrow" data-edit-id="hero_grid.text">Ohne Vorkenntnisse</span>
                <h1 data-edit-id="hero_grid.title" data-edit-label="Deine Website. Einfach selbst ändern. – Überschrift">Deine Website. Einfach selbst ändern.</h1>
                <p class="hero__lead" data-edit-id="hero_grid.text_2" data-edit-label="Deine Website. Einfach selbst ändern. – Absatz">Text anklicken, ändern, speichern – fertig. Ohne Programmierkenntnisse
                    und ohne kompliziertes CMS: Deine Website bleibt, wie sie ist, und du pflegst sie
                    direkt im Browser.</p>
                <div class="hero__actions">
                    <a class="button button--accent button--arrow" href="../admin/" data-edit-id="link_1.url" data-edit-text-id="link_1.text">Jetzt loslegen</a>
                    <a class="button button--ghost" href="#how" data-edit-id="link_2.url" data-edit-text-id="link_2.text">So funktioniert&apos;s</a>
                </div>
                <ul class="hero__trust">
                    <li><span class="hero__trust-icon"><?= icon('shield-check', 20) ?></span><span data-edit-id="hero_trust.text">Automatische Backups</span></li>
                    <li><span class="hero__trust-icon"><?= icon('server', 20) ?></span><span data-edit-id="hero_trust.text_2">Läuft auf jedem Webspace</span></li>
                    <li><span class="hero__trust-icon"><?= icon('database', 20) ?></span><span data-edit-id="hero_trust.text_3">Keine Datenbank nötig</span></li>
                </ul>
            </div>

            <div class="hero__visual">
                <div class="demo" data-demo>
                    <template data-demo-template>
                        <div class="demo__window">
                            <div class="demo__chrome">
                                <span class="demo__dots"><i></i><i></i><i></i></span>
                                <span class="demo__url">www.baeckerei-huber.at</span>
                            </div>
                            <div class="demo__page">
                                <div class="demo__nav">
                                    <span class="demo__logo">huber<b>.</b></span>
                                    <span class="demo__links"><i>Sortiment</i><i>Café</i><i>Über uns</i></span>
                                    <span class="demo__order">Bestellen</span>
                                </div>
                                <div class="demo__hero">
                                    <div class="demo__text">
                                        <h3 class="demo__title" data-demo-target="title" data-demo-new="Jetzt auch sonntags offen!">Frisches Brot jeden Morgen</h3>
                                        <p class="demo__lead" data-demo-target="lead">Mit Liebe gebacken, aus regionalem Mehl – täglich ab 6 Uhr.</p>
                                        <span class="demo__actions"><span class="demo__button">Vorbestellen</span><span class="demo__button demo__button--light">Sortiment</span></span>
                                        <span class="demo__proof">
                                            <span class="demo__avatars"><i></i><i></i><i></i></span>
                                            <span><b>4,9 ★</b> 320 Bewertungen</span>
                                        </span>
                                    </div>
                                    <div class="demo__media">
                                        <div class="demo__image" data-demo-target="image">
                                            <img class="demo__img demo__img--a" src="assets/img/demo/brot.jpg" alt="" width="800" height="640">
                                            <img class="demo__img demo__img--b" src="assets/img/demo/torte.jpg" alt="" width="800" height="640">
                                        </div>
                                        <span class="demo__float demo__float--open"><i></i>Heute offen · 6–18 Uhr</span>
                                        <span class="demo__float demo__float--new"><img src="assets/img/demo/croissants.jpg" alt="" width="480" height="320"><span><small>Neu im Sortiment</small>Butter-Croissant</span></span>
                                    </div>
                                </div>
                                <div class="demo__cards">
                                    <span><i class="demo__icon">✦</i><b>Frisch gebacken</b>Jeden Morgen aus dem Ofen</span>
                                    <span><i class="demo__icon">◎</i><b>Regionales Mehl</b>Aus dem Weinviertel</span>
                                    <span><i class="demo__icon">➜</i><b>Abholen</b>Online vorbestellen</span>
                                </div>
                            </div>
                            <div class="demo__bar">
                                <span class="demo__mode">Bearbeiten</span>
                                <span class="demo__status" data-demo-status>Alles gespeichert</span>
                                <span class="demo__save" data-demo-target="save">Speichern</span>
                            </div>
                            <div class="demo__glow" data-demo-glow><span class="demo__tag" data-demo-tag></span></div>
                            <div class="demo__toast" data-demo-toast>Gespeichert – die Seite ist online.</div>
                            <div class="demo__pointer" data-demo-cursor>
                                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 2l16 11-7 1.5L9.5 21z" fill="#0c1b4d" stroke="#fff" stroke-width="1.6" stroke-linejoin="round"/></svg>
                                <span class="demo__file" data-demo-file>torte.jpg</span>
                            </div>
                        </div>
                    </template>
                </div>
                <ol class="demo-steps" data-demo-steps>
                    <li data-edit-id="demo_steps.text">Anklicken</li>
                    <li data-edit-id="demo_steps.text_2">Ändern</li>
                    <li data-edit-id="demo_steps.text_3">Speichern – fertig</li>
                </ol>
                <p class="demo-hint"><span data-edit-id="demo_hint.text">Probier es selbst: Klick in die Vorschau.</span> <button class="demo-hint__replay" type="button" data-demo-replay hidden>Nochmal ansehen</button></p>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container about">
        <div class="prose">
        <h2 data-edit-id="container.title" data-edit-label="Was ist der Live Editor? – Überschrift">Was ist der Live Editor?</h2>
        <p data-edit-id="container.text" data-edit-label="Was ist der Live Editor? – Absatz 1">Ein schlankes PHP-Tool, das bestehende statische Websites in editierbare Websites
            verwandelt – ohne sie zu zerstören. Ein einmaliger Import ergänzt die HTML-Elemente
            um data-edit-id-Marker und lagert die Inhalte in JSON aus.</p>
        <p data-edit-id="container.text_2" data-edit-label="Was ist der Live Editor? – Absatz 2">Ab da pflegst du Inhalte über einen passwortgeschützten Editor: Texte, Links, Bilder
            ändern sich live, Backups werden automatisch angelegt, das Original bleibt vorhanden.</p>
        <blockquote data-edit-id="container.text_3" data-edit-label="Was ist der Live Editor? – Text">
            Gedacht für Agenturen, Freelancer und Hobbyisten, die schnelle, individuelle Websites
            für Kunden bauen und dann eine einfache Pflegelösung übergeben möchten.
        </blockquote>
        </div>
        <figure class="about__media">
            <img src="assets/img/editor.svg" alt="Website im Browser, deren Überschrift gerade bearbeitet wird" width="640" height="520" loading="lazy" data-edit-id="about_media.image" data-edit-alt-id="about_media.image_alt">
        </figure>
    </div>
</section>

<section id="team" class="section section--soft">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text_4">Beispiel-Plugin</span>
            <h2 data-edit-id="section_header.title_3" data-edit-label="Unser Team – Überschrift">Unser Team</h2>
            <p class="section__lead" data-edit-id="section_header.text_5" data-edit-label="Unser Team – Absatz">Diese Liste kommt aus dem Plugin Inhaltstypen. Einträge lassen sich direkt auf der Seite hinzufügen, bearbeiten und sortieren.</p>
        </header>
        <div data-plugin="content-types" data-view="list" data-type="mitarbeiter" data-limit="20"></div>
    </div>
</section>

 <div data-plugin="team" data-view="list"></div>

 <div data-plugin="contact-form" data-view="form"></div>

<section id="how" class="section">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text">In drei Schritten</span>
            <h2 data-edit-id="section_header.title" data-edit-label="So funktioniert&apos;s – Überschrift">So funktioniert&apos;s</h2>
            <p class="section__lead" data-edit-id="section_header.text_2" data-edit-label="So funktioniert&apos;s – Absatz">Von der statischen Datei zur pflegbaren Website – ohne deinen Code zu zerstören.</p>
        </header>

        <div class="card-grid card-grid--3">
            <article class="step">
                <span class="step__number" data-edit-id="step.text">1</span>
                <span class="step__icon"><?= icon('layers') ?></span>
                <h3 data-edit-id="step.title" data-edit-label="HTML oder PHP ablegen – Überschrift">HTML oder PHP ablegen</h3>
                <p data-edit-id="step.text_2" data-edit-label="HTML oder PHP ablegen – Absatz">Lege deine statischen Dateien in public/site/ ab – so wie sie sind, mit deinem CSS, JS und Assets.</p>
            </article>

            <article class="step">
                <span class="step__number" data-edit-id="step.text_3">2</span>
                <span class="step__icon"><?= icon('refresh-cw') ?></span>
                <h3 data-edit-id="step.title_2" data-edit-label="Einmaliger Import – Überschrift">Einmaliger Import</h3>
                <p data-edit-id="step.text_4" data-edit-label="Einmaliger Import – Absatz">Beim ersten Login erkennt das System die Seiten, ergänzt data-edit-id-Marker und legt Inhalte in JSON ab.</p>
            </article>

            <article class="step">
                <span class="step__number" data-edit-id="step.text_5">3</span>
                <span class="step__icon"><?= icon('pencil') ?></span>
                <h3 data-edit-id="step.title_3" data-edit-label="Inhalte pflegen – Überschrift">Inhalte pflegen</h3>
                <p data-edit-id="step.text_6" data-edit-label="Inhalte pflegen – Absatz">Im Admin Texte, Links und Bilder ändern. Save schreibt JSON, erstellt ein Backup und ist sofort live.</p>
            </article>
        </div>
    </div>
</section>

<section class="section section--soft">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text_3">Eigenschaften</span>
            <h2 data-edit-id="section_header.title_2" data-edit-label="Was den Live Editor besonders macht – Überschrift">Was den Live Editor besonders macht</h2>
        </header>

        <div class="card-grid card-grid--2">
            <article class="feature-card">
                <span class="feature-card__icon"><?= icon('database') ?></span>
                <h3 data-edit-id="feature_card.title" data-edit-label="Keine Datenbank – Überschrift">Keine Datenbank</h3>
                <p data-edit-id="feature_card.text" data-edit-label="Keine Datenbank – Absatz">Inhalte liegen als JSON-Dateien im Repository. Versionierbar mit Git, portabel zwischen Hostern, sicher gegen SQL-Probleme.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><?= icon('server') ?></span>
                <h3 data-edit-id="feature_card.title_2" data-edit-label="Läuft auf jedem PHP-Hoster – Überschrift">Läuft auf jedem PHP-Hoster</h3>
                <p data-edit-id="feature_card.text_2" data-edit-label="Läuft auf jedem PHP-Hoster – Absatz">PHP ≥ 8.0 genügt. Kein Composer-Zwang, kein Node, keine Build-Pipeline. Hochladen, Login, fertig.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><?= icon('shield-check') ?></span>
                <h3 data-edit-id="feature_card.title_3" data-edit-label="Automatische Backups – Überschrift">Automatische Backups</h3>
                <p data-edit-id="feature_card.text_3" data-edit-label="Automatische Backups – Absatz">Vor jedem Speichern wird die alte JSON-Version weggesichert. Restore per Klick aus dem Admin.</p>
            </article>

            <article class="feature-card">
                <span class="feature-card__icon"><?= icon('layout-template') ?></span>
                <h3 data-edit-id="feature_card.title_4" data-edit-label="HTML bleibt HTML – Überschrift">HTML bleibt HTML</h3>
                <p data-edit-id="feature_card.text_4" data-edit-label="HTML bleibt HTML – Absatz">Dein Code wird einmalig um data-edit-id ergänzt – keine Templates, keine Shortcodes, kein Lock-in.</p>
            </article>
        </div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
