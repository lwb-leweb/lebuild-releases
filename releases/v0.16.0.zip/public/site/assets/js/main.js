// LEWEB · main.js
// Schlanke Interaktionen: Mobile-Navigation, Scroll-Header, sanftes Aufdecken, Editor-Vorführung.

(function () {
    'use strict';

    const onReady = (fn) => {
        if (document.readyState !== 'loading') fn();
        else document.addEventListener('DOMContentLoaded', fn);
    };

    onReady(() => {
        initNavToggle();
        initHeaderShadow();
        initRevealOnScroll();
        initDemo();
    });

    function initNavToggle() {
        const toggle = document.querySelector('[data-nav-toggle]');
        const nav = document.querySelector('[data-nav]');
        if (!toggle || !nav) return;

        const close = () => {
            nav.classList.remove('is-open');
            toggle.setAttribute('aria-expanded', 'false');
        };

        toggle.addEventListener('click', () => {
            const isOpen = nav.classList.toggle('is-open');
            toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        // Beim Wechsel auf Desktop-Breite Menü zurücksetzen
        const mq = window.matchMedia('(min-width: 960px)');
        mq.addEventListener('change', (e) => { if (e.matches) close(); });

        // ESC schließt das Menü
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') close();
        });

        // Klick außerhalb schließt das Menü (nur mobile)
        document.addEventListener('click', (e) => {
            if (!nav.classList.contains('is-open')) return;
            if (e.target.closest('[data-nav]') || e.target.closest('[data-nav-toggle]')) return;
            close();
        });
    }

    function initHeaderShadow() {
        const header = document.querySelector('[data-header]');
        if (!header) return;
        const update = () => {
            header.classList.toggle('is-scrolled', window.scrollY > 4);
        };
        update();
        window.addEventListener('scroll', update, { passive: true });
    }

    function initRevealOnScroll() {
        const els = document.querySelectorAll('[data-reveal]');
        if (!els.length || !('IntersectionObserver' in window)) {
            els.forEach((el) => el.classList.add('is-revealed'));
            return;
        }
        const io = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-revealed');
                    io.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12 });
        els.forEach((el) => io.observe(el));
    }
    // Vorführung im Hero: Ein Zeiger klickt die Überschrift an, tippt einen neuen Text, zieht ein
    // Bild hinein und speichert, in Schleife. Ein Klick in die Vorschau beendet das Abspielen;
    // dann lässt sich dort selbst tippen, das Bild tauschen und speichern.
    function initDemo() {
        const root = document.querySelector('[data-demo]');
        const template = root && root.querySelector('[data-demo-template]');
        if (!template) return;
        root.appendChild(template.content.cloneNode(true));

        const pick = (selector) => root.querySelector(selector);
        const win = pick('.demo__window');
        const title = pick('[data-demo-target="title"]');
        const lead = pick('[data-demo-target="lead"]');
        const image = pick('[data-demo-target="image"]');
        const save = pick('[data-demo-target="save"]');
        const glow = pick('[data-demo-glow]');
        const tag = pick('[data-demo-tag]');
        const cursor = pick('[data-demo-cursor]');
        const file = pick('[data-demo-file]');
        const toast = pick('[data-demo-toast]');
        const status = pick('[data-demo-status]');
        const steps = Array.from(document.querySelectorAll('[data-demo-steps] li'));
        const replay = document.querySelector('[data-demo-replay]');

        const TEXT = {
            saved: status.textContent,
            unsaved: (n) => n === 1 ? '1 Änderung nicht gespeichert' : n + ' Änderungen nicht gespeichert',
            editText: 'Text ändern',
            dropImage: 'Bild hier ablegen'
        };
        const original = { title: title.textContent, lead: lead.textContent };
        const nextTitle = title.dataset.demoNew;

        // Jeder Lauf hat eine Nummer; wartet ein älterer Lauf noch, bricht er ab.
        let run = 0;
        let changes = 0;
        const STOP = {};
        const wait = (ms, id) => new Promise((resolve, reject) => {
            setTimeout(() => (id === run ? resolve() : reject(STOP)), ms);
        });

        const box = (el) => {
            const outer = win.getBoundingClientRect();
            const rect = el.getBoundingClientRect();
            return { x: rect.left - outer.left, y: rect.top - outer.top, w: rect.width, h: rect.height };
        };
        const moveTo = (el, fx, fy) => {
            const b = box(el);
            cursor.style.transform = 'translate(' + (b.x + b.w * fx) + 'px,' + (b.y + b.h * fy) + 'px)';
        };
        const showGlow = (el, text) => {
            const b = box(el);
            glow.style.cssText = 'left:' + (b.x - 6) + 'px;top:' + (b.y - 6) + 'px;width:' + (b.w + 12) + 'px;height:' + (b.h + 12) + 'px';
            tag.textContent = text;
            glow.classList.add('is-on');
        };
        const hideGlow = () => glow.classList.remove('is-on');
        const click = () => {
            cursor.classList.add('is-click');
            setTimeout(() => cursor.classList.remove('is-click'), 220);
        };
        const setStep = (n) => steps.forEach((li, i) => {
            li.classList.toggle('is-active', i + 1 === n);
            li.classList.toggle('is-done', i + 1 < n);
        });
        const setChanges = (n) => {
            changes = n;
            status.textContent = n ? TEXT.unsaved(n) : TEXT.saved;
            status.classList.toggle('is-dirty', n > 0);
            save.classList.toggle('is-ready', n > 0);
        };
        const popToast = () => {
            toast.classList.add('is-on');
            setTimeout(() => toast.classList.remove('is-on'), 2600);
        };

        function reset() {
            title.textContent = original.title;
            lead.textContent = original.lead;
            title.classList.remove('is-editing');
            image.classList.remove('is-swapped');
            file.classList.remove('is-on');
            toast.classList.remove('is-on');
            hideGlow();
            setChanges(0);
            setStep(0);
            const b = box(win);
            cursor.style.transition = 'none';
            cursor.style.transform = 'translate(' + (b.w * 0.85) + 'px,' + (b.h * 0.95) + 'px)';
            cursor.getBoundingClientRect();
            cursor.style.transition = '';
        }

        async function play(id) {
            reset();
            await wait(700, id);
            // 1. Anklicken
            setStep(1);
            moveTo(title, 0.35, 0.6);
            await wait(900, id);
            showGlow(title, TEXT.editText);
            await wait(800, id);
            click();
            title.classList.add('is-editing');
            await wait(400, id);
            // 2. Ändern: Text löschen und neu tippen, dann Bild hineinziehen
            setStep(2);
            while (title.textContent.length) {
                title.textContent = title.textContent.slice(0, -1);
                await wait(22, id);
            }
            for (const ch of nextTitle) {
                title.textContent += ch;
                await wait(60, id);
            }
            setChanges(1);
            await wait(600, id);
            title.classList.remove('is-editing');
            hideGlow();
            const b = box(win);
            cursor.style.transition = 'none';
            cursor.style.transform = 'translate(' + (b.w + 10) + 'px,' + (b.h * 0.55) + 'px)';
            cursor.getBoundingClientRect();
            cursor.style.transition = '';
            file.classList.add('is-on');
            await wait(150, id);
            moveTo(image, 0.5, 0.5);
            await wait(500, id);
            showGlow(image, TEXT.dropImage);
            await wait(800, id);
            file.classList.remove('is-on');
            image.classList.add('is-swapped');
            setChanges(2);
            await wait(900, id);
            hideGlow();
            // 3. Speichern
            setStep(3);
            moveTo(save, 0.5, 0.55);
            await wait(1000, id);
            click();
            setChanges(0);
            popToast();
            await wait(3600, id);
            play(id).catch(() => {});
        }

        function start() {
            root.classList.remove('is-live');
            if (replay) replay.hidden = true;
            title.removeAttribute('contenteditable');
            lead.removeAttribute('contenteditable');
            run++;
            play(run).catch(() => {});
        }

        // Selbst ausprobieren: Abspielen stoppen, Texte bearbeitbar, Bild tauschen, Speichern.
        function goLive() {
            if (root.classList.contains('is-live')) return;
            run++;
            hideGlow();
            file.classList.remove('is-on');
            title.classList.remove('is-editing');
            root.classList.add('is-live');
            title.setAttribute('contenteditable', 'true');
            lead.setAttribute('contenteditable', 'true');
            setStep(0);
            if (replay) replay.hidden = false;
        }

        root.addEventListener('pointerdown', goLive);
        root.addEventListener('input', () => {
            setChanges(Math.max(changes, 1));
            setStep(2);
        });
        root.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') { e.preventDefault(); e.target.blur(); }
        });
        image.addEventListener('click', () => {
            if (!root.classList.contains('is-live')) return;
            image.classList.toggle('is-swapped');
            setChanges(changes + 1);
            setStep(2);
        });
        save.addEventListener('click', () => {
            if (!root.classList.contains('is-live') || !changes) return;
            setChanges(0);
            setStep(3);
            popToast();
        });
        if (replay) replay.addEventListener('click', start);

        const still = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        if (still) goLive();
        else start();
    }
})();
