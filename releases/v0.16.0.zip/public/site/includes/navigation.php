<?php
require_once __DIR__ . '/config.php';
$current = current_page();
?>
<header class="site-header" data-header>
    <div class="container site-header__inner">
        <a class="brand" href="index.php" aria-label="<?= e(SITE_NAME) ?> Startseite" data-edit-id="header.link_1.url">
            <span class="brand__mark" aria-hidden="true" data-edit-id="header.container.text">LE</span>
            <span class="brand__name"><?= e(SITE_NAME) ?></span>
        </a>

        <button
            class="nav-toggle"
            type="button"
            aria-controls="primary-nav"
            aria-expanded="false"
            data-nav-toggle>
            <span class="nav-toggle__bars" aria-hidden="true"></span>
            <span class="visually-hidden" data-edit-id="header.container.text_2">Menü öffnen</span>
        </button>

        <nav id="primary-nav" class="primary-nav" aria-label="Hauptnavigation" data-nav>
            <ul class="primary-nav__list">
                <?php foreach ($NAV_ITEMS as $item): ?>
                    <?php $isActive = $current === $item['href']; ?>
                    <li class="primary-nav__item">
                        <a
                            href="<?= e($item['href']) ?>"
                            class="primary-nav__link<?= $isActive ? ' is-active' : '' ?>"
                            <?= $isActive ? 'aria-current="page"' : '' ?>>
                            <?= e($item['label']) ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>

        <div class="site-header__actions">
            <a class="site-header__login" href="../admin/" data-edit-id="header.link_3.url" data-edit-text-id="header.link_3.text">Anmelden</a>
            <a class="button button--accent button--small" href="#how" data-edit-id="header.link_4.url" data-edit-text-id="header.link_4.text">Loslegen</a>
        </div>
    </div>
</header>
