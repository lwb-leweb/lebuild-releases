<?php
require_once __DIR__ . '/config.php';

foreach (load_plugins_state()['active'] ?? [] as $_plugin_name) {
    $_pub = PROJECT_ROOT . '/plugins/' . $_plugin_name . '/public.php';
    if (is_file($_pub)) {
        require_once $_pub;
    }
}
unset($_plugin_name, $_pub);

// Erwartete Variablen: $page = ['title' => ..., 'description' => ..., 'slug' => ...]
$pageTitle       = $page['title']       ?? SITE_NAME;
$pageDescription = $page['description'] ?? SITE_TAGLINE;
$pageSlug        = $page['slug']        ?? '';

$fullTitle = $pageTitle === SITE_NAME
    ? SITE_NAME . ' – ' . SITE_TAGLINE
    : $pageTitle . ' | ' . SITE_NAME;
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($fullTitle) ?></title>
    <meta name="description" content="<?= e($pageDescription) ?>">
    <meta name="author" content="<?= e(SITE_OWNER) ?>">
    <meta name="theme-color" content="#0b6bff">

    <meta property="og:type" content="website">
    <meta property="og:locale" content="<?= e(SITE_LOCALE) ?>">
    <meta property="og:site_name" content="<?= e(SITE_NAME) ?>">
    <meta property="og:title" content="<?= e($fullTitle) ?>">
    <meta property="og:description" content="<?= e($pageDescription) ?>">
    <meta property="og:url" content="<?= e(SITE_URL . '/' . $pageSlug) ?>">

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= e($fullTitle) ?>">
    <meta name="twitter:description" content="<?= e($pageDescription) ?>">

    <link rel="canonical" href="<?= e(SITE_URL . '/' . $pageSlug) ?>">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='12' fill='%230b1f3a'/%3E%3Ctext x='32' y='42' font-family='Inter,Arial,sans-serif' font-size='28' font-weight='800' fill='%23ff5b2e' text-anchor='middle'%3EL%3C/text%3E%3C/svg%3E">
</head>
<body>
    <a class="skip-link" href="#main">Zum Inhalt springen</a>

    <?php require __DIR__ . '/navigation.php'; ?>

    <main id="main">
