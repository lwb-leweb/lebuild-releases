<?php
// Zentrale Konfiguration für Seiten-Metadaten und Navigation.
// Jede Seite definiert vor dem Einbinden des Headers ihre eigene $page-Variable.

declare(strict_types=1);

require_once __DIR__ . '/icons.php';

$_cfg_path = dirname(__DIR__, 3) . '/content/config.json';
$_cfg = is_file($_cfg_path) ? (json_decode((string) file_get_contents($_cfg_path), true) ?: []) : [];

define('SITE_NAME',    $_cfg['name']    ?? 'Live Editor');
define('SITE_TAGLINE', $_cfg['tagline'] ?? 'Statische Websites bearbeiten ohne Datenbank');
define('SITE_URL',     $_cfg['url']     ?? 'https://example.com');
define('SITE_EMAIL',   $_cfg['email']   ?? 'office@example.com');
define('SITE_OWNER',   $_cfg['owner']   ?? 'Dein Name');
define('SITE_LOCALE',  $_cfg['locale']  ?? 'de_AT');

unset($_cfg_path, $_cfg);

// Hauptnavigation – Reihenfolge bestimmt Anzeige.
$NAV_ITEMS = [
    ['href' => 'index.php',     'label' => 'Start'],
    ['href' => 'impressum.php', 'label' => 'Impressum'],
    ['href' => 'data.php',      'label' => 'Daten'],
];

function current_page(): string {
    return basename($_SERVER['PHP_SELF'] ?? 'index.php');
}

function e(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
