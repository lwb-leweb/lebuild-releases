<?php
declare(strict_types=1);

require_once __DIR__ . '/fileStore.php';
require_once __DIR__ . '/phpRewriter.php';
require_once __DIR__ . '/labels.php';

function run_import(bool $force = false): array
{
    prepare_storage();

    if (!$force && import_status() !== null) {
        return ['imported' => false, 'skipped' => true, 'pages' => list_pages()];
    }

    $files = array_merge(
        glob(SITE_ROOT . '/*.html') ?: [],
        glob(SITE_ROOT . '/*.php') ?: []
    );
    // Files starting with "_" are runtime/utility endpoints, not editable pages.
    $files = array_values(array_filter(
        $files,
        static fn (string $f): bool => !str_starts_with(basename($f), '_')
    ));
    sort($files);
    $pages = [];

    foreach ($files as $file) {
        $page = pathinfo($file, PATHINFO_FILENAME);
        if (str_ends_with($file, '.php')) {
            import_php_page($file, $page);
        } else {
            import_html_page($file, $page);
        }
        $pages[] = $page;
    }

    foreach (shared_components() as $name => $file) {
        import_shared_component($file, $name);
    }

    $status = [
        'imported' => true,
        'importedAt' => current_iso_time(),
        'pages' => $pages,
    ];
    save_import_status($status);

    return $status;
}

function import_html_page(string $file, string $page): void
{
    $originalPath = ORIGINALS_ROOT . '/' . basename($file);
    if (!is_file($originalPath)) {
        copy($file, $originalPath);
    }
    snapshot_original_file($file);

    $html = (string) file_get_contents($file);

    // PHP blocks before the first HTML element are extracted as preamble so
    // DOMDocument never sees them as text nodes (which it would wrap in <p>).
    $preamble = '';
    if (preg_match('/^((?:\s*<\?.*?\?>[\r\n]*)+)/s', $html, $pm)) {
        $preamble = $pm[1];
        $html     = substr($html, strlen($preamble));
    }

    // PHP blocks after the last HTML element (e.g. footer require) are extracted
    // as postamble for the same reason.
    $postamble = '';
    if (preg_match('/((?:[\r\n\s]*<\?.*?\?>)+\s*)$/s', $html, $pm)) {
        $postamble = $pm[1];
        $html      = substr($html, 0, -strlen($postamble));
    }

    // Inline PHP blocks inside the HTML content are replaced with safe
    // text placeholders so DOMDocument does not corrupt them.
    $phpBlocks = [];
    $html = preg_replace_callback(
        '/<\?(?:php|=|).*?\?>/s',
        static function (array $match) use (&$phpBlocks): string {
            $key = '__PHP_BLOCK_' . count($phpBlocks) . '__';
            $phpBlocks[$key] = $match[0];
            return $key;
        },
        $html
    ) ?? $html;

    libxml_use_internal_errors(true);
    $dom = new DOMDocument('1.0', 'UTF-8');
    $dom->preserveWhiteSpace = true;
    $dom->formatOutput = false;
    $dom->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    libxml_clear_errors();

    $xpath = new DOMXPath($dom);
    $nodes = $xpath->query('//h1|//h2|//h3|//h4|//h5|//h6|//p|//span|//a|//img');
    $content = [];
    $counts = [];
    $assignedIds = [];

    if ($nodes !== false) {
        foreach ($nodes as $node) {
            if (!$node instanceof DOMElement || should_skip_node($node)) {
                continue;
            }

            $existingId = $node->getAttribute('data-edit-id');
            $id = resolve_edit_id($node, $existingId, $counts);
            $value = extract_node_value($node);
            if ($value === '' || str_contains($value, '__PHP_BLOCK_')) {
                continue;
            }

            $id = unique_edit_id($id, $assignedIds);
            $assignedIds[$id] = true;

            if ($existingId === '' || $existingId !== $id) {
                $node->setAttribute('data-edit-id', $id);
            }
            $node->setAttribute('data-edit-label', label_from_id($id));
            if (strtolower($node->tagName) === 'a' && anchor_text_editable($node)) {
                $base = edit_base_from_id($id);
                $textId = unique_edit_id($base . '.text', $assignedIds);
                $assignedIds[$textId] = true;
                $node->setAttribute('data-edit-text-id', $textId);
                set_nested_value($content, $textId, sanitize_text_value(extract_inner_html($node)));
            }
            set_nested_value($content, $id, $value);
        }
    }

    save_page_content($page, $content);

    $output = $dom->saveHTML();
    $output = preg_replace('/<\?xml encoding="UTF-8"\??>\n?/', '', (string) $output);
    if ($phpBlocks !== []) {
        $output = strtr((string) $output, $phpBlocks);
    }
    atomic_write($file, $preamble . $output . $postamble);
}

function inject_edit_ids_php(string $file, string $prefix = ''): bool
{
    $raw = (string) file_get_contents($file);

    $phpBlocks = [];
    $html = preg_replace_callback(
        '/<\?(?:php|=|).*?\?>/s',
        static function (array $m) use (&$phpBlocks): string {
            $key = '__PHPB' . str_pad((string) count($phpBlocks), 5, '0', STR_PAD_LEFT) . '__';
            $phpBlocks[$key] = $m[0];
            return $key;
        },
        $raw
    ) ?? $raw;

    $counts       = [];
    $idCounts     = []; // tracks per-id collisions to produce unique suffixes
    $contextStack = [];
    $changed      = false;
    $output       = '';
    $pos          = 0;
    $len          = strlen($html);

    $structural = ['section', 'div', 'article', 'header', 'main', 'aside', 'footer', 'nav', 'form', 'ul', 'ol', 'table', 'tr', 'thead', 'tbody'];
    $targets    = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'span', 'li', 'a', 'img'];

    while ($pos < $len) {
        $tagStart = strpos($html, '<', $pos);
        if ($tagStart === false) {
            $output .= substr($html, $pos);
            break;
        }
        $output .= substr($html, $pos, $tagStart - $pos);

        $tagEnd = strpos($html, '>', $tagStart);
        if ($tagEnd === false) {
            $output .= substr($html, $tagStart);
            $pos = $len;
            break;
        }

        $tag = substr($html, $tagStart, $tagEnd - $tagStart + 1);
        $pos = $tagEnd + 1;

        // Closing tag — pop matching entry from context stack
        if (preg_match('/^<\/(\w+)/i', $tag, $m)) {
            $closeName = strtolower($m[1]);
            for ($i = count($contextStack) - 1; $i >= 0; $i--) {
                if ($contextStack[$i]['tag'] === $closeName) {
                    array_splice($contextStack, $i, 1);
                    break;
                }
            }
            $output .= $tag;
            continue;
        }

        if (!preg_match('/^<(\w+)((?:\s[^>]*)?)(\/?)>$/s', $tag, $m)) {
            $output .= $tag;
            continue;
        }

        $tagName   = strtolower($m[1]);
        $attrStr   = $m[2];
        $selfClose = $m[3];

        // Track structural elements so target elements can inherit context
        if (in_array($tagName, $structural, true) && $selfClose === '') {
            $ctxName = '';
            if (preg_match('/\bid="([^"]+)"/i', $attrStr, $im)) {
                $ctxName = clean_name($im[1]);
            }
            if ($ctxName === '' && preg_match('/\bclass="([^"]+)"/i', $attrStr, $cm)) {
                foreach (preg_split('/\s+/', trim($cm[1])) ?: [] as $cls) {
                    $n = clean_name($cls);
                    if ($n !== '') { $ctxName = $n; break; }
                }
            }
            if ($ctxName === '' && in_array($tagName, ['header', 'main', 'section', 'article', 'aside', 'footer', 'nav'], true)) {
                $ctxName = $tagName;
            }
            $contextStack[] = ['tag' => $tagName, 'context' => $ctxName];
            $output .= $tag;
            continue;
        }

        if (!in_array($tagName, $targets, true)) {
            $output .= $tag;
            continue;
        }

        // Already annotated — leave as-is
        if (preg_match('/\bdata-edit-id=/i', $attrStr)) {
            $output .= $tag;
            continue;
        }

        // Look ahead at inner content to skip PHP-containing or empty elements
        if ($selfClose === '' && $tagName !== 'img') {
            $closePos = stripos($html, '</' . $tagName . '>', $pos);
            if ($closePos !== false) {
                $inner = substr($html, $pos, $closePos - $pos);
                if (str_contains($inner, '__PHPB') || trim(strip_tags($inner)) === '') {
                    $output .= $tag;
                    continue;
                }
            }
        }

        // Resolve closest ancestor context
        $context = '';
        for ($i = count($contextStack) - 1; $i >= 0; $i--) {
            if ($contextStack[$i]['context'] !== '') {
                $context = $contextStack[$i]['context'];
                break;
            }
        }

        // Build and inject attribute(s)
        $pre = $prefix !== '' ? $prefix . '.' : '';
        if ($tagName === 'a') {
            $aBase  = fallback_base('a', $counts);
            $id     = $pre . $aBase . '.url';
            $textId = $pre . $aBase . '.text';
            $label  = htmlspecialchars(label_from_id($id), ENT_QUOTES);
            $output .= '<' . $tagName . $attrStr . ' data-edit-id="' . $id . '" data-edit-text-id="' . $textId . '" data-edit-label="' . $label . '">';
        } else {
            $field    = semantic_field($tagName);
            $base     = $context !== '' ? $context : fallback_base($tagName, $counts);
            $rawBase  = $base . '.' . $field;
            $idCounts[$rawBase] = ($idCounts[$rawBase] ?? 0) + 1;
            $rawId    = $idCounts[$rawBase] === 1 ? $rawBase : $rawBase . '_' . $idCounts[$rawBase];
            $id       = $pre . $rawId;
            $label    = htmlspecialchars(label_from_id($id), ENT_QUOTES);
            $sc       = $selfClose !== '' ? ' /' : '';
            $output  .= '<' . $tagName . $attrStr . ' data-edit-id="' . $id . '" data-edit-label="' . $label . '"' . $sc . '>';
        }
        $changed = true;
    }

    if (!$changed) {
        return false;
    }

    atomic_write($file, strtr($output, $phpBlocks));
    return true;
}

function extract_php_content(string $file, string $stripPrefix = ''): array
{
    $raw  = (string) file_get_contents($file);
    $html = preg_replace('/<\?(?:php|=|).*?\?>/s', ' ', $raw) ?? $raw;
    $content = [];
    $pre = $stripPrefix !== '' ? $stripPrefix . '.' : '';
    $preLen = strlen($pre);

    $stripId = static function (string $id) use ($pre, $preLen): string {
        return ($pre !== '' && str_starts_with($id, $pre)) ? substr($id, $preLen) : $id;
    };

    if (preg_match_all(
        '/<(h[1-6]|p|span|div|li|td|th|label|button|strong|em)\b[^>]*\bdata-edit-id="([^"]+)"[^>]*>(.*?)<\/\1>/is',
        $html, $matches, PREG_SET_ORDER
    )) {
        foreach ($matches as $m) {
            $id    = $stripId($m[2]);
            $value = trim(html_entity_decode(strip_tags($m[3], '<br>'), ENT_HTML5 | ENT_QUOTES, 'UTF-8'));
            $value = preg_replace('/<br\b[^>]*>/i', '<br>', $value) ?? $value;
            if ($value !== '') {
                set_nested_value($content, $id, $value);
            }
        }
    }

    if (preg_match_all(
        '/<a\b([^>]*)\bdata-edit-id="([^"]+)"([^>]*)>(.*?)<\/a>/is',
        $html, $matches, PREG_SET_ORDER
    )) {
        foreach ($matches as $m) {
            $id       = $stripId($m[2]);
            $allAttrs = $m[1] . $m[3];
            $inner    = $m[4];

            if (preg_match('/\bhref="([^"]*)"/i', $allAttrs, $hm)) {
                $href = sanitize_text_value($hm[1]);
                if ($href !== '') {
                    set_nested_value($content, $id, $href);
                }
            }

            if (preg_match('/\bdata-edit-text-id="([^"]+)"/i', $allAttrs, $tm)) {
                $textId = $stripId($tm[1]);
                $text   = trim(html_entity_decode(strip_tags($inner, '<br>'), ENT_HTML5 | ENT_QUOTES, 'UTF-8'));
                $text   = preg_replace('/<br\b[^>]*>/i', '<br>', $text) ?? $text;
                if ($text !== '') {
                    set_nested_value($content, $textId, $text);
                }
            }
        }
    }

    if (preg_match_all(
        '/<img\b([^>]*)\bdata-edit-id="([^"]+)"([^>]*)\/?>/is',
        $html, $matches, PREG_SET_ORDER
    )) {
        foreach ($matches as $m) {
            $id      = $stripId($m[2]);
            $allAttr = $m[1] . $m[3];
            if (preg_match('/\bsrc="([^"]*)"/i', $allAttr, $sm)) {
                $src = sanitize_text_value($sm[1]);
                if ($src !== '') {
                    set_nested_value($content, $id, $src);
                }
            }
        }
    }

    return $content;
}

function import_php_page(string $file, string $page): void
{
    $originalPath = ORIGINALS_ROOT . '/' . basename($file);
    if (!is_file($originalPath)) {
        copy($file, $originalPath);
    }
    snapshot_original_file($file);

    inject_edit_ids_php($file);
    save_page_content($page, extract_php_content($file));
    // PHP file is left completely untouched
}

function import_shared_component(string $file, string $name): void
{
    if (!is_file($file)) {
        return;
    }
    snapshot_original_file($file);

    inject_edit_ids_php($file, $name);
    save_page_content($name, extract_php_content($file, $name));
}

/**
 * An anchor's text is only editable as a standalone field if its inner content
 * is just text (and optional <br> line breaks). Anchors that wrap real elements
 * like <img>, <svg>, <span class="icon"> ... must keep their children intact
 * on save — overwriting their inner with a text value would destroy them.
 */
function anchor_text_editable(DOMElement $node): bool
{
    foreach ($node->childNodes as $child) {
        if ($child instanceof DOMElement && strtolower($child->tagName) !== 'br') {
            return false;
        }
    }
    return true;
}

/**
 * Serializes the children of $node back to an HTML string, preserving inline
 * markup such as <br>. Used to extract editable text values without losing
 * line breaks (textContent would collapse them).
 */
function extract_inner_html(DOMElement $node): string
{
    $doc = $node->ownerDocument;
    if ($doc === null) {
        return $node->textContent;
    }
    $html = '';
    foreach ($node->childNodes as $child) {
        $html .= $doc->saveHTML($child);
    }
    return $html;
}

function should_skip_node(DOMElement $node): bool
{
    if (in_array(strtolower($node->tagName), ['script', 'style'], true)) {
        return true;
    }
    if ($node->hasAttribute('hidden')) {
        return true;
    }
    $style = strtolower($node->getAttribute('style'));
    return str_contains($style, 'display:none') || str_contains($style, 'display: none') || str_contains($style, 'visibility:hidden');
}

function resolve_edit_id(DOMElement $node, string $existingId, array &$counts): string
{
    $tag = strtolower($node->tagName);
    if ($tag === 'a') {
        if (preg_match('/^link_[a-z0-9_-]+\.url$/', $existingId)) {
            return $existingId;
        }
        return fallback_base('a', $counts) . '.url';
    }

    if ($existingId !== '') {
        return $existingId;
    }

    return generate_edit_id($node, $counts);
}

function generate_edit_id(DOMElement $node, array &$counts): string
{
    $tag = strtolower($node->tagName);
    $group = semantic_group($node);
    $field = semantic_field($tag);
    $base = $group !== '' ? $group : fallback_base($tag, $counts);
    if ($tag === 'a') {
        $base = fallback_base('a', $counts);
    }

    return $base . '.' . $field;
}

function extract_node_value(DOMElement $node): string
{
    $tag = strtolower($node->tagName);
    if ($tag === 'img') {
        return sanitize_text_value($node->getAttribute('src'));
    }
    if ($tag === 'a') {
        return sanitize_text_value($node->getAttribute('href') ?: $node->textContent);
    }

    // Preserve inline line breaks (<br>) inside text containers.
    return sanitize_text_value(extract_inner_html($node));
}

function unique_edit_id(string $id, array $assignedIds): string
{
    if (!isset($assignedIds[$id])) {
        return $id;
    }
    $suffix = 2;
    while (isset($assignedIds[$id . '_' . $suffix])) {
        $suffix++;
    }
    return $id . '_' . $suffix;
}

function edit_base_from_id(string $id): string
{
    $parts = explode('.', $id);
    array_pop($parts);
    return implode('.', $parts);
}

function semantic_field(string $tag): string
{
    return match ($tag) {
        'h1', 'h2', 'h3', 'h4', 'h5', 'h6' => 'title',
        'a' => 'url',
        'img' => 'image',
        default => 'text',
    };
}

function semantic_group(DOMElement $node): string
{
    $candidate = closest_context_name($node);
    if ($candidate !== '') {
        return $candidate;
    }

    $tag = strtolower($node->tagName);
    return match ($tag) {
        'h1', 'h2', 'h3', 'h4', 'h5', 'h6' => 'section',
        'img' => 'image',
        'a' => 'link',
        default => 'block',
    };
}

function closest_context_name(DOMElement $node): string
{
    $cursor = $node->parentNode;
    while ($cursor instanceof DOMElement) {
        $name = context_name_from_element($cursor);
        if ($name !== '') {
            return $name;
        }
        $cursor = $cursor->parentNode;
    }

    return '';
}

function context_name_from_element(DOMElement $node): string
{
    $id = clean_name($node->getAttribute('id'));
    if ($id !== '') {
        return $id;
    }

    $classAttr = trim($node->getAttribute('class'));
    if ($classAttr !== '') {
        $classes = preg_split('/\s+/', $classAttr) ?: [];
        foreach ($classes as $class) {
            $clean = clean_name($class);
            if ($clean !== '') {
                return $clean;
            }
        }
    }

    $tag = strtolower($node->tagName);
    return in_array($tag, ['header', 'main', 'section', 'article', 'aside', 'footer', 'nav'], true) ? $tag : '';
}

function fallback_base(string $tag, array &$counts): string
{
    $counts[$tag] = ($counts[$tag] ?? 0) + 1;
    return match ($tag) {
        'h1', 'h2', 'h3', 'h4', 'h5', 'h6' => $counts[$tag] === 1 ? 'hero' : 'section_' . ($counts[$tag] - 1),
        'a' => 'link_' . $counts[$tag],
        'img' => $counts[$tag] === 1 ? 'hero' : 'image_' . $counts[$tag],
        default => $counts[$tag] === 1 ? 'block' : 'block_' . $counts[$tag],
    };
}

function clean_name(string $value): string
{
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9]+/', '_', $value) ?? '';
    return trim($value, '_');
}
