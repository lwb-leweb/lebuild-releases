<?php
declare(strict_types=1);

require_once __DIR__ . '/fileStore.php';

/**
 * Snapshot a source file to /content/originals/<base>.<timestamp>.<ext>
 * before any rewrite, so a half-written PHP file can be recovered.
 */
function snapshot_original_file(string $file): void
{
    if (!is_file($file)) {
        return;
    }
    ensure_dir(ORIGINALS_ROOT);
    $info = pathinfo($file);
    $base = $info['filename'] ?? basename($file);
    $ext  = isset($info['extension']) && $info['extension'] !== '' ? '.' . $info['extension'] : '';
    $snapshot = ORIGINALS_ROOT . '/' . $base . '.' . gmdate('YmdHis') . $ext;
    @copy($file, $snapshot);
    prune_original_snapshots($base, $ext);
}

function prune_original_snapshots(string $base, string $ext, int $keep = BACKUP_RETENTION): void
{
    $pattern = ORIGINALS_ROOT . '/' . $base . '.*' . $ext;
    $files = glob($pattern) ?: [];
    $stamped = [];
    foreach ($files as $f) {
        if (preg_match('/\.\d{14}' . preg_quote($ext, '/') . '$/', $f)) {
            $stamped[] = $f;
        }
    }
    if (count($stamped) <= $keep) {
        return;
    }
    rsort($stamped);
    foreach (array_slice($stamped, $keep) as $old) {
        @unlink($old);
    }
}

/**
 * Writes saved content values back into the PHP source file so the page
 * renders the correct text even without JavaScript.
 */
function write_component_to_php(string $name, array $content): void
{
    $components = shared_components();
    $file = $components[$name] ?? null;
    if ($file === null || !is_file($file)) {
        return;
    }

    $html = (string) file_get_contents($file);
    $flat = flatten_content($content);

    foreach ($flat as $id => $value) {
        if (!is_string($value)) {
            continue;
        }
        $html = apply_php_content_update($html, $name . '.' . $id, $value);
    }

    snapshot_original_file($file);
    atomic_write($file, $html);
}

function write_content_to_php(string $page, array $content): void
{
    $file = SITE_ROOT . '/' . $page . '.php';
    if (!is_file($file)) {
        $file = SITE_ROOT . '/' . $page . '.html';
    }
    if (!is_file($file)) {
        return;
    }

    $html = (string) file_get_contents($file);
    $flat = flatten_content($content);

    foreach ($flat as $id => $value) {
        if (!is_string($value)) {
            continue;
        }
        $html = apply_php_content_update($html, (string) $id, $value);
    }

    snapshot_original_file($file);
    atomic_write($file, $html);
}

function apply_php_content_update(string $html, string $id, string $value): string
{
    $qid           = preg_quote($id, '/');
    $encodedAttr   = htmlspecialchars($value, ENT_HTML5 | ENT_QUOTES, 'UTF-8');
    $encodedInline = encode_inline_text($value);

    // <a data-edit-id="..."> → update href attribute value
    $html = preg_replace_callback(
        '/<a\b([^>]*\bdata-edit-id="' . $qid . '"[^>]*)>/i',
        static function (array $m) use ($encodedAttr): string {
            $attrs = preg_replace('/\bhref="[^"]*"/i', 'href="' . $encodedAttr . '"', $m[1]);
            return '<a' . $attrs . '>';
        },
        $html
    ) ?? $html;

    // <a data-edit-text-id="..."> → update visible link text
    $html = preg_replace_callback(
        '/<a\b([^>]*\bdata-edit-text-id="' . $qid . '"[^>]*)>(.*?)<\/a>/is',
        static function (array $m) use ($encodedInline): string {
            // Defensive: preserve anchors that wrap real elements (e.g. <img>).
            // Only <br> is treated as part of the editable text payload.
            if (inner_has_non_br_elements($m[2])) {
                return $m[0];
            }
            return '<a' . $m[1] . '>' . $encodedInline . '</a>';
        },
        $html
    ) ?? $html;

    // Heading / paragraph / inline elements → update text content
    $html = preg_replace_callback(
        '/<(h[1-6]|p|span|div|li|td|th|label|button|strong|em)\b([^>]*\bdata-edit-id="' . $qid . '"[^>]*)>(.*?)<\/\1>/is',
        static function (array $m) use ($encodedInline): string {
            // Defensive: don't overwrite inner if it carries non-br elements
            // (e.g. nested icons). Only <br> is preserved as editable content.
            if (inner_has_non_br_elements($m[3])) {
                return $m[0];
            }
            return '<' . $m[1] . $m[2] . '>' . $encodedInline . '</' . $m[1] . '>';
        },
        $html
    ) ?? $html;

    // <img data-edit-id="..."> → update src attribute value
    $html = preg_replace_callback(
        '/<img\b([^>]*\bdata-edit-id="' . $qid . '"[^>]*)\/?>/i',
        static function (array $m) use ($encodedAttr): string {
            $attrs = preg_replace('/\bsrc="[^"]*"/i', 'src="' . $encodedAttr . '"', $m[1]);
            return '<img' . $attrs . '>';
        },
        $html
    ) ?? $html;

    return $html;
}

/**
 * Encodes a text value for safe injection into HTML while keeping <br> tags
 * intact. Everything else is htmlspecialchars-escaped.
 */
function encode_inline_text(string $value): string
{
    $sentinel = "\x01BR\x01";
    $tagged   = preg_replace('/<br\s*\/?>/i', $sentinel, $value) ?? $value;
    $encoded  = htmlspecialchars($tagged, ENT_HTML5 | ENT_QUOTES, 'UTF-8');
    return str_replace($sentinel, '<br>', $encoded);
}

/**
 * Returns true if the raw inner HTML contains any tag other than <br>.
 * Used to skip destructive rewrites that would clobber nested elements.
 */
function inner_has_non_br_elements(string $inner): bool
{
    return (bool) preg_match('/<(?!br\b|\/br\b)[a-z]/i', $inner);
}
