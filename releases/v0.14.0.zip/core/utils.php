<?php
declare(strict_types=1);

define('PROJECT_ROOT', dirname(__DIR__));
define('PUBLIC_ROOT', PROJECT_ROOT . '/public');
define('SITE_ROOT', PUBLIC_ROOT . '/site');
define('CONTENT_ROOT', PROJECT_ROOT . '/content');
// Persistente Konfiguration bleibt direkt unter content/ (users.json,
// plugins.json, config.json, content-types/, labels/). Alles, was sich aus
// public/site/ + dem Importer rekonstruieren lässt — Seiten-JSON, Backups,
// Originale, Import-Status, Updater-Runtime-State — landet unter
// content/cache/ und ist gefahrlos wegwerfbar.
define('CACHE_ROOT', CONTENT_ROOT . '/cache');
define('PAGES_ROOT', CACHE_ROOT . '/pages');
define('BACKUPS_ROOT', CACHE_ROOT . '/backups');
define('ORIGINALS_ROOT', CACHE_ROOT . '/originals');
define('UPLOADS_ROOT', PUBLIC_ROOT . '/uploads');

function ensure_dir(string $path): void
{
    if (!is_dir($path) && !mkdir($path, 0775, true) && !is_dir($path)) {
        throw new RuntimeException('Cannot create directory: ' . $path);
    }
}

function json_response(array $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function read_json_body(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return [];
    }

    $data = json_decode($raw, true);
    if (!is_array($data)) {
        json_response(['ok' => false, 'error' => 'Invalid JSON body'], 400);
    }

    return $data;
}

function safe_page_name(string $page): string
{
    $page = trim($page);
    if (!preg_match('/^[a-zA-Z0-9_-]+$/', $page)) {
        json_response(['ok' => false, 'error' => 'Invalid page name'], 400);
    }

    return $page;
}

function sanitize_text_value(mixed $value): string
{
    if (!is_scalar($value)) {
        return '';
    }

    $clean = strip_tags((string) $value, '<br>');
    // strip_tags keeps attributes on allowed tags — normalize <br foo="…"> to plain <br>
    $clean = preg_replace('/<br\b[^>]*>/i', '<br>', $clean) ?? $clean;
    return trim($clean);
}

function flatten_content(array $content, string $prefix = ''): array
{
    $flat = [];
    foreach ($content as $key => $value) {
        $path = $prefix === '' ? (string) $key : $prefix . '.' . $key;
        if (is_array($value)) {
            $flat += flatten_content($value, $path);
        } else {
            $flat[$path] = $value;
        }
    }

    return $flat;
}

function set_nested_value(array &$target, string $path, mixed $value): void
{
    $parts = explode('.', $path);
    $cursor = &$target;
    foreach ($parts as $index => $part) {
        if ($index === count($parts) - 1) {
            $cursor[$part] = $value;
            return;
        }

        if (!isset($cursor[$part]) || !is_array($cursor[$part])) {
            $cursor[$part] = [];
        }
        $cursor = &$cursor[$part];
    }
}

/**
 * Zufälliger Schlüssel pro Installation (HMAC für Formular-Signaturen,
 * Rate-Limit-Dateinamen). Wird beim ersten Aufruf erzeugt und liegt in
 * content/, das weder ausgeliefert noch vom Update angefasst wird.
 */
function app_secret(): string
{
    static $secret = null;
    if ($secret !== null) {
        return $secret;
    }

    $path = CONTENT_ROOT . '/secret.key';
    $existing = is_file($path) ? trim((string) file_get_contents($path)) : '';
    if (strlen($existing) >= 64) {
        return $secret = $existing;
    }

    ensure_dir(CONTENT_ROOT);
    $new = bin2hex(random_bytes(32));
    $tmp = $path . '.' . bin2hex(random_bytes(4)) . '.tmp';
    if (file_put_contents($tmp, $new) === false || !rename($tmp, $path)) {
        @unlink($tmp);
        throw new RuntimeException('Cannot create app secret: ' . $path);
    }
    @chmod($path, 0600);

    return $secret = $new;
}

function current_iso_time(): string
{
    return gmdate('Y-m-d\TH:i:s\Z');
}

function shared_components(): array
{
    return [
        'header' => SITE_ROOT . '/includes/navigation.php',
        'footer' => SITE_ROOT . '/includes/footer.php',
    ];
}

/**
 * SVG darf nur rein, wenn es nichts Ausführbares enthält. Lieber zu streng
 * als zu lax: abgelehnt wird, was nicht nach reiner Grafik aussieht.
 */
function svg_is_safe(string $svg): bool
{
    if (stripos($svg, '<!ENTITY') !== false || stripos($svg, '<!DOCTYPE') !== false) {
        return false;
    }

    $doc = new DOMDocument();
    $previous = libxml_use_internal_errors(true);
    $loaded = $doc->loadXML($svg, LIBXML_NONET);
    libxml_clear_errors();
    libxml_use_internal_errors($previous);
    if (!$loaded || $doc->documentElement === null || strtolower($doc->documentElement->localName) !== 'svg') {
        return false;
    }

    $forbiddenElements = ['script', 'foreignobject', 'iframe', 'embed', 'object', 'handler', 'listener'];
    foreach ($doc->getElementsByTagName('*') as $element) {
        $name = strtolower($element->localName);
        if (in_array($name, $forbiddenElements, true)) {
            return false;
        }
        foreach ($element->attributes as $attr) {
            $attrName = strtolower($attr->localName);
            $value = strtolower((string) preg_replace('/[\s\x00-\x1f]+/', '', $attr->value));
            if (str_starts_with($attrName, 'on')) {
                return false;
            }
            if (str_contains($value, 'javascript:') || str_contains($value, 'data:text') || str_contains($value, 'data:image/svg')) {
                return false;
            }
            // Verweise nur innerhalb der Datei (#id) oder auf eingebettete Rastergrafiken.
            if ($attrName === 'href' && $value !== '' && !str_starts_with($value, '#') && !preg_match('#^data:image/(png|jpe?g|gif|webp);#', $value)) {
                return false;
            }
            // <animate attributeName="href" …> könnte einen Link nachträglich umbiegen.
            if ($attrName === 'attributename' && str_contains($value, 'href')) {
                return false;
            }
        }
    }

    return true;
}

const UPLOADS_HTACCESS = <<<'HTACCESS'
# Vom Live-Editor angelegt. Uploads sind reine Dateien: nichts ausführen,
# SVGs ohne Skripte ausliefern.
<IfModule mod_headers.c>
  Header set X-Content-Type-Options "nosniff"
  <FilesMatch "(?i)\.svg$">
    Header set Content-Security-Policy "default-src 'none'; img-src data:; style-src 'unsafe-inline'; sandbox"
  </FilesMatch>
</IfModule>
<FilesMatch "(?i)\.(php[0-9]?|phtml|phar|cgi|pl|py|sh)$">
  <IfModule mod_authz_core.c>
    Require all denied
  </IfModule>
  <IfModule !mod_authz_core.c>
    Order deny,allow
    Deny from all
  </IfModule>
</FilesMatch>

HTACCESS;

