<?php
declare(strict_types=1);

require_once __DIR__ . '/plugins.php';

function render_shortcodes_in_html(string $html): string
{
    if (stripos($html, 'data-plugin') === false) {
        return $html;
    }

    $state = load_plugins_state();
    $active = array_flip($state['active']);
    $pattern = '/<(?P<tag>div|span|section|article|aside)\b(?P<attrs>[^>]*\bdata-plugin\s*=\s*["\'][a-z][a-z0-9_-]*["\'][^>]*)>(?P<body>.*?)<\/\1>/is';

    return preg_replace_callback($pattern, static function (array $match) use ($active): string {
        $tag = strtolower($match['tag']);
        $attrsText = $match['attrs'];
        $name = shortcode_attr($attrsText, 'plugin');

        if ($name === null || !plugin_name_valid($name)) {
            return $match[0];
        }

        if (!isset($active[$name])) {
            return '<' . $tag . $attrsText . '></' . $tag . '>';
        }

        $view = shortcode_attr($attrsText, 'view');
        if ($view === null || !preg_match('/^[a-z0-9_-]+$/', $view)) {
            return '<' . $tag . $attrsText . '><!-- plugin ' . htmlspecialchars($name, ENT_QUOTES) . ': data-view missing --></' . $tag . '>';
        }

        try {
            $manifest = plugin_manifest($name);
        } catch (Throwable $e) {
            return '<' . $tag . $attrsText . '><!-- plugin ' . htmlspecialchars($name, ENT_QUOTES) . ': manifest invalid --></' . $tag . '>';
        }

        $shortcode = $manifest['shortcodes'][$view] ?? null;
        if (!is_array($shortcode) || empty($shortcode['renderer']) || !is_string($shortcode['renderer'])) {
            return '<' . $tag . $attrsText . '><!-- plugin ' . htmlspecialchars($name, ENT_QUOTES) . ': view not registered --></' . $tag . '>';
        }

        try {
            $rendererPath = plugin_path($name, $shortcode['renderer']);
        } catch (Throwable $e) {
            return '<' . $tag . $attrsText . '><!-- plugin ' . htmlspecialchars($name, ENT_QUOTES) . ': renderer path invalid --></' . $tag . '>';
        }

        if (!is_file($rendererPath)) {
            return '<' . $tag . $attrsText . '><!-- plugin ' . htmlspecialchars($name, ENT_QUOTES) . ': renderer missing --></' . $tag . '>';
        }

        $attrs = shortcode_data_attrs($attrsText);
        unset($attrs['plugin'], $attrs['view']);

        ob_start();
        try {
            (static function (string $__rendererPath, array $attrs): void {
                require $__rendererPath;
            })($rendererPath, $attrs);
        } catch (Throwable $e) {
            ob_end_clean();
            return '<' . $tag . $attrsText . '><!-- plugin ' . htmlspecialchars($name, ENT_QUOTES) . ': renderer error --></' . $tag . '>';
        }
        $rendered = (string) ob_get_clean();

        return '<' . $tag . $attrsText . '>' . $rendered . '</' . $tag . '>';
    }, $html) ?? $html;
}

function shortcode_attr(string $attrsText, string $name): ?string
{
    if (!preg_match('/\bdata-' . preg_quote($name, '/') . '\s*=\s*(["\'])(.*?)\1/i', $attrsText, $match)) {
        return null;
    }

    return html_entity_decode($match[2], ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

function shortcode_data_attrs(string $attrsText): array
{
    $attrs = [];
    if (!preg_match_all('/\bdata-([a-z0-9_-]+)\s*=\s*(["\'])(.*?)\2/i', $attrsText, $matches, PREG_SET_ORDER)) {
        return $attrs;
    }

    foreach ($matches as $match) {
        $attrs[strtolower($match[1])] = html_entity_decode($match[3], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    return $attrs;
}
