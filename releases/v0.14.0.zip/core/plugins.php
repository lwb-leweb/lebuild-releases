<?php
declare(strict_types=1);

require_once __DIR__ . '/utils.php';

define('PLUGINS_ROOT', PROJECT_ROOT . '/plugins');

function plugin_name_valid(string $name): bool
{
    return (bool) preg_match('/^[a-z][a-z0-9_-]*$/', $name);
}

function plugin_table_name_valid(string $name): bool
{
    return (bool) preg_match('/^[a-z][a-z0-9_]*$/', $name);
}

function plugin_path(string $name, string $sub = ''): string
{
    if (!plugin_name_valid($name)) {
        throw new InvalidArgumentException('Invalid plugin name: ' . $name);
    }

    $base = PLUGINS_ROOT . '/' . $name;
    if ($sub === '') {
        return $base;
    }

    $normalized = str_replace('\\', '/', ltrim($sub, '/'));
    if ($normalized === '' || str_contains($normalized, '..')) {
        throw new InvalidArgumentException('Invalid plugin path: ' . $sub);
    }

    return $base . '/' . $normalized;
}

function plugin_manifest(string $name): array
{
    static $cache = [];

    if (!plugin_name_valid($name)) {
        throw new InvalidArgumentException('Invalid plugin name: ' . $name);
    }
    if (isset($cache[$name])) {
        return $cache[$name];
    }

    $path = plugin_path($name, 'plugin.json');
    if (!is_file($path)) {
        throw new RuntimeException('Plugin manifest not found: ' . $name);
    }

    $data = json_decode((string) file_get_contents($path), true);
    if (!is_array($data)) {
        throw new RuntimeException('Invalid plugin manifest JSON: ' . $name);
    }
    if (($data['name'] ?? '') !== $name) {
        throw new RuntimeException('Plugin manifest name mismatch: ' . $name);
    }
    foreach (['label', 'version', 'requires'] as $required) {
        if (!array_key_exists($required, $data)) {
            throw new RuntimeException('Missing plugin manifest key "' . $required . '": ' . $name);
        }
    }

    $data['requires'] = array_merge(
        ['database' => false, 'mail' => false, 'uploads' => false],
        is_array($data['requires']) ? $data['requires'] : []
    );
    $data['tables'] = plugin_valid_tables($data['tables'] ?? []);

    $cache[$name] = $data;
    return $data;
}

function plugin_valid_tables(mixed $tables): array
{
    if (!is_array($tables)) {
        return [];
    }

    $valid = [];
    foreach ($tables as $table) {
        if (is_string($table) && plugin_table_name_valid($table)) {
            $valid[] = $table;
        }
    }

    return array_values(array_unique($valid));
}

function list_plugin_dirs(): array
{
    if (!is_dir(PLUGINS_ROOT)) {
        return [];
    }

    $names = [];
    foreach (scandir(PLUGINS_ROOT) ?: [] as $entry) {
        if ($entry === '.' || $entry === '..' || !plugin_name_valid($entry)) {
            continue;
        }
        if (!is_dir(PLUGINS_ROOT . '/' . $entry)) {
            continue;
        }
        if (!is_file(PLUGINS_ROOT . '/' . $entry . '/plugin.json')) {
            continue;
        }
        $names[] = $entry;
    }
    sort($names);

    return $names;
}

function plugins_state_path(): string
{
    return CONTENT_ROOT . '/active-plugins.json';
}

function plugin_data_path(string $name): string
{
    if (!plugin_name_valid($name)) {
        throw new InvalidArgumentException('Invalid plugin name: ' . $name);
    }
    return CONTENT_ROOT . '/plugins/' . $name;
}

function load_plugins_state(): array
{
    $path = plugins_state_path();
    if (!is_file($path)) {
        return ['active' => [], 'installed' => []];
    }

    $data = json_decode((string) file_get_contents($path), true);
    if (!is_array($data)) {
        return ['active' => [], 'installed' => []];
    }

    $active = [];
    foreach (($data['active'] ?? []) as $name) {
        if (is_string($name) && plugin_name_valid($name)) {
            $active[] = $name;
        }
    }

    $installed = [];
    if (is_array($data['installed'] ?? null)) {
        foreach ($data['installed'] as $name => $meta) {
            if (!is_string($name) || !plugin_name_valid($name) || !is_array($meta)) {
                continue;
            }
            $meta['tables'] = plugin_valid_tables($meta['tables'] ?? []);
            $installed[$name] = $meta;
        }
    }

    return [
        'active' => array_values(array_unique($active)),
        'installed' => $installed,
    ];
}

function save_plugins_state(array $state): void
{
    $path = plugins_state_path();

    $active = [];
    foreach (($state['active'] ?? []) as $name) {
        if (is_string($name) && plugin_name_valid($name)) {
            $active[] = $name;
        }
    }

    $installed = [];
    if (is_array($state['installed'] ?? null)) {
        foreach ($state['installed'] as $name => $meta) {
            if (!is_string($name) || !plugin_name_valid($name) || !is_array($meta)) {
                continue;
            }
            $meta['tables'] = plugin_valid_tables($meta['tables'] ?? []);
            $installed[$name] = $meta;
        }
    }

    $payload = [
        'active' => array_values(array_unique($active)),
        'installed' => empty($installed) ? new stdClass() : $installed,
    ];

    ensure_dir(dirname($path));
    $json = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        throw new RuntimeException('Cannot encode active-plugins.json');
    }

    $tmp = $path . '.tmp';
    if (file_put_contents($tmp, $json . PHP_EOL, LOCK_EX) === false) {
        throw new RuntimeException('Cannot write active-plugins.json');
    }
    if (!rename($tmp, $path)) {
        @unlink($tmp);
        throw new RuntimeException('Cannot finalize active-plugins.json');
    }
}

function plugin_active(string $name): bool
{
    if (!plugin_name_valid($name)) {
        return false;
    }

    $state = load_plugins_state();
    return in_array($name, $state['active'], true);
}

function require_plugin_active(string $name): void
{
    if (!plugin_active($name)) {
        json_response(['ok' => false, 'error' => 'Plugin not active'], 404);
    }
}

function plugin_installed(string $name): bool
{
    if (!plugin_name_valid($name)) {
        return false;
    }

    $state = load_plugins_state();
    return isset($state['installed'][$name]);
}

function plugin_has_admin_sidebar(array $manifest): bool
{
    return is_array($manifest['admin']['sidebar'] ?? null);
}

function active_plugin_admin_info(): array
{
    $state = load_plugins_state();
    $info = [];

    foreach ($state['active'] as $name) {
        try {
            $manifest = plugin_manifest($name);
        } catch (Throwable $e) {
            continue;
        }
        if (!plugin_has_admin_sidebar($manifest)) {
            continue;
        }

        $extra = plugin_extra_sidebar_entries($name);
        if ($extra !== null) {
            foreach ($extra as $entry) {
                $info[] = $entry;
            }
            continue;
        }

        $sidebar = $manifest['admin']['sidebar'];
        $module = plugin_admin_module_path($manifest);
        $info[] = [
            'name' => $name,
            'route' => $name,
            'label' => (string) ($sidebar['label'] ?? $manifest['label'] ?? $name),
            'hasAdminModule' => $module !== null,
            'hasSchema' => isset($manifest['schema']['fields']) && is_array($manifest['schema']['fields']),
        ];
    }

    return $info;
}

function plugin_extra_sidebar_entries(string $name): ?array
{
    if (!plugin_name_valid($name)) {
        return null;
    }

    $libPath = plugin_path($name, 'lib.php');
    if (!is_file($libPath)) {
        return null;
    }
    require_once $libPath;

    $fn = str_replace('-', '_', $name) . '_admin_sidebar_entries';
    if (!function_exists($fn)) {
        return null;
    }

    try {
        $entries = $fn();
    } catch (Throwable $e) {
        return null;
    }
    if (!is_array($entries)) {
        return null;
    }

    $valid = [];
    foreach ($entries as $entry) {
        if (!is_array($entry)) {
            continue;
        }
        $route = $entry['route'] ?? null;
        $label = $entry['label'] ?? null;
        if (!is_string($route) || !is_string($label) || $label === '') {
            continue;
        }
        if (!preg_match('/^[a-z][a-z0-9_-]*(\/[a-z][a-z0-9_-]+)*$/', $route)) {
            continue;
        }
        $entry['name'] = $name;
        $entry['route'] = $route;
        $entry['label'] = $label;
        $entry['hasAdminModule'] = !empty($entry['hasAdminModule']);
        $entry['hasSchema'] = !empty($entry['hasSchema']);
        $valid[] = $entry;
    }

    return $valid;
}

function plugin_admin_module_path(array $manifest): ?string
{
    $module = $manifest['admin']['sidebar']['module'] ?? null;
    if (!is_string($module) || trim($module) === '') {
        return null;
    }
    if (str_contains(str_replace('\\', '/', $module), '..')) {
        return null;
    }

    return $module;
}

function filter_site_html(string $html): string
{
    $state = load_plugins_state();
    foreach ($state['active'] as $name) {
        if (!plugin_name_valid($name)) {
            continue;
        }
        $libPath = plugin_path($name, 'lib.php');
        if (!is_file($libPath)) {
            continue;
        }
        require_once $libPath;
        $fn = str_replace('-', '_', $name) . '_filter_site_html';
        if (!function_exists($fn)) {
            continue;
        }
        try {
            $next = $fn($html);
        } catch (Throwable $e) {
            error_log('filter_site_html ' . $name . ' failed: ' . $e->getMessage());
            continue;
        }
        if (is_string($next)) {
            $html = $next;
        }
    }

    return $html;
}

function plugin_sanitize_richtext(string $html): string
{
    $allowed = '<p><br><strong><b><em><i><u><ul><ol><li><a><blockquote><h2><h3><h4>';
    $clean = strip_tags($html, $allowed);
    $clean = preg_replace('/\s+on[a-z]+\s*=\s*(".*?"|\'.*?\'|[^\s>]+)/i', '', $clean) ?? '';
    $clean = preg_replace('/\s+style\s*=\s*(".*?"|\'.*?\'|[^\s>]+)/i', '', $clean) ?? '';
    $clean = preg_replace('/\s+href\s*=\s*(["\'])\s*javascript:[^"\']*\1/i', ' href="#"', $clean) ?? '';

    return trim($clean);
}
