<?php
declare(strict_types=1);

require_once __DIR__ . '/utils.php';

function db_config_path(): string
{
    return PROJECT_ROOT . '/core/db.config.php';
}

function db_config_exists(): bool
{
    return is_file(db_config_path());
}

function db_load_config(): ?array
{
    if (!db_config_exists()) {
        return null;
    }
    $config = require db_config_path();
    if (!is_array($config)) {
        return null;
    }
    return $config;
}

function db_save_config(array $config): void
{
    $required = ['host', 'port', 'name', 'user', 'password'];
    foreach ($required as $key) {
        if (!isset($config[$key])) {
            throw new InvalidArgumentException("Missing db config key: {$key}");
        }
    }
    $config['charset'] = $config['charset'] ?? 'utf8mb4';

    $php = "<?php\nreturn " . var_export($config, true) . ";\n";
    $tmp = db_config_path() . '.tmp';
    if (file_put_contents($tmp, $php, LOCK_EX) === false) {
        throw new RuntimeException('Cannot write db.config.php');
    }
    if (!rename($tmp, db_config_path())) {
        @unlink($tmp);
        throw new RuntimeException('Cannot finalize db.config.php');
    }
    @chmod(db_config_path(), 0640);
}

function db_dsn(array $config): string
{
    return sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=%s',
        $config['host'],
        (int) $config['port'],
        $config['name'],
        $config['charset']
    );
}

$DB_CONNECTION = null;

function db(): PDO
{
    global $DB_CONNECTION;
    if ($DB_CONNECTION instanceof PDO) {
        return $DB_CONNECTION;
    }
    $config = db_load_config();
    if ($config === null) {
        throw new RuntimeException('Database not configured. Activate a database-required plugin first.');
    }
    $DB_CONNECTION = new PDO(
        db_dsn($config),
        $config['user'],
        $config['password'],
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
    return $DB_CONNECTION;
}

function db_test_connection(array $config): array
{
    try {
        $pdo = new PDO(
            db_dsn($config),
            $config['user'],
            $config['password'],
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        $pdo->query('SELECT 1');
        return ['ok' => true];
    } catch (Throwable $e) {
        return ['ok' => false, 'error' => $e->getMessage()];
    }
}
