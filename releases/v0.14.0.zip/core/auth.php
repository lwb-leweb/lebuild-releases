<?php
declare(strict_types=1);

require_once __DIR__ . '/utils.php';
require_once __DIR__ . '/users.php';

const DEFAULT_ADMIN_USER = 'admin';
const DEFAULT_ADMIN_PASSWORD = 'admin';
const LOGIN_MAX_FAILURES = 10;
const LOGIN_FAILURE_WINDOW = 900;

function start_app_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
    session_start();
}

function configured_admin_user(): string
{
    return getenv('LIVE_EDITOR_USER') ?: DEFAULT_ADMIN_USER;
}

function configured_admin_password(): string
{
    return getenv('LIVE_EDITOR_PASSWORD') ?: DEFAULT_ADMIN_PASSWORD;
}

function auth_bootstrap_admin(string $username, string $password): ?array
{
    $now = current_iso_time();
    $hash = password_hash($password, PASSWORD_BCRYPT);
    if (!is_string($hash) || $hash === '') {
        return null;
    }
    $user = [
        'id' => users_generate_id(),
        'username' => $username,
        'passwordHash' => $hash,
        'role' => USER_ROLE_ADMIN,
        'createdAt' => $now,
        'updatedAt' => $now,
    ];
    // Mit dem eingebauten Standardpasswort darf niemand dauerhaft arbeiten.
    if ($password === DEFAULT_ADMIN_PASSWORD) {
        $user['mustChangePassword'] = true;
    }
    $store = users_load();
    $store['users'][] = $user;
    users_save($store);

    return $user;
}

function auth_complete_login(array $user): void
{
    session_regenerate_id(true);
    $_SESSION['logged_in'] = true;
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

function login_user(string $username, string $password): bool
{
    $username = trim($username);
    if ($username === '' || $password === '') {
        return false;
    }

    if (!users_has_admin()) {
        $expectedUser = configured_admin_user();
        $expectedPassword = configured_admin_password();
        if (!hash_equals($expectedUser, $username) || !hash_equals($expectedPassword, $password)) {
            return false;
        }
        $bootstrapped = auth_bootstrap_admin($expectedUser, $expectedPassword);
        if ($bootstrapped === null) {
            return false;
        }
        auth_complete_login($bootstrapped);
        return true;
    }

    $user = users_find_by_username($username);
    if ($user === null) {
        return false;
    }
    if (!users_verify_password($user, $password)) {
        return false;
    }

    if (users_needs_rehash($user)) {
        $newHash = password_hash($password, PASSWORD_BCRYPT);
        if (is_string($newHash) && $newHash !== '') {
            $store = users_load();
            foreach ($store['users'] as &$candidate) {
                if ($candidate['id'] === $user['id']) {
                    $candidate['passwordHash'] = $newHash;
                    $candidate['updatedAt'] = current_iso_time();
                    $user = $candidate;
                    break;
                }
            }
            unset($candidate);
            users_save($store);
        }
    }

    auth_complete_login($user);
    return true;
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}

function is_logged_in(): bool
{
    return !empty($_SESSION['logged_in']);
}

function current_user(): ?array
{
    if (!is_logged_in()) {
        return null;
    }
    $id = $_SESSION['user_id'] ?? null;
    if (!is_string($id) || $id === '') {
        return null;
    }

    return users_find_by_id($id);
}

function current_role(): ?string
{
    // Rolle immer aus users.json, nie aus der Session: gelöschte oder
    // herabgestufte Benutzer verlieren ihre Rechte sofort.
    return current_user()['role'] ?? null;
}

function must_change_password(): bool
{
    return !empty(current_user()['mustChangePassword']);
}

function is_admin(): bool
{
    return current_role() === USER_ROLE_ADMIN;
}

function require_auth(bool $allowPendingPasswordChange = false): void
{
    start_app_session();
    if (!is_logged_in()) {
        json_response(['ok' => false, 'error' => 'Not authenticated'], 401);
    }
    if (current_user() === null) {
        logout_user();
        json_response(['ok' => false, 'error' => 'Not authenticated'], 401);
    }
    if (!$allowPendingPasswordChange && must_change_password()) {
        json_response(['ok' => false, 'error' => 'Password change required'], 403);
    }
}

function require_admin(): void
{
    require_auth();
    if (!is_admin()) {
        json_response(['ok' => false, 'error' => 'Forbidden'], 403);
    }
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf'];
}

function require_csrf(): void
{
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!is_string($token) || !hash_equals(csrf_token(), $token)) {
        json_response(['ok' => false, 'error' => 'Invalid CSRF token'], 403);
    }
}

function login_throttle_path(): string
{
    $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
    return CACHE_ROOT . '/login-throttle/' . substr(hash_hmac('sha256', $ip, app_secret()), 0, 32) . '.json';
}

function login_recent_failures(): array
{
    $data = json_decode((string) @file_get_contents(login_throttle_path()), true);
    if (!is_array($data)) {
        return [];
    }
    $cutoff = time() - LOGIN_FAILURE_WINDOW;
    return array_values(array_filter(array_map('intval', $data), static fn (int $ts): bool => $ts > $cutoff));
}

function login_throttled(): bool
{
    return count(login_recent_failures()) >= LOGIN_MAX_FAILURES;
}

function login_record_failure(): void
{
    $failures = login_recent_failures();
    $failures[] = time();
    $path = login_throttle_path();
    ensure_dir(dirname($path));
    @file_put_contents($path, json_encode($failures), LOCK_EX);
}

function login_clear_failures(): void
{
    @unlink(login_throttle_path());
}
