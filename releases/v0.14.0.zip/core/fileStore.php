<?php
declare(strict_types=1);

require_once __DIR__ . '/utils.php';

function prepare_storage(): void
{
    ensure_dir(PAGES_ROOT);
    ensure_dir(BACKUPS_ROOT);
    ensure_dir(ORIGINALS_ROOT);
    ensure_dir(UPLOADS_ROOT);
    if (!is_file(UPLOADS_ROOT . '/.htaccess')) {
        @file_put_contents(UPLOADS_ROOT . '/.htaccess', UPLOADS_HTACCESS);
    }
}

function page_json_path(string $page): string
{
    return PAGES_ROOT . '/' . safe_page_name($page) . '.json';
}

function load_page_content(string $page): array
{
    $path = page_json_path($page);
    if (!is_file($path)) {
        json_response(['ok' => false, 'error' => 'Page not found'], 404);
    }

    $data = json_decode((string) file_get_contents($path), true);
    if (!is_array($data)) {
        json_response(['ok' => false, 'error' => 'Page JSON is invalid'], 500);
    }

    return $data;
}

function list_pages(): array
{
    prepare_storage();
    $files = glob(PAGES_ROOT . '/*.json') ?: [];
    $components = array_keys(shared_components());
    $pages = array_map(static fn (string $file): string => basename($file, '.json'), $files);
    $pages = array_values(array_filter($pages, static fn (string $p): bool => !in_array($p, $components, true)));
    sort($pages);

    return $pages;
}

function load_component_content(string $name): ?array
{
    $path = page_json_path($name);
    if (!is_file($path)) {
        return null;
    }
    $data = json_decode((string) file_get_contents($path), true);
    return is_array($data) ? $data : null;
}

function page_title_from_content(array $content, string $fallback): string
{
    $flat = flatten_content($content);
    foreach ($flat as $path => $value) {
        if (preg_match('/(^|\.)(title)$/', $path) && is_scalar($value) && trim((string) $value) !== '') {
            return trim((string) $value);
        }
    }

    foreach ($flat as $path => $value) {
        if (preg_match('/(^|\.)(text)$/', $path) && is_scalar($value) && trim((string) $value) !== '') {
            return trim((string) $value);
        }
    }

    return $fallback;
}

function page_extension(string $page): string
{
    return is_file(SITE_ROOT . '/' . $page . '.php') ? 'php' : 'html';
}

function list_page_info(): array
{
    prepare_storage();
    $pages = [];
    foreach (list_pages() as $page) {
        $path = page_json_path($page);
        $content = load_page_content($page);
        $pages[] = [
            'page' => $page,
            'title' => page_title_from_content($content, $page),
            'updatedAt' => is_file($path) ? gmdate('c', (int) filemtime($path)) : null,
            'ext' => page_extension($page),
        ];
    }

    return $pages;
}

function sanitize_content_tree(array $content): array
{
    $clean = [];
    foreach ($content as $key => $value) {
        $safeKey = preg_replace('/[^a-zA-Z0-9_-]/', '', (string) $key);
        if ($safeKey === '') {
            continue;
        }
        if (is_array($value)) {
            $clean[$safeKey] = sanitize_content_tree($value);
        } else {
            $clean[$safeKey] = sanitize_text_value($value);
        }
    }

    return $clean;
}

function atomic_write(string $path, string $content): void
{
    $dir = dirname($path);
    ensure_dir($dir);

    $tmp = tempnam($dir, basename($path) . '.tmp.');
    if ($tmp === false) {
        json_response(['ok' => false, 'error' => 'Could not create temp file'], 500);
    }

    if (file_put_contents($tmp, $content, LOCK_EX) === false) {
        @unlink($tmp);
        json_response(['ok' => false, 'error' => 'Could not write temp file'], 500);
    }

    if (!rename($tmp, $path)) {
        @unlink($tmp);
        json_response(['ok' => false, 'error' => 'Could not finalize write'], 500);
    }
}

const BACKUP_RETENTION = 15;

function prune_backups(string $page, int $keep = BACKUP_RETENTION): void
{
    $backupDir = BACKUPS_ROOT . '/' . $page;
    if (!is_dir($backupDir)) {
        return;
    }
    $files = glob($backupDir . '/*.json') ?: [];
    if (count($files) <= $keep) {
        return;
    }
    rsort($files);
    foreach (array_slice($files, $keep) as $old) {
        @unlink($old);
    }
}

function save_page_content(string $page, array $content): void
{
    prepare_storage();
    $page = safe_page_name($page);
    $path = page_json_path($page);

    if (is_file($path)) {
        $backupDir = BACKUPS_ROOT . '/' . $page;
        ensure_dir($backupDir);
        // Zwei Saves in derselben Sekunde dürfen sich das Backup nicht überschreiben.
        $stamp = (int) gmdate('YmdHis');
        while (is_file($backupDir . '/' . $stamp . '.json')) {
            $stamp++;
        }
        $backupPath = $backupDir . '/' . $stamp . '.json';
        if (!copy($path, $backupPath)) {
            json_response(['ok' => false, 'error' => 'Could not create backup'], 500);
        }
        prune_backups($page);
    }

    $json = json_encode(sanitize_content_tree($content), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        json_response(['ok' => false, 'error' => 'Could not encode JSON'], 500);
    }
    atomic_write($path, $json . PHP_EOL);
}

function import_status(): ?array
{
    $path = CACHE_ROOT . '/import-status.json';
    if (!is_file($path)) {
        return null;
    }

    $data = json_decode((string) file_get_contents($path), true);
    return is_array($data) ? $data : null;
}

function save_import_status(array $status): void
{
    ensure_dir(CACHE_ROOT);
    $json = json_encode($status, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        json_response(['ok' => false, 'error' => 'Could not save import status'], 500);
    }
    try {
        atomic_write(CACHE_ROOT . '/import-status.json', $json . PHP_EOL);
    } catch (Throwable $e) {
        json_response(['ok' => false, 'error' => 'Could not save import status'], 500);
    }
}
