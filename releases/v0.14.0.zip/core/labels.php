<?php
declare(strict_types=1);

require_once __DIR__ . '/utils.php';

const LABELS_ROOT = CONTENT_ROOT . '/labels';

function labels_path(string $page): string
{
    return LABELS_ROOT . '/' . safe_page_name($page) . '.json';
}

function load_label_overrides(string $page): array
{
    $path = labels_path($page);
    if (!is_file($path)) {
        return [];
    }
    $data = json_decode((string) file_get_contents($path), true);
    return is_array($data) ? $data : [];
}

function label_humanize(string $value): string
{
    $value = preg_replace('/[._]+/', ' ', $value) ?? $value;
    $words = preg_split('/\s+/', trim($value)) ?: [];
    $words = array_map(static function (string $w): string {
        if ($w === '') return '';
        return mb_strtoupper(mb_substr($w, 0, 1)) . mb_substr($w, 1);
    }, $words);
    return implode(' ', $words);
}

function label_from_id(string $id): string
{
    $parts = explode('.', $id);
    if (count($parts) < 2) {
        return label_humanize($id);
    }
    $field = array_pop($parts);
    $group = implode('.', $parts);

    $fieldIndex = '';
    if (preg_match('/^(.*?)_(\d+)$/', $field, $m)) {
        $field = $m[1];
        $fieldIndex = $m[2];
    }

    $fieldLabel = match (strtolower($field)) {
        'title' => 'Titel',
        'text' => 'Text',
        'image' => 'Bild',
        'url' => 'Link',
        default => label_humanize($field),
    };

    $groupLabel = label_humanize($group);

    if ($fieldIndex !== '') {
        $groupLabel = trim($groupLabel . ' ' . $fieldIndex);
    }

    if ($groupLabel === '') {
        return $fieldLabel;
    }
    return $groupLabel . ': ' . $fieldLabel;
}

function build_labels_for_content(string $page, array $content): array
{
    $overrides = load_label_overrides($page);
    foreach (array_keys(shared_components()) as $componentName) {
        $overrides = array_merge(load_label_overrides($componentName), $overrides);
    }

    $flat = flatten_content($content);
    $labels = [];
    foreach (array_keys($flat) as $id) {
        $id = (string) $id;
        $labels[$id] = $overrides[$id] ?? label_from_id($id);
    }
    return $labels;
}
