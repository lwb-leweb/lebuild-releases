<?php
declare(strict_types=1);

require_once __DIR__ . '/plugins.php';

function plugin_main_table(array $manifest): ?string
{
    $tables = $manifest['tables'] ?? [];
    if (!is_array($tables) || empty($tables)) {
        return null;
    }

    $name = $tables[0];
    if (!is_string($name) || !plugin_table_name_valid($name)) {
        return null;
    }

    return $name;
}

function plugin_schema_columns(array $manifest): array
{
    $fields = $manifest['schema']['fields'] ?? [];
    if (!is_array($fields)) {
        return [];
    }

    $columns = [];
    foreach ($fields as $field) {
        if (!is_array($field)) {
            continue;
        }
        $name = $field['name'] ?? null;
        if (!is_string($name) || !plugin_table_name_valid($name)) {
            continue;
        }
        $field['type'] = is_string($field['type'] ?? null) ? $field['type'] : 'text';
        $columns[] = $field;
    }

    return $columns;
}

function plugin_schema_field_names(array $manifest): array
{
    return array_map(static fn (array $field): string => $field['name'], plugin_schema_columns($manifest));
}

function plugin_schema_slugify(string $value): string
{
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9]+/', '-', $value) ?? '';
    $value = trim($value, '-');

    return $value !== '' ? $value : 'item';
}

function plugin_schema_normalize_value(array $field, mixed $value, array $allValues): mixed
{
    $type = (string) ($field['type'] ?? 'text');

    if ($type === 'slug') {
        $text = trim(strip_tags((string) $value));
        if ($text === '' && is_string($field['from'] ?? null)) {
            $text = trim(strip_tags((string) ($allValues[$field['from']] ?? '')));
        }
        return plugin_schema_slugify($text);
    }

    if ($type === 'richtext') {
        return plugin_sanitize_richtext((string) $value);
    }

    if ($type === 'boolean') {
        return !empty($value) && $value !== '0' && $value !== 'false' ? '1' : '0';
    }

    if ($type === 'number') {
        return is_numeric($value) ? (string) $value : null;
    }

    if ($type === 'datetime') {
        $text = trim((string) $value);
        if ($text === '') {
            return null;
        }
        $text = str_replace('T', ' ', $text);
        if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $text)) {
            $text .= ':00';
        }
        return preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $text) ? $text : null;
    }

    if ($type === 'select') {
        $text = trim(strip_tags((string) $value));
        if ($text === '') {
            return '';
        }
        $options = is_array($field['options'] ?? null)
            ? array_values(array_filter($field['options'], 'is_string'))
            : [];
        return in_array($text, $options, true) ? $text : '';
    }

    return trim(strip_tags((string) $value));
}
