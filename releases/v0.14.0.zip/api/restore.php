<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/fileStore.php';
require_once __DIR__ . '/../core/phpRewriter.php';

require_admin();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => 'Method not allowed'], 405);
}

$body = read_json_body();
$page = safe_page_name((string) ($body['page'] ?? ''));
$backup = basename(sanitize_text_value($body['backup'] ?? ''));

if (!preg_match('/^[0-9]{14}\.json$/', $backup)) {
    json_response(['ok' => false, 'error' => 'Invalid backup name'], 400);
}

$backupPath = BACKUPS_ROOT . '/' . $page . '/' . $backup;
if (!is_file($backupPath)) {
    json_response(['ok' => false, 'error' => 'Backup not found'], 404);
}

$data = json_decode((string) file_get_contents($backupPath), true);
if (!is_array($data)) {
    json_response(['ok' => false, 'error' => 'Backup is invalid'], 500);
}

save_page_content($page, $data);
// Die Live-Seite rendert aus public/site/, nicht aus dem JSON.
write_content_to_php($page, $data);

json_response(['ok' => true, 'page' => $page]);

