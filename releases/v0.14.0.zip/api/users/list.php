<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/users.php';

require_admin();

$store = users_load();
$users = array_map('users_public_view', $store['users']);

json_response(['ok' => true, 'users' => $users]);
