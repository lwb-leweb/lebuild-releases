<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/users.php';

require_admin();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => 'Method not allowed'], 405);
}

$body = read_json_body();
$username = trim((string) ($body['username'] ?? ''));
$password = (string) ($body['password'] ?? '');
$role = (string) ($body['role'] ?? '');

if ($error = users_validate_username($username)) {
    json_response(['ok' => false, 'error' => $error], 400);
}
if ($error = users_validate_password($password)) {
    json_response(['ok' => false, 'error' => $error], 400);
}
if ($error = users_validate_role($role)) {
    json_response(['ok' => false, 'error' => $error], 400);
}

if (users_find_by_username($username) !== null) {
    json_response(['ok' => false, 'error' => 'Username already in use'], 409);
}

$now = current_iso_time();
$user = [
    'id' => users_generate_id(),
    'username' => $username,
    'passwordHash' => password_hash($password, PASSWORD_BCRYPT),
    'role' => $role,
    'createdAt' => $now,
    'updatedAt' => $now,
];

$store = users_load();
$store['users'][] = $user;
users_save($store);

json_response(['ok' => true, 'user' => users_public_view($user)]);
