<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';

require_admin();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => 'Method not allowed'], 405);
}

$body = read_json_body();
$allowed = ['name', 'tagline', 'url', 'email', 'owner', 'locale'];
$path = CONTENT_ROOT . '/config.json';
$existing = is_file($path) ? json_decode((string) file_get_contents($path), true) : [];
$cfg = is_array($existing) ? $existing : [];

foreach ($allowed as $key) {
    if (isset($body[$key])) {
        $cfg[$key] = trim((string) $body[$key]);
    }
}

$json = json_encode($cfg, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
if ($json === false) {
    json_response(['ok' => false, 'error' => 'Could not encode JSON'], 500);
}

ensure_dir(CONTENT_ROOT);
file_put_contents($path, $json . PHP_EOL, LOCK_EX);

json_response(['ok' => true]);
