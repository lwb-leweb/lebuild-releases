<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';

start_app_session();
logout_user();

json_response(['ok' => true]);

