<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/fileStore.php';
require_once __DIR__ . '/../core/plugins.php';
require_once __DIR__ . '/../core/updater.php';

start_app_session();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => 'Method not allowed'], 405);
}

if (login_throttled()) {
    json_response(['ok' => false, 'error' => 'Zu viele Fehlversuche, bitte in 15 Minuten erneut versuchen.'], 429);
}

$body = read_json_body();
$username = sanitize_text_value($body['username'] ?? '');
$password = (string) ($body['password'] ?? '');

if (!login_user($username, $password)) {
    login_record_failure();
    json_response(['ok' => false, 'error' => 'Invalid credentials'], 401);
}
login_clear_failures();

$updateStatus = null;
$updateInstalled = null;
try {
    updater_check(false);
    if (updater_should_auto_install()) {
        $result = updater_install();
        if (!empty($result['ok'])) {
            $updateInstalled = [
                'previousVersion' => $result['previousVersion'] ?? null,
                'newVersion' => $result['newVersion'] ?? null,
            ];
        }
    }
    $updateStatus = updater_status();
} catch (Throwable $e) {
    updater_log('login update flow failed: ' . $e->getMessage());
}

$user = current_user();

json_response([
    'ok' => true,
    'csrfToken' => csrf_token(),
    'role' => current_role(),
    'username' => $user['username'] ?? null,
    'mustChangePassword' => must_change_password(),
    'pages' => list_page_info(),
    'importStatus' => import_status(),
    'updateStatus' => $updateStatus,
    'updateInstalled' => $updateInstalled,
    'activePlugins' => active_plugin_admin_info(),
]);
