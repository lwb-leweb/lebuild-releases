<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/updater.php';

require_auth();

json_response(['ok' => true, 'status' => updater_status()]);
