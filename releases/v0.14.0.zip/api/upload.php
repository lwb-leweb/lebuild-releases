<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/fileStore.php';

require_auth();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => 'Method not allowed'], 405);
}

if (empty($_FILES['file']) || !is_array($_FILES['file'])) {
    json_response(['ok' => false, 'error' => 'No file uploaded'], 400);
}

$file = $_FILES['file'];
if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
    json_response(['ok' => false, 'error' => 'Upload failed'], 400);
}
if (($file['size'] ?? 0) > 5 * 1024 * 1024) {
    json_response(['ok' => false, 'error' => 'File is too large'], 400);
}

$originalName = (string) ($file['name'] ?? '');
$extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
$allowed = ['jpg', 'jpeg', 'png', 'webp', 'svg'];
if (!in_array($extension, $allowed, true)) {
    json_response(['ok' => false, 'error' => 'File type is not allowed'], 400);
}

$tmp = (string) ($file['tmp_name'] ?? '');
$mime = mime_content_type($tmp) ?: '';
// Endung und tatsächlicher Inhalt müssen zusammenpassen, sonst landet z. B.
// ein SVG als .jpg an der Skript-Prüfung vorbei.
$mimesByExtension = [
    'jpg' => ['image/jpeg'],
    'jpeg' => ['image/jpeg'],
    'png' => ['image/png'],
    'webp' => ['image/webp'],
    'svg' => ['image/svg+xml', 'text/xml', 'application/xml'],
];
if (!in_array($mime, $mimesByExtension[$extension], true)) {
    json_response(['ok' => false, 'error' => 'Invalid image type'], 400);
}
if ($extension === 'svg' && !svg_is_safe((string) file_get_contents($tmp))) {
    json_response(['ok' => false, 'error' => 'SVG enthält Skripte oder externe Verweise und wurde abgelehnt.'], 400);
}

prepare_storage();
$safeName = preg_replace('/[^a-zA-Z0-9._-]/', '-', pathinfo($originalName, PATHINFO_FILENAME));
$safeName = trim((string) $safeName, '-_.') ?: 'upload';
$targetName = $safeName . '-' . bin2hex(random_bytes(6)) . '.' . $extension;
$targetPath = UPLOADS_ROOT . '/' . $targetName;

if (!move_uploaded_file($tmp, $targetPath)) {
    json_response(['ok' => false, 'error' => 'Could not store upload'], 500);
}

json_response(['ok' => true, 'url' => '/public/uploads/' . $targetName]);
