<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/updater.php';

require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => 'Method not allowed'], 405);
}
require_csrf();

$result = updater_rollback();
if (empty($result['ok'])) {
    json_response(['ok' => false, 'error' => $result['error'] ?? 'Rollback fehlgeschlagen', 'status' => updater_status()], 500);
}

json_response([
    'ok' => true,
    'currentVersion' => $result['currentVersion'] ?? null,
    'status' => updater_status(),
]);
