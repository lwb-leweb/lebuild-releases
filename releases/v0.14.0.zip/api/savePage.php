<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/fileStore.php';
require_once __DIR__ . '/../core/phpRewriter.php';

require_auth();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => 'Method not allowed'], 405);
}

$body = read_json_body();
$page = safe_page_name((string) ($body['page'] ?? ''));
$content = $body['content'] ?? null;

if (!is_array($content)) {
    json_response(['ok' => false, 'error' => 'Invalid content'], 400);
}

foreach (array_keys(shared_components()) as $componentName) {
    if (isset($content[$componentName]) && is_array($content[$componentName])) {
        $componentContent = $content[$componentName];
        unset($content[$componentName]);
        save_page_content($componentName, $componentContent);
        write_component_to_php($componentName, $componentContent);
    }
}

save_page_content($page, $content);
write_content_to_php($page, $content);

json_response(['ok' => true, 'page' => $page]);

