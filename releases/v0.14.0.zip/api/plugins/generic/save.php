<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../../../core/db.php';
require_once __DIR__ . '/../../../core/pluginSchema.php';

require_auth();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => 'Method not allowed'], 405);
}

$body = read_json_body();
$name = (string) ($body['plugin'] ?? '');
if (!plugin_name_valid($name)) {
    json_response(['ok' => false, 'error' => 'Invalid plugin name'], 400);
}
require_plugin_active($name);

$manifest = plugin_manifest($name);
$table = plugin_main_table($manifest);
if ($table === null) {
    json_response(['ok' => false, 'error' => 'Plugin has no main table'], 400);
}

$fields = plugin_schema_columns($manifest);
$fieldByName = [];
foreach ($fields as $field) {
    $fieldByName[$field['name']] = $field;
}

$rawValues = is_array($body['data'] ?? null) ? $body['data'] : [];
$values = [];
foreach ($fieldByName as $key => $field) {
    if (!array_key_exists($key, $rawValues)) {
        if (!empty($field['required'])) {
            json_response(['ok' => false, 'error' => 'Missing required field: ' . $key], 400);
        }
        continue;
    }
    $values[$key] = plugin_schema_normalize_value($field, $rawValues[$key], $rawValues);
    if (!empty($field['required']) && ($values[$key] === '' || $values[$key] === null)) {
        json_response(['ok' => false, 'error' => 'Missing required field: ' . $key], 400);
    }
}

if (!$values) {
    json_response(['ok' => false, 'error' => 'No valid fields'], 400);
}

$id = (int) ($body['id'] ?? 0);

try {
    if ($id > 0) {
        $sets = [];
        $params = [];
        foreach ($values as $key => $value) {
            $sets[] = "`{$key}` = ?";
            $params[] = $value;
        }
        $params[] = $id;
        db()->prepare("UPDATE `{$table}` SET " . implode(', ', $sets) . ' WHERE `id` = ?')->execute($params);
    } else {
        $keys = array_keys($values);
        $placeholders = implode(', ', array_fill(0, count($keys), '?'));
        $sql = "INSERT INTO `{$table}` (`" . implode('`, `', $keys) . "`) VALUES ({$placeholders})";
        db()->prepare($sql)->execute(array_values($values));
        $id = (int) db()->lastInsertId();
    }
} catch (Throwable $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 500);
}

json_response(['ok' => true, 'id' => $id]);
