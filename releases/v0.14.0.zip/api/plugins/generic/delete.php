<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../../../core/db.php';
require_once __DIR__ . '/../../../core/pluginSchema.php';

require_auth();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => 'Method not allowed'], 405);
}

$body = read_json_body();
$name = (string) ($body['plugin'] ?? '');
$id = (int) ($body['id'] ?? 0);
if (!plugin_name_valid($name) || $id <= 0) {
    json_response(['ok' => false, 'error' => 'Invalid request'], 400);
}
require_plugin_active($name);

$manifest = plugin_manifest($name);
$table = plugin_main_table($manifest);
if ($table === null) {
    json_response(['ok' => false, 'error' => 'Plugin has no main table'], 400);
}

try {
    $stmt = db()->prepare("DELETE FROM `{$table}` WHERE `id` = ?");
    $stmt->execute([$id]);
} catch (Throwable $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 500);
}

json_response(['ok' => true]);
