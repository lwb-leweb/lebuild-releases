<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../../../core/db.php';
require_once __DIR__ . '/../../../core/pluginSchema.php';

require_auth();

$name = (string) ($_GET['plugin'] ?? '');
$id = (int) ($_GET['id'] ?? 0);
if (!plugin_name_valid($name) || $id <= 0) {
    json_response(['ok' => false, 'error' => 'Invalid request'], 400);
}
require_plugin_active($name);

$manifest = plugin_manifest($name);
$table = plugin_main_table($manifest);
if ($table === null) {
    json_response(['ok' => false, 'error' => 'Plugin has no main table'], 400);
}

try {
    $stmt = db()->prepare("SELECT * FROM `{$table}` WHERE `id` = ? LIMIT 1");
    $stmt->execute([$id]);
    $row = $stmt->fetch();
} catch (Throwable $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 500);
}

if (!$row) {
    json_response(['ok' => false, 'error' => 'Not found'], 404);
}

json_response([
    'ok' => true,
    'row' => $row,
    'schema' => plugin_schema_columns($manifest),
]);
