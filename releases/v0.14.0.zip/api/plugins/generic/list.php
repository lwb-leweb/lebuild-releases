<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../../../core/db.php';
require_once __DIR__ . '/../../../core/pluginSchema.php';

require_auth();

$name = (string) ($_GET['plugin'] ?? '');
if (!plugin_name_valid($name)) {
    json_response(['ok' => false, 'error' => 'Invalid plugin name'], 400);
}
require_plugin_active($name);

$manifest = plugin_manifest($name);
$table = plugin_main_table($manifest);
if ($table === null) {
    json_response(['ok' => false, 'error' => 'Plugin has no main table'], 400);
}

$columns = plugin_schema_field_names($manifest);
$select = '`id`' . ($columns ? ', `' . implode('`, `', $columns) . '`' : '');

try {
    $rows = db()->query("SELECT {$select} FROM `{$table}` ORDER BY `id` DESC")->fetchAll();
} catch (Throwable $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 500);
}

json_response([
    'ok' => true,
    'rows' => $rows,
    'schema' => plugin_schema_columns($manifest),
]);
