<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/plugins.php';
require_once __DIR__ . '/../../core/db.php';

require_admin();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => 'Method not allowed'], 405);
}

$body = read_json_body();
$name = (string) ($body['name'] ?? '');
if (!plugin_name_valid($name)) {
    json_response(['ok' => false, 'error' => 'Invalid plugin name'], 400);
}

$state = load_plugins_state();
if (!isset($state['installed'][$name])) {
    json_response(['ok' => false, 'error' => 'Plugin not installed'], 404);
}

$manifest = null;
try {
    $manifest = plugin_manifest($name);
} catch (Throwable $e) {
    $manifest = null;
}

if ($manifest !== null && !empty($manifest['requires']['database'])) {
    $sqlPath = plugin_path($name, 'uninstall.sql');
    if (is_file($sqlPath)) {
        try {
            db()->exec((string) file_get_contents($sqlPath));
        } catch (Throwable $e) {
            json_response(['ok' => false, 'error' => 'uninstall.sql failed: ' . $e->getMessage()], 500);
        }
    }
}

unset($state['installed'][$name]);
$state['active'] = array_values(array_diff($state['active'], [$name]));

try {
    save_plugins_state($state);
} catch (Throwable $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 500);
}

json_response(['ok' => true, 'name' => $name, 'state' => load_plugins_state()]);
