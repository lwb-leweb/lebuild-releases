<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/db.php';

require_admin();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => 'Method not allowed'], 405);
}

$body = read_json_body();
$config = [
    'host'     => trim((string) ($body['host'] ?? '')),
    'port'     => (int) ($body['port'] ?? 3306),
    'name'     => trim((string) ($body['name'] ?? '')),
    'user'     => (string) ($body['user'] ?? ''),
    'password' => (string) ($body['password'] ?? ''),
    'charset'  => 'utf8mb4',
];

if ($config['host'] === '' || $config['name'] === '' || $config['user'] === '') {
    json_response(['ok' => false, 'error' => 'host, name and user are required'], 400);
}

$result = db_test_connection($config);
json_response($result, $result['ok'] ? 200 : 400);
