<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/plugins.php';

require_admin();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => 'Method not allowed'], 405);
}

$body = read_json_body();
$name = (string) ($body['name'] ?? '');
if (!plugin_name_valid($name)) {
    json_response(['ok' => false, 'error' => 'Invalid plugin name'], 400);
}

$state = load_plugins_state();
$state['active'] = array_values(array_diff($state['active'], [$name]));

try {
    save_plugins_state($state);
} catch (Throwable $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 500);
}

json_response(['ok' => true, 'name' => $name, 'state' => load_plugins_state()]);
