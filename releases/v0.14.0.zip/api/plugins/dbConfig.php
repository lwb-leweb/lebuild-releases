<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/db.php';

require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    json_response([
        'ok' => true,
        'configured' => db_config_exists(),
    ]);
}

require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => 'Method not allowed'], 405);
}

$body = read_json_body();
$config = [
    'host'     => trim((string) ($body['host'] ?? '')),
    'port'     => (int) ($body['port'] ?? 3306),
    'name'     => trim((string) ($body['name'] ?? '')),
    'user'     => (string) ($body['user'] ?? ''),
    'password' => (string) ($body['password'] ?? ''),
    'charset'  => 'utf8mb4',
];

if ($config['host'] === '' || $config['name'] === '' || $config['user'] === '') {
    json_response(['ok' => false, 'error' => 'host, name and user are required'], 400);
}

$test = db_test_connection($config);
if (!$test['ok']) {
    json_response(['ok' => false, 'error' => 'Connection failed: ' . $test['error']], 400);
}

try {
    db_save_config($config);
} catch (Throwable $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 500);
}

json_response(['ok' => true, 'configured' => true]);
