<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/mail.php';

require_admin();

json_response([
    'ok' => true,
    'config' => core_mail_public_config(),
    'status' => core_mail_status(),
]);
