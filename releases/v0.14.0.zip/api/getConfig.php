<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';

require_auth();

$path = CONTENT_ROOT . '/config.json';
$cfg = is_file($path) ? (json_decode((string) file_get_contents($path), true) ?: []) : [];

$defaults = [
    'name'    => 'LEWEB',
    'tagline' => 'Schnelle Websites · Live Editor · Smarte digitale Lösungen',
    'url'     => 'https://www.leweb.at',
    'email'   => 'office@leweb.at',
    'owner'   => 'Johannes Lehner',
    'locale'  => 'de_AT',
];

json_response(['ok' => true, 'config' => array_merge($defaults, $cfg)]);
