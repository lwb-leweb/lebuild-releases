<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/fileStore.php';
require_once __DIR__ . '/../core/plugins.php';
require_once __DIR__ . '/../core/updater.php';

start_app_session();

// Session ohne existierenden Benutzer (gelöscht) zählt als ausgeloggt.
$currentUser = is_logged_in() ? current_user() : null;
if ($currentUser === null && is_logged_in()) {
    logout_user();
}
$authenticated = $currentUser !== null;

$updateStatus = null;
$updateInstalled = null;

if ($authenticated) {
    try {
        updater_check(false);
        if (updater_should_auto_install()) {
            $result = updater_install();
            if (!empty($result['ok'])) {
                $updateInstalled = [
                    'previousVersion' => $result['previousVersion'] ?? null,
                    'newVersion' => $result['newVersion'] ?? null,
                ];
            }
        }
        $updateStatus = updater_status();
    } catch (Throwable $e) {
        updater_log('bootstrap update flow failed: ' . $e->getMessage());
    }
}

json_response([
    'ok' => true,
    'authenticated' => $authenticated,
    'csrfToken' => $authenticated ? csrf_token() : '',
    'role' => $currentUser['role'] ?? null,
    'username' => $currentUser['username'] ?? null,
    'mustChangePassword' => !empty($currentUser['mustChangePassword']),
    'pages' => $authenticated ? list_page_info() : [],
    'importStatus' => $authenticated ? import_status() : null,
    'updateStatus' => $updateStatus,
    'updateInstalled' => $updateInstalled,
    'activePlugins' => $authenticated ? active_plugin_admin_info() : [],
]);
