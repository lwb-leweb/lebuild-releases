<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/fileStore.php';
require_once __DIR__ . '/../core/labels.php';

require_auth();

$page = safe_page_name((string) ($_GET['page'] ?? ''));

$content = load_page_content($page);
foreach (array_keys(shared_components()) as $componentName) {
    $componentContent = load_component_content($componentName);
    if ($componentContent !== null) {
        $content[$componentName] = $componentContent;
    }
}

json_response([
    'ok' => true,
    'page' => $page,
    'content' => $content,
    'labels' => build_labels_for_content($page, $content),
    'pages' => list_page_info(),
    'importStatus' => import_status(),
]);
