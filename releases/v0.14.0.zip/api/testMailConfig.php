<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/mail.php';

require_admin();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => 'Method not allowed'], 405);
}

$body = read_json_body();
$to = trim((string) ($body['to'] ?? ''));
if ($to === '') {
    $to = core_mail_default_recipient();
}
if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
    json_response(['ok' => false, 'error' => 'Gültige Test-Empfänger-Adresse erforderlich.'], 400);
}

try {
    $result = core_mail_send([
        'to' => $to,
        'subject' => 'Live Editor SMTP-Test',
        'text' => "Diese Testmail wurde vom Live Editor versendet.\n\nWenn sie angekommen ist, funktioniert der Mailversand.",
    ]);
} catch (Throwable $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 500);
}

json_response([
    'ok' => true,
    'transport' => $result['transport'] ?? 'unknown',
]);
