<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/fileStore.php';

require_auth();

$page = safe_page_name((string) ($_GET['page'] ?? ''));
$backupDir = BACKUPS_ROOT . '/' . $page;
$files = is_dir($backupDir) ? glob($backupDir . '/*.json') : [];
$backups = [];

foreach ($files ?: [] as $file) {
    $backups[] = basename($file);
}

rsort($backups);

json_response([
    'ok' => true,
    'page' => $page,
    'backups' => $backups,
]);

