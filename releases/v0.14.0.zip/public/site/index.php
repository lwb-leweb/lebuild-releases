<?php
// Platzhalter-Startseite einer frischen Live-Editor-Installation. Wird vom
// Kunden-Import durch die tatsächliche Website überschrieben.
?>
<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Live Editor — Installation bereit</title>
  <style>
    :root { color-scheme: light dark; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      max-width: 640px;
      margin: 4rem auto;
      padding: 0 1.5rem;
      line-height: 1.55;
      color: #1a1a1a;
      background: #fafafa;
    }
    @media (prefers-color-scheme: dark) {
      body { color: #eee; background: #111; }
      code { background: #222; }
      a.btn { background: #eee; color: #111; }
    }
    h1 { font-size: 1.4rem; margin-bottom: 0.5rem; }
    p.lead { color: #666; margin-top: 0; }
    @media (prefers-color-scheme: dark) { p.lead { color: #aaa; } }
    ol { padding-left: 1.2rem; }
    li { margin: 0.4rem 0; }
    code {
      background: #f0f0f0;
      padding: 0.1em 0.35em;
      border-radius: 3px;
      font-size: 0.92em;
    }
    a.btn {
      display: inline-block;
      margin-top: 1.5rem;
      padding: 0.6rem 1.2rem;
      background: #1a1a1a;
      color: #fff;
      text-decoration: none;
      border-radius: 4px;
      font-size: 0.95rem;
    }
    a.btn:hover { opacity: 0.85; }
  </style>
</head>
<body>
  <h1 data-edit-id="hero.title" data-edit-label="Hero: Titel">Live Editor ist installiert</h1>
  <p class="lead" data-edit-id="block.text" data-edit-label="Block: Text">Diese Seite erscheint, solange noch keine Website importiert wurde.</p>
  <ol>
    <li data-edit-id="block.text_2" data-edit-label="Block 2: Text">Statische HTML-Dateien per FTP nach <code>public/site/</code> hochladen</li>
    <li data-edit-id="block_2.text" data-edit-label="Block 2: Text">Im Admin einloggen und den Import starten</li>
  </ol>
  <a class="btn" href="/public/admin/" data-edit-id="link_1.url" data-edit-text-id="link_1.text" data-edit-label="Link 1: Link">Zum Admin-Login</a>
</body>
</html>
