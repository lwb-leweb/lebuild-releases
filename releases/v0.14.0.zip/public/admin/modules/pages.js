import { state, dom, api, setMessage } from './core.js';
import { renderFields } from './fields.js';
import { loadBackups } from './backups.js';
import { navigate } from './router.js';

export function pageKey(page) {
  return typeof page === 'string' ? page : page.page;
}

export function pageExt(page) {
  const info = state.pageInfo.find(function (p) { return pageKey(p) === page; });
  return (info && info.ext) || 'html';
}

export function pageLabel(page) {
  if (typeof page === 'string') return page;
  const name = page.page;
  return name.charAt(0).toUpperCase() + name.slice(1);
}

export function pageMeta(page) {
  if (typeof page === 'string' || !page.updatedAt) return '';
  try {
    return new Date(page.updatedAt).toLocaleString();
  } catch (e) {
    return page.updatedAt;
  }
}

export function renderPages() {
  dom.pageList.textContent = '';
  (state.pageInfo.length ? state.pageInfo : state.pages).forEach(function (page) {
    const label = pageLabel(page);
    const metaText = pageMeta(page) || pageKey(page) + '.' + (page.ext || 'html');
    const haystack = (label + ' ' + metaText + ' ' + pageKey(page)).toLowerCase();
    if (state.pageQuery && haystack.indexOf(state.pageQuery) === -1) {
      return;
    }

    const button = document.createElement('button');
    button.type = 'button';
    const title = document.createElement('strong');
    title.textContent = label;
    const meta = document.createElement('span');
    meta.textContent = metaText;
    button.className = pageKey(page) === state.currentPage ? 'active page-entry' : 'page-entry';
    button.appendChild(title);
    button.appendChild(meta);
    button.addEventListener('click', function () {
      navigate('page/' + pageKey(page));
    });
    dom.pageList.appendChild(button);
  });
}

export function applyPageFilter() {
  state.pageQuery = (dom.pageSearch.value || '').trim().toLowerCase();
  renderPages();
}

export function loadPage(page) {
  api('/api/getPage.php?page=' + encodeURIComponent(page))
    .then(function (data) {
      state.currentPage = page;
      state.content = data.content || {};
      state.labels = data.labels || {};
      state.pages = data.pages || state.pages;
      state.pageInfo = data.pages || state.pageInfo;
      if (dom.previewFrame) {
        dom.previewFrame.src = '/public/site/' + encodeURIComponent(page) + '.' + pageExt(page) + '?preview=' + Date.now();
      }
      renderPages();
      renderFields();
      loadBackups(page);
      setMessage(dom.editorMessage, '', true);
    })
    .catch(function (error) {
      setMessage(dom.editorMessage, error.message, false);
    });
}
