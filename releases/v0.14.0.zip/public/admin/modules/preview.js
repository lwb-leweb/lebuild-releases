import { state, dom, registerPreviewSync } from './core.js';
import { openInlineEditor } from './inline-editor.js';

let previewOverlay = null;
let previewHighlight = null;
let previewEditButton = null;
let activePreviewTarget = null;
let previewOverlayClearTimer = null;
let pointerOnPreviewButton = false;
let previewSyncTimer = null;
let navigateHandler = null;

export function setPreviewNavigate(fn) { navigateHandler = fn; }
export function getActivePreviewTarget() { return activePreviewTarget; }

function previewRectForTarget(target) {
  const elementRect = target.getBoundingClientRect();
  const tag = target.tagName.toLowerCase();
  let contentRect = null;

  if (tag !== 'img') {
    try {
      const doc = dom.previewFrame && dom.previewFrame.contentDocument;
      if (doc && doc.createRange) {
        const range = doc.createRange();
        range.selectNodeContents(target);
        const rects = Array.prototype.slice.call(range.getClientRects()).filter(function (part) {
          return part.width > 0 && part.height > 0;
        });
        if (rects.length) {
          contentRect = rects.reduce(function (acc, part) {
            const left = Math.min(acc.left, part.left);
            const top = Math.min(acc.top, part.top);
            const right = Math.max(acc.right, part.right);
            const bottom = Math.max(acc.bottom, part.bottom);
            return { left, top, right, bottom };
          }, {
            left: elementRect.left,
            top: elementRect.top,
            right: elementRect.right,
            bottom: elementRect.bottom
          });
          contentRect = {
            left: contentRect.left,
            top: contentRect.top,
            width: contentRect.right - contentRect.left,
            height: contentRect.bottom - contentRect.top
          };
        }
      }
    } catch (error) {}
  }

  const rect = contentRect || elementRect;

  return {
    left: Math.max(8, rect.left),
    top: Math.max(8, rect.top),
    width: Math.max(20, rect.width),
    height: Math.max(20, rect.height)
  };
}

function previewOverlayPlacement(rect) {
  const doc = dom.previewFrame && dom.previewFrame.contentDocument;
  const viewportWidth = doc && doc.documentElement ? doc.documentElement.clientWidth : 0;
  const viewportHeight = doc && doc.documentElement ? doc.documentElement.clientHeight : 0;
  const buttonSize = 28;
  const gap = 8;
  const edge = 8;
  const gutter = buttonSize + gap + 4;
  const isCompact = rect.height < buttonSize + (gap * 2) || rect.width < 96;
  const placement = {
    left: rect.left,
    top: rect.top,
    width: rect.width,
    height: rect.height,
    buttonLeft: 0,
    buttonTop: 0
  };

  if (!isCompact) {
    return placement;
  }

  if (rect.left - gutter >= edge) {
    placement.left = rect.left - gutter;
    placement.width = rect.width + gutter;
    placement.buttonLeft = 0;
    placement.buttonTop = Math.max(0, Math.round((placement.height - buttonSize) / 2));
    return placement;
  }

  if (!viewportWidth || rect.left + rect.width + gutter <= viewportWidth - edge) {
    placement.width = rect.width + gutter;
    placement.buttonLeft = rect.width + gap;
    placement.buttonTop = Math.max(0, Math.round((placement.height - buttonSize) / 2));
    return placement;
  }

  if (rect.top - gutter >= edge) {
    placement.top = rect.top - gutter;
    placement.height = rect.height + gutter;
    placement.buttonLeft = 0;
    placement.buttonTop = 0;
    return placement;
  }

  if (!viewportHeight || rect.top + rect.height + gutter <= viewportHeight - edge) {
    placement.height = rect.height + gutter;
    placement.buttonLeft = 0;
    placement.buttonTop = rect.height + gap;
  }

  return placement;
}

export function ensurePreviewEditorLayer() {
  const doc = dom.previewFrame && dom.previewFrame.contentDocument;
  if (!doc || !doc.body) {
    previewOverlay = null;
    previewHighlight = null;
    previewEditButton = null;
    return;
  }

  let existing = doc.getElementById('live-editor-layer');
  if (!existing) {
    const style = doc.createElement('style');
    style.id = 'live-editor-layer-style';
    style.textContent = '' +
      '#live-editor-layer{position:fixed;inset:0;z-index:2147483647;pointer-events:none;}' +
      '#live-editor-layer.hidden{display:none !important;}' +
      '#live-editor-layer .preview-highlight{position:absolute;border:2px solid #146c5f;border-radius:8px;box-shadow:0 0 0 2px rgba(20,108,95,.08),0 10px 24px rgba(0,0,0,.08);pointer-events:auto;background:transparent;}' +
      '#live-editor-layer .preview-edit-button{position:absolute;left:-2px;top:-2px;width:28px;height:28px;padding:0;border-radius:6px 0 6px 0;border:2px solid #146c5f;display:grid;place-items:center;background:#146c5f;color:#fff;box-shadow:none;pointer-events:auto;cursor:pointer;}' +
      '#live-editor-layer .preview-edit-button::before{content:"\\270E";font-size:14px;line-height:1;}';
    doc.head.appendChild(style);

    existing = doc.createElement('div');
    existing.id = 'live-editor-layer';
    existing.className = 'hidden';
    existing.setAttribute('aria-hidden', 'true');
    existing.innerHTML = '<div class="preview-highlight"><button type="button" class="preview-edit-button" aria-label="Bearbeiten"></button></div>';
    doc.body.appendChild(existing);
  }

  previewOverlay = existing;
  previewHighlight = existing.querySelector('.preview-highlight');
  previewEditButton = existing.querySelector('.preview-edit-button');

  previewEditButton.addEventListener('click', function () {
    const path = previewEditButton.dataset.path;
    const type = previewEditButton.dataset.type || 'text';
    if (path) {
      openInlineEditor(path, type, previewEditButton.dataset.textPath || '');
    }
  });

  previewHighlight.addEventListener('mouseenter', function () {
    pointerOnPreviewButton = true;
    if (previewOverlayClearTimer) {
      clearTimeout(previewOverlayClearTimer);
      previewOverlayClearTimer = null;
    }
  });

  previewHighlight.addEventListener('mouseleave', function () {
    pointerOnPreviewButton = false;
    scheduleClearPreviewOverlay();
  });

  previewEditButton.addEventListener('mouseenter', function () {
    pointerOnPreviewButton = true;
    if (previewOverlayClearTimer) {
      clearTimeout(previewOverlayClearTimer);
      previewOverlayClearTimer = null;
    }
  });

  previewEditButton.addEventListener('mouseleave', function () {
    pointerOnPreviewButton = false;
    scheduleClearPreviewOverlay();
  });
}

export function clearPreviewOverlay() {
  if (previewOverlayClearTimer) {
    clearTimeout(previewOverlayClearTimer);
    previewOverlayClearTimer = null;
  }
  if (previewOverlay) {
    previewOverlay.classList.add('hidden');
  }
  if (previewHighlight) {
    previewHighlight.style.left = '0px';
    previewHighlight.style.top = '0px';
    previewHighlight.style.width = '0px';
    previewHighlight.style.height = '0px';
  }
  if (previewEditButton) {
    previewEditButton.style.left = '';
    previewEditButton.style.top = '';
    previewEditButton.dataset.path = '';
    previewEditButton.dataset.type = '';
    previewEditButton.dataset.textPath = '';
  }
}

function scheduleClearPreviewOverlay() {
  if (previewOverlayClearTimer) {
    clearTimeout(previewOverlayClearTimer);
  }

  previewOverlayClearTimer = setTimeout(function () {
    if (!pointerOnPreviewButton) {
      if (activePreviewTarget) {
        setEditableHover(activePreviewTarget, false);
        activePreviewTarget = null;
      }
      clearPreviewOverlay();
    }
  }, 180);
}

function showPreviewOverlay(target) {
  if (!target) {
    clearPreviewOverlay();
    return;
  }

  const path = target.getAttribute('data-edit-id');
  if (!path) {
    clearPreviewOverlay();
    return;
  }

  const rect = previewRectForTarget(target);
  const placement = previewOverlayPlacement(rect);
  const minOverlayHeight = 28;
  const overlayHeight = Math.max(minOverlayHeight, placement.height);
  const overlayTop = Math.max(8, placement.top - Math.round((overlayHeight - placement.height) / 2) - 3);
  previewOverlay.classList.remove('hidden');
  previewHighlight.style.left = placement.left + 'px';
  previewHighlight.style.top = overlayTop + 'px';
  previewHighlight.style.width = Math.max(20, placement.width) + 'px';
  previewHighlight.style.height = overlayHeight + 'px';
  previewEditButton.style.left = placement.buttonLeft + 'px';
  previewEditButton.style.top = placement.buttonTop + 'px';
  previewEditButton.dataset.path = path;
  previewEditButton.dataset.type = editableType(target);
  previewEditButton.dataset.textPath = target.getAttribute('data-edit-text-id') || '';
}

function editableTarget(node) {
  const body = dom.previewFrame && dom.previewFrame.contentDocument && dom.previewFrame.contentDocument.body;
  while (node && node !== body) {
    if (node.nodeType === 1 && node.hasAttribute && node.hasAttribute('data-edit-id')) {
      return node;
    }
    node = node.parentNode;
  }
  return null;
}

function isInsidePreviewLayer(node) {
  const body = dom.previewFrame && dom.previewFrame.contentDocument && dom.previewFrame.contentDocument.body;
  while (node && node !== body) {
    if (node.nodeType === 1 && node.id === 'live-editor-layer') {
      return true;
    }
    node = node.parentNode;
  }
  return false;
}

function editableType(target) {
  if (!target) return 'text';
  const tag = target.tagName.toLowerCase();
  if (tag === 'img') return 'image';
  if (tag === 'a') return 'link';
  return 'text';
}

function setEditableHover(target, active) {
  if (!target) return;
  if (active) {
    target.style.cursor = 'pointer';
    showPreviewOverlay(target);
    return;
  }
  target.style.cursor = '';
}

export function attachPreviewInteractions() {
  clearPreviewOverlay();

  const doc = dom.previewFrame && dom.previewFrame.contentDocument;
  if (!doc || !doc.body) {
    return;
  }

  doc.addEventListener('mousemove', function (event) {
    const target = editableTarget(event.target);
    if (target === activePreviewTarget) {
      if (target) {
        showPreviewOverlay(target);
      }
      return;
    }

    if (target === null && activePreviewTarget && isInsidePreviewLayer(event.target)) {
      showPreviewOverlay(activePreviewTarget);
      return;
    }

    if (activePreviewTarget) {
      setEditableHover(activePreviewTarget, false);
    }

    activePreviewTarget = target;
    if (activePreviewTarget) {
      setEditableHover(activePreviewTarget, true);
      if (previewOverlayClearTimer) {
        clearTimeout(previewOverlayClearTimer);
        previewOverlayClearTimer = null;
      }
    } else {
      scheduleClearPreviewOverlay();
    }
  });

  doc.addEventListener('mouseleave', function () {
    scheduleClearPreviewOverlay();
  });

  doc.defaultView.addEventListener('scroll', function () {
    if (activePreviewTarget) {
      showPreviewOverlay(activePreviewTarget);
    }
  });

  doc.addEventListener('click', function (event) {
    let node = event.target;
    while (node && node !== doc.body) {
      if (node.tagName && node.tagName.toLowerCase() === 'a') break;
      node = node.parentNode;
    }
    if (!node || !node.tagName || node.tagName.toLowerCase() !== 'a') return;

    const href = node.getAttribute('href');
    if (!href || /^(https?:\/\/|mailto:|tel:|\/\/)/i.test(href)) return;

    const clean = href.split('#')[0].split('?')[0];
    const filename = clean.split('/').pop();
    const match = filename.match(/^([^.]+)\.(php|html)$/);
    if (!match) return;

    const page = match[1];
    const known = state.pageInfo.some(function (p) {
      return ((typeof p === 'string') ? p : p.page) === page;
    });
    if (!known) return;

    event.preventDefault();
    if (navigateHandler) navigateHandler(page);
  });
}

function previewPageDocument() {
  if (!dom.previewFrame || !dom.previewFrame.contentWindow || !dom.previewFrame.contentWindow.document) {
    return null;
  }
  return dom.previewFrame.contentWindow.document;
}

function hasNonBrElementChild(el) {
  for (let i = 0; i < el.children.length; i++) {
    if (el.children[i].tagName.toLowerCase() !== 'br') return true;
  }
  return false;
}

function safeInlineHtml(value) {
  const escaped = String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
  return escaped.replace(/&lt;br\s*\/?&gt;/gi, '<br>');
}

function setInlineText(el, value) {
  if (/<br\s*\/?>/i.test(value)) {
    el.innerHTML = safeInlineHtml(value);
  } else {
    el.textContent = value;
  }
}

function previewValueForElement(el, value) {
  if (typeof value !== 'string') return;
  const tag = el.tagName.toLowerCase();
  if (tag === 'img') { el.src = value; return; }
  if (tag === 'a') { el.href = value; return; }
  setInlineText(el, value);
}

function syncPreview() {
  const doc = previewPageDocument();
  if (!doc) return;

  const values = state.content;
  Array.prototype.forEach.call(doc.querySelectorAll('[data-edit-id]'), function (el) {
    if (el.tagName.toLowerCase() === 'a') {
      const hrefPath = el.getAttribute('data-edit-id');
      const textPath = el.getAttribute('data-edit-text-id') || hrefPath.replace(/\.url$/, '.text');
      const hrefValue = hrefPath.split('.').reduce(function (cursor, part) {
        return cursor && Object.prototype.hasOwnProperty.call(cursor, part) ? cursor[part] : undefined;
      }, values);
      previewValueForElement(el, hrefValue);
      if (textPath && !hasNonBrElementChild(el)) {
        const textValue = textPath.split('.').reduce(function (cursor, part) {
          return cursor && Object.prototype.hasOwnProperty.call(cursor, part) ? cursor[part] : undefined;
        }, values);
        if (typeof textValue === 'string') {
          setInlineText(el, textValue);
        }
      }
      return;
    }

    if (hasNonBrElementChild(el)) {
      return;
    }
    const path = el.getAttribute('data-edit-id');
    const value = path.split('.').reduce(function (cursor, part) {
      return cursor && Object.prototype.hasOwnProperty.call(cursor, part) ? cursor[part] : undefined;
    }, values);
    previewValueForElement(el, value);
  });
}

export function schedulePreviewSync(immediate) {
  if (previewSyncTimer) {
    clearTimeout(previewSyncTimer);
  }
  if (immediate) {
    syncPreview();
    return;
  }
  previewSyncTimer = setTimeout(syncPreview, 120);
}

registerPreviewSync(schedulePreviewSync);

export function onIframeLoad() {
  ensurePreviewEditorLayer();
  attachPreviewInteractions();
  schedulePreviewSync(true);
}
