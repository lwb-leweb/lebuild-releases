import { state, dom, api, setMessage, setAdvancedMode, isAdmin } from './core.js';
import { clearPreviewOverlay, setPreviewNavigate } from './preview.js';
import { closeInlineEditor, saveInlineEditor, onSave as onInlineSave } from './inline-editor.js';
import { renderPages, loadPage, pageKey, applyPageFilter } from './pages.js';
import { onRestore, loadBackups } from './backups.js';
import { navigate, initRouter } from './router.js';
import { setUpdateStatus, showInstalledToast } from './update.js';
import { openModal } from './ui-modal.js';

function showEditor(data) {
  state.pages = data.pages || [];
  state.pageInfo = data.pages || [];
  state.csrfToken = data.csrfToken || state.csrfToken;
  state.activePlugins = data.activePlugins || [];
  state.role = data.role || null;
  state.username = data.username || null;
  dom.loginView.classList.add('hidden');
  dom.editorView.classList.remove('hidden');
  setAdvancedMode(false);
  dom.importNotice.classList.toggle('hidden', !!data.importStatus || state.role !== 'admin');
  renderPages();
  renderPluginNav(state.activePlugins);
  applyRoleVisibility();
  initRouter();
  setUpdateStatus(data.updateStatus || null);
  if (data.updateInstalled) {
    showInstalledToast(data.updateInstalled.previousVersion, data.updateInstalled.newVersion);
  }
  if (data.mustChangePassword) {
    requirePasswordChange();
  }
}

// Nach dem Erst-Login mit dem Standardpasswort sperrt der Server alle
// Endpoints außer dem Passwortwechsel. Abbrechen meldet ab.
function requirePasswordChange() {
  const modal = openModal({
    title: 'Neues Passwort festlegen',
    bodyHtml:
      '<p>Du bist mit dem Standardpasswort angemeldet. Bitte lege jetzt ein eigenes fest.</p>' +
      '<form id="forcedPasswordForm">' +
      '<label class="field"><small>Neues Passwort</small><input type="password" name="password" autocomplete="new-password" required></label>' +
      '<label class="field"><small>Wiederholen</small><input type="password" name="repeat" autocomplete="new-password" required></label>' +
      '</form>',
    submitLabel: 'Passwort speichern',
    cancelLabel: 'Abmelden',
    onSubmit: function (ctx) {
      const form = ctx.body.querySelector('#forcedPasswordForm');
      const password = form.elements.password.value;
      if (!password || password !== form.elements.repeat.value) {
        ctx.setMessage('Die Passwörter stimmen nicht überein.', false);
        return;
      }
      ctx.setBusy(true);
      api('/api/users/changePassword.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newPassword: password })
      })
        .then(function () { window.location.reload(); })
        .catch(function (e) {
          ctx.setBusy(false);
          ctx.setMessage(e.message, false);
        });
    },
    onCancel: logout
  });
  modal.body.querySelector('#forcedPasswordForm').addEventListener('submit', function (event) {
    event.preventDefault();
    modal.submitButton.click();
  });
}

function logout() {
  api('/api/logout.php', { method: 'POST' }).then(function () {
    window.location.reload();
  });
}

export function applyRoleVisibility() {
  const admin = isAdmin();
  const hide = function (el) { if (el) el.hidden = !admin; };
  hide(dom.settingsButton);
  hide(dom.usersButton);
  hide(dom.reimportButton);
  hide(dom.pluginsManageButton);
  if (dom.restoreButton) {
    dom.restoreButton.hidden = !admin;
  }
  if (dom.backupSelect) {
    dom.backupSelect.hidden = !admin;
  }
  document.body.classList.toggle('role-editor', !admin);
  document.body.classList.toggle('role-admin', admin);
}

function savePage() {
  if (!state.currentPage) return;
  api('/api/savePage.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ page: state.currentPage, content: state.content })
  })
    .then(function () {
      setMessage(dom.editorMessage, 'Gespeichert.', true);
      const nowIso = new Date().toISOString();
      state.pageInfo = state.pageInfo.map(function (p) {
        if (pageKey(p) !== state.currentPage) return p;
        return Object.assign({}, p, { updatedAt: nowIso });
      });
      renderPages();
      loadBackups(state.currentPage);
    })
    .catch(function (error) {
      setMessage(dom.editorMessage, error.message, false);
    });
}

function runImport(force) {
  api('/api/import.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ force: !!force })
  })
    .then(function (data) {
      state.pages = data.pages || [];
      state.pageInfo = data.pages || [];
      dom.importNotice.classList.add('hidden');
      renderPages();
      if (state.pageInfo.length) {
        state.currentPage = '';
        navigate('page/' + pageKey(state.pageInfo[0]));
      }
      setMessage(dom.editorMessage, 'Import abgeschlossen.', true);
    })
    .catch(function (error) {
      setMessage(dom.editorMessage, error.message, false);
    });
}

setPreviewNavigate(function (page) {
  navigate('page/' + page);
});

onInlineSave(savePage);

onRestore(function () {
  setMessage(dom.editorMessage, 'Backup wiederhergestellt.', true);
  loadPage(state.currentPage);
});

dom.inlineEditorClose.addEventListener('click', closeInlineEditor);
dom.inlineEditorCancel.addEventListener('click', closeInlineEditor);
dom.inlineEditorSave.addEventListener('click', saveInlineEditor);
dom.inlineEditor.addEventListener('click', function (event) {
  if (event.target && event.target.hasAttribute('data-inline-close')) {
    closeInlineEditor();
  }
});

document.addEventListener('keydown', function (event) {
  if (event.key === 'Escape') {
    closeInlineEditor();
    clearPreviewOverlay();
  }
});

dom.loginForm.addEventListener('submit', function (event) {
  event.preventDefault();
  api('/api/login.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      username: dom.loginForm.elements.username.value,
      password: dom.loginForm.elements.password.value
    })
  })
    .then(showEditor)
    .catch(function (error) {
      setMessage(dom.loginMessage, error.message, false);
    });
});

dom.settingsButton.addEventListener('click', function () { navigate('settings'); });
if (dom.usersButton) {
  dom.usersButton.addEventListener('click', function () { navigate('users'); });
}
dom.dashboardButton.addEventListener('click', function () { navigate('dashboard'); });
dom.importButton.addEventListener('click', function () { runImport(false); });
dom.reimportButton.addEventListener('click', function () {
  const ok = window.confirm('Re-Import überschreibt manuelle Änderungen in den PHP-/HTML-Quellen. Snapshots werden vorher in /content/originals abgelegt. Fortfahren?');
  if (!ok) return;
  runImport(true);
});
dom.extensionsNavToggle.addEventListener('click', function () {
  dom.extensionsGroup.classList.toggle('open');
});
dom.pluginsManageButton.addEventListener('click', function () {
  navigate('plugins');
});
dom.advancedToggle.addEventListener('click', function () {
  setAdvancedMode(!state.advanced);
});
dom.pageSearch.addEventListener('input', applyPageFilter);
dom.logoutButton.addEventListener('click', logout);

const sidebarEl = document.querySelector('.sidebar');
const sidebarCollapseBtn = document.getElementById('sidebarCollapse');
if (sidebarCollapseBtn && sidebarEl) {
  sidebarCollapseBtn.addEventListener('click', function () {
    sidebarEl.classList.toggle('collapsed');
  });
}

const pagesGroup = document.getElementById('pagesGroup');
const pagesNavToggle = document.getElementById('pagesNavToggle');
if (pagesNavToggle && pagesGroup) {
  pagesNavToggle.addEventListener('click', function () {
    pagesGroup.classList.toggle('open');
  });
}

function renderPluginNav(plugins) {
  if (!dom.pluginsActiveList || !dom.pluginsEmptyHint) return;

  dom.pluginsActiveList.textContent = '';
  if (!plugins || plugins.length === 0) {
    dom.pluginsEmptyHint.classList.remove('hidden');
    return;
  }

  dom.pluginsEmptyHint.classList.add('hidden');
  plugins.forEach(function (plugin) {
    const route = plugin.route || plugin.name;
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'page-entry plugin-entry';
    button.dataset.plugin = plugin.name;
    button.dataset.route = route;

    const title = document.createElement('strong');
    title.textContent = plugin.label || plugin.name;
    const meta = document.createElement('span');
    meta.textContent = plugin.hasAdminModule ? 'Modul' : 'Schema';

    button.appendChild(title);
    button.appendChild(meta);
    button.addEventListener('click', function () {
      navigate('plugin/' + route);
    });
    dom.pluginsActiveList.appendChild(button);
  });
}

function showLogin() {
  dom.editorView.classList.add('hidden');
  dom.loginView.classList.remove('hidden');
}

function boot() {
  fetch('/api/bootstrap.php', { credentials: 'same-origin' })
    .then(function (res) { return res.json(); })
    .then(function (data) {
      if (data.authenticated) {
        state.csrfToken = data.csrfToken || '';
        showEditor(data);
        applyPageFilter();
      } else {
        showLogin();
      }
    })
    .catch(showLogin);
}

boot();
