import { state, dom, labelFor, flatten, updateContentPath, brToNewline, newlineToBr } from './core.js';
import { uploadImage } from './upload.js';

export function renderFields() {
  if (!dom.fieldsPanel || !dom.fieldsForm) return;
  if (dom.fieldsPanel.classList.contains('hidden')) {
    dom.fieldsForm.textContent = '';
    return;
  }

  dom.fieldsForm.textContent = '';
  if (dom.currentPageTitle) {
    dom.currentPageTitle.textContent = state.currentPage ? state.currentPage + '.json' : 'Felder';
  }

  flatten(state.content).forEach(function (row) {
    const searchText = state.fieldQuery;
    const rowLabel = labelFor(row.path).toLowerCase();
    if (searchText
      && row.path.toLowerCase().indexOf(searchText) === -1
      && rowLabel.indexOf(searchText) === -1
      && String(row.value).toLowerCase().indexOf(searchText) === -1) {
      return;
    }

    const label = document.createElement('label');
    label.className = 'field';
    const title = document.createElement('small');
    title.textContent = labelFor(row.path);
    title.title = row.path;
    label.appendChild(title);

    if (/image$/i.test(row.path)) {
      const wrap = document.createElement('div');
      wrap.className = 'image-row';
      const input = document.createElement('input');
      input.name = row.path;
      input.value = row.value;
      input.addEventListener('input', function () {
        updateContentPath(row.path, input.value);
      });
      const upload = document.createElement('input');
      upload.type = 'file';
      upload.accept = '.jpg,.jpeg,.png,.webp,.svg,image/*';
      upload.addEventListener('change', function () {
        uploadImage(upload.files[0], input).then(function (url) {
          if (url) updateContentPath(row.path, url);
        }).catch(function () {});
      });
      wrap.appendChild(input);
      wrap.appendChild(upload);
      label.appendChild(wrap);
    } else if (/\.url$/i.test(row.path)) {
      const urlInput = document.createElement('input');
      urlInput.type = 'url';
      urlInput.name = row.path;
      urlInput.value = row.value;
      urlInput.addEventListener('input', function () {
        updateContentPath(row.path, urlInput.value);
      });
      label.appendChild(urlInput);
    } else {
      const textarea = document.createElement('textarea');
      textarea.name = row.path;
      textarea.value = brToNewline(row.value);
      textarea.addEventListener('input', function () {
        updateContentPath(row.path, newlineToBr(textarea.value));
      });
      label.appendChild(textarea);
    }

    dom.fieldsForm.appendChild(label);
  });
}

export function applyFieldFilter() {
  state.fieldQuery = (dom.fieldSearch && dom.fieldSearch.value || '').trim().toLowerCase();
  renderFields();
}
