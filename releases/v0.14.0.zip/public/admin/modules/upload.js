import { dom, api, setMessage } from './core.js';
import { schedulePreviewSync } from './preview.js';

export function uploadImage(file, targetInput) {
  return new Promise(function (resolve, reject) {
    if (!file) { resolve(null); return; }
    const formData = new FormData();
    formData.append('file', file);
    api('/api/upload.php', { method: 'POST', body: formData })
      .then(function (data) {
        if (targetInput) targetInput.value = data.url;
        schedulePreviewSync(true);
        setMessage(dom.editorMessage, 'Bild hochgeladen.', true);
        resolve(data.url);
      })
      .catch(function (error) {
        setMessage(dom.editorMessage, error.message, false);
        reject(error);
      });
  });
}
