import { state, dom, api, setMessage } from './core.js';

export function relativeTime(date) {
  const diff = (Date.now() - date.getTime()) / 1000;
  if (diff < 60) return 'gerade eben';
  if (diff < 3600) return 'vor ' + Math.floor(diff / 60) + ' Min';
  if (diff < 86400) return 'vor ' + Math.floor(diff / 3600) + ' Std';
  if (diff < 86400 * 30) return 'vor ' + Math.floor(diff / 86400) + ' Tagen';
  if (diff < 86400 * 365) return 'vor ' + Math.floor(diff / (86400 * 30)) + ' Mon';
  return 'vor ' + Math.floor(diff / (86400 * 365)) + ' J';
}

export function backupLabel(filename) {
  const m = /^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})\.json$/.exec(filename);
  if (!m) return filename;
  const date = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]));
  if (isNaN(date.getTime())) return filename;
  const absolute = date.toLocaleString(undefined, {
    weekday: 'short', year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit'
  });
  return absolute + ' (' + relativeTime(date) + ')';
}

export function renderBackups(backups) {
  if (!dom.backupSelect || !dom.restoreButton) return;
  dom.backupSelect.textContent = '';
  const empty = document.createElement('option');
  empty.value = '';
  empty.textContent = backups.length ? 'Backup wählen ...' : 'Keine Backups';
  dom.backupSelect.appendChild(empty);

  backups.forEach(function (backup) {
    const option = document.createElement('option');
    option.value = backup;
    option.textContent = backupLabel(backup);
    dom.backupSelect.appendChild(option);
  });

  dom.backupSelect.disabled = !backups.length || !state.currentPage;
  dom.restoreButton.disabled = !backups.length || !state.currentPage;
}

export function loadBackups(page) {
  if (!page) return;
  api('/api/listBackups.php?page=' + encodeURIComponent(page))
    .then(function (data) { renderBackups(data.backups || []); })
    .catch(function () { renderBackups([]); });
}

let restoreHandler = null;
export function onRestore(cb) { restoreHandler = cb; }

export function restoreBackup() {
  if (!state.currentPage || !dom.backupSelect || !dom.backupSelect.value) return;
  api('/api/restore.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ page: state.currentPage, backup: dom.backupSelect.value })
  })
    .then(function () {
      if (restoreHandler) restoreHandler();
    })
    .catch(function (error) {
      setMessage(dom.editorMessage, error.message, false);
    });
}
