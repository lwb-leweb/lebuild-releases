import { dom, labelFor, getContentPath, updateContentPath, brToNewline, newlineToBr } from './core.js';
import { clearPreviewOverlay, getActivePreviewTarget } from './preview.js';
import { uploadImage } from './upload.js';

const inlineEditorState = {
  path: '',
  type: '',
  target: null,
  input: null,
  fileInput: null,
  originalValues: {}
};

let saveHandler = null;
export function onSave(cb) { saveHandler = cb; }

export function openInlineEditor(path, type, textPath) {
  clearPreviewOverlay();
  inlineEditorState.path = path;
  inlineEditorState.type = type;
  inlineEditorState.target = null;
  inlineEditorState.input = null;
  inlineEditorState.fileInput = null;
  dom.inlineEditorBody.textContent = '';

  const currentValue = getContentPath(path) || '';
  const currentTextPath = textPath || (type === 'link' ? path.replace(/\.url$/, '.text') : '');
  let currentTextValue = currentTextPath ? (getContentPath(currentTextPath) || '') : '';

  inlineEditorState.originalValues = {};
  inlineEditorState.originalValues[path] = currentValue;
  if (currentTextPath) inlineEditorState.originalValues[currentTextPath] = currentTextValue;
  const activeTarget = getActivePreviewTarget();
  if (type === 'link' && !currentTextValue && activeTarget) {
    currentTextValue = activeTarget.textContent || '';
  }
  dom.inlineEditorTitle.textContent = labelFor(path);

  if (type === 'image') {
    const imagePreview = document.createElement('img');
    imagePreview.src = currentValue;
    imagePreview.alt = '';
    dom.inlineEditorBody.appendChild(imagePreview);

    const urlLabel = document.createElement('label');
    urlLabel.textContent = 'Bild-URL';
    const input = document.createElement('input');
    input.type = 'url';
    input.value = currentValue;
    input.addEventListener('input', function () {
      updateContentPath(path, input.value);
      imagePreview.src = input.value;
    });
    urlLabel.appendChild(input);
    dom.inlineEditorBody.appendChild(urlLabel);

    const fileLabel = document.createElement('label');
    fileLabel.textContent = 'Datei hochladen';
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.jpg,.jpeg,.png,.webp,.svg,image/*';
    fileInput.addEventListener('change', function () {
      if (fileInput.files && fileInput.files[0]) {
        uploadImage(fileInput.files[0], input).then(function (url) {
          if (!url) return;
          updateContentPath(path, url);
          imagePreview.src = url;
        }).catch(function () {});
      }
    });
    fileLabel.appendChild(fileInput);
    dom.inlineEditorBody.appendChild(fileLabel);

    inlineEditorState.input = input;
    inlineEditorState.fileInput = fileInput;
  } else if (type === 'link') {
    const linkUrlLabel = document.createElement('label');
    linkUrlLabel.textContent = 'Link-Ziel';
    const linkInput = document.createElement('input');
    linkInput.type = 'url';
    linkInput.value = currentValue;
    linkInput.addEventListener('input', function () {
      updateContentPath(path, linkInput.value);
    });
    linkUrlLabel.appendChild(linkInput);
    dom.inlineEditorBody.appendChild(linkUrlLabel);

    const linkTextLabel = document.createElement('label');
    linkTextLabel.textContent = 'Link-Text';
    const linkTextInput = document.createElement('input');
    linkTextInput.type = 'text';
    linkTextInput.value = currentTextValue;
    linkTextInput.addEventListener('input', function () {
      if (currentTextPath) {
        updateContentPath(currentTextPath, linkTextInput.value);
      }
    });
    linkTextLabel.appendChild(linkTextInput);
    dom.inlineEditorBody.appendChild(linkTextLabel);
    inlineEditorState.input = linkInput;
  } else {
    const textLabel = document.createElement('label');
    textLabel.textContent = 'Text';
    const textarea = document.createElement('textarea');
    textarea.value = brToNewline(currentValue);
    textarea.addEventListener('input', function () {
      updateContentPath(path, newlineToBr(textarea.value));
    });
    textLabel.appendChild(textarea);
    dom.inlineEditorBody.appendChild(textLabel);
    inlineEditorState.input = textarea;
  }

  dom.inlineEditor.classList.remove('hidden');
  dom.inlineEditor.setAttribute('aria-hidden', 'false');
  setTimeout(function () {
    if (inlineEditorState.input && inlineEditorState.input.focus) {
      inlineEditorState.input.focus();
    }
  }, 0);
}

export function closeInlineEditor() {
  Object.keys(inlineEditorState.originalValues).forEach(function (p) {
    updateContentPath(p, inlineEditorState.originalValues[p]);
  });
  inlineEditorState.originalValues = {};
  dom.inlineEditor.classList.add('hidden');
  dom.inlineEditor.setAttribute('aria-hidden', 'true');
  dom.inlineEditorBody.textContent = '';
  inlineEditorState.path = '';
  inlineEditorState.type = '';
  inlineEditorState.input = null;
  inlineEditorState.fileInput = null;
}

export function saveInlineEditor() {
  if (!inlineEditorState.path) return;
  inlineEditorState.originalValues = {};
  if (saveHandler) saveHandler();
  closeInlineEditor();
}
