import { state, api, setMessage } from '../core.js';
import { openModal, closeModal } from '../ui-modal.js';

const TEMPLATE = `
  <section class="view-area">
    <div class="card-grid">
      <div class="view-card span-12">
        <div class="topbar">
          <strong>Benutzer</strong>
          <p id="usersMessage" class="message"></p>
          <button id="usersOwnPasswordBtn" type="button" class="secondary">Eigenes Passwort ändern</button>
          <button id="usersCreateBtn" type="button">Neuer Benutzer</button>
        </div>
        <div class="users-table-wrap">
          <table class="users-table">
            <thead>
              <tr>
                <th>Benutzername</th>
                <th>Rolle</th>
                <th>Erstellt</th>
                <th>Aktionen</th>
              </tr>
            </thead>
            <tbody id="usersTbody">
              <tr><td colspan="4" class="message">Lade…</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </section>
`;

const DIALOG_FORM_HTML = `
  <form id="userDialogForm" class="settings-form">
    <label class="field" data-field="username"><small>Benutzername</small><input name="username" type="text" autocomplete="off"></label>
    <label class="field" data-field="role"><small>Rolle</small>
      <select name="role">
        <option value="editor">Editor</option>
        <option value="admin">Administrator</option>
      </select>
    </label>
    <label class="field" data-field="currentPassword"><small>Aktuelles Passwort</small><input name="currentPassword" type="password" autocomplete="current-password"></label>
    <label class="field" data-field="password"><small>Passwort</small><input name="password" type="password" autocomplete="new-password"></label>
  </form>
`;

let users = [];
let outletRef = null;

const FIELD_VISIBILITY = {
  create: ['username', 'role', 'password'],
  edit: ['username', 'role'],
  reset: ['password'],
  ownPassword: ['currentPassword', 'password']
};

const DIALOG_TITLES = {
  create: 'Neuer Benutzer',
  edit: 'Benutzer bearbeiten',
  reset: 'Passwort zurücksetzen',
  ownPassword: 'Eigenes Passwort ändern'
};

export function mount(outlet) {
  outletRef = outlet;
  outlet.innerHTML = TEMPLATE;

  outlet.querySelector('#usersCreateBtn').addEventListener('click', function () {
    openDialog('create');
  });
  outlet.querySelector('#usersOwnPasswordBtn').addEventListener('click', function () {
    openDialog('ownPassword');
  });

  loadUsers();
}

export function unmount() {
  closeModal();
  outletRef = null;
}

function loadUsers() {
  api('/api/users/list.php')
    .then(function (data) {
      users = data.users || [];
      renderTable();
    })
    .catch(function (error) {
      const tbody = document.getElementById('usersTbody');
      if (tbody) {
        tbody.innerHTML = '<tr><td colspan="4" class="message">' + escapeHtml(error.message) + '</td></tr>';
      }
    });
}

function renderTable() {
  const tbody = document.getElementById('usersTbody');
  if (!tbody) return;
  tbody.innerHTML = '';
  if (!users.length) {
    const tr = document.createElement('tr');
    tr.innerHTML = '<td colspan="4" class="message">Keine Benutzer vorhanden.</td>';
    tbody.appendChild(tr);
    return;
  }

  const adminCount = users.filter(function (u) { return u.role === 'admin'; }).length;

  users.forEach(function (user) {
    const tr = document.createElement('tr');

    const nameCell = document.createElement('td');
    nameCell.textContent = user.username;
    if (state.username && user.username === state.username) {
      const tag = document.createElement('span');
      tag.className = 'users-table__self';
      tag.textContent = ' (Du)';
      nameCell.appendChild(tag);
    }
    tr.appendChild(nameCell);

    const roleCell = document.createElement('td');
    roleCell.textContent = user.role === 'admin' ? 'Administrator' : 'Editor';
    tr.appendChild(roleCell);

    const dateCell = document.createElement('td');
    dateCell.textContent = formatDate(user.createdAt);
    tr.appendChild(dateCell);

    const actionsCell = document.createElement('td');
    actionsCell.className = 'users-table__actions';

    const editBtn = document.createElement('button');
    editBtn.type = 'button';
    editBtn.className = 'secondary';
    editBtn.textContent = 'Bearbeiten';
    editBtn.addEventListener('click', function () { openDialog('edit', user.id); });
    actionsCell.appendChild(editBtn);

    const resetBtn = document.createElement('button');
    resetBtn.type = 'button';
    resetBtn.className = 'secondary';
    resetBtn.textContent = 'Passwort setzen';
    resetBtn.addEventListener('click', function () { openDialog('reset', user.id); });
    actionsCell.appendChild(resetBtn);

    const deleteBtn = document.createElement('button');
    deleteBtn.type = 'button';
    deleteBtn.className = 'secondary danger';
    deleteBtn.textContent = 'Löschen';
    const isSelf = state.username && user.username === state.username;
    const isLastAdmin = user.role === 'admin' && adminCount <= 1;
    if (isSelf || isLastAdmin) {
      deleteBtn.disabled = true;
      deleteBtn.title = isSelf ? 'Eigenen Account kannst Du nicht löschen' : 'Letzten Admin kannst Du nicht löschen';
    }
    deleteBtn.addEventListener('click', function () { deleteUser(user); });
    actionsCell.appendChild(deleteBtn);

    tr.appendChild(actionsCell);
    tbody.appendChild(tr);
  });
}

function openDialog(mode, userId) {
  const targetId = userId || null;
  const modal = openModal({
    title: DIALOG_TITLES[mode] || 'Benutzer',
    bodyHtml: DIALOG_FORM_HTML,
    onSubmit: function (ctx) {
      submitDialog(mode, targetId, ctx);
    }
  });

  const form = modal.body.querySelector('#userDialogForm');
  const visible = new Set(FIELD_VISIBILITY[mode] || []);
  form.querySelectorAll('.field').forEach(function (field) {
    const key = field.dataset.field;
    field.hidden = !visible.has(key);
    const input = field.querySelector('input, select');
    if (input) input.disabled = !visible.has(key);
  });

  if (mode === 'edit' && targetId) {
    const user = users.find(function (u) { return u.id === targetId; });
    if (user) {
      form.elements.username.value = user.username;
      form.elements.role.value = user.role;
    }
  }

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    modal.submitButton.click();
  });
}

function submitDialog(mode, targetId, ctx) {
  const form = ctx.body.querySelector('#userDialogForm');
  if (!form) return;

  const username = form.elements.username ? form.elements.username.value.trim() : '';
  const role = form.elements.role ? form.elements.role.value : 'editor';
  const password = form.elements.password ? form.elements.password.value : '';
  const currentPassword = form.elements.currentPassword ? form.elements.currentPassword.value : '';

  function fail(message) {
    ctx.setBusy(false);
    ctx.setMessage(message, false);
  }
  function done(message) {
    ctx.close('submit');
    setUsersMessage(message, true);
  }

  if (mode === 'create') {
    if (!username || !password) {
      fail('Benutzername und Passwort sind nötig.');
      return;
    }
    ctx.setBusy(true);
    api('/api/users/create.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: username, password: password, role: role })
    })
      .then(function () { done('Benutzer angelegt.'); loadUsers(); })
      .catch(function (e) { fail(e.message); });
    return;
  }

  if (mode === 'edit' && targetId) {
    ctx.setBusy(true);
    api('/api/users/update.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: targetId, username: username, role: role })
    })
      .then(function () { done('Benutzer aktualisiert.'); loadUsers(); })
      .catch(function (e) { fail(e.message); });
    return;
  }

  if (mode === 'reset' && targetId) {
    if (!password) {
      fail('Neues Passwort eingeben.');
      return;
    }
    ctx.setBusy(true);
    api('/api/users/changePassword.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: targetId, newPassword: password })
    })
      .then(function () { done('Passwort gesetzt.'); })
      .catch(function (e) { fail(e.message); });
    return;
  }

  if (mode === 'ownPassword') {
    if (!currentPassword || !password) {
      fail('Aktuelles und neues Passwort eingeben.');
      return;
    }
    ctx.setBusy(true);
    api('/api/users/changePassword.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ currentPassword: currentPassword, newPassword: password })
    })
      .then(function () { done('Passwort geändert.'); })
      .catch(function (e) { fail(e.message); });
  }
}

function deleteUser(user) {
  if (!window.confirm('Benutzer "' + user.username + '" wirklich löschen?')) return;
  api('/api/users/delete.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ id: user.id })
  })
    .then(function () {
      setUsersMessage('Benutzer gelöscht.', true);
      loadUsers();
    })
    .catch(function (e) { setUsersMessage(e.message, false); });
}

function setUsersMessage(text, ok) {
  setMessage(document.getElementById('usersMessage'), text, ok);
}

function formatDate(iso) {
  if (!iso) return '–';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleDateString('de-DE');
}

function escapeHtml(value) {
  return String(value || '').replace(/[&<>"']/g, function (char) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
  });
}
