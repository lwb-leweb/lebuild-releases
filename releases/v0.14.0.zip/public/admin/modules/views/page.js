import { state, dom, updateDom, onAdvancedChange } from '../core.js';
import { loadPage } from '../pages.js';
import { onIframeLoad } from '../preview.js';
import { renderFields, applyFieldFilter } from '../fields.js';
import { restoreBackup } from '../backups.js';

const TEMPLATE = `
  <div class="page-view">
    <section class="preview view-area">
      <div class="card-grid">
        <iframe id="previewFrame" class="span-12" title="Live Preview"></iframe>
      </div>
    </section>

    <aside id="fieldsPanel" class="fields hidden">
      <div class="topbar">
        <strong id="currentPageTitle">Felder</strong>
      </div>
      <input id="fieldSearch" class="search" type="search" placeholder="Felder filtern">
      <div class="backup-row">
        <select id="backupSelect" disabled>
          <option value="">Backups laden ...</option>
        </select>
        <button id="restoreButton" type="button" class="secondary" disabled>Restore</button>
      </div>
      <form id="fieldsForm"></form>
      <p id="editorMessage" class="message"></p>
    </aside>
  </div>
`;

export function mount(outlet, pageKey) {
  outlet.innerHTML = TEMPLATE;

  const root = outlet.querySelector('.page-view');
  updateDom({
    pageView: root,
    previewFrame: root.querySelector('#previewFrame'),
    fieldsPanel: root.querySelector('#fieldsPanel'),
    fieldsForm: root.querySelector('#fieldsForm'),
    fieldSearch: root.querySelector('#fieldSearch'),
    currentPageTitle: root.querySelector('#currentPageTitle'),
    editorMessage: root.querySelector('#editorMessage'),
    backupSelect: root.querySelector('#backupSelect'),
    restoreButton: root.querySelector('#restoreButton')
  });

  dom.previewFrame.addEventListener('load', onIframeLoad);
  dom.restoreButton.addEventListener('click', restoreBackup);
  dom.fieldSearch.addEventListener('input', applyFieldFilter);

  applyAdvanced(state.advanced);

  if (pageKey) {
    loadPage(pageKey);
  } else if (state.currentPage) {
    loadPage(state.currentPage);
  }
}

export function update(pageKey) {
  if (pageKey && pageKey !== state.currentPage) {
    loadPage(pageKey);
  }
}

export function unmount() {
}

function applyAdvanced(open) {
  if (!dom.pageView || !dom.fieldsPanel) return;
  dom.pageView.classList.toggle('advanced', open);
  dom.fieldsPanel.classList.toggle('hidden', !open);
  if (open) renderFields();
}

onAdvancedChange(applyAdvanced);
