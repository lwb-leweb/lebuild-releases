import { api, setMessage } from '../core.js';
import { openModal, closeModal } from '../ui-modal.js';

let pluginName = null;
let outletEl = null;
let currentSchema = [];

const genericPluginView = {
  id: '__generic__',
  mount(outlet, ctx) {
    pluginName = ctx.pluginName;
    outletEl = outlet;
    renderShell();
    loadList();
  },
  unmount() {
    closeModal();
    pluginName = null;
    outletEl = null;
    currentSchema = [];
  }
};

export default genericPluginView;

function renderShell() {
  outletEl.innerHTML = `
    <section class="view-area generic-plugin-view">
      <div class="view-card span-12">
        <div class="topbar">
          <strong>${escapeHtml(pluginName)}</strong>
          <button type="button" id="newItemBtn">Neu</button>
        </div>
        <p id="genericMsg" class="message"></p>
        <div id="genericList" class="generic-list"></div>
      </div>
    </section>
  `;
  outletEl.querySelector('#newItemBtn').addEventListener('click', function () {
    openForm(null, currentSchema);
  });
}

function loadList() {
  api('/api/plugins/generic/list.php?plugin=' + encodeURIComponent(pluginName))
    .then(function (data) {
      currentSchema = data.schema || [];
      renderList(data.rows || [], currentSchema);
    })
    .catch(showError);
}

function renderList(rows, schema) {
  const list = document.getElementById('genericList');
  if (!list) return;

  if (!rows.length) {
    list.innerHTML = '<p class="message">Noch keine Einträge.</p>';
    return;
  }

  const titleField = pickTitleField(schema);
  list.innerHTML = '<ul>' + rows.map(function (row) {
    const title = titleField ? (row[titleField] || '(ohne Titel)') : ('#' + row.id);
    return `
      <li class="generic-list__row" data-id="${row.id}">
        <span class="generic-list__title">${escapeHtml(title)}</span>
        <div class="generic-list__actions">
          <button type="button" data-action="edit" data-id="${row.id}">Bearbeiten</button>
          <button type="button" data-action="delete" data-id="${row.id}" class="secondary">Löschen</button>
        </div>
      </li>
    `;
  }).join('') + '</ul>';

  list.querySelectorAll('button[data-action="edit"]').forEach(function (button) {
    button.addEventListener('click', function () {
      openFormFromServer(parseInt(button.dataset.id, 10));
    });
  });
  list.querySelectorAll('button[data-action="delete"]').forEach(function (button) {
    button.addEventListener('click', function () {
      const id = parseInt(button.dataset.id, 10);
      if (!window.confirm('Eintrag löschen?')) return;
      api('/api/plugins/generic/delete.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plugin: pluginName, id: id })
      }).then(loadList).catch(showError);
    });
  });
}

function pickTitleField(schema) {
  const named = schema.find(function (field) {
    return field.name === 'title' || field.name === 'name';
  });
  if (named) return named.name;

  const text = schema.find(function (field) { return field.type === 'text'; });
  return text ? text.name : null;
}

function openFormFromServer(id) {
  api('/api/plugins/generic/get.php?plugin=' + encodeURIComponent(pluginName) + '&id=' + id)
    .then(function (data) {
      currentSchema = data.schema || currentSchema;
      openForm(data.row || null, currentSchema);
    })
    .catch(showError);
}

function openForm(row, schema) {
  const bodyHtml = `
    <form id="genericFormEl" class="settings-form">
      ${schema.map(function (field) { return fieldInput(field, row); }).join('')}
    </form>
  `;

  const modal = openModal({
    title: row ? 'Bearbeiten' : 'Neu',
    bodyHtml: bodyHtml,
    onSubmit: function (ctx) {
      const formEl = ctx.body.querySelector('#genericFormEl');
      const data = {};
      schema.forEach(function (field) {
        const input = formEl.querySelector('[name="' + field.name + '"]');
        if (!input) return;
        data[field.name] = field.type === 'boolean' ? (input.checked ? '1' : '0') : input.value;
      });

      const body = { plugin: pluginName, data: data };
      if (row && row.id) body.id = row.id;

      ctx.setBusy(true);
      api('/api/plugins/generic/save.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      }).then(function () {
        ctx.close('submit');
        loadList();
      }).catch(function (error) {
        ctx.setBusy(false);
        ctx.setMessage(error.message || String(error), false);
      });
    }
  });

  const formEl = modal.body.querySelector('#genericFormEl');
  formEl.addEventListener('submit', function (event) {
    event.preventDefault();
    modal.submitButton.click();
  });
}

function fieldInput(field, row) {
  const value = row && row[field.name] != null ? row[field.name] : '';
  const label = escapeHtml(field.label || field.name);
  const required = field.required ? ' required' : '';
  const escaped = escapeAttr(formatInputValue(field, value));

  if (field.type === 'richtext') {
    return `<label class="field"><small>${label}</small><textarea name="${escapeAttr(field.name)}" rows="7"${required}>${escapeHtml(value)}</textarea></label>`;
  }
  if (field.type === 'datetime') {
    return `<label class="field"><small>${label}</small><input type="datetime-local" name="${escapeAttr(field.name)}" value="${escaped}"${required}></label>`;
  }
  if (field.type === 'number') {
    return `<label class="field"><small>${label}</small><input type="number" name="${escapeAttr(field.name)}" value="${escaped}"${required}></label>`;
  }
  if (field.type === 'boolean') {
    return `<label class="field field--checkbox"><span><input type="checkbox" name="${escapeAttr(field.name)}" ${value && value !== '0' ? 'checked' : ''}> ${label}</span></label>`;
  }
  if (field.type === 'image') {
    return `<label class="field"><small>${label}</small><input type="text" name="${escapeAttr(field.name)}" value="${escaped}" placeholder="/public/uploads/..."></label>`;
  }

  return `<label class="field"><small>${label}</small><input type="text" name="${escapeAttr(field.name)}" value="${escaped}"${required}></label>`;
}

function formatInputValue(field, value) {
  if (field.type === 'datetime' && value) {
    return String(value).replace(' ', 'T').slice(0, 16);
  }
  return value == null ? '' : String(value);
}

function showError(error) {
  const msg = document.getElementById('genericMsg');
  if (msg) setMessage(msg, error.message || String(error), false);
}

function escapeHtml(value) {
  return String(value || '').replace(/[&<>"']/g, function (char) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
  });
}

function escapeAttr(value) {
  return escapeHtml(value);
}
