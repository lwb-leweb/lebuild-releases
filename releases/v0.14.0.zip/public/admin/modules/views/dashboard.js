import { state, dom, updateDom } from '../core.js';
import { onUpdateStatusChange } from '../update.js';

const TEMPLATE = `
  <section class="view-area">
    <div class="card-grid">
      <div class="view-card span-8">
        <h2 class="view-title">Dashboard</h2>
        <p class="view-lead">Willkommen im Live Editor. Wähle links eine Seite oder die Einstellungen.</p>
      </div>
      <div class="view-card span-4">
        <h3 class="view-title">System</h3>
        <div id="dashboardUpdate" class="update-card"></div>
      </div>
    </div>
  </section>
`;

let unsubscribe = null;

export function mount(outlet) {
  outlet.innerHTML = TEMPLATE;
  updateDom({ dashboardPanel: outlet.querySelector('.view-area') });
  renderUpdateBlock();
  if (!unsubscribe) {
    onUpdateStatusChange(renderUpdateBlock);
    unsubscribe = true;
  }
}

export function unmount() {
}

function formatDate(iso) {
  if (!iso) return '–';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleString('de-DE');
}

function renderUpdateBlock() {
  const el = document.getElementById('dashboardUpdate');
  if (!el) return;
  const status = state.updateStatus;
  el.innerHTML = '';

  if (!status) {
    el.appendChild(rowEl('Version', '–'));
    return;
  }

  el.appendChild(rowEl('Version', status.currentVersion || '–'));
  el.appendChild(rowEl('Aktualisierungen', status.enabled ? 'aktiviert' : 'deaktiviert'));
  el.appendChild(rowEl('Letzte Prüfung', formatDate(status.lastCheck)));

  if (status.hasUpdate) {
    const pill = document.createElement('div');
    pill.className = 'update-card__notes';
    pill.textContent = 'Neue Version verfügbar: ' + status.latestVersion +
      (status.requiresConfirmation ? ' — Bestätigung nötig (siehe Banner)'
        : status.skippedVersion === status.latestVersion ? ' — nach Rollback ausgesetzt, manuell in den Einstellungen installierbar'
        : ' — wird beim nächsten Login installiert');
    el.appendChild(pill);
  } else if (status.lastError) {
    const note = document.createElement('div');
    note.className = 'update-card__notes';
    note.textContent = status.lastError;
    el.appendChild(note);
  } else {
    const ok = document.createElement('div');
    ok.className = 'update-card__notes';
    ok.textContent = 'Auf dem neuesten Stand.';
    el.appendChild(ok);
  }
}

function rowEl(label, value) {
  const row = document.createElement('div');
  row.className = 'update-card__row';
  const a = document.createElement('small');
  a.textContent = label;
  const b = document.createElement('span');
  b.textContent = value;
  row.appendChild(a);
  row.appendChild(b);
  return row;
}
