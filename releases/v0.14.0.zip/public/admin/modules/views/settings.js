import { state, dom, api, setMessage, updateDom } from '../core.js';
import { forceRemoteCheck, rollback, onUpdateStatusChange } from '../update.js';

const SETTINGS_KEYS = ['name', 'tagline', 'url', 'email', 'owner', 'locale'];

const TEMPLATE = `
  <section class="view-area">
    <div class="card-grid">
      <div class="view-card span-6">
        <div class="topbar">
          <strong>Einstellungen</strong>
          <p id="settingsMessage" class="message"></p>
          <button id="settingsSaveButton" type="button">Speichern</button>
        </div>
        <form id="settingsForm" class="settings-form">
          <label class="field"><small>Name</small><input name="name" type="text"></label>
          <label class="field"><small>Tagline</small><input name="tagline" type="text"></label>
          <label class="field"><small>Website-URL</small><input name="url" type="url"></label>
          <label class="field"><small>E-Mail</small><input name="email" type="email"></label>
          <label class="field"><small>Inhaber</small><input name="owner" type="text"></label>
          <label class="field"><small>Locale</small><input name="locale" type="text"></label>
        </form>
      </div>
      <div class="view-card span-6">
        <div class="topbar">
          <strong>Updates</strong>
          <p id="updateMessage" class="message"></p>
        </div>
        <div id="updateSection" class="update-card"></div>
      </div>
      <div class="view-card span-12">
        <div class="topbar">
          <strong>E-Mail / SMTP</strong>
          <p id="mailSettingsMessage" class="message"></p>
        </div>
        <form id="mailSettingsForm" class="settings-form">
          <label class="field"><small>Host</small><input name="host" type="text" autocomplete="off"></label>
          <label class="field"><small>Port</small><input name="port" type="number" min="1" max="65535" value="587"></label>
          <label class="field"><small>Verschlüsselung</small>
            <select name="encryption">
              <option value="tls">STARTTLS</option>
              <option value="ssl">SSL/TLS</option>
              <option value="none">Keine</option>
            </select>
          </label>
          <label class="field"><small>Benutzer</small><input name="username" type="text" autocomplete="username"></label>
          <label class="field"><small>Passwort</small><input name="password" type="password" autocomplete="new-password" placeholder="Leer lassen: bestehendes Passwort behalten"></label>
          <label class="field"><small>Absender-E-Mail</small><input name="fromEmail" type="email"></label>
          <label class="field"><small>Absender-Name</small><input name="fromName" type="text"></label>
          <label class="field"><small>Standard-Empfänger</small><input name="defaultRecipient" type="email"></label>
          <label class="field"><small>Test-Empfänger</small><input name="testRecipient" type="email"></label>
        </form>
        <p id="mailSettingsStatus" class="mail-status"></p>
        <div class="form-actions">
          <button id="mailSettingsSaveButton" type="button">SMTP speichern</button>
          <button id="mailSettingsTestButton" type="button" class="secondary">Test senden</button>
          <button id="mailSettingsDeleteButton" type="button" class="secondary">SMTP deaktivieren</button>
        </div>
      </div>
    </div>
  </section>
`;

let unsubscribed = false;

export function mount(outlet) {
  outlet.innerHTML = TEMPLATE;
  updateDom({
    settingsPanel: outlet.querySelector('.view-card'),
    settingsForm: outlet.querySelector('#settingsForm'),
    settingsSaveButton: outlet.querySelector('#settingsSaveButton'),
    settingsMessage: outlet.querySelector('#settingsMessage')
  });
  dom.settingsSaveButton.addEventListener('click', saveConfig);
  outlet.querySelector('#mailSettingsSaveButton').addEventListener('click', saveMailConfig);
  outlet.querySelector('#mailSettingsTestButton').addEventListener('click', sendTestMail);
  outlet.querySelector('#mailSettingsDeleteButton').addEventListener('click', deleteMailConfig);
  loadConfig();
  loadMailConfig();
  renderUpdates();
  if (!unsubscribed) {
    onUpdateStatusChange(renderUpdates);
    unsubscribed = true;
  }
}

export function unmount() {
}

function loadConfig() {
  api('/api/getConfig.php')
    .then(function (data) {
      const cfg = data.config || {};
      SETTINGS_KEYS.forEach(function (key) {
        const input = dom.settingsForm.elements[key];
        if (input) input.value = cfg[key] || '';
      });
      setMessage(dom.settingsMessage, '', true);
    })
    .catch(function (error) {
      setMessage(dom.settingsMessage, error.message, false);
    });
}

function saveConfig() {
  const cfg = {};
  SETTINGS_KEYS.forEach(function (key) {
    const input = dom.settingsForm.elements[key];
    if (input) cfg[key] = input.value;
  });
  api('/api/saveConfig.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(cfg)
  })
    .then(function () {
      setMessage(dom.settingsMessage, 'Gespeichert.', true);
    })
    .catch(function (error) {
      setMessage(dom.settingsMessage, error.message, false);
    });
}

function loadMailConfig() {
  api('/api/getMailConfig.php')
    .then(function (data) {
      fillMailForm(data.config || {});
      renderMailStatus(data.status || {}, data.config || {});
      setMailMessage('', true);
    })
    .catch(function (error) {
      setMailMessage(error.message, false);
    });
}

function fillMailForm(cfg) {
  const form = document.getElementById('mailSettingsForm');
  if (!form) return;
  form.elements.host.value = cfg.host || '';
  form.elements.port.value = cfg.port || 587;
  form.elements.encryption.value = cfg.encryption || 'tls';
  form.elements.username.value = cfg.username || '';
  form.elements.password.value = '';
  form.elements.fromEmail.value = cfg.fromEmail || '';
  form.elements.fromName.value = cfg.fromName || '';
  form.elements.defaultRecipient.value = cfg.defaultRecipient || '';
  form.elements.testRecipient.value = cfg.defaultRecipient || cfg.resolvedRecipient || '';
  form.elements.password.placeholder = cfg.passwordSet
    ? 'Gespeichertes Passwort behalten'
    : 'SMTP-Passwort';
}

function mailPayload() {
  const form = document.getElementById('mailSettingsForm');
  const fields = form.elements;
  return {
    host: fields.host.value,
    port: parseInt(fields.port.value, 10) || 587,
    encryption: fields.encryption.value,
    username: fields.username.value,
    password: fields.password.value,
    fromEmail: fields.fromEmail.value,
    fromName: fields.fromName.value,
    defaultRecipient: fields.defaultRecipient.value
  };
}

function saveMailConfig() {
  const button = document.getElementById('mailSettingsSaveButton');
  if (button) button.disabled = true;
  api('/api/saveMailConfig.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(mailPayload())
  })
    .then(function (data) {
      fillMailForm(data.config || {});
      renderMailStatus(data.status || {}, data.config || {});
      setMailMessage('SMTP gespeichert.', true);
    })
    .catch(function (error) {
      setMailMessage(error.message, false);
    })
    .finally(function () {
      if (button) button.disabled = false;
    });
}

function deleteMailConfig() {
  if (!window.confirm('SMTP-Einstellungen löschen und auf PHP mail() zurückfallen?')) return;
  const button = document.getElementById('mailSettingsDeleteButton');
  if (button) button.disabled = true;
  api('/api/deleteMailConfig.php', { method: 'POST' })
    .then(function (data) {
      fillMailForm(data.config || {});
      renderMailStatus(data.status || {}, data.config || {});
      setMailMessage('SMTP deaktiviert.', true);
    })
    .catch(function (error) {
      setMailMessage(error.message, false);
    })
    .finally(function () {
      if (button) button.disabled = false;
    });
}

function sendTestMail() {
  const form = document.getElementById('mailSettingsForm');
  const button = document.getElementById('mailSettingsTestButton');
  const payload = mailPayload();
  const testRecipient = form.elements.testRecipient.value;
  const shouldSave = !!(payload.host || payload.username || payload.password || payload.fromEmail || payload.fromName || payload.defaultRecipient);
  const send = function () {
    return api('/api/testMailConfig.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ to: testRecipient })
    });
  };
  if (button) button.disabled = true;
  (shouldSave
    ? api('/api/saveMailConfig.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
    .then(function (data) {
      fillMailForm(data.config || {});
      form.elements.testRecipient.value = testRecipient;
      renderMailStatus(data.status || {}, data.config || {});
      return send();
    })
    : send())
    .then(function (data) {
      setMailMessage('Testmail versendet (' + (data.transport || 'Mail') + ').', true);
    })
    .catch(function (error) {
      setMailMessage(error.message, false);
    })
    .finally(function () {
      if (button) button.disabled = false;
    });
}

function renderMailStatus(status, cfg) {
  const el = document.getElementById('mailSettingsStatus');
  if (!el) return;
  if (status.configured) {
    el.textContent = 'SMTP aktiv: ' + (cfg.host || 'Host') + ':' + (cfg.port || 587);
    el.className = 'mail-status ok';
    return;
  }
  if (status.mailFallback) {
    el.textContent = 'Fallback aktiv: PHP mail() wird genutzt, solange kein SMTP gespeichert ist.';
    el.className = 'mail-status ok';
    return;
  }
  if (status.mailFunction) {
    el.textContent = 'PHP mail() ist vorhanden, aber lokal ist kein Sendmail-Binary erreichbar. SMTP-Daten speichern.';
    el.className = 'mail-status';
    return;
  }
  el.textContent = 'Kein Mailversand verfügbar. SMTP-Daten speichern, bevor Mail-Plugins aktiviert werden.';
  el.className = 'mail-status';
}

function setMailMessage(text, ok) {
  setMessage(document.getElementById('mailSettingsMessage'), text, ok);
}

function formatDate(iso) {
  if (!iso) return '–';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleString('de-DE');
}

function row(label, value) {
  const r = document.createElement('div');
  r.className = 'update-card__row';
  const a = document.createElement('small');
  a.textContent = label;
  const b = document.createElement('span');
  b.textContent = value;
  r.appendChild(a);
  r.appendChild(b);
  return r;
}

function renderUpdates() {
  const el = document.getElementById('updateSection');
  if (!el) return;
  el.innerHTML = '';
  const status = state.updateStatus;
  if (!status) {
    el.appendChild(row('Status', 'Unbekannt'));
    return;
  }

  el.appendChild(row('Aktuelle Version', status.currentVersion || '–'));
  el.appendChild(row('Verfügbar', status.latestVersion || '–'));
  el.appendChild(row('Letzte Prüfung', formatDate(status.lastCheck)));
  el.appendChild(row('Auto-Update', status.enabled ? 'aktiviert' : 'deaktiviert'));

  if (status.lastError) {
    const errNote = document.createElement('div');
    errNote.className = 'update-card__notes';
    errNote.textContent = status.lastError;
    el.appendChild(errNote);
  }

  if (status.hasUpdate && status.notes) {
    const notes = document.createElement('div');
    notes.className = 'update-card__notes';
    notes.textContent = status.notes;
    el.appendChild(notes);
  }

  const actions = document.createElement('div');
  actions.className = 'update-card__actions';

  const checkBtn = document.createElement('button');
  checkBtn.type = 'button';
  checkBtn.className = 'secondary';
  checkBtn.textContent = 'Jetzt prüfen';
  checkBtn.addEventListener('click', function () {
    checkBtn.disabled = true;
    setMessage(document.getElementById('updateMessage'), 'Prüfe…', true);
    forceRemoteCheck()
      .then(function () {
        setMessage(document.getElementById('updateMessage'), 'Prüfung abgeschlossen.', true);
      })
      .catch(function (e) {
        setMessage(document.getElementById('updateMessage'), e.message, false);
      })
      .finally(function () { checkBtn.disabled = false; });
  });
  actions.appendChild(checkBtn);

  if (status.hasUpdate) {
    const installBtn = document.createElement('button');
    installBtn.type = 'button';
    installBtn.textContent = 'Update ' + status.latestVersion + ' installieren';
    installBtn.addEventListener('click', function () {
      installBtn.disabled = true;
      installBtn.textContent = 'Installiere…';
      api('/api/installUpdate.php', { method: 'POST' })
        .then(function (data) {
          setMessage(document.getElementById('updateMessage'),
            'Installiert: ' + (data.previousVersion || '?') + ' → ' + (data.newVersion || '?'), true);
          state.updateStatus = data.status || null;
          renderUpdates();
        })
        .catch(function (e) {
          setMessage(document.getElementById('updateMessage'), e.message, false);
          installBtn.disabled = false;
        });
    });
    actions.appendChild(installBtn);
  }

  if (status.rollbackAvailable) {
    const rb = document.createElement('button');
    rb.type = 'button';
    rb.className = 'secondary';
    rb.textContent = 'Rollback';
    rb.addEventListener('click', function () {
      if (!window.confirm('Letzte Aktualisierung zurücknehmen?')) return;
      rb.disabled = true;
      rollback()
        .then(function (data) {
          setMessage(document.getElementById('updateMessage'),
            'Zurückgesetzt auf ' + (data.currentVersion || '?'), true);
          renderUpdates();
        })
        .catch(function (e) {
          setMessage(document.getElementById('updateMessage'), e.message, false);
          rb.disabled = false;
        });
    });
    actions.appendChild(rb);
  }

  el.appendChild(actions);
}
