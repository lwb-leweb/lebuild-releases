import { api, setMessage } from '../core.js';

let container = null;

export function mount(outlet) {
  container = outlet;
  container.innerHTML = `
    <section class="view-area plugins-view">
      <div class="view-card span-12">
        <div class="topbar">
          <strong>Plugins verwalten</strong>
          <button type="button" id="pluginsRefreshButton" class="secondary">Aktualisieren</button>
        </div>
        <p class="message" id="pluginsViewMessage"></p>
        <div id="pluginsViewList" class="plugins-list"></div>
      </div>
    </section>
  `;
  container.querySelector('#pluginsRefreshButton').addEventListener('click', load);
  load();
}

export function unmount() {
  container = null;
}

function load() {
  api('/api/plugins/list.php')
    .then(function (data) {
      render(data.plugins || [], !!data.dbConfigured);
    })
    .catch(showError);
}

function render(plugins, dbConfigured) {
  const list = document.getElementById('pluginsViewList');
  const message = document.getElementById('pluginsViewMessage');
  if (!list) return;

  if (message) {
    setMessage(
      message,
      dbConfigured ? '' : 'Keine DB-Verbindung konfiguriert. DB-Plugins fragen beim Aktivieren nach den Zugangsdaten.',
      true
    );
  }

  if (!plugins.length) {
    list.innerHTML = '<p class="message">Keine Plugins gefunden.</p>';
    return;
  }

  list.innerHTML = plugins.map(pluginCard).join('');
  list.querySelectorAll('button[data-action]').forEach(function (button) {
    button.addEventListener('click', function () {
      handleAction(button.dataset.action, button.dataset.name);
    });
  });
}

function pluginCard(plugin) {
  if (plugin.error) {
    return `
      <article class="plugin-card">
        <div class="plugin-card__head">
          <h3>${escapeHtml(plugin.name)}</h3>
          <span class="status status--inactive">Fehler</span>
        </div>
        <p class="plugin-card__desc">${escapeHtml(plugin.error)}</p>
      </article>
    `;
  }

  const badges = [];
  if (plugin.requires && plugin.requires.database) badges.push('<span class="badge">DB</span>');
  if (plugin.requires && plugin.requires.mail) badges.push('<span class="badge">Mail</span>');
  if (plugin.requires && plugin.requires.uploads) badges.push('<span class="badge">Uploads</span>');

  const statusText = plugin.active ? 'Aktiv' : (plugin.installed ? 'Installiert, inaktiv' : 'Inaktiv');
  const statusClass = plugin.active ? 'active' : (plugin.installed ? 'installed' : 'inactive');
  const toggleAction = plugin.active ? 'deactivate' : 'activate';
  const toggleLabel = plugin.active ? 'Deaktivieren' : 'Aktivieren';
  const uninstallButton = plugin.installed
    ? `<button type="button" class="secondary" data-action="uninstall" data-name="${escapeAttr(plugin.name)}">Deinstallieren</button>`
    : '';

  return `
    <article class="plugin-card" data-name="${escapeAttr(plugin.name)}">
      <div class="plugin-card__head">
        <h3>${escapeHtml(plugin.label || plugin.name)}</h3>
        <span class="badges">${badges.join('')}</span>
        <span class="status status--${statusClass}">${statusText}</span>
      </div>
      <p class="plugin-card__desc">${escapeHtml(plugin.description || '')}</p>
      <footer>
        <small>v${escapeHtml(plugin.version || '0.0.0')}</small>
        <div class="plugin-card__actions">
          <button type="button" data-action="${toggleAction}" data-name="${escapeAttr(plugin.name)}">${toggleLabel}</button>
          ${uninstallButton}
        </div>
      </footer>
    </article>
  `;
}

function handleAction(action, name) {
  if (!action || !name) return;

  if (action === 'uninstall') {
    if (!window.confirm('Plugin "' + name + '" deinstallieren? Dabei werden alle Plugin-Daten und Tabellen gelöscht.')) {
      return;
    }
    api('/api/plugins/uninstall.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: name })
    }).then(reloadShell).catch(showError);
    return;
  }

  const endpoint = action === 'activate'
    ? '/api/plugins/activate.php'
    : '/api/plugins/deactivate.php';

  api(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: name })
  }).then(reloadShell).catch(function (error) {
    if (error.code === 'database_required') {
      showDbSetupDialog(name);
      return;
    }
    showError(error);
  });
}

function reloadShell() {
  window.location.reload();
}

function showDbSetupDialog(pluginName) {
  if (!container || container.querySelector('.db-setup-dialog')) return;

  const dialog = document.createElement('div');
  dialog.className = 'db-setup-dialog view-card';
  dialog.innerHTML = `
    <div class="topbar">
      <strong>Datenbank-Verbindung einrichten</strong>
      <button type="button" class="secondary" data-action="cancel">Schließen</button>
    </div>
    <p>Das Plugin "${escapeHtml(pluginName)}" benötigt eine MySQL/MariaDB-Verbindung.</p>
    <form id="dbSetupForm" class="settings-form">
      <label class="field"><small>Host</small><input name="host" value="127.0.0.1" required></label>
      <label class="field"><small>Port</small><input name="port" type="number" value="3306" min="1" max="65535" required></label>
      <label class="field"><small>Datenbank</small><input name="name" required></label>
      <label class="field"><small>Benutzer</small><input name="user" required></label>
      <label class="field"><small>Passwort</small><input name="password" type="password"></label>
      <div class="form-actions">
        <button type="submit">Verbindung testen & speichern</button>
        <button type="button" class="secondary" data-action="cancel">Abbrechen</button>
      </div>
      <p id="dbSetupMsg" class="message"></p>
    </form>
  `;

  container.querySelector('.plugins-view').appendChild(dialog);
  dialog.querySelectorAll('[data-action="cancel"]').forEach(function (button) {
    button.addEventListener('click', function () { dialog.remove(); });
  });
  dialog.querySelector('#dbSetupForm').addEventListener('submit', function (event) {
    event.preventDefault();
    const fields = event.target.elements;
    api('/api/plugins/dbConfig.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        host: fields.host.value,
        port: parseInt(fields.port.value, 10),
        name: fields.name.value,
        user: fields.user.value,
        password: fields.password.value
      })
    }).then(function () {
      dialog.remove();
      handleAction('activate', pluginName);
    }).catch(function (error) {
      const msg = dialog.querySelector('#dbSetupMsg');
      if (msg) setMessage(msg, error.message, false);
    });
  });
}

function showError(error) {
  const message = document.getElementById('pluginsViewMessage');
  if (message) setMessage(message, error.message || String(error), false);
}

function escapeHtml(value) {
  return String(value || '').replace(/[&<>"']/g, function (char) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
  });
}

function escapeAttr(value) {
  return escapeHtml(value);
}
