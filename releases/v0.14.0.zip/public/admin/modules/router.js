import { state, dom, clearViewDom, api, isAdmin } from './core.js';
import { pageKey } from './pages.js';
import { openModal, closeModal } from './ui-modal.js';
import * as DashboardView from './views/dashboard.js';
import * as SettingsView from './views/settings.js';
import * as PageView from './views/page.js';
import * as PluginsView from './views/plugins.js';
import * as UsersView from './views/users.js';

const ADMIN_ONLY_VIEWS = new Set(['settings', 'plugins', 'users']);

export const BASE_PATH = '/admin/';

const views = {
  dashboard: DashboardView,
  settings: SettingsView,
  page: PageView,
  plugins: PluginsView,
  users: UsersView,
  plugin: createPluginViewProxy()
};

let currentName = null;
let currentView = null;

function parsePath() {
  let path = window.location.pathname;
  if (path === BASE_PATH || path === BASE_PATH.slice(0, -1)) {
    path = '';
  } else if (path.startsWith(BASE_PATH)) {
    path = path.slice(BASE_PATH.length);
  }
  const slash = path.indexOf('/');
  return {
    name: slash === -1 ? path : path.slice(0, slash),
    param: slash === -1 ? '' : path.slice(slash + 1)
  };
}

export function navigate(route, options) {
  const url = BASE_PATH + route;
  if (window.location.pathname !== url) {
    if (options && options.replace) {
      history.replaceState(null, '', url);
    } else {
      history.pushState(null, '', url);
    }
  }
  renderView();
}

function renderView() {
  const { name, param } = parsePath();

  if (!views[name] || (name === 'page' && !param)) {
    if (state.pageInfo.length) {
      navigate('page/' + pageKey(state.pageInfo[0]), { replace: true });
    } else {
      navigate('dashboard', { replace: true });
    }
    return;
  }

  if (ADMIN_ONLY_VIEWS.has(name) && !isAdmin()) {
    showToast('Keine Berechtigung für diesen Bereich.');
    if (state.pageInfo.length) {
      navigate('page/' + pageKey(state.pageInfo[0]), { replace: true });
    } else {
      navigate('dashboard', { replace: true });
    }
    return;
  }

  if (name === currentName && currentView && typeof currentView.update === 'function') {
    currentView.update(param);
    syncSidebar(name);
    return;
  }

  if (currentView && typeof currentView.unmount === 'function') {
    currentView.unmount();
  }
  clearViewDom();
  dom.viewOutlet.textContent = '';

  currentView = views[name];
  currentName = name;
  currentView.mount(dom.viewOutlet, param);
  syncSidebar(name);
}

function syncSidebar(name) {
  document.querySelectorAll('.sidebar-nav .nav-item').forEach(function (btn) {
    btn.classList.remove('active');
  });
  if (dom.pluginsManageButton) {
    dom.pluginsManageButton.classList.remove('active');
  }
  if (name === 'dashboard' && dom.dashboardButton) {
    dom.dashboardButton.classList.add('active');
  }
  if (name === 'settings' && dom.settingsButton) {
    dom.settingsButton.classList.add('active');
  }
  if (name === 'plugins' && dom.pluginsManageButton) {
    dom.pluginsManageButton.classList.add('active');
  }
  document.querySelectorAll('#pluginsActiveList .page-entry').forEach(function (btn) {
    btn.classList.remove('active');
    if (name === 'plugin') {
      const parsed = parsePath();
      if (btn.dataset.route === parsed.param) {
        btn.classList.add('active');
      }
    }
  });
}

function createPluginViewProxy() {
  let loadedModule = null;

  return {
    async mount(outlet, route) {
      const segments = String(route || '').split('/').filter(Boolean);
      const pluginName = segments[0] || '';
      const subRoute = segments.slice(1).join('/');

      if (!pluginName || !/^[a-z][a-z0-9_-]*$/.test(pluginName)) {
        outlet.innerHTML = '<section class="view-area"><div class="view-card"><p class="message">Ungültiger Plugin-Name.</p></div></section>';
        return;
      }

      const info = (state.activePlugins || []).find(function (plugin) {
        const expected = plugin.route || plugin.name;
        return expected === route || plugin.name === pluginName;
      });
      if (!info) {
        outlet.innerHTML = '<section class="view-area"><div class="view-card"><p class="message">Plugin ist nicht aktiv.</p></div></section>';
        return;
      }

      try {
        if (info.hasAdminModule) {
          const mod = await import('/plugins/' + pluginName + '/admin/module.js');
          loadedModule = mod.default;
        } else if (info.hasSchema) {
          const mod = await import('./views/plugin-generic.js');
          loadedModule = mod.default;
        } else {
          outlet.innerHTML = '<section class="view-area"><div class="view-card"><p>Dieses Plugin hat keine Admin-Oberfläche.</p></div></section>';
          return;
        }

        if (!loadedModule || (loadedModule.id !== pluginName && loadedModule.id !== '__generic__')) {
          throw new Error('Plugin-Modul passt nicht zum Plugin.');
        }
        await loadedModule.mount(outlet, buildPluginContext(pluginName, subRoute, info));
      } catch (error) {
        outlet.innerHTML = '<section class="view-area"><div class="view-card"><p class="message">Plugin-Modul konnte nicht geladen werden: ' + escapeHtml(error.message || String(error)) + '</p></div></section>';
      }
    },
    unmount() {
      if (loadedModule && typeof loadedModule.unmount === 'function') {
        try {
          loadedModule.unmount();
        } catch (e) {
        }
      }
      loadedModule = null;
    }
  };
}

function buildPluginContext(pluginName, subRoute, info) {
  return {
    pluginName: pluginName,
    subRoute: subRoute || '',
    info: info || null,
    api: api,
    navigate: navigate,
    state: state,
    confirm: function (message) { return window.confirm(message); },
    toast: function (message) { window.alert(message); },
    ui: {
      openModal: openModal,
      closeModal: closeModal
    }
  };
}

function escapeHtml(value) {
  return String(value || '').replace(/[&<>"']/g, function (char) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
  });
}

let toastTimer = null;
function showToast(message) {
  let host = document.getElementById('roleToast');
  if (!host) {
    host = document.createElement('div');
    host.id = 'roleToast';
    host.className = 'role-toast';
    host.setAttribute('role', 'status');
    host.setAttribute('aria-live', 'polite');
    document.body.appendChild(host);
  }
  host.textContent = message;
  host.classList.add('visible');
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(function () {
    host.classList.remove('visible');
  }, 3000);
}

let initialized = false;
export function initRouter() {
  if (!initialized) {
    window.addEventListener('popstate', renderView);
    initialized = true;
  }
  renderView();
}
