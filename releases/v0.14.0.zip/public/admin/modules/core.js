export const state = {
  csrfToken: '',
  pages: [],
  pageInfo: [],
  currentPage: '',
  content: {},
  labels: {},
  pageQuery: '',
  fieldQuery: '',
  advanced: false,
  updateStatus: null,
  updateDismissed: false,
  activePlugins: [],
  role: null,
  username: null
};

export function isAdmin() {
  return state.role === 'admin';
}

// Shell elements (always present). View-internal refs (previewFrame,
// fieldsPanel, settingsForm, ...) are registered by view modules via
// updateDom() when they mount, and cleared via clearViewDom() on unmount.
export const dom = {
  loginView: document.getElementById('loginView'),
  loginForm: document.getElementById('loginForm'),
  loginMessage: document.getElementById('loginMessage'),
  editorView: document.getElementById('editorView'),
  viewOutlet: document.getElementById('viewOutlet'),
  pageList: document.getElementById('pageList'),
  pageSearch: document.getElementById('pageSearch'),
  importNotice: document.getElementById('importNotice'),
  importButton: document.getElementById('importButton'),
  reimportButton: document.getElementById('reimportButton'),
  extensionsGroup: document.getElementById('extensionsGroup'),
  extensionsNavToggle: document.getElementById('extensionsNavToggle'),
  pluginsManageButton: document.getElementById('pluginsManageButton'),
  pluginsActiveList: document.getElementById('pluginsActiveList'),
  pluginsEmptyHint: document.getElementById('pluginsEmptyHint'),
  advancedToggle: document.getElementById('advancedToggle'),
  usersButton: document.getElementById('usersButton'),
  settingsButton: document.getElementById('settingsButton'),
  dashboardButton: document.getElementById('dashboardButton'),
  logoutButton: document.getElementById('logoutButton'),
  updateBanner: document.getElementById('updateBanner'),
  inlineEditor: document.getElementById('inlineEditor'),
  inlineEditorTitle: document.getElementById('inlineEditorTitle'),
  inlineEditorBody: document.getElementById('inlineEditorBody'),
  inlineEditorClose: document.getElementById('inlineEditorClose'),
  inlineEditorCancel: document.getElementById('inlineEditorCancel'),
  inlineEditorSave: document.getElementById('inlineEditorSave'),

  // View-internal refs — populated by view modules on mount
  previewFrame: null,
  fieldsPanel: null,
  fieldsForm: null,
  fieldSearch: null,
  currentPageTitle: null,
  editorMessage: null,
  backupSelect: null,
  restoreButton: null,
  settingsPanel: null,
  settingsForm: null,
  settingsSaveButton: null,
  settingsMessage: null,
  dashboardPanel: null,
  pageView: null
};

const VIEW_DOM_KEYS = [
  'previewFrame', 'fieldsPanel', 'fieldsForm', 'fieldSearch',
  'currentPageTitle', 'editorMessage', 'backupSelect', 'restoreButton',
  'settingsPanel', 'settingsForm', 'settingsSaveButton', 'settingsMessage',
  'dashboardPanel', 'pageView'
];

export function updateDom(refs) {
  Object.assign(dom, refs);
}

export function clearViewDom() {
  VIEW_DOM_KEYS.forEach(function (key) { dom[key] = null; });
}

export function labelFor(path) {
  return (state.labels && state.labels[path]) || path;
}

// Stored text values may contain <br> line breaks (preserved from imported
// HTML). Convert to/from real newlines so textareas behave naturally.
export function brToNewline(value) {
  return String(value || '').replace(/<br\s*\/?>/gi, '\n');
}
export function newlineToBr(value) {
  return String(value || '').replace(/\r\n/g, '\n').replace(/\n/g, '<br>');
}

export function api(path, options = {}) {
  options.credentials = 'same-origin';
  options.headers = options.headers || {};
  if (state.csrfToken && options.method && options.method !== 'GET') {
    options.headers['X-CSRF-Token'] = state.csrfToken;
  }
  return fetch(path, options).then(function (res) {
    return res.text().then(function (text) {
      let data = {};
      try {
        data = text ? JSON.parse(text) : {};
      } catch (e) {
        data = { ok: res.ok, error: text || ('HTTP ' + res.status) };
      }
      if (!res.ok || data.ok === false) {
        const error = new Error(data.message || data.error || 'Request failed');
        error.code = data.error || null;
        error.status = res.status;
        error.data = data;
        throw error;
      }
      return data;
    });
  });
}

export function setMessage(el, text, ok) {
  if (!el) return;
  el.textContent = text || '';
  el.classList.toggle('ok', !!ok);
}

export function flatten(data, prefix, rows) {
  rows = rows || [];
  Object.keys(data || {}).forEach(function (key) {
    const path = prefix ? prefix + '.' + key : key;
    if (data[key] && typeof data[key] === 'object' && !Array.isArray(data[key])) {
      flatten(data[key], path, rows);
    } else {
      rows.push({ path: path, value: String(data[key] || '') });
    }
  });
  return rows;
}

export function setNested(target, path, value) {
  const parts = path.split('.');
  let cursor = target;
  parts.forEach(function (part, index) {
    if (index === parts.length - 1) {
      cursor[part] = value;
      return;
    }
    cursor[part] = cursor[part] || {};
    cursor = cursor[part];
  });
}

export function getContentPath(path) {
  return path.split('.').reduce(function (cursor, part) {
    return cursor && Object.prototype.hasOwnProperty.call(cursor, part) ? cursor[part] : undefined;
  }, state.content);
}

let previewSyncCallback = null;
export function registerPreviewSync(fn) { previewSyncCallback = fn; }

export function updateContentPath(path, value) {
  setNested(state.content, path, value);
  if (previewSyncCallback) previewSyncCallback(false);
}

// Advanced mode (fields panel toggle) — subscriber pattern so views can react.
const advancedSubscribers = [];
export function setAdvancedMode(open) {
  state.advanced = !!open;
  const label = dom.advancedToggle && dom.advancedToggle.querySelector('.nav-label');
  if (label) label.textContent = state.advanced ? 'Einfach' : 'Erweitert';
  advancedSubscribers.forEach(function (fn) { fn(state.advanced); });
}
export function onAdvancedChange(fn) {
  advancedSubscribers.push(fn);
}
