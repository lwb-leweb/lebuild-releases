<?php declare(strict_types=1);

// Universal front controller. Übernimmt das gesamte HTTP-Routing für
// - klassisches Apache-Shared-Hosting (siehe .htaccess: ein Rewrite leitet
//   alles ohne reale Datei hier her),
// - PHP's eingebauten Server (`php -S 127.0.0.1:8000 index.php`),
// - Nginx (`try_files $uri /index.php?$query_string;`).
//
// Vorteil: ein Router, eine Wahrheit. Keine Hoster-spezifischen Direktiven
// wie `%{DOCUMENT_ROOT}` oder Per-Dir-`.htaccess` mit `RewriteBase`, die auf
// günstigen Apaches (z.B. IONOS) regelmäßig 500s produzieren.

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
if (!is_string($path) || $path === '') {
    $path = '/';
}

$projectRoot = __DIR__;
$isCliServer = PHP_SAPI === 'cli-server';

// 1. Private Ordner nie ausliefern (Defense in Depth zusätzlich zu den
//    .htaccess in diesen Ordnern, die auf eingeschränkten Hostern manchmal
//    ignoriert werden).
if (preg_match('#^/(content|core|tests)(/|$)#', $path)) {
    return respond_not_found();
}

// 2. /public/site/includes/* sind Partials, keine Standalone-Dokumente.
if (preg_match('#^/public/site/includes(/|$)#', $path)) {
    return respond_not_found();
}

// 3. Admin-SPA: /admin und /admin/* zeigen auf /public/admin/ (gleiches gilt
//    für den kanonischen /public/admin/-Pfad, damit alte Bookmarks und der
//    direkte Dev-Aufruf weiter funktionieren). Existiert die angefragte
//    Ressource dort als Datei (CSS, JS, Bild, Modul), liefern wir sie aus;
//    sonst fällt der Request auf die SPA-Shell `index.html` zurück, damit
//    Deep-Links wie /admin/settings nach Reload weiter funktionieren.
if (preg_match('#^/(?:public/)?admin(?:/(.*))?$#', $path, $m)) {
    $rel = isset($m[1]) ? trim($m[1], '/') : '';

    if ($rel !== '') {
        if (str_contains($rel, '..') || !preg_match('#^[A-Za-z0-9_./@\-]+$#', $rel)) {
            return respond_not_found();
        }
        $asset = $projectRoot . '/public/admin/' . $rel;
        if (is_file($asset)) {
            return serve_static_file($asset);
        }
    }

    $shell = $projectRoot . '/public/admin/index.html';
    if (is_file($shell)) {
        header('Content-Type: text/html; charset=utf-8');
        readfile($shell);
        return true;
    }
    return respond_not_found();
}

// 4. Dev-Server (php -S): reale Dateien außerhalb von /public/site/*.html|php
//    soll PHP selbst ausliefern. `return false` signalisiert genau das. Site-
//    Dokumente lassen wir absichtlich durch den Renderer unten laufen, damit
//    Shortcodes und Plugin-Filter greifen.
if ($isCliServer && $path !== '/' && is_file($projectRoot . $path)) {
    $isSiteDoc = str_starts_with($path, '/public/site/')
        && (bool) preg_match('/\.(html?|php)$/i', $path);
    if (!$isSiteDoc) {
        return false;
    }
}

// 5. Site-Dokumente und Site-Assets. URL wird auf /public/site/ gemappt:
//    - /                          → /public/site/index.{php,html}
//    - /imprint                   → /public/site/imprint.{php,html} oder .../index.{php,html}
//    - /styles.min.css            → /public/site/styles.min.css
//    - /assets/logos/favicon.png  → /public/site/assets/logos/favicon.png
//    - /public/site/foo.html      → /public/site/foo.html (kanonisch)
$siteRoot = $projectRoot . '/public/site';

if (str_starts_with($path, '/public/site/')) {
    $relative = substr($path, strlen('/public/site/'));
} elseif ($path === '/') {
    $relative = '';
} else {
    $relative = ltrim($path, '/');
}
$relative = rtrim($relative, '/');

if ($relative !== '' && (str_contains($relative, '..') || !preg_match('#^[A-Za-z0-9_./@\-]+$#', $relative))) {
    return respond_not_found();
}

$candidates = [];
if ($relative === '') {
    $candidates[] = $siteRoot . '/index.php';
    $candidates[] = $siteRoot . '/index.html';
} else {
    $candidates[] = $siteRoot . '/' . $relative;
    if (!preg_match('/\.(php|html?)$/i', $relative)) {
        $candidates[] = $siteRoot . '/' . $relative . '.php';
        $candidates[] = $siteRoot . '/' . $relative . '.html';
        $candidates[] = $siteRoot . '/' . $relative . '/index.php';
        $candidates[] = $siteRoot . '/' . $relative . '/index.html';
    }
}

$file = null;
foreach ($candidates as $candidate) {
    if (is_file($candidate)) {
        $file = $candidate;
        break;
    }
}

if ($file === null) {
    return respond_not_found();
}

$ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));

if ($ext === 'php' || $ext === 'html' || $ext === 'htm') {
    require_once $projectRoot . '/core/shortcodes.php';
    require_once $projectRoot . '/core/plugins.php';

    if ($ext === 'php') {
        ob_start();
        require $file;
        $html = (string) ob_get_clean();
    } else {
        $html = (string) file_get_contents($file);
    }

    $html = render_shortcodes_in_html($html);
    $html = filter_site_html($html);

    header('Content-Type: text/html; charset=utf-8');
    echo $html;
    return true;
}

return serve_static_file($file);


function respond_not_found(): bool
{
    http_response_code(404);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Not Found';
    return true;
}

function serve_static_file(string $file): bool
{
    static $mime = [
        'css'   => 'text/css; charset=utf-8',
        'js'    => 'application/javascript; charset=utf-8',
        'mjs'   => 'application/javascript; charset=utf-8',
        'map'   => 'application/json; charset=utf-8',
        'json'  => 'application/json; charset=utf-8',
        'xml'   => 'application/xml; charset=utf-8',
        'txt'   => 'text/plain; charset=utf-8',
        'svg'   => 'image/svg+xml',
        'png'   => 'image/png',
        'jpg'   => 'image/jpeg',
        'jpeg'  => 'image/jpeg',
        'gif'   => 'image/gif',
        'webp'  => 'image/webp',
        'ico'   => 'image/x-icon',
        'woff'  => 'font/woff',
        'woff2' => 'font/woff2',
        'ttf'   => 'font/ttf',
        'eot'   => 'application/vnd.ms-fontobject',
        'otf'   => 'font/otf',
        'pdf'   => 'application/pdf',
        'mp4'   => 'video/mp4',
        'webm'  => 'video/webm',
    ];

    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    $type = $mime[$ext] ?? 'application/octet-stream';

    header('Content-Type: ' . $type);
    header('Content-Length: ' . (string) filesize($file));
    readfile($file);
    return true;
}
