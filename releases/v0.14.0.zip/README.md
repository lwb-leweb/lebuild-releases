# Live Editor

Kleines PHP/Vanilla-JS-Tool, um statische HTML-Seiten nach einem Import ohne Datenbank über JSON zu bearbeiten.

## Start

Mit einem lokalen PHP-Server (`index.php` ist der universelle Front-Controller — gleicher Code für Dev und Produktion):

```bash
php -S 127.0.0.1:8000 index.php
```

Dann im Browser öffnen:

- Admin: `http://127.0.0.1:8000/admin`
- Beispielseite: `http://127.0.0.1:8000/`

## Login & Benutzer

Beim ersten Login wird automatisch ein Admin-User in `content/users.json` angelegt:

- Benutzer: `admin`
- Passwort: `admin`

Wer sich so anmeldet, muss sofort ein eigenes Passwort festlegen; vorher ist nichts anderes erreichbar. Nach 10 Fehlversuchen sperrt der Login eine IP für 15 Minuten.

Diese Defaults sind per Env-Variable überschreibbar (Bootstrap nur beim Erst-Setup):

- `LIVE_EDITOR_USER`
- `LIVE_EDITOR_PASSWORD`

Sobald mindestens ein Admin in `content/users.json` existiert, werden die Env-Vars ignoriert — alle weiteren Benutzer werden über das Admin-UI verwaltet (**Benutzer**-Eintrag in der Sidebar).

### Rollen

- **admin** — kann alles: Inhalte bearbeiten, Einstellungen, SMTP, Updates, Plugins, Backups wiederherstellen, Benutzer anlegen / Rollen ändern / löschen.
- **editor** — darf Seiten bearbeiten, Backups einsehen, Upload nutzen. Settings, Plugin-Verwaltung, Re-Import, Restore und Update-Install sind weder im UI sichtbar noch über die API erreichbar (403).

Passwörter werden als bcrypt-Hashes in `content/users.json` gespeichert. Diese Datei ist `.gitignore`d und durch `content/.htaccess` (Apache) sowie den Dev-Router gegen direkten HTTP-Zugriff geschützt.

## Ablauf

1. Statische HTML-Dateien nach `public/site/` legen
2. Im Admin einloggen
3. Import starten
4. Inhalte im Editor ändern
5. Änderungen werden in `content/pages/*.json` gespeichert

## Speicherorte

- Seiteninhalt: `content/pages/`
- Backups: `content/backups/`
- Originale: `content/originals/`
- Benutzer (bcrypt-Hashes, nicht im Git): `content/users.json`
- Uploads: `public/uploads/`

## Hinweise

- Keine Datenbank
- Kein Node.js
- Der Import verändert HTML nur einmal und schreibt `data-edit-id` Marker in die importierten Seiten
- Re-Import ist manuell über den Admin-Button

## Tests

```bash
php tests/run.php
```

Braucht PHP mit `curl`, `sodium` und `zip`. Die Tests arbeiten in einer Wegwerf-Kopie unter dem Temp-Verzeichnis.

## Mail / SMTP

Der Core kann E-Mails zentral versenden:

- SMTP-Konfiguration: Admin → Einstellungen → E-Mail / SMTP
- Geschützte Runtime-Datei: `core/mail.config.php`
- Fallback ohne SMTP: PHP `mail()`, sofern auf dem Hosting verfügbar

Mail-Plugins wie `contact-form` rufen nur den Core-Mailer auf und kennen keine SMTP-Zugangsdaten.

## Auto-Update

Kunden-Installationen aktualisieren sich automatisch über signierte Releases im öffentlichen Repo `lwb-leweb/website-live-editor-releases`. Release-Workflow für Maintainer und Update-Verhalten beim Kunden: siehe [knowledgebase/release.md](knowledgebase/release.md).
