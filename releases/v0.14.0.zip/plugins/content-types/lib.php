<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/db.php';
require_once __DIR__ . '/../../core/plugins.php';
require_once __DIR__ . '/../../core/pluginSchema.php';

function content_types_dir(): string
{
    return plugin_data_path('content-types');
}

function content_types_name_valid(string $name): bool
{
    return (bool) preg_match('/^[a-z][a-z0-9_-]*$/', $name);
}

function content_types_list_names(): array
{
    $dir = content_types_dir();
    if (!is_dir($dir)) {
        return [];
    }

    $names = [];
    foreach (scandir($dir) ?: [] as $entry) {
        if (!is_string($entry) || !str_ends_with($entry, '.json')) {
            continue;
        }
        $name = substr($entry, 0, -5);
        if (!content_types_name_valid($name)) {
            continue;
        }
        if (!is_file($dir . '/' . $entry)) {
            continue;
        }
        $names[] = $name;
    }
    sort($names);

    return $names;
}

function content_types_load(string $name): array
{
    if (!content_types_name_valid($name)) {
        throw new InvalidArgumentException('Invalid content-type name: ' . $name);
    }
    $path = content_types_dir() . '/' . $name . '.json';
    if (!is_file($path)) {
        throw new RuntimeException('Content-type not found: ' . $name);
    }

    $data = json_decode((string) file_get_contents($path), true);
    if (!is_array($data)) {
        throw new RuntimeException('Invalid JSON for content-type: ' . $name);
    }
    if (($data['name'] ?? '') !== $name) {
        throw new RuntimeException('Content-type name mismatch: ' . $name);
    }
    if (!is_string($data['label'] ?? null) || trim($data['label']) === '') {
        throw new RuntimeException('Content-type missing label: ' . $name);
    }
    if (!is_array($data['fields'] ?? null) || empty($data['fields'])) {
        throw new RuntimeException('Content-type has no fields: ' . $name);
    }

    return $data;
}

function content_types_admin_sidebar_entries(): array
{
    $entries = [];
    foreach (content_types_list_names() as $name) {
        try {
            $def = content_types_load($name);
        } catch (Throwable $e) {
            continue;
        }
        $entries[] = [
            'name' => 'content-types',
            'route' => 'content-types/' . $name,
            'label' => (string) $def['label'],
            'hasAdminModule' => true,
            'hasSchema' => true,
            'type' => $name,
        ];
    }

    return $entries;
}

function content_types_schema_columns(string $type): array
{
    $def = content_types_load($type);
    $columns = [];
    foreach ($def['fields'] as $field) {
        if (!is_array($field)) {
            continue;
        }
        $name = $field['name'] ?? null;
        if (!is_string($name) || !preg_match('/^[a-z][a-z0-9_]*$/', $name)) {
            continue;
        }
        $field['type'] = is_string($field['type'] ?? null) ? $field['type'] : 'text';
        $columns[] = $field;
    }

    return $columns;
}

function content_types_fetch_list(string $type, int $limit = 100): array
{
    if (!content_types_name_valid($type)) {
        return [];
    }
    $limit = max(1, min(500, $limit));
    $stmt = db()->prepare(
        "SELECT id, data, sort_order, created_at, updated_at
         FROM content_items
         WHERE content_type = ?
         ORDER BY sort_order ASC, id DESC
         LIMIT {$limit}"
    );
    $stmt->execute([$type]);
    $rows = $stmt->fetchAll();

    return array_map('content_types_expand_row', $rows);
}

function content_types_fetch_by_id(string $type, int $id): ?array
{
    if (!content_types_name_valid($type) || $id <= 0) {
        return null;
    }
    $stmt = db()->prepare(
        'SELECT id, data, sort_order, created_at, updated_at
         FROM content_items WHERE content_type = ? AND id = ? LIMIT 1'
    );
    $stmt->execute([$type, $id]);
    $row = $stmt->fetch();

    return $row ? content_types_expand_row($row) : null;
}

function content_types_expand_row(array $row): array
{
    $data = json_decode((string) ($row['data'] ?? '{}'), true);
    if (!is_array($data)) {
        $data = [];
    }
    unset($row['data']);
    return $row + $data;
}

function content_types_normalize_values(string $type, array $rawValues): array
{
    $fields = content_types_schema_columns($type);
    $values = [];
    foreach ($fields as $field) {
        $key = $field['name'];
        if (!array_key_exists($key, $rawValues)) {
            if (!empty($field['required'])) {
                throw new InvalidArgumentException('Missing required field: ' . $key);
            }
            continue;
        }
        $normalized = plugin_schema_normalize_value($field, $rawValues[$key], $rawValues);
        if (!empty($field['required']) && ($normalized === '' || $normalized === null)) {
            throw new InvalidArgumentException('Missing required field: ' . $key);
        }
        $values[$key] = $normalized;
    }

    return $values;
}

function content_types_save(string $type, array $rawValues, ?int $id = null): int
{
    if (!content_types_name_valid($type)) {
        throw new InvalidArgumentException('Invalid content-type');
    }
    // Validate type exists
    content_types_load($type);

    $values = content_types_normalize_values($type, $rawValues);
    $json = json_encode($values, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        throw new RuntimeException('Cannot encode item data');
    }

    if ($id !== null && $id > 0) {
        $stmt = db()->prepare('UPDATE content_items SET data = ? WHERE content_type = ? AND id = ?');
        $stmt->execute([$json, $type, $id]);
        return $id;
    }

    $stmt = db()->prepare('INSERT INTO content_items (content_type, data) VALUES (?, ?)');
    $stmt->execute([$type, $json]);
    return (int) db()->lastInsertId();
}

function content_types_delete(string $type, int $id): void
{
    if (!content_types_name_valid($type) || $id <= 0) {
        return;
    }
    $stmt = db()->prepare('DELETE FROM content_items WHERE content_type = ? AND id = ?');
    $stmt->execute([$type, $id]);
}
