<?php
require_once __DIR__ . '/../lib.php';

$type = (string) ($attrs['type'] ?? '');
$limit = (int) ($attrs['limit'] ?? 20);

if (!content_types_name_valid($type)) {
    echo '<!-- content-types: missing or invalid type attribute -->';
    return;
}

try {
    $def = content_types_load($type);
    $rows = content_types_fetch_list($type, $limit);
    $schema = content_types_schema_columns($type);
} catch (Throwable $e) {
    echo '<!-- content-types: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES) . ' -->';
    return;
}

if (empty($rows)) {
    echo '<p class="content-list content-list--empty">Noch keine Einträge.</p>';
    return;
}
?>
<ul class="content-list content-list--<?= htmlspecialchars($type) ?>">
  <?php foreach ($rows as $row): ?>
    <li class="content-list__item">
      <?php foreach ($schema as $field): ?>
        <?php
          $name = $field['name'];
          $fieldType = $field['type'] ?? 'text';
          $value = $row[$name] ?? '';
          if ($value === '' || $value === null) continue;
        ?>
        <?php if ($fieldType === 'image'): ?>
          <img class="content-list__image" src="<?= htmlspecialchars((string) $value) ?>" alt="">
        <?php elseif ($fieldType === 'richtext'): ?>
          <div class="content-list__richtext"><?= plugin_sanitize_richtext((string) $value) ?></div>
        <?php else: ?>
          <div class="content-list__field content-list__field--<?= htmlspecialchars($name) ?>">
            <?= htmlspecialchars((string) $value) ?>
          </div>
        <?php endif ?>
      <?php endforeach ?>
    </li>
  <?php endforeach ?>
</ul>
