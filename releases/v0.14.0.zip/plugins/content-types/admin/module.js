let outletEl = null;
let ctxRef = null;
let currentType = '';
let currentLabel = '';
let currentSchema = [];

const contentTypesModule = {
  id: 'content-types',
  mount(outlet, ctx) {
    outletEl = outlet;
    ctxRef = ctx;
    currentType = ctx.subRoute || '';
    if (!currentType) {
      outlet.innerHTML = '<section class="view-area"><div class="view-card"><p class="message">Kein Content-Typ ausgewählt.</p></div></section>';
      return;
    }
    renderShell();
    loadList();
  },
  unmount() {
    if (ctxRef && ctxRef.ui && ctxRef.ui.closeModal) ctxRef.ui.closeModal();
    outletEl = null;
    ctxRef = null;
    currentType = '';
    currentLabel = '';
    currentSchema = [];
  }
};

export default contentTypesModule;

function renderShell() {
  outletEl.innerHTML = `
    <section class="view-area content-types-admin">
      <div class="view-card span-12">
        <div class="topbar">
          <strong id="ctTitle">${escapeHtml(currentType)}</strong>
          <button type="button" id="ctNewBtn">Neuer Eintrag</button>
        </div>
        <p id="ctMsg" class="message"></p>
        <div id="ctList" class="generic-list"></div>
      </div>
    </section>
  `;
  outletEl.querySelector('#ctNewBtn').addEventListener('click', function () {
    openForm(null);
  });
}

function loadList() {
  ctxRef.api('/plugins/content-types/api/list.php?type=' + encodeURIComponent(currentType))
    .then(function (data) {
      currentLabel = data.label || currentType;
      currentSchema = data.schema || [];
      const titleEl = document.getElementById('ctTitle');
      if (titleEl) titleEl.textContent = currentLabel;
      renderList(data.rows || []);
    })
    .catch(showError);
}

function renderList(rows) {
  const list = document.getElementById('ctList');
  if (!list) return;

  if (!rows.length) {
    list.innerHTML = '<p class="message">Noch keine Einträge.</p>';
    return;
  }

  const titleField = pickTitleField(currentSchema);
  list.innerHTML = '<ul>' + rows.map(function (row) {
    const title = titleField ? (row[titleField] || '(ohne Titel)') : ('#' + row.id);
    return `
      <li class="generic-list__row" data-id="${row.id}">
        <span class="generic-list__title">${escapeHtml(title)}</span>
        <div class="generic-list__actions">
          <button type="button" data-action="edit" data-id="${row.id}">Bearbeiten</button>
          <button type="button" data-action="delete" data-id="${row.id}" class="secondary">Löschen</button>
        </div>
      </li>
    `;
  }).join('') + '</ul>';

  list.querySelectorAll('button[data-action="edit"]').forEach(function (button) {
    button.addEventListener('click', function () {
      openFormFromServer(parseInt(button.dataset.id, 10));
    });
  });
  list.querySelectorAll('button[data-action="delete"]').forEach(function (button) {
    button.addEventListener('click', function () {
      const id = parseInt(button.dataset.id, 10);
      if (!ctxRef.confirm('Eintrag löschen?')) return;
      ctxRef.api('/plugins/content-types/api/delete.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: currentType, id: id })
      }).then(loadList).catch(showError);
    });
  });
}

function pickTitleField(schema) {
  const named = schema.find(function (field) {
    return field.name === 'title' || field.name === 'name';
  });
  if (named) return named.name;
  const text = schema.find(function (field) { return field.type === 'text'; });
  return text ? text.name : null;
}

function openFormFromServer(id) {
  ctxRef.api('/plugins/content-types/api/get.php?type=' + encodeURIComponent(currentType) + '&id=' + id)
    .then(function (data) {
      currentSchema = data.schema || currentSchema;
      openForm(data.row || null);
    })
    .catch(showError);
}

function openForm(row) {
  const bodyHtml = `
    <form id="ctFormEl" class="settings-form">
      ${currentSchema.map(function (field) { return fieldInput(field, row); }).join('')}
    </form>
  `;

  const modal = ctxRef.ui.openModal({
    title: row ? 'Bearbeiten' : 'Neu',
    bodyHtml: bodyHtml,
    onSubmit: function (ctx) {
      const formEl = ctx.body.querySelector('#ctFormEl');
      const data = {};
      currentSchema.forEach(function (field) {
        const input = formEl.querySelector('[name="' + field.name + '"]');
        if (!input) return;
        data[field.name] = field.type === 'boolean' ? (input.checked ? '1' : '0') : input.value;
      });

      const body = { type: currentType, data: data };
      if (row && row.id) body.id = row.id;

      ctx.setBusy(true);
      ctxRef.api('/plugins/content-types/api/save.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      }).then(function () {
        ctx.close('submit');
        loadList();
      }).catch(function (error) {
        ctx.setBusy(false);
        ctx.setMessage(error.message || String(error), false);
      });
    }
  });

  const formEl = modal.body.querySelector('#ctFormEl');
  formEl.addEventListener('submit', function (event) {
    event.preventDefault();
    modal.submitButton.click();
  });
}

function fieldInput(field, row) {
  const value = row && row[field.name] != null ? row[field.name] : '';
  const label = escapeHtml(field.label || field.name);
  const required = field.required ? ' required' : '';
  const escaped = escapeAttr(formatInputValue(field, value));

  if (field.type === 'richtext') {
    return `<label class="field"><small>${label}</small><textarea name="${escapeAttr(field.name)}" rows="7"${required}>${escapeHtml(value)}</textarea></label>`;
  }
  if (field.type === 'datetime') {
    return `<label class="field"><small>${label}</small><input type="datetime-local" name="${escapeAttr(field.name)}" value="${escaped}"${required}></label>`;
  }
  if (field.type === 'number') {
    return `<label class="field"><small>${label}</small><input type="number" name="${escapeAttr(field.name)}" value="${escaped}"${required}></label>`;
  }
  if (field.type === 'boolean') {
    return `<label class="field field--checkbox"><span><input type="checkbox" name="${escapeAttr(field.name)}" ${value && value !== '0' ? 'checked' : ''}> ${label}</span></label>`;
  }
  if (field.type === 'image') {
    return `<label class="field"><small>${label}</small><input type="text" name="${escapeAttr(field.name)}" value="${escaped}" placeholder="/public/uploads/..."></label>`;
  }
  if (field.type === 'select') {
    const opts = Array.isArray(field.options) ? field.options.filter(function (o) { return typeof o === 'string'; }) : [];
    const current = value == null ? '' : String(value);
    const placeholder = field.required ? '' : `<option value=""${current === '' ? ' selected' : ''}>—</option>`;
    const options = opts.map(function (opt) {
      const sel = opt === current ? ' selected' : '';
      return `<option value="${escapeAttr(opt)}"${sel}>${escapeHtml(opt)}</option>`;
    }).join('');
    return `<label class="field"><small>${label}</small><select name="${escapeAttr(field.name)}"${required}>${placeholder}${options}</select></label>`;
  }

  return `<label class="field"><small>${label}</small><input type="text" name="${escapeAttr(field.name)}" value="${escaped}"${required}></label>`;
}

function formatInputValue(field, value) {
  if (field.type === 'datetime' && value) {
    return String(value).replace(' ', 'T').slice(0, 16);
  }
  return value == null ? '' : String(value);
}

function showError(error) {
  const msg = document.getElementById('ctMsg');
  if (msg) msg.textContent = error.message || String(error);
}

function escapeHtml(value) {
  return String(value || '').replace(/[&<>"']/g, function (char) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
  });
}

function escapeAttr(value) {
  return escapeHtml(value);
}
