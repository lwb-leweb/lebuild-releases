<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../lib.php';

require_auth();
require_plugin_active('content-types');

$type = (string) ($_GET['type'] ?? '');
$id = (int) ($_GET['id'] ?? 0);
if (!content_types_name_valid($type) || $id <= 0) {
    json_response(['ok' => false, 'error' => 'Invalid request'], 400);
}

try {
    $def = content_types_load($type);
    $row = content_types_fetch_by_id($type, $id);
} catch (Throwable $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 400);
}

if (!$row) {
    json_response(['ok' => false, 'error' => 'Not found'], 404);
}

json_response([
    'ok' => true,
    'type' => $type,
    'schema' => content_types_schema_columns($type),
    'row' => $row,
]);
