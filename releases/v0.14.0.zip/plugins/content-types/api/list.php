<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../lib.php';

require_auth();
require_plugin_active('content-types');

$type = (string) ($_GET['type'] ?? '');
if (!content_types_name_valid($type)) {
    json_response(['ok' => false, 'error' => 'Invalid type'], 400);
}

try {
    $def = content_types_load($type);
    $limit = (int) ($_GET['limit'] ?? 200);
    $rows = content_types_fetch_list($type, $limit);
} catch (Throwable $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 400);
}

json_response([
    'ok' => true,
    'type' => $type,
    'label' => $def['label'],
    'schema' => content_types_schema_columns($type),
    'rows' => $rows,
]);
