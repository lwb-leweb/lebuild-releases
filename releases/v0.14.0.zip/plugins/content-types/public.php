<?php
declare(strict_types=1);

// Sicher require_once-bar aus beliebigen PHP-Templates.
// Gibt leere Ergebnisse zurück wenn das Plugin inaktiv oder nicht verfügbar ist.

require_once __DIR__ . '/../../core/plugins.php';

$_state = load_plugins_state();
if (in_array('content-types', $_state['active'] ?? [], true)) {
    require_once __DIR__ . '/lib.php';
}
unset($_state);

function content_types_public_list(string $type, int $limit = 100): array
{
    if (!function_exists('content_types_fetch_list')) {
        return [];
    }
    try {
        return content_types_fetch_list($type, $limit);
    } catch (Throwable $e) {
        return [];
    }
}

function content_types_public_get(string $type, int $id): ?array
{
    if (!function_exists('content_types_fetch_by_id')) {
        return null;
    }
    try {
        return content_types_fetch_by_id($type, $id);
    } catch (Throwable $e) {
        return null;
    }
}
