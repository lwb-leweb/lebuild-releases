# Content-Types Plugin

Framework-Plugin, das beliebig viele Content-Typen (Referenzen, Leistungen, Mitarbeiter, Standorte etc.) als eigene Sidebar-Einträge im Admin bereitstellt. Die Typ-Definitionen liegen pro Kunde als JSON-Dateien in `content/plugins/content-types/` — damit kann jeder Kunde eigene Strukturen haben, ohne dass das Plugin-Repo geforkt werden muss.

## Aktivierung

1. Im Admin auf "Plugins" → "Content-Typen" → aktivieren
2. Beim Aktivieren wird die DB-Tabelle `content_items` angelegt (gemeinsam für alle Typen)
3. Solange `content/plugins/content-types/` leer oder nicht existent ist, erscheint **kein** Sidebar-Eintrag — das ist gewollt
4. Sobald eine Typ-Definition unter `content/plugins/content-types/<name>.json` liegt, taucht "<label>" als eigener Sidebar-Eintrag auf

## Was es kann

- Beliebig viele Content-Typen pro Kunde definieren — jeweils mit eigenem Sidebar-Eintrag
- Jeder Typ hat eigene Felder, unterstützte Typen: `text`, `richtext`, `image`, `datetime`, `number`, `boolean`, `slug`, `select`
- CRUD-UI im Admin pro Typ (Liste, Bearbeiten, Neu, Löschen)
- Listen-Rendering im Frontend per Shortcode
- Presets als Kopiervorlagen unter `plugins/content-types/presets/` (Leistungen, Referenzen, Fakten)

## Im Admin verwenden

**Neuen Typ anlegen:**
1. JSON-Definition unter `content/plugins/content-types/<name>.json` ablegen (Schema siehe unten oder in `AGENT.md`)
2. Admin neu laden → Typ erscheint als Sidebar-Eintrag mit dem `label` aus der Datei
3. Klick auf den Eintrag → CRUD-UI

**Eintrag anlegen:** Sidebar → Typ wählen → "Neuer Eintrag" → Felder ausfüllen → "Speichern"
**Bearbeiten:** In der Liste → "Bearbeiten" → ändern → "Speichern"
**Löschen:** In der Liste → "Löschen" → bestätigen

## API-Endpoints

Alle Endpoints unter `/plugins/content-types/api/`. Auth: gültige Admin-Session. Schreib-Endpoints zusätzlich mit CSRF-Token im Header.

| Endpoint | Methode | Auth | Parameter | Response |
|---|---|---|---|---|
| `list.php` | GET | Session | `?type=<name>&limit=<n>` (limit default 200, max 500) | `{ok, type, label, schema, rows[]}` |
| `get.php` | GET | Session | `?type=<name>&id=<int>` | `{ok, type, schema, row}` oder 404 |
| `save.php` | POST | Session + CSRF | JSON-Body `{type, data: {...}, id?}` (id nur beim Update) | `{ok, id}` |
| `delete.php` | POST | Session + CSRF | JSON-Body `{type, id}` | `{ok}` |

**Beispiel — Eintrag erstellen:**

```bash
curl -X POST https://example.com/plugins/content-types/api/save.php \
  -H "Content-Type: application/json" \
  -H "X-CSRF-Token: <token>" \
  -b "session=..." \
  -d '{"type":"referenzen","data":{"kunde":"Acme GmbH","testimonial":"<p>Super Arbeit.</p>"}}'
```

**Beispiel — Liste holen:**

```bash
curl 'https://example.com/plugins/content-types/api/list.php?type=referenzen&limit=20' \
  -b "session=..."
```

## Shortcodes

### `list` — Einträge eines Typs als Liste rendern

Eingebunden via HTML-Container:

```html
<div data-plugin="content-types" data-view="list" data-type="referenzen" data-limit="20"></div>
```

| Attribut (`data-*`) | Type | Default | Pflicht? | Beschreibung |
|---|---|---|---|---|
| `data-type` | string | — | ja | Name des Content-Typs (= Dateiname ohne `.json`) |
| `data-limit` | int | 20 | nein | Max. Anzahl Einträge |

**Output (bei Einträgen):**

```html
<ul class="content-list content-list--<typname>">
  <li class="content-list__item">
    <img class="content-list__image" src="<image-path>" alt="">       <!-- für image-Felder -->
    <div class="content-list__richtext">…sanitized HTML…</div>          <!-- für richtext -->
    <div class="content-list__field content-list__field--<feldname>">  <!-- für text/number/select/etc. -->
      …Wert…
    </div>
  </li>
  …
</ul>
```

**Wenn keine Einträge:**

```html
<p class="content-list content-list--empty">Noch keine Einträge.</p>
```

**Bei Fehler** (ungültiger Typ, Load-Fehler etc.): HTML-Kommentar `<!-- content-types: <message> -->` statt sichtbarer Fehlermeldung.

## Frontend einbinden

### Shortcode (HTML)

In einer beliebigen HTML- oder PHP-Seite unter `public/site/`:

```html
<section>
  <h2>Unsere Referenzen</h2>
  <div data-plugin="content-types" data-view="list" data-type="referenzen" data-limit="20"></div>
</section>
```

`data-type` muss zum Dateinamen einer JSON-Definition in `content/plugins/content-types/` passen.

### PHP-Direktzugriff

Für eigenes Rendering oder wenn nur bestimmte Felder/Formate gebraucht werden:

```php
// Liste holen
$eintraege = content_types_public_list('referenzen', 20);

// Einzelnen Eintrag holen
$eintrag = content_types_public_get('referenzen', $id);
```

`public.php` wird vom Site-Header automatisch geladen — kein `require_once` nötig. Gibt `[]` bzw. `null` zurück wenn das Plugin inaktiv ist — kein Crash. Vorteil gegenüber Shortcode: volle Kontrolle über Markup, Felder und Datenstruktur. Nachteil: kein Standard-Rendering, eigenes HTML nötig.

## Datenbank

**Tabelle `content_items`** — wird beim Plugin-Aktivieren angelegt. Eine Tabelle für ALLE Typen.

| Spalte | Typ | Beschreibung |
|---|---|---|
| `id` | `INT UNSIGNED AUTO_INCREMENT PK` | Eindeutige ID pro Eintrag |
| `content_type` | `VARCHAR(64) NOT NULL` | Name des Typs (= Dateiname ohne `.json`) |
| `data` | `JSON NOT NULL` | Typ-spezifische Felder als JSON-Objekt |
| `sort_order` | `INT NOT NULL DEFAULT 0` | Manuelle Sortierung (UI noch nicht vorhanden) |
| `created_at` | `DATETIME` | Erstellungszeitpunkt |
| `updated_at` | `DATETIME` | Letzte Änderung (auto-update) |

Index `idx_type_sort` auf `(content_type, sort_order, id)` für schnelles Filtern/Sortieren.

## Typ-Definition (JSON-Schema)

Datei `content/plugins/content-types/<name>.json`:

```json
{
  "name": "<name>",
  "label": "<Sidebar-Label>",
  "fields": [
    { "name": "<feldname>", "label": "<Label>", "type": "<typ>", "required": <true|false> }
  ]
}
```

`name` und Dateiname müssen exakt übereinstimmen.

**Verfügbare Feld-Typen:**

| Type | Verwendung | Zusatz-Attribute |
|---|---|---|
| `text` | Kurzer Text | — |
| `richtext` | HTML mit Sanitizing | — |
| `image` | Bild-Pfad (z.B. `/public/uploads/foo.jpg`) | — |
| `datetime` | Datum + Uhrzeit | — |
| `number` | Zahl | — |
| `boolean` | Ja/Nein | — |
| `slug` | URL-Slug, optional aus anderem Feld generiert | `from: "<feldname>"` |
| `select` | Auswahl aus festen Werten | `options: ["A", "B", ...]` (Pflicht) |

Für eine ausführliche KI-Anleitung zum Anlegen neuer Typen siehe `AGENT.md` in diesem Ordner.

## Bekannte Einschränkungen

- **Keine Single-View-Routen** pro Eintrag (keine URL-Routen wie `/referenzen/acme`). Nur Listen-Rendering per Shortcode. Detailseiten müssen statisch als eigene HTML-Seite mit eigenem Shortcode/Markup gebaut werden.
- **Sortier-UI fehlt** — `sort_order` Spalte existiert, aber im Admin gibt es noch keine Drag-Drop-Sortierung. Aktuell sortiert nach `sort_order ASC, id DESC`.
- **Typ-Erstellung nur per JSON-Datei** im Dateisystem, keine Admin-UI dafür. Das ist bewusst — Typen sind Code-Artefakte und gehören in den Deploy-Workflow, nicht in die Live-DB.
- **Updater-Schutz** — `content/plugins/content-types/` liegt unter `content/` und ist damit kunden-spezifisch (wird vom Updater nicht überschrieben).

## Changelog

- **2026-05-21 — v1.2.0** — `public.php` hinzugefügt: PHP-Direktzugriff auf Einträge ohne HTTP-Umweg. `content_types_public_list()` und `content_types_public_get()` mit eingebautem Plugin-Active-Guard. README und AGENT.md aktualisiert.
- **2026-05-21 — v1.1.0** — `select`-Feldtyp ergänzt (Schema-Attribut `options: [...]` Pflicht). Betrifft `core/pluginSchema.php` (Normalizer) und `plugins/content-types/admin/module.js` (rendert `<select>`). Erstes Beispiel: `content/plugins/content-types/mitarbeiter.json`.
- **2026-05-21 — Security-Fix** — In `api/list.php` und `api/get.php` Reihenfolge von `require_auth()` und `require_plugin_active()` getauscht (Auth zuerst, analog zu save/delete). Defense-in-Depth.
- **2026-05-20 — v1.0.0** — Erstes Release: Manifest, install/uninstall-SQL für `content_items`, `lib.php` (Typ-Loader, CRUD-Helfer, Multi-Entry-Sidebar-Hook), 4 CRUD-API-Endpoints (`list`/`get`/`save`/`delete`), generisches Admin-Modul mit Form-Renderer für alle Feldtypen, Listen-Shortcode-Renderer, 3 Presets (Leistungen, Referenzen, Fakten), `AGENT.md` für KI-Agenten. Begleitende Core-Änderungen: `core/plugins.php` lernt Multi-Entry-Sidebar-Hook, Admin-Frontend (`main.js` + `router.js`) lernt Sub-Routes (`plugin/<name>/<sub>`).
