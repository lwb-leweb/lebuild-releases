<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/mail.php';
require_once __DIR__ . '/../../core/utils.php';

// Spamschutz-Konstanten (siehe docs/contact-form-plugin-spec.md).
const CONTACT_FORM_HONEYPOT   = 'url';   // verstecktes Feld; nur Bots fuellen es aus
const CONTACT_FORM_RATE_MAX   = 5;       // max. Submits pro IP und Fenster
const CONTACT_FORM_RATE_WINDOW = 3600;   // Fenster in Sekunden (60 Min)

function contact_form_config_recipient(): string
{
    return core_mail_default_recipient();
}

function contact_form_signature(string $recipient): string
{
    return hash_hmac('sha256', 'contact-form-recipient|' . $recipient, app_secret());
}

function contact_form_verified_recipient(string $recipient, string $signature): string
{
    if ($recipient !== '' && filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
        $expected = contact_form_signature($recipient);
        if (hash_equals($expected, $signature)) {
            return $recipient;
        }
    }

    return contact_form_config_recipient();
}

/**
 * Whitelist optionaler Zusatzfelder. Schluessel = POST-Feldname, Wert = Label im
 * Mailtext. Reihenfolge = Reihenfolge im Mailtext. Labels generisch halten; ein
 * site-spezifisches Body-Label ist ein spaeteres, admin-konfigurierbares v2-Thema.
 * Nur Felder aus dieser Liste landen in der Mail -- niemals beliebige $_POST-Keys.
 */
function contact_form_extra_fields(): array
{
    return [
        'company'  => 'Firma',
        'phone'    => 'Telefon',
        'telegram' => 'Telegram',
        'subject'  => 'Betreff',
    ];
}

/**
 * Honeypot: ist das versteckte Feld vorhanden UND befuellt, ist es ein Bot.
 * Fehlt das Feld (alte Formulare), wird nicht geblockt.
 */
function contact_form_honeypot_tripped(): bool
{
    return trim((string) ($_POST[CONTACT_FORM_HONEYPOT] ?? '')) !== '';
}

/**
 * Erfolgs-/Honeypot-Antwort: 303-Redirect auf den Referer. Bewusst identisch
 * fuer beide Faelle, damit ein Honeypot-Treffer wie ein Erfolg aussieht.
 */
function contact_form_submit_redirect(): void
{
    http_response_code(303);
    header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? '/'));
}

function contact_form_rate_dir(): string
{
    return CACHE_ROOT . '/contact-form/ratelimit';
}

/**
 * Datei pro IP. Keine Roh-IP speichern -- nur per HMAC mit dem Installations-Schlüssel.
 */
function contact_form_rate_file(): string
{
    $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
    $hash = substr(hash_hmac('sha256', $ip, app_secret()), 0, 32);

    return contact_form_rate_dir() . '/' . $hash . '.json';
}

/**
 * Liest die Timestamps der aktuellen IP und verwirft alles ausserhalb des Fensters.
 */
function contact_form_rate_timestamps(): array
{
    $raw = @file_get_contents(contact_form_rate_file());
    if ($raw === false) {
        return [];
    }

    $data = json_decode($raw, true);
    if (!is_array($data)) {
        return [];
    }

    $cutoff = time() - CONTACT_FORM_RATE_WINDOW;
    $valid = [];
    foreach ($data as $ts) {
        $ts = (int) $ts;
        if ($ts > $cutoff) {
            $valid[] = $ts;
        }
    }

    return $valid;
}

/**
 * false = gesperrt. Prueft nur, schreibt nichts.
 */
function contact_form_rate_check(): bool
{
    return count(contact_form_rate_timestamps()) < CONTACT_FORM_RATE_MAX;
}

/**
 * Haengt einen Timestamp an. Nur nach einem erfolgreichen, validen Versand
 * aufrufen -- sonst fuellen Bots das Fenster mit Garbage und sperren echte Nutzer.
 * Schreibt atomar via tmp + rename.
 */
function contact_form_rate_hit(): void
{
    $timestamps = contact_form_rate_timestamps();
    $timestamps[] = time();

    ensure_dir(contact_form_rate_dir());

    $file = contact_form_rate_file();
    $tmp = $file . '.' . bin2hex(random_bytes(4)) . '.tmp';
    if (file_put_contents($tmp, json_encode(array_values($timestamps)), LOCK_EX) === false) {
        @unlink($tmp);
        return;
    }
    if (!rename($tmp, $file)) {
        @unlink($tmp);
    }
}
