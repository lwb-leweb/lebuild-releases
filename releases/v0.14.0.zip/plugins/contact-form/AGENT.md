# Contact-Form Plugin -- Anleitung fuer KI-Agenten

## Was das Plugin tut

Das Plugin rendert ein einfaches Kontaktformular per Shortcode und sendet die Nachricht an den konfigurierten Standard-Empfaenger oder an einen signierten Shortcode-Empfaenger.
Der Versand laeuft immer ueber den Core-Mailer (`core/mail.php`), der SMTP nutzt, wenn `core/mail.config.php` vorhanden ist, und sonst auf PHP `mail()` zurueckfaellt.
Es schuetzt sich selbst per Honeypot und datei-basiertem IP-Rate-Limit (kein externer Dienst, keine DB) und kann optionale Zusatzfelder ueber eine Whitelist im Plugin-Code in den Mailtext aufnehmen.

## Was du als KI tun darfst

- Formularfelder im Renderer erweitern, wenn die Submit-Validierung synchron angepasst wird.
- Betreff, Textformat und Redirect-Verhalten vorsichtig anpassen.
- Sicherheitslogik fuer Spam-Schutz ergaenzen, z.B. Honeypot oder Rate-Limit.
- Dokumentation und Changelog bei jeder funktionalen Aenderung aktualisieren.

## Was du NICHT anfassen darfst

- Keine SMTP-Logik in dieses Plugin kopieren. Mailversand gehoert in `core/mail.php`.
- Keine SMTP-Passwoerter in `content/config.json`, Page-JSON oder Plugin-Manifest speichern.
- Die Empfaenger-Signatur nicht entfernen, weil sonst Formular-Posts beliebige Empfaenger setzen koennten.
- Keine Datenbank-Abhaengigkeit einbauen.

## Dateistruktur

- `plugin.json` -- Manifest, Shortcode-Definition und Mail-Capability.
- `lib.php` -- Empfaenger-Ermittlung, signierte Empfaenger-Felder, Feld-Registry (`contact_form_extra_fields`), Honeypot- und Rate-Limit-Helper, Spamschutz-Konstanten.
- `api/submit.php` -- oeffentlicher Frontend-Endpoint fuer Formular-Posts (Honeypot -> Rate-Limit -> Validierung -> Whitelist-Body -> Versand).
- `render/form.php` -- Shortcode-Renderer fuer das Formular (inkl. Honeypot- und Registry-Feldern).
- `AGENT.md` -- diese Arbeitsanleitung.
- `README.md` -- Nutzer- und Entwicklerdokumentation.

## Datenbank

Keine Datenbank. Das Plugin speichert selbst keine Inhalte. Der Rate-Limit-State liegt wegwerfbar unter `content/cache/contact-form/ratelimit/<hash>.json` -- nur gehashte IP + Timestamps, niemals Roh-IP.

## Haeufige Anpassungen -- wie geht das?

Neues Pflicht-Formularfeld hinzufuegen:
1. Feld in `render/form.php` rendern.
2. Wert in `api/submit.php` lesen, validieren und in den Mailtext aufnehmen.
3. README und Changelog aktualisieren.

Optionales Zusatzfeld (Whitelist) hinzufuegen:
1. Schluessel + Label in `contact_form_extra_fields()` in `lib.php` ergaenzen (Reihenfolge = Reihenfolge im Mailtext, Label generisch halten).
2. Mehr ist nicht noetig: `render/form.php` rendert das Feld automatisch, `api/submit.php` liest, bereinigt (`core_mail_clean_header`, max. 200 Zeichen) und haengt es an den Body. Niemals beliebige `$_POST`-Keys uebernehmen -- nur die Registry.
3. Kein reservierter Key (`name`, `email`, `message`, `recipient`, `recipient_sig`, der Honeypot) gehoert in die Registry.
4. README und Changelog aktualisieren.

Standard-Empfaenger aendern:
1. Nicht im Plugin hart codieren.
2. Admin -> Einstellungen -> E-Mail / SMTP -> Standard-Empfaenger nutzen.
3. Alternativ im Shortcode `data-recipient` setzen; der Renderer signiert diesen Wert per HMAC mit `app_secret()`.

Mailversand anpassen:
1. Nur den Aufruf von `core_mail_send()` in `api/submit.php` anpassen.
2. Transportdetails bleiben im Core-Mailer.

## Fehlervermeidung

- `api/submit.php` bleibt bewusst ohne Admin-Auth, weil Website-Besucher das Formular absenden muessen.
- Dynamische Werte im Renderer immer mit `htmlspecialchars()` escapen.
- Besucher-E-Mail nur als `Reply-To` verwenden, nicht als SMTP-Absender.
- Fehlerdetails aus SMTP nicht im Frontend ausgeben; sie koennen interne Hostnamen verraten.
- Honeypot-Treffer NIE mit `400`/`500` beantworten -- immer mit `303` wie ein Erfolg (`contact_form_submit_redirect()`), sonst lernen Bots den Mechanismus.
- Rate-Limit-Counter (`contact_form_rate_hit()`) erst NACH erfolgreichem `core_mail_send()` hochzaehlen. Die Pruefung (`contact_form_rate_check()`) laeuft davor. Sonst fuellen Bots das Fenster mit Garbage-Posts und sperren echte Nutzer aus.
- Niemals die Roh-IP im Rate-Limit-State speichern, nur den HMAC mit dem Installations-Schlüssel (`hash_hmac('sha256', IP, app_secret())`).
- `subject` aus der Registry ist nur ein Body-Feld und darf den Mail-Betreff NICHT setzen (Header-Injection). Betreff bleibt `Kontaktformular: {name}`.
- Hinter Cloudflare/Proxy ist `REMOTE_ADDR` die Proxy-IP -- das Rate-Limit greift dann global. `X-Forwarded-For` wird bewusst nicht vertraut (spoofbar).
