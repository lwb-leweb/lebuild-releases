<?php
require_once __DIR__ . '/../lib.php';

$recipient = (string) ($attrs['recipient'] ?? contact_form_config_recipient());
$signature = contact_form_signature($recipient);
?>
<form class="contact-form" method="post" action="/plugins/contact-form/api/submit.php">
  <input type="hidden" name="recipient" value="<?= htmlspecialchars($recipient) ?>">
  <input type="hidden" name="recipient_sig" value="<?= htmlspecialchars($signature) ?>">
  <div class="contact-form-hp" aria-hidden="true" style="position:absolute;left:-9999px;top:auto;width:1px;height:1px;overflow:hidden;">
    <label>Bitte leer lassen<input type="text" name="<?= htmlspecialchars(CONTACT_FORM_HONEYPOT) ?>" autocomplete="off" tabindex="-1"></label>
  </div>
  <label>Name<input type="text" name="name" required></label>
  <label>E-Mail<input type="email" name="email" required></label>
  <?php foreach (contact_form_extra_fields() as $key => $label): ?>
  <label><?= htmlspecialchars($label) ?><input type="text" name="<?= htmlspecialchars($key) ?>"></label>
  <?php endforeach ?>
  <label>Nachricht<textarea name="message" rows="5" required></textarea></label>
  <button type="submit">Absenden</button>
</form>
