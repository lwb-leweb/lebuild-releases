<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../lib.php';

require_plugin_active('contact-form');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo 'Method not allowed';
    return;
}

// Honeypot: Treffer sehen aus wie Erfolg (303 auf Referer), damit Bots den
// Mechanismus nicht erkennen. Kein Mailversand.
if (contact_form_honeypot_tripped()) {
    contact_form_submit_redirect();
    return;
}

// Rate-Limit nach Honeypot, vor Validierung/Versand. Nur Pruefung -- der
// Counter wird erst nach erfolgreichem Versand hochgezaehlt (siehe unten).
if (!contact_form_rate_check()) {
    http_response_code(429);
    echo 'Zu viele Anfragen, bitte später erneut.';
    return;
}

$name = trim(strip_tags((string) ($_POST['name'] ?? '')));
$email = trim((string) ($_POST['email'] ?? ''));
$message = trim(strip_tags((string) ($_POST['message'] ?? '')));
$recipient = trim((string) ($_POST['recipient'] ?? ''));
$signature = trim((string) ($_POST['recipient_sig'] ?? ''));

if ($name === '' || $email === '' || $message === '') {
    http_response_code(400);
    echo 'Fehlende Felder.';
    return;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo 'Ungültige E-Mail.';
    return;
}

$recipient = contact_form_verified_recipient($recipient, $signature);
if ($recipient === '') {
    http_response_code(500);
    echo 'Empfänger-Adresse nicht konfiguriert.';
    return;
}

// Betreff bleibt serverseitig fix. Ein vom Client gesetztes `subject` ist nur
// ein Body-Feld (siehe Whitelist unten) und ueberschreibt den Header nicht.
$subject = 'Kontaktformular: ' . substr($name, 0, 60);

// Body: Name + E-Mail, dann die befuellten Whitelist-Felder (Registry-Reihenfolge),
// dann eine Leerzeile und die eigentliche Nachricht. Niemals beliebige $_POST-Keys.
$lines = [
    'Name: ' . $name,
    'E-Mail: ' . $email,
];
foreach (contact_form_extra_fields() as $key => $label) {
    $value = core_mail_clean_header((string) ($_POST[$key] ?? ''));
    if ($value === '') {
        continue;
    }
    $value = function_exists('mb_substr') ? mb_substr($value, 0, 200) : substr($value, 0, 200);
    $lines[] = $label . ': ' . $value;
}
$body = implode("\n", $lines) . "\n\n" . $message . "\n";

try {
    core_mail_send([
        'to' => $recipient,
        'subject' => $subject,
        'text' => $body,
        'replyTo' => $email,
    ]);
} catch (Throwable $e) {
    error_log('contact-form mail failed: ' . $e->getMessage());
    http_response_code(500);
    echo 'Versand fehlgeschlagen.';
    return;
}

// Counter erst nach erfolgreichem Versand hochzaehlen.
contact_form_rate_hit();

contact_form_submit_redirect();
