<?php
require_once __DIR__ . '/../lib.php';

$label = (string) ($attrs['label'] ?? 'Cookie-Einstellungen');
?>
<a href="#cookie-settings" class="cc-settings-link" data-cc-settings-link><?= htmlspecialchars($label) ?></a>
