# Cookie-Banner Plugin -- Anleitung fuer KI-Agenten

## Was das Plugin tut

DSGVO/TTDSG-konformer Cookie-Banner. Blockt Drittanbieter-Inhalte (YouTube, GA, Maps, Pixel...) per Server-seitigem HTML-Rewriting, bis der Besucher zustimmt. Banner laeuft nur im Site-Output, nicht im Admin. Consent liegt ausschliesslich im `localStorage` des Besuchers, kein Server-Logging.

## Was du als KI tun darfst

- Service-Registry in `services.php` erweitern (neue Drittanbieter mit `category`, `hosts`, `type`, `placeholder`).
- Default-Texte und Default-Kategorien in `cookie_banner_default_config()` anpassen.
- Banner-Styles in `render/banner.php` (inline `<style>`) feintunen.
- Granular-Loading-Logik im Banner-JS verbessern.
- Admin-UI-Felder erweitern, wenn neue Konfig-Werte dazukommen.
- README.md + Changelog bei jeder funktionalen Aenderung pflegen.

## Was du NICHT anfassen darfst

- **Kein Server-Logging des Consents.** Weder DB noch Logfiles fuer Consent-Entscheidungen.
- **Kein Cookie fuer den Consent.** Nur `localStorage`. Cookies waeren wieder zustimmungspflichtig.
- **Service-Registry kein Admin-UI.** Erweiterung ausschliesslich im Plugin-Code.
- **"Akzeptieren" nicht prominenter als "Ablehnen".** Drei gleich grosse Buttons, gleiche Hierarchie.
- **Kein blockierender Modal-Overlay ("Cookie-Wall").** Banner ist Slide-in unten, Seite bleibt nutzbar.
- **Default-Checkboxen nicht-notwendiger Kategorien nicht auf `checked`.** Deny-by-Default.
- **Google Fonts nicht in `necessary` einsortieren**, um Banner zu umgehen -- stattdessen beim Import lokalisieren.
- **`filter_site_html` nicht fuer Side-Effects** (DB-Writes, Mails) nutzen -- nur Transformation.

## Dateistruktur

- `plugin.json` -- Manifest, Shortcode-Definition fuer `settings-link`, Admin-Sidebar.
- `lib.php` -- Konfig-Loader, Service-Matching, `filter_site_html`-Hook, HTML-Rewriting fuer Iframes/Scripts, Banner-Injection vor `</body>`.
- `services.php` -- Service-Registry (Plugin-gepflegt, kein UI).
- `render/banner.php` -- Banner-HTML inkl. Inline-CSS und Inline-JS.
- `render/settings-link.php` -- Shortcode-Renderer fuer Widerruf-Link.
- `admin/module.js` -- Admin-UI: Texte, Kategorien, Version-Bump, Service-Liste.
- `admin/icon.svg` -- Sidebar-Icon.
- `api/get.php` / `api/save.php` -- Admin-API fuer Konfig.
- `AGENT.md` -- diese Datei.
- `README.md` -- Nutzer-Doku.

Konfig-Storage: `content/plugins/cookie-banner/config.json` (über `plugin_data_path('cookie-banner')`). Wird beim Speichern automatisch angelegt.

## Datenbank

Keine. Bewusste Entscheidung -- Consent ist Client-Zustand, alles andere ist JSON.

## Haeufige Anpassungen -- wie geht das?

**Neuen Drittanbieter hinzufuegen:**
1. Eintrag in `services.php` ergaenzen mit `category`, `hosts` (Array), `type` (`iframe` oder `script`), optional `placeholder`-Key.
2. Pruefen, dass die Kategorie in `cookie_banner_default_config()` existiert.
3. README.md unter "Erkannte Drittanbieter" aktualisieren.
4. Plugin-Version in `plugin.json` patchen (Minor bei neuem Service).

**Neue Kategorie hinzufuegen:**
1. Default in `cookie_banner_default_config()` ergaenzen.
2. Hinweis im Admin: Version muss vom Admin manuell hochgezaehlt werden, damit Bestandsbesucher neu zustimmen.

**Banner-Styles aendern:**
1. Inline-`<style>` in `render/banner.php` anpassen.
2. Klassen-Praefix `cc-` einhalten, damit kein Konflikt mit Site-Styles entsteht.

**Settings-Link irgendwo einbinden:**
- `<div data-plugin="cookie-banner" data-view="settings-link" data-label="Cookie-Einstellungen"></div>` -- rendert einen Link, der `window.cookieBanner.open()` triggert.

## Fehlervermeidung

- `filter_site_html` wird **fuer jede Site-Seite** aufgerufen. Frueh-Exit bei `!cookie_banner_enabled()` ist Pflicht.
- HTML-Rewriting ist regex-basiert -- bewusst defensiv (skipt Tags mit bereits gesetzten `data-cc`-Attributen, prueft `about:blank`/`data:`/`javascript:`).
- Banner-JS muss idempotent gegen mehrfaches Init sein. Aktuell genuegt eine einzige `<script>`-Insertion pro Seite.
- Inline-Scripts (`<script>...</script>` ohne `src`) werden **nicht** automatisch erkannt. Entwickler muss diese manuell mit `<script type="text/plain" data-cc="statistics">...</script>` markieren.
- `iframe`/`script` ohne erkanntes Service-Host werden unveraendert durchgereicht -- nicht versehentlich alles blockieren.
- Admin-API: `require_auth()` vor `require_plugin_active()`, `require_csrf()` nur bei POST.
- Consent-Storage hat `v` (Version) -- wenn der Admin die Version hochzaehlt, wird der gespeicherte Consent ungueltig und das Banner erscheint erneut.
