# Cookie-Banner Plugin

DSGVO/TTDSG-konformer Cookie-Banner. Blockt Drittanbieter-Embeds (YouTube, Google Analytics, Google Maps, Meta-Pixel, Hotjar etc.) so lange, bis der Besucher zustimmt. Editor-Nutzer muss nichts ins HTML schreiben -- Erkennung und Markierung passieren automatisch beim Page-Render.

## Aktivierung

1. Im Admin auf "Plugins verwalten" -> "Cookie-Banner" -> aktivieren.
2. Sidebar-Eintrag "Cookie-Banner" erscheint -- dort Texte, Kategorien und Datenschutz-URL pflegen.
3. Beim Speichern wird `content/plugins/cookie-banner/config.json` angelegt.
4. Der Banner erscheint automatisch auf allen Site-Seiten (`/public/site/*`), nicht im Admin.

Keine Datenbanktabelle. Keine Migrationen.

## Was es kann

- Server-seitiges HTML-Rewriting: `<iframe>` und `<script src="...">` von bekannten Diensten werden vor der Auslieferung geblockt.
- Banner als Slide-in unten -- nicht-blockierend, keine "Cookie-Wall".
- Drei gleich prominente Buttons: Ablehnen | Einstellungen | Alle akzeptieren.
- Kategorie-Auswahl mit Deny-by-Default (alle ausser `necessary` standardmaessig aus).
- Granularer "Inhalt laden"-Button am einzelnen Embed-Platzhalter, ohne globalen Consent zu aendern.
- Consent als `localStorage`-Eintrag `cc_consent`, kein Cookie, kein Server-Log.
- Version-Counter: bei Aenderung an Texten/Kategorien manuell hochzaehlen -> alle Besucher muessen erneut zustimmen.
- `cc:consent`-Event fuer andere Plugins (z.B. Tracking-Plugin), wird bei Page-Load und nach Auswahl gefeuert.

## Im Admin verwenden

**Banner-Texte aendern:** Sidebar -> "Cookie-Banner" -> Felder ausfuellen -> "Speichern".

**Datenschutz-URL:** Pfad zur Datenschutzerklaerung (z.B. `/datenschutz` oder `/public/site/impressum.php`).

**Neue Kategorie anlegen:** "Kategorie hinzufuegen" -> ID (kebab-case), Label, optional "erforderlich" -> speichern. Tipp: Beim Hinzufuegen oder Aendern von Kategorien zusaetzlich "Version hochzaehlen" anhaken, damit Bestandsbesucher erneut zustimmen.

**Consent neu erzwingen:** Checkbox "Beim Speichern Version hochzaehlen" anhaken -> bei der naechsten Anzeige sehen alle Besucher den Banner erneut.

**Service-Registry:** Read-only. Liste der erkannten Drittanbieter (Plugin-gepflegt). Erweiterungen kommen ueber Plugin-Updates.

## API-Endpoints

Alle Endpoints unter `/plugins/cookie-banner/api/`. Auth: gueltige Admin-Session. Schreib-Endpoints zusaetzlich mit CSRF-Token.

| Endpoint | Methode | Auth | Parameter | Response |
|---|---|---|---|---|
| `get.php` | GET | Session | -- | `{ok, config, services[]}` |
| `save.php` | POST | Session + CSRF | JSON `{config, bumpVersion?}` | `{ok, config}` |

**Beispiel -- Konfig speichern und Version hochzaehlen:**

```bash
curl -X POST https://example.com/plugins/cookie-banner/api/save.php \
  -H "Content-Type: application/json" \
  -H "X-CSRF-Token: <token>" \
  -b "session=..." \
  -d '{"config":{"texts":{"intro":"..."}},"bumpVersion":true}'
```

## Shortcodes

### `settings-link` -- Widerruf-/Wieder-Oeffnen-Link

```html
<div data-plugin="cookie-banner" data-view="settings-link" data-label="Cookie-Einstellungen"></div>
```

| Attribut | Type | Default | Beschreibung |
|---|---|---|---|
| `data-label` | string | `Cookie-Einstellungen` | Link-Text |

Output: `<a href="#cookie-settings" class="cc-settings-link" data-cc-settings-link>Cookie-Einstellungen</a>`. Klick oeffnet das Banner mit Kategorie-Auswahl.

## Frontend einbinden

Der Banner selbst muss **nicht** eingebunden werden. Er wird automatisch via `filter_site_html`-Hook vor `</body>` jeder Site-Seite injiziert, solange das Plugin aktiv und in der Konfig `enabled: true` ist.

Im Footer empfiehlt sich der Settings-Link, damit Besucher ihre Auswahl spaeter widerrufen koennen:

```html
<footer>
  ...
  <div data-plugin="cookie-banner" data-view="settings-link"></div>
</footer>
```

### Eigene Scripts/Iframes mit Consent koppeln

**Automatisch erkannt** werden alle `<iframe>` und `<script src="...">` zu Hosts aus der Registry (YouTube, GA, Maps etc.).

**Inline-Scripts** (kein `src`) muessen manuell markiert werden:

```html
<script type="text/plain" data-cc="statistics">
  // dieser Code laeuft erst nach Consent fuer "statistics"
  console.log('Tracking aktiv');
</script>
```

**Eigene Plugins**, die Drittanbieter laden, hoeren auf das Consent-Event:

```js
window.addEventListener('cc:consent', function (event) {
  var cats = event.detail.categories;
  if (cats.statistics) {
    // erst jetzt initialisieren
  }
});
```

Das Event feuert beim Page-Load (wenn gueltiger Consent existiert) und nach jeder Auswahl.

## Konfig-Datei

Liegt unter `content/plugins/cookie-banner/config.json`. Struktur:

```json
{
  "enabled": true,
  "version": 1,
  "categories": [
    { "id": "necessary",  "label": "Notwendig",  "required": true },
    { "id": "statistics", "label": "Statistik",  "required": false },
    { "id": "marketing",  "label": "Marketing",  "required": false }
  ],
  "texts": { "title": "...", "intro": "...", "accept": "...", "reject": "...", "settings": "...", "save": "...", "policyLink": "Datenschutzerklaerung" },
  "policyUrl": "/datenschutz",
  "placeholder": {
    "default": "Externer Inhalt blockiert. Klicken, um zu laden.",
    "youtube": "Video laden? Es werden Daten an YouTube uebertragen.",
    "maps": "Karte laden? Es werden Daten an Google uebertragen."
  }
}
```

`version` wird vom Admin manuell hochgezaehlt (oder per Checkbox beim Speichern), damit gespeicherter Consent ungueltig wird.

## Erkannte Drittanbieter

| Service | Kategorie | Typ | Hosts |
|---|---|---|---|
| youtube | marketing | iframe | youtube.com, youtu.be, youtube-nocookie.com |
| vimeo | marketing | iframe | player.vimeo.com, vimeo.com |
| gmaps | marketing | iframe | google.com/maps, maps.google.com |
| ga4 | statistics | script | googletagmanager.com, google-analytics.com |
| meta-pixel | marketing | script | connect.facebook.net |
| hotjar | statistics | script | static.hotjar.com, script.hotjar.com |

Google Fonts ist bewusst **nicht** enthalten -- Fonts werden beim Import lokalisiert.

## Bekannte Einschraenkungen

- Inline-Scripts und manuell platzierte Tracker werden nicht automatisch erkannt -- Entwickler muss `type="text/plain" data-cc="..."` setzen.
- Kein MutationObserver-Fallback fuer Embeds, die per JS nachtraeglich ins DOM kommen.
- Kein Geo-Targeting (Banner zeigt weltweit; das ist rechtlich okay).
- Single-Language: Texte sind ein Set, kein Multi-Lang.
- Kein Server-seitiges Consent-Logging (bewusste Designentscheidung -- weniger Aufwand, datenschutzfreundlicher).

## Changelog

- **2026-05-22 -- v0.1.0** -- Erstes Release: `filter_site_html`-Hook, Iframe-/Script-Rewriting, Banner mit Inline-CSS+JS, `localStorage`-Consent, Admin-UI fuer Texte/Kategorien/Version, `settings-link`-Shortcode, Service-Registry mit YouTube/Vimeo/Maps/GA4/Meta-Pixel/Hotjar.
