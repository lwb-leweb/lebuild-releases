<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../lib.php';

require_auth();
require_plugin_active('cookie-banner');
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => 'Method not allowed'], 405);
}

$body = read_json_body();
$incoming = is_array($body['config'] ?? null) ? $body['config'] : [];
$bumpVersion = !empty($body['bumpVersion']);

if ($bumpVersion) {
    $current = cookie_banner_load_config();
    $incoming['version'] = (int) ($current['version'] ?? 1) + 1;
}

try {
    cookie_banner_save_config($incoming);
} catch (Throwable $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 400);
}

json_response(['ok' => true, 'config' => cookie_banner_load_config()]);
