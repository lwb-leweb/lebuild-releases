<?php
declare(strict_types=1);

/**
 * Service-Registry: Plugin-gepflegt, kein Admin-UI.
 * Erweiterung erfolgt im Plugin-Code als Teil von Plugin-Updates.
 * Google Fonts bewusst NICHT enthalten -> beim Import lokalisieren.
 */
return [
    'youtube' => [
        'category' => 'marketing',
        'hosts' => ['youtube.com', 'youtu.be', 'youtube-nocookie.com'],
        'type' => 'iframe',
        'placeholder' => 'youtube',
    ],
    'vimeo' => [
        'category' => 'marketing',
        'hosts' => ['player.vimeo.com', 'vimeo.com'],
        'type' => 'iframe',
        'placeholder' => 'default',
    ],
    'gmaps' => [
        'category' => 'marketing',
        'hosts' => ['google.com/maps', 'maps.google.com', 'www.google.com/maps'],
        'type' => 'iframe',
        'placeholder' => 'maps',
    ],
    'ga4' => [
        'category' => 'statistics',
        'hosts' => ['googletagmanager.com', 'google-analytics.com'],
        'type' => 'script',
        'placeholder' => 'default',
    ],
    'meta-pixel' => [
        'category' => 'marketing',
        'hosts' => ['connect.facebook.net'],
        'type' => 'script',
        'placeholder' => 'default',
    ],
    'hotjar' => [
        'category' => 'statistics',
        'hosts' => ['static.hotjar.com', 'script.hotjar.com'],
        'type' => 'script',
        'placeholder' => 'default',
    ],
];
