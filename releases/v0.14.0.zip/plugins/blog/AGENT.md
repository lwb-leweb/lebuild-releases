# Blog Plugin — Anleitung für KI-Agenten

## Was das Plugin tut

Verwaltet Blog-Posts mit Titel, Slug, Bild, Richtext-Body und Veröffentlichungsdatum. Posts können als Entwurf (kein `published`-Datum) oder terminiert (zukünftiges Datum) gespeichert werden und erscheinen erst im Frontend wenn `published <= NOW()`.

## Was du als KI tun darfst

- Felder in `plugin.json` (unter `schema.fields`) ergänzen und `lib.php` entsprechend anpassen
- Render-Templates (`render/list.php`, `render/single.php`) für neues Markup anpassen
- `admin/module.js` für neue Felder oder UI-Tweaks erweitern
- `public.php` um neue Wrapper-Funktionen ergänzen (nur Lese-Funktionen)
- Neue API-Endpoints unter `api/` hinzufügen (gleiche Pflicht-Header wie bestehende)

## Was du NICHT anfassen darfst

- `install.sql` ohne explizite Anweisung — Tabellen-Änderungen brauchen eine Migration
- `core/pluginSchema.php` — das ist ein geteiltes Core-File
- Andere Plugins

## Dateistruktur

```
plugins/blog/
├── plugin.json         Manifest: Felder, Shortcodes, Admin-Sidebar
├── AGENT.md            Diese Datei
├── README.md           Menschenlesbare Doku
├── install.sql         Legt Tabelle blog_posts an
├── uninstall.sql       Löscht Tabelle blog_posts
├── lib.php             CRUD-Helfer (fetch_list, fetch_by_slug, save, delete)
├── public.php          PHP-Direktzugriff für eigene Templates (plugin-active-guard)
├── api/
│   ├── list.php        GET: Liste aller Posts (Auth: Session)
│   ├── get.php         GET: Einzelner Post by ID (Auth: Session)
│   ├── save.php        POST: Anlegen/Updaten (Auth: Session + CSRF)
│   └── delete.php      POST: Löschen (Auth: Session + CSRF)
├── admin/
│   └── module.js       Custom Admin-UI mit Slug-Generator und Datumsfeld
└── render/
    ├── list.php        Shortcode-Renderer für Post-Liste
    └── single.php      Shortcode-Renderer für einzelnen Post (by Slug)
```

## Datenbank

**Tabelle `blog_posts`:**

| Spalte | Typ | Beschreibung |
|---|---|---|
| `id` | `INT UNSIGNED AUTO_INCREMENT PK` | — |
| `title` | `VARCHAR(255) NOT NULL` | Titel |
| `slug` | `VARCHAR(255) NOT NULL UNIQUE` | URL-Slug, aus Titel generiert |
| `image` | `VARCHAR(500)` | Pfad zu `/public/uploads/...` oder leer |
| `body` | `LONGTEXT` | Sanitized HTML |
| `published` | `DATETIME` | Leer = Entwurf, Zukunft = terminiert, Vergangenheit = live |
| `created_at` | `DATETIME` | Auto-gesetzt beim Insert |
| `updated_at` | `DATETIME` | Auto-update on change |

## Häufige Anpassungen

**Neues Feld hinzufügen (z.B. `excerpt`):**
1. In `plugin.json` unter `schema.fields` ergänzen
2. In `lib.php` → `blog_save()` das neue Feld in `$values` aufnehmen und im `INSERT`/`UPDATE` ergänzen
3. In `admin/module.js` → `fieldInput()` oder Formular-HTML ergänzen
4. In `render/list.php` oder `render/single.php` ausgeben
5. `version` in `plugin.json` hochzählen, README Changelog-Eintrag

**Shortcode in PHP-Template nutzen:**

```php
$posts = blog_public_list(5);       // neueste 5 veröffentlichte Posts
$post  = blog_public_get('mein-slug'); // einzelner Post by Slug
```

Kein `require_once` nötig — der Site-Header lädt `public.php` automatisch.

## Fehlervermeidung

- `slug` muss UNIQUE sein — `blog_save()` macht kein automatisches Deduping bei Konflikten, Exception bei Collision
- `published` ist `null` für Entwürfe, nicht leer string — `blog_normalize_datetime('')` gibt `null` zurück
- `blog_fetch_list()` filtert standardmäßig auf `published <= NOW()` — für Admin-Ansicht `$publicOnly = false` übergeben
- `body`-Feld immer durch `plugin_sanitize_richtext()` — niemals raw HTML direkt ausgeben
