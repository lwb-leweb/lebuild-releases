let outletEl = null;
let ctxRef = null;

const blogModule = {
  id: 'blog',
  mount(outlet, ctx) {
    outletEl = outlet;
    ctxRef = ctx;
    renderShell();
    loadList();
  },
  unmount() {
    if (ctxRef && ctxRef.ui && ctxRef.ui.closeModal) ctxRef.ui.closeModal();
    outletEl = null;
    ctxRef = null;
  }
};

export default blogModule;

function renderShell() {
  outletEl.innerHTML = `
    <section class="view-area blog-admin">
      <div class="view-card span-12">
        <div class="topbar">
          <strong>Blog</strong>
          <button type="button" id="blogNewBtn">Neuen Post anlegen</button>
        </div>
        <p id="blogMsg" class="message"></p>
        <div id="blogList" class="generic-list"></div>
      </div>
    </section>
  `;
  document.getElementById('blogNewBtn').addEventListener('click', function () {
    openForm(null);
  });
}

function loadList() {
  ctxRef.api('/plugins/blog/api/list.php?limit=100&admin=1')
    .then(function (data) {
      renderList(data.posts || []);
    })
    .catch(showError);
}

function renderList(posts) {
  const list = document.getElementById('blogList');
  if (!posts.length) {
    list.innerHTML = '<p class="message">Noch keine Posts.</p>';
    return;
  }
  list.innerHTML = '<ul>' + posts.map(function (post) {
    return `
      <li class="generic-list__row" data-id="${post.id}">
        <span class="generic-list__title">
          <strong>${escapeHtml(post.title)}</strong>
          <small>${escapeHtml(post.published || 'unveröffentlicht')}</small>
        </span>
        <div class="generic-list__actions">
          <button type="button" data-action="edit" data-id="${post.id}">Bearbeiten</button>
          <button type="button" data-action="delete" data-id="${post.id}" class="secondary">Löschen</button>
        </div>
      </li>
    `;
  }).join('') + '</ul>';

  list.querySelectorAll('button[data-action="edit"]').forEach(function (button) {
    button.addEventListener('click', function () {
      ctxRef.api('/plugins/blog/api/get.php?id=' + parseInt(button.dataset.id, 10))
        .then(function (data) { openForm(data.post); })
        .catch(showError);
    });
  });
  list.querySelectorAll('button[data-action="delete"]').forEach(function (button) {
    button.addEventListener('click', function () {
      const id = parseInt(button.dataset.id, 10);
      if (!ctxRef.confirm('Post wirklich löschen?')) return;
      ctxRef.api('/plugins/blog/api/delete.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: id })
      }).then(loadList).catch(showError);
    });
  });
}

function openForm(post) {
  const bodyHtml = `
    <form id="blogFormEl" class="settings-form">
      <label class="field"><small>Titel</small><input name="title" required value="${escapeAttr(post ? post.title : '')}"></label>
      <label class="field"><small>Slug</small><input name="slug" required value="${escapeAttr(post ? post.slug : '')}"></label>
      <label class="field"><small>Bild-URL</small><input name="image" value="${escapeAttr(post && post.image ? post.image : '')}" placeholder="/public/uploads/..."></label>
      <label class="field"><small>Veröffentlichung</small><input name="published" type="datetime-local" value="${escapeAttr(post ? toLocalDateTime(post.published) : '')}"></label>
      <label class="field"><small>Inhalt</small><textarea name="body" rows="10">${escapeHtml(post ? post.body : '')}</textarea></label>
    </form>
  `;

  const modal = ctxRef.ui.openModal({
    title: post ? 'Post bearbeiten' : 'Neuer Post',
    bodyHtml: bodyHtml,
    onSubmit: function (ctx) {
      const formEl = ctx.body.querySelector('#blogFormEl');
      const fields = formEl.elements;
      const body = {
        data: {
          title: fields.title.value,
          slug: fields.slug.value,
          image: fields.image.value,
          body: fields.body.value,
          published: fields.published.value
        }
      };
      if (post && post.id) body.id = post.id;

      ctx.setBusy(true);
      ctxRef.api('/plugins/blog/api/save.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      }).then(function () {
        ctx.close('submit');
        loadList();
      }).catch(function (error) {
        ctx.setBusy(false);
        ctx.setMessage(error.message || String(error), false);
      });
    }
  });

  const formEl = modal.body.querySelector('#blogFormEl');
  formEl.addEventListener('submit', function (event) {
    event.preventDefault();
    modal.submitButton.click();
  });
}

function toLocalDateTime(value) {
  if (!value) return '';
  return String(value).replace(' ', 'T').slice(0, 16);
}

function showError(error) {
  const message = document.getElementById('blogMsg');
  if (message) message.textContent = error.message || String(error);
}

function escapeHtml(value) {
  return String(value || '').replace(/[&<>"']/g, function (char) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
  });
}

function escapeAttr(value) {
  return escapeHtml(value);
}
