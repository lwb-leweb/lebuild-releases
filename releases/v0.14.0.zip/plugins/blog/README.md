# Blog Plugin

Blog-Posts mit Titel, Slug, Bild, Richtext-Body und Veröffentlichungsdatum. Unterstützt Entwürfe (kein Datum), terminierte Posts (Zukunftsdatum) und Live-Posts. Rendering via Shortcode oder PHP-Direktzugriff.

## Aktivierung

1. Im Admin auf "Plugins" → "Blog" → aktivieren
2. Beim Aktivieren wird die Tabelle `blog_posts` angelegt
3. Sidebar-Eintrag "Blog" erscheint → Einträge anlegen, bearbeiten, löschen

## Was es kann

- Blog-Posts anlegen mit Titel, Slug (auto-generiert aus Titel), Bild, Richtext-Body, Veröffentlichungsdatum
- Entwurfs-Modus: Post ohne Datum = nicht öffentlich sichtbar
- Terminierung: Post mit Zukunftsdatum = wird erst dann öffentlich
- Listen-Shortcode für Übersichtsseite
- Single-Shortcode für Detailseite (by URL-Slug)
- PHP-Direktzugriff für eigenes Rendering

## Im Admin verwenden

**Post anlegen:** Sidebar → "Blog" → "Neuer Eintrag" → Felder ausfüllen → "Speichern"

**Entwurf:** Veröffentlichungsdatum leer lassen → Post ist nicht öffentlich sichtbar

**Veröffentlichen:** Datum setzen → Post erscheint sobald Datum erreicht ist

**Bearbeiten:** In der Liste → "Bearbeiten" → ändern → "Speichern"

**Löschen:** In der Liste → "Löschen" → bestätigen

## API-Endpoints

Alle Endpoints unter `/plugins/blog/api/`. Auth: gültige Admin-Session. Schreib-Endpoints zusätzlich mit CSRF-Token.

| Endpoint | Methode | Auth | Parameter | Response |
|---|---|---|---|---|
| `list.php` | GET | Session | `?limit=<n>` (default 20) | `{ok, posts[]}` |
| `get.php` | GET | Session | `?id=<int>` | `{ok, post}` oder 404 |
| `save.php` | POST | Session + CSRF | JSON-Body `{title, slug?, image?, body?, published?, id?}` | `{ok, id}` |
| `delete.php` | POST | Session + CSRF | JSON-Body `{id}` | `{ok}` |

**Beispiel — Post erstellen:**

```bash
curl -X POST https://example.com/plugins/blog/api/save.php \
  -H "Content-Type: application/json" \
  -H "X-CSRF-Token: <token>" \
  -b "session=..." \
  -d '{"title":"Mein erster Post","body":"<p>Hallo Welt.</p>","published":"2026-05-21 09:00:00"}'
```

## Shortcodes

### `list` — Post-Liste

```html
<div data-plugin="blog" data-view="list" data-limit="10"></div>
```

| Attribut | Type | Default | Beschreibung |
|---|---|---|---|
| `data-limit` | int | 10 | Max. Anzahl Posts |

Zeigt nur veröffentlichte Posts (`published <= NOW()`).

**Output:**

```html
<ul class="blog-list">
  <li class="blog-list__item">
    <img src="..." alt="">
    <h3><a href="/blog-post.html?slug=<slug>">Titel</a></h3>
    <time>2026-05-21 09:00:00</time>
  </li>
</ul>
```

### `single` — Einzelner Post

```html
<div data-plugin="blog" data-view="single" data-slug="mein-post"></div>
```

Liest `data-slug` aus dem Attribut, fallback auf `$_GET['slug']`. Zeigt "Beitrag nicht gefunden." wenn kein Match.

**Output:**

```html
<article class="blog-post">
  <h1>Titel</h1>
  <img src="..." alt="">
  <time>...</time>
  <div class="blog-post__body">...sanitized HTML...</div>
</article>
```

## Frontend einbinden

### Shortcode (HTML)

Übersichtsseite `public/site/blog.html`:

```html
<div data-plugin="blog" data-view="list" data-limit="10"></div>
```

Detailseite `public/site/blog-post.html`:

```html
<div data-plugin="blog" data-view="single"></div>
```

Slug wird per `?slug=mein-post` als GET-Parameter übergeben.

### PHP-Direktzugriff

Für eigenes Rendering oder wenn nur bestimmte Felder gebraucht werden:

```php
// Liste der neuesten Posts
$posts = blog_public_list(10);

// Einzelner Post by Slug
$post = blog_public_get('mein-post');
```

`public.php` wird vom Site-Header automatisch geladen — kein `require_once` nötig.

Gibt `[]` bzw. `null` zurück wenn das Plugin inaktiv ist — kein Crash.

## Datenbank

**Tabelle `blog_posts`:**

| Spalte | Typ | Beschreibung |
|---|---|---|
| `id` | `INT UNSIGNED AUTO_INCREMENT PK` | — |
| `title` | `VARCHAR(255) NOT NULL` | Titel |
| `slug` | `VARCHAR(255) NOT NULL UNIQUE` | URL-Slug |
| `image` | `VARCHAR(500)` | Pfad oder leer |
| `body` | `LONGTEXT` | Sanitized HTML |
| `published` | `DATETIME` | `NULL` = Entwurf |
| `created_at` | `DATETIME` | Auto |
| `updated_at` | `DATETIME` | Auto-update |

## Bekannte Einschränkungen

- Slug muss eindeutig sein — kein automatisches Deduping bei Konflikten
- Keine Kategorien oder Tags
- Keine Pagination im Shortcode — nur `limit`

## Changelog

- **2026-05-21 — v1.0.0** — Erstes Release: Tabelle `blog_posts`, `lib.php` (fetch_list, fetch_by_slug, save, delete), 4 CRUD-API-Endpoints, Admin-Modul mit Slug-Generator, List- und Single-Shortcode, `public.php` für PHP-Direktzugriff, AGENT.md, README.md.
