<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../lib.php';

require_plugin_active('blog');

$slug = trim((string) ($_GET['slug'] ?? ''));
$id = (int) ($_GET['id'] ?? 0);

$post = null;
if ($id > 0) {
    require_auth();
    $post = blog_fetch_by_id($id);
} elseif ($slug !== '') {
    $post = blog_fetch_by_slug($slug, true);
}

if (!$post) {
    json_response(['ok' => false, 'error' => 'Not found'], 404);
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok' => true, 'post' => $post], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
