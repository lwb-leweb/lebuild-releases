<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../lib.php';

require_auth();
require_csrf();
require_plugin_active('blog');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => 'Method not allowed'], 405);
}

$body = read_json_body();
$id = (int) ($body['id'] ?? 0);
if ($id <= 0) {
    json_response(['ok' => false, 'error' => 'Invalid id'], 400);
}

blog_delete($id);
json_response(['ok' => true]);
