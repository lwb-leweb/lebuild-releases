<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/db.php';
require_once __DIR__ . '/../../core/plugins.php';

function blog_fetch_list(int $limit = 10, bool $publicOnly = true): array
{
    $limit = max(1, min(100, $limit));
    $where = $publicOnly ? 'WHERE published IS NULL OR published <= NOW()' : '';
    $stmt = db()->prepare(
        "SELECT id, title, slug, image, published FROM blog_posts {$where} ORDER BY COALESCE(published, created_at) DESC LIMIT {$limit}"
    );
    $stmt->execute();

    return $stmt->fetchAll();
}

function blog_fetch_by_slug(string $slug, bool $publicOnly = true): ?array
{
    $where = $publicOnly ? ' AND (published IS NULL OR published <= NOW())' : '';
    $stmt = db()->prepare("SELECT * FROM blog_posts WHERE slug = ?{$where} LIMIT 1");
    $stmt->execute([$slug]);
    $row = $stmt->fetch();

    return $row ?: null;
}

function blog_fetch_by_id(int $id): ?array
{
    $stmt = db()->prepare('SELECT * FROM blog_posts WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);
    $row = $stmt->fetch();

    return $row ?: null;
}

function blog_slugify(string $value): string
{
    $value = strtolower(trim(strip_tags($value)));
    $value = preg_replace('/[^a-z0-9]+/', '-', $value) ?? '';
    $value = trim($value, '-');

    return $value !== '' ? $value : 'post';
}

function blog_normalize_datetime(mixed $value): ?string
{
    $text = trim((string) $value);
    if ($text === '') {
        return null;
    }
    $text = str_replace('T', ' ', $text);
    if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $text)) {
        $text .= ':00';
    }

    return preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $text) ? $text : null;
}

function blog_save(array $data, ?int $id = null): int
{
    $title = trim(strip_tags((string) ($data['title'] ?? '')));
    $slug = blog_slugify((string) ($data['slug'] ?? $title));
    if ($title === '') {
        throw new InvalidArgumentException('title required');
    }

    $values = [
        'title' => $title,
        'slug' => $slug,
        'image' => trim(strip_tags((string) ($data['image'] ?? ''))) ?: null,
        'body' => plugin_sanitize_richtext((string) ($data['body'] ?? '')),
        'published' => blog_normalize_datetime($data['published'] ?? ''),
    ];

    if ($id !== null && $id > 0) {
        $stmt = db()->prepare('UPDATE blog_posts SET title = ?, slug = ?, image = ?, body = ?, published = ? WHERE id = ?');
        $stmt->execute([$values['title'], $values['slug'], $values['image'], $values['body'], $values['published'], $id]);

        return $id;
    }

    $stmt = db()->prepare('INSERT INTO blog_posts (title, slug, image, body, published) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$values['title'], $values['slug'], $values['image'], $values['body'], $values['published']]);

    return (int) db()->lastInsertId();
}

function blog_delete(int $id): void
{
    $stmt = db()->prepare('DELETE FROM blog_posts WHERE id = ?');
    $stmt->execute([$id]);
}
