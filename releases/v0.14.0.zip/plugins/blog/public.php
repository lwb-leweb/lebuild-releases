<?php
declare(strict_types=1);

// Sicher require_once-bar aus beliebigen PHP-Templates.
// Gibt leere Ergebnisse zurück wenn das Plugin inaktiv oder nicht verfügbar ist.

require_once __DIR__ . '/../../core/plugins.php';

$_state = load_plugins_state();
if (in_array('blog', $_state['active'] ?? [], true)) {
    require_once __DIR__ . '/lib.php';
}
unset($_state);

function blog_public_list(int $limit = 10): array
{
    if (!function_exists('blog_fetch_list')) {
        return [];
    }
    try {
        return blog_fetch_list($limit);
    } catch (Throwable $e) {
        return [];
    }
}

function blog_public_get(string $slug): ?array
{
    if (!function_exists('blog_fetch_by_slug')) {
        return null;
    }
    try {
        return blog_fetch_by_slug($slug);
    } catch (Throwable $e) {
        return null;
    }
}
