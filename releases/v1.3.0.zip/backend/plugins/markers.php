<?php
declare(strict_types=1);

// Markierungen für Plugin-Listen und -Einträge auf der Seite (data-le-*), damit der Seiten-Editor sie bearbeiten kann.

require_once LE_BACKEND . '/html/markup.php';
require_once LE_BACKEND . '/plugins/plugins.php';

// plugin.json „inlineEdit“: Endpoints für Plugin-Listen auf der Seite; Wert = Pflicht.
const PLUGIN_INLINE_EDIT_ENDPOINTS = ['list' => true, 'get' => true, 'save' => true, 'delete' => true, 'sort' => false];
// Markierungen, an denen der Seiten-Editor Plugin-Listen und ihre Einträge erkennt.
const LE_LIST_ATTR = 'data-le-list';
const LE_ITEM_ATTR = 'data-le-item';
const LE_SINGLE_ATTR = 'data-le-single';
// Am Listen-Element: Ein Klick auf einen Eintrag öffnet beim Bearbeiten immer sein Formular, auch wenn
// der Eintrag ein Link ist (sonst zeigt ein Link „Öffnen →“). Setzen Plugins, deren Einträge als Ganzes
// verlinken (Content-Typen mit Vorlage).
const LE_ITEM_FORM_ATTR = 'data-le-item-form';
// Am Listen-Element: Die Reihenfolge ergibt sich aus den Einträgen (z. B. nach Datum), ↑/↓ entfällt.
const LE_FIXED_ORDER_ATTR = 'data-le-fixed-order';
// Letztes Kind einer Liste: Link „Mehr laden“ auf ihre nächste Seite (z. B. Content-Typen mit data-paging). Der Seiten-Editor
// folgt ihm, wenn ein gespeicherter Eintrag nach dem Neuladen nicht auf der ersten Seite steht.
const LE_MORE_ATTR = 'data-le-more';
// Ereignisse zwischen Seiten-Editor und Skripten der Website (CustomEvent, Namen auch in
// plugins/content-types/assets/modal.js und list.js; ein Test hält sie gleich):
// - LE_LIST_RELOADED_EVENT: am neu geladenen Listen-Element (bubbelt), nachdem der Editor es getauscht hat, ebenso
//   an einer Liste, an die „Mehr laden“ der Content-Typen Einträge gehängt hat;
// - LE_ITEM_DIALOG_EVENT: an document, wenn ein Skript einen Eintrag in einem Dialog zeigt (detail.item:
//   Element im Eintrag) oder ihn schließt (detail.item: null); die Leiste bietet dann „Bearbeiten“.
const LE_LIST_RELOADED_EVENT = 'le-list-reloaded';
const LE_ITEM_DIALOG_EVENT = 'le-item-dialog';
// Beschriftung des Knopfes an der Einzelansicht; das Plugin gibt sie mit, sonst LE_SINGLE_LABEL.
const LE_SINGLE_LABEL_ATTR = 'data-le-single-label';
const LE_SINGLE_LABEL = 'Diesen Beitrag bearbeiten';
// Am <img> eines Bildfelds (le_image): "<typ>.<feld>" (der Browser bekommt beides über le_preview_config). Daran findet das Formular eines Eintrags beim Messen das Bild auf
// den Seiten, an denen es steht (Stellen aus imageUsage), und liest Größe und Stil seines Rahmens.
const LE_FIELD_ATTR = 'data-le-field';
const LE_FIELD_SEPARATOR = '.';
// Wert der Markierung: "<plugin>/<typ>" (Plugin bis zum ersten Trenner).
const LE_KEY_SEPARATOR = '/';
// Richtungen beim Sortieren (inlineEdit „sort“: {type, id, direction}).
const INLINE_EDIT_SORT_UP = 'up';
const INLINE_EDIT_SORT_DOWN = 'down';

/**
 * Was der Seiten-Editor für Plugin-Listen braucht: Endpoints, Markierungen, Trenner, Sortier-Richtungen,
 * Ereignisse und die Beschriftung des Knopfes an Einzelansichten ohne eigene (LE_SINGLE_LABEL).
 */
function plugin_lists_config(): array
{
    return [
        'endpoints' => plugin_inline_edit_config(),
        'attrs' => ['list' => LE_LIST_ATTR, 'item' => LE_ITEM_ATTR, 'single' => LE_SINGLE_ATTR, 'singleLabel' => LE_SINGLE_LABEL_ATTR, 'itemForm' => LE_ITEM_FORM_ATTR, 'fixedOrder' => LE_FIXED_ORDER_ATTR, 'more' => LE_MORE_ATTR],
        'separator' => LE_KEY_SEPARATOR,
        'directions' => ['up' => INLINE_EDIT_SORT_UP, 'down' => INLINE_EDIT_SORT_DOWN],
        'singleLabel' => LE_SINGLE_LABEL,
        'events' => ['listReloaded' => LE_LIST_RELOADED_EVENT, 'itemDialog' => LE_ITEM_DIALOG_EVENT],
    ];
}

/** Attribut, das eine Plugin-Liste für den Seiten-Editor markiert (escaped, auch für Besucher). */
function le_list_attrs(string $plugin, string $type): string
{
    return LE_LIST_ATTR . '="' . markup_attr_escape(le_key($plugin, $type)) . '"';
}

/** Wert der Markierung einer Liste oder Einzelansicht (unescaped). */
function le_key(string $plugin, string $type): string
{
    return $plugin . LE_KEY_SEPARATOR . $type;
}

/** Attribut, das einen Eintrag einer Plugin-Liste markiert. */
function le_item_attrs(int $id): string
{
    return LE_ITEM_ATTR . '="' . $id . '"';
}

/** Markiert die Ausgabe einer Vorlage als Eintrag einer Liste (le_mark mit le_item_attrs()). */
function le_item_mark(string $html, int $id): string
{
    return le_mark($html, [LE_ITEM_ATTR => (string) $id]);
}

/** Markiert die Ausgabe einer Vorlage als Einzelansicht eines Eintrags (le_mark mit le_single_values()). */
function le_single_mark(string $html, string $plugin, string $type, int $id, string $label = LE_SINGLE_LABEL): string
{
    return le_mark($html, le_single_values($plugin, $type, $id, $label));
}

/**
 * Markiert die Ausgabe einer Vorlage ohne zusätzliches Element: die Attribute $attrs (Name → Wert, roh)
 * kommen ins einzige Wurzelelement (z. B. die Karte im Grid der Website). Hat die Ausgabe mehrere
 * Elemente oder Text außerhalb, wird sie in ein markiertes <div> gehüllt.
 */
function le_mark(string $html, array $attrs): string
{
    $doc = markup_parse($html);
    $element = null;
    foreach ($doc['roots'] as $index) {
        $node = $doc['nodes'][$index];
        if ($node['type'] === 'comment' || ($node['type'] === 'text' && trim(substr($html, $node['start'], $node['end'] - $node['start'])) === '')) {
            continue;
        }
        if ($node['type'] !== 'element' || $element !== null) {
            $element = false;
            break;
        }
        $element = $index;
    }
    if (!is_int($element)) {
        return '<div ' . le_attrs($attrs) . '>' . $html . '</div>';
    }

    return markup_apply($html, array_map(static fn (string $name, string $value): array => markup_set_attr($doc, $element, $name, markup_attr_escape($value)), array_keys($attrs), $attrs));
}

/**
 * Attribute für die Einzelansicht eines Eintrags (z. B. eigene Seite eines Content-Typ-Eintrags): bearbeitbar wie ein Listeneintrag,
 * aber keine Liste (kein „+ Hinzufügen“). $label: Beschriftung des Knopfes (Konstante des Plugins), ohne
 * LE_SINGLE_LABEL.
 */
function le_single_attrs(string $plugin, string $type, int $id, string $label = LE_SINGLE_LABEL): string
{
    return le_attrs(le_single_values($plugin, $type, $id, $label));
}

/** Markierung der Einzelansicht als [Name => Wert], roh (le_single_attrs, le_single_mark). */
function le_single_values(string $plugin, string $type, int $id, string $label): array
{
    return [LE_SINGLE_ATTR => le_key($plugin, $type), LE_ITEM_ATTR => (string) $id, LE_SINGLE_LABEL_ATTR => $label];
}

/** Attribute aus [Name => Wert] als Text: Werte escaped, durch Leerzeichen getrennt (le_mark, Vorlagen der Plugins). */
function le_attrs(array $attrs): string
{
    $out = [];
    foreach ($attrs as $name => $value) {
        $out[] = $name . '="' . markup_attr_escape((string) $value) . '"';
    }

    return implode(' ', $out);
}
