<?php
declare(strict_types=1);

// Einträge der Plugins: generisch speichern, löschen samt Bildern, die sonst nirgends verwendet werden (Medien selbst
// sprechen keine Datenbank an), Plugin deinstallieren samt den Bildern seiner Einträge, Version und Konflikt beim
// Speichern, Slugs, Fehlerantwort.

require_once LE_BACKEND . '/base/db.php';
require_once LE_BACKEND . '/plugins/plugins.php';
require_once LE_BACKEND . '/plugins/pluginSchema.php';
require_once LE_BACKEND . '/media/usage.php';
require_once LE_BACKEND . '/base/http.php';
require_once LE_BACKEND . '/base/texts.php';
require_once LE_BACKEND . '/plugins/hooks.php';

/**
 * Gemeinsamer Anfang der generischen Endpunkte (api/plugins/generic/<aktion>.php) für das Plugin $name: aktiv (404, beim
 * Schreiben während eines Umzugs 503), kein eigener Endpunkt für $action (400), lesbare plugin.json (500) und eine
 * Haupttabelle (400 noMainTable). Liefert ['manifest' => …, 'table' => …].
 */
function le_plugin_generic_table(string $name, string $action): array
{
    require_plugin_active($name);
    le_require_generic_endpoint($name, $action);
    $manifest = le_plugin_manifest_or_fail($name);
    $table = plugin_main_table($manifest);
    if ($table === null) {
        json_response(['ok' => false, 'error' => API_TEXT['noMainTable']], 400);
    }
    return ['manifest' => $manifest, 'table' => $table];
}

/**
 * Eintrag eines Plugins ohne eigene Endpunkte speichern (api/plugins/generic/save.php): $body mit 'data' (Werte nach
 * schema.fields), 'id' (> 0: ändern) und für die Prüfung auf fremde Änderungen 'version' und 'overwrite'. Vom Prüfen der
 * Bilder bis zum Aufräumen ersetzter Bilder nacheinander mit dem Erledigen offener Uploads (le_open_uploads_hold), in
 * derselben Reihenfolge wie content_types_save: kein Bild verschwindet mitten im Speichern. Name ungültig 400, inzwischen
 * gelöscht 404, fremd geändert 409, ungültiger Wert 400 (Meldung der Prüfung), keine Felder 400, Datenbank 500.
 * Liefert ['id' => id des Eintrags, 'created' => neu angelegt?].
 */
function le_plugin_generic_save(string $name, array $body): array
{
    // Offene Uploads erst hier: entries.php laden auch Lesen und Löschen der generischen Endpunkte.
    require_once LE_BACKEND . '/media/openUploads.php';
    le_require_plugin_name($name);
    ['manifest' => $manifest, 'table' => $table] = le_plugin_generic_table($name, 'save');
    $fields = plugin_schema_columns($manifest);
    $rawValues = is_array($body['data'] ?? null) ? $body['data'] : [];
    $id = (int) ($body['id'] ?? 0);
    $created = $id <= 0;

    $id = le_open_uploads_hold(static function () use ($table, $fields, $rawValues, $id, $created, $body): int {
        try {
            $stored = $created ? [] : plugin_fetch_row($table, $id);
        } catch (Throwable $e) {
            plugin_failure_response('save', $e);
        }
        if ($stored === null) {
            // Inzwischen gelöscht: nicht als gespeichert melden.
            json_response(['ok' => false, 'error' => API_TEXT['notFound']], 404);
        }
        if (!$created) {
            plugin_entry_conflict_check($body, plugin_entry_version($stored));
        }
        try {
            $values = plugin_schema_column_values(plugin_schema_values($fields, $rawValues, $stored));
        } catch (InvalidArgumentException $e) {
            json_response(['ok' => false, 'error' => $e->getMessage()], 400);
        } catch (Throwable $e) {
            plugin_failure_response('save', $e);
        }

        if (!$values) {
            json_response(['ok' => false, 'error' => API_TEXT['noValidFields']], 400);
        }

        $replaced = [];
        try {
            // Zeitstempel setzt PHP selbst (kein ON UPDATE, SQLite-Zeit wäre UTC),
            // aber nur für Spalten, die die Tabelle hat und das Schema nicht liefert.
            $columns = db_table_columns($table);
            $stamps = $created ? ['created_at', 'updated_at'] : ['updated_at'];
            foreach ($stamps as $stamp) {
                if (in_array($stamp, $columns, true) && !array_key_exists($stamp, $values)) {
                    $values[$stamp] = db_now();
                }
            }

            if (!$created) {
                $sets = [];
                $params = [];
                foreach ($values as $key => $value) {
                    $sets[] = "`{$key}` = ?";
                    $params[] = $value;
                }
                $params[] = $id;
                db()->prepare("UPDATE `{$table}` SET " . implode(', ', $sets) . ' WHERE `id` = ?')->execute($params);
                // Bilder, die der Eintrag nicht mehr nutzt (ersetzt, Zeile entfernt), wenn sie sonst nirgends vorkommen.
                $replaced = array_diff(plugin_schema_image_values($fields, $stored), plugin_schema_image_values($fields, $values + $stored));
            } else {
                $keys = array_keys($values);
                $placeholders = implode(', ', array_fill(0, count($keys), '?'));
                $sql = "INSERT INTO `{$table}` (`" . implode('`, `', $keys) . "`) VALUES ({$placeholders})";
                db()->prepare($sql)->execute(array_values($values));
                $id = (int) db()->lastInsertId();
            }
        } catch (Throwable $e) {
            plugin_failure_response('save', $e);
        }
        delete_unused_uploads($replaced);

        return $id;
    });
    return ['id' => $id, 'created' => $created];
}

/**
 * Löscht den Eintrag $id aus der Haupttabelle des Plugins samt Bildern, die sonst nirgends verwendet werden:
 * lesen, Bildwerte bestimmen, löschen, aufräumen. $where schränkt zusätzlich ein (Spalte => Wert).
 * Bildwerte liefert der Hook „<plugin>_image_values(array $row): array“, sonst die image-Felder aus
 * schema.fields. Kann er sie nicht bestimmen, bleiben die Dateien liegen. Liefert, ob es den Eintrag gab.
 */
function plugin_delete_entry(string $plugin, int $id, array $where = []): bool
{
    $manifest = plugin_manifest($plugin);
    $table = plugin_main_table($manifest);
    if ($table === null) {
        throw new RuntimeException('Plugin has no main table');
    }
    $conditions = ['`id` = ?'];
    $params = [$id];
    foreach ($where as $column => $value) {
        if (!is_string($column) || !plugin_table_name_valid($column)) {
            throw new InvalidArgumentException('Invalid column: ' . $column);
        }
        $conditions[] = "`{$column}` = ?";
        $params[] = $value;
    }
    $condition = implode(' AND ', $conditions);

    $stmt = db()->prepare("SELECT * FROM `{$table}` WHERE {$condition} LIMIT 1");
    $stmt->execute($params);
    $row = $stmt->fetch();
    if (!$row) {
        return false;
    }
    $images = le_plugin_entry_images($plugin, $row);
    db()->prepare("DELETE FROM `{$table}` WHERE {$condition}")->execute($params);
    delete_unused_uploads($images);

    return true;
}

/**
 * Bildwerte einer Rohzeile der Haupttabelle des Plugins: Hook „<plugin>_image_values(array $row): array“, sonst die
 * image-Felder aus schema.fields. Lassen sie sich nicht bestimmen (Hook wirft), keine.
 */
function le_plugin_entry_images(string $plugin, array $row): array
{
    try {
        $fn = plugin_hook_function($plugin, 'image_values');
        $images = $fn !== null ? $fn($row) : plugin_schema_image_values(plugin_schema_columns(plugin_manifest($plugin)), $row);
    } catch (Throwable $e) {
        return [];
    }

    return is_array($images) ? array_values(array_filter($images, 'is_string')) : [];
}

/**
 * Plugin deinstallieren (api/plugins/uninstall.php), so nah an ganz oder gar nicht wie möglich: gültiger Name (400), unter
 * der Sperre des Plugin-Status installiert (le_plugin_installed, sonst 404) und sein Ordner unter plugin_data_path
 * löschbar (le_rrmdir_possible, sonst 500 uninstallFailed); dann deaktivieren, damit seine Hooks wie bei einem inaktiven
 * Plugin laufen (die Content-Typen spielen dabei kein Startpaket ein). Danach die Bilder und Dateien der Einträge seiner
 * Haupttabelle einsammeln (le_plugin_table_images; scheitert das: 500, es bleibt installiert, inaktiv) und erst dann die
 * gemerkten Tabellen löschen (500 uninstallFailed), auch ohne lesbare plugin.json. Ohne gemerkte Tabellen keine
 * Verbindung zur Datenbank. Unter SQLite folgt VACUUM, das den Platz freigibt (nur, wenn es die Datei gibt; sonst legte
 * die Verbindung eine leere an); scheitert es, bleibt die Datei nur größer. Mit den Tabellen ist das Plugin
 * deinstalliert. Erst danach wird aufgeräumt, Fehler nur ins Log: der Ordner (bleibt er, gilt das Plugin weiter als
 * installiert und ein zweiter Versuch löscht ihn) und die eingesammelten Uploads, sofern sonst nirgends verwendet
 * (delete_unused_uploads; was bleibt, räumt le_media_cleanup_if_due später weg). Liefert den neuen Stand.
 */
function le_plugin_uninstall(string $name): array
{
    le_require_plugin_name($name);
    $dir = plugin_data_path($name);
    $state = le_plugins_state_update('uninstall', $name, static function (array &$state) use ($name, $dir): void {
        if (!le_plugin_installed($state, $name)) {
            json_response(['ok' => false, 'error' => API_TEXT['pluginNotInstalled']], 404);
        }
        if (!le_rrmdir_possible($dir)) {
            error_log('plugin uninstall ' . $name . ': cannot remove ' . le_instance_relative($dir));
            json_response(['ok' => false, 'error' => API_TEXT['uninstallFailed']], 500);
        }
        $state['active'] = array_values(array_diff($state['active'], [$name]));
    });
    try {
        $manifest = plugin_manifest($name);
    } catch (Throwable $e) {
        $manifest = null;
    }
    // Ohne lesbare plugin.json (kaputt oder gelöscht) braucht das Plugin eine Datenbank, sobald Tabellen gemerkt sind.
    $tables = plugin_valid_tables($state['installed'][$name]['tables'] ?? []);
    $usesDatabase = $manifest !== null ? !empty($manifest['requires']['database']) : $tables !== [];
    $images = [];
    if ($usesDatabase && $tables !== []) {
        try {
            $images = le_plugin_table_images($name, $manifest, $tables);
            db_drop_tables(db(), $tables);
            // Mit den Tabellen fällt sein Stand des Schemas weg (LE_PLUGIN_SCHEMA_TABLE).
            le_plugin_schema_forget(db(), $name);
        } catch (Throwable $e) {
            error_log('plugin uninstall ' . $name . ': ' . $e->getMessage());
            json_response(['ok' => false, 'error' => API_TEXT['uninstallFailed']], 500);
        }
    }
    if ($usesDatabase && db_driver() === DB_DRIVER_SQLITE && is_file(db_sqlite_path())) {
        try {
            db()->exec('VACUUM');
        } catch (Throwable $e) {
        }
    }
    $state = le_plugins_state_update('uninstall', $name, static function (array &$state) use ($name): void {
        unset($state['installed'][$name]);
    });
    if (!le_rrmdir($dir)) {
        error_log('plugin uninstall ' . $name . ': cannot remove ' . le_instance_relative($dir));
    }
    // Aufräumen erst ohne die Sperre plugins: delete_unused_uploads nimmt die Sperre der offenen Uploads (le_images_forget).
    $state = le_plugins_state_done($state);
    delete_unused_uploads($images);

    return $state;
}

/**
 * Bildwerte aller Einträge der Haupttabelle von $name, wenn sie unter den gemerkten $tables ist und es sie gibt (je Zeile
 * le_plugin_entry_images). Wirft, wenn sich die Zeilen nicht lesen lassen.
 */
function le_plugin_table_images(string $name, ?array $manifest, array $tables): array
{
    $table = $manifest !== null ? plugin_main_table($manifest) : null;
    if ($table === null || !in_array($table, $tables, true) || !db_table_exists(db(), $table)) {
        return [];
    }
    $images = [];
    foreach (db()->query("SELECT * FROM `{$table}`") as $row) {
        array_push($images, ...le_plugin_entry_images($name, $row));
    }

    return $images;
}

// code der 409-Antwort, wenn ein Eintrag seit dem Laden geändert wurde (plugin_entry_conflict_check).
const PLUGIN_ENTRY_CONFLICT_CODE = 'conflict';

/** Stand eines Eintrags (Zeile wie gespeichert, ohne $skip-Spalten): get liefert ihn als version, save vergleicht ihn. */
function plugin_entry_version(array $row, array $skip = []): string
{
    $row = array_diff_key($row, array_flip($skip));
    ksort($row);
    return substr(hash('sha256', (string) json_encode($row, JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR)), 0, 16);
}

/**
 * Speichern eines bestehenden Eintrags: Schickt der Client den Stand beim Laden ($body['version']) und ist der Eintrag
 * seitdem geändert ($current), 409 mit code PLUGIN_ENTRY_CONFLICT_CODE, außer mit $body['overwrite']. Ohne version
 * (ältere Clients, curl) wie bisher: der letzte gewinnt.
 */
function plugin_entry_conflict_check(array $body, string $current): void
{
    $version = $body['version'] ?? null;
    if (is_string($version) && $version !== '' && empty($body['overwrite']) && !hash_equals($current, $version)) {
        json_response(['ok' => false, 'error' => API_TEXT['entryConflict'], 'code' => PLUGIN_ENTRY_CONFLICT_CODE], 409);
    }
}

/**
 * Zeile $id der Tabelle $table eines Plugins (generische Plugins, Einspielen von Plugin-Daten), null ohne. $lock sperrt
 * sie unter MySQL bis zum Ende der laufenden Transaktion (FOR UPDATE, sonst läse InnoDB einen alten Stand); SQLite
 * sperrt beim Schreiben selbst und bricht ab, wenn die Zeile seit dem Lesen geändert wurde.
 */
function plugin_fetch_row(string $table, int $id, bool $lock = false): ?array
{
    $forUpdate = $lock && db_driver() === DB_DRIVER_MYSQL ? ' FOR UPDATE' : '';
    $stmt = db()->prepare("SELECT * FROM `{$table}` WHERE `id` = ? LIMIT 1{$forUpdate}");
    $stmt->execute([$id]);
    $row = $stmt->fetch();

    return $row ?: null;
}

/**
 * Ob eine Spalte aus schema.fields der Haupttabelle die Upload-Datei $file enthält (Bildfeld, Bild in einer
 * Zeile eines list-Feldes oder Verweis im Text). Gilt für jedes Plugin mit Schema, auch ohne lib.php (generisches Admin-Formular).
 */
function plugin_schema_upload_in_use(array $manifest, string $file): bool
{
    $table = plugin_main_table($manifest);
    $columns = plugin_schema_field_names($manifest);
    if ($table === null || $columns === []) {
        return false;
    }
    $where = implode(' OR ', array_map(static fn (string $column): string => "INSTR(`{$column}`, ?) > 0", $columns));
    $stmt = db()->prepare("SELECT 1 FROM `{$table}` WHERE {$where} LIMIT 1");
    $stmt->execute(array_fill(0, count($columns), $file));

    return $stmt->fetchColumn() !== false;
}

/** Antwort, wenn $action ('load', 'save', 'delete', 'sort', 'import') an $e scheitert: Meldung aus PLUGIN_FAILED_TEXT, Fehler ins Log. */
function plugin_failure_response(string $action, Throwable $e): void
{
    error_log('plugin ' . $action . ': ' . $e->getMessage());
    json_response(['ok' => false, 'error' => PLUGIN_FAILED_TEXT[$action]], PLUGIN_FAILED_STATUS);
}

function plugin_schema_slugify(string $value): string
{
    $value = strtr(mb_strtolower(trim($value), 'UTF-8'), PLUGIN_SLUG_TRANSLITERATION);
    $value = preg_replace('/[^a-z0-9]+/', '-', $value) ?? '';
    $value = trim(substr(trim($value, '-'), 0, PLUGIN_SLUG_MAX_LENGTH), '-');

    return $value !== '' ? $value : PLUGIN_SLUG_FALLBACK;
}

/** Slug, der in $table.$column noch frei ist, sonst mit -2, -3 …; die Zeile $id selbst zählt nicht. */
function plugin_unique_slug(string $table, string $column, string $slug, ?int $id): string
{
    $stmt = db()->prepare("SELECT 1 FROM `{$table}` WHERE `{$column}` = ? AND `id` <> ? LIMIT 1");

    return plugin_unique_slug_with($slug, static function (string $candidate) use ($stmt, $id): bool {
        $stmt->execute([$candidate, $id ?? 0]);
        $taken = $stmt->fetchColumn() !== false;
        $stmt->closeCursor();
        return $taken;
    });
}

/** $slug, wenn $taken($slug) false ist, sonst der erste freie mit -2, -3 … (auch für Slugs außerhalb einer Spalte, z. B. im JSON eines Eintrags). */
function plugin_unique_slug_with(string $slug, callable $taken): string
{
    $candidate = $slug;
    for ($n = 2; $taken($candidate); $n++) {
        $candidate = $slug . '-' . $n;
    }

    return $candidate;
}
