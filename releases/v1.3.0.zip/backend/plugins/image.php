<?php
declare(strict_types=1);

// Bilder der Plugins auf der Website: das eine <img> aus einem Bildwert samt Fokuspunkt (Vorlagen und Renderer der Plugins,
// ct_image der Content-Typen). Ein rohes <img in einem Plugin meldet tests/plugins/structure.test.php (R11).

require_once LE_BACKEND . '/html/markup.php';
require_once LE_BACKEND . '/html/textMarkup.php';
require_once LE_BACKEND . '/plugins/markers.php';

// Attribute, die le_image() aus $attrs übernimmt: Laden steuern (fetchpriority="high" für das größte Bild oben,
// loading="lazy" weiter unten), Klasse, sizes und die Maße. Alle anderen (style, on*, src, alt …) fallen weg.
const LE_IMAGE_ATTRS = ['loading', 'fetchpriority', 'decoding', 'class', 'sizes', 'width', 'height'];

/**
 * <img> eines Bildwerts: src nach der Bildregel wie beim Speichern (sanitize_field_value, kein javascript: oder data:),
 * alt, aus $attrs nur LE_IMAGE_ATTRS mit einzelnem Wert, dazu style="object-position: …", wenn $focus ein gültiger
 * Fokuspunkt ist (le_focus_valid; leer oder ungültig: kein style), und LE_FIELD_ATTR, wenn $field das Bildfeld nennt
 * (le_field_key; leer: kein Attribut). Alle Werte escaped (le_attrs); ohne Bild ''.
 */
function le_image(string $value, string $alt = '', array $attrs = [], string $focus = '', string $field = ''): string
{
    $src = sanitize_field_value('image', $value);
    if ($src === '') {
        return '';
    }
    $extra = array_intersect_key(array_filter($attrs, 'is_scalar'), array_flip(LE_IMAGE_ATTRS));
    $style = $focus !== '' && le_focus_valid($focus) ? ['style' => le_markup_style_declaration(LE_FOCUS_IMAGE_PROPERTY, $focus)] : [];
    $mark = $field !== '' ? [LE_FIELD_ATTR => $field] : [];

    return '<img ' . le_attrs(['src' => $src, 'alt' => $alt] + $extra + $style + $mark) . '>';
}

/** Wert für LE_FIELD_ATTR (unescaped): "<typ>.<feld>", z. B. team.bild. */
function le_field_key(string $type, string $field): string
{
    return $type . LE_FIELD_SEPARATOR . $field;
}
