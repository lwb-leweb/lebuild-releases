<?php
declare(strict_types=1);

// Helfer der Vorlagen der Website für Content-Typen (public/includes/content-types/<typ>/): der Vertrag mit den
// Vorlagen der Kunden, Namen und Ausgabe bleiben. Die Helfer escapen selbst, auch für Attribute (data-category="…"
// mit ct_text).

// Karte mit Ziel modal: öffnet den versteckten Inhalt mit gleicher id (Modal-Skript des Plugins).
const CONTENT_TYPES_OPEN_ATTR = 'data-ct-open';
const CONTENT_TYPES_MODAL_ATTRS = ['role' => 'button', 'tabindex' => '0', 'aria-haspopup' => 'dialog'];

// Mit ['size' => true] setzt ct_image() width und height aus der Datei. Nur auf Wunsch: Ohne height: auto (oder feste
// Höhe) im CSS der Website würde das Bild sonst in der Originalhöhe gezeichnet.
const CONTENT_TYPES_IMAGE_SIZE = 'size';

/** Eintrag, den die Vorlage gerade ausgibt (wie $item, aber sicher vor Includes der Website); außerhalb []. */
function ct_item(): array
{
    return content_types_current()['item'];
}

/** Typ-Definition des Eintrags, den die Vorlage gerade ausgibt (wie $type); außerhalb []. */
function ct_type(): array
{
    return content_types_current()['type'];
}

/** In page.php: fertige Ausgabe von detail.php (wie $detail); sonst ''. */
function ct_detail(): string
{
    return content_types_current()['detail'];
}

/** Text eines Feldes, escaped (auch für Attribute); Listen und fehlende Felder ergeben ''. */
function ct_text(array $item, string $field): string
{
    $value = $item[$field] ?? '';

    return is_scalar($value) ? markup_attr_escape((string) $value) : '';
}

/** Mehrzeiliger Text (textarea) eines Feldes, escaped, Zeilenumbrüche als <br>; Listen und fehlende Felder ergeben ''. */
function ct_lines(array $item, string $field): string
{
    $value = $item[$field] ?? '';

    return is_scalar($value) ? le_text_lines((string) $value) : '';
}

/** Formatierter Text (richtext) eines Feldes, bereinigt wie beim Speichern. */
function ct_rich(array $item, string $field): string
{
    $value = $item[$field] ?? '';

    return is_string($value) ? plugin_sanitize_richtext($value) : '';
}

/**
 * Bild eines Bildfeldes über le_image (Bildregel wie beim Speichern, erlaubte Attribute LE_IMAGE_ATTRS), Alt-Text aus dem
 * Feld $altField, Fokuspunkt aus <feld>_focus des Eintrags (auch ohne Felddefinition, etwa in Blöcken); ohne Bild ''.
 * Typ und Feld (LE_FIELD_ATTR) nur für den Eintrag der Vorlage, die gerade läuft (gleiche id wie ct_item, Typ ct_type),
 * nicht für Zeilen (ct_rows) und Blöcke mit einem Feld gleichen Namens.
 */
function ct_image(array $item, string $field, string $altField = '', array $attrs = []): string
{
    $entry = isset($item['id']) && $item['id'] === (ct_item()['id'] ?? null);

    return content_types_image($entry ? ct_type() : [], $item, $field, $altField, $attrs);
}

/**
 * ct_image für den Typ $def (auch die Liste ohne Vorlage): Ist $field ein Bildfeld der obersten Ebene von $def, trägt das
 * <img> LE_FIELD_ATTR mit "<typ>.<feld>" (le_field_key), sonst nicht (kein Typ, Unterfeld, andere Art).
 */
function content_types_image(array $def, array $item, string $field, string $altField = '', array $attrs = []): string
{
    // Bereinigt schon hier, weil die Maße aus der Datei dieselbe Adresse brauchen, die le_image ausgibt.
    $src = is_string($item[$field] ?? null) ? sanitize_field_value('image', $item[$field]) : '';
    $alt = $altField !== '' && is_scalar($item[$altField] ?? null) ? (string) $item[$altField] : '';
    $focus = $item[$field . LE_FOCUS_ID_SUFFIX] ?? '';
    $size = $src !== '' && !empty($attrs[CONTENT_TYPES_IMAGE_SIZE]) ? content_types_image_size($src) : [];
    $mark = isset($def['name']) && content_types_image_field($def, $field) ? le_field_key((string) $def['name'], $field) : '';

    return le_image($src, $alt, $size + $attrs, is_string($focus) ? $focus : '', $mark);
}

/**
 * width und height eines Bildes der Website (Pfad wie /public/site/uploads/x.webp oder assets/img/x.jpg), damit der
 * Browser den Platz vor dem Laden kennt (kein Verrutschen); [] für fremde Adressen, fehlende Dateien und SVG ohne Maße.
 */
function content_types_image_size(string $src): array
{
    if (preg_match('#^[a-z][a-z0-9+.-]*:|^//#i', $src)) {
        return [];
    }
    $file = le_site_request_file('/' . ltrim(explode('?', $src, 2)[0], '/'));
    $size = $file !== null ? @getimagesize($file) : false;

    return is_array($size) && $size[0] > 0 && $size[1] > 0 ? ['width' => (string) $size[0], 'height' => (string) $size[1]] : [];
}

/**
 * <svg> eines Icon-Feldes (Satz des Seiten-Editors, Attribute wie beim Tausch auf der Seite), $size Pixel
 * breit und hoch, aria-hidden; ohne Icon ''.
 */
function ct_icon(array $item, string $field, int $size = 24): string
{
    $name = is_string($item[$field] ?? null) ? le_icon_name($item[$field]) : '';
    if ($name === '') {
        return '';
    }
    $attrs = ['xmlns' => 'http://www.w3.org/2000/svg', 'width' => (string) $size, 'height' => (string) $size]
        + LE_ICON_SVG_ATTRS + LE_ICON_SVG_DEFAULTS + ['aria-hidden' => 'true'];

    return '<svg ' . le_attrs($attrs) . '>' . LE_ICON_SET[$name][0] . '</svg>';
}

/** Zeilen eines list-Feldes; jede lässt sich wie $item mit den Helfern ausgeben. */
function ct_rows(array $item, string $field): array
{
    return plugin_schema_list_rows($item[$field] ?? null);
}

/**
 * Attribute für das Element, das die Vorlage mit ct_tag() öffnet: link und page href (extern mit
 * target/rel), modal CONTENT_TYPES_OPEN_ATTR mit der id und Rolle eines Knopfes; none ''.
 */
function ct_action_attrs(array $item): string
{
    $target = content_types_item_target($item);
    if ($target['href'] !== '') {
        return ct_url_attrs($target, 'href');
    }
    if ($target['action'] === 'modal') {
        return le_attrs([CONTENT_TYPES_OPEN_ATTR => (int) ($item['id'] ?? 0)] + CONTENT_TYPES_MODAL_ATTRS);
    }

    return '';
}

/**
 * Attribute für einen Link auf die Adresse eines url-Feldes (auch in Zeilen aus ct_rows): href, bei einem
 * anderen Host mit target/rel (le_url_link_attrs, wie beim Klickziel); ohne erlaubte Adresse ''.
 */
function ct_url_attrs(array $item, string $field): string
{
    $value = $item[$field] ?? '';
    $href = is_string($value) ? sanitize_url($value, TEXT_LINK_SCHEMES) : '';

    return $href === '' ? '' : le_attrs(['href' => $href] + le_url_link_attrs($href));
}

/**
 * Blöcke eines blocks-Feldes als HTML in ihrer Reihenfolge: je Art die Vorlage der Website
 * (CONTENT_TYPES_TEMPLATE_DIR/_blocks/<art>.php mit $block und $item, Werte über die ct_-Helfer), sonst
 * das schlichte Markup aus content_types_block_html (Klassen ct-block, ct-block--<art>). Unbekannte Arten
 * fallen weg; wirft eine Vorlage, steht für den Block ein Kommentar (Grund im Log).
 */
function ct_blocks(array $item, string $field): string
{
    $html = '';
    foreach (plugin_schema_list_rows($item[$field] ?? []) as $block) {
        $type = $block[PLUGIN_SCHEMA_BLOCK_TYPE] ?? null;
        if (!is_string($type) || !isset(PLUGIN_SCHEMA_BLOCKS[$type])) {
            continue;
        }
        $path = CONTENT_TYPES_TEMPLATE_DIR . '/' . CONTENT_TYPES_BLOCK_DIR . '/' . $type . '.php';
        $html .= is_file($path) ? (content_types_render_block($path, $block, $item) ?? content_types_render_comment('template')) : content_types_block_html($type, $block);
    }

    return $html;
}

/**
 * Adresse (escaped, für href) der Liste mit data-id $list auf $path (Vorgabe: die aktuelle Seite), gefiltert nach dem
 * Wert von $field, z. B. die Kategorie auf einer Karte der Startseite zur Blogseite. '' ohne Wert und wenn der Wert
 * keine Option des Auswahlfeldes im Typ der Vorlage (ct_type) ist, etwa nach dem Löschen der Kategorie (die Liste
 * käme ungefiltert). Wirft bei einer ungültigen ID (in einer Vorlage: Kommentar statt der Karte, Grund im Log).
 */
function ct_filter_href(array $item, string $field, string $list, ?string $path = null): string
{
    content_types_list_id_check($list);
    $value = content_types_row_text($item, $field) ?? '';
    $select = array_column(content_types_schema_columns(ct_type() + ['fields' => []]), null, 'name')[$field] ?? null;
    if ($value === '' || $select === null || !in_array($value, content_types_select_options($select), true)) {
        return '';
    }

    return markup_attr_escape(content_types_list_href($path ?? content_types_request_path(), [content_types_list_param($list, $field) => plugin_schema_slugify($value)]));
}

/** Element für einen Eintrag: a bei link und page, sonst div. */
function ct_tag(array $item): string
{
    return content_types_item_target($item)['href'] !== '' ? 'a' : 'div';
}
