// Texte des Formulars und Namen eines Eintrags (Titelfeld, Anzeigename, Titel einer Kopie, Rückfrage beim Löschen).

export const ENTRY_TEXT = {
  add: 'Neu',
  edit: 'Bearbeiten',
  // Kopieren eines Eintrags (Knopf auf der Seite und in der Verwaltung) und Titel des Formulars der Kopie (copyTitle).
  copy: 'Kopieren',
  copyTitle: 'Kopie: {name}',
  save: 'Speichern',
  cancel: 'Abbrechen',
  untitled: '(ohne Titel)',
  // Speichern mit veraltetem Stand (409 conflict, plugin_entry_conflict_check): Rückfrage im Backend-Modal.
  conflictPanel: 'Jemand anderes hat diesen Eintrag gespeichert, seit du ihn geöffnet hast. Deine Fassung überschreibt die andere ganz.',
  conflictAsk: 'Jemand anderes hat diesen Eintrag inzwischen geändert.\n\nOK: deine Fassung speichern (überschreibt die andere).\nAbbrechen: nichts speichern.',
  conflictTheirs: 'Stattdessen die andere Fassung ins Formular laden? Deine Eingaben gehen dabei verloren.',
  // Ebene „Ausschnitt“ mit Änderungen schließen (×, Esc, Klick daneben), Rückfrage im Backend-Modal.
  framingDiscard: 'Änderungen am Ausschnitt verwerfen?',
  emptyOption: '—',
  deleteQuestion: '‚{name}‘ löschen?',
  remove: 'Entfernen',
  richtextRequired: '„{name}“ bitte ausfüllen.',
  addRow: '+ {name} hinzufügen',
  addRowFallback: '+ Zeile hinzufügen',
  addOption: '+ {name} hinzufügen',
  addOptionPrompt: '{name} hinzufügen:',
  rowUp: '↑',
  rowDown: '↓',
  rowUpLabel: 'Nach oben',
  rowDownLabel: 'Nach unten',
  slugEdit: 'Adresse ändern',
  slugAuto: 'entsteht beim Speichern aus „{name}“',
  addImages: '+ {name} hinzufügen',
  imagesUploaded: '{count} Bilder hochgeladen.',
  imageReplace: 'Bild ersetzen (ziehen zum Verschieben)',
  imageMissing: 'Bild wählen',
  otherFile: 'Anderes PDF',
  fileOpen: 'Datei in neuem Tab öffnen',
  imageUploading: 'Lädt …',
  imageBefore: 'Nach vorne',
  imageAfter: 'Nach hinten',
  imageRemove: 'Bild entfernen',
  imagesTooMany: 'Höchstens {max} {name}; die übrigen Dateien sind nicht hochgeladen.',
  addBlock: '+ {name}',
  blockCollapse: 'Einklappen',
  blockExpand: 'Aufklappen',
  blockImages: '{count} Fotos',
  blockFiles: '{count} Downloads',
  blockRemove: 'Block entfernen',
  blockMove: 'Ziehen zum Verschieben'
};
// Felder, die einen Eintrag benennen (vor dem ersten Textfeld).
const TITLE_FIELDS = ['name', 'title'];
const TITLE_FALLBACK_TYPE = 'text';

// Beschriftung eines Feldes: label aus dem Schema, sonst sein Name.
export function fieldLabel(field) {
  return field.label ? field.label : field.name;
}

// Feld, das einen Eintrag benennt: name oder title, sonst das erste Textfeld (null ohne).
export function titleField(schema) {
  const named = schema.find(function (field) { return TITLE_FIELDS.indexOf(field.name) !== -1; });
  if (named) return named.name;
  const text = schema.find(function (field) { return field.type === TITLE_FALLBACK_TYPE; });
  return text ? text.name : null;
}

// Anzeigename eines Eintrags (Listen im Backend, Nachfrage beim Löschen).
export function entryTitle(schema, row) {
  const name = titleField(schema);
  if (!name) return '#' + row.id;
  return row[name] ? String(row[name]) : ENTRY_TEXT.untitled;
}

// „‚Max Muster‘ löschen?“ – als Text für confirm(), nie als HTML.
export function deleteQuestion(schema, row) {
  // Ersatz als Funktion: „$&“ o. Ä. im Namen bleibt wörtlich stehen.
  const title = entryTitle(schema, row);
  return ENTRY_TEXT.deleteQuestion.replace('{name}', function () { return title; });
}

// „Kopie: Max Muster“ – Titel des Formulars einer Kopie, Name aus dem Original (ohne Titelfeld „Kopie: #12“).
export function copyTitle(schema, row) {
  const title = entryTitle(schema, row);
  return ENTRY_TEXT.copyTitle.replace('{name}', function () { return title; });
}
