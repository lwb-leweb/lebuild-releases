// Aussehen des Formulars: Klassen im Backend-Modal (BACKEND_LOOK; im Seiten-Editor PAGE_LOOK in plugin-lists.js)
// und welche Feldarten bei zwei Spalten in die Spalte der Angaben kommen.

// Formular mit split: Felder dieser Arten (Angaben wie Kategorie, Datum, Bild) kommen in die Spalte look.side,
// Zeilen und Blöcke (list, blocks) unter beide Spalten (look.full), die übrigen (Titel, Texte) in look.main; ohne Felder einer
// Gruppe bleibt es einspaltig.
// Eine Adresse (slug) mit from steht ohnehin unter ihrem Quellfeld (meist der Titel).
export const SIDE_FIELD_TYPES = ['select', 'datetime', 'date', 'number', 'boolean', 'url', 'image', 'file', 'icon'];
// Klassen im Backend-Modal (app/css/entry-form.css).
export const BACKEND_LOOK = {
  form: 'settings-form entry-form',
  field: 'field',
  labelTag: 'small',
  label: '',
  checkbox: 'field field--checkbox',
  picker: 'entry-form__picker',
  image: 'entry-form__image',
  imageEmpty: 'entry-form__image-empty',
  imageDrop: 'entry-form__drop',
  imageDropActive: 'entry-form__drop--active',
  imageActions: 'entry-form__image-actions',
  file: 'entry-form__file',
  list: 'entry-form__list',
  listRow: 'entry-form__row',
  listRowActions: 'entry-form__row-actions',
  iconGrid: { grid: 'entry-form__icons', item: 'entry-form__icon', empty: 'entry-form__icons-empty' },
  iconButton: 'entry-form__icon-btn',
  slug: 'entry-form__slug',
  slugText: 'entry-form__slug-text',
  slugAuto: 'entry-form__slug-text--auto',
  slugInput: 'entry-form__slug-input',
  gallery: 'entry-form__gallery',
  galleryActive: 'entry-form__gallery--active',
  galleryTile: 'entry-form__tile',
  galleryPending: 'entry-form__tile--pending',
  galleryMedia: 'entry-form__tile-media',
  galleryCaption: 'entry-form__tile-caption',
  galleryActions: 'entry-form__tile-actions',
  blocks: 'entry-form__blocks',
  block: 'entry-form__block',
  blockHead: 'entry-form__block-head',
  blockTitle: 'entry-form__block-title',
  blockSummary: 'entry-form__block-summary',
  blockBody: 'entry-form__block-body',
  blockCollapsed: 'entry-form__block--collapsed',
  blockAdd: 'entry-form__block-add',
  // Knöpfe des Ausschnitts im Bildfeld (framingField: text, option) und der Ebene „Ausschnitt“ (openImageFraming;
  // Hauptaktion im Stil von base.css, ohne Klasse).
  framing: { primary: '', secondary: 'entry-form__picker', text: 'entry-form__text-btn', option: 'entry-form__picker entry-form__picker--pill', close: 'entry-form__icon-btn' }
};
