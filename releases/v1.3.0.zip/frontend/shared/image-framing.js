import { state } from './core.js';
import { editorButton } from './buttons.js';
import { sheet } from './sheet.js';
import { holdSaveKey } from './save-key.js';
import { icon, symbolButton } from './icons.js';
import { imageInfo, deriveImage, uploadPending, settledAction, holdUpload, imagePicker, imageDropArea, dropFiles } from './upload.js';
import { errorNotice } from './request.js';
import {
  framingPath, CORNERS, FIT_COVER, focusText, focusParse, ratioOf, fullRect, formatRect, movedRect, anchorOf, resizedRect,
  cropMin, cropOf, rectOf, sameCrop, formatOf, rectPercent, pointIn, focusPoint, cropFocus, clampToRect, previewRatio,
  previewPlacement, groupPlaces, joinNames
} from './framing-geometry.js';

// Baustein „Ausschnitt im Feld“ (framingField): Zuschnitt und Fokuspunkt direkt im Bild, in Feldbreite. Rahmen mit vier
// Ecken und Drittel-Linien auf dem Original (api/imageInfo.php), außen abgedunkelt, darin der Fokuspunkt. Nach dem
// Loslassen rechnet der Server den Zuschnitt (api/imageDerive.php, der Browser schickt nur Koordinaten). Darunter
// Hinweis, Vorschauen der gemessenen Stellen (framing-measure.js) und Formate.
// Genutzt im Eintragsformular (Bildfeld), im Panel „Bild“ des Seiten-Editors und in der Ebene des Bildrasters (mountFraming).
// Maus und Touch über Pointer-Ereignisse. Rechnung in framing-geometry.js, Aussehen in image-framing.css.

// Formate des Zuschnitts ([Breite, Höhe], null = frei); die Beschriftung entsteht aus dem Verhältnis.
export const FRAMING_FORMATS = [{ ratio: null }, { ratio: [1, 1] }, { ratio: [4, 3] }, { ratio: [16, 9] }];
// Kleinste Seite des Zuschnitts in Pixeln des Originals (bei kleineren Bildern das Bild).
const CROP_MIN = 120;
// Angezeigt ist der Rahmen mindestens CROP_MIN_TARGETS Greifflächen (CROP_TARGET_VAR, die Fläche einer Ecke in
// image-framing.css) breit und hoch: Jede Ecke nimmt eine halbe nach innen, in der Mitte bleibt eine ganze zum Verschieben.
const CROP_TARGET_VAR = '--le-touch-target';
const CROP_MIN_TARGETS = 2;
// Seitenverhältnis des Bildes bzw. einer Vorschau für das CSS (Breite des Bildes, Form der Vorschau).
const RATIO_VAR = '--le-framing-ratio';
// So lange nach dem Loslassen (ms) wartet der Zuschnitt, ob gleich weiter gezogen wird; erst dann rechnet der Server.
const DERIVE_DELAY = 400;
// Ab so vielen CSS-Pixeln Bewegung verschiebt ein Druck auf den Rahmen ihn, darunter ist es ein Tippen (Fokus).
const TAP_SLOP = 5;
const RATIO_SEPARATOR = ':';

export const FRAMING_TEXT = {
  // Knopf an einer Kachel des Bildrasters und Titel ihrer Ebene.
  title: 'Ausschnitt',
  original: 'Original',
  cancel: 'Abbrechen',
  apply: 'Übernehmen',
  close: 'Schließen',
  free: 'Frei',
  formats: 'Format',
  otherImage: 'Anderes Bild',
  drop: 'Bild hier ablegen',
  hint: 'Tipp auf das Wichtigste im Bild, es bleibt dann überall sichtbar. Ecken ziehen schneidet zu.',
  // Ohne Speicherort für den Fokus (focus null) nur der Teil zum Zuschnitt.
  cropHint: 'Ecken ziehen schneidet zu.',
  // Stellen gleicher Form in einer Zeile: „Startseite, Team und Über uns“.
  comma: ', ',
  and: ' und '
};

const CLASSES = {
  view: 'le-framing',
  head: 'le-framing__head',
  tools: 'le-framing__tools',
  tool: 'le-framing__tool',
  remove: 'le-framing__remove',
  hint: 'le-framing__hint',
  pick: 'le-framing__pick',
  pickFocus: 'le-framing__pick--focus',
  image: 'le-framing__image',
  drop: 'le-framing__drop',
  marker: 'le-framing__marker',
  places: 'le-framing__places',
  place: 'le-framing__place',
  placeName: 'le-framing__place-name',
  previews: 'le-framing__previews',
  preview: 'le-framing__preview',
  previewFrame: 'le-framing__preview-frame',
  previewClip: 'le-framing__preview-clip',
  previewImage: 'le-framing__preview-image',
  crop: 'le-framing__crop',
  clip: 'le-framing__clip',
  shade: 'le-framing__shade',
  handle: 'le-framing__handle',
  formats: 'le-framing__formats',
  layer: 'le-framing-layer',
  layerBox: 'le-framing-layer__box'
};
const CORNER_ATTR = 'data-corner';
// Breite einer Vorschau (key aus state.preview.widths); ihre Höhenstufe hängt daran (image-framing.css).
const PREVIEW_ATTR = 'data-preview';
// Was in der Ebene den Fokus nehmen kann (Tab läuft nur dort entlang).
const FOCUSABLE = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';

// Quelle für den Server zu einem Bildwert, oder null: dann gibt es keinen Ausschnitt. Nur Bilder vom selben Ort wie
// die Seite (keine fremden Adressen, kein data:) mit einer Endung, aus der der Server rechnet (upload_config
// deriveTypes, also kein SVG). Immer der Pfad ab „/“, wie der Browser das Bild anfragt (framingPath); der Server merkt
// ihn sich als Form des Originals (address), die auf jeder Seite gilt.
export function framingSource(url) {
  return framingPath(url, document.baseURI, window.location.origin, state.upload.deriveTypes);
}

// Ausschnitt im Feld. options: { url (Bildwert, '' = keins), focus (Fokus wie gespeichert, relativ zum Zuschnitt, '' =
// keiner; null = kein Speicherort, etwa ein Seitenbild ohne Fokus-Marker: dann nur Zuschnitt, kein Punkt, der verloren
// ginge), maxWidth (höchste Anzeigebreite, null = keine), form
// (uploadForm), notify, buttons ({ text, option, icon }: Klassen der Oberfläche), drop (Klassen der leeren Ablagefläche wie bei imageDropArea; nur mit replace), replace (Kopf mit „Anderes Bild“, Datei
// aufs Bild ziehen), removeLabel (Text für „Entfernen“, null = ohne), onChange({ url, focus, fresh }) }.
// onChange kommt bei jeder Änderung: der Fokus sofort (auch beim Ziehen), ein Zuschnitt, sobald der Server ihn gerechnet
// hat (fresh = neue Datei, ein offener Upload von form), ein neues Bild mit leerem Fokus, Entfernen mit url ''. Bis dahin
// zählt der Zuschnitt wie ein laufender Upload (uploadPending). Ohne framingSource (SVG, fremde Adresse) nur das Bild.
// Liefert { element, head (Kopfzeile: der Gastgeber kann seine Bezeichnung vorne hineinsetzen), setPlaces(list) (die
// gemessenen Stellen [{ label, frames: [{ key, label, w, h, fit, radius }] }], framing-measure.js: Vorschauen; ein weiterer Aufruf ersetzt sie, z. B. mit einem nachgetragenen Namen), isDirty() (Wert anders als zu Beginn
// oder Zuschnitt ausstehend), dispose() (wenn das Feld wegfällt: ein ausstehender Zuschnitt wird verworfen) }.
export function framingField(options) {
  const view = element('div', CLASSES.view);
  const head = element('div', CLASSES.head);
  const tools = element('div', CLASSES.tools);
  const body = element('div', CLASSES.view);
  head.appendChild(tools);
  view.append(head, body);
  let url = options.url;
  let focus = options.focus;
  // Ohne Speicherort bleibt focus null (kein Punkt, Hinweis nur zum Zuschnitt), sonst leert ein neues Bild ihn zu ''.
  const focusable = options.focus !== null;
  const noFocus = focusable ? '' : null;
  let session = null;
  // Gemessene Stellen, sobald da, gleiche Formen zusammengefasst (groupPlaces).
  let groups = null;
  const emit = function (fresh) { options.onChange({ url: url, focus: focus, fresh: fresh }); };
  const picker = options.replace ? imagePicker(function (next) {
    url = next;
    focus = noFocus;
    show();
    emit(true);
  }, options.notify, options.buttons.text + ' ' + CLASSES.tool, options.form, options.maxWidth) : null;
  if (picker) {
    picker.element.firstChild.nodeValue = FRAMING_TEXT.otherImage;
    picker.element.prepend(icon('upload'));
    tools.appendChild(picker.element);
  }
  const remove = options.removeLabel ? symbolButton('trash', options.removeLabel, options.buttons.icon + ' ' + CLASSES.remove, function () {
    url = '';
    focus = noFocus;
    show();
    emit(false);
  }) : null;
  if (remove) tools.appendChild(remove);
  const show = function () {
    if (session) session.dispose();
    session = null;
    body.replaceChildren();
    // Die Auswahl bleibt im Dokument (die leere Ablagefläche öffnet sie), nur ohne Bild ausgeblendet.
    if (picker) picker.element.hidden = !url;
    if (remove) remove.hidden = !url;
    if (!url) {
      const area = imageDropArea(picker, options.drop);
      area.show('');
      body.appendChild(area.element);
      return;
    }
    const source = framingSource(url);
    session = source ? cropSession(source) : plainSession();
  };

  // Bild in Feldbreite (über RATIO_VAR, Hochformate begrenzt das CSS), darauf beim Hineinziehen „Bild hier ablegen“.
  const pickArea = function (src) {
    const pick = element('div', CLASSES.pick);
    const img = pickImage(src, CLASSES.image);
    img.addEventListener('load', function () { pick.style.setProperty(RATIO_VAR, String(img.naturalWidth / img.naturalHeight)); });
    pick.appendChild(img);
    if (picker) {
      const drop = element('div', CLASSES.drop, FRAMING_TEXT.drop);
      drop.hidden = true;
      pick.appendChild(drop);
      dropFiles(pick, function (on) { drop.hidden = !on; }, picker.upload);
    }
    body.appendChild(pick);
    return { pick: pick, img: img };
  };

  const plainSession = function () {
    pickArea(url);
    return { dispose: function () {}, pending: function () { return false; }, render: function () {} };
  };

  // Zuschnitt und Fokus an einem Bild, solange es angezeigt ist. Fokus in Pixeln des Originals (point, null = keiner),
  // gespeichert relativ zum Zuschnitt (cropFocus); applied ist der Zuschnitt des Werts url.
  const cropSession = function (source) {
    const area = pickArea(url);
    const pick = area.pick;
    const img = area.img;
    const hint = element('p', CLASSES.hint);
    const places = element('div', CLASSES.places);
    const formats = element('div', CLASSES.formats);
    formats.setAttribute('role', 'group');
    formats.setAttribute('aria-label', FRAMING_TEXT.formats);
    hint.hidden = true;
    places.hidden = true;
    formats.hidden = true;
    body.append(hint, places, formats);
    let active = true;
    let info = null;
    let W = 0;
    let H = 0;
    let applied = null;
    let rect = null;
    let format = null;
    let point = null;
    let marker = null;
    let shade = null;
    let crop = null;
    let buttons = [];
    let previews = [];
    // Ausstehender Zuschnitt: Zeitgeber, Halt (holdUpload), Nummer der jüngsten Anfrage (nur sie gilt) und ihr Ausschnitt
    // (target; wer ihn noch einmal anfordert, wartet auf dieselbe Anfrage).
    let timer = null;
    let hold = null;
    let latest = 0;
    let target = null;
    const release = function () {
      if (timer !== null || !hold) return;
      hold();
      hold = null;
    };
    const fail = function (problem) {
      const notice = errorNotice(problem);
      options.notify(notice.message, notice.action);
    };
    const focusValue = function () { return point ? focusText(cropFocus(point, rect)) : ''; };
    const changeFocus = function () {
      if (!focusable) return;
      const next = focusValue();
      if (next === focus) return;
      focus = next;
      emit(false);
    };
    const buildPreviews = function () {
      places.replaceChildren();
      previews = [];
      places.hidden = !groups || !groups.length;
      if (places.hidden) return;
      groups.forEach(function (group) {
        const row = element('div', CLASSES.place);
        const list = element('div', CLASSES.previews);
        row.append(element('span', CLASSES.placeName, joinNames(group.labels, FRAMING_TEXT.comma, FRAMING_TEXT.and)), list);
        group.frames.forEach(function (frame) {
          const figure = element('figure', CLASSES.preview);
          figure.setAttribute(PREVIEW_ATTR, frame.key);
          const box = element('div', CLASSES.previewFrame);
          box.style.borderRadius = frame.radius;
          // clip zeigt nur den Zuschnitt, darin das Original an seiner Lage.
          const clip = element('div', CLASSES.previewClip);
          const shown = pickImage(info.original, CLASSES.previewImage);
          clip.appendChild(shown);
          box.appendChild(clip);
          figure.append(box, element('figcaption', '', frame.label));
          list.appendChild(figure);
          previews.push({ frame: frame, box: box, clip: clip, img: shown });
        });
        places.appendChild(row);
      });
    };
    const place = function (node, at) {
      node.style.left = at.left + '%';
      node.style.top = at.top + '%';
      node.style.width = at.width + '%';
      node.style.height = at.height + '%';
    };
    const render = function () {
      const ratio = rect.w / rect.h;
      const percent = rectPercent(rect, W, H);
      place(shade, percent);
      place(crop, percent);
      // Ohne Fokus steht der Punkt in der Mitte des Rahmens, wohin object-position ohne Angabe ausrichtet.
      const shown = point || { x: rect.x + rect.w / 2, y: rect.y + rect.h / 2 };
      marker.style.left = shown.x / W * 100 + '%';
      marker.style.top = shown.y / H * 100 + '%';
      buttons.forEach(function (item) { item.button.setAttribute('aria-pressed', String(item.entry === format)); });
      const position = point ? cropFocus(point, rect) : null;
      previews.forEach(function (item) {
        const box = previewRatio(item.frame, ratio);
        const at = previewPlacement(rect, W, H, box, item.frame.fit === FIT_COVER, position);
        item.box.style.setProperty(RATIO_VAR, String(box));
        place(item.clip, at.clip);
        place(item.img, at.image);
      });
    };
    // Nach dem Loslassen: Weicht der Rahmen vom Zuschnitt des Werts ab, rechnet der Server ihn nach DERIVE_DELAY; bis dahin
    // und solange er rechnet, zählt das wie ein laufender Upload. Derselbe Rahmen wie die ausstehende Anfrage (Tippen,
    // Loslassen ohne Ziehen): nichts Neues. Zurück auf den Zuschnitt des Werts: nichts zu rechnen.
    const settle = function () {
      const next = cropOf(rect, W, H);
      if (sameCrop(next, target)) return;
      target = next;
      window.clearTimeout(timer);
      timer = null;
      if (sameCrop(next, applied)) {
        latest++;
        release();
        return;
      }
      if (!hold) hold = holdUpload();
      timer = window.setTimeout(derive, DERIVE_DELAY);
    };
    const derive = function () {
      timer = null;
      const next = target;
      const choice = ++latest;
      deriveImage(options.form, info, next, options.maxWidth).then(function (derived) {
        if (!active || choice !== latest) {
          if (derived.fresh) options.form.close([derived.url]);
          return;
        }
        applied = next;
        url = derived.url;
        if (focusable) focus = focusValue();
        release();
        emit(derived.fresh);
      }, function (problem) {
        if (!active || choice !== latest) return;
        release();
        target = applied;
        rect = rectOf(applied, W, H);
        format = formatOf(applied, FRAMING_FORMATS);
        if (point) point = clampToRect(point, rect);
        render();
        changeFocus();
        fail(problem);
      });
    };
    const setRect = function (next) {
      rect = next;
      if (point) point = clampToRect(point, rect);
      render();
      changeFocus();
    };
    imageInfo(source).then(function (data) {
      if (!active) return;
      info = data;
      W = info.originalWidth;
      H = info.originalHeight;
      applied = info.crop;
      target = applied;
      rect = rectOf(applied, W, H);
      format = formatOf(applied, FRAMING_FORMATS);
      const stored = focusParse(focus);
      point = stored ? focusPoint(stored, rect) : null;
      img.src = info.original;
      crop = element('div', CLASSES.crop);
      CORNERS.forEach(function (corner) {
        const handle = element('span', CLASSES.handle);
        handle.setAttribute(CORNER_ATTR, corner);
        crop.appendChild(handle);
      });
      // Abdunkelung außerhalb des Rahmens nur über dem Bild; Rahmen, Ecken und Punkt darüber, nicht abgeschnitten.
      const clip = element('div', CLASSES.clip);
      shade = element('div', CLASSES.shade);
      clip.appendChild(shade);
      marker = element('span', CLASSES.marker);
      img.after(clip, crop, marker);
      marker.hidden = !focusable;
      pick.classList.toggle(CLASSES.pickFocus, focusable);
      hint.textContent = focusable ? FRAMING_TEXT.hint : FRAMING_TEXT.cropHint;
      buttons = FRAMING_FORMATS.map(function (entry) {
        const label = entry.ratio ? entry.ratio.join(RATIO_SEPARATOR) : FRAMING_TEXT.free;
        // Ein festes Format setzt den Rahmen um seine Mitte; „Frei“ hebt nur das Format auf, der Rahmen bleibt.
        const button = editorButton(label, options.buttons.option, function () {
          format = entry;
          setRect(formatRect(rect, W, H, ratioOf(entry.ratio)));
          settle();
        });
        formats.appendChild(button);
        return { entry: entry, button: button };
      });
      // „Original“: ganzes Bild, Fokus leer.
      formats.appendChild(editorButton(FRAMING_TEXT.original, options.buttons.text, function () {
        format = formatOf(null, FRAMING_FORMATS);
        point = null;
        setRect(fullRect(W, H));
        settle();
      }));
      hint.hidden = false;
      formats.hidden = false;
      let drag = null;
      const at = function (event) { return pointIn(event.clientX, event.clientY, img.getBoundingClientRect(), W, H); };
      onDrag(pick, function (event) {
        const corner = event.target.getAttribute(CORNER_ATTR);
        const start = at(event);
        drag = null;
        if (corner) {
          // Kleinste Breite und Höhe nach der Größe, in der das Bild gerade angezeigt wird.
          const target = parseFloat(window.getComputedStyle(crop).getPropertyValue(CROP_TARGET_VAR));
          const min = cropMin(CROP_MIN, CROP_MIN_TARGETS * target, img.getBoundingClientRect().width, W, H);
          // Wo die Ecke liegt, gemessen vom Druckpunkt (die Greiffläche ist größer als der Punkt): Sie springt nicht.
          const edge = { x: corner.indexOf('w') !== -1 ? rect.x : rect.x + rect.w, y: corner.indexOf('n') !== -1 ? rect.y : rect.y + rect.h };
          drag = { corner: corner, anchor: anchorOf(rect, corner), min: min, x: event.clientX, y: event.clientY, dx: edge.x - start.x, dy: edge.y - start.y, moved: false };
        } else if (event.target === marker && focusable) {
          drag = { focus: true };
        } else if (event.target === crop) {
          drag = { start: start, x: event.clientX, y: event.clientY, rect: rect, point: point, moved: false };
        } else if (focusable) {
          point = clampToRect(start, rect);
          render();
          changeFocus();
          drag = { focus: true };
        }
      }, function (event) {
        if (!drag) return;
        const now = at(event);
        if (drag.focus) {
          point = clampToRect(now, rect);
          render();
          changeFocus();
        } else {
          // Ecke und Rahmen bewegen sich erst ab TAP_SLOP: Ein Tipp ändert den Rahmen nie.
          if (!drag.moved && Math.hypot(event.clientX - drag.x, event.clientY - drag.y) < TAP_SLOP) return;
          drag.moved = true;
          if (drag.corner) {
            setRect(resizedRect(drag.anchor, { x: now.x + drag.dx, y: now.y + drag.dy }, drag.corner, ratioOf(format.ratio), drag.min, W, H));
            return;
          }
          const moved = movedRect(drag.rect, now.x - drag.start.x, now.y - drag.start.y, W, H);
          // Der Punkt wandert mit dem Rahmen.
          if (drag.point) point = { x: drag.point.x + moved.x - drag.rect.x, y: drag.point.y + moved.y - drag.rect.y };
          setRect(moved);
        }
      }, function () {
        if (!drag) return;
        // Tippen in den Rahmen ohne Ziehen setzt den Fokus, auf eine Ecke nichts; nur ein gezogener Rahmen wird gerechnet.
        if (drag.start && !drag.moved && focusable) {
          point = clampToRect(drag.start, rect);
          render();
          changeFocus();
        }
        if (drag.moved) settle();
        drag = null;
      });
      buildPreviews();
      render();
    }, function (problem) {
      if (active) fail(problem);
    });
    return {
      pending: function () { return hold !== null; },
      // Stellen sind gemessen: Vorschauen aufbauen.
      render: function () {
        if (!info) return;
        buildPreviews();
        render();
      },
      dispose: function () {
        active = false;
        window.clearTimeout(timer);
        timer = null;
        latest++;
        release();
      }
    };
  };

  show();
  return {
    element: view,
    head: head,
    setPlaces: function (list) {
      groups = groupPlaces(list);
      if (session) session.render();
    },
    isDirty: function () { return url !== options.url || focus !== options.focus || (session !== null && session.pending()); },
    dispose: function () {
      if (session) session.dispose();
      session = null;
    }
  };
}

// Ausschnitt in frame: { body, foot, close(), buttons: { primary, secondary, text, option, close } } (Ebene des
// Bildrasters; Knopfklassen der jeweiligen Oberfläche): framingField ohne Kopf und ohne Vorschauen, Fuß
// Abbrechen · Übernehmen. options: { url (framingSource nicht null), focus (wie bei framingField), maxWidth, form
// (uploadForm), notify, onApply({ url, focus }) }. onApply bekommt Wert und Fokus nur, wenn sich einer davon ändert;
// sonst schließt Übernehmen nur. Steht ein Zuschnitt noch aus, wartet Übernehmen darauf (settledAction); ein laufender
// Upload lehnt mit dem Hinweis von uploadPending ab. Liefert { isDirty(), dispose() }; dispose(), wenn frame zugeht (auch
// von außen): Zuschnitte, die nicht übernommen sind, erledigt dann form.
export function mountFraming(frame, options) {
  let current = { url: options.url, focus: options.focus };
  let taken = null;
  // Hier gerechnete Zuschnitte (neue Dateien).
  const fresh = [];
  const field = framingField({
    url: options.url,
    focus: options.focus,
    maxWidth: options.maxWidth,
    form: options.form,
    notify: options.notify,
    buttons: frame.buttons,
    drop: null,
    replace: false,
    removeLabel: null,
    onChange: function (result) {
      current = { url: result.url, focus: result.focus };
      if (result.fresh) fresh.push(result.url);
    }
  });
  let closed = false;
  // Ein Zuschnitt, der noch gerechnet wird, kommt mit: Übernehmen wartet gesperrt darauf (mit Zeitgrenze), Abbrechen geht.
  const applying = settledAction(options.notify, function (busy) { apply.disabled = busy; });
  const apply = editorButton(FRAMING_TEXT.apply, frame.buttons.primary, function () {
    applying.run(function () {
      if (closed || uploadPending(options.notify)) return;
      if (current.url !== options.url || current.focus !== options.focus) {
        taken = current.url;
        options.onApply(current);
      }
      frame.close();
    });
  });
  frame.foot.append(editorButton(FRAMING_TEXT.cancel, frame.buttons.secondary, frame.close), apply);
  frame.body.appendChild(field.element);
  // Übernehmen hat den Fokus, Esc gilt dann dem Panel bzw. der Ebene.
  apply.focus({ preventScroll: true });
  return {
    isDirty: field.isDirty,
    dispose: function () {
      closed = true;
      field.dispose();
      options.form.close(fresh.filter(function (url) { return url !== taken; }));
    }
  };
}

// Eigene Ebene für den Ausschnitt über einem Formular (Eintragsformular im Panel des Seiten-Editors bzw. im Modal der
// Verwaltung, F2): Das Formular bleibt offen darunter. Abdunkelung und der Rahmen aus sheet.js (Überzeile, Titel, ×,
// Inhalt, Fuß), eingehängt neben near (im selben Shadow-Root bzw. Dokument). Solange sie offen ist, gehören ihr Esc und
// Tab, wo auch immer der Fokus liegt: Tab läuft nur durch ihre Knöpfe, Fokus außerhalb holt sie zurück, Esc läuft nicht
// weiter zu Modal oder Panel. Mit Änderungen fragt Strg+S wie × nach, statt das Formular zu speichern (holdSaveKey). ×, Esc und Klick daneben fragen bei Änderungen (options.isDirty) über options.confirmClose()
// (Promise mit true = verwerfen) nach, Abbrechen im Fuß nicht. options: { eyebrow, buttons (Knopfklassen wie bei
// mountFraming, dazu close für ×), isDirty(), confirmClose(), onClose() (nach jedem Schließen) }. Liefert das frame für
// mountFraming; close() schließt ohne Rückfrage, auch von außen (Formular zu), und gibt den Fokus an near zurück.
export function openFramingLayer(near, options) {
  const root = near.getRootNode();
  const layer = element('div', CLASSES.layer);
  let open = true;
  // Solange die Rückfrage offen ist (eigener Dialog des Gastgebers), gehören Fokus und Tasten ihr.
  let asking = false;
  const requestClose = function () {
    if (asking) return;
    if (!options.isDirty()) {
      frame.close();
      return;
    }
    asking = true;
    options.confirmClose().then(function (yes) {
      asking = false;
      if (yes) frame.close();
      else if (open) focusIn();
    });
  };
  const parts = sheet({
    className: CLASSES.layerBox,
    title: FRAMING_TEXT.title,
    eyebrow: options.eyebrow,
    closeClass: options.buttons.close,
    closeLabel: FRAMING_TEXT.close,
    onClose: requestClose
  });
  const box = parts.element;
  box.setAttribute('aria-modal', 'true');
  box.tabIndex = -1;
  layer.appendChild(box);
  const inside = function (node) { return node instanceof Node && box.contains(node); };
  const focusable = function () {
    return Array.prototype.filter.call(box.querySelectorAll(FOCUSABLE), function (node) {
      return !node.disabled && node.getClientRects().length > 0;
    });
  };
  const focusIn = function () { box.focus({ preventScroll: true }); };
  // Tasten am window (Capture), damit sie vor den Zuhörern von Modal (document) und Panel ankommen.
  const onKey = function (event) {
    if (asking) return;
    const target = event.composedPath()[0];
    if (event.key === 'Escape') {
      event.preventDefault();
      event.stopImmediatePropagation();
      requestClose();
      return;
    }
    if (event.key !== 'Tab') return;
    const items = focusable();
    if (!items.length) return;
    const first = items[0];
    const last = items[items.length - 1];
    let next = null;
    if (!inside(target) || target === box) next = event.shiftKey ? last : first;
    else if (event.shiftKey && target === first) next = last;
    else if (!event.shiftKey && target === last) next = first;
    if (!next) return;
    event.preventDefault();
    next.focus({ preventScroll: true });
  };
  const onFocus = function (event) {
    if (!asking && !inside(event.composedPath()[0])) focusIn();
  };
  // Strg+S speichert das Formular nicht an nicht übernommenen Änderungen vorbei, sondern fragt wie ×.
  const releaseSave = holdSaveKey(function () {
    if (!options.isDirty()) return false;
    requestClose();
    return true;
  });
  const frame = {
    body: parts.body,
    foot: parts.foot,
    buttons: options.buttons,
    close: function () {
      if (!open) return;
      open = false;
      window.removeEventListener('keydown', onKey, true);
      document.removeEventListener('focusin', onFocus, true);
      releaseSave();
      layer.remove();
      if (options.onClose) options.onClose();
      if (near.isConnected) near.focus({ preventScroll: true });
    }
  };
  layer.addEventListener('click', function (event) {
    if (event.target === layer) requestClose();
  });
  window.addEventListener('keydown', onKey, true);
  document.addEventListener('focusin', onFocus, true);
  (root instanceof ShadowRoot ? root : document.body).appendChild(layer);
  focusIn();
  return frame;
}


function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text) node.textContent = text;
  return node;
}

// Bild im Feld bzw. in einer Vorschau; nicht ziehbar (sonst zöge der Browser eine Kopie statt den Punkt bzw. Rahmen).
function pickImage(src, className) {
  const img = element('img', className);
  img.src = src;
  img.alt = '';
  img.draggable = false;
  return img;
}

// Ziehen mit Maus und Finger an target (Muster: Logo in bar.js): start(event) beim Drücken, move(event) solange gedrückt,
// end() beim Loslassen oder Abbrechen.
function onDrag(target, start, move, end) {
  let id = null;
  target.addEventListener('pointerdown', function (event) {
    if (event.button !== 0) return;
    event.preventDefault();
    id = event.pointerId;
    target.setPointerCapture(id);
    start(event);
  });
  target.addEventListener('pointermove', function (event) {
    if (event.pointerId === id) move(event);
  });
  const stop = function (event) {
    if (event.pointerId !== id) return;
    id = null;
    end();
  };
  target.addEventListener('pointerup', stop);
  target.addEventListener('pointercancel', stop);
}
