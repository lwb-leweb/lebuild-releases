// Gefilterte Liste (data-filter="kategorie=Blog", content-types): Ein neuer Eintrag bekommt den Wert des Filters vorab
// (default), damit er in dieser Liste landet. Das gilt auch für eine Kopie, deren Filterfeld copy: false hat: copyValues
// lässt das Feld weg, das Formular startet mit default. Getrennt am ersten „=“ wie auf dem Server
// (content_types_list_filter). Ohne Importe und ohne DOM, damit node es prüfen kann (tests/frontend/entry-copy.test.php).
export function withFilterDefault(schema, filter) {
  const cut = filter ? filter.indexOf('=') : -1;
  if (cut <= 0) return schema;
  const name = filter.slice(0, cut);
  const value = filter.slice(cut + 1);
  return schema.map(function (field) {
    return field.name === name ? Object.assign({}, field, { default: value }) : field;
  });
}
