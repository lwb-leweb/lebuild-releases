// Welche Knöpfe ein Eintrag einer Plugin-Liste auf der Seite bekommt, in dieser Reihenfolge (plugin-lists.js baut sie).
// Ohne Importe und ohne DOM, damit node es prüfen kann (tests/frontend/entry-copy.test.php).

// Einzelansicht (le_single_attrs): nur Bearbeiten. Sonst Bearbeiten, ↑/↓ (sortable: sort-Endpoint und keine feste
// Reihenfolge; nicht am Rand: index in der Liste mit count Einträgen), Kopieren, Löschen.
export function entryActions(single, sortable, index, count) {
  if (single) return ['edit'];
  const actions = ['edit'];
  if (sortable && index > 0) actions.push('up');
  if (sortable && index < count - 1) actions.push('down');
  actions.push('copy', 'remove');
  return actions;
}
