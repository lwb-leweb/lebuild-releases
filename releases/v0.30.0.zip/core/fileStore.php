<?php
declare(strict_types=1);

require_once __DIR__ . '/utils.php';
require_once __DIR__ . '/textMarkup.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/labels.php';
require_once __DIR__ . '/updater.php';

function prepare_storage(): void
{
    ensure_dir(PAGES_ROOT);
    ensure_dir(BACKUPS_ROOT);
    ensure_dir(ORIGINALS_ROOT);
    ensure_dir(UPLOADS_ROOT);
    if (!is_file(UPLOADS_ROOT . '/.htaccess')) {
        try {
            write_file_atomic(UPLOADS_ROOT . '/.htaccess', UPLOADS_HTACCESS);
        } catch (RuntimeException $e) {
            // Wie vorher still: Der nächste Request versucht es wieder, die Systemprüfung meldet fehlende Schreibrechte.
        }
    }
    le_uploads_migrate();
}

/**
 * Dateien der früheren Ablage LE_LEGACY_UPLOADS_ROOT (public/uploads/) nach UPLOADS_ROOT umziehen, einmal nach dem
 * Update oder nach dem Einspielen einer alten Sicherung. Gespeicherte Werte behalten die alte Adresse (upload_file_name
 * nimmt beide). Eine gleichnamige Datei am Ziel gewinnt, die alte bleibt dann liegen. Ist nur noch die eigene
 * .htaccess übrig, fällt der alte Ordner weg.
 */
function le_uploads_migrate(): void
{
    if (!is_dir(LE_LEGACY_UPLOADS_ROOT)) {
        return;
    }
    $own = ['.htaccess', '.gitkeep'];
    foreach (dir_entries(LE_LEGACY_UPLOADS_ROOT) as $file) {
        $from = LE_LEGACY_UPLOADS_ROOT . '/' . $file;
        if (in_array($file, $own, true) || is_link($from) || !is_file($from) || file_exists(UPLOADS_ROOT . '/' . $file)) {
            continue;
        }
        @rename($from, UPLOADS_ROOT . '/' . $file);
    }
    if (array_diff(dir_entries(LE_LEGACY_UPLOADS_ROOT), $own) === []) {
        foreach ($own as $file) {
            @unlink(LE_LEGACY_UPLOADS_ROOT . '/' . $file);
        }
        @rmdir(LE_LEGACY_UPLOADS_ROOT);
    }
}

function page_json_path(string $page): string
{
    return PAGES_ROOT . '/' . safe_page_name($page) . '.json';
}

// Schlüssel im JSON einer Seite oder Komponente neben ihren Feldern: Hash der Quelldatei, wie der Kern
// sie zuletzt geschrieben bzw. importiert hat (Speichern, Wiederherstellen, Import). Weicht die Datei
// davon ab, wurde sie direkt geändert (Deploy, FTP, Editor): le_sync_sources gleicht ab. Kein Feld,
// le_page_json_content lässt ihn weg. Das „@“ kann keine Feld-ID tragen (import_id_storable,
// sanitize_content_tree), so verdeckt der Schlüssel nie ein Feld, auch kein von Hand gesetztes data-edit-id="sourceHash".
const LE_SOURCE_HASH_KEY = '@sourceHash';
const LE_SOURCE_HASH_ALGO = 'sha256';

/** Hash einer Quelldatei (Inhalt $source) für LE_SOURCE_HASH_KEY. */
function le_source_hash(string $source): string
{
    return hash(LE_SOURCE_HASH_ALGO, $source);
}

/** Felder aus dem Text einer Seiten-JSON oder eines ihrer Backups, ohne LE_SOURCE_HASH_KEY; null, wenn unlesbar. */
function le_page_json_content(string $json): ?array
{
    $data = json_decode($json, true);
    if (!is_array($data)) {
        return null;
    }
    unset($data[LE_SOURCE_HASH_KEY]);
    return $data;
}

/** Gemerkter Hash der Quelldatei aus dem Text einer Seiten-JSON; null ohne (Altbestand) oder wenn unlesbar. */
function le_page_json_source_hash(string $json): ?string
{
    $hash = json_decode($json, true)[LE_SOURCE_HASH_KEY] ?? null;
    return is_string($hash) ? $hash : null;
}

/** Hash der Quelldatei nach dem Schreiben eines Plans ('file', 'source' wie aus plan_source_rewrite): neue Fassung, sonst die Datei. */
function le_plan_source_hash(array $plan): string
{
    return le_source_hash($plan['source'] ?? (string) file_get_contents($plan['file']));
}

/**
 * Merkt $hash als Hash der Quelldatei im JSON von $name, ohne dass sich Felder ändern: kein Backup,
 * „Zuletzt gespeichert“ bleibt (Altbestand ohne Hash, Datei ohne geänderte Felder). Eine unlesbare
 * JSON bleibt, wie sie ist. Der Aufrufer hält lock_pages.
 */
function le_write_source_hash(string $name, string $hash): void
{
    $path = page_json_path($name);
    $content = is_file($path) ? le_page_json_content((string) file_get_contents($path)) : null;
    if ($content === null) {
        return;
    }
    clearstatcache(true, $path);
    $updatedAt = (int) filemtime($path);
    atomic_write($path, (string) page_json_text($content, $hash));
    touch($path, $updatedAt);
}

function load_page_content(string $page): array
{
    $path = page_json_path($page);
    if (!is_file($path)) {
        json_response(['ok' => false, 'error' => API_TEXT['pageNotFound']], 404);
    }

    $data = le_page_json_content((string) file_get_contents($path));
    if ($data === null) {
        json_response(['ok' => false, 'error' => API_TEXT['pageInvalid']], 500);
    }

    return $data;
}

function list_pages(): array
{
    prepare_storage();
    $files = glob(PAGES_ROOT . '/*.json') ?: [];
    $components = array_keys(shared_components());
    $pages = array_map(static fn (string $file): string => basename($file, '.json'), $files);
    $pages = array_values(array_filter($pages, static fn (string $p): bool => !in_array($p, $components, true)));
    sort($pages);

    return $pages;
}

/** JSON einer Seite oder Komponente; null ohne Datei oder wenn sie unlesbar ist (anders als load_page_content ohne Abbruch). */
function load_component_content(string $name): ?array
{
    $path = page_json_path($name);
    if (!is_file($path)) {
        return null;
    }
    return le_page_json_content((string) file_get_contents($path));
}

/**
 * Seitentitel für Listen: erstes title-, sonst text-Feld als Klartext ($kinds: Feldarten wie aus
 * page_field_kinds, sonst nach der ID; ein Titel der Art plain bleibt, wie er ist). $kindOf (Pfad →
 * Art) ersetzt den Rückfall auf field_kind und läuft nur, wenn die Art den Titel ändert: Ein Wert,
 * den die Textbereinigung nicht verändert, ist in jeder Art derselbe (page_info liest die
 * Seitendatei so nur dann).
 */
function page_title_from_content(array $content, string $fallback, array $kinds = [], ?callable $kindOf = null): string
{
    $flat = flatten_content($content);
    foreach (['title', 'text'] as $field) {
        foreach ($flat as $path => $value) {
            $path = (string) $path;
            if (!preg_match('/(^|\.)' . $field . '$/', $path) || !is_scalar($value)) {
                continue;
            }
            $value = (string) $value;
            $title = trim($value);
            if (isset($kinds[$path]) || text_markup_plain($value) !== $title) {
                $title = trim(field_plain_text($kinds[$path] ?? ($kindOf === null ? field_kind($path) : $kindOf($path)), $value));
            }
            if ($title !== '') {
                return $title;
            }
        }
    }

    return $fallback;
}

/** Endung der Seitendatei unter public/site (.php vor .html wie bei der Auslieferung); null, wenn keine da ist. */
function page_extension(string $page): ?string
{
    foreach (['php', 'html'] as $ext) {
        if (is_file(LE_SITE_ROOT . '/' . $page . '.' . $ext)) {
            return $ext;
        }
    }
    return null;
}

/** Quelldatei einer Seite oder Komponente (header/footer) unter public/site; null, wenn sie fehlt. */
function page_source_path(string $name): ?string
{
    $component = shared_components()[$name] ?? null;
    if ($component !== null) {
        return is_file($component) ? $component : null;
    }
    $page = safe_page_name($name);
    $ext = page_extension($page);
    return $ext === null ? null : LE_SITE_ROOT . '/' . $page . '.' . $ext;
}

/** „Zuletzt gespeichert“ einer Seite: Änderungszeit ihrer JSON, null ohne JSON. */
function page_updated_at(string $page): ?string
{
    $path = page_json_path($page);
    clearstatcache(true, $path);
    return is_file($path) ? gmdate('c', (int) filemtime($path)) : null;
}

/**
 * Rückt „Zuletzt gespeichert“ vor, wenn sich nur die Seitendatei oder eine Komponente
 * geändert hat und die JSON der Seite deshalb nicht neu geschrieben wurde.
 */
function mark_page_updated(string $page): void
{
    $path = page_json_path(safe_page_name($page));
    if (is_file($path)) {
        touch($path);
    }
}

/**
 * Eintrag der Seitenliste (Backend, JSON-Block des Seiten-Editors): Name, Titel, zuletzt gespeichert,
 * Endung. Ohne Seitendatei (JSON da, Datei gelöscht) ist ext null und missing true: Das Backend zeigt
 * die Seite mit Hinweis, öffnet sie aber nicht.
 */
function page_info(string $page): array
{
    // Mit kaputter JSON (unlesbar) heißt die Seite nach ihrem Namen; Backend, Verlauf und Seiten-Editor laden trotzdem.
    $content = load_component_content($page) ?? [];
    $ext = page_extension($page);
    // Feldart wie page_field_kinds, aber die Seitendatei wird nur gelesen, wenn ein Titelkandidat sie braucht.
    $doc = null;
    $kindOf = static function (string $path) use (&$doc, $page): string {
        $doc ??= page_source_doc($page);
        return field_kind_in_doc($doc, field_id_prefix($page) . $path);
    };
    return [
        'page' => $page,
        'title' => page_title_from_content($content, $page, [], $kindOf),
        'updatedAt' => page_updated_at($page),
        'ext' => $ext,
        'missing' => $ext === null,
    ];
}

function list_page_info(): array
{
    prepare_storage();
    return array_map('page_info', list_pages());
}

/**
 * Schlüssel bereinigen und jeden Wert nach seiner Feldart: $kinds (Pfad → Art aus der Markierung
 * in der Datei, page_field_kinds/plan_source_rewrite), für Felder ohne Markierung field_kind der ID.
 */
function sanitize_content_tree(array $content, array $kinds = [], string $prefix = ''): array
{
    $clean = [];
    foreach ($content as $key => $value) {
        $safeKey = preg_replace('/[^a-zA-Z0-9_-]/', '', (string) $key);
        if ($safeKey === '') {
            continue;
        }
        $id = $prefix === '' ? $safeKey : $prefix . '.' . $safeKey;
        if (is_array($value)) {
            $clean[$safeKey] = sanitize_content_tree($value, $kinds, $id);
        } else {
            $clean[$safeKey] = sanitize_field_value($kinds[$id] ?? field_kind($id), is_scalar($value) ? (string) $value : '');
        }
    }

    return $clean;
}

/**
 * write_file_atomic für Seiten, Komponenten und ihre JSON: Scheitert es, bleibt die Datei, wie sie
 * war, und die Antwort ist 500 ohne Dateinamen (nur das Fehlerprotokoll nennt den Pfad).
 */
function atomic_write(string $path, string $content): void
{
    if (!le_atomic_write($path, $content)) {
        json_response(['ok' => false, 'error' => write_failed_message()], 500);
    }
}

/** atomic_write ohne Antwort an den Browser: false (Pfad im Fehlerprotokoll), wenn es nicht geht, z. B. für Aufräumen nebenher; $private wie bei write_file_atomic. */
function le_atomic_write(string $path, string $content, bool $private = false): bool
{
    try {
        write_file_atomic($path, $content, $private);
    } catch (RuntimeException $e) {
        error_log('atomic_write failed: ' . $path);
        return false;
    }
    return true;
}

/** Meldung, wenn der Server nicht schreiben lässt: ohne Datei- und Ordnernamen; $labels: betroffene Namen wie im Editor („Fußzeile“, „diese Seite“). */
function write_failed_message(array $labels = []): string
{
    $names = $labels === [] ? '' : sprintf(API_TEXT['writeFailedNames'], implode(', ', $labels));
    return sprintf(API_TEXT['writeFailed'], $names) . ' ' . API_TEXT['contactSupport'];
}

const BACKUP_RETENTION = 15;
// Name eines Backups: Zeitpunkt in UTC (backup_timestamp liest ihn zurück, restore.php erwartet 14 Ziffern).
const BACKUP_STAMP_FORMAT = 'YmdHis';
// So viele Namen probiert create_backup_file, bevor es aufgibt (belegt durch gleichzeitige Saves).
const BACKUP_CREATE_ATTEMPTS = 100;
// Kurzinfo neben jedem Backup <stempel>.json als <stempel>.info (JSON): wer gespeichert hat und
// welche Felder sich wie geändert haben (Verlauf). Eigene Endung, damit sie weder unter
// page_backup_files() noch unter die Backup-Namen von api/restore.php fällt.
const BACKUP_INFO_EXTENSION = '.info';
// Alter und neuer Text in der Kurzinfo: Klartext, höchstens so viele Zeichen.
const BACKUP_INFO_TEXT_MAX = 80;
// Verlauf (page_history): eine Zeile je Speichern, „Heute, 14:03 – anna – Überschrift ‚Willkommen‘,
// 2 weitere Texte, 1 weiteres Bild; Fußzeile: Telefon ‚0664 123‘“ (mitgespeicherte Kopf- und
// Fußzeile mit ihrem Namen aus COMPONENT_LABELS); ohne Kurzinfo (ältere Backups) nur
// „Gespeichert“, ein Wiederherstellen beginnt mit „Wiederhergestellt: “.
const HISTORY_TEXT = [
    'separator' => ' – ',
    'saved' => 'Gespeichert',
    'restored' => 'Wiederhergestellt',
    'restoredLead' => ': ',
    'oldest' => 'Ältester gespeicherter Stand',
    'quote' => [' ‚', '‘'],
    'list' => ', ',
    'componentLead' => ': ',
    'components' => '; ',
];
// Feldarten im Verlauf: Texte zeigen ihren neuen Text („Überschrift ‚Willkommen‘“), die übrigen
// nur ihre Art und ihren Namen („Bild ‚Team – Bild 1‘“, nie einen Upload-Pfad); weitere Felder
// werden je Gruppe gezählt (Einzahl, Mehrzahl). Reihenfolge = Reihenfolge der Zählung.
const HISTORY_GROUPS = [
    'text' => ['kinds' => ['text', 'linktext', 'plain'], 'word' => null, 'more' => ['%d weiterer Text', '%d weitere Texte']],
    'alt' => ['kinds' => ['alt'], 'word' => null, 'more' => ['%d weiterer Alt-Text', '%d weitere Alt-Texte']],
    'url' => ['kinds' => ['url'], 'word' => 'Link-Ziel', 'more' => ['%d weiteres Link-Ziel', '%d weitere Link-Ziele']],
    'image' => ['kinds' => ['image', 'background'], 'word' => 'Bild', 'more' => ['%d weiteres Bild', '%d weitere Bilder']],
    'icon' => ['kinds' => ['icon'], 'word' => 'Icon', 'more' => ['%d weiteres Icon', '%d weitere Icons']],
];

// Sperrdatei je Seite oder Komponente in ihrem Backup-Ordner (lock_pages).
const PAGE_LOCK_FILE = '.lock';
// Nur für die Tests (tests/): Millisekunden Pause zwischen Lesen und Schreiben in save_page_content,
// damit sich gleichzeitige Saves ohne Sperre sicher überschneiden. Sonst nie gesetzt.
const SAVE_DELAY_ENV = 'LEBUILD_TEST_SAVE_DELAY_MS';

/**
 * Sperrt Seiten und Komponenten ($names) für den ganzen Ablauf Lesen → Backup → JSON → Dateien
 * (Speichern, Wiederherstellen, Import): wartet auf laufende und sperrt in fester Reihenfolge
 * (sortiert), damit zwei Requests einander nicht verklemmen. Namen ohne Quelldatei werden nicht
 * gesperrt (für sie wird nichts geschrieben, Grund „Quelldatei fehlt“), so entstehen für erfundene
 * Namen weder Ordner noch Sperrdateien. Frei mit unlock_pages, spätestens am Ende des Requests.
 * Nie verschachtelt aufrufen (eine zweite Sperre derselben Seite wartete auf die erste).
 */
function lock_pages(array $names): array
{
    $names = array_filter(array_unique(array_map('safe_page_name', $names)), static fn (string $name): bool => page_source_path($name) !== null);
    sort($names);
    $locks = [];
    foreach ($names as $name) {
        $dir = BACKUPS_ROOT . '/' . $name;
        try {
            ensure_dir($dir);
        } catch (RuntimeException $e) {
            // Ohne Pfad in der Antwort (ensure_dir nennt ihn).
            json_response(['ok' => false, 'error' => API_TEXT['lockFailed']], 500);
        }
        $lock = updater_acquire_lock($dir . '/' . PAGE_LOCK_FILE, true);
        if ($lock === null) {
            json_response(['ok' => false, 'error' => API_TEXT['lockFailed']], 500);
        }
        $locks[] = $lock;
    }
    return $locks;
}

/** Gibt Sperren aus lock_pages frei; schon freigegebene bleiben unberührt (le_log_after_unlock). */
function unlock_pages(array $locks): void
{
    foreach (array_reverse($locks) as $lock) {
        if (is_resource($lock)) {
            updater_release_lock($lock);
        }
    }
}

/**
 * Backup-Dateien einer Seite oder Komponente (Pfade, unsortiert); leer ohne Backups. Ohne leere Dateien: Die
 * belegt le_create_file_atomic ohne link() kurz als Platzhalter, nach einem Absturz dazwischen bleiben sie liegen.
 */
function page_backup_files(string $page): array
{
    return array_values(array_filter(glob(BACKUPS_ROOT . '/' . safe_page_name($page) . '/*.json') ?: [], 'le_backup_file_ready'));
}

/** Ist $path ein fertiges Backup (vorhanden, nicht leer, siehe page_backup_files)? */
function le_backup_file_ready(string $path): bool
{
    return is_file($path) && filesize($path) > 0;
}

/** Kurzinfo zu einer Backup-Datei (gleicher Name, Endung BACKUP_INFO_EXTENSION). */
function backup_info_path(string $backupPath): string
{
    return dirname($backupPath) . '/' . basename($backupPath, '.json') . BACKUP_INFO_EXTENSION;
}

/** Kurzinfo eines Backups; null ohne (ältere Backups) oder wenn unlesbar. */
function read_backup_info(string $backupPath): ?array
{
    $path = backup_info_path($backupPath);
    $data = is_file($path) ? json_decode((string) file_get_contents($path), true) : null;
    return is_array($data) && is_array($data['fields'] ?? null) ? $data : null;
}

/**
 * Kurzinfo zum Speichern einer Seite oder Komponente von $old auf $new: $user, sonst der angemeldete
 * Benutzer, und je geändertem Feld ID, Feldart ($kinds, sonst nach der ID), Name (wie im Editor,
 * core/labels.php, aus $doc oder der Quelldatei), alter und neuer Text gekürzt.
 */
function backup_info(string $name, array $old, array $new, array $kinds, ?array $doc, bool $restored, ?string $user = null): array
{
    $before = flatten_content($old);
    $after = flatten_content($new);
    $labels = null;
    $fields = [];
    foreach (array_keys($after + $before) as $id) {
        $id = (string) $id;
        $oldValue = (string) ($before[$id] ?? '');
        $newValue = (string) ($after[$id] ?? '');
        if ($oldValue === $newValue) {
            continue;
        }
        $labels ??= page_label_table($name, $doc ?? page_source_doc($name));
        $kind = $kinds[$id] ?? field_kind($id);
        $fields[] = [
            'id' => $id,
            'kind' => $kind,
            'label' => label_for_id($labels, field_id_prefix($name) . $id, $name),
            'old' => text_excerpt(field_plain_text($kind, $oldValue), BACKUP_INFO_TEXT_MAX),
            'new' => text_excerpt(field_plain_text($kind, $newValue), BACKUP_INFO_TEXT_MAX),
        ];
    }
    return ['user' => $user ?? current_user()['username'] ?? null, 'restored' => $restored, 'fields' => $fields];
}

/**
 * Legt das Backup einer Seite oder Komponente mit Inhalt $data an und liefert seinen Pfad. Name =
 * Zeitpunkt (BACKUP_STAMP_FORMAT, UTC): jetzt, mindestens aber eine Sekunde nach dem neuesten
 * vorhandenen, damit das neueste das neueste bleibt (viele Saves je Sekunde, Uhr zurückgesprungen).
 * Exklusiv und atomar angelegt (le_create_file_atomic): auch gleichzeitige Saves überschreiben nie ein Backup, ein
 * belegter Name rückt eine Sekunde weiter, ein Abbruch hinterlässt kein halbes.
 */
function create_backup_file(string $page, string $data): string
{
    $dir = BACKUPS_ROOT . '/' . safe_page_name($page);
    ensure_dir($dir);
    $time = time();
    foreach (page_backup_files($page) as $file) {
        $time = max($time, (backup_timestamp($file) ?? 0) + 1);
    }
    for ($attempt = 0; $attempt < BACKUP_CREATE_ATTEMPTS; $attempt++, $time++) {
        $path = $dir . '/' . gmdate(BACKUP_STAMP_FORMAT, $time) . '.json';
        try {
            if (le_create_file_atomic($path, $data)) {
                return $path;
            }
        } catch (RuntimeException $e) {
            break;
        }
    }
    json_response(['ok' => false, 'error' => API_TEXT['backupFailed']], 500);
}

function prune_backups(string $page, int $keep = BACKUP_RETENTION): void
{
    $files = page_backup_files($page);
    if (count($files) <= $keep) {
        return;
    }
    rsort($files);
    foreach (array_slice($files, $keep) as $old) {
        @unlink($old);
        @unlink(backup_info_path($old));
    }
}

/**
 * $kinds: Feldarten aus der Datei (siehe sanitize_content_tree). Gleicht der Inhalt dem
 * gespeicherten, wird nichts geschrieben und kein Backup angelegt (wiederholter Import), außer
 * es kommen Komponenten dieses Speicherns mit ($history['components'], save_page_group).
 * Neben dem Backup liegt die Kurzinfo für den Verlauf (backup_info); $history: 'doc' = Baum der
 * neuen Quelldatei für die Feldnamen (Import, sonst wird die Datei gelesen), 'restored' = true
 * beim Wiederherstellen, 'components' = Name → ['before' => Inhalt davor, 'after' => Inhalt
 * danach, 'fields' => Felder (ID mit Präfix)] (save_page_group), 'user' = Urheber statt des
 * angemeldeten Benutzers (Abgleich, LE_SYNC_AUTHOR). Liefert die Kurzinfo des
 * Backups ([] ohne Backup, erste JSON) oder null, wenn nichts geschrieben wurde. Der Aufrufer
 * hält die Sperre (lock_pages) und räumt alte Backups erst weg, wenn alles geschrieben ist
 * (prune_backups), damit ein Fehler danach den Stand davor wiederherstellen kann.
 * $sourceHash: Hash der Quelldatei nach diesem Schreiben (le_plan_source_hash), null behält den
 * gemerkten; ändert sich nur er, schreibt le_write_source_hash ihn ohne Backup (Rückgabe null).
 */
function save_page_content(string $page, array $content, array $kinds = [], array $history = [], ?string $sourceHash = null): ?array
{
    prepare_storage();
    $page = safe_page_name($page);
    $path = page_json_path($page);
    $components = $history['components'] ?? [];

    $content = sanitize_content_tree($content, $kinds);
    $current = is_file($path) ? (string) file_get_contents($path) : null;
    $storedHash = $current === null ? null : le_page_json_source_hash($current);
    $sourceHash ??= $storedHash;
    $json = page_json_text($content, $sourceHash);
    if ($json === null) {
        json_response(['ok' => false, 'error' => API_TEXT['encodeFailed']], 500);
    }
    if ($current === null) {
        atomic_write($path, $json);
        return [];
    }
    if ($current === $json && $components === []) {
        return null;
    }
    $old = le_page_json_content($current);
    if ($sourceHash !== $storedHash && $components === [] && $old !== null && page_json_text($old) === page_json_text($content)) {
        le_write_source_hash($page, (string) $sourceHash);
        return null;
    }
    $delay = (int) getenv(SAVE_DELAY_ENV);
    if ($delay > 0) {
        usleep($delay * 1000);
    }

    $backupPath = create_backup_file($page, $current);
    $info = backup_info($page, $old ?? [], $content, $kinds, $history['doc'] ?? null, !empty($history['restored']), $history['user'] ?? null);
    if ($components !== []) {
        $info['fields'] = array_merge($info['fields'], ...array_values(array_column($components, 'fields')));
        $info['components'] = array_map(static fn (array $component): array => ['before' => $component['before'], 'after' => $component['after']], $components);
    }
    $encoded = json_encode($info, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($encoded !== false) {
        atomic_write(backup_info_path($backupPath), $encoded . PHP_EOL);
    }

    atomic_write($path, $json);
    return $info;
}

/**
 * Inhalt der JSON einer Seite bzw. Komponente, wie save_page_content sie schreibt ($content
 * bereinigt, $sourceHash unter LE_SOURCE_HASH_KEY vorn); null, wenn er sich nicht kodieren lässt.
 */
function page_json_text(array $content, ?string $sourceHash = null): ?string
{
    $data = $sourceHash === null ? $content : [LE_SOURCE_HASH_KEY => $sourceHash] + $content;
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    return $json === false ? null : $json . PHP_EOL;
}

/**
 * Ein Speichern einer Seite samt Komponenten (api/savePage.php, api/restore.php): $plans Name →
 * ['content' => Inhalt, 'kinds' => Feldarten, 'file'/'source' wie aus plan_source_rewrite für den
 * Hash der Quelldatei] für die Seite $page und mitgeschickte Komponenten.
 * Erst die Komponenten, dann die Seite. Hat sich eine Komponente geändert, bekommt die Seite einen
 * Verlaufseintrag, auch wenn sie selbst gleich bleibt: Seine Kurzinfo nennt die Felder der
 * Komponente (ID mit Präfix, Name wie im Editor, 'component' = ihr Name) und trägt ihren Inhalt davor und danach, damit
 * „Diesen Stand wiederherstellen“ sie mit zurücksetzt (backup_components).
 * Liefert, ob eine JSON geschrieben wurde. Der Aufrufer hält die Sperre (lock_pages).
 */
function save_page_group(string $page, array $plans, bool $restored = false): bool
{
    $written = false;
    $components = [];
    foreach ($plans as $name => $plan) {
        $name = (string) $name; // Seiten wie „404“: PHP macht den Schlüssel zur Zahl.
        if ($name === $page) {
            continue;
        }
        $before = load_component_content($name) ?? [];
        $info = save_page_content($name, $plan['content'], $plan['kinds'], ['restored' => $restored], le_plan_source_hash($plan));
        $written = $written || $info !== null;
        if (($info['fields'] ?? []) !== []) {
            $prefix = field_id_prefix($name);
            $components[$name] = [
                'before' => $before,
                'after' => load_component_content($name) ?? [],
                'fields' => array_map(static fn (array $field): array => ['id' => $prefix . $field['id'], 'component' => $name] + $field, $info['fields']),
            ];
        }
    }
    $info = save_page_content($page, $plans[$page]['content'], $plans[$page]['kinds'], ['restored' => $restored, 'components' => $components], le_plan_source_hash($plans[$page]));
    return $written || $info !== null;
}

/**
 * Komponenten, die „Diesen Stand wiederherstellen“ mit dem Backup $backup (Name wie im Verlauf,
 * page_history) einer Seite mit zurücksetzt, Name → Inhalt: Ein Eintrag stellt den Stand nach
 * seinem Speichern her, also die Komponenten dieses Speicherns aus der Kurzinfo des Backups davor
 * ('after'); der älteste Stand den vor dem ältesten Speichern ('before' aus dessen Kurzinfo).
 * Leer für Kurzinfos ohne Zuordnung (ältere Backups) und unbekannte Backups.
 */
function backup_components(string $page, string $backup): array
{
    $files = page_backup_files($page);
    sort($files);
    $at = array_search($backup, array_map('basename', $files), true);
    if (!is_int($at)) {
        return [];
    }
    return $at > 0 ? info_components(read_backup_info($files[$at - 1]), 'after') : info_components(read_backup_info($files[$at]), 'before');
}

/** Komponenten einer Kurzinfo im Zustand $state ('before' oder 'after'): Name → Inhalt; leer ohne Zuordnung. */
function info_components(?array $info, string $state): array
{
    $components = [];
    foreach (is_array($info['components'] ?? null) ? $info['components'] : [] as $name => $states) {
        if (isset(shared_components()[$name]) && is_array($states[$state] ?? null)) {
            $components[$name] = $states[$state];
        }
    }
    return $components;
}

/** Zeitpunkt eines Backups aus seinem Namen (YmdHis, UTC); null bei fremden Namen. */
function backup_timestamp(string $backupPath): ?int
{
    $time = DateTimeImmutable::createFromFormat('!' . BACKUP_STAMP_FORMAT, basename($backupPath, '.json'), new DateTimeZone('UTC'));
    return $time === false ? null : $time->getTimestamp();
}

/** Gruppe einer Feldart im Verlauf (HISTORY_GROUPS); ohne Art (alte Kurzinfo) die erste, Text. */
function history_group(string $kind): string
{
    foreach (HISTORY_GROUPS as $group => $spec) {
        if (in_array($kind, $spec['kinds'], true)) {
            return $group;
        }
    }
    return array_key_first(HISTORY_GROUPS);
}

/**
 * Zusammenfassung einer Kurzinfo: je Seite und mitgespeicherter Komponente (Feld 'component',
 * save_page_group) ihre Felder (history_fields_summary), Komponenten mit ihrem Namen davor;
 * ein Wiederherstellen ist als solches gekennzeichnet.
 */
function backup_info_summary(?array $info): string
{
    $fields = $info['fields'] ?? [];
    $restored = !empty($info['restored']);
    if ($fields === []) {
        return $restored ? HISTORY_TEXT['restored'] : HISTORY_TEXT['saved'];
    }
    $groups = [];
    foreach ($fields as $field) {
        $groups[(string) ($field['component'] ?? '')][] = $field;
    }
    $parts = [];
    foreach ($groups as $component => $groupFields) {
        // Ein Name aus der ID nennt die Komponente schon („Kopfzeile Logo: Alt-Text“, label_from_id).
        $summary = history_fields_summary($groupFields);
        $name = COMPONENT_LABELS[$component] ?? $component;
        $parts[] = $component === '' || str_starts_with($summary, $name) ? $summary : $name . HISTORY_TEXT['componentLead'] . $summary;
    }
    return ($restored ? HISTORY_TEXT['restored'] . HISTORY_TEXT['restoredLead'] : '') . implode(HISTORY_TEXT['components'], $parts);
}

/** Felder einer Kurzinfo: erstes Feld (Text mit neuem Text, sonst Art und Name), dazu die Zahl der übrigen je Gruppe. */
function history_fields_summary(array $fields): string
{
    [$open, $close] = HISTORY_TEXT['quote'];
    $label = (string) ($fields[0]['label'] ?? '');
    $text = (string) ($fields[0]['new'] ?? '');
    $word = HISTORY_GROUPS[history_group((string) ($fields[0]['kind'] ?? ''))]['word'];
    $parts = [match (true) {
        $word !== null => $word . $open . $label . $close,
        $text !== '' => $label . $open . $text . $close,
        default => $label,
    }];
    $counts = array_fill_keys(array_keys(HISTORY_GROUPS), 0);
    foreach (array_slice($fields, 1) as $field) {
        $counts[history_group((string) ($field['kind'] ?? ''))]++;
    }
    foreach ($counts as $group => $count) {
        if ($count > 0) {
            $parts[] = sprintf(HISTORY_GROUPS[$group]['more'][$count === 1 ? 0 : 1], $count);
        }
    }
    return implode(HISTORY_TEXT['list'], $parts);
}

/** Namen der Komponenten (COMPONENT_LABELS) zu Name → Inhalt, in deren Reihenfolge. */
function component_labels(array $components): array
{
    return array_values(array_intersect_key(COMPONENT_LABELS, $components));
}

/**
 * Verlauf einer Seite (api/listBackups.php), neuester Eintrag zuerst. Ein Eintrag je Speichern
 * (Backup samt Kurzinfo): Zeit, Benutzer, geänderte Felder, die fertige Zeile (text) und die
 * Namen der Komponenten, die „Diesen Stand wiederherstellen“ auf allen Seiten mit zurücksetzt
 * (components, wie backup_components; der Seiten-Editor fragt dann nach).
 * „Diesen Stand wiederherstellen“ meint den Stand nach diesem Speichern, das ist das nächste
 * Backup ('backup'); beim neuesten ist es der aktuelle Stand ('backup' null). Den Stand vor dem
 * ältesten Speichern gibt es als letzten Eintrag ohne Zeit. Zeiten in der App-Zeitzone (day_time_label).
 */
function page_history(string $page, int $now): array
{
    $files = page_backup_files($page);
    sort($files);
    $entries = [];
    foreach ($files as $i => $file) {
        $info = read_backup_info($file);
        if ($i === 0) {
            $entries[] = ['backup' => basename($file), 'time' => null, 'user' => null, 'fields' => [], 'text' => HISTORY_TEXT['oldest'], 'components' => component_labels(info_components($info, 'before'))];
        }
        $time = backup_timestamp($file);
        $parts = $time === null ? [] : [ucfirst(day_time_label($time, $now))];
        if (($info['user'] ?? null) !== null) {
            $parts[] = (string) $info['user'];
        }
        $parts[] = backup_info_summary($info);
        $entries[] = [
            'backup' => isset($files[$i + 1]) ? basename($files[$i + 1]) : null,
            'time' => $time === null ? null : gmdate('Y-m-d\TH:i:s\Z', $time),
            'user' => $info['user'] ?? null,
            'fields' => $info['fields'] ?? [],
            'text' => implode(HISTORY_TEXT['separator'], $parts),
            'components' => isset($files[$i + 1]) ? component_labels(info_components($info, 'after')) : [],
        ];
    }
    return array_reverse($entries);
}

function import_status(): ?array
{
    $path = CACHE_ROOT . '/import-status.json';
    if (!is_file($path)) {
        return null;
    }

    $data = json_decode((string) file_get_contents($path), true);
    return is_array($data) ? $data : null;
}

function save_import_status(array $status): void
{
    ensure_dir(CACHE_ROOT);
    $json = json_encode($status, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        json_response(['ok' => false, 'error' => API_TEXT['importStatusFailed']], 500);
    }
    // atomic_write antwortet selbst mit 500, wenn es nicht schreiben kann.
    atomic_write(CACHE_ROOT . '/import-status.json', $json . PHP_EOL);
}
