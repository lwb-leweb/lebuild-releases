<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/plugins.php';
require_once __DIR__ . '/../../core/db.php';

require_admin();
require_csrf();
require_no_db_migration();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$name = (string) ($body['name'] ?? '');
if (!plugin_name_valid($name)) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidPlugin']], 400);
}

// Lesen → Ändern → Schreiben von active-plugins.json unter Sperre, bis zum Ende des Requests.
$lock = store_lock('plugins');
$state = load_plugins_state();
if (!isset($state['installed'][$name])) {
    json_response(['ok' => false, 'error' => API_TEXT['pluginNotInstalled']], 404);
}

$manifest = null;
try {
    $manifest = plugin_manifest($name);
} catch (Throwable $e) {
    $manifest = null;
}

// Beim Installieren gemerkte Tabellen. Ohne lesbare plugin.json (kaputt oder gelöscht) zählen nur
// sie: Das Plugin braucht eine Datenbank, sobald welche gemerkt sind.
$tables = plugin_valid_tables($state['installed'][$name]['tables'] ?? []);
$usesDatabase = $manifest !== null ? !empty($manifest['requires']['database']) : $tables !== [];

if ($usesDatabase) {
    $sqlPath = $manifest !== null ? plugin_sql_path($name, 'uninstall') : null;
    try {
        if ($sqlPath !== null && is_file($sqlPath)) {
            db()->exec((string) file_get_contents($sqlPath));
        } elseif ($tables) {
            // Ohne Datei für den aktiven Treiber (oder ohne Manifest) die gemerkten
            // Tabellen entfernen, damit keine Daten liegen bleiben.
            db_drop_tables(db(), $tables);
        }
    } catch (Throwable $e) {
        error_log('plugin uninstall ' . $name . ': ' . $e->getMessage());
        json_response(['ok' => false, 'error' => API_TEXT['uninstallFailed']], 500);
    }
    // SQLite gibt den Platz gelöschter Tabellen erst mit VACUUM frei. Scheitert
    // es, bleibt die Datei nur größer; die Deinstallation gilt trotzdem.
    if (db_driver() === DB_DRIVER_SQLITE) {
        try {
            db()->exec('VACUUM');
        } catch (Throwable $e) {
        }
    }
}

unset($state['installed'][$name]);
$state['active'] = array_values(array_diff($state['active'], [$name]));

try {
    save_plugins_state($state);
} catch (Throwable $e) {
    error_log('plugin uninstall ' . $name . ': ' . $e->getMessage());
    json_response(['ok' => false, 'error' => API_TEXT['pluginStateFailed']], 500);
}
le_activity_log('plugin_uninstalled', $name);

json_response(['ok' => true, 'name' => $name, 'state' => load_plugins_state()]);
