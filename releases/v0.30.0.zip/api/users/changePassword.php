<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/users.php';

// Auch während eines erzwungenen Passwortwechsels erreichbar.
require_auth(true);
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$newPassword = (string) ($body['newPassword'] ?? '');
$currentPassword = (string) ($body['currentPassword'] ?? '');
$targetId = trim((string) ($body['id'] ?? ''));

$self = current_user();
if ($self === null) {
    json_response(['ok' => false, 'error' => API_TEXT['notAuthenticated']], 401);
}

if ($targetId === '' || $targetId === $self['id']) {
    $isSelf = true;
    $targetId = $self['id'];
} else {
    $isSelf = false;
    if (!is_admin()) {
        json_response(['ok' => false, 'error' => API_TEXT['forbidden']], 403);
    }
}

// Das Standardpasswort ist kürzer als PASSWORD_MIN_LENGTH und fällt schon hier durch.
if ($error = users_validate_password($newPassword)) {
    json_response(['ok' => false, 'error' => $error], 400);
}

// Falsche aktuelle Passwörter zählen wie Fehlversuche beim Login je Adresse (derselbe Zähler) und dazu je Session: Mit
// einer übernommenen Session ließe sich sonst unbegrenzt raten. Nicht je Benutzer: Fehlversuche anderer für denselben
// Namen sperrten sonst den angemeldeten Benutzer aus. Geprüft wird unten unter der Sperre noch einmal.
if ($isSelf && empty($self['mustChangePassword'])) {
    $cutoff = time() - LOGIN_FAILURE_WINDOW;
    $sessionFailures = array_values(array_filter((array) ($_SESSION[LE_PASSWORD_FAILURES_SESSION_KEY] ?? []), static fn (mixed $t): bool => is_int($t) && $t > $cutoff));
    if (count($sessionFailures) >= LOGIN_MAX_FAILURES || !login_attempt_begin()) {
        json_response(['ok' => false, 'error' => LOGIN_THROTTLED_MESSAGE], LOGIN_THROTTLED_STATUS);
    }
    if (!users_verify_password($self, $currentPassword)) {
        $_SESSION[LE_PASSWORD_FAILURES_SESSION_KEY] = [...$sessionFailures, time()];
        json_response(['ok' => false, 'error' => API_TEXT['wrongPassword']], 400);
    }
    login_attempt_forget();
}

$changed = le_users_update_or_fail(static function (array &$store) use ($targetId, $isSelf, $currentPassword, $newPassword): array {
    $index = null;
    foreach ($store['users'] as $i => $user) {
        if ($user['id'] === $targetId) {
            $index = $i;
            break;
        }
    }
    if ($index === null) {
        json_response(['ok' => false, 'error' => API_TEXT['userNotFound']], 404);
    }

    // Beim erzwungenen Wechsel nach dem Erst-Login ist das alte Passwort das
    // bekannte Standardpasswort; die frische Session reicht als Nachweis.
    if ($isSelf && empty($store['users'][$index]['mustChangePassword'])) {
        if (!users_verify_password($store['users'][$index], $currentPassword)) {
            json_response(['ok' => false, 'error' => API_TEXT['wrongPassword']], 400);
        }
    }

    $store['users'][$index]['passwordHash'] = password_hash($newPassword, PASSWORD_BCRYPT);
    $store['users'][$index]['updatedAt'] = current_iso_time();
    // Alle bestehenden Sessions des Benutzers enden (gestohlene Session nach einem Reset).
    $store['users'][$index]['sessionVersion'] = users_session_version($store['users'][$index]) + 1;
    if ($isSelf) {
        unset($store['users'][$index]['mustChangePassword']);
    }
    return $store['users'][$index];
});
le_activity_log('user_password_changed', $changed['username'], $self['username']);

// Die eigene Session läuft weiter, mit neuer ID und neuem Token (das Backend übernimmt es).
if ($isSelf) {
    auth_renew_session($changed);
    json_response(['ok' => true, 'csrfToken' => csrf_token()]);
}
json_response(['ok' => true]);
