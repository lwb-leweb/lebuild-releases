# Contact-Form Plugin -- Anleitung fuer KI-Agenten

## Was das Plugin tut

Das Plugin („Formulare“ im Admin) rendert per Shortcode ein einfaches Kontaktformular oder mit `data-form="<name>"` ein Formular aus `public/site/includes/forms/<name>.json` (Felder, Schritte, Anhänge; Aufbau in README, „Formulare aus einer Datei“). Es sendet an den Standard-Empfaenger, einen signierten Shortcode-Empfaenger bzw. den `recipient` der Formular-Datei.
Der Versand laeuft immer ueber den Core-Mailer (`core/mail.php`), der SMTP nutzt, wenn `content/config/mail.config.php` vorhanden ist, und sonst auf PHP `mail()` zurueckfaellt.
Es schuetzt sich selbst per Honeypot und datei-basiertem IP-Rate-Limit (kein externer Dienst, keine DB) und kann optionale Zusatzfelder ueber eine Whitelist im Plugin-Code in den Mailtext aufnehmen.

## Was du als KI tun darfst

- Formularfelder im Renderer erweitern, wenn die Submit-Validierung synchron angepasst wird.
- Betreff, Textformat und Redirect-Verhalten vorsichtig anpassen.
- Sicherheitslogik fuer Spam-Schutz ergaenzen, z.B. Honeypot oder Rate-Limit.
- Dokumentation und Changelog bei jeder funktionalen Aenderung aktualisieren.

## Was du NICHT anfassen darfst

- Keine SMTP-Logik in dieses Plugin kopieren. Mailversand gehoert in `core/mail.php`.
- Keine SMTP-Passwoerter in `content/config.json`, Page-JSON oder Plugin-Manifest speichern.
- Die Empfaenger-Signatur nicht entfernen, weil sonst Formular-Posts beliebige Empfaenger setzen koennten.
- Keine Datenbank-Abhaengigkeit einbauen.

## Dateistruktur

- `plugin.json` -- Manifest, Shortcode-Definition und Mail-Capability.
- `lib.php` -- Empfaenger-Ermittlung, signierte Empfaenger-Felder, Feld-Registry (`contact_form_extra_fields`), Mailtext (`contact_form_mail`), Honeypot- und Rate-Limit-Helper, Spamschutz-Konstanten.
- `api/submit.php` -- oeffentlicher Frontend-Endpoint fuer Formular-Posts (Honeypot -> Rate-Limit -> Validierung -> Whitelist-Body -> Versand).
- `api/form.php` -- Endpoint fuer Formulare aus einer Datei (Name in `?form=`, gleicher Ablauf, Eingaben gegen die Definition, Anhaenge).
- `render/form.php` -- Shortcode-Renderer fuer das Formular (inkl. Honeypot- und Registry-Feldern); mit `form`-Attribut bindet er `render/definition.php` ein.
- `render/definition.php` -- HTML eines Formulars aus einer Datei.
- `assets/form.js` -- Schritte einzeln zeigen, je Schritt pruefen, Groesse der Anhaenge pruefen. Ohne JS muss alles funktionieren.
- `AGENT.md` -- diese Arbeitsanleitung.
- `README.md` -- Nutzer- und Entwicklerdokumentation.

## Datenbank

Keine Datenbank. Das Plugin speichert selbst keine Inhalte. Der Rate-Limit-State liegt wegwerfbar unter `content/cache/contact-form/ratelimit/<hash>.json` -- nur gehashte IP + Timestamps, niemals Roh-IP.

## Haeufige Anpassungen -- wie geht das?

Neues Pflicht-Formularfeld hinzufuegen:
1. Feld in `render/form.php` rendern.
2. Wert in `api/submit.php` lesen und validieren, in `contact_form_mail()` in den Mailtext aufnehmen.
3. README und Changelog aktualisieren.

Optionales Zusatzfeld (Whitelist) hinzufuegen:
1. Schluessel + Label in `contact_form_extra_fields()` in `lib.php` ergaenzen (Reihenfolge = Reihenfolge im Mailtext, Label generisch halten).
2. Mehr ist nicht noetig: `render/form.php` rendert das Feld automatisch, `contact_form_mail()` liest, bereinigt (`core_mail_clean_header`, max. 200 Zeichen) und haengt es an den Body. Niemals beliebige `$_POST`-Keys uebernehmen -- nur die Registry.
3. Kein reservierter Key (`name`, `email`, `message`, `recipient`, `recipient_sig`, der Honeypot) gehoert in die Registry.
4. README und Changelog aktualisieren.

Standard-Empfaenger aendern:
1. Nicht im Plugin hart codieren.
2. Admin -> Einstellungen -> E-Mail / SMTP -> Standard-Empfaenger nutzen.
3. Alternativ im Shortcode `data-recipient` setzen; der Renderer signiert diesen Wert per HMAC mit `app_secret()` (`CONTACT_FORM_SIGNATURE_CONTEXT`). Ohne `data-recipient` kommt kein Empfänger in die Seite, `submit.php` nimmt den beim Absenden eingestellten.

Mailversand anpassen:
1. Nur den Aufruf von `core_mail_send()` in `api/submit.php` anpassen.
2. Transportdetails bleiben im Core-Mailer.

Neuen Feldtyp fuer Formulare aus einer Datei:
1. In `CONTACT_FORM_FIELD_TYPES` aufnehmen, Extras in `contact_form_definition_field()` pruefen.
2. Wert in `contact_form_definition_input()`/`contact_form_value_valid()` pruefen, HTML in `render/definition.php`.
3. Test in `tests/forms.test.php`, README (Feldtabelle) und Changelog.

## Fehlervermeidung

- Formular-Dateien sind vertrauenswuerdig (Repo der Website), Besucher schicken nur den Namen; der Name geht nur durch `contact_form_definition_name_valid()` in einen Pfad. Uebernommen werden nur Felder der Definition, nie beliebige `$_POST`-Keys.
- `showIf` wertet der Server selbst aus (`contact_form_condition_met()` in `contact_form_definition_input()`), nie dem Browser glauben: Ausgeblendete Felder werden nicht geprueft und nicht uebernommen. Bedingungen zeigen nur auf fruehere Felder mit `options` (keine Zyklen).
- Anhaenge werden nie gespeichert, nur gemailt: Endung aus `CONTACT_FORM_FILE_TYPES` und `accept`, Inhalt per finfo passend (docx/xlsx mit ZipArchive als OOXML-Dokument der Art, `contact_form_ooxml_valid`), zusammen hoechstens `CONTACT_FORM_FILE_MAX_TOTAL`. Die Upload-Whitelist des Kerns (Bilder auf dem Server) gilt dafuer nicht.

- `api/submit.php` bleibt bewusst ohne Admin-Auth, weil Website-Besucher das Formular absenden muessen.
- Dynamische Werte im Renderer immer mit `htmlspecialchars()` escapen.
- Werte der Besucher kommen wörtlich in die Mail (kein `strip_tags`, „<3“ bleibt); das geht nur, weil die Mail `text/plain` ist. Eine HTML-Mail müsste jeden Wert escapen.
- Besucher-E-Mail nur als `Reply-To` verwenden, nicht als SMTP-Absender.
- Fehlerdetails aus SMTP nicht im Frontend ausgeben; sie koennen interne Hostnamen verraten. Antworttexte nur aus `CONTACT_FORM_TEXT` (`lib.php`), nie als Literal oder Exception-Text.
- Honeypot-Treffer NIE mit `400`/`500` beantworten -- immer mit `303` wie ein Erfolg (`contact_form_submit_redirect()`), sonst lernen Bots den Mechanismus.
- Rate-Limit-Slot mit `contact_form_rate_reserve()` erst NACH Honeypot und Validierung, aber VOR `core_mail_send()` reservieren (Pruefen und Eintragen unter einer Sperre, sonst unterlaufen parallele Anfragen das Limit). Scheitert der Versand, `contact_form_rate_release()`. Frueher reservieren hiesse: Bots fuellen das Fenster mit Garbage-Posts und sperren echte Nutzer aus. `contact_form_rate_check()` ist nur die fruehe 429-Pruefung.
- Niemals die Roh-IP im Rate-Limit-State speichern, nur den HMAC mit dem Installations-Schlüssel (`hash_hmac('sha256', le_login_ip_key(IP), app_secret())`, IPv6 je /64-Netz).
- `subject` aus der Registry ist nur ein Body-Feld und darf den Mail-Betreff NICHT setzen (Header-Injection). Betreff bleibt `Kontaktformular: {name}`.
- Hinter Cloudflare/Proxy ist `REMOTE_ADDR` die Proxy-IP -- das Rate-Limit greift dann global. `X-Forwarded-For` wird bewusst nicht vertraut (spoofbar).
