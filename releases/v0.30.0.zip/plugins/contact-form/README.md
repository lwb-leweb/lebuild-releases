# Formulare (Plugin `contact-form`)

Rendert per Shortcode das feste Kontaktformular oder ein eigenes Formular aus einer Datei der Website (beliebige Felder, mehrere Schritte, Anhänge). Der Versand nutzt den zentralen Core-Mailer: SMTP, wenn in den globalen Einstellungen konfiguriert, sonst PHP `mail()`. Der interne Name bleibt `contact-form`, im Admin heißt es „Formulare“.

## Aktivierung

Im Admin unter "Erweiterungen" das Plugin "Formulare" aktivieren. Es legt keine Datenbanktabellen an.

## Was es kann

- Kontaktformular per Shortcode rendern
- Name, E-Mail und Nachricht validieren
- Standard-Empfaenger aus den globalen Mail-Einstellungen verwenden
- Optional signierten Shortcode-Empfaenger verwenden
- Versand ueber SMTP oder PHP `mail()` via Core-Mailer
- Spamschutz ohne externen Dienst: Honeypot-Feld + datei-basiertes IP-Rate-Limit (max. 5 Submits / 60 Min / IP)
- Optionale Zusatzfelder (Firma, Telefon, Telegram, Betreff) ueber eine Whitelist im Plugin-Code -- werden mit Label oberhalb der Nachricht in den Mailtext aufgenommen
- Eigene Formulare aus `public/site/includes/forms/<name>.json`: zehn Feldtypen, mehrere Schritte, Abhängigkeiten zwischen Feldern, Dateien als Mail-Anhang (siehe „Formulare aus einer Datei“)

## Formulare aus einer Datei

Wir legen jedes Formular als JSON im Repo der Website an; der Kunde kann es nicht bearbeiten. Eingebunden wird es mit `data-form`:

```html
<div data-plugin="contact-form" data-view="form" data-form="projekt"></div>
```

Beispiel mit allen Feldtypen und einer Abhängigkeit: `public/site/includes/forms/projekt.json` (Testseite `/anfrage`).

| Schlüssel | Bedeutung |
|---|---|
| `title` | Erste Zeile der Mail, Vorgabe für den Betreff |
| `subject` | Betreff, `{feldname}` wird durch den Wert ersetzt (optional) |
| `recipient` | Empfänger (optional, sonst Standard-Empfänger der Einstellungen) |
| `submit`, `next`, `back` | Knopftexte (Vorgabe Absenden, Weiter, Zurück) |
| `success` | eigene Erfolgsmeldung (optional) |
| `fields` oder `steps` | Liste der Felder, oder Schritte `[{ "title": "…", "fields": [...] }]` |

Feld: `name` (`a-z0-9_`, nicht `url`, `form`, `recipient`, `recipient_sig`), `label`, `type`, optional `required`, `placeholder`, `help`, `showIf`.

### Abhängigkeiten (`showIf`)

Ein Feld oder ein ganzer Schritt erscheint nur, wenn ein früheres Feld mit `options` (`radio`, `select`, `checkbox`) eine bestimmte Antwort hat:

```json
{ "title": "Deine bestehende Website", "showIf": { "field": "bestehend", "value": "Ja" }, "fields": [...] }
{ "name": "anders", "label": "Was genau?", "type": "textarea", "required": true, "showIf": { "field": "funktionen", "value": ["Etwas anderes"] } }
```

- `value`: eine Option oder eine Liste (eine davon genügt; bei Checkboxen: eine davon angehakt). Nur Optionen des Feldes, sonst ist die Datei ungültig.
- Ausgeblendet heißt: nicht ausgefüllt. `assets/form.js` blendet ein und aus, ausgeblendete Felder sind `disabled`, Schritte fallen aus „Weiter“ und der Zählung; `required` gilt nur, solange das Feld zu sehen ist.
- Der Server wertet dieselben Bedingungen aus und übergeht ausgeblendete Felder (keine Prüfung, nicht in der Mail, Anhänge verworfen). Ohne JavaScript stehen alle Felder da, bedingte ohne `required`.
- Ketten gehen: hängt ein Feld an einem ausgeblendeten, ist es auch aus.
- Fortschritt: `assets/form.js` setzt `--le-form-progress` (0 bis 1) an `.le-form__progress`, z. B. für einen Balken.

| `type` | Extra | Mail |
|---|---|---|
| `text`, `tel`, `textarea` | `maxlength` (höchstens 200, mehrzeilig 5000) | Wert |
| `email` | – | Wert; das erste E-Mail-Feld wird Reply-To |
| `number` | `min`, `max`, `step` | Wert |
| `date` | – | `JJJJ-MM-TT` |
| `select`, `radio` | `options` (Liste aus Texten) | gewählte Option |
| `checkbox` | mit `options`: Mehrfachauswahl; ohne: ein Kästchen (z. B. Zustimmung) | Optionen mit Komma bzw. „Ja“ |
| `file` | `multiple`, `accept` (Teilmenge von pdf, jpg, jpeg, png, webp, heic, docx, xlsx) | Dateinamen, Dateien als Anhang |

- Der Server prüft jede Eingabe gegen die Datei: Pflichtfelder, Typ, Optionen, Endung und Inhalt der Datei (finfo, falls vorhanden; ohne finfo nur die Endung). `docx`/`xlsx` müssen mit der zip-Erweiterung zudem ein echtes Word- bzw. Excel-Dokument sein (`[Content_Types].xml` nennt einen vorhandenen Hauptteil dieser Art, Name egal; mit Makros, also docm/xlsm, nicht), ohne sie reicht wie bisher, was finfo meldet (auch ein beliebiges ZIP). Alle Anhänge zusammen höchstens 10 MB, höchstens 10 Dateien; nichts bleibt auf dem Server.
- Andere POST-Felder werden ignoriert. Honeypot und Rate-Limit wie beim Kontaktformular.
- Mehrere Schritte zeigt `assets/form.js` einzeln mit Weiter/Zurück und prüft je Schritt; ohne JavaScript stehen alle untereinander.
- Eine kaputte Datei gibt nur `<!-- contact-form: form invalid -->` aus, der Grund steht im PHP-Log.
- Klassen zum Gestalten: `le-form`, `le-form__step`, `le-form__step-title`, `le-form__progress`, `le-form__field` (`--<type>`), `le-form__option`, `le-form__help`, `le-form__required`, `le-form__nav`, `le-form__back`, `le-form__next`, `le-form__submit`, `le-form__notice--ok`/`--error`.

## Im Admin verwenden

SMTP wird nicht im Plugin selbst gepflegt. Die Einstellungen liegen global unter "Einstellungen" -> "E-Mail / SMTP".

## API-Endpoints

| Endpoint | Methode | Auth | Parameter | Response |
|---|---|---|---|---|
| `/plugins/contact-form/api/submit.php` | POST | nein | `name`, `email`, `message`, `recipient` und `recipient_sig` (nur mit `data-recipient`), optional `company`, `phone`, `telegram`, `subject`, Honeypot `url` | siehe Antwort-Codes unten |
| `/plugins/contact-form/api/form.php?form=<name>` | POST (multipart) | nein | Felder der Formular-Datei, Honeypot `url` | wie unten, dazu `400` „Bitte die Eingaben prüfen.“, „Dieser Dateityp ist nicht erlaubt.“, „Unbekanntes Formular.“ und `413` „Die Dateien sind zu groß.“; aus dem Browser `?formular-<name>=<ergebnis>#formular-<name>` (zusätzlich `ungueltig`, `dateityp`, `zu-gross`, `unbekannt`) |

Beispiel:

```bash
curl -i -X POST https://example.com/plugins/contact-form/api/submit.php \
  -d 'name=Max' \
  -d 'email=max@example.com' \
  -d 'message=Hallo'
```

### Antwort-Codes

| Fall | Code | Body | AJAX (`res.ok`) |
|---|---|---|---|
| Erfolg | `303` | `Location: Referer` | true (Redirect folgt) |
| Honeypot-Treffer | `303` | `Location: Referer` | true (stiller Drop, keine Mail) |
| Pflichtfeld fehlt | `400` | „Fehlende Felder." | false |
| Ungueltige E-Mail | `400` | „Ungültige E-Mail." | false |
| Rate-Limit | `429` | „Zu viele Anfragen, bitte später erneut." | false |
| Kein Empfänger (kein signierter `recipient` bzw. keiner in der Formular-Datei, kein Standard-Empfänger in den Einstellungen) | `500` | „Empfänger-Adresse nicht konfiguriert." | false |
| Versand-Fehler | `500` | „Versand fehlgeschlagen." | false |

Ein Honeypot-Treffer antwortet bewusst wie ein Erfolg, damit Bots den Mechanismus nicht erkennen.

Normales Absenden aus dem Browser (`Sec-Fetch-Mode: navigate`; ohne diesen Header: `Accept` beginnt mit `text/html` und kein `X-Requested-With`): Erfolg und jeder Fehler leiten per `303` auf die Seite des Formulars zurück (Pfad und Query des Referers wörtlich, nie ein fremder Host), mit `?kontakt=<ergebnis>#kontaktformular` (`gesendet`, `fehlende-felder`, `ungueltige-email`, `zu-viele`, `kein-empfaenger`, `versand`). Das Formular (`id="kontaktformular"`) zeigt dann die Meldung (`p.contact-form__notice--ok` bzw. `--error`); die Eingaben sind nach einem Fehler leer. Per `fetch`/curl bleibt es bei der Tabelle oben.

### Zusatzfelder (Whitelist)

Optionale Felder werden nur uebernommen, wenn ihr Name in der Registry `contact_form_extra_fields()` (`lib.php`) steht -- derzeit `company` (Firma), `phone` (Telefon), `telegram` (Telegram), `subject` (Betreff). Jeder Wert wird auf eine Zeile bereinigt und auf 200 Zeichen gekuerzt; leere Felder werden uebersprungen. `subject` landet nur im Body und setzt den Mail-Betreff nicht (bleibt `Kontaktformular: {name}`). Andere `$_POST`-Keys werden ignoriert.

### Spamschutz

- **Honeypot:** verstecktes Feld `url`. Befuellt -> stiller Drop (`303`), keine Mail.
- **Rate-Limit:** max. 5 Versandversuche pro IP (IPv6 je /64-Netz) und 60-Minuten-Fenster. Der Slot wird nach Honeypot und Validierung unter einer Dateisperre reserviert, bevor die Mail rausgeht; gleichzeitige Anfragen koennen das Limit so nicht gemeinsam unterlaufen. Scheitert der Versand, wird der Slot wieder frei. State liegt unter `content/cache/contact-form/ratelimit/<hash>.json` (gehashte IP, wegwerfbar). Bei Ueberschreitung `429`.

## Shortcodes

```html
<div data-plugin="contact-form" data-view="form"></div>
```

Mit explizitem Empfaenger:

```html
<div data-plugin="contact-form" data-view="form" data-recipient="office@example.com"></div>
```

| Attribut | Bedeutung |
|---|---|
| `recipient` | Optionaler Empfaenger. Wird serverseitig signiert, bevor das Formular ausgegeben wird. Ohne ihn steht weder Adresse noch Signatur in der Seite, `submit.php` nimmt den Standard-Empfänger, der beim Absenden eingestellt ist. |
| `form` | Name einer Formular-Datei in `public/site/includes/forms/`; dann gilt „Formulare aus einer Datei“ statt des Kontaktformulars. |

## Frontend einbinden

Den Shortcode-Marker in eine Seite unter `public/site/` setzen. Der Router ersetzt ihn bei aktiven Plugins durch das Formular mit der CSS-Klasse `contact-form` -- inklusive Honeypot-Feld und der Registry-Felder.

Custom-Formulare (eigenes Markup statt Shortcode) posten die Zusatzfelder direkt unter ihren Registry-Namen (`company`, `phone`, `telegram`, `subject`) und sollten das Honeypot-Feld `url` mitschicken (off-screen, `autocomplete=off`, `tabindex=-1`, `aria-hidden`).

## Bekannte Einschraenkungen

- Kein Captcha (externer Dienst + Keys) -- erst, wenn Honeypot + Rate-Limit nachweislich nicht reichen.
- Rate-Limit nutzt `REMOTE_ADDR`. Hinter Cloudflare/Proxy ist das die Proxy-IP, das Limit greift dann global statt pro Besucher. `X-Forwarded-For` wird bewusst nicht vertraut (spoofbar).
- Rate-Limit-State liegt in `content/cache/` und ist nicht persistent -- beim Leeren des Caches wird das Fenster zurueckgesetzt. Dateien, die eine Stunde nicht geschrieben wurden, loescht `contact_form_rate_prune()` gelegentlich (etwa jede 50. Reservierung).
- Betreff ist nicht vom Client steuerbar (Header-Injection-Schutz); `subject` ist nur ein Body-Feld.
- Nur Textmails; Anhänge nur bei Formularen aus einer Datei.
- Nach einem Fehler beim Server sind die Eingaben leer (die Prüfung im Browser fängt das Meiste vorher ab).
- Erfolg fuehrt zurueck zur Referrer-Seite.

## Changelog

- **2026-11-15** -- `docx`/`xlsx`-Anhänge: mit der zip-Erweiterung nur echte OOXML-Dokumente der passenden Art (Hauptteil laut `[Content_Types].xml`, auch `word/document2.xml` von Word Online), kein beliebiges ZIP und keine Makro-Dokumente.
- **2026-11-15** -- Ohne `data-recipient` stehen weder Standard-Empfänger noch Signatur in der Seite; `submit.php` nimmt den beim Absenden eingestellten. Signaturen haben einen neuen Kontext: Alte Kopien einer Seite mit dem früheren Standard-Empfänger gehen an den aktuellen. Ebenso geht ein Formular mit eigenem `data-recipient`, das vor dem Update geladen wurde (offener Tab), einmal an den aktuellen Standard-Empfänger statt an seinen; nach dem Neuladen gilt wieder `data-recipient`.

- **2026-11-14** -- Ein ungültiger Formularname aus `?form=` kommt nicht mehr roh ins Log (Zeilenumbrüche fälschten sonst Einträge).

- **2026-11-11 -- v1.4.0** -- Abhängigkeiten in Formularen aus einer Datei: `showIf` an Feldern und Schritten (`{ "field", "value" }`), im Browser ein- und ausgeblendet (`disabled`), der Server übergeht ausgeblendete Felder. Fortschritt zählt nur sichtbare Schritte und setzt `--le-form-progress`.

- **2026-11-11 -- v1.3.0** -- Formulare aus einer Datei (`data-form`, `public/site/includes/forms/<name>.json`): zehn Feldtypen, mehrere Schritte (`assets/form.js`), Dateien als Mail-Anhang (Core-Mailer kann jetzt `attachments`), Endpoint `api/form.php`. Im Admin heißt das Plugin „Formulare“; Kontaktformular unverändert.

- **2026-10-28** -- Name, Nachricht und Zusatzfelder kommen wörtlich in die Mail (kein `strip_tags` mehr, „Ich <3“ und „a < b“ bleiben); die Mail ist `text/plain`. Mailtext baut `contact_form_mail()`.
- **2026-10-28** -- Antworttexte von `submit.php` stehen in `CONTACT_FORM_TEXT` (falsche Methode: `API_TEXT['method']`, jetzt deutsch). Betreff kuerzt den Namen per `mb_substr` (kein halbierter Umlaut). Rate-Limit-Dateien, die eine Stunde nicht geschrieben wurden, raeumt etwa jede 50. Reservierung weg.
- **2026-10-28** -- Rate-Limit reserviert den Slot unter `flock` vor dem Versand (`contact_form_rate_reserve()`, bei Versandfehler `contact_form_rate_release()`), parallele Anfragen kommen nicht mehr ueber 5 pro Stunde.
- **2026-10-13 -- v1.2.1** -- Empfaenger-Signatur und Rate-Limit-Hash per HMAC mit dem Installations-Schluessel (`app_secret()`) statt mit Pfad + Admin-Passwort (war faelschbar).
- **2026-05-23 -- v1.2.0** -- Spamschutz im Plugin: Honeypot-Feld `url` (stiller `303`-Drop) und datei-basiertes IP-Rate-Limit (max. 5 / 60 Min, gehashter State unter `content/cache/`, `429` bei Ueberschreitung). Konfigurierbare Zusatzfelder ueber die Whitelist `contact_form_extra_fields()` (`company`, `phone`, `telegram`, `subject`) -- bereinigt, auf 200 Zeichen gekuerzt, mit Label in den Mailtext. `subject` bleibt ein Body-Feld. Renderer gibt Honeypot- und Registry-Felder aus. Kein Core-Eingriff am Mailer.
- **2026-05-21 -- v1.1.0** -- Versand auf den zentralen Core-Mailer umgestellt. SMTP wird global in den Einstellungen verwaltet; ohne SMTP bleibt PHP `mail()` als Fallback.
- **2026-05-20 -- v1.0.0** -- Erstes Release mit Shortcode-Formular und `mail()`-Versand.
