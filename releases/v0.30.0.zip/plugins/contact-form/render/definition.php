<?php
// Formular aus public/site/includes/forms/<name>.json (eingebunden von render/form.php mit $attrs['form']).
// Ohne JavaScript stehen alle Schritte untereinander; assets/form.js zeigt sie einzeln mit Weiter und Zurück.

$formName = (string) $attrs['form'];
try {
    $definition = contact_form_definition($formName);
} catch (Throwable $e) {
    error_log('contact-form form ' . $formName . ': ' . $e->getMessage());
    echo '<!-- contact-form: form invalid -->';
    return;
}

$h = static fn (string $value): string => htmlspecialchars($value, ENT_QUOTES);
$anchor = contact_form_definition_anchor($formName);
$notice = contact_form_result_notice($anchor);
if ($notice !== null && $notice['ok'] && $definition['success'] !== '') {
    $notice['text'] = $definition['success'];
}
$fields = contact_form_definition_fields($definition);
$hasFiles = array_filter($fields, static fn (array $f): bool => $f['type'] === 'file') !== [];
$multi = count($definition['steps']) > 1;

// showIf als Attribute (assets/form.js blendet ein und aus). Ohne JavaScript steht alles da, der Server übergeht Ausgeblendetes.
$condition = static fn (?array $if): string => $if === null ? ''
    : ' data-le-form-if="' . $h($if['field']) . '" data-le-form-if-values="' . $h((string) json_encode($if['values'], JSON_UNESCAPED_UNICODE)) . '"';

/** Ein Feld als HTML. $conditional: Feld oder sein Schritt hat showIf. */
$renderField = static function (array $field, bool $conditional) use ($h, $formName, $condition): string {
    $id = 'f-' . $formName . '-' . $field['name'];
    $name = $field['name'];
    // Bedingte Pflichtfelder setzt das Skript erst auf required, sonst hielte der Browser ohne Skript den anderen Zweig auf.
    $req = $field['required'] ? ($conditional || $field['showIf'] !== null ? ' data-le-form-required-shown' : ' required') : '';
    $if = $condition($field['showIf']);
    $mark = $field['required'] ? '<span class="le-form__required" aria-hidden="true">*</span>' : '';
    $help = $field['help'] !== '' ? '<p class="le-form__help" id="' . $h($id) . '-help">' . $h($field['help']) . '</p>' : '';
    $described = $field['help'] !== '' ? ' aria-describedby="' . $h($id) . '-help"' : '';
    $placeholder = $field['placeholder'] !== '' ? ' placeholder="' . $h($field['placeholder']) . '"' : '';
    $class = 'le-form__field le-form__field--' . $field['type'];

    // Auswahl aus mehreren (Radio, Checkboxen): eine Gruppe mit Legende.
    if ($field['type'] === 'radio' || ($field['type'] === 'checkbox' && $field['options'] !== [])) {
        $radio = $field['type'] === 'radio';
        $out = '<fieldset class="' . $class . '"' . $if . ($field['required'] && !$radio ? ' data-le-form-required' : '') . $described . '>'
            . '<legend>' . $h($field['label']) . $mark . '</legend>';
        foreach ($field['options'] as $option) {
            $out .= '<label class="le-form__option"><input type="' . ($radio ? 'radio' : 'checkbox') . '" name="' . $h($name) . ($radio ? '' : '[]')
                . '" value="' . $h($option) . '"' . ($radio ? $req : '') . '> ' . $h($option) . '</label>';
        }
        return $out . $help . '</fieldset>';
    }
    // Einzelne Checkbox (z. B. Zustimmung): Beschriftung neben dem Kästchen.
    if ($field['type'] === 'checkbox') {
        return '<div class="' . $class . '"' . $if . '><label class="le-form__option"><input type="checkbox" name="' . $h($name) . '" value="1" id="' . $h($id) . '"'
            . $req . $described . '> ' . $h($field['label']) . $mark . '</label>' . $help . '</div>';
    }

    $label = '<label for="' . $h($id) . '">' . $h($field['label']) . $mark . '</label>';
    $common = ' id="' . $h($id) . '"' . $req . $described;
    switch ($field['type']) {
        case 'textarea':
            $control = '<textarea name="' . $h($name) . '" rows="5" maxlength="' . $field['maxlength'] . '"' . $common . $placeholder . '></textarea>';
            break;
        case 'select':
            $control = '<select name="' . $h($name) . '"' . $common . '><option value="">' . $h($field['placeholder'] !== '' ? $field['placeholder'] : 'Bitte wählen') . '</option>';
            foreach ($field['options'] as $option) {
                $control .= '<option value="' . $h($option) . '">' . $h($option) . '</option>';
            }
            $control .= '</select>';
            break;
        case 'file':
            $accept = implode(',', array_map(static fn (string $ext): string => '.' . $ext, $field['accept']));
            $control = '<input type="file" name="' . $h($name) . ($field['multiple'] ? '[]" multiple' : '"') . ' accept="' . $h($accept) . '"' . $common . '>';
            break;
        default:
            $extra = isset($field['maxlength']) ? ' maxlength="' . $field['maxlength'] . '"' : '';
            foreach (['min', 'max', 'step'] as $key) {
                if (($field[$key] ?? null) !== null) {
                    $extra .= ' ' . $key . '="' . $h((string) $field[$key]) . '"';
                }
            }
            $autocomplete = ['email' => ' autocomplete="email"', 'tel' => ' autocomplete="tel"'][$field['type']] ?? '';
            $control = '<input type="' . $field['type'] . '" name="' . $h($name) . '"' . $common . $extra . $placeholder . $autocomplete . '>';
    }
    return '<div class="' . $class . '"' . $if . '>' . $label . $control . $help . '</div>';
};
?>
<form class="le-form" id="<?= $h($anchor) ?>" method="post" action="/plugins/contact-form/api/form.php?form=<?= $h(rawurlencode($formName)) ?>"<?= $hasFiles ? ' enctype="multipart/form-data"' : '' ?> data-le-form data-max-total="<?= CONTACT_FORM_FILE_MAX_TOTAL ?>">
  <?php if ($notice !== null): ?>
  <p class="le-form__notice le-form__notice--<?= $notice['ok'] ? 'ok' : 'error' ?>" role="<?= $notice['ok'] ? 'status' : 'alert' ?>"><?= $h($notice['text']) ?></p>
  <?php endif ?>
  <div class="le-form__hp" aria-hidden="true" style="position:absolute;left:-9999px;top:auto;width:1px;height:1px;overflow:hidden;">
    <label>Bitte leer lassen<input type="text" name="<?= $h(CONTACT_FORM_HONEYPOT) ?>" autocomplete="off" tabindex="-1"></label>
  </div>
  <?php if ($multi): ?>
  <p class="le-form__progress" data-le-form-progress hidden></p>
  <?php endif ?>
  <?php foreach ($definition['steps'] as $step): ?>
  <?php if ($multi || $step['title'] !== ''): ?>
  <fieldset class="le-form__step" data-le-form-step<?= $condition($step['showIf']) ?>>
    <?php if ($step['title'] !== ''): ?><legend class="le-form__step-title"><?= $h($step['title']) ?></legend><?php endif ?>
    <?php foreach ($step['fields'] as $field): ?><?= $renderField($field, $step['showIf'] !== null) ?><?php endforeach ?>
  </fieldset>
  <?php else: ?>
  <?php foreach ($step['fields'] as $field): ?><?= $renderField($field, $step['showIf'] !== null) ?><?php endforeach ?>
  <?php endif ?>
  <?php endforeach ?>
  <div class="le-form__nav">
    <?php if ($multi): ?>
    <button type="button" class="le-form__back" data-le-form-back hidden><?= $h($definition['back']) ?></button>
    <button type="button" class="le-form__next" data-le-form-next hidden><?= $h($definition['next']) ?></button>
    <?php endif ?>
    <button type="submit" class="le-form__submit"><?= $h($definition['submit']) ?></button>
  </div>
</form>
<script src="<?= $h(PLUGINS_URL . 'contact-form/assets/form.js') ?>" defer></script>
