# PDF-Blätterer Plugin

Zeigt ein PDF der Website zum Durchblättern wie ein Heft, etwa eine Gemeinde- oder Vereinszeitung, und die erste Seite eines PDFs als Titelbild. Gezeichnet wird im Browser mit PDF.js, das im Plugin liegt (keine Drittanbieter, kein Cookie-Banner nötig).

## Aktivierung

Im Admin unter „Plugins“ → „PDF-Blätterer“ aktivieren. Keine Tabelle, keine Einstellungen; ohne Aktivierung bleiben die Platzhalter leer.

## Was es kann

- Breite Bildschirme: Doppelseiten wie ein Heft (Titelseite allein rechts, mittig), Umblättern als 3D-Drehung des Blatts.
- Handy: eine Seite, Wischen oder Tippen links/rechts zum Blättern.
- Pfeiltasten, Vollbild, Seitenzahl, Download-Link; Adresse `#seite-<n>` öffnet eine Seite direkt.
- Zoom bis 300 %: Knöpfe „Verkleinern“/„Vergrößern“, Doppelklick bzw. Doppeltippen (200 % an dieser Stelle, nochmal: zurück), Strg+Mausrad und Zwei-Finger-Zoom am Touchpad oder Handy, Tasten `+`, `-`, `0`. Gezoomt verschieben Ziehen und Mausrad die Seiten, Blättern bleibt gezoomt (oben links); danach werden die Seiten in der neuen Größe scharf neu gezeichnet. Der Browser selbst zoomt auf dem Blätterer nicht mehr.
- Titelseite: erste Seite eines PDFs als Bild, gezeichnet, sobald sie in den sichtbaren Bereich kommt (für Karten ohne eigenes Titelbild).
- Nur PDFs dieser Website (Upload oder Datei unter `/public/site/`), die es gibt; anderes ergibt nur einen Kommentar.
- Skript und CSS kommen nur auf Seiten, die einen Platzhalter enthalten.

## Shortcodes

### `blaettern`

```html
<div data-plugin="pdf-viewer" data-view="blaettern" data-src="/public/site/uploads/zeitung-3-2026-a1b2c3.pdf"></div>
```

| Attribut | Pflicht | Bedeutung |
|---|---|---|
| `data-src` | ja | Adresse des PDFs dieser Website |
| `data-download` | nein | `nein` blendet den Link „PDF herunterladen“ aus |

Ausgabe: `.pdf-blaetterer` mit `.pdf-blaetterer__buehne` (Seiten; gezoomt `.pdf-blaetterer__ausschnitt` und am Element die Klasse `ist-gezoomt`), `.pdf-blaetterer__leiste` (Knöpfe `.pdf-blaetterer__knopf`, Zoom und Vollbild zusätzlich `--zoom`/`--neben`, Seitenzahl `.pdf-blaetterer__seite`, `.pdf-blaetterer__download`). Ungültige Adresse: `<!-- pdf-viewer: src invalid -->`.

### `titelseite`

```html
<span data-plugin="pdf-viewer" data-view="titelseite" data-src="/public/site/uploads/zeitung-3-2026-a1b2c3.pdf"></span>
```

Ausgabe: `.pdf-titelseite`, darin nach dem Laden `canvas.pdf-titelseite__bild` (füllt das Element; Größe und Seitenverhältnis gibt die Website vor).

## Frontend einbinden

Mit Content-Typen: ein Feld der Art `file` für das PDF, die Vorlage gibt den Platzhalter mit seinem Wert aus. In `detail.php` (eigene Seite) wird er ersetzt wie auf jeder Seite; in `card.php` (Liste) ersetzt ihn kein Renderer, das Skript liest dort `data-src` selbst.

```php
<div data-plugin="pdf-viewer" data-view="blaettern" data-src="<?= ct_text($item, 'pdf') ?>"></div>
```

Farben setzt die Website über Variablen an `.pdf-blaetterer`: `--pdf-blaetterer-hoehe`, `--pdf-blaetterer-text`, `--pdf-blaetterer-knopf`, `--pdf-blaetterer-knopf-text`, `--pdf-blaetterer-knopf-neben`, `--pdf-blaetterer-schatten`. Alle Regeln des Plugins stehen unter `:where()`, jede Regel der Website gewinnt.

## Bekannte Einschränkungen

- PDFs anderer Websites gehen nicht (der Browser lädt sie ohne CORS nicht, der Renderer lehnt sie ab).
- WebAssembly liefert der Server unter `/plugins` nicht aus: PDF.js nimmt seine JavaScript-Fassung der Bild-Decoder (langsamer bei JPEG 2000). Nicht eingebettete Schriften außer Helvetica/Arial (Liberation Sans) ersetzt der Browser.
- Große PDFs: Hochladen ist durch `UPLOAD_MAX_BYTES` und die PHP-Grenzen beschränkt (Server: 16 MB).
- Ein einfacher Klick auf eine Seitenhälfte blättert erst nach 260 ms (so lange wartet er auf einen Doppelklick).
- Leinwände sind höchstens 3200 px breit; darüber (sehr große Bildschirme bei 300 %) wird die Seite leicht unscharf.

## Changelog

- **2026-11-15 — v1.0.0** — Erste Fassung: Shortcodes `blaettern` (Doppelseiten, Umblättern, Zoom, Vollbild, Download) und `titelseite`; PDF.js 6.3.289 lokal.
