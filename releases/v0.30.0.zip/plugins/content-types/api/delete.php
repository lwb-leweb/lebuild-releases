<?php
declare(strict_types=1);

require_once __DIR__ . '/../../../core/auth.php';
require_once __DIR__ . '/../../../core/plugins.php';
require_once __DIR__ . '/../../../core/pluginSchema.php';
require_once __DIR__ . '/../lib.php';

require_auth();
require_csrf();
require_plugin_active('content-types');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$type = (string) ($body['type'] ?? '');
$id = (int) ($body['id'] ?? 0);
if (!content_types_name_valid($type) || $id <= 0) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidRequest']], 400);
}

try {
    content_types_delete($type, $id);
} catch (Throwable $e) {
    plugin_failure_response('delete', $e);
}
le_activity_log('plugin_entry_deleted', $type . ' #' . $id);

json_response(['ok' => true]);
