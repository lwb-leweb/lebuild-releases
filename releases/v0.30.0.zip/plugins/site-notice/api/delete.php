<?php
declare(strict_types=1);

// Löscht den einen Hinweis, unabhängig von der ID (Backend; die Einzelansicht im Seiten-Editor bietet kein Löschen,
// dort heißt Abschalten: Text leeren). Ohne Hinweis 404.
require_once __DIR__ . '/../lib.php';
require_once __DIR__ . '/../../../core/uploads.php';

require_auth();
require_plugin_active(SITE_NOTICE_PLUGIN);
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

try {
    $row = site_notice_entry();
    $deleted = $row !== null && plugin_delete_entry(SITE_NOTICE_PLUGIN, (int) $row['id']);
} catch (Throwable $e) {
    plugin_failure_response('delete', $e);
}
if (!$deleted) {
    json_response(['ok' => false, 'error' => API_TEXT['notFound']], 404);
}
le_activity_log('plugin_entry_deleted', le_activity_plugin_target(SITE_NOTICE_PLUGIN, (int) $row['id']));

json_response(['ok' => true]);
