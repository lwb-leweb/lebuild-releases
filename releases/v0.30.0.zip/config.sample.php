<?php
// Zugang des ersten Admins. Vor dem Hochladen nach config.php kopieren und ausfüllen.
// Beim ersten Login legt der Editor daraus den Admin an und leert das Passwort hier.
// Sobald es Benutzer gibt (content/users.json), gilt diese Datei nicht mehr.
return [
    // 3 bis 64 Zeichen: Buchstaben, Ziffern, Punkt, Unterstrich, Bindestrich.
    'username' => '',
    // 8 bis 72 Byte (Umlaute und Sonderzeichen zählen doppelt oder mehr).
    'password' => '',
];
