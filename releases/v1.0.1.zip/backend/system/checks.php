<?php
declare(strict_types=1);

require_once LE_BACKEND . '/users/auth.php';
require_once LE_BACKEND . '/base/db.php';
require_once LE_BACKEND . '/base/files.php';
require_once LE_BACKEND . '/media/images.php';

// Systemprüfung: einzige Quelle für die Voraussetzungen des Editors. Admin →
// Einstellungen → System und der Hinweis im Dashboard lesen beide hier.

// Gleich minPhp in release.json: Installationen mit älterem PHP spielen das Update nicht ein (backend/update/updater.php).
const SYSTEM_MIN_PHP_VERSION = '8.2';
// Ende der Sicherheitsupdates je PHP-Version (php.net/supported-versions). Danach meldet die
// Systemprüfung einen Mangel, der Editor läuft weiter; fehlende (neuere) Versionen gelten als versorgt.
const SYSTEM_PHP_SECURITY_UNTIL = [
    '8.0' => '2023-11-26',
    '8.1' => '2025-12-31',
    '8.2' => '2026-12-31',
    '8.3' => '2027-12-31',
    '8.4' => '2028-12-31',
    '8.5' => '2029-12-31',
];

// Systemprüfung private_htaccess (system_private_htaccess_ok); %s: Pfad der Datei relativ zum Ordner der Website.
const SYSTEM_PRIVATE_HTACCESS_TEXT = [
    'label' => 'Sperre in %s',
    'purpose' => '%s – fehlt oder ist geändert. Auf Apache ohne eigenen Webroot sperrt sie Benutzer, Schlüssel und Einstellungen auch dann,'
        . ' wenn die Weiterleitung an den Router ausfällt (etwa durch RewriteEngine Off). Fehlt sie, legt LeBuild sie an, sobald private/ beschreibbar ist'
        . ' (beim Anmelden, Speichern oder Import); ist sie geändert, die Datei löschen.',
];

function system_php_version_ok(string $version): bool
{
    return version_compare($version, SYSTEM_MIN_PHP_VERSION, '>=');
}

/** Bekommt diese PHP-Version am Tag $today (Y-m-d, sonst heute) noch Sicherheitsupdates? */
function system_php_security_supported(string $version, ?string $today = null): bool
{
    $until = SYSTEM_PHP_SECURITY_UNTIL[implode('.', array_slice(explode('.', $version), 0, 2))] ?? null;
    return $until === null || ($today ?? date('Y-m-d')) <= $until;
}

/**
 * Prüfliste mit key, label, ok und purpose (wofür es gebraucht wird).
 * $extensions/$phpVersion/$today vorgeben nur für Tests; ohne Angabe gilt die
 * laufende PHP-Umgebung.
 */
function system_checks(?array $extensions = null, string $phpVersion = PHP_VERSION, ?string $today = null): array
{
    $loaded = array_map('strtolower', $extensions ?? get_loaded_extensions());

    $versionOk = system_php_version_ok($phpVersion);
    $checks = [[
        'key' => 'php',
        'label' => 'PHP ' . $phpVersion . ' (mind. ' . SYSTEM_MIN_PHP_VERSION . ')',
        'ok' => $versionOk && system_php_security_supported($phpVersion, $today),
        'purpose' => $versionOk
            ? 'PHP-Version – PHP ' . $phpVersion . ' bekommt keine Sicherheitsupdates mehr, bitte beim Hoster eine neuere Version einstellen.'
            : 'PHP-Version – unter ' . SYSTEM_MIN_PHP_VERSION . ' läuft der Editor nicht.',
    ]];

    $extensionPurposes = [
        'openssl' => 'openssl – ohne sie werden keine Updates installiert.',
        'pdo_sqlite' => DB_SQLITE_MISSING_MESSAGE,
        'zip' => 'zip – ohne sie werden keine Updates entpackt und installiert und keine Sicherungen erstellt.',
        'curl' => 'curl – ohne sie lädt der Editor Updates nur, wenn der Hoster allow_url_fopen erlaubt.',
        'mbstring' => 'mbstring – ohne sie brechen Import und Bearbeiten von Texten mit einem Fehler ab.',
        'dom' => 'dom – ohne sie lassen sich keine SVG-Bilder hochladen.',
        'tokenizer' => 'tokenizer – ohne sie sind Texte in PHP-Seiten nicht bearbeitbar (PHP-Code wird nicht sicher erkannt).',
    ];
    foreach ($extensionPurposes as $name => $purpose) {
        $checks[] = [
            'key' => $name,
            'label' => 'PHP-Erweiterung ' . $name,
            'ok' => in_array($name, $loaded, true),
            'purpose' => $purpose,
        ];
    }

    // Mit vorgegebenen Erweiterungen (Tests) zählt gd als WebP-fähig.
    $checks[] = [
        'key' => 'gd',
        'label' => 'PHP-Erweiterung gd mit WebP',
        'ok' => in_array('gd', $loaded, true) && ($extensions !== null || le_image_webp_supported()),
        'purpose' => 'gd mit WebP – ohne sie werden hochgeladene Fotos (JPG) abgelehnt (das Original trüge GPS-Position und Gerät), PNG unverändert gespeichert.',
    ];

    $writablePaths = [
        'content' => [CONTENT_ROOT, 'ohne Schreibrechte werden keine Inhalte, Benutzer oder Einstellungen gespeichert.'],
        'site' => [LE_SITE_ROOT, 'ohne Schreibrechte werden Änderungen nicht in die Seiten der Website geschrieben.'],
        'uploads' => [UPLOADS_ROOT, 'ohne Schreibrechte lassen sich keine Bilder hochladen.'],
    ];
    foreach ($writablePaths as $key => [$path, $purpose]) {
        $relative = le_instance_relative($path) . '/';
        $checks[] = [
            'key' => 'writable_' . $key,
            'label' => 'Schreibrechte ' . $relative,
            'ok' => system_path_writable($path),
            'purpose' => $relative . ' – ' . $purpose,
        ];
    }

    // Auf Apache ohne einstellbaren Webroot (Domain auf den Hauptordner): Rewrite-Anweisungen in public/.htaccess, die die
    // geerbte Regel abschalten (RewriteEngine Off, RewriteOptions IgnoreInherit), lassen Apache das PHP der Website unter der
    // Adresse ihres Ordners selbst ausführen, am Router vorbei. Vorsichtig wie unten: jede Rewrite-Anweisung zählt. Die
    // Adresse gibt es nur, wenn die Website im Hauptordner liegt (Einzelinstallation); ein Kundenordner liegt außerhalb.
    $siteHtaccess = le_instance_relative(LE_SITE_ROOT) . '/.htaccess';
    $siteUrl = le_path_in(LE_SITE_ROOT, [LE_ROOT]) ? '/' . le_root_relative(LE_SITE_ROOT) . '/' : null;
    $checks[] = [
        'key' => 'site_rewrite',
        'label' => 'Keine Rewrite-Regeln in ' . $siteHtaccess,
        'ok' => !system_has_rewrite_rules(LE_SITE_ROOT . '/.htaccess'),
        'purpose' => $siteHtaccess . ' – eigene Rewrite-Anweisungen (auch RewriteEngine Off) heben auf Apache ohne eigenen Webroot die Weiterleitung an'
            . ' den Router auf: Apache führt das PHP der Website dann ' . ($siteUrl !== null ? 'unter ' . $siteUrl . ' ' : '')
            . 'selbst aus, ohne Shortcodes und Cookie-Banner, und zeigt Fehler samt Serverpfaden. Die Rewrite-Zeilen entfernen oder die Datei löschen.',
    ];

    // Auf Apache ohne einstellbaren Webroot: eigene Rewrite-Anweisungen (auch RewriteEngine Off) in der .htaccess neben
    // setup.php und private/ heben die Weiterleitung an webroot/index.php auf, Apache liefert die Dateien dann selbst.
    $checks[] = [
        'key' => 'instance_rewrite',
        'label' => 'Keine Rewrite-Regeln in der .htaccess im Ordner der Website',
        'ok' => !system_has_rewrite_rules(LE_INSTANCE_ROOT . '/.htaccess'),
        'purpose' => '.htaccess im Ordner der Website (neben setup.php) – eigene Rewrite-Anweisungen können auf Apache private Daten und das PHP der Website offenlegen. Die Datei löschen.',
    ];

    // Die Sperr-.htaccess in private/ (le_private_prepare) gilt unabhängig von mod_rewrite; fehlt sie oder sagt sie etwas
    // anderes als LE_PRIVATE_HTACCESS_RULES, liegen private Daten offen, sobald die Weiterleitung ausfällt.
    $privateHtaccess = le_instance_relative(LE_PRIVATE_HTACCESS_FILE);
    $checks[] = [
        'key' => 'private_htaccess',
        'label' => sprintf(SYSTEM_PRIVATE_HTACCESS_TEXT['label'], $privateHtaccess),
        'ok' => system_private_htaccess_ok(),
        'purpose' => sprintf(SYSTEM_PRIVATE_HTACCESS_TEXT['purpose'], $privateHtaccess),
    ];

    $checks[] = [
        'key' => 'setup_password',
        'label' => 'Kein Passwort in setup.php',
        'ok' => !le_setup_password_left(),
        'purpose' => 'setup.php – dort steht noch das Passwort des ersten Admins im Klartext. Den Admin gibt es schon: das Passwort in setup.php per FTP leeren oder die Datei löschen.',
    ];

    return $checks;
}

/** Ob die .htaccess $file eine Rewrite-Anweisung enthält (auch RewriteEngine Off ersetzt die geerbten Regeln). */
function system_has_rewrite_rules(string $file): bool
{
    $content = is_file($file) ? (string) @file_get_contents($file) : '';

    return preg_match('/^[ \t]*Rewrite[A-Za-z]+\b/mi', $content) === 1;
}

/** Ob LE_PRIVATE_HTACCESS_FILE genau die Anweisungen aus LE_PRIVATE_HTACCESS_RULES enthält (le_private_htaccess_rules). */
function system_private_htaccess_ok(): bool
{
    $content = is_file(LE_PRIVATE_HTACCESS_FILE) ? @file_get_contents(LE_PRIVATE_HTACCESS_FILE) : false;

    return $content !== false && le_private_htaccess_rules($content) === LE_PRIVATE_HTACCESS_RULES;
}

/** Ein fehlender Ordner zählt als beschreibbar, wenn ensure_dir() ihn anlegen kann. */
function system_path_writable(string $path): bool
{
    return is_dir($path) ? is_writable($path) : !file_exists($path) && is_writable(dirname($path));
}

/** Nur die Einträge, die fehlen. */
function system_problems(array $checks): array
{
    return array_values(array_filter($checks, static fn (array $check): bool => !$check['ok']));
}

/** Mängel für den Dashboard-Hinweis: nur Admins bekommen sie, sonst leer. */
function system_problems_for_current_user(): array
{
    return is_admin() ? system_problems(system_checks()) : [];
}
