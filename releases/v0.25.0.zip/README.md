# LeBuild

Kleines PHP/Vanilla-JS-Tool, um statische HTML-Seiten nach einem Import ohne Datenbank über JSON zu bearbeiten.

## Start

Mit einem lokalen PHP-Server (`index.php` ist der universelle Front-Controller — gleicher Code für Dev und Produktion):

```bash
php -S 127.0.0.1:8000 index.php
```

Dann im Browser öffnen:

- Login: `http://127.0.0.1:8000/login`
- Website (angemeldet mit Editor-Leiste): `http://127.0.0.1:8000/`
- Verwaltung (nur Admins): `http://127.0.0.1:8000/admin`

## Login & Benutzer

Angemeldet wird unter `/login`. Danach zeigt jede Seite der Website unten die Editor-Leiste (Name, Verwaltung für Admins, Abmelden); Texte, Bilder und Links werden direkt auf der Seite angeklickt und bearbeitet. Besucher sehen nichts davon und bekommen kein Cookie. Der Editor nutzt das Session-Cookie `le_session` und lässt eine PHP-Session der Website (Formulare, Mitgliederbereich) unberührt. Die Anmeldung hält 8 Stunden ohne Anfrage an den Server; ihre Dateien liegen in `content/cache/sessions/`, damit kein Aufräumen des Servers sie früher löscht.

### Erstinstallation

Einen Standardzugang gibt es nicht. Vor dem Hochladen `config.sample.php` im Hauptordner nach `config.php` kopieren und Benutzername und Passwort (mindestens 8 Zeichen) des ersten Admins eintragen.

- Der erste Login mit diesem Zugang legt den Admin in `content/users.json` an (nur als bcrypt-Hash) und leert das Passwort in `config.php`.
- Lässt sich `config.php` nicht umschreiben, steht das im PHP-Fehlerprotokoll, und Einstellungen → System sowie das Dashboard erinnern daran, das Passwort per FTP zu leeren.
- Ohne Benutzer und ohne gültige `config.php` kommt niemand hinein; `/login` zeigt dann statt des Formulars einen Hinweis.
- `config.php` ist gitignored, nie im Release und per HTTP gesperrt; Updates fassen sie nicht an.

Nach 10 Fehlversuchen sperrt der Login eine IP (bei IPv6 das /64-Netz) für 15 Minuten. Nach 10 Fehlversuchen für denselben Benutzer, egal von wo, geht für ihn nur noch ein Versuch alle 10 Sekunden; das gilt nicht in Browsern, in denen er sich schon angemeldet hat (Cookie `le_device_…`, 180 Tage), damit ein Angriff ihn nicht aussperrt.

Sobald `content/users.json` existiert, wird `config.php` ignoriert — alle weiteren Benutzer werden über das Admin-UI verwaltet (**Benutzer**-Eintrag in der Sidebar). Ist die Datei beschädigt (unlesbar, kein gültiges JSON), meldet sich niemand an, der Fehler steht im PHP-Fehlerprotokoll und die Datei wird nie überschrieben: aus einer Sicherung zurückspielen oder reparieren. Einträge mit unbekannter Rolle können sich nicht anmelden, bleiben aber erhalten.

### Rollen

- **admin** — kann alles: Inhalte bearbeiten, Einstellungen, SMTP, Updates, Plugins, Benutzer anlegen / Rollen ändern / löschen, Aktivitäts-Log (wer hat wann was getan, ohne IP, 90 Tage), Verwaltung unter `/admin`.
- **editor** — sieht nur die Website mit Leiste (`/admin` führt zurück auf die Website): bearbeitet Seiten und Plugin-Listen, nutzt Upload, sieht den Verlauf einer Seite und stellt frühere Stände wieder her. Settings, Plugin-Verwaltung, „Markierungen aktualisieren“, Benutzer und Update-Install sind über die API nicht erreichbar (403). Wurde eine Seitendatei direkt geändert (FTP, Deploy), aktualisiert das Öffnen oder Speichern der Seite ihre Markierungen trotzdem von selbst, auch für Editoren (im Verlauf als „Direkte Änderung“).

Passwörter werden als bcrypt-Hashes in `content/users.json` gespeichert. Diese Datei ist `.gitignore`d und durch `content/.htaccess` (Apache) sowie den Dev-Router gegen direkten HTTP-Zugriff geschützt.

## Voraussetzungen

PHP 8.0 oder neuer mit `pdo_sqlite`, `openssl`, `zip`, `curl`, `mbstring`, `dom` und `tokenizer` (fast immer eingebaut), empfohlen `gd` mit WebP (hochgeladene JPG und PNG werden auf 1920 px Breite verkleinert und als WebP gespeichert; ohne werden Fotos (JPG) abgelehnt, weil das Original GPS-Position und Gerät verriete, PNG bleiben unverändert) und `exif` (dreht Handyfotos richtig); Schreibrechte auf `content/` und `public/site/` (darin `uploads/` für hochgeladene Bilder). Einstellungen → System und das Dashboard zeigen, was fehlt, und melden auch eine PHP-Version ohne Sicherheitsupdates (8.0, 8.1).

**Nginx:** neben `try_files $uri /index.php?$query_string;` zwingend, und zwar vor dem PHP-Block (der erste passende Regex-Block gewinnt); `/+` hält auch mit `merge_slashes off`, die `.php/`-Zeilen auch mit einem PHP-Block für PATH_INFO (`\.php(/|$)`):

```
location ~ ^/+(content|core|tests|tools)(/|$) { deny all; }
location ~* ^/+public/+site/+includes(/|$) { deny all; }
location ~ /\.(?!well-known/) { deny all; }
location ~* ^/+([^/]+\.md|composer\.(json|lock)|package(-lock)?\.json)$ { deny all; }
location ~* ^/+config(\.sample)?\.php(/|$) { deny all; }
location ~* ^/+public/+(site/+)?uploads/.*\.(php[0-9]?|phtml|phar)(/|$) { deny all; }
location ~* ^/+plugins/.*\.(php[0-9]?|phtml|phar)/ { deny all; }
location ~* ^/+plugins/+(?!/*[^/]+/+api/+[^/]+\.php$)(?!.*\.(css|js|mjs|svg|png|jpe?g|gif|webp|avif|ico|woff2?|ttf|otf)$) { deny all; }
location ~* ^/+public/+(site/+(.+\.(html?|php)(/.*)?)?|admin/*(index\.html)?)$ { rewrite ^ /index.php last; }
location ~* ^/+public/+(site/+)?uploads/.+\.svg$ {
    add_header Content-Security-Policy "default-src 'none'; img-src data:; style-src 'unsafe-inline'; sandbox";
    add_header X-Content-Type-Options nosniff;
}
```

sonst liefert Nginx vorhandene Dateien (z. B. `content/users.json`, `.git/`, `plugins/*/plugin.json`) direkt aus oder führt `config.php` aus, `public/site/includes/*.php` (auch die Vorlagen der Content-Typen) und Site-Dokumente laufen ohne den Editor, und die Verwaltungs-Shell kommt ohne Rollenprüfung (die APIs bleiben geschützt). Unter `/plugins/` bleiben nur Assets und `<name>/api/*.php` erreichbar. Hochgeladene SVGs kämen ohne den Block oben ohne Sandbox.

**Caddy** (mehrere Websites auf einem Server): `deploy/Caddyfile` gibt nur frei, was direkt ausgeliefert werden darf, siehe [unten](#mehrere-websites-auf-einem-server).

## Env-Variablen

Alle optional, gelesen per `getenv()`:

| Variable | Wirkung |
|---|---|
| `LEBUILD_UPDATES` | `off` (oder `0`, `false`, `no`) schaltet das Auto-Update ab; mit eigenem Kundenordner (`LEBUILD_SITE(S)`) ist es immer aus |
| `LEBUILD_UPDATE_FEED` | andere URL zu `latest.json` (zum Testen), die Signaturprüfung bleibt |
| `LEBUILD_IMAGES_FROM` | nur für eine lokale Kopie: Adresse der echten Website (z. B. `https://kunde.at`); fehlende Bilder der Website (Fotos und Uploads sind nie im Git) leitet LeBuild dorthin um, so sind sie lokal zu sehen |
| `LEBUILD_HEALTH_TOKEN` | Token für die Einzelprüfungen des [Health-Checks](#health-check) |
| `LEBUILD_SITES` | mehrere Websites auf einem Server: Ordner mit je einem Kundenordner (`config.php`, `content/`, `public/site/`) und `domains.json` (`{"kunde.at": "kunde"}`); der Host der Anfrage wählt den Ordner, Unbekanntes bekommt 404 |
| `LEBUILD_PREVIEW_DOMAIN` | dazu die Domain der Vorschau-Adressen `<kurzname>.<domain>` (Antworten mit `X-Robots-Tag: noindex, nofollow`) |
| `LEBUILD_SITE` | genau ein Kundenordner, ohne Blick auf den Host (Kommandozeile, Tests, Dev-Server); hat Vorrang vor `LEBUILD_SITES`, das auf der Kommandozeile ohne `LEBUILD_SITE` abbricht |
| `LEBUILD_REPOS` | Ordner, in dem `tools/sites.php` die Git-Verzeichnisse der Kunden anlegt (`<kurzname>.git`, Arbeitsordner per `core.worktree`); gehört nur dem Benutzer von `sites.php`, nie unter `LEBUILD_SITES` ([Mehrere Websites](#mehrere-websites-auf-einem-server)) |
| `LEBUILD_PHP_USER` | Benutzer, als der `tools/sites.php` die PHP-Prozesse je Kunde startet (`sudo -u`); leer: derselbe Benutzer ([Mehrere Websites](#mehrere-websites-auf-einem-server)) |

Apache (mod_env) in der vHost-Konfiguration oder dort, wo der Hoster Env-Variablen anbietet; nicht in der `.htaccess` des Projekts, die jedes Update ersetzt:

```
SetEnv LEBUILD_UPDATES off
```

Nginx mit PHP-FPM: `fastcgi_param LEBUILD_UPDATES off;` im PHP-`location`.

## Health-Check

`GET /api/health.php` für Uptime-Monitore, ohne Anmeldung. Er prüft, ob `content/` lesbar und beschreibbar ist (samt `content/users.json`), rendert die Startseite wie für Besucher und fragt die Plugin-Datenbank ab (nur, wenn ein aktives Plugin Tabellen hat). Das Ergebnis gilt 10 Sekunden.

- Alles in Ordnung: `200 {"status":"ok","checkedAt":"…"}`; ein Fehler: `503` mit `"status":"error"`, für jeden Aufrufer gleich.
- Die Einzelprüfungen (`checks` mit `name`, `ok`, `error`, `durationMs`, dazu `ageMs`) gibt es nur mit `Authorization: Bearer <Token>`. Ein falsches Token bekommt die öffentliche Antwort.
- Token (z. B. `openssl rand -hex 32`) per `LEBUILD_HEALTH_TOKEN` oder, wo sich keine Env-Variable setzen lässt, in `content/config/health.config.php`: `<?php return ['token' => '…'];`
- Monitor: auf `"status":"ok"` prüfen und erst nach zwei, drei Fehlschlägen in Folge alarmieren.

## Ablauf

1. Die Testseite in `public/site/` ganz löschen und die statischen HTML-Dateien des Kunden dorthin legen
2. Unter `/login` anmelden, im Admin (`/admin`) den Import starten
3. Inhalte direkt auf der Website ändern, „Speichern“ übernimmt alle Änderungen auf einmal
4. Änderungen landen in der Seitendatei und in `content/cache/pages/*.json`; „Verlauf“ in der Leiste zeigt frühere Stände und stellt sie wieder her

## Speicherorte

- Seiteninhalt (JSON-Spiegel): `content/cache/pages/`
- Backups samt Kurzinfo für den Verlauf: `content/cache/backups/`
- Originale: `content/cache/originals/`
- Benutzer (bcrypt-Hashes, nicht im Git): `content/users.json`
- Zugang des ersten Admins (nicht im Git, Vorlage `config.sample.php`): `config.php`
- Uploads: `public/site/uploads/`, bei den übrigen Bildern der Website, aber nie im Git (sie stecken in der Sicherung); die frühere Ablage `public/uploads/` zieht LeBuild von selbst um, alte Adressen gelten weiter
- Aktivitäts-Log (nicht in der Sicherung): `content/activity.jsonl`
- Zugangsdaten (0600): `content/config/db.config.php`, `content/config/mail.config.php`
- Plugin-Daten (SQLite): `content/data/site.sqlite`

## Datenbank

Plugin-Daten liegen standardmäßig in SQLite. Admin → Einstellungen → Datenbank richtet MySQL/MariaDB ein und zieht die Daten in beide Richtungen um; Altdaten bleiben im Archiv, nach 30 Tagen erinnert das Dashboard ans Löschen.

## Hinweise

- Keine Datenbank für den Editor selbst; Plugins mit Daten nutzen SQLite (`content/data/site.sqlite`), MySQL nur auf Wunsch
- Kein Node.js
- Der Import schreibt `data-edit-id`-Marker byte-genau in die Seitendateien; Speichern ersetzt nur das bearbeitete Feld
- Bestehende Seiten stellt der Admin-Button „Markierungen aktualisieren“ auf neue Markierungen um (IDs und Inhalte bleiben); dabei werden auch Seitentitel und Meta-Beschreibung bearbeitbar
- Speichert jemand anderes dasselbe Feld, bleibt dessen Stand erhalten: Der Editor meldet das Feld, speichert den Rest und behält die eigene Änderung in der Liste
- Eine schreibgeschützte Seitendatei wird nicht ersetzt; Speichern meldet das, statt etwas halb zu schreiben
- Aufbau des Seiten-Editors, Design System und Bausteine: [knowledgebase/seiten-editor.md](knowledgebase/seiten-editor.md)

## Tests

```bash
php tests/run.php            # alle Dateien tests/*.test.php, parallel
php tests/run.php save sites # nur Dateien, deren Name das enthält
php tests/save.test.php      # eine Datei allein
```

Braucht PHP mit `curl`, `openssl`, `pdo_sqlite`, `zip` und `gd`. Die Tests arbeiten in einer Wegwerf-Kopie unter dem Temp-Verzeichnis. MySQL-Tests laufen nur mit `TEST_MYSQL_DSN` (DSN einer leeren Wegwerf-Datenbank), `TEST_MYSQL_USER`, `TEST_MYSQL_PASS`, sonst werden sie übersprungen; mit Test-Datenbank laufen die Dateien nacheinander.

## Suchmaschinen

LeBuild erzeugt `/robots.txt`, `/sitemap.xml` (braucht die Website-URL unter Einstellungen), eine 404-Seite im Design der Startseite, ein Vorschaubild für Google und Social Media (Einstellung „Vorschaubild“) und strukturierte Daten der Startseite. CSS und JS gehen verkleinert und mit Browser-Cache raus, ohne Build-Step. Eigene Dateien und Tags der Website gehen vor; Details in `knowledgebase/architecture.md`, „Suchmaschinen“.

## Mail / SMTP

Der Core kann E-Mails zentral versenden:

- SMTP-Konfiguration: Admin → Einstellungen → E-Mail / SMTP
- Geschützte Runtime-Datei: `content/config/mail.config.php`
- Fallback ohne SMTP: PHP `mail()`, sofern auf dem Hosting verfügbar
- Mails gehen als reiner Text (UTF-8, quoted-printable)

Mail-Plugins wie `contact-form` rufen nur den Core-Mailer auf und kennen keine SMTP-Zugangsdaten.

## Auto-Update

Kunden-Installationen aktualisieren sich automatisch über signierte Releases im öffentlichen Repo `lwb-leweb/lebuild-releases`. Release-Workflow für Maintainer und Update-Verhalten beim Kunden: siehe [knowledgebase/release.md](knowledgebase/release.md).

## Mehrere Websites auf einem Server

Ein Checkout bedient beliebig viele Websites, je Kunde ein Kundenordner (`config.php`, `content/`, `public/site/`) unter `sites/`. Der Webserver ist Caddy mit `deploy/Caddyfile`; Zertifikate holt er beim ersten Aufruf einer Domain, die `tools/tls-ask.php` kennt. Unterschiede zur Einzelinstallation: kein Auto-Update (die Verwaltung zeigt nur die Version), `plugins/` gehört zum Code und ist nicht in der Sicherung, ein schreibgeschützter Code-Ordner ist kein Mangel.

```
/srv/lebuild/app/      # Git-Checkout dieses Repos (ein Tag), für PHP nur lesbar
/srv/lebuild/sites/    # domains.json und je Kunde ein Ordner <kurzname>/
/srv/lebuild/repos/    # Git-Verzeichnis je Kunde (<kurzname>.git), nur für lebuild
```

### Server einrichten

Ubuntu 24.04 LTS; die Beispiele nutzen `/srv/lebuild`, `vorschau.example.com` und PHP 8.3. Alle Befehle als root.

1. Pakete: Caddy aus seinem offiziellen Repo, PHP-FPM mit den Erweiterungen aus „Voraussetzungen“, Git ≥ 2.38 (`deploy` nutzt `git merge-tree --write-tree`; Ubuntu 24.04 hat 2.43). OPcache ist an, `opcache.validate_timestamps` nicht abschalten.
   ```bash
   apt install -y debian-keyring debian-archive-keyring apt-transport-https curl
   curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
   curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' > /etc/apt/sources.list.d/caddy-stable.list
   apt update && apt install -y caddy php8.3-fpm php8.3-sqlite3 php8.3-zip php8.3-curl php8.3-gd php8.3-mbstring php8.3-xml php8.3-mysql git unattended-upgrades
   ```
2. DNS einmalig: `*.vorschau.example.com` als A- und AAAA-Eintrag auf den Server. Jede Vorschau-Adresse bekommt ein eigenes Zertifikat. Let's Encrypt stellt je registrierter Domain höchstens 50 neue pro Woche aus. Wer viele Kunden in einer Woche anlegt, nimmt eine eigene Domain nur für die Vorschau oder ein Wildcard-Zertifikat (DNS-Challenge, Caddy mit DNS-Plugin).
3. Benutzer: `lebuild` (Git, `tools/sites.php`, Deploy-Keys unter `~/.ssh/`: `lebuild-<kurzname>` je Kunde, `lebuild_app` mit Unterstrich für den Code, damit kein Kurzname ihn trifft), `lebuild-php` für PHP-FPM, Mitglied der Gruppe `lebuild`. Git-Identität für die Commits des Servers. Als `lebuild` arbeiten: `sudo -iu lebuild`.
   ```bash
   adduser --disabled-password --gecos '' lebuild
   adduser --system --group --no-create-home lebuild-php
   usermod -aG lebuild lebuild-php
   sudo -u lebuild git config --global user.name 'LeBuild-Server'
   sudo -u lebuild git config --global user.email '<adresse>'
   ```
4. Code: `app/` gehört `lebuild` und ist für die Gruppe nicht beschreibbar (umask 022 beim Klonen und bei Updates), PHP darf ihn nur lesen. Immer ein Tag, nie `main`. Das Repo ist privat: Den öffentlichen Schlüssel als Deploy-Key (nur Lesen) im Repo eintragen, dann klonen.
   ```bash
   mkdir -p /srv/lebuild/sites && chown lebuild:lebuild /srv/lebuild
   sudo -u lebuild ssh-keygen -t ed25519 -N '' -f /home/lebuild/.ssh/lebuild_app && cat /home/lebuild/.ssh/lebuild_app.pub
   sudo -u lebuild sh -c 'umask 022 && GIT_SSH_COMMAND="ssh -i ~/.ssh/lebuild_app" git clone <git@github.com:org/repo.git> /srv/lebuild/app && cd /srv/lebuild/app && git config core.sshCommand "ssh -i ~/.ssh/lebuild_app" && git checkout vX.Y.Z'
   ```
5. Kundenordner: `sites/` gehört `lebuild-php`, Gruppe `lebuild`, beschreibbar für beide. setgid vererbt die Gruppe an neue Dateien und Ordner.
   ```bash
   chown lebuild-php:lebuild /srv/lebuild/sites && chmod 2770 /srv/lebuild/sites
   ```
   Die Git-Verzeichnisse der Kunden liegen nicht im Kundenordner (dort darf PHP schreiben und könnte Hooks oder Git-Konfiguration unterschieben), sondern unter `repos/`, das nur `lebuild` gehört (`LEBUILD_REPOS`). sites.php ruft Git immer mit `--git-dir` auf, Arbeitsordner per `core.worktree`; `safe.directory` braucht es nicht.
   ```bash
   install -d -o lebuild -g lebuild -m 700 /srv/lebuild/repos
   ```
6. PHP-FPM: eigener Pool statt `www.conf`, umask 002, damit `lebuild` alles lesen und schreiben kann, was die Websites anlegen. Das Health-Token gilt für alle Websites. Upload- und Speichergrenzen wie in `deploy/docker/php.ini`, sonst gelten Ubuntus 2 MB je Upload und Handyfotos werden abgewiesen; `memory_limit` als `php_value`, damit sich der Upload für große Fotos mehr holen kann. Die umask greift erst nach einem Neustart, ein `reload` reicht nicht.
   ```bash
   rm /etc/php/8.3/fpm/pool.d/www.conf
   cat > /etc/php/8.3/fpm/pool.d/lebuild.conf <<'EOF'
   [lebuild]
   user = lebuild-php
   group = lebuild
   listen = /run/php/lebuild.sock
   listen.owner = caddy
   listen.group = caddy
   pm = ondemand
   pm.max_children = 20
   php_admin_value[upload_max_filesize] = 16M
   php_admin_value[post_max_size] = 20M
   php_value[memory_limit] = 256M
   env[LEBUILD_HEALTH_TOKEN] = <openssl rand -hex 32>
   EOF
   mkdir -p /etc/systemd/system/php8.3-fpm.service.d
   printf '[Service]\nUMask=0002\n' > /etc/systemd/system/php8.3-fpm.service.d/umask.conf
   systemctl daemon-reload && systemctl restart php8.3-fpm
   ```
7. `tools/sites.php` immer über das Skript `lebuild-sites` aufrufen, als `lebuild`, aus der Shell, per ssh und aus cron gleich. Es setzt die Umgebung, die sonst nur eine Login-Shell hätte. Den PHP-Pfad prüfen (`php -r 'echo PHP_BINARY;'`): sites.php startet seine Kindprozesse mit genau diesem Pfad, die sudoers-Regel muss ihn wörtlich nennen.
   ```bash
   cat > /usr/local/bin/lebuild-sites <<'EOF'
   #!/bin/sh
   export LEBUILD_SITES=/srv/lebuild/sites LEBUILD_REPOS=/srv/lebuild/repos LEBUILD_PREVIEW_DOMAIN=vorschau.example.com LEBUILD_PHP_USER=lebuild-php
   exec /usr/bin/php8.3 /srv/lebuild/app/tools/sites.php "$@"
   EOF
   chmod 755 /usr/local/bin/lebuild-sites
   sudo -u lebuild lebuild-sites list
   ```
   Nächtliches `commit` in der crontab von `lebuild` (`crontab -u lebuild -e`): `30 2 * * * /usr/local/bin/lebuild-sites commit`.
8. sudoers-Regel nur für die PHP-Prozesse je Kunde (`visudo -f /etc/sudoers.d/lebuild`). sites.php startet sie mit `sudo -n -u lebuild-php`, dabei kommt nur `LEBUILD_SITE` mit. sudo setzt die umask dabei auf 022, deshalb setzt sites.php in jedem Prozess selbst umask 002, auch im Kindprozess.
   ```
   Defaults:lebuild env_keep += "LEBUILD_SITE"
   lebuild ALL=(lebuild-php) NOPASSWD: /usr/bin/php8.3 /srv/lebuild/app/tools/sites.php *
   ```
9. Caddy: `deploy/Caddyfile` übernehmen, Pfade und Vorschau-Domain anpassen, prüfen, laden.
    ```bash
    sed 's/vorschau\.example\.com/vorschau.meine-firma.at/' /srv/lebuild/app/deploy/Caddyfile > /etc/caddy/Caddyfile
    caddy validate --config /etc/caddy/Caddyfile && systemctl reload caddy
    ```
10. Absichern: SSH nur mit Schlüssel (`PasswordAuthentication no`), Firewall 22/80/443 (`ufw allow OpenSSH && ufw allow 80,443/tcp && ufw enable`), `unattended-upgrades` an, Hetzner-Backups an. Mails gehen wie bisher über das SMTP des Kunden bzw. von LEWEB, kein eigener Mailserver.

### Mit Docker hinter einem vorhandenen Caddy

Für einen Server, auf dem schon ein Caddy andere Sites bedient (`deploy/docker/`). Container `php` (PHP-FPM, Pool wie oben, aber höchstens 8 Worker bei 2 GB Speicher), `caddy` (Routen aus `deploy/routes.caddy`, ohne TLS, mit Docker-Healthcheck über PHP: „unhealthy“ in `docker ps`, wenn PHP hängt) und `tools` (`sites.php`, nur per `run`); alle ohne root, mit Speichergrenze, Ports nur auf `127.0.0.1`. Der Caddy am Host macht TLS samt On-Demand-Zertifikaten und reicht alles weiter. Die Ordner liegen am Host und haben im Container denselben Pfad; die Benutzer sind feste IDs (`lebuild` 10000, `lebuild-php` 10001, Gruppe `lebuild` 10000).

```
/srv/lebuild/app/          # Git-Checkout (ein Tag), gehört root
/srv/lebuild/sites/        # Kundenordner, 10001:10000, 2770
/srv/lebuild/repos/        # Git-Verzeichnisse, 10000, 700
/srv/lebuild/home/         # Home von lebuild: Deploy-Keys, known_hosts, .gitconfig; 10000, 700
/srv/lebuild/lebuild.env   # LEBUILD_PREVIEW_DOMAIN, LEBUILD_HEALTH_TOKEN, optional LEBUILD_PORT (8100), LEBUILD_ASK_PORT (8101)
```

Alle Befehle als root.

1. Docker aus Ubuntu (Sicherheitsupdates per `unattended-upgrades`), Logs mit Rotation:
   ```bash
   apt install -y docker.io docker-compose-v2 docker-buildx
   printf '{"log-driver": "local"}\n' > /etc/docker/daemon.json && systemctl restart docker
   ```
2. Code mit einem Deploy-Key (nur Lesen) von root, wie Schritt 4 oben:
   ```bash
   ssh-keygen -t ed25519 -N '' -f /root/.ssh/lebuild_app && cat /root/.ssh/lebuild_app.pub
   GIT_SSH_COMMAND="ssh -i /root/.ssh/lebuild_app" git clone <git@github.com:org/repo.git> /srv/lebuild/app
   git -C /srv/lebuild/app config core.sshCommand "ssh -i /root/.ssh/lebuild_app" && git -C /srv/lebuild/app checkout vX.Y.Z
   ```
3. Ordner, Git-Identität und GitHub-Hostschlüssel für `lebuild` (Fingerabdruck mit den von GitHub veröffentlichten vergleichen):
   ```bash
   install -d -o 10001 -g 10000 -m 2770 /srv/lebuild/sites
   install -d -o 10000 -g 10000 -m 700 /srv/lebuild/repos /srv/lebuild/home /srv/lebuild/home/.ssh
   printf '[user]\n\tname = LeBuild-Server\n\temail = <adresse>\n' > /srv/lebuild/home/.gitconfig
   ssh-keyscan -t ed25519 github.com > /srv/lebuild/home/.ssh/known_hosts && ssh-keygen -lf /srv/lebuild/home/.ssh/known_hosts
   chown 10000:10000 /srv/lebuild/home/.gitconfig /srv/lebuild/home/.ssh/known_hosts
   ```
4. Einstellungen und Start:
   ```bash
   printf 'LEBUILD_PREVIEW_DOMAIN=vorschau.example.com\nLEBUILD_HEALTH_TOKEN=%s\n' "$(openssl rand -hex 32)" > /srv/lebuild/lebuild.env && chmod 600 /srv/lebuild/lebuild.env
   docker compose -f /srv/lebuild/app/deploy/docker/compose.yaml --env-file /srv/lebuild/lebuild.env up -d --build
   ```
5. `lebuild-sites` ruft `sites.php` im Container `tools` auf; als root (`sudo lebuild-sites list`, per ssh `ssh <server> sudo lebuild-sites commit <kurzname>`). Nächtliches `commit` in der crontab von root: `30 2 * * * /usr/local/bin/lebuild-sites commit`. Ein TTY bekommt der Container nur, wenn STDIN und STDOUT ein Terminal sind (Passwortabfrage von `new`); sonst `-T`, damit `data-pull > datei` und `data-apply < datei` Daten und Meldungen unverändert und getrennt weitergeben.
   ```bash
   cat > /usr/local/bin/lebuild-sites <<'EOF'
   #!/bin/sh
   t=-T; [ -t 0 ] && [ -t 1 ] && t=
   exec docker compose -f /srv/lebuild/app/deploy/docker/compose.yaml --env-file /srv/lebuild/lebuild.env run --rm $t tools "$@"
   EOF
   chmod 755 /usr/local/bin/lebuild-sites
   ```
6. Caddy am Host: in die globalen Optionen das `ask`, dazu ein Site-Block für alle übrigen Domains, dann `caddy validate --config /etc/caddy/Caddyfile && systemctl reload caddy`.
   ```
   {
   	on_demand_tls {
   		ask http://127.0.0.1:8101/
   	}
   }

   https:// {
   	tls {
   		on_demand
   	}
   	reverse_proxy 127.0.0.1:8100
   	header {
   		-Server
   		-Via
   	}
   }
   ```

Update: `git -C /srv/lebuild/app fetch --tags && git -C /srv/lebuild/app checkout vX.Y.Z`, dann `docker compose … restart php caddy` (leert OPcache, liest das Caddyfile neu); ein neues PHP-Image (Sicherheitsupdates) mit `docker compose … build --pull && docker compose … up -d`. Die übrigen Abschnitte gelten mit `sudo lebuild-sites` statt `sudo -u lebuild lebuild-sites`.

### Updates

Ein Update trifft alle Kunden gleichzeitig. Vorher lokal testen: Dev-Server mit `LEBUILD_SITE` auf eine Kopie eines Kundenordners.

```bash
LEBUILD_SITE=/pfad/zur/kopie php -S 127.0.0.1:8000 index.php
```

- Update: `sudo -u lebuild sh -c 'umask 022 && cd /srv/lebuild/app && git fetch --tags && git checkout vX.Y.Z' && systemctl reload php8.3-fpm` (das Neuladen leert OPcache).
- Hat sich `deploy/Caddyfile` geändert (`git -C /srv/lebuild/app diff v<alt> vX.Y.Z -- deploy/Caddyfile`), Schritt 9 wiederholen; die Routen (`deploy/routes.caddy`) liest Caddy aus dem Checkout, für sie reicht `systemctl reload caddy`.
- Rollback: den vorigen Tag auschecken, dann ebenso neu laden.

### tools/sites.php

Aufruf als `lebuild` über `lebuild-sites` (Server einrichten, Schritt 7), z. B. `sudo -u lebuild lebuild-sites list`. Eine Zeile je Ergebnis, Exit-Code 1 bei einem Fehler (`data-pull`: JSON auf STDOUT, Fehler auf STDERR).

| Befehl | Wirkung |
|---|---|
| `new <kurzname> [--backup <zip>]` | Kundenordner anlegen (Kurzname `a-z`, `0-9`, `-`, `-` nicht am Rand, höchstens 40 Zeichen), erster Admin per Abfrage, `.gitignore`, Git-Verzeichnis `repos/<kurzname>.git` mit Remote `git@github.com:lwb-lebuild/<kurzname>.git`, Deploy-Key `~/.ssh/lebuild-<kurzname>`; gibt Vorschau-Adresse und öffentlichen Schlüssel aus |
| `domain <kurzname> <domain>` | Hauptdomain setzen oder ersetzen (eine je Kunde, ohne oder mit `www.`, je nach Hauptadresse); zeigt, ob der DNS-Eintrag schon hierher zeigt. `--remove` entfernt sie |
| `refresh <kurzname>` | „Markierungen aktualisieren“ für alle Seiten, mit Sperre und Sicherung wie in der Verwaltung |
| `commit [<kurzname>]` | Stand jedes Kunden mit Änderungen committen („Stand <Datum>“) und auf `main` pushen; hat `main` Commits, die am Server fehlen, auf den Zweig `kunde` |
| `deploy <kurzname>` | Stand aus GitHub (`main`) mit dem Stand des Kunden zusammenführen und ausrollen (siehe [Arbeiten an einer Kunden-Website](#arbeiten-an-einer-kunden-website)) |
| `list` | Kurzname, Vorschau-Adresse, Domain, DNS, letzter Commit, letzter Save |
| `data-pull <kurzname>` | Plugin-Daten (Tabellen der aktiven Plugins) und Benutzer als JSON, für `php tools/data.php pull` im Klon |
| `data-apply <kurzname> [--lokal-gewinnt <tabelle:id,…>]` | Änderungsliste aus `php tools/data.php diff` von STDIN einspielen, ganz oder gar nicht (siehe [Arbeiten an einer Kunden-Website](#arbeiten-an-einer-kunden-website)) |

Ins Repo kommen Website, Uploads und Inhalte. Zugangsdaten, Benutzer, `content/cache/`, Plugin-Daten (`content/data/`), das Aktivitäts-Log und Temp-Dateien lässt `commit` weg (dieselbe Liste steht in der `.gitignore` für den Klon); sie sichern die Hetzner-Backups. `.gitignore` und `.gitattributes` im Kundenordner darf PHP ändern, am Server wirken sie deshalb nicht. Das nächtliche `commit` steht in der crontab (Schritt 7). Liegt irgendwo im Kundenordner ein Git-Repo (`.git`, z. B. hochgeladen), brechen `commit` und `deploy` für diesen Kunden ab, bis es entfernt ist. Git läuft dabei ohne Hooks, ohne `GIT_*`-Umgebung und ohne `/etc/gitconfig`. Restrisiko: PHP darf im Kundenordner schreiben, während Git ihn liest; eine übernommene Website kann so per Wettlauf ein Git-Repo unterschieben, bevor die Prüfungen es sehen. Das passt dazu, dass es zwischen den Kunden keine technische Trennung gibt (alle Websites laufen im selben PHP-Pool).

Kunden auf einen anderen Server umziehen: Kundenordner, Git-Verzeichnis `repos/<kurzname>.git` und Deploy-Key `~lebuild/.ssh/lebuild-<kurzname>*` mitkopieren, Eintrag in `domains.json` setzen (`domain`). Hat der Kundenordner dort einen anderen Pfad: `sudo -u lebuild git --git-dir=/srv/lebuild/repos/<kurzname>.git config core.worktree <neuer Pfad>` (sonst bricht `commit` ab). Ohne Git-Verzeichnis neu anlegen, als `lebuild` (`sudo -iu lebuild`; die Dateien im Kundenordner bleiben, `reset` setzt nur den Stand):
```bash
g="git --git-dir=/srv/lebuild/repos/<kurzname>.git"
$g init --shared=0600 -b main && $g config core.bare false && $g config core.worktree /srv/lebuild/sites/<kurzname>
$g config core.sshCommand "ssh -i ~/.ssh/lebuild-<kurzname> -o IdentitiesOnly=yes"
$g remote add origin git@github.com:lwb-lebuild/<kurzname>.git && $g fetch origin && $g reset origin/main
```

### Neuer Kunde

1. Repo `lwb-lebuild/<kurzname>` auf GitHub anlegen (leer).
2. Kundenordner anlegen, dann den ausgegebenen Schlüssel im Repo als Deploy-Key mit Schreibrecht eintragen:
   ```bash
   sudo -u lebuild lebuild-sites new <kurzname>
   ```
3. Website-Dateien nach `sites/<kurzname>/public/site/`, Fotos (jpg, png, webp, gif, avif) und `public/site/uploads/` gehören dazu, kommen aber nie ins Git und mit `deploy` nie mit, dann unter `https://<kurzname>.vorschau.example.com/admin` importieren und bearbeiten. Der Kunde schaut sich die Vorschau an.
4. Wenn alles passt, die Domain setzen; danach setzt der Kunde A- und AAAA-Einträge für `kunde.at` und `www.kunde.at`, das Zertifikat kommt beim ersten Aufruf. Ab dem ersten Aufruf über die Domain leitet die Vorschau-Adresse dorthin weiter:
   ```bash
   sudo -u lebuild lebuild-sites domain <kurzname> kunde.at
   ```

### Arbeiten an einer Kunden-Website

LEWEB ändert nicht am Server, sondern in einem Klon des Kunden-Repos auf dem eigenen Rechner. Der Kunde kann währenddessen weiter bearbeiten.

1. Stand des Kunden ins Repo holen, dann im Klon pullen:
   ```bash
   ssh lebuild@<server> lebuild-sites commit <kurzname>
   git pull
   ```
   Meldet `commit`, dass es auf `kunde` gepusht hat: `git pull origin kunde`.
   Nennt `commit` (oder `deploy`) „Code geändert“, hat PHP im Kundenordner Code geschrieben (`.php`, `.htaccess`, `.js` …). Die genannten Dateien vor `git pull` bzw. vor dem Dev-Server ansehen: `git fetch && git log -p HEAD..origin/main -- <Pfad> …` (nach einem Push auf `kunde`: `origin/kunde`). Eine übernommene Website liefe sonst mit deinen Rechten (ssh zum Server, GitHub) auf deinem Rechner.
2. Lokal ansehen: Plugin-Daten (Einträge, Öffnungszeiten …) und Benutzer des Kunden holen, dann Dev-Server mit `LEBUILD_SITE` auf den Klon; Anmeldung mit den Zugängen des Kunden. Holen ersetzt die Plugin-Daten im Klon, auch nicht eingespielte Änderungen, und legt den Ausgangsstand für Schritt 5 ab (`content/data/`, `content/users.json`, beides gitignored). Die Datei enthält Passwort-Hashes: außerhalb des Klons ablegen und löschen.
   ```bash
   f=$(mktemp) && ssh lebuild@<server> lebuild-sites data-pull <kurzname> > "$f" \
     && LEBUILD_SITE=/pfad/zum/klon php tools/data.php pull "$f"; rm -f "$f"
   LEBUILD_SITE=/pfad/zum/klon LEBUILD_IMAGES_FROM=https://kunde.at php -S 127.0.0.1:8000 index.php
   ```
   Fotos und Uploads sind nicht im Repo; mit `LEBUILD_IMAGES_FROM` kommen sie von der echten Website. Neue Fotos gehen beim Ausrollen nicht mit: am Server von Hand an dieselbe Stelle unter `public/site/` hochladen (SVG kommen über Git).
3. Committen und `git push`. Die `.gitignore` gilt nur im Klon: Am Server committet `commit` alles außer der festen Liste aus `tools/sites.php` (Zugangsdaten, Benutzer, `content/cache/` …). Was dort nicht ins Repo soll (z. B. per FTP hochgeladene `.DS_Store` oder Videos), am Server löschen. Keine Untermodule: `deploy` lehnt einen Stand mit Untermodul ab.
4. Ausrollen, danach im Klon `git pull` (das Ausrollen setzt Markierungen für neue Bereiche und pusht sie):
   ```bash
   ssh lebuild@<server> lebuild-sites deploy <kurzname>
   ```
   Der Kunde kann dabei weiter bearbeiten; ein Speichern wartet die paar Sekunden. Ausgabe: eine Zeile je geänderter Datei, Exit-Code ≠ 0 bei Konflikt oder Fehler. Bei einem Konflikt (beide haben dieselbe Zeile oder dieselbe Binärdatei geändert, oder einer hat gelöscht, was der andere geändert hat; die Ausgabe nennt die Art) wird nichts ausgerollt, der Stand des Kunden landet auf `kunde`: `git pull origin kunde`, Konflikt lösen, pushen, erneut `deploy`. Bringt `main` eine neue Datei, die am Server ausgeschlossen ist (etwa per `git add -f content/users.json`), rollt `deploy` nichts aus und nennt sie, auch wenn es sie am Server noch nicht gibt: im Klon `git rm --cached`, pushen, erneut `deploy`. Vor dem Auschecken legt `deploy` die Markierung `repos/<kurzname>.git/lebuild-deploy-unvollstaendig` an, darin die Befehle zurück auf den alten Stand; nach dem Ausrollen entfernt es sie wieder. Bricht das Ausrollen mittendrin ab (z. B. Platte voll, Abbruch des Prozesses), bleibt sie, und `commit` und `deploy` laufen für diesen Kunden nicht. Lösen als `lebuild`: Ursache beheben, die Befehle aus der Datei ausführen, die Datei löschen, erneut `deploy`.
5. Plugin-Daten einspielen, erst nach `deploy` (neue Content-Typen müssen online sein) und mit allen neuen Bildern am Server. Danach Schritt 2 wiederholen: Aus einem Ausgangsstand spielt `data-apply` nur einmal ein, eine zweite Liste daraus lehnt es ab („erst neu holen“). Holen ersetzt alles, was im Klon seit dem letzten Holen geändert wurde; wer nach dem Einspielen schon weitergearbeitet hat, sichert das vorher bzw. macht es danach neu.
   ```bash
   LEBUILD_SITE=/pfad/zum/klon php tools/data.php diff /tmp/aenderungen.json
   ssh lebuild@<server> lebuild-sites data-apply <kurzname> < /tmp/aenderungen.json
   ```
   Ganz oder gar nicht, Benutzer und Zugangsdaten bleiben unberührt, eine Zeile kommt ins Aktivitäts-Log. Hat der Kunde eine Zeile, die LEWEB geändert oder gelöscht hat, seit dem Holen selbst geändert oder gelöscht, wird nichts eingespielt (Exit-Code 1); die Ausgabe nennt sie als `tabelle:id` mit dem Unterschied. Dann mit `--lokal-gewinnt content_items:12,…` die lokale Fassung durchsetzen, oder die Zeile im Klon unverändert lassen bzw. genau wie online setzen und den Diff neu bilden (nicht neu holen, das verwirft die Arbeit im Klon). Ein fehlendes Bild, eine online schon vergebene Adresse oder ein online unbekannter Typ brechen ebenso ab und lassen sich nur im Klon lösen.

### Umzug einer Einzelinstallation

1. Sicherung herunterladen (`tools/backup-pull.php`, [knowledgebase/backup.md](knowledgebase/backup.md)). Das Abhol-Skript legt sie nur für seinen Benutzer lesbar ab, deshalb eine Kopie für `lebuild`:
   ```bash
   install -o lebuild -m 600 <ablage>/<kunde>/<JJJJ-MM-TT>.zip /home/lebuild/umzug.zip
   ```
2. Kundenordner anlegen und die Sicherung darin auspacken (`plugins/` und `database/` bleiben draußen, Benutzer und Passwörter bleiben erhalten), danach die Kopie löschen: `sudo -u lebuild lebuild-sites new <kurzname> --backup /home/lebuild/umzug.zip && rm /home/lebuild/umzug.zip`.
3. In `public/site/includes/config.php` die Zeile mit `siteRoutes.php` ersetzen:
   ```php
   require_once LE_PROJECT_ROOT . '/core/siteRoutes.php';
   ```
4. Unter `https://<kurzname>.vorschau.example.com/admin` anmelden, „Import starten“ (`content/cache/` ist nicht in der Sicherung) und alles prüfen.
5. `sudo -u lebuild lebuild-sites domain <kurzname> kunde.at`, dann den DNS-Eintrag umstellen; die alte Installation läuft bis dahin weiter.

## Lizenz

Proprietär, nicht Open Source: Nutzung nur für Websites, die LEWEB einrichtet oder betreut. Details in [LICENSE](LICENSE).
