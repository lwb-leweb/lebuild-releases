<?php
declare(strict_types=1);

// Zerlegt HTML- und PHP-Seitendateien byte-genau in einen leichten Baum.
// PHP-Blöcke (von „<?“ bis zum schließenden Fragezeichen-Klammer-Paar)
// bleiben undurchsichtig, auch in Tags und Attributen. Jeder Knoten kennt seine Byte-Spans; Änderungen werden als
// Ersetzungen gesammelt und mit markup_apply() in einem Rutsch angewendet,
// der Rest der Datei bleibt Byte für Byte gleich. Werte sind roh (wie in der
// Datei); Encoding ist Sache des Aufrufers.
// Wo ein PHP-Block endet, sagt der PHP-Tokenizer (le_markup_php_blocks), ein
// schließendes Tag in einem String, Kommentar oder Heredoc beendet ihn nicht.
// Grenze: Was der Tokenizer nicht als PHP liest (`<?xml`, ohne die Erweiterung
// tokenizer), endet beim ersten schließenden Tag. In Rohtext-Elementen (MARKUP_RAW_TEXT_ELEMENTS)
// werden PHP-Blöcke nicht als eigene Knoten erkannt; markup_inner_has_php()
// sucht dort im Text nach „<?“.

// Elemente ohne Innenbereich und ohne End-Tag.
const MARKUP_VOID_ELEMENTS = ['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'];
// Zeichen (außer Leerraum) direkt hinter einem Attribut, vor denen sein Leerraum mit wegfallen darf (markup_remove_attr):
// Tag-Ende und PHP-Block, kein weiteres Attribut.
const LE_MARKUP_ATTR_FOLLOWERS = '>/<';
// Inhalt wird nicht als Markup gelesen, sondern bis zum passenden End-Tag als Text.
const MARKUP_RAW_TEXT_ELEMENTS = ['script', 'style', 'textarea', 'title'];
// Offenes Element → Start-Tags, die es ohne End-Tag schließen (HTML-Spec, Alltagsfälle).
const MARKUP_IMPLICIT_CLOSE = [
    'p' => ['address', 'article', 'aside', 'blockquote', 'details', 'div', 'dl', 'fieldset', 'figcaption', 'figure', 'footer', 'form', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'header', 'hr', 'main', 'nav', 'ol', 'p', 'pre', 'section', 'table', 'ul'],
    'li' => ['li'],
    'dt' => ['dt', 'dd'],
    'dd' => ['dt', 'dd'],
    'tr' => ['tr', 'tbody', 'tfoot'],
    'td' => ['td', 'th', 'tr', 'tbody', 'tfoot'],
    'th' => ['td', 'th', 'tr', 'tbody', 'tfoot'],
    'option' => ['option', 'optgroup'],
];

/**
 * Baum einer Datei: ['source' => string, 'nodes' => Knoten[], 'roots' => int[], 'by_attr' => Index].
 * Knoten: type (element|text|php|comment|declaration), start, end, parent.
 * Elemente zusätzlich: tag (klein), attrs, tag_end (nach dem Start-Tag),
 * inner_start, inner_end, self_closing, has_php (PHP-Block an Attribut-Position
 * im Start-Tag), attrs_end (Einfügestelle für neue Attribute: Ende des letzten
 * Attributs vor dem ersten PHP-Block im Tag, sonst Ende des Tag-Namens – nie in
 * oder hinter einem PHP-Block, z. B. einer Bedingung), children (Indizes).
 * Attribut: name (klein), value (roh, null ohne Wert), quote ('"', "'" oder ''),
 * has_php (Wert enthält einen PHP-Block), start/end (Name bis Wertende),
 * ws_start (Leerraum davor, zum Entfernen), value_start/value_end (nur der Wert, zum Ersetzen).
 * by_attr: Name → roher Wert → Element-Indizes (erstes Vorkommen je Element), für markup_find_by_attr().
 */
function markup_parse(string $source): array
{
    $nodes = [];
    $roots = [];
    $byAttr = [];
    $stack = [];
    $len = strlen($source);
    $pos = 0;
    $textStart = 0;
    $phpBlocks = le_markup_php_blocks($source);
    $phpEnds = $phpBlocks === null ? [] : array_column($phpBlocks, 1, 0);

    $add = static function (array $node) use (&$nodes, &$roots, &$stack): int {
        $index = count($nodes);
        $parent = $stack === [] ? null : $stack[count($stack) - 1];
        $node['parent'] = $parent;
        $nodes[$index] = $node;
        if ($parent === null) {
            $roots[] = $index;
        } else {
            $nodes[$parent]['children'][] = $index;
        }
        return $index;
    };
    $flushText = static function (int $upTo) use (&$textStart, $add): void {
        if ($upTo > $textStart) {
            $add(['type' => 'text', 'start' => $textStart, 'end' => $upTo]);
        }
    };
    // Schließt die obersten Elemente bis einschließlich Stapelposition $down.
    $closeTo = static function (int $down, int $innerEnd, int $end) use (&$nodes, &$stack): void {
        while (count($stack) > $down) {
            $index = array_pop($stack);
            $nodes[$index]['inner_end'] = $innerEnd;
            $nodes[$index]['end'] = $end;
        }
    };

    while ($pos < $len) {
        $lt = strpos($source, '<', $pos);
        if ($lt === false) {
            break;
        }
        $next = $source[$lt + 1] ?? '';

        if ($next === '?') {
            $flushText($lt);
            $end = markup_php_end($source, $lt, $phpEnds);
            $add(['type' => 'php', 'start' => $lt, 'end' => $end]);
            $pos = $textStart = $end;
            continue;
        }
        if ($next === '!') {
            $flushText($lt);
            if (substr($source, $lt, 4) === '<!--') {
                $end = markup_comment_end($source, $lt);
                $add(['type' => 'comment', 'start' => $lt, 'end' => $end]);
            } else {
                $close = strpos($source, '>', $lt);
                $end = $close === false ? $len : $close + 1;
                $add(['type' => 'declaration', 'start' => $lt, 'end' => $end]);
            }
            $pos = $textStart = $end;
            continue;
        }
        if ($next === '/' && ctype_alpha($source[$lt + 2] ?? '')) {
            $flushText($lt);
            $nameEnd = $lt + 2;
            while ($nameEnd < $len && !ctype_space($source[$nameEnd]) && $source[$nameEnd] !== '>') {
                $nameEnd++;
            }
            $tag = strtolower(substr($source, $lt + 2, $nameEnd - $lt - 2));
            $close = strpos($source, '>', $nameEnd);
            $end = $close === false ? $len : $close + 1;
            // Offene Elemente über dem passenden schließen implizit; ein End-Tag
            // ohne offenes Element wird übergangen.
            for ($i = count($stack) - 1; $i >= 0; $i--) {
                if ($nodes[$stack[$i]]['tag'] === $tag) {
                    $closeTo($i + 1, $lt, $lt);
                    $closeTo($i, $lt, $end);
                    break;
                }
            }
            $pos = $textStart = $end;
            continue;
        }
        if (!ctype_alpha($next)) {
            // Einzelnes „<“ im Text.
            $pos = $lt + 1;
            continue;
        }

        $flushText($lt);
        $tagInfo = markup_parse_start_tag($source, $lt, $phpEnds);
        $tag = $tagInfo['tag'];

        // Implizit schließen: nächstes passendes Element von oben, solange nur
        // implizit schließbare Elemente darüber liegen.
        for ($i = count($stack) - 1; $i >= 0; $i--) {
            $openTag = $nodes[$stack[$i]]['tag'];
            if (!isset(MARKUP_IMPLICIT_CLOSE[$openTag])) {
                break;
            }
            if (in_array($tag, MARKUP_IMPLICIT_CLOSE[$openTag], true)) {
                $closeTo($i, $lt, $lt);
                break;
            }
        }

        $isVoid = in_array($tag, MARKUP_VOID_ELEMENTS, true) || $tagInfo['self_closing'];
        $index = $add([
            'type' => 'element',
            'tag' => $tag,
            'start' => $lt,
            'tag_end' => $tagInfo['end'],
            'inner_start' => $tagInfo['end'],
            'inner_end' => $tagInfo['end'],
            'end' => $tagInfo['end'],
            'attrs' => $tagInfo['attrs'],
            'self_closing' => $isVoid,
            'has_php' => $tagInfo['has_php'],
            'attrs_end' => $tagInfo['attrs_end'],
            'children' => [],
        ]);
        $seen = [];
        foreach ($tagInfo['attrs'] as $attr) {
            if (!isset($seen[$attr['name']]) && $attr['value'] !== null) {
                $byAttr[$attr['name']][$attr['value']][] = $index;
            }
            $seen[$attr['name']] = true;
        }
        $pos = $textStart = $tagInfo['end'];
        if ($isVoid) {
            continue;
        }
        $stack[] = $index;

        if (in_array($tag, MARKUP_RAW_TEXT_ELEMENTS, true)) {
            [$innerEnd, $end] = markup_raw_text_end($source, $tag, $pos);
            $flushText($innerEnd);
            $closeTo(count($stack) - 1, $innerEnd, $end);
            $pos = $textStart = $end;
        }
    }

    $flushText($len);
    $closeTo(0, $len, $len);

    return ['source' => $source, 'nodes' => $nodes, 'roots' => $roots, 'by_attr' => $byAttr, 'php_blocks' => $phpBlocks];
}

/** Ende des Kommentars, der bei $lt mit <!-- beginnt: hinter dem nächsten -->, ungeschlossen das Ende der Datei. */
function markup_comment_end(string $source, int $lt): int
{
    $close = strpos($source, '-->', $lt + 4);

    return $close === false ? strlen($source) : $close + 3;
}

/**
 * Ende eines PHP-Blocks ab $start (nach dem schließenden Tag oder Dateiende). $phpEnds (öffnendes Tag => Ende, aus
 * le_markup_php_blocks) kommt vom Tokenizer, damit ein schließendes Tag in einem String, Kommentar oder Heredoc den
 * Block nicht beendet. Kennt der Tokenizer $start nicht (z. B. `<?xml`), endet der Block wie bisher beim ersten „?>“.
 */
function markup_php_end(string $source, int $start, array $phpEnds = []): int
{
    if (isset($phpEnds[$start])) {
        return $phpEnds[$start];
    }
    $close = strpos($source, '?>', $start + 2);
    return $close === false ? strlen($source) : $close + 2;
}

/**
 * PHP-Bereiche der Quelle als [[Start, Ende], …], aufsteigend, laut PHP-Tokenizer. Ein `<?`, das der Tokenizer hier
 * nicht als PHP liest (short_open_tag aus) und das keine XML-Deklaration ist, gilt bis zum Dateiende als PHP: Läuft die
 * Website mit short_open_tag an, ist es dort Code. null: Die Quelle enthält `<?`, aber der Tokenizer fehlt.
 */
function le_markup_php_blocks(string $source): ?array
{
    if (!str_contains($source, '<?')) {
        return [];
    }
    if (!function_exists('token_get_all')) {
        return null;
    }
    $blocks = [];
    $open = null;
    $offset = 0;
    foreach (token_get_all($source) as $token) {
        $text = is_array($token) ? $token[1] : $token;
        $type = is_array($token) ? $token[0] : null;
        if ($type === T_OPEN_TAG || $type === T_OPEN_TAG_WITH_ECHO) {
            $open = $offset;
        } elseif ($type === T_CLOSE_TAG && $open !== null) {
            // Das Token enthält einen folgenden Zeilenumbruch, der Block endet direkt nach dem Tag.
            $blocks[] = [$open, $offset + 2];
            $open = null;
        } elseif ($type === T_INLINE_HTML && preg_match_all('/<\?(?!xml\b)/i', $text, $m, PREG_OFFSET_CAPTURE)) {
            $blocks[] = [$offset + $m[0][0][1], strlen($source)];
            return $blocks;
        }
        $offset += strlen($text);
    }
    if ($open !== null) {
        $blocks[] = [$open, strlen($source)];
    }
    return $blocks;
}

// Ein rohes <img in einer PHP-Quelle (le_markup_img_lines): im HTML, in Strings, nicht in Kommentaren.
const LE_MARKUP_IMG_PATTERN = '/<img\b/i';

/**
 * Zeilen der PHP-Quelle $source mit einem <img (LE_MARKUP_IMG_PATTERN) außerhalb von PHP-Kommentaren, aufsteigend, ohne
 * die Zeilen, in denen ein Kommentar auf $exempt passt (z. B. der Marker „// le-img:“ des Strukturtests). Ohne
 * Tokenizer zählt jede Zeile mit <img. Für den Strukturtest (R11).
 */
function le_markup_img_lines(string $source, ?string $exempt = null): array
{
    // Ohne Tokenizer gibt es auch seine Konstanten nicht: die ganze Quelle als ein Stück Text.
    $tokens = function_exists('token_get_all') ? token_get_all($source) : [[null, $source, 1]];
    $hits = [];
    $exempted = [];
    foreach ($tokens as $token) {
        if (!is_array($token)) {
            continue;
        }
        [$id, $text, $line] = $token;
        if ($id !== null && ($id === T_COMMENT || $id === T_DOC_COMMENT)) {
            if ($exempt !== null && preg_match($exempt, $text) === 1) {
                $exempted[] = $line;
            }
            continue;
        }
        preg_match_all(LE_MARKUP_IMG_PATTERN, $text, $m, PREG_OFFSET_CAPTURE);
        foreach ($m[0] as [, $offset]) {
            $hits[] = $line + substr_count($text, "\n", 0, $offset);
        }
    }
    $lines = array_values(array_unique(array_diff($hits, $exempted)));
    sort($lines);
    return $lines;
}

/** Ist die Seiten- bzw. Komponentendatei PHP (läuft beim Aufruf als Code)? .html-Seiten liefert der Router roh aus. */
function le_source_is_php(string $file): bool
{
    return strtolower(pathinfo($file, PATHINFO_EXTENSION)) === 'php';
}

/** markup_parse für eine Seitenquelle: Nur in PHP-Quellen ($php) gelten PHP-Bereiche für le_markup_edit_in_php. */
function le_markup_parse_source(string $source, bool $php): array
{
    $doc = markup_parse($source);
    if (!$php) {
        $doc['php_blocks'] = [];
    }
    return $doc;
}

/** Liegt die Ersetzung ([start, end, text]) mit einem Ende in einem PHP-Bereich von $doc? Ohne Tokenizer immer, sobald die Quelle PHP enthält. */
function le_markup_edit_in_php(array $doc, array $edit): bool
{
    // null: Quelle mit PHP, aber ohne Tokenizer – dann gilt alles als PHP (nichts bearbeitbar statt unsicher).
    $blocks = array_key_exists('php_blocks', $doc) ? $doc['php_blocks'] : [];
    if ($blocks === null) {
        return true;
    }
    foreach ([$edit['start'], $edit['end']] as $pos) {
        // Binärsuche: letzter Bereich, der vor $pos beginnt.
        [$lo, $hi] = [0, count($blocks) - 1];
        while ($lo <= $hi) {
            $mid = intdiv($lo + $hi, 2);
            if ($blocks[$mid][0] < $pos) {
                $lo = $mid + 1;
            } else {
                $hi = $mid - 1;
            }
        }
        if ($hi >= 0 && $pos < $blocks[$hi][1]) {
            return true;
        }
    }
    return false;
}

/**
 * Berührt die Ersetzung PHP-Code: ein Ende in einem PHP-Bereich (le_markup_edit_in_php) oder ein PHP-Bereich, der in
 * [start, end) beginnt, also ganz im ersetzten Span liegt (etwa ein Attribut samt `<?= $i ?>` im Wert).
 */
function le_markup_edit_touches_php(array $doc, array $edit): bool
{
    if (le_markup_edit_in_php($doc, $edit)) {
        return true;
    }
    $blocks = $doc['php_blocks'] ?? [];
    // Binärsuche: erster Bereich, der bei oder nach start beginnt.
    [$lo, $hi] = [0, count($blocks)];
    while ($lo < $hi) {
        $mid = intdiv($lo + $hi, 2);
        if ($blocks[$mid][0] < $edit['start']) {
            $lo = $mid + 1;
        } else {
            $hi = $mid;
        }
    }
    return $lo < count($blocks) && $blocks[$lo][0] < $edit['end'];
}

/** Ende eines Rohtext-Elements: [Inner-Ende, Ende nach dem End-Tag]. */
function markup_raw_text_end(string $source, string $tag, int $from): array
{
    $len = strlen($source);
    $needle = '</' . $tag;
    $search = $from;
    while (($at = stripos($source, $needle, $search)) !== false) {
        $after = $source[$at + strlen($needle)] ?? '>';
        if ($after === '>' || ctype_space($after)) {
            $close = strpos($source, '>', $at);
            return [$at, $close === false ? $len : $close + 1];
        }
        $search = $at + 1;
    }
    return [$len, $len];
}

/** Start-Tag ab $lt lesen: ['tag', 'attrs', 'end', 'self_closing', 'has_php', 'attrs_end']. */
function markup_parse_start_tag(string $source, int $lt, array $phpEnds = []): array
{
    $len = strlen($source);
    $p = $lt + 1;
    while ($p < $len && !ctype_space($source[$p]) && $source[$p] !== '>' && $source[$p] !== '/'
        && !($source[$p] === '<' && ($source[$p + 1] ?? '') === '?')) {
        $p++;
    }
    $tag = strtolower(substr($source, $lt + 1, $p - $lt - 1));
    $attrs = [];
    $selfClosing = false;
    $hasPhp = false;
    $attrsEnd = $p;

    while (true) {
        $wsStart = $p;
        while ($p < $len && ctype_space($source[$p])) {
            $p++;
        }
        if ($p >= $len) {
            break;
        }
        $c = $source[$p];
        if ($c === '>') {
            $p++;
            break;
        }
        if ($c === '/') {
            if (($source[$p + 1] ?? '') === '>') {
                $selfClosing = true;
                $p += 2;
                break;
            }
            $p++;
            continue;
        }
        if ($c === '<' && ($source[$p + 1] ?? '') === '?') {
            $hasPhp = true;
            $p = markup_php_end($source, $p, $phpEnds);
            continue;
        }

        $nameStart = $p;
        while ($p < $len && !ctype_space($source[$p]) && $source[$p] !== '=' && $source[$p] !== '>' && $source[$p] !== '/'
            && !($source[$p] === '<' && ($source[$p + 1] ?? '') === '?')) {
            $p++;
        }
        if ($p === $nameStart) {
            $p++;
            continue;
        }
        $attr = [
            'name' => strtolower(substr($source, $nameStart, $p - $nameStart)),
            'value' => null,
            'quote' => '',
            'has_php' => false,
            'ws_start' => $wsStart,
            'start' => $nameStart,
            'end' => $p,
            'value_start' => $p,
            'value_end' => $p,
        ];

        $q = $p;
        while ($q < $len && ctype_space($source[$q])) {
            $q++;
        }
        if (($source[$q] ?? '') === '=') {
            $q++;
            while ($q < $len && ctype_space($source[$q])) {
                $q++;
            }
            $quote = $source[$q] ?? '';
            if ($quote === '"' || $quote === "'") {
                $valueStart = $q + 1;
                $v = $valueStart;
                while ($v < $len && $source[$v] !== $quote) {
                    if ($source[$v] === '<' && ($source[$v + 1] ?? '') === '?') {
                        $attr['has_php'] = true;
                        $v = markup_php_end($source, $v, $phpEnds);
                    } else {
                        $v++;
                    }
                }
                $attr['quote'] = $quote;
                $attr['value_start'] = $valueStart;
                $attr['value_end'] = $v;
                $attr['end'] = min($v + 1, $len);
            } else {
                $valueStart = $q;
                $v = $valueStart;
                while ($v < $len && !ctype_space($source[$v]) && $source[$v] !== '>') {
                    if ($source[$v] === '<' && ($source[$v + 1] ?? '') === '?') {
                        $attr['has_php'] = true;
                        $v = markup_php_end($source, $v, $phpEnds);
                    } else {
                        $v++;
                    }
                }
                $attr['value_start'] = $valueStart;
                $attr['value_end'] = $v;
                $attr['end'] = $v;
            }
            $attr['value'] = substr($source, $attr['value_start'], $attr['value_end'] - $attr['value_start']);
            $p = $attr['end'];
        }
        $attrs[] = $attr;
        if (!$hasPhp) {
            $attrsEnd = $attr['end'];
        }
    }

    return ['tag' => $tag, 'attrs' => $attrs, 'end' => $p, 'self_closing' => $selfClosing, 'has_php' => $hasPhp, 'attrs_end' => $attrsEnd];
}

/** Indizes aller Elemente, deren Attribut $name genau $value (roh) enthält; ohne Durchlauf (by_attr). */
function markup_find_by_attr(array $doc, string $name, string $value): array
{
    return $doc['by_attr'][$name][$value] ?? [];
}

/** Index des ersten Elements mit dem Tag $tag (klein), null ohne. */
function markup_find_tag(array $doc, string $tag): ?int
{
    foreach ($doc['nodes'] as $index => $node) {
        if ($node['type'] === 'element' && $node['tag'] === $tag) {
            return $index;
        }
    }
    return null;
}

/** Attribut eines Elements (erstes Vorkommen) oder null. */
function markup_attr(array $node, string $name): ?array
{
    foreach ($node['attrs'] ?? [] as $attr) {
        if ($attr['name'] === $name) {
            return $attr;
        }
    }
    return null;
}

/** Attributwert mit aufgelösten Entities; '' ohne Attribut. */
function markup_attr_text(array $node, string $name): string
{
    return html_entity_decode((string) (markup_attr($node, $name)['value'] ?? ''), ENT_HTML5 | ENT_QUOTES, 'UTF-8');
}

/** Roher Innenbereich eines Elements. */
function markup_inner_html(array $doc, int $index): string
{
    $node = $doc['nodes'][$index];
    return substr($doc['source'], $node['inner_start'], $node['inner_end'] - $node['inner_start']);
}

/** Enthält der Innenbereich (rekursiv) einen PHP-Block – als Knoten, im Start-Tag oder Attribut eines Kindes, im Rohtext oder Kommentar? */
function markup_inner_has_php(array $doc, int $index): bool
{
    foreach ($doc['nodes'][$index]['children'] ?? [] as $child) {
        $node = $doc['nodes'][$child];
        if ($node['type'] === 'php' || ($node['has_php'] ?? false) || markup_inner_has_php($doc, $child)) {
            return true;
        }
        if (in_array($node['type'], ['text', 'comment'], true) && str_contains(substr($doc['source'], $node['start'], $node['end'] - $node['start']), '<?')) {
            return true;
        }
        foreach ($node['attrs'] ?? [] as $attr) {
            if ($attr['has_php']) {
                return true;
            }
        }
    }
    return false;
}

/** Ersetzung „Innenbereich setzen“ ($html fertig encodiert). */
function markup_set_inner(array $doc, int $index, string $html): array
{
    $node = $doc['nodes'][$index];
    if ($node['self_closing']) {
        throw new RuntimeException('Element <' . $node['tag'] . '> hat keinen Innenbereich');
    }
    return ['start' => $node['inner_start'], 'end' => $node['inner_end'], 'text' => $html];
}

/**
 * Ersetzung „Attribut setzen“ ($value roh, fertig encodiert).
 * Fehlt das Attribut, wird es als „ name="…"“ an der Einfügestelle attrs_end eingefügt (hinter
 * dem letzten Attribut vor einem PHP-Block, sonst hinter dem Tag-Namen): Leerraum vor „>“/„/>“
 * bleibt, mehrere Einfügungen an derselben Stelle reihen sich, und markup_remove_attr() stellt
 * das Original byte-genau wieder her.
 */
function markup_set_attr(array $doc, int $index, string $name, string $value): array
{
    $node = $doc['nodes'][$index];
    $attr = markup_attr($node, $name);
    if ($attr === null) {
        return ['start' => $node['attrs_end'], 'end' => $node['attrs_end'], 'text' => ' ' . $name . '="' . $value . '"'];
    }
    if ($attr['quote'] === '') {
        return ['start' => $attr['start'], 'end' => $attr['end'], 'text' => $name . '="' . $value . '"'];
    }
    return ['start' => $attr['value_start'], 'end' => $attr['value_end'], 'text' => $value];
}

/** Wert für ein Attribut kodieren (alle Anführungszeichen, passt zu markup_set_attr). */
function markup_attr_escape(string $value): string
{
    return htmlspecialchars($value, ENT_HTML5 | ENT_QUOTES, 'UTF-8');
}

/**
 * Ersetzung „Attribut entfernen“ samt Leerraum davor; null, wenn es fehlt. Folgt direkt etwas anderes als Leerraum, „>“, „/“
 * oder ein PHP-Block (das nächste Attribut ohne Leerraum), bleibt der Leerraum davor: Nichts wächst zusammen.
 */
function markup_remove_attr(array $doc, int $index, string $name): ?array
{
    $attr = markup_attr($doc['nodes'][$index], $name);
    if ($attr === null) {
        return null;
    }
    $next = $doc['source'][$attr['end']] ?? '>';
    return ['start' => str_contains(LE_HTML_WHITESPACE . LE_MARKUP_ATTR_FOLLOWERS, $next) ? $attr['ws_start'] : $attr['start'], 'end' => $attr['end'], 'text' => ''];
}

/**
 * Ersetzung „Knoten entfernen“ samt Leerraum direkt davor (Zeilenumbruch,
 * Einrückung): endet der vorige Geschwister-Textknoten am Knoten, geht sein
 * abschließender Leerraum mit weg. Gegenstück zu markup_remove_attr().
 */
function markup_remove_node(array $doc, int $index): array
{
    $node = $doc['nodes'][$index];
    $start = $node['start'];
    $siblings = $node['parent'] === null ? $doc['roots'] : $doc['nodes'][$node['parent']]['children'];
    $at = array_search($index, $siblings, true);
    $prev = $at > 0 ? $doc['nodes'][$siblings[$at - 1]] : null;
    if ($prev !== null && $prev['type'] === 'text' && $prev['end'] === $start) {
        $text = substr($doc['source'], $prev['start'], $prev['end'] - $prev['start']);
        $start -= strlen($text) - strlen(rtrim($text));
    }
    return ['start' => $start, 'end' => $node['end'], 'text' => ''];
}

/** Wendet Ersetzungen ([start, end, text]) an; sie dürfen sich nicht überlappen. */
function markup_apply(string $source, array $replacements): string
{
    usort($replacements, static fn (array $a, array $b): int => $a['start'] <=> $b['start'] ?: $a['end'] <=> $b['end']);
    $out = '';
    $pos = 0;
    foreach ($replacements as $r) {
        if ($r['start'] < $pos || $r['end'] < $r['start'] || $r['end'] > strlen($source)) {
            throw new RuntimeException('Überlappende Ersetzungen');
        }
        $out .= substr($source, $pos, $r['start'] - $pos) . $r['text'];
        $pos = $r['end'];
    }
    return $out . substr($source, $pos);
}

// Zeichenreferenzen, die der style-Zerleger auflöst (le_markup_style_decode): was der Kern in eine Hintergrund-Adresse
// schreibt (markup_attr_escape) und die Anführungszeichen, die BACKGROUND_URL_PATTERN um sie kennt. Jedes andere „&“ macht
// den style nicht zerlegbar.
const LE_STYLE_ENTITIES = ['&amp;' => '&', '&lt;' => '<', '&gt;' => '>', '&quot;' => '"', '&apos;' => "'", '&#39;' => "'", '&#039;' => "'"];
// Positivliste des Zerlegers (le_markup_style_segments), auf dem aufgelösten Wert. Erlaubte Zeichen außerhalb von Strings und
// Klammern: ohne „*“ (nie ein Kommentar), Anführungszeichen, „\“, „:“, „;“, Blöcke, „<“/„>“ und Zeilenumbruch.
const LE_STYLE_PLAIN = '[A-Za-z0-9 \t#%,.\/!+_-]';
// String ohne „\“ und Zeilenumbruch: alles darin ist wörtlich, auch „;“, „/*“ und Blöcke.
const LE_STYLE_STRING = '(?:\'[^\'\\\\\n\r\f]*\'|"[^"\\\\\n\r\f]*")';
// url(…) ohne Anführungszeichen, Leerraum nur am Rand, ohne Klammern und „\“ darin (das Gegenstück zu sanitize_css_url): Der
// Browser liest bis zur ersten „)“, alles darin wörtlich. Nur, wo kein Name davor weitergeht (sonst ist es keine url()).
const LE_STYLE_URL = '(?<![A-Za-z0-9#%.!+_-])[uU][rR][lL]\([ \t]*[^ \t\n\r\f()\'"\\\\]*[ \t]*\)';
// Ein Abschnitt bis „;“ bzw. zum Ende: leer oder eine Deklaration, Name aus Buchstaben, Ziffern und „-“, Wert aus den Teilen
// oben und Klammern eine Ebene tief (darin genau ein String, Leerraum am Rand, oder nur Zeichen aus LE_STYLE_PLAIN).
const LE_STYLE_SEGMENT_PATTERN = '/[ \t]*(?:(?<name>[A-Za-z0-9-]+)[ \t]*:[ \t]*(?<value>(?:' . LE_STYLE_URL . '|\((?:[ \t]*' . LE_STYLE_STRING
    . '[ \t]*|' . LE_STYLE_PLAIN . '*)\)|' . LE_STYLE_STRING . '|' . LE_STYLE_PLAIN . ')*?))?[ \t]*(?<sep>;|\z)/A';
// Wert mit !important am Ende: gilt im Browser vor jeder Deklaration derselben Eigenschaft ohne.
const LE_STYLE_IMPORTANT_PATTERN = '/!\s*important\z/i';

/** Eine Deklaration, wie le_markup_set_style_value sie anhängt: „object-position: 30% 70%“ ($value roh). */
function le_markup_style_declaration(string $property, string $value): string
{
    return $property . ': ' . $value;
}

/**
 * Rohen style-Wert für le_markup_style_segments auflösen (LE_STYLE_ENTITIES): [Text, Offset im rohen Wert je Byte des Texts
 * und für sein Ende]; null bei jedem anderen „&“.
 */
function le_markup_style_decode(string $style): ?array
{
    $text = '';
    $offsets = [];
    for ($i = 0, $length = strlen($style); $i < $length; $i += strlen($unit)) {
        $unit = $style[$i];
        if ($unit === '&') {
            $unit = (string) array_key_first(array_filter(LE_STYLE_ENTITIES, static fn (string $entity): bool => substr_compare($style, $entity, $i, strlen($entity)) === 0, ARRAY_FILTER_USE_KEY));
            if ($unit === '') {
                return null;
            }
        }
        $offsets[] = $i;
        $text .= LE_STYLE_ENTITIES[$unit] ?? $unit;
    }
    $offsets[] = strlen($style);
    return [$text, $offsets];
}

/**
 * Zerlegt einen rohen style-Wert, der ganz der Positivliste folgt (LE_STYLE_ENTITIES, LE_STYLE_SEGMENT_PATTERN), in Abschnitte:
 * je „;“ bzw. Ende ['name' (klein, null bei einem leeren Abschnitt), 'value' (aufgelöst, ohne Leerraum am Rand), 'important',
 * Offsets im rohen Wert: 'start' (Name, null ohne), 'value_start', 'value_end', 'end' (Trenner bzw. Ende), 'sep_end' (hinter
 * dem „;“, null ohne)]. null bei allem anderen: Dann darf nichts geändert werden, denn der Browser könnte es anders lesen.
 */
function le_markup_style_segments(string $style): ?array
{
    $decoded = le_markup_style_decode($style);
    if ($decoded === null) {
        return null;
    }
    [$text, $offsets] = $decoded;
    $segments = [];
    for ($at = 0; ; $at = $m['sep'][1] + 1) {
        if (preg_match(LE_STYLE_SEGMENT_PATTERN, $text, $m, PREG_OFFSET_CAPTURE | PREG_UNMATCHED_AS_NULL, $at) !== 1) {
            return null;
        }
        [$name, $start] = $m['name'];
        [$value, $valueStart] = $m['value'];
        $segments[] = [
            'name' => $name === null ? null : strtolower($name),
            'value' => (string) $value,
            'important' => preg_match(LE_STYLE_IMPORTANT_PATTERN, (string) $value) === 1,
            'start' => $name === null ? null : $offsets[$start],
            'value_start' => $value === null ? null : $offsets[$valueStart],
            'value_end' => $value === null ? null : $offsets[$valueStart + strlen($value)],
            'end' => $offsets[$m['sep'][1]],
            'sep_end' => $m['sep'][0] === ';' ? $offsets[$m['sep'][1] + 1] : null,
        ];
        if ($m['sep'][0] === '') {
            return $segments;
        }
    }
}

/** Deklarationen der Eigenschaft $property im rohen style-Wert (le_markup_style_segments); null, wenn er nicht zerlegbar ist. */
function le_markup_style_declarations(string $style, string $property): ?array
{
    $segments = le_markup_style_segments($style);
    return $segments === null ? null : array_values(array_filter($segments, static fn (array $segment): bool => $segment['name'] === strtolower($property)));
}

/** Die Deklaration, die im Browser gilt: die letzte mit !important, sonst die letzte; null ohne. */
function le_markup_style_effective(array $declarations): ?array
{
    $important = array_values(array_filter($declarations, static fn (array $declaration): bool => $declaration['important']));
    $candidates = $important === [] ? $declarations : $important;
    return $candidates === [] ? null : $candidates[count($candidates) - 1];
}

/**
 * Ob sich der style des Elements sicher ändern lässt (le_markup_set_style_value): zerlegbar (le_markup_style_segments)
 * und, ohne Anführungszeichen, ohne „"“ (es beendete den Wert, sobald er Anführungszeichen bekommt). Ohne style ja;
 * PHP darin prüft der Aufrufer (edit_target_problem).
 */
function le_markup_style_writable(array $node): bool
{
    $attr = markup_attr($node, 'style');
    if ($attr === null || $attr['value'] === null) {
        return true;
    }
    return le_markup_style_segments($attr['value']) !== null && ($attr['quote'] !== '' || !str_contains($attr['value'], '"'));
}

/**
 * Wert der Eigenschaft $property im style des Elements mit aufgelösten Entities, aus der Deklaration, die im Browser
 * gilt (le_markup_style_effective, samt !important); '' ohne oder bei nicht zerlegbarem style.
 */
function le_markup_style_value(array $node, string $property): string
{
    $style = (string) (markup_attr($node, 'style')['value'] ?? '');
    return le_markup_style_effective(le_markup_style_declarations($style, $property) ?? [])['value'] ?? '';
}

/**
 * Ersetzungen „Eigenschaft $property im style setzen“; $value roh, der Aufrufer hat ihn geprüft (kodiert wie
 * markup_set_attr) und le_markup_style_writable vorher (sonst RuntimeException). Gibt es die Eigenschaft, bleibt genau
 * eine Deklaration: die geltende bekommt den neuen Wert (auch statt eines Werts in anderem Format oder mit !important),
 * die übrigen fallen weg. Sonst hängt es sie vor dem Leerraum am Ende an (mit „; “, hinter einem „;“ am Ende wieder mit
 * „;“) oder fügt das Attribut ein. Leer entfernt alle Deklarationen samt Trenner; bleibt vom style nur Leerraum, fällt das
 * Attribut weg (markup_remove_attr, also byte-genau wie vor dem Einfügen). Nur die Bytes der Deklaration ändern sich, der
 * Rest des style bleibt byte-gleich, auch eine Kurzform (background:). Die Spans liegen nur im eigenen Teil des Werts und
 * passen so neben markup_set_background_url in einen markup_apply. Ein Wert ohne Anführungszeichen bekommt welche.
 */
function le_markup_set_style_value(array $doc, int $index, string $property, string $value): array
{
    $node = $doc['nodes'][$index];
    if (!le_markup_style_writable($node)) {
        throw new RuntimeException('style von <' . $node['tag'] . '> ist nicht zerlegbar');
    }
    $attr = markup_attr($node, 'style');
    $style = (string) ($attr['value'] ?? '');
    $segments = le_markup_style_segments($style);
    $declarations = le_markup_style_declarations($style, $property);
    $declaration = markup_attr_escape(le_markup_style_declaration($property, $value));
    if ($value === '') {
        $spans = le_markup_style_removals($style, $segments, $declarations);
        if ($spans === []) {
            return [];
        }
        if (trim(markup_apply($style, $spans), LE_HTML_WHITESPACE) === '') {
            return [markup_remove_attr($doc, $index, 'style')];
        }
    } elseif ($attr === null || $attr['value'] === null) {
        return [markup_set_attr($doc, $index, 'style', $declaration)];
    } elseif ($declarations !== []) {
        $effective = le_markup_style_effective($declarations);
        $others = array_values(array_filter($declarations, static fn (array $d): bool => $d['start'] !== $effective['start']));
        $spans = le_markup_style_removals($style, $segments, $others);
        $spans[] = ['start' => $effective['value_start'], 'end' => $effective['value_end'], 'text' => markup_attr_escape($value)];
    } else {
        $end = strlen(rtrim($style, LE_HTML_WHITESPACE));
        $closed = count($segments) > 1 && $segments[count($segments) - 1]['start'] === null;
        $spans = [['start' => $end, 'end' => $end, 'text' => ($end === 0 ? '' : ($closed ? ' ' : '; ')) . $declaration . ($closed ? ';' : '')]];
    }
    usort($spans, static fn (array $a, array $b): int => $a['start'] <=> $b['start']);
    if ($value !== '' && $attr['quote'] === '') {
        // Ohne Anführungszeichen endete der Wert am ersten Leerzeichen: er bekommt welche („"“ enthält er nicht, le_markup_style_writable).
        $spans = [['start' => 0, 'end' => 0, 'text' => '"'], ...$spans, ['start' => strlen($style), 'end' => strlen($style), 'text' => '"']];
    }
    return array_map(static fn (array $span): array => ['start' => $attr['value_start'] + $span['start'], 'end' => $attr['value_start'] + $span['end'], 'text' => $span['text']], $spans);
}

/**
 * Spans im style-Wert, die die Deklarationen $remove (aus $segments, le_markup_style_segments) samt Trenner entfernen,
 * sich berührende zusammengelegt: Ein eigenes „;“ geht mit dem Leerraum dahinter weg, bei der letzten Deklaration mit
 * dem davor; der letzten ohne „;“ gehört das „;“ davor. Leerraum am Ende des style bleibt.
 */
function le_markup_style_removals(string $style, array $segments, array $remove): array
{
    $length = strlen($style);
    $starts = array_column($remove, 'start');
    $spans = [];
    foreach ($segments as $k => $segment) {
        if ($segment['start'] === null || !in_array($segment['start'], $starts, true)) {
            continue;
        }
        $before = strlen(rtrim(substr($style, 0, $segment['start']), LE_HTML_WHITESPACE));
        if ($segment['sep_end'] !== null) {
            $next = $segment['sep_end'] + strspn($style, LE_HTML_WHITESPACE, $segment['sep_end']);
            $span = $next === $length ? [$before, $segment['sep_end']] : [$segment['start'], $next];
        } else {
            $span = [$k > 0 ? $segments[$k - 1]['end'] : $before, $segment['value_end']];
        }
        $last = count($spans) - 1;
        if ($last >= 0 && $span[0] <= $spans[$last]['end']) {
            $spans[$last]['end'] = max($spans[$last]['end'], $span[1]);
        } else {
            $spans[] = ['start' => $span[0], 'end' => $span[1], 'text' => ''];
        }
    }
    return $spans;
}

// Fertige Seite (nach dem Rendern): Stellen, an denen Plugins und der Seiten-Editor vor </head> bzw. </body> einfügen.
const LE_HTML_CLOSE_TAGS = ['head', 'body'];
// Tags, mit denen ein HTML-Dokument beginnt (wie <!doctype html>); auch hinter einem XML-Prolog eine Seite (XHTML).
const LE_HTML_DOCUMENT_TAGS = ['html', ...LE_HTML_CLOSE_TAGS];
// Byte-Order-Mark am Anfang einer UTF-8-Datei.
const LE_UTF8_BOM = "\xEF\xBB\xBF";
// Leerraum in HTML (vor dem ersten Tag übersprungen).
const LE_HTML_WHITESPACE = " \t\n\r\f";
// So beginnt (hinter BOM und Leerraum) JSON; nur dann wird geprüft, ob die ganze Ausgabe gültiges JSON ist.
const LE_HTML_JSON_STARTS = ['{', '[', '"'];
// Wurzeln von XML, das keine Seite ist (SVG, RSS, Atom, Sitemap), wenn die Ausgabe mit ihrem schließenden Tag endet.
// Hinter einem XML-Prolog (<?xml) gilt das für jede Wurzel außer LE_HTML_DOCUMENT_TAGS.
const LE_HTML_XML_ROOTS = ['svg', 'rss', 'feed', 'urlset', 'sitemapindex'];

/**
 * Stelle des schließenden Tags $tag ('head': das erste, 'body': das letzte) in einer fertigen Seite, außerhalb von
 * Kommentaren und Rohtext (MARKUP_RAW_TEXT_ELEMENTS). Kommentare und Start-Tags zählen wie in markup_parse
 * (markup_comment_end, markup_parse_start_tag, auch für selbst geschlossene Tags), Groß/klein und Leerraum vor „>“ egal.
 * Keine Seite (null) ist nur, was sicher keine ist (le_html_is_page): gültiges JSON, ganzes XML wie SVG, RSS, Sitemap.
 * Ohne solches </body> das Ende, wenn die Ausgabe (hinter BOM, Leerraum, Kommentaren, <?xml …?>) mit <!doctype html>
 * oder einem Tag aus LE_HTML_DOCUMENT_TAGS beginnt. Sonst wie vor dem Umbau das erste </head> bzw. letzte </body>
 * überhaupt (etwa hinter <!-- oder <script im Wert eines Attributs, das den Rest verdeckt), damit nichts fehlt; ohne eins
 * null (nachgeladene Teilstücke). Ein Durchlauf ab Versatz ohne .*?, auch für Skripte über 1 MB. Bekannte Grenzen:
 * Verdeckt ein Attributwert das </body> eines Dokuments, landet das Eingefügte am Ende, der Browser hängt es an <body>
 * an. Steht </head> bzw. </body> nur in einem Skript (etwa in einem String), findet es der Rückfall dort, und das
 * Eingefügte landet im Skript wie vor dem Umbau.
 */
function le_html_close_tag(string $html, string $tag): ?int
{
    static $pattern = null;
    if (!in_array($tag, LE_HTML_CLOSE_TAGS, true)) {
        throw new InvalidArgumentException('Unbekanntes Tag: ' . $tag);
    }
    if (!le_html_is_page($html)) {
        return null;
    }
    $pattern ??= '#<!--|<(' . implode('|', MARKUP_RAW_TEXT_ELEMENTS) . ')[\s>/]|</(' . implode('|', LE_HTML_CLOSE_TAGS) . ')[\s>]#i';
    $found = null;
    $offset = 0;
    while (preg_match($pattern, $html, $m, PREG_OFFSET_CAPTURE, $offset) === 1) {
        $at = $m[0][1];
        if ($m[0][0] === '<!--') {
            $offset = markup_comment_end($html, $at);
            continue;
        }
        if (($m[1][1] ?? -1) >= 0) {
            $start = markup_parse_start_tag($html, $at);
            $offset = $start['self_closing'] ? $start['end'] : markup_raw_text_end($html, strtolower($m[1][0]), $start['end'])[1];
            continue;
        }
        if (strtolower($m[2][0]) === $tag) {
            $found = $at;
            if ($tag === 'head') {
                return $found;
            }
        }
        $offset = $at + strlen($m[0][0]);
    }
    if ($found !== null) {
        return $found;
    }
    $documentStart = '#\G(?:<!doctype\s+html|<(?:' . implode('|', LE_HTML_DOCUMENT_TAGS) . ')[\s>])#i';
    if ($tag === 'body' && preg_match($documentStart, $html, $m, 0, le_html_markup_start($html, true)) === 1) {
        return strlen($html);
    }
    // Wie vor dem Umbau: ein </head> bzw. </body> irgendwo (das erste bzw. letzte), damit nichts fehlt.
    $all = preg_match_all('#</' . $tag . '[\s>]#i', $html, $m, PREG_OFFSET_CAPTURE);

    return $all > 0 ? $m[0][$tag === 'head' ? 0 : $all - 1][1] : null;
}

/**
 * Ob eine fertige Ausgabe eine Seite sein kann. Keine ist nur, was es als Ganzes sicher nicht ist (ohne BOMs und
 * Leerraum außen): gültiges JSON (geprüft erst, wenn sie mit einem Zeichen aus LE_HTML_JSON_STARTS beginnt) und
 * XML, das mit dem schließenden Tag seiner Wurzel endet (LE_HTML_XML_ROOTS, hinter <?xml …?> jede außer
 * LE_HTML_DOCUMENT_TAGS). Ein SVG-Sprite oder Text wie {{ x }} vor dem Doctype schließt eine Seite also nicht aus.
 * Bekannte Grenze: Steht ein <!DOCTYPE svg …> vor der Wurzel, wird sie nicht erkannt, und die Ausgabe gilt als Seite.
 */
function le_html_is_page(string $html): bool
{
    $at = le_html_markup_start($html, false);
    if (in_array($html[$at] ?? '', LE_HTML_JSON_STARTS, true)) {
        $json = substr($html, $at, le_html_markup_end($html) - $at);
        // json_validate ab PHP 8.3 braucht keinen Speicher für die Werte; was so beginnt, decodiert nie zu null.
        return !(function_exists('json_validate') ? json_validate($json) : json_decode($json) !== null);
    }
    $roots = preg_match('#\G<\?xml\b#i', $html, $m, 0, $at) === 1
        ? '(?!(?:' . implode('|', LE_HTML_DOCUMENT_TAGS) . ')[\s>/])[^\s>/!?]+'
        : implode('|', LE_HTML_XML_ROOTS);
    if (preg_match('#\G<(' . $roots . ')[\s>/]#i', $html, $m, 0, le_html_markup_start($html, true)) !== 1) {
        return true;
    }
    $close = '</' . $m[1] . '>';
    $end = le_html_markup_end($html);

    return $end < strlen($close) || substr_compare($html, $close, $end - strlen($close), strlen($close), true) !== 0;
}

/**
 * Versatz hinter BOMs und Leerraum am Anfang einer fertigen Seite (beliebig oft und gemischt); mit $markup auch hinter
 * Kommentaren und einem <?xml …?>-Prolog.
 */
function le_html_markup_start(string $html, bool $markup): int
{
    $at = 0;
    while (true) {
        $at += strspn($html, LE_HTML_WHITESPACE, $at);
        if (substr($html, $at, strlen(LE_UTF8_BOM)) === LE_UTF8_BOM) {
            $at += strlen(LE_UTF8_BOM);
        } elseif ($markup && substr($html, $at, 4) === '<!--') {
            $at = markup_comment_end($html, $at);
        } elseif ($markup && preg_match('#\G<\?xml\b#i', $html, $m, 0, $at) === 1) {
            $close = strpos($html, '?>', $at);
            $at = $close === false ? strlen($html) : $close + 2;
        } else {
            return $at;
        }
    }
}

/** Versatz vor BOMs und Leerraum am Ende einer fertigen Ausgabe (beliebig oft und gemischt), wie le_html_markup_start. */
function le_html_markup_end(string $html): int
{
    $end = strlen($html);
    while (true) {
        if ($end > 0 && str_contains(LE_HTML_WHITESPACE, $html[$end - 1])) {
            $end--;
        } elseif ($end >= strlen(LE_UTF8_BOM) && substr_compare($html, LE_UTF8_BOM, $end - strlen(LE_UTF8_BOM), strlen(LE_UTF8_BOM)) === 0) {
            $end -= strlen(LE_UTF8_BOM);
        } else {
            return $end;
        }
    }
}
