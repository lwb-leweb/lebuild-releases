<?php
declare(strict_types=1);

require_once LE_BACKEND . '/pages/store.php';
require_once LE_BACKEND . '/pages/rewrite.php';
require_once LE_BACKEND . '/pages/labels.php';
require_once LE_BACKEND . '/pages/fields.php';
require_once LE_BACKEND . '/base/files.php';
require_once LE_BACKEND . '/base/http.php';
require_once LE_BACKEND . '/base/texts.php';
require_once LE_BACKEND . '/base/utils.php';
require_once LE_BACKEND . '/html/markup.php';
require_once LE_BACKEND . '/pages/history.php';
require_once LE_BACKEND . '/pages/save.php';
require_once LE_BACKEND . '/pages/importMarkers.php';

// Elemente, die als Ganzes zu einem Textfeld werden können (dazu jedes Element mit vorhandener data-edit-id).
const IMPORT_CANDIDATE_TAGS = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'li', 'dt', 'dd', 'td', 'th', 'figcaption', 'blockquote', 'label', 'button', 'summary', 'div', 'span', 'a'];
const IMPORT_HEADING_TAGS = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'];
// Wrapper, die keine Abschnittsgrenze für Überschriften sind, auch wenn sie id oder class tragen.
const IMPORT_HEADING_WRAPPER_TAGS = ['header', 'hgroup'];
// Kinder, die statt des Elternteils markiert werden, wenn es sonst keinen eigenen Text hat.
const IMPORT_CHILD_TAGS = ['a', 'span'];
// Tag liefert den Abschnittsnamen, wenn id und class fehlen.
const IMPORT_STRUCTURE_TAGS = ['header', 'main', 'section', 'article', 'aside', 'footer', 'nav'];
// Ganzer Teilbaum wird weder markiert noch durchlaufen (ein <svg>, das als Icon gilt, wird ein Feld, le_icon_svg).
const IMPORT_SKIP_TAGS = ['script', 'style', 'template', 'svg', 'noscript'];
// Rest der Encoding-Anweisung, den der frühere DOMDocument-Import vor das HTML setzte (libxml schrieb sie als PI oder
// Kommentar); le_import_strip_xml_remnant() entfernt sie nur im Vorspann der Datei.
const LE_IMPORT_XML_REMNANTS = ['<?xml encoding="UTF-8">', '<?xml encoding="UTF-8"?>', '<!--?xml encoding="UTF-8"-->', '<!--?xml encoding="UTF-8"?-->'];
// Gründe, warum eine Datei unverändert übersprungen wird (Import-Ergebnis „skippedFiles“).
// 'name': Dateiname ist kein gültiger Seitenname (is_safe_page_name), z. B. index.bak.html, über-uns.html.
// 'component': heißt wie eine Komponente (header.html, footer.php), deren JSON sie überschriebe.
// 'duplicate': gleichnamige Seite mit anderer Endung; es gilt die, die auch ausgeliefert wird (page_source_path, .php vor .html).
// 'file_locked'/'store_locked': Datei bzw. Ablage unter private/cache nicht beschreibbar (vorab, import_write_problem).
const IMPORT_SKIP_REASONS = [
    'encoding' => 'nicht UTF-8',
    'name' => 'ungültiger Dateiname',
    'component' => 'Name der Kopf- oder Fußzeile',
    'duplicate' => 'gleichnamige .php-Seite gilt',
    'file_locked' => REWRITE_REASONS['file_locked'],
    'store_locked' => REWRITE_REASONS['store_locked'],
];
// <meta name="…" content="…">, die ein Feld werden (Wert im content-Attribut, reiner Text wie der
// Seitentitel; je Name die erste): name → ID ohne Präfix. Der Feldname ist LABEL_KINDS[name], ohne Überschrift.
const IMPORT_META_FIELDS = ['description' => 'meta.description'];
// <title> wird ebenso ein Feld (reiner Text, der erste, ohne PHP) mit dieser ID und dem Namen
// LABEL_KINDS[IMPORT_TITLE_KIND]. Die ID endet nicht auf .title: Die Seitenliste nimmt ihren
// Titel weiter aus der ersten Überschrift (page_title_from_content).
const IMPORT_TITLE_ID = 'meta.page_title';
const IMPORT_TITLE_KIND = 'pageTitle';
// Felder im <head>: heißen nur nach ihrer Art (import_label_kind), ohne Überschrift.
const IMPORT_HEAD_FIELD_TAGS = ['meta', 'title'];
// Stand der Markierungsregeln: Jede Änderung an ihnen, die bestehende Seiten betrifft, erhöht ihn. Import und
// „Markierungen aktualisieren“ speichern ihn im Import-Status (le_import_marker_rules); ist er dort kleiner, holt
// ops/tools/sites.php refresh --all das nach, mit eigenem Hosting zeigt die Seitenliste den Hinweis.
const LE_MARKER_RULES_VERSION = 1;

/**
 * Import bzw. mit $force „Markierungen aktualisieren“ für alle Seiten und Komponenten (api/import.php):
 * unter einer Sperre für alle (le_lock_all_pages), damit kein Speichern dazwischen kommt.
 */
function run_import(bool $force = false): array
{
    prepare_storage();

    // Ohne finally: Bricht eine Datei mittendrin ab, nimmt plans_restore_point sie am Ende des Prozesses
    // zurück, und bis dahin hält le_lock_all_pages die Sperre.
    $locks = le_lock_all_pages();
    // Status erst unter der Sperre prüfen: Zwei gleichzeitige Importe sähen sonst beide keinen.
    if (!$force && import_status() !== null) {
        unlock_pages($locks);
        return ['imported' => false, 'skipped' => true, 'pages' => list_pages(), 'skippedFiles' => []];
    }
    $status = le_run_import_locked();
    unlock_pages($locks);
    return $status;
}

/**
 * Was der Import anfasst: je Datei unter public/ (ohne „_“ am Anfang, das sind Endpoints, und ohne Links nach außen,
 * le_site_file_inside) und je
 * vorhandene Komponente ['file', 'name', 'reason']; reason ist der Schlüssel aus IMPORT_SKIP_REASONS,
 * wenn die Datei vorab übersprungen wird (Name ungültig, heißt wie eine Komponente, gleichnamige Seite
 * gilt), sonst null.
 */
function le_import_sources(): array
{
    $files = array_merge(
        glob(LE_SITE_ROOT . '/*.html') ?: [],
        glob(LE_SITE_ROOT . '/*.php') ?: []
    );
    $files = array_values(array_filter(
        $files,
        static fn (string $f): bool => !str_starts_with(basename($f), '_') && le_site_file_inside($f)
    ));
    sort($files);
    $sources = [];
    foreach ($files as $file) {
        $page = pathinfo($file, PATHINFO_FILENAME);
        // Ungültige Namen vorab aussortieren: safe_page_name bräche sonst mitten im Import ab.
        // Gleichnamige Dateien teilen sich eine JSON, also nur eine importieren.
        $reason = match (true) {
            !is_safe_page_name($page) => 'name',
            isset(shared_components()[$page]) => 'component',
            realpath((string) page_source_path($page)) !== realpath($file) => 'duplicate',
            default => null,
        };
        $sources[] = ['file' => $file, 'name' => $page, 'reason' => $reason];
    }
    foreach (shared_components() as $name => $file) {
        if (is_file($file)) {
            $sources[] = ['file' => $file, 'name' => $name, 'reason' => null];
        }
    }
    return $sources;
}

/**
 * lock_pages für alle Seiten und Komponenten, die der Import anfasst (le_import_sources): Import,
 * „Markierungen aktualisieren“ und ops/tools/sites.php (refresh, commit, deploy). Frei mit unlock_pages; bricht eine
 * Datei mittendrin ab, hält le_hold_until_shutdown die Sperre bis nach der Rücknahme.
 */
function le_lock_all_pages(): array
{
    prepare_storage();
    $names = array_column(array_filter(le_import_sources(), static fn (array $s): bool => $s['reason'] === null), 'name');
    $locks = lock_pages($names);
    le_hold_until_shutdown($locks);
    return $locks;
}

/**
 * Import aller Dateien (le_import_sources) unter einer schon gehaltenen Sperre (le_lock_all_pages). Je Datei
 * ganz oder gar nicht (le_refresh_markers_locked); übersprungene stehen mit Grund in skippedFiles. $user wie
 * bei le_refresh_markers_locked. Schreibt und liefert den Import-Status.
 */
function le_run_import_locked(?string $user = null): array
{
    $pages = [];
    $skippedFiles = [];
    foreach (le_import_sources() as $source) {
        $reason = $source['reason'] ?? le_refresh_markers_locked($source['name'], $user);
        if ($reason !== null) {
            $skippedFiles[] = ['file' => basename($source['file']), 'reason' => IMPORT_SKIP_REASONS[$reason]];
        } elseif (!isset(shared_components()[$source['name']])) {
            $pages[] = $source['name'];
        }
    }

    $status = [
        'imported' => true,
        'importedAt' => current_iso_time(),
        'pages' => $pages,
        'skippedFiles' => $skippedFiles,
        'markerRules' => LE_MARKER_RULES_VERSION,
    ];
    save_import_status($status);

    return $status;
}

/**
 * „Markierungen aktualisieren“ für $name unter einer schon gehaltenen lock_pages-Sperre
 * (le_sync_sources, ops/tools/sites.php; nie verschachtelt sperren). $user: Urheber in der Kurzinfo des
 * Backups, sonst der angemeldete Benutzer.
 */
function le_refresh_markers_locked(string $name, ?string $user = null): ?string
{
    $file = (string) page_source_path($name);
    $prefix = isset(shared_components()[$name]) ? $name : '';
    $source = (string) file_get_contents($file);
    if (!mb_check_encoding($source, 'UTF-8')) {
        return 'encoding';
    }

    $result = import_source($source, $prefix, import_issued_ids($name), le_source_is_php($file));
    // Kurzinfo mit den Namen aus der neuen Quelle (neue IDs heißen wie im Editor), ein Baum für beides.
    $doc = markup_parse($result['source']);
    $kinds = page_field_kinds($doc, $name, $result['content']);
    $plans = [$name => ['file' => $file, 'source' => $result['source'] !== $source ? $result['source'] : null]];
    $problem = import_write_problem($name, $plans[$name], $result['content'], $kinds);
    if ($problem !== null) {
        return $problem;
    }
    if ($prefix === '') {
        $originalPath = ORIGINALS_ROOT . '/' . basename($file);
        if (!is_file($originalPath)) {
            copy($file, $originalPath);
        }
    }

    $restore = plans_restore_point($plans);
    $done = false;
    register_shutdown_function(static function () use (&$done, $restore): void {
        if (!$done) {
            $restore();
        }
    });
    save_page_content($name, $result['content'], $kinds, ['doc' => $doc, 'user' => $user], le_plan_source_hash($plans[$name]));
    if ($plans[$name]['source'] !== null) {
        snapshot_original_file($file, false);
        atomic_write($file, $result['source']);
    }
    $done = true;
    // Alte Backups und Snapshots erst nach Erfolg weg, damit die Rücknahme den Stand davor hat.
    prune_backups($name);
    if ($plans[$name]['source'] !== null) {
        prune_file_snapshots($file);
    }
    return null;
}

/**
 * Was der Import von $name schreiben würde und nicht kann, vorab wie plan_write_errors beim
 * Speichern: geänderte Datei ($plan['source']) bzw. JSON samt Backup-Ordner, wenn sich die JSON
 * ändert. Schlüssel aus IMPORT_SKIP_REASONS oder null.
 */
function import_write_problem(string $name, array $plan, array $content, array $kinds): ?string
{
    $json = page_json_path($name);
    $jsonChanges = !is_file($json) || file_get_contents($json) !== page_json_text(sanitize_content_tree($content, $kinds), le_plan_source_hash($plan));
    return match (true) {
        $plan['source'] !== null && !path_writable($plan['file']) => 'file_locked',
        $jsonChanges && (!path_writable($json) || !is_writable(BACKUPS_ROOT . '/' . $name)) => 'store_locked',
        default => null,
    };
}

/**
 * IDs, die eine Seite oder Komponente schon vergeben hat (wie in der Datei, mit Präfix): Felder
 * ihres JSON und ihrer Backups sowie ihre Namens-Overrides. Der Import gibt sie keinem anderen
 * Element, sonst schriebe ein altes Backup fremden Text hinein.
 */
function import_issued_ids(string $name): array
{
    $pre = field_id_prefix($name);
    $issued = array_fill_keys(array_keys(load_label_overrides($name)), true);
    foreach ([page_json_path($name), ...page_backup_files($name)] as $file) {
        $data = is_file($file) ? le_page_json_content((string) file_get_contents($file)) : null;
        foreach (array_keys(flatten_content($data ?? [])) as $id) {
            $issued[$pre . $id] = true;
        }
    }
    return $issued;
}

function import_status(): ?array
{
    $path = CACHE_ROOT . '/import-status.json';
    if (!is_file($path)) {
        return null;
    }

    $data = json_decode((string) file_get_contents($path), true);
    return is_array($data) ? $data : null;
}

/**
 * Stand der Markierungsregeln, nach dem $status (import_status) gesetzt wurde; ohne das Feld (Import von vorher) 0,
 * vor dem ersten Import (kein Status) null.
 */
function le_import_marker_rules(?array $status): ?int
{
    return $status === null ? null : (int) ($status['markerRules'] ?? 0);
}

function save_import_status(array $status): void
{
    ensure_dir(CACHE_ROOT);
    $json = json_encode($status, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        json_response(['ok' => false, 'error' => API_TEXT['importStatusFailed']], 500);
    }
    // atomic_write antwortet selbst mit 500, wenn es nicht schreiben kann.
    atomic_write(CACHE_ROOT . '/import-status.json', $json . PHP_EOL);
}
