<?php
declare(strict_types=1);

// Stellen eines Bildfelds auf der Website (Endpunkt imageUsage) und was der Browser zum Messen und für die Vorschauen
// braucht: Breiten, Höchstzahl der Stellen, Parameter der Messseite, Markierung am <img> (le_preview_config).

require_once LE_BACKEND . '/pages/store.php';
require_once LE_BACKEND . '/pages/routes.php';
require_once LE_BACKEND . '/plugins/hooks.php';
require_once LE_BACKEND . '/plugins/render.php';
require_once LE_BACKEND . '/plugins/markers.php';

// Breiten, in denen der Browser eine Stelle misst und die Vorschau zeigt (dieselben wie im Skill lebuild-website). height:
// Fenster des Geräts in der Vorschau einer Galerie (gallery-preview.js), dort das Maß für vh und Medienabfragen nach der
// Höhe; gemessen wird weiter in einem Fenster der Höhe --le-framing-measure-height.
const LE_PREVIEW_WIDTHS = [
    'desktop' => ['label' => 'Desktop', 'width' => 1280, 'height' => 900],
    'tablet' => ['label' => 'Tablet', 'width' => 768, 'height' => 1024],
    'mobile' => ['label' => 'Handy', 'width' => 390, 'height' => 844],
];
// Höchstens so viele Stellen je Bildfeld (le_image_places).
const LE_PREVIEW_MAX_PLACES = 4;
// Messseite: ?le-measure=1 liefert Angemeldeten die Seite ohne Seiten-Editor (le_respond_site_html), Besuchern wie sonst.
const LE_MEASURE_PARAM = 'le-measure';
const LE_MEASURE_VALUE = '1';
// Namen der Stellen: die Startseite, die eigene Seite eines Eintrags; sonst der Text des Navigationslinks auf die Seite
// (le_nav_labels), ohne einen der Titel aus der Seitenliste, ohne den der Seitenname.
const LE_PLACE_HOME_LABEL = 'Startseite';
const LE_PLACE_OWN_LABEL = 'Eigene Seite';
const LE_PLACE_HOME_URL = '/';
// Dateien der Website, in denen eine Navigation stehen kann (Seiten und eingebundene Teile).
const LE_NAV_EXTENSIONS = ['php', 'html', 'htm'];

/** Ob die Anfrage eine Messseite will (LE_MEASURE_PARAM mit LE_MEASURE_VALUE); wirksam nur für Angemeldete. */
function le_measure_requested(): bool
{
    return ($_GET[LE_MEASURE_PARAM] ?? null) === LE_MEASURE_VALUE;
}

/**
 * Stellen des Bildfelds $field des Typs $type von $plugin als Liste aus ['label', 'url']: zuerst Seiten der Seitenliste,
 * deren Datei einen Shortcode des Plugins für eine Liste dieses Typs enthält (Hook image_usage, le_shortcodes_in_html;
 * Adresse ohne Endung, Name nach le_place_label), dann die eigene Seite des Eintrags $id (ohne $id oder ohne eigene
 * Seite die eines anderen Eintrags), die der Hook nennt, als LE_PLACE_OWN_LABEL. Höchstens LE_PREVIEW_MAX_PLACES, die
 * eigene Seite zählt immer mit (sie hat meist eine andere Form). [] ohne Hook, für einen unbekannten Typ oder ein Feld,
 * das kein Bildfeld ist.
 */
function le_image_places(string $plugin, string $type, string $field, ?int $id = null): array
{
    $usage = le_plugin_image_usage($plugin, $type, $field, $id);
    if ($usage === null) {
        return [];
    }
    $own = $usage['page'] !== null ? [['label' => LE_PLACE_OWN_LABEL, 'url' => $usage['page']]] : [];
    $places = [];
    $nav = null;
    foreach (list_pages() as $page) {
        if (count($places) >= LE_PREVIEW_MAX_PLACES - count($own)) {
            break;
        }
        $file = page_source_path($page);
        $url = $file !== null ? le_page_place_url($page, $file) : null;
        $source = $url !== null ? @file_get_contents($file) : false;
        if ($source === false) {
            continue;
        }
        foreach (le_shortcodes_in_html($source) as $attrs) {
            if (($attrs['plugin'] ?? null) === $plugin && array_intersect_assoc($usage['shortcode'], $attrs) === $usage['shortcode']) {
                $nav ??= le_nav_labels();
                $places[] = ['label' => le_place_label($page, $url, $nav, page_info($page)['title']), 'url' => $url];
                break;
            }
        }
    }

    return [...$places, ...$own];
}

/** Adresse der Seite $page mit der Quelldatei $file, wie Stellen sie nennen (ohne Endung, le_site_clean_path). */
function le_page_place_url(string $page, string $file): string
{
    return le_site_clean_path(LE_SITE_FILES_URL . $page . '.' . pathinfo($file, PATHINFO_EXTENSION), $file);
}

/**
 * Die Seite $page als Stelle ihrer eigenen Bilder (Panel „Bild“ des Seiten-Editors): [['label', 'url']] mit dem Namen
 * nach le_place_label wie bei den Stellen eines Bildfelds; die Startseite ohne Suche in der Navigation. [] für eine
 * Seite, die nicht in der Seitenliste steht oder keine Quelldatei hat.
 */
function le_page_places(string $page): array
{
    $file = is_safe_page_name($page) && in_array($page, list_pages(), true) ? page_source_path($page) : null;
    if ($file === null) {
        return [];
    }
    $url = le_page_place_url($page, $file);

    return [['label' => le_place_label($page, $url, $url === LE_PLACE_HOME_URL ? [] : le_nav_labels(), page_info($page)['title']), 'url' => $url]];
}

/**
 * Kurzer Name einer Seite $page mit der Adresse $url für die Vorschauen: LE_PLACE_HOME_LABEL für die Startseite, sonst der
 * Text des Navigationslinks auf $url ($nav aus le_nav_labels), sonst ihr Titel aus der Seitenliste ($title), ohne ihn
 * der Seitenname.
 */
function le_place_label(string $page, string $url, array $nav, string $title): string
{
    if ($url === LE_PLACE_HOME_URL) {
        return LE_PLACE_HOME_LABEL;
    }

    return $nav[$url] ?? ($title !== '' ? $title : $page);
}

/**
 * Texte der Links in <nav> der Website (Seiten und eingebundene Teile unter LE_SITE_ROOT, LE_NAV_EXTENSIONS) als
 * [Pfad => Text]: Pfad ohne Host, Query und abschließendes „/“, Links mit # zählen nicht, der erste Text je Pfad gilt.
 * Text ohne Tags, Entitäten aufgelöst, Leerraum zusammengefasst; leere fallen weg.
 */
function le_nav_labels(): array
{
    // Erst hier: Die öffentliche Seite lädt diese Datei (le_measure_requested), braucht die Dateiliste aber nie.
    require_once LE_BACKEND . '/media/usage.php';
    $labels = [];
    foreach (le_media_text_paths(LE_SITE_ROOT, LE_NAV_EXTENSIONS) as $path) {
        // Wie bei der Suche nach Verweisen: Dateien über UPLOAD_REFERENCE_MAX_BYTES liest sie nicht.
        $size = is_file($path) && le_site_file_inside($path) ? @filesize($path) : false;
        $source = $size !== false && $size <= UPLOAD_REFERENCE_MAX_BYTES ? @file_get_contents($path) : false;
        // Kein Treffer oder ein Fehler der Suche (z. B. Grenze der Rückverfolgung bei riesigen Dateien): nichts von hier.
        if ($source === false || !preg_match_all('~<nav\b[^>]*>(.*?)</nav>~is', $source, $navs)) {
            continue;
        }
        foreach ($navs[1] as $nav) {
            if (!preg_match_all('~<a\b[^>]*\bhref=(["\'])(.*?)\1[^>]*>(.*?)</a>~is', $nav, $links, PREG_SET_ORDER)) {
                continue;
            }
            foreach ($links as [, , $href, $inner]) {
                $href = html_entity_decode($href, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $text = trim((string) preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags($inner), ENT_QUOTES | ENT_HTML5, 'UTF-8')));
                $path = parse_url($href, PHP_URL_PATH);
                if (str_contains($href, '#') || !is_string($path) || $text === '') {
                    continue;
                }
                $labels[rtrim($path, '/') ?: LE_PLACE_HOME_URL] ??= $text;
            }
        }
    }

    return $labels;
}

/** Was der Browser zum Messen und für die Vorschauen braucht (Bootstrap und JSON-Block des Seiten-Editors). */
function le_preview_config(): array
{
    return [
        'widths' => LE_PREVIEW_WIDTHS,
        'maxPlaces' => LE_PREVIEW_MAX_PLACES,
        'measureParam' => LE_MEASURE_PARAM,
        'measureValue' => LE_MEASURE_VALUE,
        'fieldAttr' => LE_FIELD_ATTR,
        'fieldSeparator' => LE_FIELD_SEPARATOR,
    ];
}
