<?php
declare(strict_types=1);

// Felder der Seitendateien: Feldart aus der ID (für Felder ohne Markierung) und aus der Markierung, Element eines Feldes
// finden, Wert aus der Quelle lesen, Hintergrundbilder und Bildvarianten.

require_once LE_BACKEND . '/html/icons.php';
require_once LE_BACKEND . '/html/markup.php';
require_once LE_BACKEND . '/html/textMarkup.php';
require_once LE_BACKEND . '/media/images.php';
require_once LE_BACKEND . '/media/uploads.php';
require_once LE_BACKEND . '/pages/store.php';

/**
 * Feldart nach dem letzten ID-Segment: text | url | image | alt | focus | background | icon. Gilt für Felder
 * ohne Markierung in der Datei; sonst entscheidet die Markierung (field_target_kind, dazu linktext
 * und plain).
 */
function field_kind(string $id): string
{
    $field = edit_field_from_id($id);
    if (str_ends_with($field, '_alt')) {
        return 'alt';
    }
    if (str_ends_with($field, LE_FOCUS_ID_SUFFIX)) {
        return 'focus';
    }
    return in_array($field, ['url', 'image', 'background', 'icon'], true) ? $field : 'text';
}

/** Feldname einer ID ohne Nummer: hero.url_2 → url. */
function edit_field_from_id(string $id): string
{
    $field = substr(strrchr('.' . $id, '.'), 1);
    return preg_replace('/_\d+$/', '', $field) ?? $field;
}

// Markierungen, über die ein Feld sein Element in der Datei findet, und was dort ersetzt wird:
// 'inner' = Innenbereich, 'background' = URL im style-Attribut, 'focus' = Fokuspunkt im style-Attribut (le_focus_property),
// 'icon' = ganzes <svg> (backend/html/icons.php), sonst das genannte Attribut; null = bei data-edit-id entscheidet der Tag (EDIT_ATTR_BY_TAG).
const EDIT_MARKERS = ['data-edit-id' => null, 'data-edit-text-id' => 'inner', 'data-edit-alt-id' => 'alt', 'data-edit-bg-id' => 'background', 'data-edit-focus-id' => 'focus'];
// Eigenschaft des Fokuspunkts je Tag (le_focus_property): am Bild object-position, sonst (Hintergrund) background-position.
const LE_FOCUS_PROPERTY_BY_TAG = ['img' => LE_FOCUS_IMAGE_PROPERTY];
// Bei data-edit-id entscheidet der Tag, was ersetzt wird; ohne Eintrag der Innenbereich.
// <meta>: der Wert im content-Attribut (Seitenbeschreibung); <svg>: das Icon.
const EDIT_ATTR_BY_TAG = ['a' => 'href', 'img' => 'src', 'meta' => 'content', 'svg' => 'icon'];
// Hintergrundbild im style-Attribut (background-image oder background-Kurzform), roh oder mit
// Entity-Anführungszeichen; Gruppe 2 ist die URL, leer bei url() bzw. url("") (geleertes Feld).
const BACKGROUND_URL_PATTERN = '/(?<![\w-])background(?:-image)?\s*:[^;]*?url\(\s*(&quot;|&#0*39;|&apos;|[\'"]|)([^\'")]*?)\1\s*\)/i';
// Fallen beim Tausch von src weg, sonst zeigten Browser weiter das alte Bild daraus.
const IMAGE_VARIANT_ATTRS = ['srcset', 'sizes'];
// In <picture> fallen beim Tausch von src auch die <source>-Geschwister weg.
const PICTURE_TAG = 'picture';
const PICTURE_SOURCE_TAG = 'source';
// Größe am <img>: Beim Tausch von src bleibt die Breite, die Höhe folgt der neuen Datei (le_image_height_replacement).
const LE_IMAGE_WIDTH_ATTR = 'width';
const LE_IMAGE_HEIGHT_ATTR = 'height';
// Breite, mit der gerechnet wird: ganze Pixel ohne Einheit. Dieselbe Regel steht im Browser als SIZE_PATTERN
// (frontend/site-editor/page-sync.js, auch für data-le-size); tests/frontend/code.test.php hält beide gleich.
const LE_IMAGE_DIMENSION_PATTERN = '/^[1-9][0-9]*\z/';
// Ziel in der Datei → Feldart für die Bereinigung (sanitize_field_value); Text in einem Link
// wird zu 'linktext', der Innenbereich von PLAIN_TEXT_TAGS zu 'plain' (field_target_kind).
// Das content-Attribut von <meta> ist reiner Text wie der Seitentitel ('plain').
// Elemente, deren Inhalt der Browser als Text mit Entities liest (<title>, <textarea>): reiner Text
// ohne Auszeichnung, gelesen dekodiert, geschrieben kodiert. <script>/<style> gehören nicht dazu
// (dort gelten keine Entities); der Import markiert sie nicht.
const PLAIN_TEXT_TAGS = ['title', 'textarea'];
const EDIT_KIND_BY_TARGET = ['inner' => 'text', 'href' => 'url', 'src' => 'image', 'alt' => 'alt', 'background' => 'background', 'content' => 'plain', 'icon' => 'icon', 'focus' => 'focus'];

/**
 * Element eines Feldes im Baum: [Knotenindex, Ziel ('inner' oder Attributname)]
 * oder der Fehlerschlüssel aus REWRITE_REASONS.
 */
function find_field_element(array $doc, string $id): array|string
{
    $hits = [];
    foreach (array_keys(EDIT_MARKERS) as $marker) {
        foreach (markup_find_by_attr($doc, $marker, $id) as $index) {
            $hits[] = [$marker, $index];
        }
    }
    if ($hits === []) {
        return 'missing';
    }
    if (count($hits) > 1) {
        return 'duplicate';
    }
    [$marker, $index] = $hits[0];
    $node = $doc['nodes'][$index];
    $target = edit_marker_target($marker, $node);
    if (($target === 'inner' || $target === 'icon') && $node['self_closing']) {
        return 'void';
    }
    if ($target !== 'inner' && edit_target_problem($node, $target) === 'missing') {
        return 'missing';
    }
    return [$index, $target];
}

/**
 * Warum ein Ziel außer 'inner' am Element nicht lesbar und zurückschreibbar ist (Schlüssel aus
 * REWRITE_REASONS), sonst null – die eine Regel für Import und Speichern: Hintergrund ohne url(…)
 * im style gilt als nicht gefunden, ein PHP-Block im Attribut als 'php' (beim Icon irgendwo im
 * Start-Tag; PHP im Innenbereich prüft der Aufrufer), ein style, den der Fokus nicht sicher ändern
 * kann, als 'style' (le_markup_style_writable). Ein fehlendes Attribut ist kein Hindernis
 * (markup_set_attr fügt es ein).
 */
function edit_target_problem(array $node, string $target): ?string
{
    if ($target === 'icon') {
        return $node['has_php'] || in_array(true, array_column($node['attrs'], 'has_php'), true) ? 'php' : null;
    }
    $attr = markup_attr($node, edit_target_attr($target));
    if ($target === 'background' && background_url_match($attr['value'] ?? '') === null) {
        return 'missing';
    }
    if ($attr['has_php'] ?? false) {
        return 'php';
    }
    return $target === 'focus' && !le_markup_style_writable($node) ? 'style' : null;
}

/** Was eine Markierung am Element ersetzt: 'inner', 'background' oder ein Attributname (EDIT_MARKERS). */
function edit_marker_target(string $marker, array $node): string
{
    return EDIT_MARKERS[$marker] ?? EDIT_ATTR_BY_TAG[$node['tag']] ?? 'inner';
}

/** Attribut, in dem ein Ziel außer 'inner' steht: Hintergrund-URL und Fokuspunkt im style, sonst das Ziel selbst. */
function edit_target_attr(string $target): string
{
    return in_array($target, ['background', 'focus'], true) ? 'style' : $target;
}

/** CSS-Eigenschaft des Fokuspunkts am Element (LE_FOCUS_PROPERTY_BY_TAG). */
function le_focus_property(array $node): string
{
    return LE_FOCUS_PROPERTY_BY_TAG[$node['tag']] ?? LE_FOCUS_BACKGROUND_PROPERTY;
}

/**
 * Feldart eines Feldes in der Datei – die eine Quelle für Datei, JSON und Admin: Ziel der
 * Markierung (EDIT_KIND_BY_TARGET); Text an oder in einem Link ist Linktext (ohne eigene Links).
 */
function field_target_kind(array $doc, int $index, string $target): string
{
    if ($target === 'inner' && in_array($doc['nodes'][$index]['tag'], PLAIN_TEXT_TAGS, true)) {
        return 'plain';
    }
    $kind = EDIT_KIND_BY_TARGET[$target];
    for ($i = $index; $kind === 'text' && $i !== null; $i = $doc['nodes'][$i]['parent']) {
        if ($doc['nodes'][$i]['tag'] === 'a') {
            $kind = 'linktext';
        }
    }
    return $kind;
}

/** Feldart einer ID: aus der Markierung, wenn das Feld in der Datei eindeutig steht, sonst nach der ID. */
function field_kind_in_doc(array $doc, string $id): string
{
    $found = find_field_element($doc, $id);
    return is_array($found) ? field_target_kind($doc, $found[0], $found[1]) : field_kind($id);
}

/**
 * Feldarten aller Felder eines Inhalts und aller in der Datei markierten (auch nicht importierten)
 * Felder (Pfad wie im Inhalt → Art) im Baum $doc der Seite oder Komponente $name
 * (page_source_doc, beim Import der Baum der neuen Quelle).
 */
function page_field_kinds(array $doc, string $name, array $content): array
{
    $prefix = field_id_prefix($name);
    $ids = array_map('strval', array_keys(flatten_content($content)));
    foreach (array_keys(EDIT_MARKERS) as $marker) {
        foreach (array_keys($doc['by_attr'][$marker] ?? []) as $id) {
            if (str_starts_with((string) $id, $prefix)) {
                $ids[] = substr((string) $id, strlen($prefix));
            }
        }
    }
    $kinds = [];
    foreach (array_unique($ids) as $id) {
        $kinds[$id] = field_kind_in_doc($doc, $prefix . $id);
    }
    return $kinds;
}

/**
 * Teilt einen Inhalt (altes Backup) nach dem Baum $doc der Seite oder Komponente $name
 * (page_source_doc): ['content' => Felder, deren ID dort markiert ist, 'skipped' => Zahl der
 * übrigen]. Ohne Datei ist kein Feld bekannt.
 */
function known_source_fields(array $doc, string $name, array $content): array
{
    $prefix = field_id_prefix($name);
    $known = [];
    $skipped = 0;
    foreach (flatten_content($content) as $id => $value) {
        if (find_field_element($doc, $prefix . $id) === 'missing') {
            $skipped++;
            continue;
        }
        set_nested_value($known, (string) $id, $value);
    }
    return ['content' => $known, 'skipped' => $skipped];
}

/** Treffer von BACKGROUND_URL_PATTERN im rohen style-Wert: ['url' => roh, 'start' => Offset, 'end' => Offset] oder null. */
function background_url_match(string $style): ?array
{
    if (!preg_match(BACKGROUND_URL_PATTERN, $style, $m, PREG_OFFSET_CAPTURE)) {
        return null;
    }
    return ['url' => $m[2][0], 'start' => $m[2][1], 'end' => $m[2][1] + strlen($m[2][0])];
}

/**
 * Ersetzung „nur die URL in url(…) des style-Attributs“; Anführungszeichen bleiben wie vorgefunden.
 * $url ist der bereinigte Feldwert und landet unverändert in url(…), nur fürs Attribut
 * HTML-kodiert; Leerraum, Klammern und Anführungszeichen kodiert die Bereinigung des Feldwerts.
 * Der Kern macht einen zerlegbaren style nie unzerlegbar (le_markup_style_segments, sonst sperrte der Fokus): Wäre er es
 * danach, kommt die Adresse in Anführungszeichen, die das Attribut nicht beenden.
 */
function markup_set_background_url(array $doc, int $index, string $url): array
{
    $attr = markup_attr($doc['nodes'][$index], 'style');
    $match = background_url_match($attr['value']);
    $text = markup_attr_escape($url);
    $written = substr_replace($attr['value'], $text, $match['start'], $match['end'] - $match['start']);
    if (le_markup_style_segments($written) === null && le_markup_style_segments($attr['value']) !== null) {
        $quote = $attr['quote'] === "'" ? '"' : "'";
        $text = $quote . $text . $quote;
    }
    return ['start' => $attr['value_start'] + $match['start'], 'end' => $attr['value_start'] + $match['end'], 'text' => $text];
}

/** Eigenschaft des Fokuspunkts je Tag (le_focus_property) an den Browser: Die Vorschau setzt sie wie das Speichern. */
function le_focus_config(): array
{
    return ['byTag' => LE_FOCUS_PROPERTY_BY_TAG, 'other' => LE_FOCUS_BACKGROUND_PROPERTY];
}

/**
 * Regel für image_variant_removals an den Browser (api/bootstrap.php), die Vorschau tauscht Bilder genauso; dazu die
 * Größe am <img>, deren Höhe sie wie le_image_height_replacement nachzieht, und die Endungen, bei denen das gilt.
 */
function image_variant_config(): array
{
    return ['attrs' => IMAGE_VARIANT_ATTRS, 'picture' => PICTURE_TAG, 'source' => PICTURE_SOURCE_TAG,
        'width' => LE_IMAGE_WIDTH_ATTR, 'height' => LE_IMAGE_HEIGHT_ATTR, 'heightTypes' => le_image_height_types()];
}

/**
 * Endungen, bei denen die Höhe am <img> der neuen Datei folgt: Fotos (LE_SITE_PHOTO_EXTENSIONS, kein SVG), die als Bild
 * dieses Projekts gelten (LE_UPLOAD_TYPES, le_upload_image_path). Die eine Liste für Speichern und Vorschau.
 */
function le_image_height_types(): array
{
    return array_values(array_intersect(LE_SITE_PHOTO_EXTENSIONS, array_keys(LE_UPLOAD_TYPES)));
}

/**
 * Ersetzungen, die beim Tausch von src mitgehen: srcset/sizes am Bild und, liegt es in
 * <picture>, dessen <source>-Kinder. PHP darin ist kein Hindernis, der Block liegt
 * vollständig im entfernten Span.
 */
function image_variant_removals(array $doc, int $index): array
{
    $removals = [];
    foreach (IMAGE_VARIANT_ATTRS as $name) {
        $removal = markup_remove_attr($doc, $index, $name);
        if ($removal !== null) {
            $removals[] = $removal;
        }
    }
    $parent = $doc['nodes'][$index]['parent'];
    if ($parent !== null && $doc['nodes'][$parent]['tag'] === PICTURE_TAG) {
        foreach ($doc['nodes'][$parent]['children'] as $child) {
            if ($doc['nodes'][$child]['type'] === 'element' && $doc['nodes'][$child]['tag'] === PICTURE_SOURCE_TAG) {
                $removals[] = markup_remove_node($doc, $child);
            }
        }
    }
    return $removals;
}

/**
 * Ersetzung, die beim Tausch von src mitgeht: Trägt das <img> width (ganze Pixel) und height, beide ohne PHP, und ist
 * $url ein Foto dieses Projekts (le_upload_image_path, Endung aus le_image_height_types), bleibt width und height
 * folgt dem Seitenverhältnis, wie der Browser die Datei zeigt (le_image_display_size, mit EXIF-Drehung). Sonst (fremde
 * Adresse, SVG – getimagesize liest es erst ab PHP 8.5 –, width in Prozent, unlesbar, Höhe stimmt schon) null.
 */
function le_image_height_replacement(array $doc, int $index, string $url): ?array
{
    $node = $doc['nodes'][$index];
    $width = markup_attr($node, LE_IMAGE_WIDTH_ATTR);
    $height = markup_attr($node, LE_IMAGE_HEIGHT_ATTR);
    if ($width === null || $height === null || $width['has_php'] || $height['has_php']
        || !preg_match(LE_IMAGE_DIMENSION_PATTERN, (string) $width['value'])) {
        return null;
    }
    $site = le_upload_site_url($url);
    $file = $site !== null ? le_upload_image_path($site) : null;
    $photo = $file !== null && in_array(strtolower(pathinfo($file, PATHINFO_EXTENSION)), le_image_height_types(), true);
    $size = $photo ? le_image_display_size($file) : null;
    if ($size === null) {
        return null;
    }
    $value = (string) max(1, (int) round((int) $width['value'] * $size[1] / $size[0]));
    return $value === $height['value'] ? null : markup_set_attr($doc, $index, LE_IMAGE_HEIGHT_ATTR, $value);
}

/** Bereinigter Wert eines Feldes in der Datei ($target wie aus find_field_element). */
function source_field_value(array $doc, int $index, string $target): string
{
    $node = $doc['nodes'][$index];
    $kind = field_target_kind($doc, $index, $target);
    $raw = match ($target) {
        'inner' => $kind === 'plain' ? html_entity_decode(markup_inner_html($doc, $index), ENT_HTML5 | ENT_QUOTES, 'UTF-8') : markup_inner_html($doc, $index),
        'background' => html_entity_decode(background_url_match(markup_attr($node, 'style')['value'])['url'], ENT_HTML5 | ENT_QUOTES, 'UTF-8'),
        'icon' => le_icon_from_svg($doc, $index),
        'focus' => le_markup_style_value($node, le_focus_property($node)),
        default => markup_attr_text($node, $target),
    };
    return sanitize_field_value($kind, $raw);
}

/** Liegt im Innenbereich ein weiteres markiertes Element (sein Marker ginge beim Ersetzen verloren)? */
function inner_has_field(array $doc, int $index): bool
{
    foreach ($doc['nodes'][$index]['children'] ?? [] as $child) {
        $node = $doc['nodes'][$child];
        foreach (array_keys(EDIT_MARKERS) as $marker) {
            if ($node['type'] === 'element' && markup_attr($node, $marker) !== null) {
                return true;
            }
        }
        if (inner_has_field($doc, $child)) {
            return true;
        }
    }
    return false;
}

/** IDs in der Datei tragen bei Komponenten (header/footer) den Namen als Präfix. */
function field_id_prefix(string $name): string
{
    return isset(shared_components()[$name]) ? $name . '.' : '';
}

/**
 * Komponente, deren Präfix die ID trägt (header.…, footer.…), sonst null. Das Präfix ordnet ein
 * Feld der Komponente zu (getPage, savePage); Seiten-IDs tragen deshalb keins (Import).
 */
function id_component(string $id): ?string
{
    $first = strstr($id, '.', true);
    return $first !== false && isset(shared_components()[$first]) ? $first : null;
}
