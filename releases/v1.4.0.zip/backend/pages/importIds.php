<?php
declare(strict_types=1);

// Import, IDs und Feldnamen der markierten Elemente (data-edit-id): vorhandene bleiben, neue gab es nie.

require_once LE_BACKEND . '/html/markup.php';
require_once LE_BACKEND . '/pages/fields.php';
require_once LE_BACKEND . '/pages/import.php';
require_once LE_BACKEND . '/pages/importMarkers.php';
require_once LE_BACKEND . '/pages/labels.php';

/**
 * Vorhandene IDs bleiben, und zwar das erste Vorkommen: erst die IDs, die schon so in der Datei
 * stehen, dann die, die in Komponenten erst das Präfix $pre bekommen. Danach sind auch die früher
 * vergebenen ($issued) gesperrt; weitere Vorkommen (z. B. per FTP kopiert) und neue Elemente
 * bekommen eine ID, die es nie gab – so nimmt kein Element die ID eines anderen.
 */
function import_assign_ids(array $doc, array $marks, string $pre, array $issued = []): array
{
    $assigned = [];
    $take = static function (string $id) use (&$assigned, $pre): string {
        $id = unique_edit_id($pre === '' ? import_page_id($id) : $id, $assigned);
        $assigned[$id] = true;
        return $id;
    };

    $copies = [];
    foreach ([true, false] as $exact) {
        foreach ($marks as $m => $mark) {
            foreach (import_existing_ids($doc['nodes'][$mark['index']], $mark) as $name => $existing) {
                if (str_starts_with($existing, $pre) !== $exact) {
                    continue;
                }
                $id = $exact ? $existing : $pre . $existing;
                if (isset($assigned[$id])) {
                    $copies[] = [$m, $name, $id];
                } else {
                    $assigned[$id] = true;
                    $marks[$m]['attrs'][$name] = $id;
                }
            }
        }
    }
    $assigned += $issued;
    foreach ($copies as [$m, $name, $id]) {
        $marks[$m]['attrs'][$name] = $take($id);
    }

    $counts = [];
    foreach ($marks as &$mark) {
        $tag = $mark['tag'];
        if ($mark['field'] !== null && !isset($mark['attrs']['data-edit-id'])) {
            $id = match ($tag) {
                'meta' => IMPORT_META_FIELDS[$mark['field']],
                'title' => IMPORT_TITLE_ID,
                default => generate_edit_id($tag, $mark['group'], $counts, $assigned, $pre),
            };
            $mark['attrs']['data-edit-id'] = $take($pre . $id);
        }
        if ($mark['text'] && !isset($mark['attrs']['data-edit-text-id'])) {
            // Ohne data-edit-id (Link ohne Ziel) ein eigenes Textfeld, benannt wie ein span.
            $mark['attrs']['data-edit-text-id'] = $take(isset($mark['attrs']['data-edit-id'])
                ? edit_base_from_id($mark['attrs']['data-edit-id']) . '.text'
                : $pre . generate_edit_id('span', $mark['group'], $counts, $assigned, $pre));
        }
        if ($mark['alt'] && !isset($mark['attrs']['data-edit-alt-id'])) {
            $mark['attrs']['data-edit-alt-id'] = $take($mark['attrs']['data-edit-id'] . '_alt');
        }
        if ($mark['bg'] && !isset($mark['attrs']['data-edit-bg-id'])) {
            $base = context_name_from_element($doc['nodes'][$mark['index']]) ?: $mark['group'] ?: fallback_base($tag, $counts);
            $mark['attrs']['data-edit-bg-id'] = $take($pre . $base . '.background');
        }
        if ($mark['focus'] && !isset($mark['attrs']['data-edit-focus-id'])) {
            $field = $mark['field'] === 'image' ? 'data-edit-id' : 'data-edit-bg-id';
            $mark['attrs']['data-edit-focus-id'] = $take($mark['attrs'][$field] . LE_FOCUS_ID_SUFFIX);
        }
    }
    unset($mark);

    return $marks;
}

/**
 * Neue Seiten-IDs beginnen nie mit dem Präfix einer Komponente (id_component), damit Seite und
 * Komponente sich keine ID teilen: Der Abschnitt bekommt die Nummer wie ein Duplikat
 * (unique_edit_id, header.image → header_2.image). Vorhandene IDs bleiben, wie sie sind (eine ID
 * wechselt nie); Speichern ordnet sie über die Datei der Seite zu (split_page_content).
 */
function import_page_id(string $id): string
{
    $component = id_component($id);
    return $component === null ? $id : unique_edit_id($component, [$component => true]) . substr($id, strlen($component));
}

/** Vorhandene IDs einer Markierung in der Datei (Marker → ID wie dort, ggf. ohne Präfix). */
function import_existing_ids(array $node, array $mark): array
{
    $ids = [];
    foreach (import_mark_markers($mark) as $name) {
        $existing = markup_attr($node, $name)['value'] ?? '';
        // Ein Link ohne Ziel trägt sein Textfeld als data-edit-text-id; eine vorhandene
        // data-edit-id daran (außer einer Link-ID) ist dieses Feld und bleibt.
        if ($existing === '' && $name === 'data-edit-text-id' && $mark['field'] === null) {
            $existing = markup_attr($node, 'data-edit-id')['value'] ?? '';
            if (edit_field_from_id($existing) === semantic_field('a')) {
                $existing = '';
            }
        }
        // Eine ID, die das JSON nicht als Schlüssel halten kann (z. B. kontakt:titel, sanitize_content_tree),
        // fände Speichern nie wieder: Das Element bekommt eine neue (import_assign_ids).
        if ($existing !== '' && import_id_storable($existing)) {
            $ids[$name] = $existing;
        }
    }
    return $ids;
}

/** Besteht die ID nur aus Segmenten, die sanitize_content_tree unverändert als Schlüssel übernimmt? */
function import_id_storable(string $id): bool
{
    return preg_match('/^[a-zA-Z0-9_-]+(?:\.[a-zA-Z0-9_-]+)*$/', $id) === 1;
}

/**
 * data-edit-label „<Überschrift> – <Art>[ Nr]“; Nummer nur bei mehreren derselben Art unter
 * derselben Überschrift. Felder im <head> heißen nur nach ihrer Art („Seitentitel“, „Seitenbeschreibung“).
 */
function import_assign_labels(array $marks, array $headings): array
{
    $totals = [];
    foreach ($marks as $mark) {
        if ($mark['heading'] !== null) {
            $key = $mark['heading'] . '|' . import_label_kind($mark);
            $totals[$key] = ($totals[$key] ?? 0) + 1;
        }
    }
    $seen = [];
    foreach ($marks as &$mark) {
        if (in_array($mark['tag'], IMPORT_HEAD_FIELD_TAGS, true)) {
            $mark['attrs']['data-edit-label'] = LABEL_KINDS[import_label_kind($mark)];
        }
        if ($mark['heading'] === null) {
            continue;
        }
        $kind = import_label_kind($mark);
        $key = $mark['heading'] . '|' . $kind;
        $seen[$key] = ($seen[$key] ?? 0) + 1;
        $mark['attrs']['data-edit-label'] = label_for_heading($headings[$mark['heading']], $kind, $totals[$key] > 1 ? $seen[$key] : 0);
    }
    unset($mark);

    return $marks;
}

/** Art einer Markierung (Schlüssel aus LABEL_KINDS). */
function import_label_kind(array $mark): string
{
    if ($mark['field'] === null) {
        return $mark['text'] ? 'text' : 'background';
    }
    return match (true) {
        in_array($mark['tag'], IMPORT_HEAD_FIELD_TAGS, true) => $mark['field'],
        in_array($mark['tag'], IMPORT_HEADING_TAGS, true) => 'heading',
        $mark['field'] === 'url' => 'url',
        $mark['field'] === 'image' => 'image',
        $mark['field'] === 'icon' => 'icon',
        $mark['tag'] === 'p' => 'paragraph',
        $mark['tag'] === 'li' => 'item',
        default => 'text',
    };
}

/**
 * Neue ID (ohne Präfix $pre). Gezählte Basen (link_N, block_N, …) überspringen schon vergebene
 * IDs aus $assigned; Gruppen-IDs bekommen beim Vergeben _2 (unique_edit_id).
 */
function generate_edit_id(string $tag, string $group, array &$counts, array $assigned = [], string $pre = ''): string
{
    $counted = $tag === 'a' || $group === '';
    do {
        $id = ($counted ? fallback_base($tag, $counts) : $group) . '.' . semantic_field($tag);
    } while ($counted && isset($assigned[$pre . $id]));
    return $id;
}

function unique_edit_id(string $id, array $assignedIds): string
{
    if (!isset($assignedIds[$id])) {
        return $id;
    }
    $suffix = 2;
    while (isset($assignedIds[$id . '_' . $suffix])) {
        $suffix++;
    }
    return $id . '_' . $suffix;
}

function edit_base_from_id(string $id): string
{
    $parts = explode('.', $id);
    array_pop($parts);
    return implode('.', $parts);
}

function semantic_field(string $tag): string
{
    return match (true) {
        in_array($tag, IMPORT_HEADING_TAGS, true) => 'title',
        $tag === 'a' => 'url',
        $tag === 'img' => 'image',
        $tag === 'svg' => 'icon',
        default => 'text',
    };
}

/** Name des nächsten Vorfahren mit id, class oder Strukturtag; leer ohne. */
function closest_context_name(array $doc, array $ancestors): string
{
    for ($i = count($ancestors) - 1; $i >= 0; $i--) {
        $name = context_name_from_element($doc['nodes'][$ancestors[$i]]);
        if ($name !== '') {
            return $name;
        }
    }
    return '';
}

function context_name_from_element(array $node): string
{
    $id = clean_name(import_attr_value($node, 'id'));
    if ($id !== '') {
        return $id;
    }

    foreach (preg_split('/\s+/', import_attr_value($node, 'class')) ?: [] as $class) {
        $clean = clean_name($class);
        if ($clean !== '') {
            return $clean;
        }
    }

    return in_array($node['tag'], IMPORT_STRUCTURE_TAGS, true) ? $node['tag'] : '';
}

function fallback_base(string $tag, array &$counts): string
{
    $counts[$tag] = ($counts[$tag] ?? 0) + 1;
    return match (true) {
        in_array($tag, IMPORT_HEADING_TAGS, true) => $counts[$tag] === 1 ? 'hero' : 'section_' . ($counts[$tag] - 1),
        $tag === 'a' => 'link_' . $counts[$tag],
        $tag === 'img' => $counts[$tag] === 1 ? 'hero' : 'image_' . $counts[$tag],
        default => $counts[$tag] === 1 ? 'block' : 'block_' . $counts[$tag],
    };
}

function clean_name(string $value): string
{
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9]+/', '_', $value) ?? '';
    return trim($value, '_');
}
