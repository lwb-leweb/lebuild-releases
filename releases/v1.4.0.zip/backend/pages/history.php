<?php
declare(strict_types=1);

// Verlauf der Seiten: ein Backup je Speichern mit Kurzinfo, Kürzen nach Erfolg, Einträge für die Verwaltung.

require_once LE_BACKEND . '/base/files.php';
require_once LE_BACKEND . '/base/http.php';
require_once LE_BACKEND . '/base/texts.php';
require_once LE_BACKEND . '/base/utils.php';
require_once LE_BACKEND . '/html/textMarkup.php';
require_once LE_BACKEND . '/pages/fields.php';
require_once LE_BACKEND . '/pages/labels.php';
require_once LE_BACKEND . '/pages/store.php';
require_once LE_BACKEND . '/users/auth.php';

const BACKUP_RETENTION = 15;
// Name eines Backups: Zeitpunkt in UTC (backup_timestamp liest ihn zurück, LE_BACKUP_NAME_PATTERN erwartet 14 Ziffern).
const BACKUP_STAMP_FORMAT = 'YmdHis';
// Gültiger Name eines Backups beim Wiederherstellen (le_page_restore): Zeitpunkt nach BACKUP_STAMP_FORMAT, Endung .json.
const LE_BACKUP_NAME_PATTERN = '/^[0-9]{14}\.json$/';
// So viele Namen probiert create_backup_file, bevor es aufgibt (belegt durch gleichzeitige Saves).
const BACKUP_CREATE_ATTEMPTS = 100;
// Kurzinfo neben jedem Backup <stempel>.json als <stempel>.info (JSON): wer gespeichert hat und
// welche Felder sich wie geändert haben (Verlauf). Eigene Endung, damit sie weder unter
// page_backup_files() noch unter LE_BACKUP_NAME_PATTERN fällt.
const BACKUP_INFO_EXTENSION = '.info';
// Alter und neuer Text in der Kurzinfo: Klartext, höchstens so viele Zeichen.
const BACKUP_INFO_TEXT_MAX = 80;
// Verlauf (page_history): eine Zeile je Speichern, „Heute, 14:03 – anna – Überschrift ‚Willkommen‘,
// 2 weitere Texte, 1 weiteres Bild; Fußzeile: Telefon ‚0664 123‘“ (mitgespeicherte Kopf- und
// Fußzeile mit ihrem Namen aus COMPONENT_LABELS); ohne Kurzinfo (ältere Backups) nur
// „Gespeichert“, ein Wiederherstellen beginnt mit „Wiederhergestellt: “.
const HISTORY_TEXT = [
    'separator' => ' – ',
    'saved' => 'Gespeichert',
    'restored' => 'Wiederhergestellt',
    'restoredLead' => ': ',
    'oldest' => 'Ältester gespeicherter Stand',
    'quote' => [' ‚', '‘'],
    'list' => ', ',
    'componentLead' => ': ',
    'components' => '; ',
];
// Feldarten im Verlauf: Texte zeigen ihren neuen Text („Überschrift ‚Willkommen‘“), die übrigen
// nur ihre Art und ihren Namen („Bild ‚Team – Bild 1‘“, nie einen Upload-Pfad); weitere Felder
// werden je Gruppe gezählt (Einzahl, Mehrzahl). Reihenfolge = Reihenfolge der Zählung.
const HISTORY_GROUPS = [
    'text' => ['kinds' => ['text', 'linktext', 'plain'], 'word' => null, 'more' => ['%d weiterer Text', '%d weitere Texte']],
    'alt' => ['kinds' => ['alt'], 'word' => null, 'more' => ['%d weiterer Alt-Text', '%d weitere Alt-Texte']],
    'url' => ['kinds' => ['url'], 'word' => 'Link-Ziel', 'more' => ['%d weiteres Link-Ziel', '%d weitere Link-Ziele']],
    'image' => ['kinds' => ['image', 'background'], 'word' => 'Bild', 'more' => ['%d weiteres Bild', '%d weitere Bilder']],
    'focus' => ['kinds' => ['focus'], 'word' => LABEL_KINDS['focus'], 'more' => ['%d weiterer Bildausschnitt', '%d weitere Bildausschnitte']],
    'icon' => ['kinds' => ['icon'], 'word' => 'Icon', 'more' => ['%d weiteres Icon', '%d weitere Icons']],
];

/**
 * Backup-Dateien einer Seite oder Komponente (Pfade, unsortiert); leer ohne Backups. Ohne leere Dateien: Die
 * belegt le_create_file_atomic ohne link() kurz als Platzhalter, nach einem Absturz dazwischen bleiben sie liegen.
 */
function page_backup_files(string $page): array
{
    return array_values(array_filter(glob(BACKUPS_ROOT . '/' . safe_page_name($page) . '/*.json') ?: [], 'le_backup_file_ready'));
}

/** Ist $path ein fertiges Backup (vorhanden, nicht leer, siehe page_backup_files)? */
function le_backup_file_ready(string $path): bool
{
    return is_file($path) && filesize($path) > 0;
}

/**
 * Stand zum Wiederherstellen (le_page_restore): die Seite $page aus dem Backup $backup samt der Komponenten, die das
 * Speichern dieses Eintrags mitgeschrieben hat (backup_components), Name → Inhalt. Fehlt das Backup 404 backupNotFound,
 * unlesbar 500 backupInvalid. Der Aufrufer hält lock_pages.
 */
function le_backup_entry(string $page, string $backup): array
{
    $backupPath = BACKUPS_ROOT . '/' . $page . '/' . $backup;
    if (!le_backup_file_ready($backupPath)) {
        json_response(['ok' => false, 'error' => API_TEXT['backupNotFound']], 404);
    }
    $data = le_page_json_content((string) file_get_contents($backupPath));
    if ($data === null) {
        json_response(['ok' => false, 'error' => API_TEXT['backupInvalid']], 500);
    }
    return backup_components($page, $backup) + [$page => $data];
}

/** Kurzinfo zu einer Backup-Datei (gleicher Name, Endung BACKUP_INFO_EXTENSION). */
function backup_info_path(string $backupPath): string
{
    return dirname($backupPath) . '/' . basename($backupPath, '.json') . BACKUP_INFO_EXTENSION;
}

/** Kurzinfo eines Backups; null ohne (ältere Backups) oder wenn unlesbar. */
function read_backup_info(string $backupPath): ?array
{
    $path = backup_info_path($backupPath);
    $data = is_file($path) ? json_decode((string) file_get_contents($path), true) : null;
    return is_array($data) && is_array($data['fields'] ?? null) ? $data : null;
}

/**
 * Kurzinfo zum Speichern einer Seite oder Komponente von $old auf $new: $user, sonst der angemeldete
 * Benutzer, und je geändertem Feld ID, Feldart ($kinds, sonst nach der ID), Name (wie im Editor,
 * backend/pages/labels.php, aus $doc oder der Quelldatei), alter und neuer Text gekürzt.
 */
function backup_info(string $name, array $old, array $new, array $kinds, ?array $doc, bool $restored, ?string $user = null): array
{
    $before = flatten_content($old);
    $after = flatten_content($new);
    $labels = null;
    $fields = [];
    foreach (array_keys($after + $before) as $id) {
        $id = (string) $id;
        $oldValue = (string) ($before[$id] ?? '');
        $newValue = (string) ($after[$id] ?? '');
        if ($oldValue === $newValue) {
            continue;
        }
        $labels ??= page_label_table($name, $doc ?? page_source_doc($name));
        $kind = $kinds[$id] ?? field_kind($id);
        $fields[] = [
            'id' => $id,
            'kind' => $kind,
            'label' => label_for_id($labels, field_id_prefix($name) . $id, $name),
            'old' => text_excerpt(field_plain_text($kind, $oldValue), BACKUP_INFO_TEXT_MAX),
            'new' => text_excerpt(field_plain_text($kind, $newValue), BACKUP_INFO_TEXT_MAX),
        ];
    }
    return ['user' => $user ?? current_user()['username'] ?? null, 'restored' => $restored, 'fields' => $fields];
}

/**
 * Legt das Backup einer Seite oder Komponente mit Inhalt $data an und liefert seinen Pfad. Name =
 * Zeitpunkt (BACKUP_STAMP_FORMAT, UTC): jetzt, mindestens aber eine Sekunde nach dem neuesten
 * vorhandenen, damit das neueste das neueste bleibt (viele Saves je Sekunde, Uhr zurückgesprungen).
 * Exklusiv und atomar angelegt (le_create_file_atomic): auch gleichzeitige Saves überschreiben nie ein Backup, ein
 * belegter Name rückt eine Sekunde weiter, ein Abbruch hinterlässt kein halbes.
 */
function create_backup_file(string $page, string $data): string
{
    $dir = BACKUPS_ROOT . '/' . safe_page_name($page);
    ensure_dir($dir);
    $time = time();
    foreach (page_backup_files($page) as $file) {
        $time = max($time, (backup_timestamp($file) ?? 0) + 1);
    }
    for ($attempt = 0; $attempt < BACKUP_CREATE_ATTEMPTS; $attempt++, $time++) {
        $path = $dir . '/' . gmdate(BACKUP_STAMP_FORMAT, $time) . '.json';
        try {
            if (le_create_file_atomic($path, $data)) {
                return $path;
            }
        } catch (RuntimeException $e) {
            break;
        }
    }
    json_response(['ok' => false, 'error' => API_TEXT['backupFailed']], 500);
}

function prune_backups(string $page, int $keep = BACKUP_RETENTION): void
{
    $files = page_backup_files($page);
    if (count($files) <= $keep) {
        return;
    }
    rsort($files);
    foreach (array_slice($files, $keep) as $old) {
        @unlink($old);
        @unlink(backup_info_path($old));
    }
}

/**
 * Komponenten, die „Diesen Stand wiederherstellen“ mit dem Backup $backup (Name wie im Verlauf,
 * page_history) einer Seite mit zurücksetzt, Name → Inhalt: Ein Eintrag stellt den Stand nach
 * seinem Speichern her, also die Komponenten dieses Speicherns aus der Kurzinfo des Backups davor
 * ('after'); der älteste Stand den vor dem ältesten Speichern ('before' aus dessen Kurzinfo).
 * Leer für Kurzinfos ohne Zuordnung (ältere Backups) und unbekannte Backups.
 */
function backup_components(string $page, string $backup): array
{
    $files = page_backup_files($page);
    sort($files);
    $at = array_search($backup, array_map('basename', $files), true);
    if (!is_int($at)) {
        return [];
    }
    return $at > 0 ? info_components(read_backup_info($files[$at - 1]), 'after') : info_components(read_backup_info($files[$at]), 'before');
}

/** Komponenten einer Kurzinfo im Zustand $state ('before' oder 'after'): Name → Inhalt; leer ohne Zuordnung. */
function info_components(?array $info, string $state): array
{
    $components = [];
    foreach (is_array($info['components'] ?? null) ? $info['components'] : [] as $name => $states) {
        if (isset(shared_components()[$name]) && is_array($states[$state] ?? null)) {
            $components[$name] = $states[$state];
        }
    }
    return $components;
}

/** Zeitpunkt eines Backups aus seinem Namen (YmdHis, UTC); null bei fremden Namen. */
function backup_timestamp(string $backupPath): ?int
{
    $time = DateTimeImmutable::createFromFormat('!' . BACKUP_STAMP_FORMAT, basename($backupPath, '.json'), new DateTimeZone('UTC'));
    return $time === false ? null : $time->getTimestamp();
}

/** Gruppe einer Feldart im Verlauf (HISTORY_GROUPS); ohne Art (alte Kurzinfo) die erste, Text. */
function history_group(string $kind): string
{
    foreach (HISTORY_GROUPS as $group => $spec) {
        if (in_array($kind, $spec['kinds'], true)) {
            return $group;
        }
    }
    return array_key_first(HISTORY_GROUPS);
}

/**
 * Zusammenfassung einer Kurzinfo: je Seite und mitgespeicherter Komponente (Feld 'component',
 * save_page_group) ihre Felder (history_fields_summary), Komponenten mit ihrem Namen davor;
 * ein Wiederherstellen ist als solches gekennzeichnet.
 */
function backup_info_summary(?array $info): string
{
    $fields = $info['fields'] ?? [];
    $restored = !empty($info['restored']);
    if ($fields === []) {
        return $restored ? HISTORY_TEXT['restored'] : HISTORY_TEXT['saved'];
    }
    $groups = [];
    foreach ($fields as $field) {
        $groups[(string) ($field['component'] ?? '')][] = $field;
    }
    $parts = [];
    foreach ($groups as $component => $groupFields) {
        // Ein Name aus der ID nennt die Komponente schon („Kopfzeile Logo: Alt-Text“, label_from_id).
        $summary = history_fields_summary($groupFields);
        $name = COMPONENT_LABELS[$component] ?? $component;
        $parts[] = $component === '' || str_starts_with($summary, $name) ? $summary : $name . HISTORY_TEXT['componentLead'] . $summary;
    }
    return ($restored ? HISTORY_TEXT['restored'] . HISTORY_TEXT['restoredLead'] : '') . implode(HISTORY_TEXT['components'], $parts);
}

/** Felder einer Kurzinfo: erstes Feld (Text mit neuem Text, sonst Art und Name), dazu die Zahl der übrigen je Gruppe. */
function history_fields_summary(array $fields): string
{
    [$open, $close] = HISTORY_TEXT['quote'];
    $label = (string) ($fields[0]['label'] ?? '');
    $text = (string) ($fields[0]['new'] ?? '');
    $word = HISTORY_GROUPS[history_group((string) ($fields[0]['kind'] ?? ''))]['word'];
    $parts = [match (true) {
        $word !== null => $word . $open . $label . $close,
        $text !== '' => $label . $open . $text . $close,
        default => $label,
    }];
    $counts = array_fill_keys(array_keys(HISTORY_GROUPS), 0);
    foreach (array_slice($fields, 1) as $field) {
        $counts[history_group((string) ($field['kind'] ?? ''))]++;
    }
    foreach ($counts as $group => $count) {
        if ($count > 0) {
            $parts[] = sprintf(HISTORY_GROUPS[$group]['more'][$count === 1 ? 0 : 1], $count);
        }
    }
    return implode(HISTORY_TEXT['list'], $parts);
}

/** Namen der Komponenten (COMPONENT_LABELS) zu Name → Inhalt, in deren Reihenfolge. */
function component_labels(array $components): array
{
    return array_values(array_intersect_key(COMPONENT_LABELS, $components));
}

/**
 * Verlauf einer Seite (api/listBackups.php), neuester Eintrag zuerst. Ein Eintrag je Speichern
 * (Backup samt Kurzinfo): Zeit, Benutzer, geänderte Felder, die fertige Zeile (text) und die
 * Namen der Komponenten, die „Diesen Stand wiederherstellen“ auf allen Seiten mit zurücksetzt
 * (components, wie backup_components; der Seiten-Editor fragt dann nach).
 * „Diesen Stand wiederherstellen“ meint den Stand nach diesem Speichern, das ist das nächste
 * Backup ('backup'); beim neuesten ist es der aktuelle Stand ('backup' null). Den Stand vor dem
 * ältesten Speichern gibt es als letzten Eintrag ohne Zeit. Zeiten in der App-Zeitzone (day_time_label).
 */
function page_history(string $page, int $now): array
{
    $files = page_backup_files($page);
    sort($files);
    $entries = [];
    foreach ($files as $i => $file) {
        $info = read_backup_info($file);
        if ($i === 0) {
            $entries[] = ['backup' => basename($file), 'time' => null, 'user' => null, 'fields' => [], 'text' => HISTORY_TEXT['oldest'], 'components' => component_labels(info_components($info, 'before'))];
        }
        $time = backup_timestamp($file);
        $parts = $time === null ? [] : [ucfirst(day_time_label($time, $now))];
        if (($info['user'] ?? null) !== null) {
            $parts[] = (string) $info['user'];
        }
        $parts[] = backup_info_summary($info);
        $entries[] = [
            'backup' => isset($files[$i + 1]) ? basename($files[$i + 1]) : null,
            'time' => $time === null ? null : gmdate('Y-m-d\TH:i:s\Z', $time),
            'user' => $info['user'] ?? null,
            'fields' => $info['fields'] ?? [],
            'text' => implode(HISTORY_TEXT['separator'], $parts),
            'components' => isset($files[$i + 1]) ? component_labels(info_components($info, 'after')) : [],
        ];
    }
    return array_reverse($entries);
}

/**
 * Snapshot a source file to /content/originals/<base>.<timestamp>.<ext>
 * before any rewrite, so a half-written PHP file can be recovered (<base>: snapshot_name_parts).
 * $prune false: alte Snapshots räumt der Aufrufer erst nach Erfolg weg (prune_file_snapshots).
 */
function snapshot_original_file(string $file, bool $prune = true): void
{
    if (!is_file($file)) {
        return;
    }
    ensure_dir(ORIGINALS_ROOT);
    [$base, $ext] = snapshot_name_parts($file);
    $snapshot = ORIGINALS_ROOT . '/' . $base . '.' . gmdate('YmdHis') . $ext;
    @copy($file, $snapshot);
    if ($prune) {
        prune_original_snapshots($base, $ext);
    }
}

// Steht in Snapshot-Namen für „/“ des Pfads unter LE_SITE_ROOT; kommt in Seitennamen nie vor (is_safe_page_name).
const LE_SNAPSHOT_DIR_SEPARATOR = '~';

/**
 * Name und Endung (mit Punkt) der Snapshots einer Datei. Der Name ist der Pfad unter LE_SITE_ROOT ohne Endung, „/“ als
 * LE_SNAPSHOT_DIR_SEPARATOR: Seiten heißen wie bisher (index), Komponenten in Unterordnern bekommen den Ordner dazu
 * (includes~navigation) und teilen sich so nie Namen und Kürzen mit einer gleichnamigen Seite.
 */
function snapshot_name_parts(string $file): array
{
    $info = pathinfo($file);
    $base = $info['filename'] ?? basename($file);
    if (le_path_in($file, [LE_SITE_ROOT]) && ($dir = dirname(substr($file, strlen(LE_SITE_ROOT) + 1))) !== '.') {
        $base = str_replace('/', LE_SNAPSHOT_DIR_SEPARATOR, $dir) . LE_SNAPSHOT_DIR_SEPARATOR . $base;
    }
    return [$base, isset($info['extension']) && $info['extension'] !== '' ? '.' . $info['extension'] : ''];
}

function prune_file_snapshots(string $file): void
{
    prune_original_snapshots(...snapshot_name_parts($file));
}

function prune_original_snapshots(string $base, string $ext, int $keep = BACKUP_RETENTION): void
{
    $pattern = ORIGINALS_ROOT . '/' . $base . '.*' . $ext;
    $files = glob($pattern) ?: [];
    $stamped = [];
    foreach ($files as $f) {
        if (preg_match('/\.\d{14}' . preg_quote($ext, '/') . '$/', $f)) {
            $stamped[] = $f;
        }
    }
    if (count($stamped) <= $keep) {
        return;
    }
    rsort($stamped);
    foreach (array_slice($stamped, $keep) as $old) {
        @unlink($old);
    }
}
