<?php
declare(strict_types=1);

// Dateien und Ordner für jedes Thema: atomar schreiben mit Antwort bei Fehlern, Schreibrechte prüfen, Sperren über einen
// Pfad, Ordner löschen, Reihenfolge am Prozessende, Pfad der Zugangsdaten und das Update-Log. Kein Thema lädt dafür den
// Updater oder den Seitenspeicher.

require_once LE_BACKEND . '/base/utils.php';
require_once LE_BACKEND . '/base/http.php';
require_once LE_BACKEND . '/base/texts.php';

// Update-Log (updater_log_path): Der Updater schreibt hinein. So weit zurück (Bytes vom Ende) prüft
// updater_log_once() auf Wiederholungen.
const UPDATER_LOG_REPEAT_WINDOW_BYTES = 4096;

/**
 * Sperre auf die Datei $path (flock, exklusiv); ohne $wait sofort null, wenn sie belegt ist, sonst wartet sie. null
 * auch, wenn sich die Datei nicht öffnen lässt. Frei mit store_unlock(), spätestens am Ende des Requests.
 */
function le_lock_file(string $path, bool $wait = false)
{
    ensure_dir(CACHE_ROOT);
    // c+: der Datenumzug liest seine Notiz aus der gehaltenen Sperrdatei.
    $fh = @fopen($path, 'c+');
    if (!$fh) {
        return null;
    }
    if (!flock($fh, $wait ? LOCK_EX : LOCK_EX | LOCK_NB)) {
        fclose($fh);
        return null;
    }
    return $fh;
}

function updater_log_path(): string
{
    return CACHE_ROOT . '/update-log.txt';
}

function updater_log(string $message): void
{
    @file_put_contents(
        updater_log_path(),
        '[' . current_iso_time() . '] ' . $message . PHP_EOL,
        FILE_APPEND
    );
}

/**
 * Wie updater_log(), aber ohne Wiederholung: Steht dieselbe Meldung schon im
 * Ende des Logs, entfällt sie. Für Fehler, die sonst jeder Request meldet.
 */
function updater_log_once(string $message): void
{
    $path = updater_log_path();
    $size = is_file($path) ? (int) filesize($path) : 0;
    $offset = max(0, $size - UPDATER_LOG_REPEAT_WINDOW_BYTES);
    $tail = $size > 0 ? (string) @file_get_contents($path, false, null, $offset) : '';
    if (!str_contains($tail, '] ' . $message . PHP_EOL)) {
        updater_log($message);
    }
}

/** Pfad einer Zugangsdaten-Datei unter private/config/. */
function le_config_path(string $file): string
{
    return CONFIG_ROOT . '/' . $file;
}

/**
 * Ob le_rrmdir($path) durchgehen kann: nichts da, oder der Ordner darüber beschreibbar und jeder Ordner darin lesbar,
 * beschreibbar und durchsuchbar (ein Link zählt als Datei). Zum Prüfen, bevor etwas Unumkehrbares passiert.
 */
function le_rrmdir_possible(string $path): bool
{
    clearstatcache();
    if (!file_exists($path) && !is_link($path)) {
        return true;
    }
    if (!is_writable(dirname($path))) {
        return false;
    }
    if (is_link($path) || !is_dir($path)) {
        return true;
    }
    if (!is_readable($path) || !is_writable($path) || !is_executable($path)) {
        return false;
    }
    foreach (dir_entries($path) as $entry) {
        if (!le_rrmdir_possible($path . '/' . $entry)) {
            return false;
        }
    }
    return true;
}

function le_rrmdir(string $path): bool
{
    if (is_link($path) || is_file($path)) {
        return @unlink($path);
    }
    if (!is_dir($path)) {
        return true;
    }
    $entries = scandir($path) ?: [];
    foreach ($entries as $entry) {
        if ($entry === '.' || $entry === '..') {
            continue;
        }
        le_rrmdir($path . '/' . $entry);
    }
    return @rmdir($path);
}

/**
 * write_file_atomic für Seiten, Komponenten und ihre JSON: Scheitert es, bleibt die Datei, wie sie
 * war, und die Antwort ist 500 ohne Dateinamen (nur das Fehlerprotokoll nennt den Pfad).
 */
function atomic_write(string $path, string $content): void
{
    if (!le_atomic_write($path, $content)) {
        json_response(['ok' => false, 'error' => write_failed_message()], 500);
    }
}

/** atomic_write ohne Antwort an den Browser: false (Pfad im Fehlerprotokoll), wenn es nicht geht, z. B. für Aufräumen nebenher; $private wie bei write_file_atomic. */
function le_atomic_write(string $path, string $content, bool $private = false): bool
{
    try {
        write_file_atomic($path, $content, $private);
    } catch (RuntimeException $e) {
        error_log('atomic_write failed: ' . $path);
        return false;
    }
    return true;
}

/** Meldung, wenn der Server nicht schreiben lässt: ohne Datei- und Ordnernamen; $labels: betroffene Namen wie im Editor („Fußzeile“, „diese Seite“). */
function write_failed_message(array $labels = []): string
{
    $names = $labels === [] ? '' : sprintf(API_TEXT['writeFailedNames'], implode(', ', $labels));
    return sprintf(API_TEXT['writeFailed'], $names) . ' ' . API_TEXT['contactSupport'];
}

/** Lässt sich die Datei anlegen bzw. ersetzen (Ordner und eine vorhandene Datei beschreibbar)? */
function path_writable(string $path): bool
{
    clearstatcache(true, $path);
    return is_writable(dirname($path)) && (!file_exists($path) || is_writable($path));
}

/**
 * $fn am Ende des Prozesses nach allen anderen Shutdown-Funktionen (Rücknahme beim Speichern, plans_restore_point):
 * Eine während des Shutdowns registrierte Funktion läuft nach allen schon registrierten.
 */
function le_after_shutdown(callable $fn): void
{
    register_shutdown_function(static function () use ($fn): void {
        register_shutdown_function($fn);
    });
}

// Rechte für Dateien mit Geheimnissen (Zugangsdaten, Schlüssel, Benutzer, SQLite).
const PRIVATE_FILE_MODE = 0600;

function ensure_dir(string $path): void
{
    if (!is_dir($path) && !mkdir($path, 0775, true) && !is_dir($path)) {
        throw new RuntimeException('Cannot create directory: ' . $path);
    }
}

// Sperr-.htaccess im Ordner der privaten Daten (le_private_prepare): Apache antwortet dort 403, auch wenn die Weiterleitung
// an den Router ausfällt (RewriteEngine Off in einer .htaccess darüber oder darin). RedirectMatch (mod_alias) statt Require:
// Es braucht nur AllowOverride FileInfo, das der Router ohnehin braucht (Rewrite); Require bräuchte AuthConfig und gäbe
// bei Hostern ohne das 500. Ohne IfModule: Fehlt mod_alias oder ist FileInfo nicht erlaubt, lieber 500 als offen.
// Caddy und der Mehrfachbetrieb brauchen sie nicht, stören tut sie dort nicht. Die Systemprüfung private_htaccess
// vergleicht die Anweisungen der Datei (ohne Kommentare, le_private_htaccess_rules) mit LE_PRIVATE_HTACCESS_RULES.
const LE_PRIVATE_HTACCESS_FILE = CONTENT_ROOT . '/.htaccess';
const LE_PRIVATE_HTACCESS_RULES = "RedirectMatch 403 ^\n";
const LE_PRIVATE_HTACCESS = "# Von LeBuild angelegt. private/ ist nie per Adresse abrufbar, auch ohne mod_rewrite.\n" . LE_PRIVATE_HTACCESS_RULES;
// Anweisungen früherer Fassungen von LeBuild (content/.htaccess, kommt so aus alten Sicherungen): le_private_prepare ersetzt
// sie durch LE_PRIVATE_HTACCESS, da Require ohne AllowOverride AuthConfig 500 gibt.
const LE_PRIVATE_HTACCESS_OLD_RULES = [
    "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder deny,allow\nDeny from all\n</IfModule>\n",
];

/** Anweisungen einer .htaccess ohne Kommentare, Leerzeilen, Einrückung und Zeilenenden, je Zeile mit "\n". */
function le_private_htaccess_rules(string $content): string
{
    $rules = array_filter(array_map('trim', preg_split('/\R/', $content) ?: []), static fn (string $line): bool => $line !== '' && $line[0] !== '#');

    return implode('', array_map(static fn (string $line): string => $line . "\n", $rules));
}

/**
 * Ordner der privaten Daten samt LE_PRIVATE_HTACCESS anlegen (prepare_storage, ops/tools/sites.php new); eine vorhandene
 * .htaccess bleibt, wie sie ist, außer einer früheren Fassung von LeBuild (LE_PRIVATE_HTACCESS_OLD_RULES). Scheitert das
 * Schreiben, still wie bei den Uploads (le_uploads_prepare): Der nächste Anlass versucht es wieder, die Systemprüfung meldet es.
 */
function le_private_prepare(): void
{
    ensure_dir(CONTENT_ROOT);
    $current = is_file(LE_PRIVATE_HTACCESS_FILE) ? @file_get_contents(LE_PRIVATE_HTACCESS_FILE) : null;
    if ($current === null || ($current !== false && in_array(le_private_htaccess_rules($current), LE_PRIVATE_HTACCESS_OLD_RULES, true))) {
        try {
            write_file_atomic(LE_PRIVATE_HTACCESS_FILE, LE_PRIVATE_HTACCESS);
        } catch (RuntimeException) {
            // Wie bei den Uploads still; die Systemprüfung (private_htaccess) meldet die fehlende Datei.
        }
    }
}

/**
 * Nach dem Schreiben einer Datei: OPcache vergisst ihre übersetzte Fassung, damit der nächste Aufruf
 * die neue ausführt. Seiten, Kopf-/Fußzeile und Konfigurationen sind PHP; Hoster prüfen die
 * Zeitstempel oft selten oder nie (opcache.validate_timestamps=0). Ohne OPcache tut es nichts.
 */
function forget_compiled_file(string $path): void
{
    if (function_exists('opcache_invalidate')) {
        @opcache_invalidate($path, true);
    }
}

/** forget_compiled_file für eine Datei bzw. alle PHP-Dateien eines Ordners (Auto-Update tauscht ganze Ordner). */
function forget_compiled_tree(string $path): void
{
    if (!is_dir($path)) {
        forget_compiled_file($path);
        return;
    }
    foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS)) as $file) {
        if ($file->isFile() && strtolower($file->getExtension()) === 'php') {
            forget_compiled_file($file->getPathname());
        }
    }
}

/** Rechte einer neuen, nicht privaten Datei: wie von file_put_contents, 0666 ohne umask (write_file_atomic, Einspielen einer Sicherung). */
function le_new_file_mode(): int
{
    return 0666 & ~umask();
}

// Temp-Datei von write_file_atomic: <name>.tmp.<zufall> neben dem Ziel (nie ins Repo eines Kundenordners, ops/tools/sites.php).
const LE_ATOMIC_TMP_INFIX = '.tmp.';

/**
 * Schreibt atomar: Temp-Datei mit eindeutigem Namen im selben Ordner, dann rename. Gleichzeitige
 * Schreiber kommen sich so nie in die Quere, Leser sehen den alten oder den neuen Stand. Eine
 * vorhandene Datei behält ihre Rechte, eine neue bekommt le_new_file_mode() (tempnam legt 0600 an,
 * das sperrte z. B. Git als anderer Benutzer der Gruppe aus); $private oder ein Pfad aus
 * LE_PRIVATE_DATA (le_private_data, dieselbe Liste wie beim Einspielen einer Sicherung): immer
 * PRIVATE_FILE_MODE, der Inhalt ist nie mit anderen Rechten lesbar. Scheitert es, bleibt die Datei, wie sie war, und
 * es fliegt eine RuntimeException (nur mit dem Dateinamen). Für Lesen → Ändern → Schreiben hält
 * der Aufrufer dazu store_lock(). Ist $path ein Symlink, wird atomar ins Ziel geschrieben und der Link bleibt.
 */
function write_file_atomic(string $path, string $content, bool $private = false): void
{
    $private = $private || le_private_data($path);
    $link = null;
    if (is_link($path) && ($real = realpath($path)) !== false) {
        [$link, $path] = [$path, $real];
    }
    $dir = dirname($path);
    ensure_dir($dir);

    // tempnam weicht ohne Schreibrecht auf den System-Temp-Ordner aus; es liefert den aufgelösten
    // Pfad, deshalb realpath (Ablage oder Website hinter einem Symlink).
    $tmp = @tempnam($dir, basename($path) . LE_ATOMIC_TMP_INFIX);
    $written = $tmp !== false && realpath(dirname($tmp)) === realpath($dir)
        && (!$private || @chmod($tmp, PRIVATE_FILE_MODE))
        && @file_put_contents($tmp, $content, LOCK_EX) !== false;
    if ($written && !$private) {
        @chmod($tmp, is_file($path) ? fileperms($path) & 0777 : le_new_file_mode());
    }
    if (!$written || !@rename($tmp, $path)) {
        if ($tmp !== false) {
            @unlink($tmp);
        }
        throw new RuntimeException('Cannot write ' . basename($link ?? $path));
    }
    forget_compiled_file($path);
    if ($link !== null) {
        forget_compiled_file($link);
    }
}

/**
 * Schreibt eine Datei atomar und nur für den Eigentümer lesbar (PRIVATE_FILE_MODE). Unter private/ außerhalb von
 * LE_PRIVATE_DATA nur, was nicht in die Sicherung kommt (private/cache/, Aktivitäts-Log): Das Einspielen einer
 * Sicherung gäbe einer solchen Datei die Rechte neuer Dateien. Pfade aus der Liste schreibt write_file_atomic
 * ohnehin privat.
 */
function write_private_file(string $path, string $content): void
{
    write_file_atomic($path, $content, true);
}

/**
 * Legt $path nur an, wenn es ihn noch nicht gibt (wie fopen 'x'), aber atomar: erst eine vollständige Temp-Datei
 * (write_file_atomic, Rechte wie dort), dann link(), das bei einem belegten Namen scheitert statt zu überschreiben.
 * Ohne link() (disable_functions auf Shared Hosting, Dateisystem ohne Hardlinks) belegt fopen 'x' den Namen mit
 * einer leeren Datei, die rename dann ersetzt; stirbt der Prozess dazwischen, bleibt sie leer liegen (Leser von
 * Backups überspringen leere, le_backup_file_ready). Unter $path steht nie eine halbe Datei, die Temp-Datei räumt
 * jeder Fehlerweg weg (nur ein Absturz lässt sie liegen). false, wenn der Name belegt ist; scheitert das Schreiben, RuntimeException.
 */
function le_create_file_atomic(string $path, string $content): bool
{
    $tmp = $path . LE_ATOMIC_TMP_INFIX . bin2hex(random_bytes(4));
    write_file_atomic($tmp, $content);
    $linked = function_exists('link') && @link($tmp, $path);
    clearstatcache(true, $path);
    if ($linked || file_exists($path)) {
        @unlink($tmp);
        return $linked;
    }
    $claim = @fopen($path, 'x');
    if ($claim === false) {
        @unlink($tmp);
        clearstatcache(true, $path);
        if (file_exists($path)) {
            return false;
        }
        throw new RuntimeException('Cannot write ' . basename($path));
    }
    fclose($claim);
    // Ersetzt nur die eben selbst angelegte leere Datei.
    if (!@rename($tmp, $path)) {
        @unlink($tmp);
        @unlink($path);
        throw new RuntimeException('Cannot write ' . basename($path));
    }
    return true;
}

/**
 * Sperre für Lesen → Ändern → Schreiben einer kleinen Datei (users.json, config.json,
 * active-plugins.json, …): flock auf private/cache/<name>.lock, wartet auf laufende. Frei mit
 * store_unlock(), spätestens am Ende des Requests. Nie verschachtelt für denselben Namen.
 * $dir statt private/cache/: Sperre außerhalb einer Website (ops/tools/sites.php, domains.json).
 */
function store_lock(string $name, ?string $dir = null)
{
    $dir ??= CACHE_ROOT;
    ensure_dir($dir);
    $handle = @fopen($dir . '/' . $name . '.lock', 'c');
    if ($handle === false || !flock($handle, LOCK_EX)) {
        throw new RuntimeException('Cannot lock ' . $name);
    }
    return $handle;
}

function store_unlock($handle): void
{
    flock($handle, LOCK_UN);
    fclose($handle);
}

/**
 * store_lock($name) bis zum Ende der Anfrage, auch über die Shutdown-Funktionen (IndexNow) hinweg: Lesen → Ändern →
 * Schreiben im Kern, das mit json_response abbrechen kann. Eine Sperre in einer lokalen Variablen fiele dabei schon vor
 * dem Shutdown (exit räumt die Variablen der Funktionen ab), hier hält sie ein Static wie früher die globale Variable
 * des Endpunkts. Ein zweiter Aufruf für denselben Namen nimmt die schon gehaltene.
 */
function le_store_lock_until_end(string $name): void
{
    $held = &le_store_locks_until_end();
    $held[$name] ??= store_lock($name);
}

/**
 * Sperre aus le_store_lock_until_end vorzeitig freigeben, wenn die Arbeit darunter gelungen ist: Danach braucht sie
 * niemand mehr, und Shutdown-Funktionen, die andere Sperren nehmen (IndexNow), hielten sie sonst mit.
 */
function le_store_unlock_until_end(string $name): void
{
    $held = &le_store_locks_until_end();
    if (isset($held[$name])) {
        store_unlock($held[$name]);
        unset($held[$name]);
    }
}

/** Die Sperren, die le_store_lock_until_end hält: [Name => Handle]. */
function &le_store_locks_until_end(): array
{
    static $held = [];
    return $held;
}

/**
 * $work unter store_lock($name), aber nur für seine Dauer; hält die Anfrage die Sperre schon (le_store_lock_until_end,
 * etwa beim Aktivieren eines Plugins), läuft $work unter ihr, statt auf sich selbst zu warten. Liefert sein Ergebnis.
 */
function le_store_lock_during(string $name, callable $work): mixed
{
    if (isset(le_store_locks_until_end()[$name])) {
        return $work();
    }
    $lock = store_lock($name);
    try {
        return $work();
    } finally {
        store_unlock($lock);
    }
}

/** Namen der Einträge eines Ordners (ohne . und ..); leer, wenn es ihn nicht gibt. */
function dir_entries(string $dir): array
{
    return is_dir($dir) ? array_values(array_diff(scandir($dir) ?: [], ['.', '..'])) : [];
}

/** Darf ein ZIP-Eintrag so entpackt werden (kein Ausbruch aus dem Zielordner)? */
function zip_entry_name_safe(string $name): bool
{
    if ($name === '' || str_contains($name, '\\') || str_contains($name, ':')) {
        return false;
    }
    // Nur ganze Pfad-Segmente zählen: „wien..jpg“ ist ein gültiger Dateiname.
    // Ein Schrägstrich am Ende kennzeichnet einen Ordner-Eintrag.
    return !array_intersect(explode('/', rtrim($name, '/')), ['..', '.', '']);
}

// Erst hier stehen write_file_atomic und seine Konstanten bereit (backend/base/instance.php läuft ganz am Anfang).
le_instance_note_live();
