<?php
declare(strict_types=1);

// Antworten an Besucher: Dateien mit Typ, Cache-Dauer und Range, Uploads, Texte, Weiterleitungen, 404, 503.

require_once LE_BACKEND . '/base/http.php';
require_once LE_BACKEND . '/base/texts.php';
require_once LE_BACKEND . '/media/uploads.php';
require_once LE_BACKEND . '/site/assetVersion.php';
require_once LE_BACKEND . '/users/setup.php';
require_once LE_BACKEND . '/users/users.php';

// Wie lange Browser Dateien der Website behalten dürfen (Sekunden), danach fragen sie mit ETag nach (304):
// Stylesheets und Skripte kurz (sie ändern sich unter demselben Namen), Bilder, Schriften und Videos eine Woche,
// Uploads einen Monat (bei jedem Hochladen ein neuer Name), robots.txt und sitemap.xml eine Stunde.
const LE_STATIC_MAX_AGE = ['code' => 3600, 'media' => 604800, 'upload' => 2592000, 'text' => 3600];
const LE_STATIC_MEDIA_EXTENSIONS = ['png', 'jpg', 'jpeg', 'gif', 'webp', 'avif', 'svg', 'ico', 'woff', 'woff2', 'ttf', 'otf', 'eot', 'mp4', 'webm', 'pdf'];
// Typ je Endung für le_serve_static_file (andere Dateien der Website gehen als application/octet-stream raus). Aus den
// Code-Ordnern (Verwaltung, assets/ und admin/ der Plugins) liefert der Router nur Dateien mit diesen Endungen aus.
const LE_STATIC_MIME_TYPES = [
    'html'  => 'text/html; charset=utf-8',
    'css'   => 'text/css; charset=utf-8',
    'js'    => 'application/javascript; charset=utf-8',
    'mjs'   => 'application/javascript; charset=utf-8',
    'map'   => 'application/json; charset=utf-8',
    'json'  => 'application/json; charset=utf-8',
    'xml'   => 'application/xml; charset=utf-8',
    'txt'   => 'text/plain; charset=utf-8',
    'svg'   => 'image/svg+xml',
    'png'   => 'image/png',
    'jpg'   => 'image/jpeg',
    'jpeg'  => 'image/jpeg',
    'gif'   => 'image/gif',
    'webp'  => 'image/webp',
    'avif'  => 'image/avif',
    'ico'   => 'image/x-icon',
    'woff'  => 'font/woff',
    'woff2' => 'font/woff2',
    'ttf'   => 'font/ttf',
    'eot'   => 'application/vnd.ms-fontobject',
    'otf'   => 'font/otf',
    'pdf'   => 'application/pdf',
    'mp4'   => 'video/mp4',
    'webm'  => 'video/webm',
];

/** Wie lange der Browser die Datei $file der Website behalten darf (LE_STATIC_MAX_AGE). */
function le_static_max_age(string $file): int
{
    return in_array(strtolower(pathinfo($file, PATHINFO_EXTENSION)), LE_STATIC_MEDIA_EXTENSIONS, true) ? LE_STATIC_MAX_AGE['media'] : LE_STATIC_MAX_AGE['code'];
}

function le_respond_not_found(): bool
{
    http_response_code(404);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Not Found';
    return true;
}

// Adresse ohne Datei, die einem Plugin mit fehlgeschlagenem Schema gehören könnte (PLUGIN_SITE_PAGE_UNAVAILABLE).
const LE_SITE_UNAVAILABLE_TEXT = 'Diese Seite ist gerade nicht verfügbar. Bitte später noch einmal versuchen.';

/** 503 mit LE_SITE_UNAVAILABLE_TEXT, ohne Cache: Sobald das Schema nachgezogen ist, gibt es die Seite wieder. */
function le_respond_unavailable(): bool
{
    http_response_code(503);
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: no-store');
    echo LE_SITE_UNAVAILABLE_TEXT;
    return true;
}

function le_respond_text(string $text, string $type): bool
{
    header('Content-Type: ' . $type);
    header('Cache-Control: public, max-age=' . LE_STATIC_MAX_AGE['text']);
    echo $text;
    return true;
}

/**
 * Login-Seite mit dem Hinweis API_TEXT['setupMissing'] an Stelle der Formulare (zwischen
 * LE_LOGIN_FORMS_START und LE_LOGIN_FORMS_END); ohne die Markierungen nur der Hinweis.
 */
function le_respond_login_setup(string $file): bool
{
    $html = (string) file_get_contents($file);
    $hint = '<div class="panel"><h1>LeBuild</h1><p>'
        . htmlspecialchars(sprintf(API_TEXT['setupMissing'], PASSWORD_MIN_LENGTH, PASSWORD_MAX_LENGTH), ENT_QUOTES, 'UTF-8') . '</p></div>';
    $start = strpos($html, LE_LOGIN_FORMS_START);
    $end = strpos($html, LE_LOGIN_FORMS_END);
    $html = $start !== false && $end !== false && $end > $start
        ? substr($html, 0, $start) . $hint . substr($html, $end + strlen(LE_LOGIN_FORMS_END))
        : $hint;

    header('Content-Type: text/html; charset=utf-8');
    echo $html;
    return true;
}

/**
 * Login, Verwaltung und Seiten mit Editor nur von dieser Website einbetten lassen (Clickjacking);
 * die Seitenansicht der Verwaltung zeigt die Website im iframe desselben Origins.
 * Öffentliche Seiten ohne Editor bleiben einbettbar.
 */
function le_deny_foreign_framing(): void
{
    header("Content-Security-Policy: frame-ancestors 'self'");
    header('X-Frame-Options: SAMEORIGIN');
}

function le_respond_redirect(string $location): bool
{
    header('Cache-Control: no-store');
    header('Location: ' . $location, true, 302);
    return true;
}

/**
 * Datei $rel unter einem Code-Ordner $dir (Verwaltung, assets/ und admin/ eines Plugins), wie der Router sie ausliefert:
 * erlaubte Zeichen (LE_SITE_PATH_PATTERN, kein „..“) und eine Endung aus LE_STATIC_MIME_TYPES, also nie PHP, SQL oder
 * Doku; null sonst oder ohne Datei. Punkt-Stücke weist der Router vorher ab.
 */
function le_code_file(string $dir, string $rel): ?string
{
    if (str_contains($rel, '..') || !preg_match(LE_SITE_PATH_PATTERN, $rel) || !isset(LE_STATIC_MIME_TYPES[strtolower(pathinfo($rel, PATHINFO_EXTENSION))])) {
        return null;
    }
    $file = $dir . '/' . $rel;

    return is_file($file) ? $file : null;
}

/** Ob $file in UPLOADS_ROOT liegt (auch über Links aufgelöst). */
function le_upload_path(string $file): bool
{
    $real = realpath($file);
    $root = realpath(UPLOADS_ROOT);

    return $real !== false && $root !== false && str_starts_with($real, $root . '/');
}

/** Upload ausliefern: nur Endungen der Upload-Whitelist, SVGs in der Sandbox (UPLOADS_SVG_CSP); anderes 404. */
function le_serve_upload_file(string $file): bool
{
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    if (!isset(LE_UPLOAD_TYPES[$ext])) {
        return le_respond_not_found();
    }
    if ($ext === 'svg') {
        header('Content-Security-Policy: ' . UPLOADS_SVG_CSP);
    }

    // Uploads heißen bei jedem Hochladen neu (api/upload.php), dürfen also lange im Browser bleiben.
    return le_serve_static_file($file, LE_STATIC_MAX_AGE['upload']);
}

/**
 * $file ausliefern, mit $maxAge samt Browser-Cache; $source: Datei, deren Endung den Typ bestimmt (verkleinerte Kopie).
 * Rohe Dateien auch in Teilen (Range, le_http_range): Safari spielt Videos nur so ab, PDF.js lädt nur die nötigen Bytes.
 * HEAD bekommt dieselben Header ohne Inhalt.
 */
function le_serve_static_file(string $file, ?int $maxAge = null, ?string $source = null): bool
{
    $ext = strtolower(pathinfo($source ?? $file, PATHINFO_EXTENSION));
    $type = LE_STATIC_MIME_TYPES[$ext] ?? 'application/octet-stream';
    $head = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'HEAD';

    header('Content-Type: ' . $type);
    // Mit $maxAge darf der Browser die Datei so lange behalten und fragt danach mit ETag bzw. Datum nach (304);
    // mit der aktuellen Versionsnummer (?v=…, backend/site/assetVersion.php) ein Jahr ohne Nachfrage.
    // Ohne (Verwaltung, Login) kein Last-Modified: Browser würden sonst nach Gefühl cachen, auch über ein Update hinweg.
    if ($maxAge !== null) {
        $mtime = (int) filemtime($file);
        $tag = le_asset_version($source ?? $file);
        $versioned = le_asset_version_matches($source ?? $file, $_GET[LE_ASSET_VERSION_PARAM] ?? null);
        header('Cache-Control: public, max-age=' . ($versioned ? LE_ASSET_VERSION_MAX_AGE . ', immutable' : $maxAge));
        header('ETag: "' . $tag . '"');
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $mtime) . ' GMT');
        $ifNoneMatch = (string) ($_SERVER['HTTP_IF_NONE_MATCH'] ?? '');
        $ifModifiedSince = strtotime((string) ($_SERVER['HTTP_IF_MODIFIED_SINCE'] ?? '')) ?: null;
        // Ein Webserver, der komprimiert, hängt an den ETag etwas an (Caddy: "…-gzip"): der Kern zählt.
        if ($ifNoneMatch !== '' ? str_contains($ifNoneMatch, '"' . $tag) : ($ifModifiedSince !== null && $ifModifiedSince >= $mtime)) {
            http_response_code(304);
            return true;
        }
    }
    // Stylesheets der Website und der Plugins: url() mit Versionsnummer wie in den Seiten (erzeugt, daher ohne Range).
    if ($maxAge !== null && $ext === 'css') {
        $css = le_asset_versioned_css((string) file_get_contents($file), $source ?? $file);
        header('Content-Length: ' . (string) strlen($css));
        echo $head ? '' : $css;
        return true;
    }
    $size = (int) filesize($file);
    $range = le_http_range(isset($_SERVER['HTTP_RANGE']) ? (string) $_SERVER['HTTP_RANGE'] : null, $size);
    // If-Range: Teile nur vom selben Stand (ETag oder Datum von oben), sonst die ganze Datei.
    $ifRange = isset($_SERVER['HTTP_IF_RANGE']) ? trim((string) $_SERVER['HTTP_IF_RANGE']) : null;
    if ($range !== null && $ifRange !== null && ($maxAge === null || ($ifRange !== '"' . $tag . '"' && strtotime($ifRange) !== $mtime))) {
        $range = null;
    }
    header('Accept-Ranges: bytes');
    if ($range === false) {
        http_response_code(416);
        header('Content-Range: bytes */' . $size);
        header('Content-Length: 0');
        return true;
    }
    [$first, $last] = $range ?? [0, $size - 1];
    if ($range !== null) {
        http_response_code(206);
        header('Content-Range: bytes ' . $first . '-' . $last . '/' . $size);
    }
    header('Content-Length: ' . (string) max(0, $last - $first + 1));
    if ($head || $size === 0) {
        return true;
    }
    $in = fopen($file, 'rb');
    $out = fopen('php://output', 'wb');
    if ($in !== false && $out !== false) {
        stream_copy_to_stream($in, $out, $last - $first + 1, $first);
    }
    return true;
}
