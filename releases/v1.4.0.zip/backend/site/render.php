<?php
declare(strict_types=1);

// Seite der Website rendern: Der Router bindet diese Datei als letzte Anweisung auf oberster Ebene ein ($path, $file
// und alle Variablen bleiben global), sie wählt das Dokument, führt das PHP der Seite aus und liefert sie aus.

// Alles, was diese Datei und das PHP der Seite brauchen (eine Liste, auch für den Health-Check).
require_once LE_BACKEND . '/site/sitePhp.php';

// Content-Types einer Seite. Setzt das PHP der Website selbst einen anderen (header(), etwa application/json ohne exit),
// ist die Antwort keine Seite (le_site_response_is_html). Vor dem Code unten: const gilt erst, wenn die Zeile gelaufen ist.
const LE_SITE_HTML_TYPES = ['text/html', 'application/xhtml+xml'];

if ($file === null) {
    $siteDocument = plugin_site_page($path);
    // Alte Adressen (private/redirects.json) → 301, erst wenn weder Datei noch Plugin sie beantworten.
    $redirect = in_array($siteDocument, [null, PLUGIN_SITE_PAGE_NOT_FOUND, PLUGIN_SITE_PAGE_UNAVAILABLE], true) ? le_seo_redirect_target($path) : null;
    if ($redirect !== null) {
        $query = (string) ($_SERVER['QUERY_STRING'] ?? '');
        header('Location: ' . $redirect . ($query !== '' && !str_contains($redirect, '?') ? '?' . $query : ''), true, 301);
        return true;
    }
    // Könnte die Adresse einem Plugin mit fehlgeschlagenem Schema gehören: 503 statt der 404-Seite (plugin_site_page);
    // fehlende Bilder, Skripte usw. bleiben „Not Found“.
    if ($siteDocument === PLUGIN_SITE_PAGE_UNAVAILABLE) {
        if (le_site_not_found_is_page($path)) {
            return le_respond_unavailable();
        }
        $siteDocument = null;
    }
    // Seiten ohne Datei und ohne Plugin bekommen die 404-Seite, fehlende Bilder, Skripte usw. nur „Not Found“.
    if ($siteDocument === PLUGIN_SITE_PAGE_NOT_FOUND || ($siteDocument === null && le_site_not_found_is_page($path))) {
        $siteDocument = le_site_not_found_document();
    }
    if ($siteDocument === null) {
        return le_respond_not_found();
    }
} elseif (le_upload_path($file)) {
    // Auch über Kurzadressen wie /uploads/x.svg: Uploads nur mit den Regeln aus Schritt 3, nie als Seite ausgeführt.
    return le_serve_upload_file($file);
} elseif (le_site_is_document($file)) {
    $siteDocument = le_site_document($file);
} else {
    // CSS und JS verkleinert (backend/site/minify.php); die Quelldatei bestimmt Typ und Cache-Dauer.
    return le_serve_static_file(le_minified_file($file) ?? $file, le_static_max_age($file), $file);
}

// Die Seite wird hier auf oberster Ebene eingebunden, nicht in einer Funktion: Site-PHP sieht ihre
// Variablen global wie gewohnt (Funktionen mit `global $x` aus einem Include). Der Status kommt vorher,
// damit eine Seite ihn selbst ändern kann (eigenes 404, Weiterleitung mit Location). Wirft die Seite eines
// Plugins (z. B. page.php) oder ihr finish, kommt einmal die 404-Seite der Website (le_site_document,
// le_site_not_found_document); wirft auch die (Rahmen der Startseite), der Fehler. Lesefunktionen der aktiven Plugins
// (public.php) lädt der Kern vorher, die Website nicht selbst.
le_plugins_load_public();
$siteNotFoundShown = false;
for (;;) {
    extract($siteDocument['vars'], EXTR_SKIP);
    http_response_code($siteDocument['status']);
    $siteBufferLevel = ob_get_level();
    ob_start();
    try {
        if ($siteDocument['file'] !== null) {
            if (strtolower(pathinfo($siteDocument['file'], PATHINFO_EXTENSION)) === 'php') {
                require $siteDocument['file'];
            } else {
                readfile($siteDocument['file']);
            }
        }
        $siteHtml = (string) ob_get_clean();
        if ($siteDocument['finish'] !== null) {
            $siteHtml = ($siteDocument['finish'])($siteHtml);
        }
        break;
    } catch (Throwable $e) {
        if ($siteDocument['finish'] === null || $siteNotFoundShown) {
            throw $e;
        }
        $siteNotFoundShown = true;
        while (ob_get_level() > $siteBufferLevel) {
            ob_end_clean();
        }
        header_remove('Location');
        error_log('site_page ' . $path . ': ' . $e->getMessage());
        $siteDocument = le_site_not_found_document();
        if ($siteDocument === null) {
            return le_respond_not_found();
        }
    }
}
return le_respond_site_html($siteHtml, $siteDocument['editor'], $path);

/** Ob die Antwort eine Seite ist: ohne eigenen Content-Type oder mit einem aus LE_SITE_HTML_TYPES (Groß/klein und Parameter wie charset egal). */
function le_site_response_is_html(): bool
{
    $type = null;
    foreach (headers_list() as $header) {
        if (stripos($header, 'Content-Type:') === 0) {
            $type = strtolower(trim(explode(';', substr($header, strlen('Content-Type:')), 2)[0]));
        }
    }
    return $type === null || in_array($type, LE_SITE_HTML_TYPES, true);
}

/**
 * Seite der Website ausliefern: Shortcodes, Plugin-Filter, Vorschaubild und strukturierte Daten (le_seo_head),
 * für Angemeldete der Seiten-Editor. $html: gerendertes Dokument; $file: seine Datei (Editor: welche Seite
 * bearbeitet wird); $path: angefragte Adresse (kanonisch). Keine Seite (le_site_response_is_html): Ausgabe und
 * Content-Type, wie das PHP der Website sie gesetzt hat, ohne jede Einfügung.
 */
function le_respond_site_html(string $html, string $file, string $path): bool
{
    // Mit Session-Cookie sieht eine Seite anders aus (Editor): Caches des Hosters dürfen
    // Besuchern und Angemeldeten nicht dieselbe Fassung geben.
    header('Vary: Cookie');
    if (!le_site_response_is_html()) {
        echo $html;
        return true;
    }
    $html = render_shortcodes_in_html($html);
    $html = filter_site_html($html);
    // Status, wie ihn die Seite zuletzt gesetzt hat (eigenes 404, Weiterleitung).
    $html = le_seo_head($html, $path, (int) http_response_code());
    // Unter dem <base> des Kerns (Einzelseiten, erzeugte 404-Seite) bleiben Links wie href="#main" auf der Seite.
    $self = le_site_base_inserted() ? le_site_request_url() : null;
    if ($self !== null) {
        $html = le_site_fragment_links($html, $self);
    }

    header('Content-Type: text/html; charset=utf-8');
    // Angemeldet: Seiten-Editor einhängen; die Antwort ist dann persönlich und darf in keinen Cache. Eine Messseite
    // (le_measure_requested) bleibt ohne Editor, sonst wie für Angemeldete; für Besucher hat der Parameter keine Wirkung.
    $editorUser = signed_in_user();
    $measure = $editorUser !== null && le_measure_requested();
    $withEditor = $editorUser !== null && !$measure ? inject_site_editor($html, $editorUser, $file) : null;
    if ($withEditor !== null || $measure) {
        $html = $withEditor ?? $html;
        header('Cache-Control: no-store');
        le_deny_foreign_framing();
    } else {
        // Nur für Besucher: Der Editor würde die Nummern sonst in die Seitendateien speichern.
        $html = le_asset_versioned_html($html, $path);
    }
    echo $html;
    return true;
}
