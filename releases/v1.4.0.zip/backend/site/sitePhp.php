<?php
declare(strict_types=1);

// Kern, den das PHP einer Seite der Website vorfindet: alles, was der Router bis zum Rendern geladen hat. Eine Liste für
// die Besucherseite (render.php) und den Health-Check (le_health_check_render), damit beide gleich rendern. Die
// Lesefunktionen aktiver Plugins (public.php) lädt le_plugins_load_public dazu.

require_once LE_BACKEND . '/base/http.php';
require_once LE_BACKEND . '/base/texts.php';
require_once LE_BACKEND . '/base/utils.php';
require_once LE_BACKEND . '/pages/imagePlaces.php';
require_once LE_BACKEND . '/pages/routes.php';
require_once LE_BACKEND . '/pages/siteEditor.php';
require_once LE_BACKEND . '/plugins/hooks.php';
require_once LE_BACKEND . '/plugins/plugins.php';
require_once LE_BACKEND . '/plugins/render.php';
require_once LE_BACKEND . '/site/assetVersion.php';
require_once LE_BACKEND . '/site/head.php';
require_once LE_BACKEND . '/site/indexNow.php';
require_once LE_BACKEND . '/site/minify.php';
require_once LE_BACKEND . '/site/respond.php';
require_once LE_BACKEND . '/site/seo.php';
require_once LE_BACKEND . '/users/auth.php';
require_once LE_BACKEND . '/users/setup.php';
