<?php
declare(strict_types=1);

// Spielt die Plugin-Tabellen einer MySQL-Sicherung (database/schema.json und
// database/<tabelle>.jsonl) in die Datenbank dieser Installation ein. Auf der
// Kunden-Installation, nachdem die Sicherung entpackt ist (siehe
// docs/knowledgebase/backup/restore.md):
//   php backend/backup/restore-mysql.php [ordner mit database/, Standard: Installation]
// Baut die (leeren) Tabellen jedes Plugins aus den Schema-Dateien bis zum Schema-Stand
// der Sicherung neu (LE_PLUGIN_SCHEMA_TABLE; ältere Sicherungen ohne: älteste Datei),
// übernimmt seinen Stand, dann Zeilen samt id und den id-Zähler, und zieht danach das
// Schema auf den Stand des Codes nach (le_plugins_schema_update). Enthält eine
// Zieltabelle schon Zeilen, bricht es vorher ab. Bricht es später ab, sind die
// Tabellen der begonnenen Plugins weg und ihr Stand mit ihnen; ein neuer Lauf geht.

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

// Einstieg im Backend, damit jede Installation das Skript in der Version ihres Kerns hat (ops/ ist nicht im Release).
require_once __DIR__ . '/../base/paths.php';
require_once LE_BACKEND . '/database/migration.php';
require_once LE_BACKEND . '/backup/siteBackupFormat.php';

// Meldungen beim Abbruch. %1$s: Tabelle; bei columnsFailed %2$s: Plugin, %3$s: Version der dort gescheiterten Schema-Datei.
// schemaFailed: Warnung nach dem Nachziehen, %1$s: Plugin, %2$s: Version der gescheiterten Schema-Datei.
const LE_RESTORE_MYSQL_TEXT = [
    'columns' => 'Spalten von %1$s passen nicht zur Sicherung (andere Plugin-Version?)',
    // Kern-Tabelle LE_PLUGIN_SCHEMA_TABLE: kommt aus einer anderen LeBuild-Version.
    'stateColumns' => 'Spalten von %1$s passen nicht zur Sicherung (andere LeBuild-Version?)',
    'columnsFailed' => 'Spalten von %1$s passen nicht zur Sicherung: Dort war Schema-Datei %3$s von %2$s fehlgeschlagen und hatte schon Teile festgeschrieben. Eine Sicherung von vor dem Fehlschlag einspielen oder die Tabellen von Hand angleichen',
    'schemaFailed' => 'WARNUNG: %1$s: Schema-Datei %2$s fehlgeschlagen (Details im Fehlerprotokoll).',
];

/**
 * Tabellen aus schema.json, geprüft gegen die installierten Plugins
 * (private/active-plugins.json aus der Sicherung): [Tabelle => ['columns', 'nextId']]. Dazu die Kern-Tabelle
 * LE_PLUGIN_SCHEMA_TABLE, wenn die Sicherung sie hat (ältere haben sie nicht: Übergangsregel).
 */
function backup_restore_schema(string $dir, array $plugins): array
{
    $schema = json_decode((string) @file_get_contents($dir . '/' . SITE_BACKUP_DB_SCHEMA), true);
    if (!is_array($schema)) {
        throw new RuntimeException($dir . '/' . SITE_BACKUP_DB_SCHEMA . ' fehlt oder ist ungültig');
    }
    $expected = array_merge(...array_values($plugins));
    $unknown = array_diff(array_keys($schema), db_migration_all_tables($plugins));
    if ($unknown) {
        throw new RuntimeException('Tabellen ohne installiertes Plugin: ' . implode(', ', $unknown));
    }
    $tables = [];
    foreach (array_key_exists(LE_PLUGIN_SCHEMA_TABLE, $schema) ? [...$expected, LE_PLUGIN_SCHEMA_TABLE] : $expected as $table) {
        $entry = $schema[$table] ?? null;
        $columns = is_array($entry) ? ($entry['columns'] ?? null) : null;
        // next_id berücksichtigt den Zähler der Quelle (gelöschte Zeilen am Ende).
        $nextId = is_array($entry) ? ($entry['next_id'] ?? null) : null;
        if (!is_array($columns) || array_filter($columns, 'is_string') !== $columns || !is_int($nextId)) {
            throw new RuntimeException('Tabelle ' . $table . ' fehlt in ' . SITE_BACKUP_DB_SCHEMA . ' oder ist ungültig');
        }
        if (!is_file($dir . '/' . $table . SITE_BACKUP_DB_ROWS_SUFFIX)) {
            throw new RuntimeException('Datei ' . $table . SITE_BACKUP_DB_ROWS_SUFFIX . ' fehlt');
        }
        $tables[$table] = ['columns' => $columns, 'nextId' => $nextId];
    }
    return $tables;
}

/** Zeilen einer .jsonl-Datei blockweise einfügen; liefert die Zahl der Zeilen. */
function backup_restore_table(PDO $pdo, string $dir, string $table, array $columns): int
{
    $count = backup_restore_rows($dir, $table, $columns, db_migration_inserter($pdo, $table, $columns));
    $stored = (int) $pdo->query("SELECT COUNT(*) FROM `{$table}`")->fetchColumn();
    if ($stored !== $count) {
        throw new RuntimeException("Zeilenzahl in {$table} weicht ab ({$stored} statt {$count})");
    }
    return $count;
}

/**
 * Zeilen von $table aus ihrer .jsonl-Datei, geprüft gegen $columns, blockweise an $batch (Liste von Werte-Listen in der
 * Reihenfolge von $columns); liefert ihre Zahl.
 */
function backup_restore_rows(string $dir, string $table, array $columns, callable $batch): int
{
    $fh = fopen($dir . '/' . $table . SITE_BACKUP_DB_ROWS_SUFFIX, 'rb');
    $rows = [];
    $count = 0;
    $line = 0;
    while (($json = fgets($fh)) !== false) {
        $line++;
        if (trim($json) === '') {
            continue;
        }
        $row = json_decode($json, true);
        if (!is_array($row) || count($row) !== count($columns) || array_diff($columns, array_keys($row))) {
            fclose($fh);
            throw new RuntimeException("Zeile {$line} in {$table}" . SITE_BACKUP_DB_ROWS_SUFFIX . ' passt nicht zu den Spalten');
        }
        $rows[] = array_map(static fn (string $column) => $row[$column], $columns);
        if (count($rows) === DB_MIGRATION_BATCH) {
            $batch($rows);
            $count += count($rows);
            $rows = [];
        }
    }
    fclose($fh);
    if ($rows) {
        $batch($rows);
        $count += count($rows);
    }
    return $count;
}

/**
 * Schema-Stand der Sicherung aus LE_PLUGIN_SCHEMA_TABLE ($tables wie backup_restore_schema): [Plugin => Zeile wie
 * le_plugin_schema_rows]; leer bei einer älteren Sicherung ohne die Tabelle (Übergangsregel).
 */
function backup_restore_stands(string $dir, array $tables): array
{
    $columns = $tables[LE_PLUGIN_SCHEMA_TABLE]['columns'] ?? null;
    if ($columns === null) {
        return [];
    }
    if (array_diff(['plugin', ...LE_PLUGIN_SCHEMA_COLUMNS], $columns) !== []) {
        throw new RuntimeException(sprintf(LE_RESTORE_MYSQL_TEXT['stateColumns'], LE_PLUGIN_SCHEMA_TABLE));
    }
    $stands = [];
    backup_restore_rows($dir, LE_PLUGIN_SCHEMA_TABLE, $columns, static function (array $rows) use ($columns, &$stands): void {
        foreach ($rows as $values) {
            $row = array_combine($columns, $values);
            $stands[(string) $row['plugin']] = le_plugin_schema_values($row);
        }
    });
    return $stands;
}

/** Ganzer Lauf; Rückgabe ist der Exit-Code. */
function backup_restore_main(array $argv): int
{
    $dir = rtrim($argv[1] ?? LE_INSTANCE_ROOT, '/') . '/' . SITE_BACKUP_DB_DIR;
    $plugins = db_migration_plugins();
    if (!$plugins) {
        // Nur „nichts zu tun“, wenn auch die Sicherung keine Tabellen hat (kein database/ wie bei SQLite, oder ein
        // leeres schema.json); sonst sähe ein Restore ohne Wirkung erfolgreich aus.
        if (is_dir($dir)) {
            $schema = json_decode((string) @file_get_contents($dir . '/' . SITE_BACKUP_DB_SCHEMA), true);
            if (!is_array($schema)) {
                echo 'FEHLER: ' . $dir . '/' . SITE_BACKUP_DB_SCHEMA . " fehlt oder ist ungültig\n";
                return 1;
            }
            if ($schema !== []) {
                echo 'FEHLER: Tabellen ohne installiertes Plugin: ' . implode(', ', array_keys($schema)) . "\n";
                return 1;
            }
        }
        echo "Keine installierten Plugins mit Tabellen, nichts einzuspielen.\n";
        return 0;
    }

    $created = [];
    try {
        $tables = backup_restore_schema($dir, $plugins);
        $driver = db_driver();
        $error = db_migration_check_schemas($driver, $plugins);
        if ($error !== null) {
            throw new RuntimeException($error['message']);
        }
        $pdo = db();
        foreach (array_diff(array_keys($tables), [LE_PLUGIN_SCHEMA_TABLE]) as $table) {
            if (db_table_exists($pdo, $table) && $pdo->query("SELECT 1 FROM `{$table}` LIMIT 1")->fetchColumn() !== false) {
                throw new RuntimeException("Tabelle {$table} enthält schon Zeilen. Abbruch, nichts verändert.");
            }
        }
        $stands = backup_restore_stands($dir, $tables);
        // Anfragen ziehen das Schema nicht nach, solange eingespielt wird; danach finden sie den Stand der Sicherung.
        le_store_lock_until_end('plugins');
        le_plugin_schema_table_create($pdo, $driver);

        foreach ($plugins as $name => $pluginTables) {
            // Die Tabellen sind leer (s. o.): immer neu bis zum Stand der Sicherung, damit die Spalten zu ihr passen, was
            // auch immer eine Anfrage vorher angelegt hat. Erst danach der Stand, damit er nie vor den Tabellen steht.
            // Schon vorher vermerkt, damit der Abbruch auch die Tabellen früherer Dateien wegräumt.
            $stand = $stands[$name] ?? ['version' => le_plugin_schema_oldest($name, $driver)];
            array_push($created, ...$pluginTables);
            db_drop_tables($pdo, $pluginTables);
            le_plugin_schema_build($pdo, $driver, $name, $pluginTables, $stand['version']);
            le_plugin_schema_save($pdo, $name, $stand['version'], $stand);
            foreach ($pluginTables as $table) {
                $columns = db_migration_columns($pdo, $table);
                $expected = $tables[$table]['columns'];
                if (count($expected) !== count($columns) || array_diff($columns, $expected)) {
                    throw new RuntimeException(($stand['failed_manifest'] ?? null) !== null
                        ? sprintf(LE_RESTORE_MYSQL_TEXT['columnsFailed'], $table, $name, (string) $stand['failed_file'])
                        : sprintf(LE_RESTORE_MYSQL_TEXT['columns'], $table));
                }
                $count = backup_restore_table($pdo, $dir, $table, $columns);
                db_set_next_id($pdo, $driver, $table, max(db_next_id($pdo, $driver, $table), $tables[$table]['nextId']));
                echo "{$table}: {$count} Zeilen\n";
            }
        }
    } catch (Throwable $e) {
        // Nichts Halbes zurücklassen: Die Tabellen der begonnenen Plugins sind weg und mit ihnen ihr Stand (die nächste
        // Anfrage legt sie wieder an, alle fehlen); die übrigen Plugins sind unberührt. Ein neuer Lauf baut alle neu.
        echo 'FEHLER: ' . $e->getMessage() . "\n";
        try {
            if (isset($pdo)) {
                db_drop_tables($pdo, $created);
                foreach (array_keys($plugins) as $name) {
                    if (array_intersect($plugins[$name], $created) !== []) {
                        le_plugin_schema_forget($pdo, $name);
                    }
                }
            }
        } catch (Throwable $cleanup) {
            echo 'Aufräumen fehlgeschlagen, Tabellen ' . implode(', ', $created) . ' von Hand löschen: ' . $cleanup->getMessage() . "\n";
        }
        return 1;
    }
    // Wie bei der ersten Verbindung einer Anfrage, die auf der Kommandozeile nicht nachzieht; Fehler stehen im Log.
    le_plugins_schema_update($pdo, $driver);
    foreach (array_keys($plugins) as $name) {
        $failed = le_plugin_schema_failed($name);
        if ($failed !== null) {
            echo sprintf(LE_RESTORE_MYSQL_TEXT['schemaFailed'], $name, (string) $failed['file']) . "\n";
        }
    }
    $real = realpath($dir);
    if ($real !== false && $real !== LE_INSTANCE_ROOT && le_path_in($real, [LE_INSTANCE_ROOT])) {
        echo "Fertig. {$dir} liegt im Ordner der Website und enthält Kundendaten: jetzt löschen.\n";
    } else {
        echo "Fertig.\n";
    }
    return 0;
}

if (get_included_files()[0] === __FILE__) {
    exit(backup_restore_main($argv));
}
