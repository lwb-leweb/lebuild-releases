<?php
declare(strict_types=1);

// Bildoptimierung beim Upload (le_upload_accept in media/openUploads.php): JPG und PNG werden auf höchstens LE_IMAGE_MAX_WIDTH Pixel Breite
// verkleinert und als WebP gespeichert, das Original nicht aufbewahrt. Alles andere (WebP, SVG) bleibt, wie es ist.
// Lässt sich ein Bild nicht umrechnen (ohne GD mit WebP, zu groß, Fehler von GD), lehnt der Upload ein JPG ab
// (das Original trüge EXIF mit GPS-Position) und speichert ein PNG unverändert. Unverändert gespeicherte PNG und WebP
// verlieren vorher ihre Metadaten (le_image_without_metadata), ohne neu zu kodieren. Umgerechnet wird immer nur ein Bild
// zur Zeit je Server (LE_IMAGE_CONVERT_LOCK): mehrere große Fotos gleichzeitig sprengten sonst den Speicher.
// Dieselben Helfer (le_image_webp, le_image_resampled) rechnen abgeleitete Dateien (Zuschnitt, kleinere Breite, media/derived.php).

require_once LE_BACKEND . '/media/uploads.php';
require_once LE_BACKEND . '/base/files.php';


const LE_IMAGE_MAX_WIDTH = 1920;
const LE_IMAGE_WEBP_QUALITY = 82;
// Speicher je Pixel einer Bitmap in GD (4 Bytes plus Zeilenzeiger und Puffer der Decoder), für die Schätzung vor dem Laden.
const LE_IMAGE_BYTES_PER_PIXEL = 5;
// Speicher, den sich ein Upload für das Umrechnen holt (ini_set), falls memory_limit darunter liegt: reicht für
// LE_IMAGE_MAX_PIXELS (50 MP × 5 Byte ≈ 240 MB plus verkleinerte Fassung).
const LE_IMAGE_MEMORY_LIMIT = '512M';
// Feste Obergrenze, die immer gilt, auch ohne memory_limit (-1): Größere Bilder werden nicht umgerechnet.
const LE_IMAGE_MAX_PIXELS = 50_000_000;
// Endungen, die optimiert werden, mit dem Bildtyp, den getimagesize dazu liefern muss.
const LE_IMAGE_OPTIMIZE_TYPES = ['jpg' => IMAGETYPE_JPEG, 'jpeg' => IMAGETYPE_JPEG, 'png' => IMAGETYPE_PNG];
// Endungen, aus denen eine abgeleitete Datei entstehen kann (media/derived.php): dazu WebP, die Form fast jedes Originals.
const LE_IMAGE_DERIVE_TYPES = LE_IMAGE_OPTIMIZE_TYPES + ['webp' => IMAGETYPE_WEBP];
// Höchste Anzeigebreite (CSS-Pixel, maxWidth) mal diesen Faktor ist die Breite einer abgeleiteten Datei: hochauflösende Bildschirme.
const LE_IMAGE_DENSITY = 2;

// Blöcke mit Metadaten (EXIF samt GPS-Position, XMP, Text wie Autor oder Kommentar, Zeitstempel, C2PA-Herkunftsnachweis,
// der seinerseits EXIF mit GPS tragen kann), die ein unverändert gespeichertes Bild verliert; beim WebP mit dem Bit, das
// der VP8X-Chunk dafür setzt (C2PA hat keins).
const LE_IMAGE_PNG_METADATA_CHUNKS = ['eXIf', 'tEXt', 'iTXt', 'zTXt', 'tIME', 'caBX'];
const LE_IMAGE_WEBP_METADATA_CHUNKS = ['EXIF' => 0x08, 'XMP ' => 0x04, 'C2PA' => 0];

// Drehung je EXIF-Orientierung (imagerotate, gegen den Uhrzeigersinn) nach dem Spiegeln; fehlt sie, wird nicht gedreht.
const LE_IMAGE_ORIENTATION_ANGLES = [3 => 180, 5 => -90, 6 => -90, 7 => -90, 8 => 90];

// Sperrdatei im Temp-Ordner (bei Docker für alle Websites des Containers gemeinsam): ein Umrechnen zur Zeit.
const LE_IMAGE_CONVERT_LOCK = 'lebuild-image-convert.lock';

/** Ob GD WebP schreiben kann; sonst wird nicht umgerechnet (Systemprüfung: gd). */
function le_image_webp_supported(): bool
{
    return function_exists('imagewebp') && function_exists('gd_info') && !empty(gd_info()['WebP Support']);
}

/**
 * WebP-Fassung des hochgeladenen Bildes $path mit der Endung $extension, verkleinert auf LE_IMAGE_MAX_WIDTH und nach
 * der EXIF-Orientierung gedreht (WebP verwirft EXIF; ohne exif-Erweiterung dreht nichts). null heißt: unverändert
 * speichern, weil es kein JPG/PNG ist, GD kein WebP kann, ein animiertes PNG, le_image_webp scheitert (zu viele Pixel,
 * Speicher, GD) oder, ohne Verkleinern, das WebP eines PNG nicht kleiner wäre.
 * Ein JPG wird immer WebP (auch wenn größer): das Original trüge EXIF samt GPS-Position, Zeit und Gerät.
 * $webp und $memoryLimit (Bytes, null: memory_limit) vorgeben nur für Tests.
 */
function le_image_optimized(string $path, string $extension, ?bool $webp = null, ?int $memoryLimit = null): ?string
{
    $type = LE_IMAGE_OPTIMIZE_TYPES[strtolower($extension)] ?? null;
    if ($type === null || !($webp ?? le_image_webp_supported())) {
        return null;
    }
    $info = le_image_info($path, $type);
    $shown = $info !== null ? le_image_display_size($path) : null;
    // Animiertes PNG: GD läse nur das erste Bild.
    if ($shown === null || ($type === IMAGETYPE_PNG && le_image_png_animated($path))) {
        return null;
    }
    $orientation = le_image_orientation($path, $type);
    [$shownWidth] = $shown;
    // Verkleinert wird nach der Breite, wie das Bild gedreht erscheint; gedreht wird erst danach (kleineres Bild).
    $scale = min(1, LE_IMAGE_MAX_WIDTH / $shownWidth);
    $newWidth = max(1, (int) round($info[0] * $scale));
    $newHeight = max(1, (int) round($info[1] * $scale));
    $resize = $scale < 1;
    $rotate = isset(LE_IMAGE_ORIENTATION_ANGLES[$orientation]);

    $data = le_image_webp($path, $info, $newWidth * $newHeight * ((int) $resize + (int) $rotate), static function (GdImage $image) use ($resize, $newWidth, $newHeight, $orientation): GdImage {
        return le_image_oriented($resize ? le_image_resampled($image, $newWidth, $newHeight) : $image, $orientation);
    }, $memoryLimit);
    if ($data === null) {
        return null;
    }

    return $resize || $type === IMAGETYPE_JPEG || strlen($data) < (int) @filesize($path) ? $data : null;
}

/** getimagesize von $path, wenn es ein Bild vom Typ $type mit mindestens 1 × 1 Pixel ist; sonst null (Fehlerprotokoll). */
function le_image_info(string $path, int $type): ?array
{
    $info = @getimagesize($path);
    if ($info === false || $info[2] !== $type || $info[0] < 1 || $info[1] < 1) {
        error_log('image: cannot read ' . basename($path));
        return null;
    }

    return $info;
}

/** EXIF-Orientierung des Bildes $path vom Typ $type: nur ein JPG trägt sie, alles andere 1. */
function le_image_orientation(string $path, int $type): int
{
    return $type === IMAGETYPE_JPEG ? le_image_exif_orientation($path) : 1;
}

/**
 * WebP aus dem Bild $path (getimagesize $info: JPG, PNG oder WebP): geladen, mit $transform(GdImage): GdImage bearbeitet,
 * kodiert mit LE_IMAGE_WEBP_QUALITY. null (Grund im Fehlerprotokoll), wenn es mehr als LE_IMAGE_MAX_PIXELS hat, der
 * Speicher für das Bild und $morePixels weitere Pixel (Zwischenbilder von $transform) nach der Schätzung nicht reicht
 * oder GD scheitert. Ein Umrechnen zur Zeit je Server (LE_IMAGE_CONVERT_LOCK). $memoryLimit wie bei le_image_optimized.
 */
function le_image_webp(string $path, array $info, int $morePixels, callable $transform, ?int $memoryLimit = null): ?string
{
    [$width, $height, $type] = $info;
    if ($width * $height > LE_IMAGE_MAX_PIXELS) {
        error_log('image: ' . $width . 'x' . $height . ' above ' . LE_IMAGE_MAX_PIXELS . ' pixels, not converted');
        return null;
    }
    $limit = $memoryLimit ?? ini_size_bytes((string) ini_get('memory_limit'));
    if ($limit !== null && memory_get_usage() + ($width * $height + $morePixels) * LE_IMAGE_BYTES_PER_PIXEL > $limit) {
        error_log('image: ' . $width . 'x' . $height . ' too large for memory_limit, not converted');
        return null;
    }

    // Ein Umrechnen zur Zeit (LE_IMAGE_CONVERT_LOCK); ohne Sperrdatei trotzdem umrechnen.
    $lock = @fopen(sys_get_temp_dir() . '/' . LE_IMAGE_CONVERT_LOCK, 'c');
    if ($lock) {
        flock($lock, LOCK_EX);
    }
    try {
        $image = match ($type) {
            IMAGETYPE_JPEG => @imagecreatefromjpeg($path),
            IMAGETYPE_PNG => @imagecreatefrompng($path),
            IMAGETYPE_WEBP => @imagecreatefromwebp($path),
            default => false,
        };
        if ($image === false) {
            throw new RuntimeException('cannot decode');
        }
        if (!imageistruecolor($image) && !imagepalettetotruecolor($image)) {
            throw new RuntimeException('cannot convert palette');
        }
        $image = $transform($image);
        imagesavealpha($image, true);
        ob_start();
        $written = imagewebp($image, null, LE_IMAGE_WEBP_QUALITY);
        $data = (string) ob_get_clean();
        if (!$written || $data === '') {
            throw new RuntimeException('cannot encode webp');
        }
    } catch (Throwable $e) {
        error_log('image convert failed for ' . basename($path) . ': ' . $e->getMessage());
        return null;
    } finally {
        unset($image);
        if ($lock) {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }

    return $data;
}

/**
 * Für große Fotos mehr Speicher nur in dieser Anfrage (LE_IMAGE_MEMORY_LIMIT), falls memory_limit darunter liegt
 * (php_admin_value im Pool verhindert das, dann gilt die Grenze dort). Vor jedem Umrechnen (Upload, abgeleitete Datei).
 */
function le_image_memory_raise(): void
{
    $memory = ini_size_bytes((string) ini_get('memory_limit'));
    if ($memory !== null && $memory < ini_size_bytes(LE_IMAGE_MEMORY_LIMIT)) {
        @ini_set('memory_limit', LE_IMAGE_MEMORY_LIMIT);
    }
}

/**
 * $image auf $width × $height verkleinert, mit Alphakanal (transparente PNG bleiben transparent); $source [x, y, w, h]
 * nimmt nur diesen Ausschnitt (Zuschnitt), ohne das ganze Bild.
 */
function le_image_resampled(GdImage $image, int $width, int $height, ?array $source = null): GdImage
{
    [$x, $y, $w, $h] = $source ?? [0, 0, imagesx($image), imagesy($image)];
    $target = imagecreatetruecolor($width, $height);
    if ($target === false) {
        throw new RuntimeException('cannot allocate');
    }
    imagealphablending($target, false);
    imagesavealpha($target, true);
    imagefill($target, 0, 0, imagecolorallocatealpha($target, 0, 0, 0, 127));
    if (!imagecopyresampled($target, $image, 0, 0, $x, $y, $width, $height, $w, $h)) {
        throw new RuntimeException('cannot resample');
    }

    return $target;
}

/** EXIF-Orientierung 1–8 eines JPG; 1 ohne exif-Erweiterung, ohne Angabe oder bei einem Lesefehler. */
function le_image_exif_orientation(string $path): int
{
    if (!function_exists('exif_read_data')) {
        return 1;
    }
    $exif = @exif_read_data($path);
    $orientation = is_array($exif) ? (int) ($exif['Orientation'] ?? 1) : 1;

    return $orientation >= 1 && $orientation <= 8 ? $orientation : 1;
}

/** Ob die EXIF-Orientierung $orientation (5–8) das Bild um 90° dreht: angezeigt sind Breite und Höhe getauscht. */
function le_image_exif_turned(int $orientation): bool
{
    return $orientation >= 5;
}

/**
 * Maße [Breite, Höhe] des Bildes $path, wie der Browser es zeigt: bei einem JPG mit EXIF-Drehung getauscht (wie
 * le_image_optimized dreht); null, wenn getimagesize es nicht liest.
 */
function le_image_display_size(string $path): ?array
{
    $info = @getimagesize($path);
    if ($info === false || $info[0] < 1 || $info[1] < 1) {
        return null;
    }
    return $info[2] === IMAGETYPE_JPEG && le_image_exif_turned(le_image_exif_orientation($path)) ? [$info[1], $info[0]] : [$info[0], $info[1]];
}

/** $image so gespiegelt und gedreht, wie die EXIF-Orientierung es verlangt (imagerotate dreht gegen den Uhrzeigersinn). */
function le_image_oriented(GdImage $image, int $orientation): GdImage
{
    if (in_array($orientation, [2, 7], true)) {
        imageflip($image, IMG_FLIP_HORIZONTAL);
    }
    if (in_array($orientation, [4, 5], true)) {
        imageflip($image, IMG_FLIP_VERTICAL);
    }
    $angle = LE_IMAGE_ORIENTATION_ANGLES[$orientation] ?? 0;
    if ($angle === 0) {
        return $image;
    }
    $rotated = imagerotate($image, $angle, 0);
    if ($rotated === false) {
        throw new RuntimeException('cannot rotate');
    }

    return $rotated;
}

/** Ob das PNG $path animiert ist (APNG: acTL-Block vor den Bilddaten). */
function le_image_png_animated(string $path): bool
{
    $head = (string) @file_get_contents($path, false, null, 0, 4096);
    $actl = strpos($head, 'acTL');
    $idat = strpos($head, 'IDAT');

    return $actl !== false && ($idat === false || $actl < $idat);
}

/**
 * $data (Bild mit der Endung $extension) ohne Metadaten, ohne neu zu kodieren: PNG ohne LE_IMAGE_PNG_METADATA_CHUNKS,
 * WebP ohne LE_IMAGE_WEBP_METADATA_CHUNKS; alle anderen Blöcke byte-gleich (samt CRC), nach dem Ende (IEND, RIFF-Größe)
 * nichts mehr. Andere Endungen unverändert. null: kein lesbares PNG/WebP, le_upload_accept lehnt es dann ab.
 */
function le_image_without_metadata(string $data, string $extension): ?string
{
    return match (strtolower($extension)) {
        'png' => le_image_png_without_metadata($data),
        'webp' => le_image_webp_without_metadata($data),
        default => $data,
    };
}

/** PNG: Signatur, dann Chunks (Länge, Typ, Daten, CRC) bis IEND. */
function le_image_png_without_metadata(string $data): ?string
{
    $signature = "\x89PNG\r\n\x1a\n";
    if (!str_starts_with($data, $signature)) {
        return null;
    }
    $out = $signature;
    $length = strlen($data);
    for ($pos = strlen($signature); $pos + 12 <= $length; $pos = $end) {
        $type = substr($data, $pos + 4, 4);
        $end = $pos + 12 + unpack('N', $data, $pos)[1];
        if ($end > $length || !preg_match('/^[A-Za-z]{4}$/', $type)) {
            return null;
        }
        if (!in_array($type, LE_IMAGE_PNG_METADATA_CHUNKS, true)) {
            $out .= substr($data, $pos, $end - $pos);
        }
        if ($type === 'IEND') {
            return $out;
        }
    }

    return null;
}

/** WebP: RIFF-Kopf mit Größe, dann Chunks (FourCC, Größe, Daten, auf gerade Länge aufgefüllt); VP8X trägt die Flags. */
function le_image_webp_without_metadata(string $data): ?string
{
    if (strlen($data) < 20 || !str_starts_with($data, 'RIFF') || substr($data, 8, 4) !== 'WEBP') {
        return null;
    }
    $riffEnd = 8 + unpack('V', $data, 4)[1];
    if ($riffEnd > strlen($data)) {
        return null;
    }
    $chunks = '';
    for ($pos = 12; $pos < $riffEnd; $pos = $end) {
        if ($pos + 8 > $riffEnd) {
            return null;
        }
        $fourcc = substr($data, $pos, 4);
        $size = unpack('V', $data, $pos + 4)[1];
        if ($pos + 8 + $size > $riffEnd) {
            return null;
        }
        $end = min($riffEnd, $pos + 8 + $size + ($size & 1));
        if (!isset(LE_IMAGE_WEBP_METADATA_CHUNKS[$fourcc])) {
            $chunks .= substr($data, $pos, $end - $pos);
        }
    }
    if ($chunks === '') {
        return null;
    }
    if (str_starts_with($chunks, 'VP8X') && strlen($chunks) > 8) {
        $chunks[8] = chr(ord($chunks[8]) & ~array_sum(LE_IMAGE_WEBP_METADATA_CHUNKS));
    }

    return 'RIFF' . pack('V', strlen($chunks) + 4) . 'WEBP' . $chunks;
}

/** Schreibt das Bild atomar, lesbar wie eine mit move_uploaded_file abgelegte Datei (write_file_atomic). */
function le_image_write(string $path, string $content): bool
{
    try {
        write_file_atomic($path, $content);
    } catch (RuntimeException $e) {
        error_log('image write failed: ' . $e->getMessage());
        return false;
    }

    return true;
}
