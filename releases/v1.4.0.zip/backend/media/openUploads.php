<?php
declare(strict_types=1);

// Offene Uploads: hochgeladen, aber noch nicht gespeichert oder verworfen; Annehmen, Liste, Sperre, Verwerfen und Ablauf.

require_once LE_BACKEND . '/base/files.php';
require_once LE_BACKEND . '/media/uploads.php';
require_once LE_BACKEND . '/media/usage.php';
require_once LE_BACKEND . '/media/derived.php';

// Offene Uploads: hochgeladen (le_upload_accept), aber noch nicht durch Speichern oder Verwerfen erledigt; je Dateiname
// Formular, Benutzer und Zeit. Liegt außerhalb von UPLOAD_REFERENCE_ROOTS, sonst zählte jede offene Datei als verwendet.
const LE_OPEN_UPLOADS_FILE = CACHE_ROOT . '/open-uploads.json';
// Sperre der Liste (atomic_write ersetzt die Datei selbst, an ihr ließe sich nicht warten), le_open_uploads_hold.
const LE_OPEN_UPLOADS_LOCK = CACHE_ROOT . '/open-uploads.lock';
// Kopie einer kaputten Liste, bevor die aus den Dateien rekonstruierte sie ersetzt (le_open_uploads_recover).
const LE_OPEN_UPLOADS_BROKEN_FILE = CACHE_ROOT . '/open-uploads.broken.json';
// Belegte Sperre der Liste: so viele Sekunden höchstens warten (le_open_uploads_hold), dabei alle so viele Millisekunden nachsehen.
const LE_OPEN_UPLOADS_LOCK_TIMEOUT = 10;
const LE_OPEN_UPLOADS_LOCK_POLL_MS = 50;
// Formulare, die nie geschlossen wurden (Tab zu, Absturz, abgelaufene Anmeldung): Ihre offenen Uploads räumt nach
// so vielen Sekunden der nächste Upload bzw. das nächste Schließen eines Formulars weg.
const LE_OPEN_UPLOAD_MAX_AGE = 86400;
// Kennung eines Formulars, vom Browser zufällig gewählt (shared/upload.js).
const LE_UPLOAD_FORM_PATTERN = '/^[A-Za-z0-9]{16,64}$/';
// Kennzeichen am offenen Upload: ein Original, dessen Adresse der Browser nie bekam (Upload mit maxWidth antwortet mit der
// abgeleiteten Datei); nur so ein Original verwirft das Verwerfen seiner abgeleiteten Datei mit (le_open_uploads_discard).
const LE_OPEN_UPLOAD_UNSEEN = 'unseen';
// Zufallsteil im Namen jeder neuen Datei in UPLOADS_ROOT (le_upload_new_name), Bytes; als Hex doppelt so viele Zeichen.
const LE_UPLOAD_NAME_RANDOM_BYTES = 6;
// Name, wenn vom Dateinamen nach dem Bereinigen nichts bleibt.
const LE_UPLOAD_DEFAULT_NAME = 'upload';

/** Offene Uploads: Dateiname => ['form' => …, 'user' => Benutzer-ID, 'time' => …]; ohne Liste leer, kaputt rekonstruiert. */
function le_open_uploads(): array
{
    return le_open_uploads_stored() ?? le_open_uploads_recover();
}

/** Gespeicherte Liste; [] ohne Datei, null wenn sie kaputt oder unlesbar ist. */
function le_open_uploads_stored(): ?array
{
    if (!is_file(LE_OPEN_UPLOADS_FILE)) {
        return [];
    }
    $list = json_decode((string) @file_get_contents(LE_OPEN_UPLOADS_FILE), true);

    return is_array($list) ? $list : null;
}

/**
 * Ersatz für eine kaputte Liste: Jede Upload-Datei, die seit dem letzten Schreiben der Liste abzüglich der Frist
 * entstanden ist, kann darin gestanden haben (ältere nicht, jedes Schreiben räumt danach Abgelaufenes weg). Sie gilt als
 * offen ohne Formular, so erledigt sie nur die Frist ab ihrer Entstehung und löscht sie nur, wenn sie unbenutzt ist.
 */
function le_open_uploads_recover(): array
{
    $since = (int) @filemtime(LE_OPEN_UPLOADS_FILE) - LE_OPEN_UPLOAD_MAX_AGE;
    $list = [];
    foreach (dir_entries(UPLOADS_ROOT) as $file) {
        $time = upload_file_name(UPLOADS_URL . $file) !== null ? @filemtime(UPLOADS_ROOT . '/' . $file) : false;
        if ($time !== false && $time >= $since) {
            $list[$file] = ['form' => '', 'user' => '', 'time' => $time];
        }
    }

    return $list;
}

/**
 * Führt $work unter der Sperre der Liste aus und liefert sein Ergebnis; die Sperre gilt nur so lange (verschachtelt: schon
 * gehalten). Erledigen offener Uploads und Speichern (Seite, Plugin-Einträge, Import) halten sie vom Prüfen der Bilder bis
 * zum Schreiben, so laufen sie nacheinander, unabhängig von der Sperre der PHP-Session: Verwerfen löscht nie ein Bild, das
 * ein Speichern gerade festschreibt, und ein Speichern danach merkt, dass die Datei fehlt (le_upload_missing).
 * Ist sie belegt, wartet es höchstens LE_OPEN_UPLOADS_LOCK_TIMEOUT Sekunden, dann 503 (API_TEXT['uploadsBusy']); geht sie
 * gar nicht (Cache nicht beschreibbar), 500 wie beim Schreiben. Mit $wait = false (Aufräumen nebenher) weder Warten
 * noch Antwort: Ohne Sperre entfällt $work, null.
 */
function le_open_uploads_hold(callable $work, bool $wait = true): mixed
{
    static $held = false;
    if ($held) {
        return $work();
    }
    $lock = le_open_uploads_lock($wait);
    if ($lock === null) {
        return null;
    }
    $held = true;
    try {
        return $work();
    } finally {
        $held = false;
        store_unlock($lock);
    }
}

/** Sperre für le_open_uploads_hold: Handle, sonst (nur ohne $wait) null; mit $wait antwortet es selbst. */
function le_open_uploads_lock(bool $wait)
{
    try {
        ensure_dir(CACHE_ROOT);
        $lock = @fopen(LE_OPEN_UPLOADS_LOCK, 'c');
    } catch (RuntimeException $e) {
        $lock = false;
    }
    $deadline = microtime(true) + LE_OPEN_UPLOADS_LOCK_TIMEOUT;
    $busy = 0;
    while ($lock !== false) {
        if (flock($lock, LOCK_EX | LOCK_NB, $busy)) {
            return $lock;
        }
        if (!$busy || !$wait || microtime(true) >= $deadline) {
            fclose($lock);
            break;
        }
        usleep(LE_OPEN_UPLOADS_LOCK_POLL_MS * 1000);
    }
    if ($wait || !$busy) {
        error_log($busy ? 'open uploads: lock busy, gave up' : 'open uploads: lock failed');
    }
    if (!$wait) {
        return null;
    }
    json_response(['ok' => false, 'error' => $busy ? API_TEXT['uploadsBusy'] : write_failed_message()], $busy ? 503 : 500);
}

/**
 * Ändert die Liste unter Sperre (le_open_uploads_hold): $change(array $list): array liefert die neue (unverändert: kein
 * Schreiben). Eine kaputte Liste wird vorher nach LE_OPEN_UPLOADS_BROKEN_FILE kopiert und rekonstruiert. Wirft, wenn sich
 * die Liste nicht schreiben lässt (keine Antwort an den Browser: Aufrufer wie das Aufräumen nach einem Upload loggen nur).
 */
function le_open_uploads_change(callable $change): void
{
    le_open_uploads_hold(static function () use ($change): void {
        $stored = le_open_uploads_stored();
        if ($stored === null) {
            error_log('open uploads: broken list, rebuilt from files, copy in ' . LE_OPEN_UPLOADS_BROKEN_FILE);
            if (@copy(LE_OPEN_UPLOADS_FILE, LE_OPEN_UPLOADS_BROKEN_FILE)) {
                @chmod(LE_OPEN_UPLOADS_BROKEN_FILE, PRIVATE_FILE_MODE);
            }
        }
        $list = $stored ?? le_open_uploads_recover();
        $changed = $change($list);
        if (($changed !== $list || $stored === null)
            // Mit Benutzernamen: nur für den Eigentümer lesbar wie das Aktivitäts-Log.
            && !le_atomic_write(LE_OPEN_UPLOADS_FILE, (string) json_encode($changed, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), true)) {
            throw new RuntimeException('Cannot write open uploads');
        }
    });
}

/** Merkt sich die Upload-Datei $file als offen für das Formular $form ('' ohne: nur die Frist räumt sie weg). */
function le_open_upload_add(string $file, string $form, string $user, int $now): void
{
    le_open_uploads_change(static function (array $list) use ($file, $form, $user, $now): array {
        $list[$file] = ['form' => $form, 'user' => $user, 'time' => $now];
        return $list;
    });
}

/**
 * Setzt bzw. nimmt am offenen Upload $file das Kennzeichen LE_OPEN_UPLOAD_UNSEEN; ist er nicht (mehr) offen, nichts.
 * Wirft wie le_open_uploads_change.
 */
function le_open_upload_unseen(string $file, bool $unseen): void
{
    le_open_uploads_change(static function (array $list) use ($file, $unseen): array {
        if (is_array($list[$file] ?? null)) {
            unset($list[$file][LE_OPEN_UPLOAD_UNSEEN]);
            if ($unseen) {
                $list[$file][LE_OPEN_UPLOAD_UNSEEN] = true;
            }
        }
        return $list;
    });
}

/**
 * Die Adresse $url soll den Browser erreichen (imageDerive, imageInfo): Ein offener Upload darunter verliert
 * LE_OPEN_UPLOAD_UNSEEN und geht nicht mehr mit seiner abgeleiteten Datei. Ohne Kennzeichen kein Schreiben. Lässt sich
 * die Liste nicht schreiben, 500 (write_failed_message) statt der Adresse: Sonst ginge das Original später mit.
 */
function le_open_upload_seen(string $url): void
{
    $file = upload_file_name($url);
    if ($file === null || empty(le_open_uploads()[$file][LE_OPEN_UPLOAD_UNSEEN])) {
        return;
    }
    try {
        le_open_upload_unseen($file, false);
    } catch (Throwable $e) {
        error_log('open upload seen failed: ' . $e->getMessage());
        json_response(['ok' => false, 'error' => write_failed_message()], 500);
    }
}

/**
 * Erledigt offene Uploads: Einträge, für die $match(array $entry, string $file) zutrifft, fallen aus der Liste, ihre
 * Dateien werden gelöscht, sofern unbenutzt (delete_unused_uploads: gespeicherte bleiben). Liefert die gelöschten Dateinamen.
 */
function le_open_uploads_close(callable $match): array
{
    return le_open_uploads_hold(static function () use ($match): array {
        $closed = [];
        le_open_uploads_change(static function (array $list) use ($match, &$closed): array {
            foreach ($list as $file => $entry) {
                if ($match((array) $entry, (string) $file)) {
                    $closed[] = UPLOADS_URL . $file;
                    unset($list[$file]);
                }
            }
            return $list;
        });

        return delete_unused_uploads($closed);
    });
}

/**
 * Erledigt die offenen Uploads, die älter als LE_OPEN_UPLOAD_MAX_AGE sind (Formular nie geschlossen). Aufräumen nebenher
 * (nach Upload und Verwerfen): Ist die Sperre gerade belegt, entfällt es diesmal; ein Fehler (z. B. Liste nicht
 * schreibbar) kommt nur ins Log, die Anfrage davor bleibt gelungen. Liefert die gelöschten Dateinamen.
 */
function le_open_uploads_expire(int $now): array
{
    $expired = static fn (array $entry): bool => (int) ($entry['time'] ?? 0) < $now - LE_OPEN_UPLOAD_MAX_AGE;
    try {
        return le_open_uploads_hold(static fn (): array => le_open_uploads_close($expired), false) ?? [];
    } catch (Throwable $e) {
        error_log('open uploads expire failed: ' . $e->getMessage());
        return [];
    }
}

/**
 * Erledigt die offenen Uploads des Formulars $form von $user, mit $files (Dateinamen) nur diese. null, wenn eine
 * davon dort nicht offen ist (fremd, schon erledigt, erfunden): dann bleibt alles, wie es ist. Mit einer abgeleiteten
 * Datei geht ihr Original nur, wenn der Browser es nie bekam (LE_OPEN_UPLOAD_UNSEEN, Upload mit maxWidth), es dort offen
 * ist und keine andere abgeleitete Datei mehr daran hängt (le_images_released_originals).
 */
function le_open_uploads_discard(string $form, string $user, ?array $files): ?array
{
    $owned = static fn (array $entry): bool => ($entry['form'] ?? null) === $form && ($entry['user'] ?? null) === $user;

    return le_open_uploads_hold(static function () use ($owned, $files): ?array {
        $open = le_open_uploads();
        foreach ($files ?? [] as $file) {
            if (!isset($open[$file]) || !$owned((array) $open[$file])) {
                return null;
            }
        }
        if ($files !== null) {
            // Nur nie gezeigte Originale; ob sie in diesem Formular offen sind, prüft das Erledigen darunter ($owned).
            $originals = array_filter(le_images_released_originals($files), static fn (string $file): bool => !empty($open[$file][LE_OPEN_UPLOAD_UNSEEN]));
            $files = [...$files, ...$originals];
        }

        return le_open_uploads_close(static fn (array $entry, string $file): bool => $owned($entry) && ($files === null || in_array($file, $files, true)));
    });
}

/**
 * Datei annehmen (api/media/upload.php): $file aus $_FILES['file'], $form die Kennung des Formulars, aus dem hochgeladen
 * wird (shared/upload.js; bis es gespeichert oder verworfen ist, bleibt der Upload offen), $contentLength die Größe der
 * Anfrage, $userId der angemeldete Benutzer. Prüft Größe, Endung und Inhalt (Upload-Whitelist, svg_is_safe, PDF-Kopf),
 * rechnet JPG und PNG in WebP um und entfernt Metadaten; jede Ablehnung 400 mit Meldung aus UPLOAD_TEXT bzw. API_TEXT.
 * Legt die Datei unter einem neuen Namen in UPLOADS_ROOT ab und merkt sie als offen (scheitert es: 500 store). Mit
 * $maxWidth (höchste Anzeigebreite, le_image_max_width; ungültig 400 vor dem Ablegen) zusätzlich die abgeleitete Datei
 * (le_image_derive), sofern sie schmaler wird und der Server sie rechnen kann; sonst bleibt es beim Upload wie ohne.
 * Liefert den Dateinamen, mit abgeleiteter Datei deren.
 */
function le_upload_accept(mixed $file, mixed $form, int $contentLength, string $userId, mixed $kind = '', mixed $maxWidth = null): string
{
    // Bildbearbeitung erst hier: openUploads.php laden auch Speichern und die Plugin-Schnittstelle.
    require_once LE_BACKEND . '/media/images.php';
    // Über post_max_size verwirft PHP den ganzen Body, $_FILES bleibt leer.
    if (empty($file) || !is_array($file)) {
        $tooLarge = $contentLength > upload_max_bytes();
        json_response(['ok' => false, 'error' => $tooLarge ? upload_too_large_message() : UPLOAD_TEXT['noFile']], 400);
    }
    if (!le_upload_form_valid($form) || !in_array($kind, ['', LE_UPLOAD_KIND_IMAGE], true)) {
        json_response(['ok' => false, 'error' => API_TEXT['invalidRequest']], 400);
    }
    $maxWidth = le_image_max_width($maxWidth);

    $error = $file['error'] ?? UPLOAD_ERR_NO_FILE;
    if (($error === UPLOAD_ERR_INI_SIZE || $error === UPLOAD_ERR_FORM_SIZE) || ($error === UPLOAD_ERR_OK && ($file['size'] ?? 0) > upload_max_bytes())) {
        json_response(['ok' => false, 'error' => upload_too_large_message()], 400);
    }
    if ($error !== UPLOAD_ERR_OK) {
        json_response(['ok' => false, 'error' => UPLOAD_TEXT['failed']], 400);
    }

    $originalName = (string) ($file['name'] ?? '');
    $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    // Aus einem Bildfeld nur Bilder, sonst (Dateifeld, Mediathek) auch Dokumente.
    $allowed = $kind === LE_UPLOAD_KIND_IMAGE ? UPLOAD_MIME_TYPES : LE_UPLOAD_TYPES;
    if (!isset($allowed[$extension])) {
        json_response(['ok' => false, 'error' => sprintf(UPLOAD_TEXT['type'], implode(', ', array_keys($allowed)))], 400);
    }
    $document = isset(LE_UPLOAD_DOCUMENT_TYPES[$extension]);

    $tmp = (string) ($file['tmp_name'] ?? '');
    $mime = mime_content_type($tmp) ?: '';
    // Endung und tatsächlicher Inhalt müssen zusammenpassen (LE_UPLOAD_TYPES).
    if (!in_array($mime, LE_UPLOAD_TYPES[$extension], true)) {
        json_response(['ok' => false, 'error' => UPLOAD_TEXT['content']], 400);
    }
    if ($extension === 'svg' && !svg_is_safe((string) file_get_contents($tmp))) {
        json_response(['ok' => false, 'error' => UPLOAD_TEXT['svg']], 400);
    }
    // PDF: Kopf prüfen, sonst unverändert ablegen (keine Bildbearbeitung, keine Metadaten-Bereinigung).
    if ($extension === 'pdf' && (string) file_get_contents($tmp, false, null, 0, strlen(LE_UPLOAD_PDF_SIGNATURE)) !== LE_UPLOAD_PDF_SIGNATURE) {
        json_response(['ok' => false, 'error' => UPLOAD_TEXT['pdf']], 400);
    }

    // JPG und PNG als verkleinertes WebP (media/images.php), vor der Sperre: Das Umrechnen kann dauern. null: unverändert.
    le_image_memory_raise();
    $webp = $document ? null : le_image_optimized($tmp, $extension);
    // Ein JPG nie im Original speichern (EXIF mit GPS-Position, Gerät): lässt es sich nicht umrechnen, ablehnen.
    if ($webp === null && in_array($extension, ['jpg', 'jpeg'], true)) {
        json_response(['ok' => false, 'error' => UPLOAD_TEXT['notConvertible']], 400);
    }
    // Unverändert gespeicherte PNG und WebP ohne Metadaten (EXIF mit GPS-Position, XMP, Text); unlesbare ablehnen.
    $content = null;
    if ($webp === null && $extension !== 'svg' && !$document) {
        $content = le_image_without_metadata((string) file_get_contents($tmp), $extension);
        if ($content === null) {
            json_response(['ok' => false, 'error' => UPLOAD_TEXT['damaged']], 400);
        }
    }

    $targetName = le_upload_new_name($originalName, $webp !== null ? 'webp' : $extension);
    le_upload_store($targetName, $form, $userId, $webp ?? $content, $tmp);
    $derived = $maxWidth !== null && isset(LE_IMAGE_DERIVE_TYPES[pathinfo($targetName, PATHINFO_EXTENSION)])
        ? le_image_derive(UPLOADS_URL . $targetName, null, $maxWidth, $form, $userId)['file'] ?? null : null;
    if ($derived !== null) {
        // Die Antwort nennt nur die abgeleitete Datei: Das Original bekommt der Browser nicht.
        try {
            le_open_upload_unseen($targetName, true);
        } catch (Throwable $e) {
            error_log('open upload unseen failed: ' . $e->getMessage());
        }
        return $derived;
    }
    return $targetName;
}

/** Ob $form als Kennung eines Formulars taugt: leer (dann erledigt nur die Frist den Upload) oder LE_UPLOAD_FORM_PATTERN. */
function le_upload_form_valid(mixed $form): bool
{
    return is_string($form) && ($form === '' || preg_match(LE_UPLOAD_FORM_PATTERN, $form) === 1);
}

/**
 * Neuer Dateiname in UPLOADS_ROOT zu $name (Dateiname, auch mit Endung): ohne Endung, andere Zeichen als a-zA-Z0-9._-
 * werden „-“, leer LE_UPLOAD_DEFAULT_NAME; dazu „-“ und LE_UPLOAD_NAME_RANDOM_BYTES Zufall als Hex (eindeutig für die
 * Suche nach Verwendungen), $suffix (abgeleitete Datei: „-<Breite>“) und die Endung $extension.
 */
function le_upload_new_name(string $name, string $extension, string $suffix = ''): string
{
    $safeName = trim((string) preg_replace('/[^a-zA-Z0-9._-]/', '-', pathinfo($name, PATHINFO_FILENAME)), '-_.') ?: LE_UPLOAD_DEFAULT_NAME;

    return $safeName . '-' . bin2hex(random_bytes(LE_UPLOAD_NAME_RANDOM_BYTES)) . $suffix . '.' . $extension;
}

/**
 * Legt eine neue Datei $name in UPLOADS_ROOT ab: $bytes über le_image_write, ohne ($bytes null) die hochgeladene Datei
 * $tmp über move_uploaded_file. Erst als offen für $form und $userId merken, dann ablegen: So liegt keine Datei, die die
 * Liste nicht kennt. Beides unter der Sperre der Liste, sonst könnte ein Verwerfen den Eintrag dazwischen erledigen und
 * die Datei danach unbekannt liegen bleiben. $derived (abgeleitete Datei): ihr Eintrag in LE_IMAGES_FILE, im selben Zug
 * und unter derselben Sperre vor dem Ablegen. Scheitert etwas, fallen die Einträge wieder weg und die Antwort ist 500
 * store. Danach abgelaufene offene Uploads aufräumen.
 */
function le_upload_store(string $name, string $form, string $userId, ?string $bytes, string $tmp = '', ?array $derived = null): void
{
    require_once LE_BACKEND . '/media/images.php';
    le_uploads_prepare();
    $path = UPLOADS_ROOT . '/' . $name;
    $now = time();
    $stored = false;
    try {
        $stored = le_open_uploads_hold(static function () use ($name, $form, $userId, $now, $tmp, $path, $bytes, $derived): bool {
            if ($derived !== null) {
                le_images_add($name, $derived);
            }
            le_open_upload_add($name, $form, $userId, $now);
            if ($bytes === null ? move_uploaded_file($tmp, $path) : le_image_write($path, $bytes)) {
                return true;
            }
            le_open_uploads_close(static fn (array $entry, string $file): bool => $file === $name);
            if ($derived !== null) {
                le_images_forget([$name]);
            }
            return false;
        });
    } catch (Throwable $e) {
        error_log('open upload failed: ' . $e->getMessage());
    }
    if (!$stored) {
        json_response(['ok' => false, 'error' => UPLOAD_TEXT['store']], 500);
    }
    // Fallback für nie geschlossene Formulare; scheitert er, ist der Upload trotzdem da.
    le_open_uploads_expire($now);
}
