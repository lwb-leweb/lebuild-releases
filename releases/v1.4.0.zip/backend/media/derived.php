<?php
declare(strict_types=1);

// Abgeleitete Bilder: Zuschnitt oder kleinere Breite eines Originals (Upload oder Bild der Website), gerechnet immer aus
// dem Original, abgelegt als neuer Upload <name>-<hex>-<breite>.webp. Je abgeleitete Datei ein Eintrag in LE_IMAGES_FILE
// (Dateiname => {original, crop, width}). Ein Original gilt als verwendet, solange eine seiner abgeleiteten Dateien
// verwendet ist (uploads_in_use, le_media_status); mit der abgeleiteten Datei fällt ihr Eintrag weg (delete_unused_uploads).
// Die Liste ändert sich nur unter der Sperre der offenen Uploads (le_open_uploads_hold), unter der auch jede neue Datei
// abgelegt wird: eine Sperre für beides, nie zwei verschachtelt.

require_once LE_BACKEND . '/base/files.php';
require_once LE_BACKEND . '/base/http.php';
require_once LE_BACKEND . '/base/texts.php';
require_once LE_BACKEND . '/media/uploads.php';
// Offene Uploads (Sperre, Ablegen) und Bildbearbeitung laden erst die Funktionen, die sie brauchen: usage.php lädt diese
// Datei, und wer nur Verwendungen prüft (Plugin-Einträge), lädt so nicht mehr als vorher.

// Meldungen beim Ableiten und Nachschlagen (api/media/derive.php, api/media/info.php); ohne GD wie beim Upload
// (UPLOAD_TEXT['notConvertible']).
const LE_IMAGE_DERIVE_TEXT = [
    // Fremde Adresse, SVG, PDF, Datei fehlt: kein Original, aus dem der Server rechnen kann.
    'source' => 'Von diesem Bild lässt sich kein Ausschnitt anlegen.',
    // Rechteck nicht aus ganzen Zahlen x, y, w, h oder nicht ganz im Bild.
    'crop' => 'Der Ausschnitt liegt nicht ganz im Bild.',
];
// Schlüssel eines Ausschnitts (Pixel des Originals, wie es angezeigt wird): links, oben, Breite, Höhe.
const LE_IMAGE_CROP_KEYS = ['x', 'y', 'w', 'h'];

/** Abgeleitete Dateien: Dateiname => ['original' => Adresse, 'crop' => {x, y, w, h} | null, 'width' => Pixel]; [] ohne Liste. Wirft, wenn sie kaputt oder unlesbar ist. */
function le_images(): array
{
    if (!is_file(LE_IMAGES_FILE)) {
        return [];
    }
    $list = json_decode((string) @file_get_contents(LE_IMAGES_FILE), true);
    if (!is_array($list)) {
        throw new RuntimeException('broken ' . basename(LE_IMAGES_FILE));
    }

    return $list;
}

/**
 * Ändert die Liste unter der Sperre der offenen Uploads (le_open_uploads_hold, $wait wie dort): $change(array $list): array
 * liefert die neue. Vorher fallen Einträge weg, deren Datei fehlt (ein Löschen, das die Sperre nicht bekam). Liefert, ob
 * die Sperre zu haben war; wirft, wenn sich die Liste nicht lesen oder schreiben lässt.
 */
function le_images_change(callable $change, bool $wait = true): bool
{
    require_once LE_BACKEND . '/media/openUploads.php';
    return le_open_uploads_hold(static function () use ($change): bool {
        $stored = le_images();
        $list = array_filter($stored, static fn (mixed $entry, int|string $file): bool => le_images_entry_alive($file), ARRAY_FILTER_USE_BOTH);
        $changed = $change($list);
        if ($changed !== $stored) {
            ensure_dir(dirname(LE_IMAGES_FILE));
            write_file_atomic(LE_IMAGES_FILE, (string) json_encode($changed, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
        }
        return true;
    }, $wait) ?? false;
}

/** Ob der Eintrag $file (Schlüssel in LE_IMAGES_FILE) noch gilt: ein gültiger Upload-Name, dessen Datei es gibt. */
function le_images_entry_alive(int|string $file): bool
{
    return upload_file_name(UPLOADS_URL . $file) !== null && is_file(UPLOADS_ROOT . '/' . $file);
}

/** Trägt die abgeleitete Datei $file mit $entry (original, crop, width) ein; nur unter le_upload_store, vor dem Ablegen. */
function le_images_add(string $file, array $entry): void
{
    le_images_change(static fn (array $list): array => [$file => $entry] + $list);
}

/**
 * Nimmt die Einträge der Dateien $files heraus (gelöscht oder nie abgelegt). Hält die Anfrage die Sperre der offenen
 * Uploads schon, darunter; sonst ohne zu warten (ein Aufrufer wie die Deinstallation hält andere Sperren): Ist sie
 * belegt, fällt der Eintrag beim nächsten Ändern weg (le_images_change). Wirft nie.
 */
function le_images_forget(array $files): void
{
    try {
        $gone = array_flip(array_map('strval', $files));
        if (array_intersect_key(le_images(), $gone) === []) {
            return;
        }
        if (!le_images_change(static fn (array $list): array => array_diff_key($list, $gone), false)) {
            error_log('images: list busy, entries of ' . implode(', ', array_keys($gone)) . ' go with the next change');
        }
    } catch (Throwable $e) {
        error_log('images forget failed: ' . $e->getMessage());
    }
}

/**
 * Die eine Zuordnung Original → abgeleitete Dateien: zu den Adressen $urls (Originale) je die abgeleiteten Dateien, die
 * es noch gibt (Eintrag in LE_IMAGES_FILE und Datei in UPLOADS_ROOT): [Adresse => [Dateiname => Eintrag]], nur Originale
 * mit mindestens einer. Wirft wie le_images.
 */
function le_images_derived(array $urls): array
{
    $wanted = array_flip(array_filter($urls, 'is_string'));
    $of = [];
    foreach (le_images() as $file => $entry) {
        $original = is_array($entry) ? ($entry['original'] ?? null) : null;
        if (is_string($original) && isset($wanted[$original]) && le_images_entry_alive($file)) {
            $of[$original][(string) $file] = $entry;
        }
    }

    return $of;
}

/**
 * Namen der abgeleiteten Dateien je Original aus $byUrl (Ergebnis von le_images_derived) unter dem Schlüssel $keys[Adresse]
 * (z. B. dem Dateinamen des Originals), für le_images_inherit_status: [Schlüssel => [Dateiname…]]; Originale ohne Schlüssel
 * fehlen, Originale mit demselben Schlüssel teilen sich die Liste.
 */
function le_images_derived_names(array $byUrl, array $keys): array
{
    $names = [];
    foreach ($byUrl as $original => $entries) {
        $key = $keys[$original] ?? null;
        if ($key !== null) {
            $names[(string) $key] = [...($names[(string) $key] ?? []), ...array_map('strval', array_keys($entries))];
        }
    }

    return $names;
}

/**
 * Upload-Dateinamen der Originale der abgeleiteten Dateien $files, an denen keine andere abgeleitete Datei mehr hängt
 * (le_images_derived); ob der Browser sie kennt, prüft le_open_uploads_discard. Kaputte Liste: keine.
 */
function le_images_released_originals(array $files): array
{
    try {
        $images = le_images();
        $originals = [];
        foreach ($files as $file) {
            $original = is_array($images[$file] ?? null) ? ($images[$file]['original'] ?? null) : null;
            if (is_string($original) && upload_file_name($original) !== null) {
                $originals[] = $original;
            }
        }
        $released = [];
        foreach (le_images_derived($originals) as $original => $derived) {
            if (array_diff(array_keys($derived), $files) === []) {
                $released[] = (string) upload_file_name($original);
            }
        }
        return $released;
    } catch (Throwable $e) {
        error_log('images released originals: ' . $e->getMessage());
        return [];
    }
}

/**
 * Die eine Regel „ein Original hat mindestens den Status seiner abgeleiteten Dateien“: $status (Name => Wert, Originale
 * und ihre abgeleiteten Dateien aus $derivedOf: Schlüssel in $status => [Dateiname…], aus le_images_derived) mit dem Wert jedes Originals angehoben auf den
 * stärksten seiner abgeleiteten Dateien; $order nennt die Werte vom schwächsten zum stärksten.
 */
function le_images_inherit_status(array $status, array $derivedOf, array $order): array
{
    foreach ($derivedOf as $original => $files) {
        if (!array_key_exists($original, $status)) {
            continue;
        }
        foreach ($files as $file) {
            if (array_key_exists($file, $status) && array_search($status[$file], $order, true) > array_search($status[$original], $order, true)) {
                $status[$original] = $status[$file];
            }
        }
    }

    return $status;
}

/**
 * Original zu $source (Bildwert oder Pfad, wie der Browser ihn anfragt): %XX wird genau einmal dekodiert, wie der Router
 * die Anfrage liest („/assets/Team%20Foto.png“; doppelt Kodiertes findet danach keine Datei). Dann wird die Adresse
 * einheitlich (le_upload_site_url: auch so, wie sie im Markup steht, „assets/a.png“, „/uploads/b.webp“; nur vorhandene
 * Dateien, kein Ausbruch aus dem Ordner, keine Punkt-Stücke „./“, „../“, die löst der Browser auf), dann steht eine abgeleitete
 * Datei (Eintrag in LE_IMAGES_FILE) für ihr Original; sonst ist sie selbst das Original, ein Upload oder ein Bild der
 * Website mit Endung aus LE_IMAGE_DERIVE_TYPES. Fremde Adressen, SVG, PDF, fehlende Dateien: 400 source; Inhalt passt
 * nicht zur Endung: 400 content. Liefert url (einheitlich), address (das Original in der Form, die in den Bildwert gehört:
 * wie es kam, dekodiert wie ein gespeicherter Wert, bei einer abgeleiteten Datei wie es beim Ableiten kam), path, info (getimagesize), orientation, width und
 * height (wie angezeigt) des Originals und derived (Eintrag der Quelle, null für ein Original).
 */
function le_image_source(mixed $source): array
{
    require_once LE_BACKEND . '/media/images.php';
    $source = is_string($source) ? rawurldecode($source) : null;
    $given = $source !== null ? le_upload_site_url($source) : null;
    $file = $given !== null ? upload_file_name($given) : null;
    try {
        $entry = $file !== null ? (le_images()[$file] ?? null) : null;
    } catch (Throwable $e) {
        // Kaputte Liste: die Quelle gilt als Original; Ablegen scheitert danach ohnehin (le_upload_store).
        error_log('image source: ' . $e->getMessage());
        $entry = null;
    }
    $url = is_array($entry) ? ($entry['original'] ?? null) : $given;
    $address = is_array($entry) ? ($entry['address'] ?? $url) : $source;
    $type = is_string($url) ? (LE_IMAGE_DERIVE_TYPES[strtolower(pathinfo($url, PATHINFO_EXTENSION))] ?? null) : null;
    $path = $type !== null ? le_upload_image_path($url) : null;
    if ($path === null) {
        json_response(['ok' => false, 'error' => LE_IMAGE_DERIVE_TEXT['source']], 400);
    }
    $info = le_image_info($path, $type);
    if ($info === null) {
        json_response(['ok' => false, 'error' => UPLOAD_TEXT['content']], 400);
    }
    $size = le_image_display_size($path);
    if ($size === null) {
        json_response(['ok' => false, 'error' => UPLOAD_TEXT['content']], 400);
    }
    [$width, $height] = $size;
    $orientation = le_image_orientation($path, $type);

    return ['url' => $url, 'address' => $address, 'path' => $path, 'info' => $info, 'orientation' => $orientation, 'width' => $width,
        'height' => $height, 'derived' => is_array($entry) ? $entry : null];
}

/**
 * Ausschnitt $crop im Original von $width × $height Pixeln: null (fehlt) oder genau die Schlüssel LE_IMAGE_CROP_KEYS
 * als ganze Zahlen, Breite und Höhe mindestens 1, ganz im Bild; sonst 400 crop. Das ganze Bild ist kein Zuschnitt: null.
 */
function le_image_crop(mixed $crop, int $width, int $height): ?array
{
    if ($crop === null) {
        return null;
    }
    $valid = is_array($crop) && count($crop) === count(LE_IMAGE_CROP_KEYS)
        && array_filter(LE_IMAGE_CROP_KEYS, static fn (string $key): bool => !is_int($crop[$key] ?? null)) === [];
    if (!$valid || $crop['x'] < 0 || $crop['y'] < 0 || $crop['w'] < 1 || $crop['h'] < 1 || $crop['x'] + $crop['w'] > $width || $crop['y'] + $crop['h'] > $height) {
        json_response(['ok' => false, 'error' => LE_IMAGE_DERIVE_TEXT['crop']], 400);
    }
    if ($crop['x'] === 0 && $crop['y'] === 0 && $crop['w'] === $width && $crop['h'] === $height) {
        return null;
    }

    return ['x' => $crop['x'], 'y' => $crop['y'], 'w' => $crop['w'], 'h' => $crop['h']];
}

/** Höchste Anzeigebreite (CSS-Pixel) aus der Anfrage: fehlt (null, leer) null, sonst eine positive ganze Zahl (auch als Text aus einem Formular); anderes 400. */
function le_image_max_width(mixed $value): ?int
{
    if ($value === null || $value === '') {
        return null;
    }
    $width = is_int($value) || is_string($value) ? filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]) : false;
    if ($width === false) {
        json_response(['ok' => false, 'error' => API_TEXT['invalidRequest']], 400);
    }

    return $width;
}

/**
 * Abgeleitete Datei zu $source (api/media/derive.php, le_upload_accept mit maxWidth), gerechnet aus dem Original
 * (le_image_source): $crop (le_image_crop; fehlt: das ganze Original) auf die Breite min(LE_IMAGE_DENSITY × $maxWidth,
 * Breite des Ausschnitts bzw. Originals, LE_IMAGE_MAX_WIDTH). Eine neue Datei <name>-<hex>-<breite>.webp entsteht nur, wenn sie zuschneidet
 * oder schmaler wird; sie ist ein offener Upload von $form wie jeder Upload und steht in LE_IMAGES_FILE (le_upload_store).
 * Geht die Adresse des Originals zurück (in der Form, wie es kam, le_image_source address), kennt der Browser es
 * (le_open_upload_seen). Der Eintrag merkt sich diese Form, wenn sie von der einheitlichen abweicht (address).
 * Ungültige Anfrage 400. Liefert ['url' => Adresse der neuen Datei bzw. des Originals, 'file' => neuer Dateiname oder
 * null]; null, wenn der Server das Bild nicht rechnen kann (GD ohne WebP, animiertes PNG, zu groß, Fehler von GD).
 */
function le_image_derive(mixed $source, mixed $crop, mixed $maxWidth, mixed $form, string $userId): ?array
{
    require_once LE_BACKEND . '/media/openUploads.php';
    if (!le_upload_form_valid($form)) {
        json_response(['ok' => false, 'error' => API_TEXT['invalidRequest']], 400);
    }
    $maxWidth = le_image_max_width($maxWidth);
    $original = le_image_source($source);
    $crop = le_image_crop($crop, $original['width'], $original['height']);
    $fullWidth = $crop['w'] ?? $original['width'];
    $fullHeight = $crop['h'] ?? $original['height'];
    // Höchstens LE_IMAGE_MAX_WIDTH wie jeder Upload; ein Bild ohne Zuschnitt und ohne maxWidth bleibt aber, wie es ist.
    $width = (int) min($fullWidth, LE_IMAGE_MAX_WIDTH, $maxWidth === null ? PHP_INT_MAX : LE_IMAGE_DENSITY * $maxWidth);
    if ($crop === null && ($maxWidth === null || $width >= $original['width'])) {
        le_open_upload_seen($original['url']);
        return ['url' => $original['address'], 'file' => null];
    }
    if (!le_image_webp_supported() || ($original['info'][2] === IMAGETYPE_PNG && le_image_png_animated($original['path']))) {
        return null;
    }
    $height = max(1, (int) round($fullHeight * $width / $fullWidth));
    $orientation = $original['orientation'];
    $rect = $crop === null ? null : [$crop['x'], $crop['y'], $crop['w'], $crop['h']];
    // Zwischenbilder: das gedrehte Original (nur bei einer Drehung) und das Ergebnis.
    $morePixels = $width * $height + (isset(LE_IMAGE_ORIENTATION_ANGLES[$orientation]) ? $original['width'] * $original['height'] : 0);
    le_image_memory_raise();
    $data = le_image_webp($original['path'], $original['info'], $morePixels,
        static fn (GdImage $image): GdImage => le_image_resampled(le_image_oriented($image, $orientation), $width, $height, $rect));
    if ($data === null) {
        return null;
    }
    $file = le_upload_new_name(basename($original['url']), 'webp', '-' . $width);
    $entry = ['original' => $original['url'], 'crop' => $crop, 'width' => $width];
    le_upload_store($file, $form, $userId, $data, '', $original['address'] === $original['url'] ? $entry : $entry + ['address' => $original['address']]);

    return ['url' => UPLOADS_URL . $file, 'file' => $file];
}

/**
 * Original und bisheriger Ausschnitt zu $source (api/media/info.php): ['original' => Adresse (einheitlich, zum Anzeigen),
 * 'address' => dieselbe Datei in der Form, die in den Bildwert gehört (le_image_source), 'crop' => {x, y, w, h} |
 * null, 'width' => Breite der Datei $source, 'originalWidth', 'originalHeight' (wie angezeigt)]. Für ein Original ist
 * crop null und width seine Breite. Was kein Original haben kann, 400 wie le_image_source. Das Original kennt der Browser
 * danach (le_open_upload_seen).
 */
function le_image_describe(mixed $source): array
{
    require_once LE_BACKEND . '/media/openUploads.php';
    $original = le_image_source($source);
    le_open_upload_seen($original['url']);

    return [
        'original' => $original['url'],
        'address' => $original['address'],
        'crop' => $original['derived']['crop'] ?? null,
        'width' => (int) ($original['derived']['width'] ?? $original['width']),
        'originalWidth' => $original['width'],
        'originalHeight' => $original['height'],
    ];
}
