<?php
declare(strict_types=1);

// Hochgeladene Dateien wieder entfernen, sobald nichts mehr auf sie verweist
// (z. B. beim Löschen eines Plugin-Eintrags). Verweise zählen als Treffer des
// Dateinamens (zufälliger Suffix aus le_upload_accept). Im Zweifel bleibt die
// Datei liegen: ein falscher Treffer, eine unlesbare Datei oder ein Fehler bei
// der Suche zählen als „verwendet“. Uploads aus Formularen, die noch nicht
// gespeichert oder verworfen sind, führt die Liste offener Uploads (le_open_*).

require_once LE_BACKEND . '/media/uploads.php';
require_once LE_BACKEND . '/plugins/plugins.php';
require_once LE_BACKEND . '/plugins/entries.php';
require_once LE_BACKEND . '/media/derived.php';

// Hier können Seiten auf Uploads verweisen: Seiten-JSON, Seiten-Backups, Snapshots der Quelldateien, Site-Dateien.
const UPLOAD_REFERENCE_ROOTS = [PAGES_ROOT, BACKUPS_ROOT, ORIGINALS_ROOT, LE_SITE_ROOT];
// Einzelne Dateien, die ebenfalls auf Uploads verweisen können: die Einstellungen der Website (Vorschaubild, og:image).
const UPLOAD_REFERENCE_FILES = [LE_SITE_CONFIG_FILE];
// Binärdateien mit diesen Endungen werden nicht durchsucht; alle anderen Dateien gelten als Text.
const UPLOAD_REFERENCE_SKIP_EXTENSIONS = [
    'jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'ico', 'bmp', 'tif', 'tiff',
    'mp4', 'mov', 'webm', 'm4v', 'avi', 'mkv', 'mp3', 'wav', 'ogg', 'm4a',
    'woff', 'woff2', 'ttf', 'otf', 'eot', 'pdf', 'zip', 'gz', 'tar', '7z', 'rar',
];
// Größere Dateien werden nicht eingelesen, sondern zählen als Verwendung (im Zweifel behalten).
const UPLOAD_REFERENCE_MAX_BYTES = 5 * 1024 * 1024;

/**
 * Ob eine Seite, ein Backup, eine Site-Datei, die Einstellungen oder ein Plugin die Upload-Datei $file noch verwendet
 * (uploads_in_use für eine Datei).
 */
function upload_in_use(string $file): bool
{
    return uploads_in_use([$file]) !== [];
}

/**
 * Welche der Upload-Dateien $files eine Seite, ein Backup, eine Site-Datei, die Einstellungen oder ein Plugin noch
 * verwendet: alle Textdateien einmal lesen (le_media_text_files), nicht je Datei; Schluss, sobald alle gefunden sind.
 * Ein Original gilt als verwendet, solange eine seiner abgeleiteten Dateien (LE_IMAGES_FILE) verwendet oder noch offen ist
 * (le_images_inherit_status); sie werden im selben Durchgang gesucht.
 * Im Zweifel verwendet: bei Fehlern (dann alle), unlesbaren oder zu großen Textdateien und Ordner-Links (werden nicht
 * verfolgt, gelten für jede Datei). Liefert die verwendeten Namen.
 */
function uploads_in_use(array $files): array
{
    $files = array_values(array_unique(array_map('strval', $files)));
    try {
        $urls = array_map(static fn (string $file): string => UPLOADS_URL . $file, $files);
        $derivedOf = le_images_derived_names(le_images_derived($urls), array_combine($urls, $files));
        $derived = array_merge([], ...array_values($derivedOf));
        $left = array_fill_keys([...$files, ...$derived], true);
        $used = array_fill_keys(array_keys($left), false);
        $mark = static function (?string $content) use (&$left, &$used): void {
            foreach (array_keys($left) as $file) {
                if ($content === null || str_contains($content, (string) $file)) {
                    $used[$file] = true;
                    unset($left[$file]);
                }
            }
        };
        foreach (UPLOAD_REFERENCE_ROOTS as $root) {
            foreach (le_media_text_files($root) as $content) {
                if ($left === []) {
                    break 2;
                }
                $mark($content);
            }
        }
        foreach (UPLOAD_REFERENCE_FILES as $path) {
            if ($left !== [] && is_file($path)) {
                $content = @file_get_contents($path);
                $mark($content === false ? null : $content);
            }
        }
        foreach (array_keys($left) as $file) {
            if (plugins_upload_in_use((string) $file)) {
                $used[$file] = true;
            }
        }
        // Eine noch offene abgeleitete Datei (Formular nicht gespeichert) hält ihr Original wie eine verwendete.
        $open = [];
        if ($derived !== []) {
            // Offene Uploads erst hier: Wer ohne abgeleitete Dateien prüft (Plugin-Einträge), lädt so viel wie vorher.
            require_once LE_BACKEND . '/media/openUploads.php';
            $open = le_open_uploads();
        }
        foreach ($derived as $file) {
            $used[$file] = $used[$file] || isset($open[$file]);
        }
        $used = le_images_inherit_status($used, $derivedOf, [false, true]);
    } catch (Throwable $e) {
        error_log('uploads_in_use failed: ' . $e->getMessage());
        return $files;
    }

    return array_values(array_filter($files, static fn (string $file): bool => $used[$file]));
}

/**
 * Inhalte der Textdateien unter $root, in denen ein Upload stehen kann (le_media_text_paths); null für eine Datei, die
 * nicht gelesen werden kann oder größer als UPLOAD_REFERENCE_MAX_BYTES ist, und für einen Ordner-Link (zählen als
 * Treffer für jedes Bild). Für uploads_in_use und die Mediathek (le_media_status).
 */
function le_media_text_files(string $root): Generator
{
    foreach (le_media_text_paths($root) as $path) {
        $size = is_dir($path) ? false : @filesize($path);
        $content = $size !== false && $size <= UPLOAD_REFERENCE_MAX_BYTES ? @file_get_contents($path) : false;
        yield $content === false ? null : $content;
    }
}

/**
 * Pfade der Textdateien unter $root (ohne Binärdateien nach UPLOAD_REFERENCE_SKIP_EXTENSIONS, ohne die Uploads selbst:
 * auch ein SVG verweist auf nichts), mit $extensions nur mit diesen Endungen (klein), dazu jeder Ordner-Link (wird nicht
 * verfolgt) und jeder Ordner, der sich nicht lesen lässt (der Rest wird weiter durchlaufen). Ohne Lesen; für
 * le_media_text_files und die Namen der Stellen eines Bildes (le_nav_labels).
 */
function le_media_text_paths(string $root, array $extensions = []): Generator
{
    if (!is_dir($root)) {
        return;
    }
    $dirs = new RecursiveCallbackFilterIterator(
        new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS),
        static fn (SplFileInfo $entry): bool => $entry->getPathname() !== UPLOADS_ROOT
    );
    $entries = new RecursiveIteratorIterator($dirs, RecursiveIteratorIterator::SELF_FIRST, RecursiveIteratorIterator::CATCH_GET_CHILD);
    foreach ($entries as $entry) {
        if ($entry->isDir()) {
            if ($entry->isLink() || !$entry->isReadable() || !$entry->isExecutable()) {
                yield $entry->getPathname();
            }
            continue;
        }
        $extension = strtolower($entry->getExtension());
        if ($entry->isFile() && !str_starts_with($entry->getPathname(), UPLOADS_ROOT . '/')
            && !in_array($extension, UPLOAD_REFERENCE_SKIP_EXTENSIONS, true) && ($extensions === [] || in_array($extension, $extensions, true))) {
            yield $entry->getPathname();
        }
    }
}

/**
 * Plugin-Daten: Spalten aus schema.fields der Haupttabelle (jedes Plugin mit Schema) und der Hook
 * „<plugin>_upload_in_use(string $file): bool“ für alles andere (z. B. JSON-Spalten der Content-Typen).
 * Gilt für installierte Plugins, aktiv oder nicht (die Daten bleiben). Wirft bei Fehlern.
 */
function plugins_upload_in_use(string $file): bool
{
    $state = load_plugins_state();
    foreach (array_unique(array_merge($state['active'], array_keys($state['installed']))) as $name) {
        if (plugin_schema_upload_in_use(plugin_manifest($name), $file)) {
            return true;
        }
        $fn = plugin_hook_function($name, 'upload_in_use');
        if ($fn !== null && $fn($file) !== false) {
            return true;
        }
    }

    return false;
}

/**
 * Löscht die Upload-Dateien zu den Bildwerten $urls, die nirgends mehr verwendet werden (uploads_in_use, einmal für
 * alle). Aufruf erst, nachdem der Eintrag selbst gelöscht ist; wirft nie (der Eintrag ist dann schon weg), Fehler lassen
 * die Datei liegen; der Eintrag einer gelöschten abgeleiteten Datei in LE_IMAGES_FILE fällt mit weg. Ein Original bleibt,
 * solange es noch eine abgeleitete Datei davon gibt (le_images_derived). Liefert die gelöschten Dateinamen.
 */
function delete_unused_uploads(array $urls): array
{
    $candidates = [];
    try {
        $uploadsDir = realpath(UPLOADS_ROOT);
        foreach (array_unique(array_filter($urls, 'is_string')) as $url) {
            $file = upload_file_name($url);
            if ($file === null || $uploadsDir === false) {
                continue;
            }
            $path = UPLOADS_ROOT . '/' . $file;
            $real = realpath($path);
            // Nur echte Dateien direkt in UPLOADS_ROOT, keine Links nach draußen.
            if ($real !== false && !is_link($path) && is_file($real) && dirname($real) === $uploadsDir) {
                $candidates[$file] = $real;
            }
        }
        $used = array_flip(uploads_in_use(array_keys($candidates)));
        $derivedOf = le_images_derived(array_map(static fn (int|string $file): string => UPLOADS_URL . $file, array_keys($candidates)));
    } catch (Throwable $e) {
        error_log('delete_unused_uploads failed: ' . $e->getMessage());
        return [];
    }
    // Erst alles ohne abgeleitete Dateien (auch die abgeleiteten selbst), dann die Originale, deren abgeleitete Dateien
    // dabei alle weggefallen sind: Ein Original geht nie vor seiner letzten abgeleiteten Datei.
    $deleted = [];
    foreach ($candidates as $file => $real) {
        if (!isset($used[(string) $file]) && !isset($derivedOf[UPLOADS_URL . $file]) && @unlink($real)) {
            $deleted[] = (string) $file;
        }
    }
    foreach ($derivedOf as $original => $derived) {
        $file = (string) upload_file_name($original);
        if (!isset($used[$file]) && array_diff(array_keys($derived), $deleted) === [] && @unlink($candidates[$file])) {
            $deleted[] = $file;
        }
    }
    // Mit einer abgeleiteten Datei fällt ihr Eintrag weg (le_images_forget).
    if ($deleted !== []) {
        le_images_forget($deleted);
    }

    return $deleted;
}
