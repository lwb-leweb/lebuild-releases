<?php
declare(strict_types=1);

// Stellen eines Bildfelds auf der Website (?plugin=…&type=…&field=…, optional &id= des Eintrags für seine eigene Seite),
// backend/pages/imagePlaces.php: { ok, places }, je Stelle { label, url }; leer für ein unbekanntes Plugin, einen
// unbekannten Typ oder ein Feld, das kein Bildfeld ist. Eine id, die keine positive ganze Zahl ist, zählt nicht.
// Mit ?page=<Seite> die Seite selbst als Stelle ihrer Bilder (Panel „Bild“ des Seiten-Editors, le_page_places).

require_once LE_BACKEND . '/pages/imagePlaces.php';

$param = static fn (string $name): string => is_string($_GET[$name] ?? null) ? $_GET[$name] : '';

if ($param('page') !== '') {
    json_response(['ok' => true, 'places' => le_page_places($param('page'))]);
}

$id = filter_var($param('id'), FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);

json_response(['ok' => true, 'places' => le_image_places($param('plugin'), $param('type'), $param('field'), $id === false ? null : $id)]);
