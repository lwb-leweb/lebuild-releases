<?php
declare(strict_types=1);

// Abgeleitete Datei (Zuschnitt, kleinere Breite) aus dem Original eines Bildes, backend/media/derived.php.
// Body { source, crop?, maxWidth?, form }; Antwort { ok, url }, ohne neue Datei die Adresse des Originals.

require_once LE_BACKEND . '/users/auth.php';
require_once LE_BACKEND . '/media/derived.php';
require_once LE_BACKEND . '/media/uploads.php';
require_once LE_BACKEND . '/base/activity.php';

$body = read_json_body();
$derived = le_image_derive($body['source'] ?? null, $body['crop'] ?? null, $body['maxWidth'] ?? null, $body['form'] ?? '', (string) current_user()['id']);
if ($derived === null) {
    json_response(['ok' => false, 'error' => UPLOAD_TEXT['notConvertible']], 400);
}
if ($derived['file'] !== null) {
    le_activity_log('image_derived', $derived['file']);
}

json_response(['ok' => true, 'url' => $derived['url']]);
