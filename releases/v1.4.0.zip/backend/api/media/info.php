<?php
declare(strict_types=1);

// Original und bisheriger Ausschnitt eines Bildes (?source=…), backend/media/derived.php: { ok, original, address, crop,
// width, originalWidth, originalHeight }, für ein Original crop null; address ist das Original in der Form für den Bildwert.

require_once LE_BACKEND . '/media/derived.php';

json_response(['ok' => true] + le_image_describe($_GET['source'] ?? null));
