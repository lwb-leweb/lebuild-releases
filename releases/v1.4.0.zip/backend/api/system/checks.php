<?php
declare(strict_types=1);

require_once LE_BACKEND . '/system/checks.php';

$checks = system_checks();
// problems: dieselben Mängel wie im bootstrap, damit das Dashboard nach „Erneut versuchen“ den neuen Stand zeigt.
json_response([
    'ok' => true,
    'checks' => $checks,
    'problems' => system_problems($checks),
]);
