<?php
declare(strict_types=1);

require_once LE_BACKEND . '/plugins/plugins.php';
require_once LE_BACKEND . '/base/db.php';
require_once LE_BACKEND . '/site/indexNow.php';
require_once LE_BACKEND . '/base/activity.php';

// Heilt das Schema, kommen die Eintragsseiten des Plugins zurück in die Sitemap.
le_indexnow_watch();
require_no_db_migration();

$body = read_json_body();
$name = (string) ($body['name'] ?? '');
// Aktivität nur nach einem echten Versuch (es gab einen Fehlerstand), nicht für ein schon geheiltes Plugin.
$retried = le_plugin_schema_retry_or_fail($name);
if ($retried) {
    le_activity_log('plugin_schema_retried', $name);
}

json_response(['ok' => true, 'retried' => $retried]);
