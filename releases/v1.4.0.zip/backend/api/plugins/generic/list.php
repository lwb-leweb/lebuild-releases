<?php
declare(strict_types=1);

require_once LE_BACKEND . '/plugins/plugins.php';
require_once LE_BACKEND . '/base/db.php';
require_once LE_BACKEND . '/plugins/pluginSchema.php';
require_once LE_BACKEND . '/plugins/entries.php';

$name = (string) ($_GET['plugin'] ?? '');
le_require_plugin_name($name);
['manifest' => $manifest, 'table' => $table] = le_plugin_generic_table($name, 'list');

$columns = plugin_schema_field_names($manifest);
$select = '`id`' . ($columns ? ', `' . implode('`, `', $columns) . '`' : '');

try {
    $rows = db()->query("SELECT {$select} FROM `{$table}` ORDER BY `id` DESC")->fetchAll();
} catch (Throwable $e) {
    plugin_failure_response('load', $e);
}

$fields = le_image_usage_columns(plugin_schema_columns($manifest), $name, $table);
json_response([
    'ok' => true,
    'rows' => array_map(static fn (array $row): array => plugin_schema_decode_row($fields, $row), $rows),
    'schema' => $fields,
]);
