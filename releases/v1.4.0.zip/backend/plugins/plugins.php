<?php
declare(strict_types=1);

require_once LE_BACKEND . '/base/db.php';
require_once LE_BACKEND . '/base/files.php';
require_once LE_BACKEND . '/base/http.php';
require_once LE_BACKEND . '/base/texts.php';
require_once LE_BACKEND . '/plugins/hooks.php';
require_once LE_BACKEND . '/plugins/markers.php';

// Schema-Dateien im Plugin-Ordner: sql/<version>.<treiber>.sql, je Version mit Schema-Änderung eine je Treiber
// (plugin_sql_file, docs/knowledgebase/plugins/versioning.md). Gruppen: Version, Treiber; ob es den Treiber gibt (DB_DRIVERS),
// prüft le_plugin_sql_file_parts.
const PLUGIN_SQL_DIR = 'sql';
const PLUGIN_SQL_FILE_PATTERN = '/^(\d+(?:\.\d+)*)\.([a-z]+)\.sql$/';
// Kopie der SQLite-Datei vor neuen Schema-Dateien (le_plugins_schema_pass); bleibt, solange ein Plugin einen Fehlerstand hat.
const LE_PLUGIN_SCHEMA_BACKUP_FILE = DB_SQLITE_FILE . '-vor-schema';
// Merker unter CACHE_ROOT: Plugins mit Fehlerstand als {Plugin: {file, manifest}}, damit die Website ohne Verbindung zur
// Datenbank fragen kann (le_plugin_schema_blocked). Die Wahrheit bleibt LE_PLUGIN_SCHEMA_TABLE: Der Läufer gleicht den
// Merker an, wo er sie liest oder ändert (le_plugin_schema_marker_sync); fehlt er, stellt ihn die nächste Verbindung her.
const LE_PLUGIN_SCHEMA_FAILED_FILE = 'plugin-schema-failed.json';
// Kern-Tabelle der Website-Datenbank: je Plugin Stand des Schemas und Fehlerstand. Sie gehört zur Datenbank, nicht zu
// active-plugins.json (die wandert per Deploy, die Datenbank nicht): mit in Sicherung, Einspielen und Umzug, nicht in den
// Datenabgleich. Fehlt sie oder die Zeile eines Plugins, gilt die Übergangsregel (le_plugin_schema_oldest).
// Tabellen mit diesem Präfix gehören dem Kern; ein Plugin darf keine in tables führen (plugin_table_reserved).
const LE_CORE_TABLE_PREFIX = 'le_';
// Beginnt mit LE_CORE_TABLE_PREFIX (das Fixture zu R8 in tests/plugins/structure.test.php setzt es voraus).
const LE_PLUGIN_SCHEMA_TABLE = 'le_plugin_schema';
// Spalten je Plugin neben id und plugin: Stand, Fehlerstand (Datei, Manifest-Version); Text oder NULL (le_plugin_schema_values).
const LE_PLUGIN_SCHEMA_COLUMNS = ['version', 'failed_file', 'failed_manifest'];
const LE_PLUGIN_SCHEMA_TABLE_SQL = [
    DB_DRIVER_MYSQL => 'CREATE TABLE IF NOT EXISTS ' . LE_PLUGIN_SCHEMA_TABLE . ' (id INT UNSIGNED NOT NULL AUTO_INCREMENT, plugin VARCHAR(64) NOT NULL,'
        . ' version VARCHAR(32) NULL, failed_file VARCHAR(32) NULL, failed_manifest VARCHAR(32) NULL,'
        . ' PRIMARY KEY (id), UNIQUE KEY uniq_plugin (plugin)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
    DB_DRIVER_SQLITE => 'CREATE TABLE IF NOT EXISTS ' . LE_PLUGIN_SCHEMA_TABLE . ' (id INTEGER PRIMARY KEY AUTOINCREMENT,'
        . ' plugin TEXT NOT NULL UNIQUE CHECK (length(plugin) <= 64), version TEXT NULL CHECK (length(version) <= 32),'
        . ' failed_file TEXT NULL CHECK (length(failed_file) <= 32), failed_manifest TEXT NULL CHECK (length(failed_manifest) <= 32))',
];
// Antwort des Hooks site_page, wenn die Adresse dem Plugin gehört, es dort aber nichts gibt (404-Seite der Website).
const PLUGIN_SITE_PAGE_NOT_FOUND = ['notFound' => true];
// plugin_site_page: Die Adresse könnte einem Plugin mit fehlgeschlagenem Schema gehören (503, le_respond_unavailable).
const PLUGIN_SITE_PAGE_UNAVAILABLE = ['unavailable' => true];

function plugin_name_valid(string $name): bool
{
    return (bool) preg_match('/^[a-z][a-z0-9_-]*$/', $name);
}

function plugin_table_name_valid(string $name): bool
{
    return (bool) preg_match('/^[a-z][a-z0-9_]*$/', $name);
}

/** Gehört der Tabellenname dem Kern (LE_CORE_TABLE_PREFIX, etwa LE_PLUGIN_SCHEMA_TABLE)? Dann nicht in tables eines Plugins. */
function plugin_table_reserved(string $name): bool
{
    return str_starts_with($name, LE_CORE_TABLE_PREFIX);
}

function plugin_path(string $name, string $sub = ''): string
{
    if (!plugin_name_valid($name)) {
        throw new InvalidArgumentException('Invalid plugin name: ' . $name);
    }

    $base = LE_PLUGINS . '/' . $name;
    if ($sub === '') {
        return $base;
    }

    $normalized = str_replace('\\', '/', ltrim($sub, '/'));
    if ($normalized === '' || str_contains($normalized, '..')) {
        throw new InvalidArgumentException('Invalid plugin path: ' . $sub);
    }

    return $base . '/' . $normalized;
}

/** Pfad der Schema-Datei für $version und $driver relativ zum Plugin-Ordner (PLUGIN_SQL_FILE_PATTERN). */
function plugin_sql_file(string $version, string $driver): string
{
    return PLUGIN_SQL_DIR . '/' . $version . '.' . $driver . '.sql';
}

/** Version und Treiber aus dem Namen $file einer Schema-Datei (PLUGIN_SQL_FILE_PATTERN, Treiber aus DB_DRIVERS); null für jeden anderen Namen. */
function le_plugin_sql_file_parts(string $file): ?array
{
    return preg_match(PLUGIN_SQL_FILE_PATTERN, $file, $m) === 1 && in_array($m[2], DB_DRIVERS, true) ? [$m[1], $m[2]] : null;
}

/**
 * Schema-Dateien von $name für $driver mit $from < Version ≤ $to (null: ohne Grenze), nach Version sortiert
 * (version_compare): [Version => Pfad]. Einzige Stelle, die sql/ eines Plugins liest; ein sql/, das sich nicht lesen
 * lässt, wirft (RuntimeException), statt als „keine Dateien“ zu gelten.
 */
function le_plugin_schema_files(string $name, string $driver, ?string $from = null, ?string $to = null): array
{
    $dir = plugin_path($name, PLUGIN_SQL_DIR);
    $entries = is_dir($dir) ? @scandir($dir) : [];
    if ($entries === false) {
        throw new RuntimeException('Schema-Dateien von ' . $name . ' lassen sich nicht lesen');
    }
    $files = [];
    foreach ($entries as $entry) {
        [$version, $entryDriver] = le_plugin_sql_file_parts($entry) ?? [null, null];
        if ($version !== null && $entryDriver === $driver
            && ($from === null || version_compare($version, $from, '>')) && ($to === null || version_compare($version, $to, '<='))) {
            $files[$version] = plugin_path($name, plugin_sql_file($version, $driver));
        }
    }
    uksort($files, static fn (int|string $a, int|string $b): int => version_compare((string) $a, (string) $b));

    return $files;
}

/** Meldung, wenn einem Plugin die Schema-Dateien für einen Treiber fehlen; nennt ihr Muster im Plugin (plugin_sql_file). */
function plugin_schema_missing_message(string $name, string $driver): string
{
    return sprintf(API_TEXT['pluginSchemaFilesMissing'], $name, plugin_sql_file('*', $driver), $driver);
}

function plugin_manifest(string $name): array
{
    static $cache = [];

    if (!plugin_name_valid($name)) {
        throw new InvalidArgumentException('Invalid plugin name: ' . $name);
    }
    if (isset($cache[$name])) {
        return $cache[$name];
    }

    $path = plugin_path($name, 'plugin.json');
    if (!is_file($path)) {
        throw new RuntimeException('Plugin manifest not found: ' . $name);
    }

    $data = json_decode((string) file_get_contents($path), true);
    if (!is_array($data)) {
        throw new RuntimeException('Invalid plugin manifest JSON: ' . $name);
    }
    if (($data['name'] ?? '') !== $name) {
        throw new RuntimeException('Plugin manifest name mismatch: ' . $name);
    }
    foreach (['label', 'version', 'requires'] as $required) {
        if (!array_key_exists($required, $data)) {
            throw new RuntimeException('Missing plugin manifest key "' . $required . '": ' . $name);
        }
    }

    $data['requires'] = array_merge(
        ['database' => false, 'mail' => false, 'uploads' => false],
        is_array($data['requires']) ? $data['requires'] : []
    );
    $data['tables'] = plugin_valid_tables($data['tables'] ?? []);
    // Deinstallieren löschte sonst die Tabelle des Kerns, der Abgleich übertrüge sie.
    $reserved = array_values(array_filter($data['tables'], 'plugin_table_reserved'));
    if ($reserved !== []) {
        throw new RuntimeException('Plugin manifest table reserved for the core "' . $reserved[0] . '": ' . $name);
    }
    if (array_key_exists('inlineEdit', $data)) {
        $data['inlineEdit'] = plugin_valid_inline_edit($name, $data['inlineEdit']);
    }

    $cache[$name] = $data;
    return $data;
}

function plugin_valid_tables(mixed $tables): array
{
    if (!is_array($tables)) {
        return [];
    }

    $valid = [];
    foreach ($tables as $table) {
        if (is_string($table) && plugin_table_name_valid($table)) {
            $valid[] = $table;
        }
    }

    return array_values(array_unique($valid));
}

/**
 * inlineEdit aus plugin.json: je Aktion ein Pfad „api/<datei>.php“ (optional mit fester Query),
 * der im Plugin existiert. list, get, save, delete sind Pflicht, sort und preview optional (PLUGIN_INLINE_EDIT_ENDPOINTS).
 */
function plugin_valid_inline_edit(string $name, mixed $inlineEdit): array
{
    $error = new RuntimeException('Invalid plugin manifest key "inlineEdit": ' . $name);
    if (!is_array($inlineEdit) || array_diff_key($inlineEdit, PLUGIN_INLINE_EDIT_ENDPOINTS) !== []) {
        throw $error;
    }

    $valid = [];
    foreach (PLUGIN_INLINE_EDIT_ENDPOINTS as $action => $required) {
        $endpoint = $inlineEdit[$action] ?? null;
        if ($endpoint === null && !$required) {
            continue;
        }
        if (!is_string($endpoint) || !preg_match('#^api/[a-z0-9_-]+\.php(\?[a-z0-9_=&-]+)?$#i', $endpoint)
            || !is_file(plugin_path($name, (string) strtok($endpoint, '?')))) {
            throw $error;
        }
        $valid[$action] = $endpoint;
    }

    return $valid;
}

/** URLs der inlineEdit-Endpoints aller aktiven Plugins, die mitmachen: [Plugin => [Aktion => URL]]. */
function plugin_inline_edit_config(): array
{
    $config = [];
    foreach (load_plugins_state()['active'] as $name) {
        try {
            $inlineEdit = plugin_manifest($name)['inlineEdit'] ?? null;
        } catch (Throwable $e) {
            continue;
        }
        if ($inlineEdit === null) {
            continue;
        }
        $config[$name] = array_map(static fn (string $endpoint): string => PLUGINS_URL . $name . '/' . $endpoint, $inlineEdit);
    }

    return $config;
}

function list_plugin_dirs(): array
{
    if (!is_dir(LE_PLUGINS)) {
        return [];
    }

    $names = [];
    foreach (scandir(LE_PLUGINS) ?: [] as $entry) {
        if ($entry === '.' || $entry === '..' || !plugin_name_valid($entry)) {
            continue;
        }
        if (!is_dir(LE_PLUGINS . '/' . $entry)) {
            continue;
        }
        if (!is_file(LE_PLUGINS . '/' . $entry . '/plugin.json')) {
            continue;
        }
        $names[] = $entry;
    }
    sort($names);

    return $names;
}

function plugins_state_path(): string
{
    return CONTENT_ROOT . '/active-plugins.json';
}

function plugin_data_path(string $name): string
{
    if (!plugin_name_valid($name)) {
        throw new InvalidArgumentException('Invalid plugin name: ' . $name);
    }
    return CONTENT_ROOT . '/plugins/' . $name;
}

function load_plugins_state(): array
{
    $path = plugins_state_path();
    if (!is_file($path)) {
        return ['active' => [], 'installed' => []];
    }

    $data = json_decode((string) file_get_contents($path), true);
    return plugins_state_normalize(is_array($data) ? $data : []);
}

/** Beim Lesen und Schreiben: nur gültige Plugin-Namen, active ohne Doppelte, installed mit geprüften Tabellennamen. */
function plugins_state_normalize(array $state): array
{
    $active = [];
    foreach (is_array($state['active'] ?? null) ? $state['active'] : [] as $name) {
        if (is_string($name) && plugin_name_valid($name)) {
            $active[] = $name;
        }
    }
    $installed = [];
    foreach (is_array($state['installed'] ?? null) ? $state['installed'] : [] as $name => $meta) {
        if (is_string($name) && plugin_name_valid($name) && is_array($meta)) {
            $meta['tables'] = plugin_valid_tables($meta['tables'] ?? []);
            $installed[$name] = $meta;
        }
    }
    return ['active' => array_values(array_unique($active)), 'installed' => $installed];
}

function save_plugins_state(array $state): void
{
    $path = plugins_state_path();
    $payload = plugins_state_normalize($state);
    // Leer als {} statt [], wie bisher in active-plugins.json.
    if ($payload['installed'] === []) {
        $payload['installed'] = new stdClass();
    }

    $json = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        throw new RuntimeException('Cannot encode active-plugins.json');
    }

    write_file_atomic($path, $json . PHP_EOL);
}

function plugin_active(string $name): bool
{
    if (!plugin_name_valid($name)) {
        return false;
    }

    $state = load_plugins_state();
    return in_array($name, $state['active'], true);
}

/** plugin_manifest() für API-Endpoints: Ist plugin.json fehlerhaft, antwortet der Request mit 500 und fester Meldung (Details ins Log). */
function le_plugin_manifest_or_fail(string $name): array
{
    try {
        return plugin_manifest($name);
    } catch (Throwable $e) {
        error_log('plugin manifest ' . $name . ': ' . $e->getMessage());
        json_response(['ok' => false, 'error' => API_TEXT['pluginInvalid']], 500);
    }
}

/** Plugin-Name aus einer Anfrage: ungültig (plugin_name_valid) → 400 invalidPlugin. */
function le_require_plugin_name(string $name): void
{
    if (!plugin_name_valid($name)) {
        json_response(['ok' => false, 'error' => API_TEXT['invalidPlugin']], 400);
    }
}

/**
 * Lesen → Ändern → Schreiben von active-plugins.json (Aktivieren, Deaktivieren, Deinstallieren): sperrt bis zum Ende der
 * Anfrage (le_store_lock_until_end), $change bekommt den Stand per Referenz und darf mit json_response abbrechen (dann
 * bleibt die Datei). Scheitert das Speichern, ins Log mit $action und $name und 500 pluginStateFailed. Liefert den neuen
 * Stand. Ist der ganze Schritt gelungen, gibt der Aufrufer die Sperre frei (le_plugins_state_done).
 */
function le_plugins_state_update(string $action, string $name, callable $change): array
{
    le_store_lock_until_end('plugins');
    $state = load_plugins_state();
    $change($state);
    try {
        save_plugins_state($state);
    } catch (Throwable $e) {
        error_log('plugin ' . $action . ' ' . $name . ': ' . $e->getMessage());
        json_response(['ok' => false, 'error' => API_TEXT['pluginStateFailed']], 500);
    }
    return load_plugins_state();
}

/**
 * Aktivieren, Deaktivieren oder Deinstallieren ist gelungen: die Sperre aus le_plugins_state_update freigeben, bevor die
 * Shutdown-Funktionen laufen. Sonst nähme IndexNow dort content-types-website unter ihr, während eine andere Anfrage
 * unter content-types-website in db() auf plugins wartet (Schema-Läufer): Verklemmung. Liefert $state.
 */
function le_plugins_state_done(array $state): array
{
    le_store_unlock_until_end('plugins');
    return $state;
}

/** Plugin deaktivieren (api/plugins/deactivate.php); ein nicht aktives bleibt, wie es ist. Liefert den neuen Stand. */
function le_plugin_deactivate(string $name): array
{
    le_require_plugin_name($name);
    return le_plugins_state_done(le_plugins_state_update('deactivate', $name, static function (array &$state) use ($name): void {
        $state['active'] = array_values(array_diff($state['active'], [$name]));
    }));
}

/**
 * Plugin aktivieren (api/plugins/activate.php): gültiger Name (400), plugin.json da (404) und lesbar (500), dann unter der
 * Sperre des Plugin-Status die Anforderungen: Datenbank (409 database_required), beschreibbare Uploads und Mailversand
 * (409). Beim ersten Mal mit Datenbank die Tabellen aus allen Schema-Dateien bis zur Version im Manifest (409
 * schema_missing, 500 pluginInstallFailed) und Version, Zeit, Tabellen und Stand des Schemas merken. Liefert den neuen Stand.
 */
function le_plugin_activate(string $name): array
{
    // Mail erst hier: plugins.php lädt jede Besucherseite, den Mailversand braucht nur das Aktivieren.
    require_once LE_BACKEND . '/base/mail.php';
    le_require_plugin_name($name);
    if (!is_file(plugin_path($name, 'plugin.json'))) {
        json_response(['ok' => false, 'error' => API_TEXT['pluginNotFound']], 404);
    }
    $manifest = le_plugin_manifest_or_fail($name);

    return le_plugins_state_done(le_plugins_state_update('activate', $name, static function (array &$state) use ($name, $manifest): void {
        if (!empty($manifest['requires']['database']) && !db_available()) {
            json_response(db_migration_error('database_required', DB_UNAVAILABLE_MESSAGE), DB_MIGRATION_ERROR_STATUS['database_required']);
        }
        if (!empty($manifest['requires']['uploads']) && (!is_dir(UPLOADS_ROOT) || !is_writable(UPLOADS_ROOT))) {
            json_response([
                'ok' => false,
                'error' => 'uploads_unwritable',
                'message' => API_TEXT['uploadsUnwritable'],
            ], 409);
        }
        if (!empty($manifest['requires']['mail']) && !core_mail_available()) {
            json_response([
                'ok' => false,
                'error' => 'mail_unavailable',
                'message' => API_TEXT['mailUnavailable'],
            ], 409);
        }

        if (!empty($manifest['requires']['database']) && !isset($state['installed'][$name])) {
            $driver = db_driver();
            $version = (string) $manifest['version'];
            $files = le_plugin_schema_files($name, $driver, null, $version);
            if ($files === []) {
                json_response(db_migration_error('schema_missing', plugin_schema_missing_message($name, $driver)), DB_MIGRATION_ERROR_STATUS['schema_missing']);
            }
            try {
                $pdo = db();
                // Die erste Verbindung kann das Schema der übrigen Plugins nachziehen und dabei tables speichern
                // (le_plugins_schema_update): neu lesen, sonst überschriebe der alte Stand ihn.
                $state = load_plugins_state();
                le_plugin_schema_table_create($pdo, $driver);
                le_plugin_schema_build($pdo, $driver, $name, $manifest['tables'], $version);
                le_plugin_schema_save($pdo, $name, $version);
                // Eine alte Zeile mit Fehlerstand (etwa nach Deinstallieren im Klon) ist damit überschrieben.
                le_plugin_schema_marker_sync(le_plugin_schema_rows($pdo));
            } catch (Throwable $e) {
                error_log('plugin activate ' . $name . ': ' . $e->getMessage());
                $file = $e instanceof LePluginSchemaException ? $e->fileName : basename((string) reset($files));
                json_response(['ok' => false, 'error' => sprintf(API_TEXT['pluginInstallFailed'], $file)], 500);
            }
            $state['installed'][$name] = [
                'version' => $version,
                'installedAt' => current_iso_time(),
                'tables' => $manifest['tables'],
            ];
        }

        if (!in_array($name, $state['active'], true)) {
            $state['active'][] = $name;
        }
    }));
}

/** Ob $name im Stand $state installiert ist: mit gemerkten Tabellen, aktiv oder mit eigenen Dateien (plugin_data_path). */
function le_plugin_installed(array $state, string $name): bool
{
    return isset($state['installed'][$name]) || in_array($name, $state['active'], true) || file_exists(plugin_data_path($name));
}

// Aktionen der generischen Endpoints (api/plugins/generic/<aktion>.php). Ein Plugin mit eigenem
// plugins/<name>/api/<aktion>.php bedienen sie dafür nicht: Sie umgingen seine Regeln (opening_hours_delete räumt etwa
// die Ausnahmen eines Bereichs mit auf).
const LE_PLUGIN_GENERIC_ACTIONS = ['list', 'get', 'save', 'delete'];
const LE_PLUGIN_GENERIC_URL = '/api/plugins/generic/';

// Adresse eines Plugin-Endpunkts: /plugins/<name>/api/<datei>.php (le_plugin_endpoint_file prüft beide Teile).
const LE_PLUGIN_ENDPOINT_PATTERN = '#^' . PLUGINS_URL . '([^/]+)/api/([^/]+)\.php$#';
// Dateien eines Plugins, die der Router ausliefert (LE_PLUGIN_SITE_FILES_DIR, LE_PLUGIN_ADMIN_FILES_DIR); alles andere im
// Plugin-Ordner ist von außen nicht erreichbar.
const LE_PLUGIN_FILE_PATTERN = '#^' . PLUGINS_URL . '([^/]+)/(' . LE_PLUGIN_SITE_FILES_DIR . '|' . LE_PLUGIN_ADMIN_FILES_DIR . ')/(.+)$#';
// Name eines Endpunkts unter plugins/<name>/api/ (ohne .php): keine Unterordner, keine Punkte.
const LE_PLUGIN_ENDPOINT_NAME_PATTERN = '/^[A-Za-z0-9_-]+$/';

/** Datei des Endpunkts $endpoint (ohne .php) von Plugin $name; null bei ungültigem Namen oder ohne Datei. */
function le_plugin_endpoint_file(string $name, string $endpoint): ?string
{
    if (!plugin_name_valid($name) || !preg_match(LE_PLUGIN_ENDPOINT_NAME_PATTERN, $endpoint)) {
        return null;
    }
    $file = plugin_path($name, 'api/' . $endpoint . '.php');

    return is_file($file) ? $file : null;
}

/** Adresse des eigenen Endpoints von $name für $action (LE_PLUGIN_GENERIC_ACTIONS), null ohne. */
function le_plugin_own_endpoint(string $name, string $action): ?string
{
    return le_plugin_endpoint_file($name, $action) !== null ? PLUGINS_URL . $name . '/api/' . $action . '.php' : null;
}

/** Endpoints je Aktion für die generische Ansicht im Backend: die eigenen des Plugins, sonst die generischen. */
function le_plugin_entry_endpoints(string $name): array
{
    $endpoints = [];
    foreach (LE_PLUGIN_GENERIC_ACTIONS as $action) {
        $endpoints[$action] = le_plugin_own_endpoint($name, $action) ?? LE_PLUGIN_GENERIC_URL . $action . '.php';
    }
    return $endpoints;
}

/** Generischer Endpoint für $action: 400, wenn $name dafür einen eigenen hat. */
function le_require_generic_endpoint(string $name, string $action): void
{
    if (le_plugin_own_endpoint($name, $action) !== null) {
        json_response(['ok' => false, 'error' => API_TEXT['pluginOwnEndpoint']], 400);
    }
}

function require_plugin_active(string $name): void
{
    if (!plugin_active($name)) {
        json_response(['ok' => false, 'error' => API_TEXT['pluginNotActive']], 404);
    }
    // Fehlt eine Schema-Datei (gescheitert), antworten alle Endpunkte des Plugins 503, eigene wie generische; auch in der
    // Anfrage, deren Verbindung das Schema eben scheitern lässt (der Endpunkt verbände ohnehin).
    if (le_plugin_schema_blocked_after_connect($name)) {
        json_response(['ok' => false, 'error' => API_TEXT['pluginSchemaIncomplete']], 503);
    }
    // Zentrale Sperre während eines Datenumzugs: schreibende Requests von
    // Plugins mit Datenbank → 503, Lesen läuft weiter aus der alten Quelle.
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if ($method !== 'GET' && $method !== 'HEAD' && !empty(le_plugin_manifest_or_fail($name)['requires']['database'])) {
        require_no_db_migration();
    }
}

/** Eine Schema-Datei ist gescheitert: ihre Version und ihr Name, die Meldung mit dem Grund (installSqlFailed, nur ins Log). */
final class LePluginSchemaException extends RuntimeException
{
    public function __construct(public readonly string $version, public readonly string $fileName, Throwable $previous)
    {
        parent::__construct(sprintf(API_TEXT['installSqlFailed'], $fileName, $previous->getMessage()), 0, $previous);
    }
}

/**
 * Schema-Dateien $files (le_plugin_schema_files) der Reihe nach auf $pdo ausführen, nach jeder gelungenen $done(Version).
 * Scheitert eine, bleibt von ihr keine neue Tabelle aus $tables (db_run_schema) und es wirft LePluginSchemaException.
 */
function le_plugin_schema_run(PDO $pdo, string $driver, array $files, array $tables, ?callable $done = null): void
{
    foreach ($files as $version => $path) {
        try {
            db_run_schema($pdo, $driver, (string) file_get_contents($path), $tables);
        } catch (Throwable $e) {
            throw new LePluginSchemaException((string) $version, basename($path), $e);
        }
        if ($done !== null) {
            $done((string) $version);
        }
    }
}

/**
 * Tabellen $tables von $name auf $pdo aus allen Schema-Dateien bis $version aufbauen (null: Übergangsregel, nur die
 * älteste), ganz oder gar nicht: Scheitert eine Datei, fallen auch die Tabellen der Dateien davor weg. Aktivieren, Ziel
 * eines Umzugs, Einspielen einer Sicherung. Wirft LePluginSchemaException.
 */
function le_plugin_schema_build(PDO $pdo, string $driver, string $name, array $tables, ?string $version): void
{
    $version ??= le_plugin_schema_oldest($name, $driver);
    $existing = array_filter($tables, static fn (string $table): bool => db_table_exists($pdo, $table));
    try {
        le_plugin_schema_run($pdo, $driver, $version === null ? [] : le_plugin_schema_files($name, $driver, null, $version), $tables);
    } catch (Throwable $e) {
        db_drop_tables($pdo, array_diff($tables, $existing));
        throw $e;
    }
}

/** Version der ältesten Schema-Datei von $name für $driver (Übergangsregel: so weit gilt ein Schema ohne Stand); null ohne Dateien. */
function le_plugin_schema_oldest(string $name, string $driver): ?string
{
    $oldest = array_key_first(le_plugin_schema_files($name, $driver));

    return $oldest === null ? null : (string) $oldest;
}

function le_plugin_schema_table_create(PDO $pdo, string $driver): void
{
    $pdo->exec(LE_PLUGIN_SCHEMA_TABLE_SQL[$driver]);
}

/**
 * Zeilen von LE_PLUGIN_SCHEMA_TABLE in einer Abfrage: [Plugin => ['version' => ?string, 'failed_file' => ?string,
 * 'failed_manifest' => ?string]] (LE_PLUGIN_SCHEMA_COLUMNS); null, wenn es die Tabelle nicht gibt.
 */
function le_plugin_schema_rows(PDO $pdo): ?array
{
    try {
        $stmt = $pdo->query('SELECT plugin, ' . implode(', ', LE_PLUGIN_SCHEMA_COLUMNS) . ' FROM `' . LE_PLUGIN_SCHEMA_TABLE . '`');
    } catch (PDOException $e) {
        if (db_table_missing_error($e, LE_PLUGIN_SCHEMA_TABLE)) {
            return null;
        }
        throw $e;
    }
    $rows = [];
    foreach ($stmt->fetchAll() as $row) {
        $rows[(string) $row['plugin']] = le_plugin_schema_values($row);
    }

    return $rows;
}

/** Werte einer Zeile von LE_PLUGIN_SCHEMA_TABLE (Abfrage, Sicherung, Aufrufer) je Spalte aus LE_PLUGIN_SCHEMA_COLUMNS als Text oder null. */
function le_plugin_schema_values(array $row): array
{
    $values = [];
    foreach (LE_PLUGIN_SCHEMA_COLUMNS as $column) {
        $values[$column] = isset($row[$column]) ? (string) $row[$column] : null;
    }

    return $values;
}

/**
 * Zeile von $name in LE_PLUGIN_SCHEMA_TABLE schreiben (die Tabelle gibt es, le_plugin_schema_table_create): Stand
 * $version (null: keiner), $failed wie le_plugin_schema_rows (ohne: kein Fehlerstand). Erst ändern, dann anlegen, damit
 * die Zeile nie fehlt (sonst griffe die Übergangsregel).
 */
function le_plugin_schema_save(PDO $pdo, string $name, ?string $version, array $failed = []): void
{
    $values = [...array_values(le_plugin_schema_values(['version' => $version] + $failed)), $name];
    $table = '`' . LE_PLUGIN_SCHEMA_TABLE . '`';
    $set = implode(' = ?, ', LE_PLUGIN_SCHEMA_COLUMNS) . ' = ?';
    $pdo->prepare("UPDATE {$table} SET {$set} WHERE plugin = ?")->execute($values);
    $exists = $pdo->prepare("SELECT 1 FROM {$table} WHERE plugin = ?");
    $exists->execute([$name]);
    if ($exists->fetchColumn() === false) {
        $placeholders = implode(', ', array_fill(0, count($values), '?'));
        $pdo->prepare('INSERT INTO ' . $table . ' (' . implode(', ', LE_PLUGIN_SCHEMA_COLUMNS) . ", plugin) VALUES ({$placeholders})")->execute($values);
    }
}

/** Zeile von $name aus LE_PLUGIN_SCHEMA_TABLE löschen (Deinstallieren), auf der Website-Datenbank samt Merker; ohne die Tabelle nichts. */
function le_plugin_schema_forget(PDO $pdo, string $name): void
{
    if (db_table_exists($pdo, LE_PLUGIN_SCHEMA_TABLE)) {
        $pdo->prepare('DELETE FROM `' . LE_PLUGIN_SCHEMA_TABLE . '` WHERE plugin = ?')->execute([$name]);
        if (db_is_active($pdo)) {
            le_plugin_schema_marker_sync(le_plugin_schema_rows($pdo));
        }
    }
}

/** Fehlerstand {file, manifest} in $row (Zeile aus le_plugin_schema_rows), solange er für die Manifest-Version $version gilt; null ohne. */
function le_plugin_schema_failure(?array $row, string $version): ?array
{
    return $row !== null && $row['failed_manifest'] === $version ? ['file' => $row['failed_file'], 'manifest' => $version] : null;
}

/**
 * Plugins mit Fehlerstand in den Zeilen $rows (le_plugin_schema_rows, null ohne Tabelle), nach Namen sortiert:
 * [Plugin => {file, manifest}]. Es zählt nur, was le_plugin_schema_failure für die Version im Manifest meldet, ein
 * veralteter Fehlerstand (Code zurückgesetzt, Code des Plugins entfernt) nicht: Merker und SQLite-Kopie folgen so derselben
 * Regel wie Website, Systemprüfung und „Erneut versuchen“.
 */
function le_plugin_schema_failures(?array $rows): array
{
    $failed = [];
    foreach ($rows ?? [] as $name => $row) {
        $manifest = le_plugin_schema_manifest((string) $name);
        $failure = $manifest === null ? null : le_plugin_schema_failure($row, (string) $manifest['version']);
        if ($failure !== null) {
            $failed[(string) $name] = $failure;
        }
    }
    ksort($failed);

    return $failed;
}

/** Fehlen alle Tabellen $tables (Datenbank verloren)? Ohne Tabellen nein. */
function le_plugin_tables_lost(PDO $pdo, array $tables): bool
{
    return $tables !== [] && array_filter($tables, static fn (string $table): bool => db_table_exists($pdo, $table)) === [];
}

/**
 * Hat das Schema (Manifest $manifest, Zeile $row oder null) etwas nachzuholen? Ohne Abfrage, ohne Datei: nein mit
 * Fehlerstand für diese Version und mit Stand gleich oder über der Version (Code zurückgesetzt); sonst ja.
 */
function le_plugin_schema_due(array $manifest, ?array $row): bool
{
    $version = (string) $manifest['version'];
    if (le_plugin_schema_failure($row, $version) !== null) {
        return false;
    }

    return ($row['version'] ?? null) === null || version_compare($row['version'], $version, '<');
}

/** Manifest von $name, wenn es eine Datenbank braucht; null ohne lesbare plugin.json (Code entfernt oder kaputt, meldet die Plugin-Liste) oder ohne Datenbank. */
function le_plugin_schema_manifest(string $name): ?array
{
    try {
        $manifest = plugin_manifest($name);
    } catch (Throwable $e) {
        return null;
    }

    return empty($manifest['requires']['database']) ? null : $manifest;
}

function le_plugin_schema_marker_path(): string
{
    return CACHE_ROOT . '/' . LE_PLUGIN_SCHEMA_FAILED_FILE;
}

/** Inhalt des Merkers (LE_PLUGIN_SCHEMA_FAILED_FILE), je Anfrage einmal gelesen; ohne Datei ein Dateizugriff. */
function &le_plugin_schema_marker(): array
{
    static $marker = null;
    if ($marker === null) {
        $path = le_plugin_schema_marker_path();
        $data = is_file($path) ? json_decode((string) @file_get_contents($path), true) : [];
        $marker = is_array($data) ? $data : [];
    }
    return $marker;
}

/**
 * Merker an die Zeilen $rows (le_plugin_schema_rows der Website-Datenbank, null ohne Tabelle) angleichen: jedes Plugin
 * mit Fehlerstand (le_plugin_schema_failures). Schreibt nur, wenn sich etwas ändert (write_file_atomic), ohne
 * Fehlerstand fällt die Datei weg. Scheitert das, eine Zeile ins Update-Log, aber nicht je Anfrage (updater_log_once); die
 * Datenbank bleibt die Wahrheit, le_plugin_schema_blocked fragt bei einem Eintrag ohnehin nach. $rows gelten für den Rest
 * der Anfrage (le_plugin_schema_seen), le_plugin_schema_confirmed liest sie dann nicht noch einmal.
 */
function le_plugin_schema_marker_sync(?array $rows): void
{
    $failed = le_plugin_schema_failures($rows);
    $seen = &le_plugin_schema_seen();
    $seen = $rows ?? [];
    $marker = &le_plugin_schema_marker();
    if ($failed === $marker) {
        return;
    }
    // Der Wert der Anfrage gilt gleich, auch wenn die Datei sich nicht schreiben lässt: Ein eben gescheitertes Plugin ist
    // ab hier gesperrt (le_plugin_schema_blocked), nicht erst in der nächsten Anfrage.
    $marker = $failed;
    $path = le_plugin_schema_marker_path();
    try {
        if ($failed === []) {
            if (is_file($path) && !@unlink($path)) {
                throw new RuntimeException('Cannot delete ' . basename($path));
            }
        } else {
            write_file_atomic($path, (string) json_encode($failed, JSON_UNESCAPED_SLASHES));
        }
    } catch (Throwable $e) {
        updater_log_once('plugin schema marker: ' . $e->getMessage());
    }
}

/**
 * Leseweg für Website und Router: Hat $name ein fehlgeschlagenes Schema? Ohne Eintrag im Merker (Normalfall) nein, ohne
 * Datenbank. Steht er dort mit der Version im Manifest, bestätigt es die Datenbank einmal je Anfrage
 * (le_plugin_schema_confirmed): Sagt sie nein, ist der Merker berichtigt und das Plugin frei; ist sie nicht erreichbar,
 * gilt es als blockiert. Ebenso bis zum Ende der Anfrage, wenn sein Schema in ihr nur an einer gesperrten Datenbank scheiterte
 * (le_plugin_schema_busy). Der Weg für Systemprüfung, Health-Check und „Erneut versuchen“ ist le_plugin_schema_failed().
 */
function le_plugin_schema_blocked(string $name): bool
{
    if (in_array($name, le_plugin_schema_busy(), true)) {
        return true;
    }
    $entry = le_plugin_schema_marker()[$name] ?? null;
    $manifest = is_array($entry) ? le_plugin_schema_manifest($name) : null;
    if ($manifest === null || ($entry['manifest'] ?? null) !== (string) $manifest['version']) {
        return false;
    }
    $rows = le_plugin_schema_confirmed();

    return $rows === null || le_plugin_schema_failure($rows[$name] ?? null, (string) $manifest['version']) !== null;
}

/**
 * le_plugin_schema_blocked, nachdem die Anfrage verbunden hat (nur für ein Plugin mit Datenbank): Die erste Verbindung
 * zieht das Schema nach (le_plugins_schema_update), ein eben gescheitertes gilt so schon jetzt als gesperrt. Für Code, der
 * ohnehin gleich verbindet (Endpunkte, Lesefunktionen); Seiten ohne Datenbank-Zugriff nehmen le_plugin_schema_blocked,
 * Arbeit, die einen Fehlschlag dauerhaft merkt (Startpakete), le_plugin_schema_ready.
 * Ist die Datenbank nicht erreichbar, meldet das der Aufrufer selbst, wenn er sie braucht.
 */
function le_plugin_schema_blocked_after_connect(string $name): bool
{
    if (le_plugin_schema_manifest($name) === null) {
        return false;
    }
    try {
        db();
    } catch (Throwable $e) {
    }

    return le_plugin_schema_blocked($name);
}

/**
 * Hat die Anfrage eine Verbindung, auf der das Schema von $name fertig ist (Stand mindestens die Version im Manifest, kein
 * Fehlerstand)? Für Arbeit, die einen Fehlschlag gegen die Datenbank als dauerhaft merkt (Startpakete): Scheitert die
 * Verbindung (SQLite beim ersten Start gesperrt, MySQL kurz weg) oder blieb das Nachziehen in dieser Anfrage aus, wartet sie
 * auf eine spätere Anfrage, statt gegen ein fehlendes Schema zu scheitern. Ohne Datenbank im Manifest ja.
 */
function le_plugin_schema_ready(string $name): bool
{
    $manifest = le_plugin_schema_manifest($name);
    if ($manifest === null) {
        return true;
    }
    try {
        db();
    } catch (Throwable $e) {
        return false;
    }
    $row = (le_plugin_schema_confirmed() ?? [])[$name] ?? null;

    return $row !== null && le_plugin_schema_failure($row, (string) $manifest['version']) === null && !le_plugin_schema_due($manifest, $row);
}

/**
 * Darf eine Lesefunktion aus der public.php von $name jetzt lesen? Nur bei aktivem Plugin ohne fehlgeschlagenes Schema,
 * geprüft nach der ersten Verbindung der Anfrage (le_plugin_schema_blocked_after_connect): Scheitert das Schema eben
 * dabei, ist schon diese Anfrage gesperrt, gelesen wird nie aus dem halben Schema. Ohne Datenbank nur, ob es aktiv ist.
 * Jede Funktion in public.php beginnt damit und liefert sonst leer (R10, tests/plugins/structure.test.php), so bleibt
 * eine Seite, die sie aufruft, auch bei gesperrtem Plugin heil.
 */
function le_plugin_public_ready(string $name): bool
{
    return plugin_active($name) && !le_plugin_schema_blocked_after_connect($name);
}

/**
 * Plugins, deren Schema-Datei in dieser Anfrage auf der Website-Datenbank nur an einer gesperrten Datenbank scheiterte
 * (db_error_transient): ohne Fehlerstand und ohne Merker, aber bis zum Ende der Anfrage gesperrt (le_plugin_schema_blocked),
 * damit nichts aus einem bei MySQL vielleicht halb geänderten Schema liest.
 */
function &le_plugin_schema_busy(): array
{
    static $busy = [];
    return $busy;
}

/**
 * Zeilen von LE_PLUGIN_SCHEMA_TABLE der Website-Datenbank, wie die Anfrage sie zuletzt gelesen hat
 * (le_plugin_schema_marker_sync); false: noch nicht gelesen, null: Datenbank nicht erreichbar.
 */
function &le_plugin_schema_seen(): array|false|null
{
    static $rows = false;
    return $rows;
}

/**
 * Zeilen von LE_PLUGIN_SCHEMA_TABLE über db(), je Anfrage einmal, und der Merker danach berichtigt; null, wenn die
 * Datenbank nicht erreichbar ist. Hat die erste Verbindung sie schon gelesen (Läufer), ohne zweite Abfrage.
 */
function le_plugin_schema_confirmed(): ?array
{
    $seen = &le_plugin_schema_seen();
    if ($seen === false) {
        try {
            $pdo = db();
            if ($seen === false) {
                le_plugin_schema_marker_sync(le_plugin_schema_rows($pdo) ?? []);
            }
        } catch (Throwable $e) {
            error_log('plugin schema: ' . $e->getMessage());
            $seen = null;
        }
    }
    return $seen;
}

function le_plugin_schema_backup_path(): string
{
    return CACHE_ROOT . '/' . LE_PLUGIN_SCHEMA_BACKUP_FILE;
}

/**
 * SQLite-Kopie (le_plugin_schema_backup_path) löschen, wenn die Zeilen $rows der Website-Datenbank keinen Fehlerstand
 * haben (le_plugin_schema_failures, dieselbe Regel wie der Merker): nach einem Durchlauf und bei veraltetem Fehlerstand
 * (Code zurückgesetzt oder entfernt). Nur unter der Sperre plugins mit unter ihr gelesenen Zeilen, sonst löschte es die
 * Kopie, die ein Durchlauf einer anderen Anfrage eben angelegt hat.
 */
function le_plugin_schema_backup_drop(?array $rows): void
{
    $path = le_plugin_schema_backup_path();
    if (le_plugin_schema_failures($rows) === [] && is_file($path) && !@unlink($path)) {
        updater_log_once('plugin schema backup: cannot delete ' . basename($path));
    }
}

/**
 * Schema aller installierten Plugins auf $pdo auf die Version ihres Manifests bringen. Im Normalfall eine Abfrage
 * (le_plugin_schema_rows), ohne installiertes Plugin mit Datenbank keine; keine Schema-Datei, keine Sperre. Ist etwas
 * fällig und läuft kein Umzug, unter der Sperre plugins nur für den Durchlauf (le_store_lock_during):
 * le_plugins_schema_pass. Bei der ersten Verbindung einer Anfrage (db(), nicht auf der Kommandozeile), vor Datenabgleich
 * und Umzug, nach dem Einspielen einer Sicherung. Fehler nur ins Log.
 */
function le_plugins_schema_update(PDO $pdo, string $driver): void
{
    try {
        $manifests = [];
        foreach (array_keys(load_plugins_state()['installed']) as $name) {
            $manifests[$name] = le_plugin_schema_manifest($name);
        }
        $manifests = array_filter($manifests);
        $active = db_is_active($pdo);
        // Liegt eine Kopie ohne Fehlerstand (veraltet: Code zurückgesetzt oder entfernt), ohne dass ein Durchlauf ansteht:
        // selten, darum erst dann die Sperre.
        $dropBackup = static function (?array $rows) use ($pdo, $active): void {
            if ($active && le_plugin_schema_failures($rows) === [] && is_file(le_plugin_schema_backup_path())) {
                le_store_lock_during('plugins', static fn () => le_plugin_schema_backup_drop(le_plugin_schema_rows($pdo)));
            }
        };
        if ($manifests === []) {
            if ($active) {
                le_plugin_schema_marker_sync(null);
            }
            $dropBackup(null);
            return;
        }
        $rows = le_plugin_schema_rows($pdo);
        if ($active) {
            le_plugin_schema_marker_sync($rows);
        }
        $rows ??= [];
        $due = [];
        foreach ($manifests as $name => $manifest) {
            if (le_plugin_schema_due($manifest, $rows[$name] ?? null)) {
                $due[] = (string) $name;
            }
        }
        if ($due === [] || db_migration_running()) {
            if ($due === []) {
                $dropBackup($rows);
            }
            return;
        }
        le_store_lock_during('plugins', static fn () => le_plugins_schema_pass($pdo, $driver, $due));
    } catch (Throwable $e) {
        error_log('plugin schema: ' . $e->getMessage());
    }
}

/**
 * Ein Durchlauf unter der Sperre plugins für die Plugins $names: Stand neu lesen, je fälligem Plugin die Dateien
 * Stand < Version ≤ Manifest einzeln (ohne Zeile: Übergangsregel; fehlen alle Tabellen: alle Dateien), nach jeder den
 * Stand speichern, am Ende Stand = Manifest-Version und tables aus dem Manifest in active-plugins.json. Scheitert eine
 * (oder schon das Lesen von sql/): ins Log, Stand bei der letzten gelungenen, Fehlerstand mit Datei und Manifest-Version
 * (nicht bei nur gesperrter Datenbank, db_error_transient: dann versucht es die nächste Verbindung);
 * ein späterer Versuch führt die Datei ganz aus. Die übrigen Plugins laufen weiter. SQLite: vor der ersten Datei eines
 * Plugins mit Tabellen eine Kopie der Datenbank in den Cache, wenn keine von einem Fehlschlag liegt; sie fällt weg, sobald
 * kein Plugin mehr einen Fehlerstand hat (le_plugin_schema_backup_drop).
 */
function le_plugins_schema_pass(PDO $pdo, string $driver, array $names): void
{
    try {
        le_plugin_schema_table_create($pdo, $driver);
    } catch (Throwable $e) {
        // Ohne Kern-Tabelle (kein CREATE-Recht, schreibgeschützte Datei) gibt es keinen Fehlerstand: nicht je Anfrage loggen.
        updater_log_once('plugin schema: ' . LE_PLUGIN_SCHEMA_TABLE . ' not created: ' . $e->getMessage());
        return;
    }
    $rows = le_plugin_schema_rows($pdo) ?? [];
    $state = load_plugins_state();
    $tablesChanged = false;
    // Die Kopie gehört zur Datenbank der Website, nicht zu einer anderen Verbindung (Quelle eines Umzugs).
    $copy = $driver === DB_DRIVER_SQLITE && db_is_active($pdo);
    $copyTried = false;
    foreach ($names as $name) {
        $manifest = le_plugin_schema_manifest($name);
        $row = $rows[$name] ?? null;
        if ($manifest === null || !isset($state['installed'][$name]) || !le_plugin_schema_due($manifest, $row)) {
            continue;
        }
        $version = (string) $manifest['version'];
        $stand = $row['version'] ?? null;
        $files = [];
        try {
            $lost = le_plugin_tables_lost($pdo, $manifest['tables']);
            $from = $lost ? null : ($row['version'] ?? le_plugin_schema_oldest($name, $driver));
            $stand = $from;
            $files = le_plugin_schema_files($name, $driver, $from, $version);
            // Ohne Stand und ohne Datei fehlt jede Schema-Datei; fehlt einer Version die Datei dieses Treibers, ebenso.
            $other = array_values(array_diff(DB_DRIVERS, [$driver]));
            if (($from === null && $files === []) || array_keys($files) !== array_keys(le_plugin_schema_files($name, $other[0], $from, $version))) {
                throw new RuntimeException(plugin_schema_missing_message($name, $driver));
            }
            if ($copy && !$lost && $files !== [] && !$copyTried && !is_file(le_plugin_schema_backup_path())) {
                $copyTried = true;
                try {
                    db_sqlite_copy($pdo, le_plugin_schema_backup_path());
                } catch (Throwable $e) {
                    // Ohne Kopie weiter: Eine scheiternde Datei rollt SQLite ohnehin zurück.
                    error_log('plugin schema backup: ' . $e->getMessage());
                }
            }
            le_plugin_schema_run($pdo, $driver, $files, $manifest['tables'], static function (string $done) use ($pdo, $name, &$stand): void {
                $stand = $done;
                le_plugin_schema_save($pdo, $name, $done);
            });
            le_plugin_schema_save($pdo, $name, $version);
            if ($state['installed'][$name]['tables'] !== $manifest['tables']) {
                $state['installed'][$name]['tables'] = $manifest['tables'];
                $tablesChanged = true;
            }
        } catch (Throwable $e) {
            // Sperrt nur gerade eine andere Verbindung, ist das kein Fehlerstand (er sperrte das Plugin bis „Erneut
            // versuchen“): Der Stand bleibt bei der letzten gelungenen Datei, die nächste Verbindung versucht es wieder;
            // gesperrt ist es nur für den Rest dieser Anfrage. Hält die Sperre an, nicht je Anfrage loggen.
            if (db_error_transient($e)) {
                updater_log_once('plugin schema ' . $name . ': ' . $e->getMessage());
                if (db_is_active($pdo)) {
                    $busy = &le_plugin_schema_busy();
                    $busy[] = $name;
                }
                continue;
            }
            error_log('plugin schema ' . $name . ': ' . $e->getMessage());
            le_plugin_schema_save($pdo, $name, $stand, [
                'failed_file' => $e instanceof LePluginSchemaException ? $e->version : (string) (array_key_first($files) ?? $version),
                'failed_manifest' => $version,
            ]);
        }
    }
    if ($tablesChanged) {
        save_plugins_state($state);
    }
    // Merker und Kopie gehören zur Datenbank der Website.
    if (db_is_active($pdo)) {
        $rows = le_plugin_schema_rows($pdo);
        le_plugin_schema_marker_sync($rows);
        le_plugin_schema_backup_drop($rows);
    }
}

/** Zeile von $name aus LE_PLUGIN_SCHEMA_TABLE über db(); null ohne (auch ohne Tabelle oder erreichbare Datenbank). */
function le_plugin_schema_row(string $name): ?array
{
    try {
        return (le_plugin_schema_rows(db()) ?? [])[$name] ?? null;
    } catch (Throwable $e) {
        return null;
    }
}

/**
 * Fehlerstand des Schemas von $name ({file: Version der Datei, manifest}), solange er für die Version im Manifest gilt;
 * sonst null. Genau, aus der Datenbank (db()): „Erneut versuchen“, Einspielen einer Sicherung; Systemprüfung und
 * Health-Check lesen alle Plugins in einer Abfrage (le_plugins_schema_report), die Website fragt le_plugin_schema_blocked.
 */
function le_plugin_schema_failed(string $name): ?array
{
    $manifest = le_plugin_schema_manifest($name);

    return $manifest === null ? null : le_plugin_schema_failure(le_plugin_schema_row($name), (string) $manifest['version']);
}

/** Steht der Stand in $row (Zeile aus le_plugin_schema_rows) über der Manifest-Version $version? */
function le_plugin_schema_above(?array $row, string $version): bool
{
    return ($row['version'] ?? null) !== null && version_compare((string) $row['version'], $version, '>');
}

/**
 * „Erneut versuchen“: Fehlerstand von $name löschen und gleich nachziehen
 * (le_plugins_schema_update). Liefert den Fehlerstand danach, null wenn alles gelaufen ist; ohne Zeile oder für ein nicht
 * installiertes Plugin nichts als den Fehlerstand. Wirft, wenn die Datenbank nicht erreichbar ist.
 */
function le_plugin_schema_retry(string $name): ?array
{
    $pdo = db();
    le_store_lock_during('plugins', static function () use ($pdo, $name): void {
        $row = (le_plugin_schema_rows($pdo) ?? [])[$name] ?? null;
        if ($row !== null && $row['failed_manifest'] !== null) {
            le_plugin_schema_save($pdo, $name, $row['version']);
        }
    });
    le_plugins_schema_update($pdo, db_driver());

    return le_plugin_schema_failed($name);
}

/**
 * „Erneut versuchen“ aus der Systemprüfung (api/plugins/retrySchema.php): gültiger Name (400), installiert (404),
 * Datenbank da (409 database_required). Ohne Fehlerstand in der Datenbank nichts (false: kein Versuch, keine Aktivität),
 * sonst le_plugin_schema_retry: Scheitert die Datei wieder, 500 mit Plugin und Version (pluginSchemaRetryFailed), jeder
 * andere Fehler 500 pluginSchemaRetryError; Gründe nur ins Log. true nach einem gelungenen Versuch.
 */
function le_plugin_schema_retry_or_fail(string $name): bool
{
    le_require_plugin_name($name);
    if (!isset(load_plugins_state()['installed'][$name])) {
        json_response(['ok' => false, 'error' => API_TEXT['pluginNotInstalled']], 404);
    }
    if (!db_available()) {
        json_response(db_migration_error('database_required', DB_UNAVAILABLE_MESSAGE), DB_MIGRATION_ERROR_STATUS['database_required']);
    }
    try {
        if (le_plugin_schema_failed($name) === null) {
            return false;
        }
        $failed = le_plugin_schema_retry($name);
    } catch (Throwable $e) {
        error_log('plugin schema retry ' . $name . ': ' . $e->getMessage());
        json_response(['ok' => false, 'error' => API_TEXT['pluginSchemaRetryError']], 500);
    }
    if ($failed !== null) {
        $label = (string) (le_plugin_schema_manifest($name)['label'] ?? $name);
        json_response(['ok' => false, 'error' => sprintf(API_TEXT['pluginSchemaRetryFailed'], $label, (string) $failed['file'])], 500);
    }

    return true;
}

/**
 * Stand des Schemas je installiertem Plugin mit Datenbank: [Name => ['failed' => {file, manifest}|null, 'ahead' => bool]].
 * $exact: aus der Kern-Tabelle in einer Abfrage (Systemprüfung, Health-Check; wirft ohne erreichbare Datenbank); sonst nur
 * der Fehlerstand über le_plugin_schema_blocked, ohne Merker ohne Datenbank (Dashboard über bootstrap, ahead dann immer false).
 */
function le_plugins_schema_report(bool $exact, ?PDO $pdo = null): array
{
    $versions = [];
    foreach (array_keys(load_plugins_state()['installed']) as $name) {
        $manifest = le_plugin_schema_manifest($name);
        if ($manifest !== null) {
            $versions[$name] = (string) $manifest['version'];
        }
    }
    // Ohne installiertes Plugin mit Datenbank keine Verbindung (sie legte bei SQLite sonst die Datei an).
    $rows = $exact && $versions !== [] ? (le_plugin_schema_rows($pdo ?? db()) ?? []) : [];
    $report = [];
    foreach ($versions as $name => $version) {
        $row = $rows[$name] ?? null;
        $report[$name] = $exact
            ? ['failed' => le_plugin_schema_failure($row, $version), 'ahead' => le_plugin_schema_above($row, $version)]
            : ['failed' => le_plugin_schema_blocked($name) ? (le_plugin_schema_marker()[$name] ?? null) : null, 'ahead' => false];
    }

    return $report;
}

/**
 * Aktive Plugins, deren Shortcodes die Website rendert: ohne die mit fehlgeschlagenem Schema (le_plugin_schema_blocked;
 * ohne Merker ohne Datenbank). Hooks sperrt plugin_hook_function selbst (LE_PLUGIN_SITE_HOOKS), Lesefunktionen aus
 * public.php le_plugin_public_ready.
 */
function le_plugins_site_active(): array
{
    return array_values(array_filter(load_plugins_state()['active'], static fn (string $name): bool => !le_plugin_schema_blocked($name)));
}

function plugin_has_admin_sidebar(array $manifest): bool
{
    return is_array($manifest['admin']['sidebar'] ?? null);
}

/** Hat das Plugin ein Schema für die generische Ansicht im Backend (schema.fields)? */
function le_plugin_has_schema(array $manifest): bool
{
    return isset($manifest['schema']['fields']) && is_array($manifest['schema']['fields']);
}

/**
 * Alle Plugins für Verwaltung → Plugins (api/plugins/list.php): je Plugin Beschriftung, Version, Anforderungen, Zustand
 * und was es im Backend mitbringt; eine unlesbare plugin.json nur mit Meldung (pluginInvalid, Grund ins Log). Dazu, ob die
 * Datenbank für Plugins bereitsteht.
 */
function le_plugins_list(): array
{
    $state = load_plugins_state();
    $plugins = [];

    foreach (list_plugin_dirs() as $name) {
        try {
            $manifest = plugin_manifest($name);
            $adminModule = plugin_admin_module_path($manifest);
            $plugins[] = [
                'name' => $name,
                'label' => (string) ($manifest['label'] ?? $name),
                'version' => (string) ($manifest['version'] ?? '0.0.0'),
                'description' => (string) ($manifest['description'] ?? ''),
                'requires' => $manifest['requires'],
                'active' => in_array($name, $state['active'], true),
                'installed' => le_plugin_installed($state, $name),
                'installedVersion' => $state['installed'][$name]['version'] ?? null,
                'hasAdminSidebar' => plugin_has_admin_sidebar($manifest),
                'hasAdminModule' => $adminModule !== null,
                'hasSchema' => le_plugin_has_schema($manifest),
            ];
        } catch (Throwable $e) {
            error_log('plugin list ' . $name . ': ' . $e->getMessage());
            $plugins[] = [
                'name' => $name,
                'error' => API_TEXT['pluginInvalid'],
            ];
        }
    }

    return [
        'plugins' => $plugins,
        'dbAvailable' => db_available(),
        'dbMessage' => db_available() ? '' : DB_UNAVAILABLE_MESSAGE,
    ];
}

function active_plugin_admin_info(): array
{
    $state = load_plugins_state();
    $info = [];

    foreach ($state['active'] as $name) {
        try {
            $manifest = plugin_manifest($name);
        } catch (Throwable $e) {
            continue;
        }
        if (!plugin_has_admin_sidebar($manifest)) {
            continue;
        }

        $extra = plugin_extra_sidebar_entries($name);
        if ($extra !== null) {
            foreach ($extra as $entry) {
                $info[] = $entry;
            }
            continue;
        }

        $sidebar = $manifest['admin']['sidebar'];
        $module = plugin_admin_module_path($manifest);
        $info[] = [
            'name' => $name,
            'route' => $name,
            'label' => (string) ($sidebar['label'] ?? $manifest['label'] ?? $name),
            'hasAdminModule' => $module !== null,
            'hasSchema' => le_plugin_has_schema($manifest),
            'endpoints' => le_plugin_entry_endpoints($name),
        ];
    }

    return $info;
}

/**
 * Lädt die public.php jedes aktiven Plugins (Lesefunktionen für das PHP der Website), vorher die Plugin-Schnittstelle.
 * Der Router und der Health-Check rufen das vor dem Rendern auf; die Website lädt dafür keine Plugin- oder Kern-Datei selbst.
 */
function le_plugins_load_public(): void
{
    // Auch bei fehlgeschlagenem Schema: Die Seiten der Website rufen die Funktionen direkt auf (ohne function_exists), sie
    // müssen da sein. Gesperrt wird in jeder Funktion (le_plugin_public_ready), sie liefert dann leer.
    foreach (load_plugins_state()['active'] as $name) {
        $public = is_string($name) && plugin_name_valid($name) ? plugin_path($name, 'public.php') : null;
        if ($public !== null && is_file($public)) {
            // Erst, wenn es Plugin-Code gibt: Besucherseiten ohne ihn laden die Schnittstelle (Uploads, Schema …) nicht.
            require_once LE_PLUGIN_API_FILE;
            // Wie bei den Hooks: Ein kaputtes Plugin nimmt die Website nicht mit, es fehlen nur seine Lesefunktionen.
            try {
                require_once $public;
            } catch (Throwable $e) {
                error_log('public.php ' . $name . ' failed: ' . $e->getMessage());
            }
        }
    }
}

/**
 * Lädt die lib.php von $name (gültiger Name) samt der Plugin-Schnittstelle davor: Plugins laden keine Kern-Datei selbst.
 * false ohne lib.php. Hooks laden Plugins nur so, der Router vor einem Plugin-Endpunkt über le_plugin_load_for_endpoint.
 */
function le_plugin_load_lib(string $name): bool
{
    $libPath = plugin_path($name, 'lib.php');
    if (!is_file($libPath)) {
        return false;
    }
    require_once LE_PLUGIN_API_FILE;
    require_once $libPath;

    return true;
}

/**
 * Vor einem Endpunkt von $name (gültiger Name): erst die Plugin-Schnittstelle, dann die lib.php, falls es eine gibt. Die
 * Schnittstelle kommt immer mit, auch ein Plugin mit api/ ohne lib.php bekommt Wächter und Helfer.
 */
function le_plugin_load_for_endpoint(string $name): void
{
    require_once LE_PLUGIN_API_FILE;
    le_plugin_load_lib($name);
}

function plugin_extra_sidebar_entries(string $name): ?array
{
    $fn = plugin_hook_function($name, 'admin_sidebar_entries');
    if ($fn === null) {
        return null;
    }

    try {
        $entries = $fn();
    } catch (Throwable $e) {
        return null;
    }
    // Schema eben während des Hooks gescheitert (LE_PLUGIN_SITE_HOOKS): Die Einträge kämen aus dem halben Schema.
    if (!is_array($entries) || le_plugin_schema_blocked($name)) {
        return null;
    }

    $valid = [];
    foreach ($entries as $entry) {
        if (!is_array($entry)) {
            continue;
        }
        $route = $entry['route'] ?? null;
        $label = $entry['label'] ?? null;
        if (!is_string($route) || !is_string($label) || $label === '') {
            continue;
        }
        if (!preg_match('/^[a-z][a-z0-9_-]*(\/[a-z][a-z0-9_-]+)*$/', $route)) {
            continue;
        }
        $entry['name'] = $name;
        $entry['route'] = $route;
        $entry['label'] = $label;
        $entry['hasAdminModule'] = !empty($entry['hasAdminModule']);
        $entry['hasSchema'] = !empty($entry['hasSchema']);
        $valid[] = $entry;
    }

    return $valid;
}

function plugin_admin_module_path(array $manifest): ?string
{
    $module = $manifest['admin']['sidebar']['module'] ?? null;
    if (!is_string($module) || trim($module) === '') {
        return null;
    }
    if (str_contains(str_replace('\\', '/', $module), '..')) {
        return null;
    }

    return $module;
}
