<?php
declare(strict_types=1);

// Seiten-Editor und Verwaltung: Name und Schema des einen Hinweises (rows: er selbst, falls angelegt); single: Es gibt
// nur ihn, die Verwaltung bietet kein „Kopieren“ (ein zweiter Hinweis gäbe 409, site_notice_save).

require_auth();

try {
    $fields = site_notice_fields();
    $row = site_notice_entry();
} catch (Throwable $e) {
    plugin_failure_response('load', $e);
}

json_response([
    'ok' => true,
    'type' => SITE_NOTICE_TYPE,
    'label' => SITE_NOTICE_TEXT['label'],
    'single' => true,
    'schema' => $fields,
    'rows' => $row === null ? [] : [plugin_schema_decode_row($fields, $row)],
]);
