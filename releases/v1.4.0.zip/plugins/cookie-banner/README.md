# Cookie-Banner (Plugin `cookie-banner`)

## Zweck

DSGVO/TTDSG-konformer Cookie-Banner: blockt Dienste aus der Registry, bis der Besucher zustimmt. Erkannt und blockiert werden beim Ausliefern jeder Seite der Website (nie im Admin):

- `<iframe>` und `<script src>` zu Hosts der Registry. Zählen bei iframes `src`, `data-src`, `data-lazy-src`, bei Scripts dazu LiteSpeed (`type="litespeed/javascript" data-src=…`); Werte mit oder ohne Anführungszeichen (minifiziert, `COOKIE_BANNER_ATTR_VALUE`).
- Inline-Scripts (ohne `type` oder mit JavaScript-`type`), deren Code einen Host eines Dienstes vom Typ `script` nennt (Standard-Snippets von Meta-Pixel, Hotjar, GTM). Das gtag-Config-Snippet nennt keinen Host und läuft sofort, sendet aber nichts, solange `gtag/js` blockiert ist.
- In `<noscript>`: `<img>` und `<iframe>` zu Hosts der Registry fallen ganz weg (ohne JavaScript gibt es keinen Banner, also keine Einwilligung); der Rest bleibt.

Banner und Einwilligung:

- Slide-in unten, keine Cookie-Wall; drei gleich prominente Knöpfe: Ablehnen, Einstellungen, Alle akzeptieren. Kategorien Deny-by-Default (außer `necessary`).
- „Inhalt laden“ am einzelnen Platzhalter, ohne die Einwilligung zu ändern.
- Einwilligung nur im `localStorage` (`cc_consent` mit `v` = Version), kein Cookie, kein Server-Log. Version hochzählen: Alle sehen den Banner erneut.
- Ereignis `cc:consent` (`event.detail.categories`) beim Laden mit gültiger Einwilligung und nach jeder Auswahl.

Im Backend (Seitenleiste „Cookie-Banner“, nur Admins): Banner aktiv, Texte, Datenschutz-URL, Kategorien, „Beim Speichern Version hochzählen“, Liste der Dienste (nur lesen).

- Datenschutz-URL: Pfad (`/datenschutz`) oder `http(s)://`; anderes Schema (`javascript:`) weist das Speichern mit 400 ab, aus einer alten Konfig wird es nicht ausgegeben.
- Feste Kategorien `necessary`, `statistics`, `marketing`: nicht entfernbar, ID fest, nur der Name änderbar; fehlen sie in der Konfig, ergänzt der Server sie (beim Speichern und Laden). „Erforderlich“ ist bei `necessary` immer an, bei `statistics` und `marketing` abwählbar (einwilligungspflichtig). Neue Kategorie: ID (kebab-case), Label; dabei Version hochzählen.

| Dienst | Kategorie | Typ | Hosts |
|---|---|---|---|
| youtube | marketing | iframe | youtube.com, youtu.be, youtube-nocookie.com |
| vimeo | marketing | iframe | player.vimeo.com, vimeo.com |
| gmaps | marketing | iframe | google.com/maps, maps.google.com, www.google.com/maps |
| ga4 | statistics | script | googletagmanager.com, google-analytics.com |
| meta-pixel | marketing | script | connect.facebook.net, facebook.com/tr |
| hotjar | statistics | script | static.hotjar.com, script.hotjar.com |

Google Fonts bewusst nicht: Schriften werden beim Import lokalisiert.

Grenzen:

- GTM zählt als Statistik (`googletagmanager.com` gehört zu `ga4`): Ein Container mit Marketing-Tags feuert schon mit der Statistik-Einwilligung, Consent Mode wird nicht gesetzt. Solche Container selbst mit `type="text/plain" data-cc="marketing"` markieren.
- Nicht erkannt: Inline-Scripts ohne Registry-Host (eigene Tracker, zusammengesetzte URLs, `type="module"`) und Einbettungen, die erst per JS ins DOM kommen.
- Widerruf entlädt geladene Scripts nicht (bis zum nächsten Seitenaufruf).
- Ein Satz Texte, keine Mehrsprachigkeit, kein Geo-Targeting, kein Consent-Logging am Server (bewusst).

## Einbinden

Der Banner kommt von selbst (Hook `filter_site_html`, solange Plugin und `enabled` aktiv sind) vor das letzte `</body>` außerhalb von Skripten und Kommentaren, ohne eins ans Ende des Dokuments; JSON und Teilstücke ohne `<html>`/`<body>` bleiben ohne Banner.

Link zum Widerrufen, z. B. im Footer (Shortcode `settings-link`, `data-label` Vorgabe „Cookie-Einstellungen“):

```html
<div data-plugin="cookie-banner" data-view="settings-link" data-label="Cookie-Einstellungen"></div>
```

Ausgabe `<a href="#cookie-settings" class="cc-settings-link" data-cc-settings-link>…</a>`; ein Klick öffnet die Kategorie-Auswahl (`window.cookieBanner.open()`).

Andere Inline-Scripts von Hand an eine Kategorie koppeln; eigene Plugins mit Drittanbietern hören auf das Ereignis:

```html
<script type="text/plain" data-cc="statistics">/* läuft erst nach Einwilligung für statistics */</script>
<script>window.addEventListener('cc:consent', function (e) { if (e.detail.categories.statistics) { /* starten */ } });</script>
```

## Daten

Keine Tabelle. Konfig in `website/private/plugins/cookie-banner/config.json` (`plugin_data_path`), angelegt beim ersten Speichern, sonst gelten die Vorgaben aus `cookie_banner_default_config()`:

```json
{ "enabled": true, "version": 1,
  "categories": [{ "id": "necessary", "label": "Notwendig", "required": true }, { "id": "statistics", "label": "Statistik", "required": false }, { "id": "marketing", "label": "Marketing", "required": false }],
  "texts": { "title": "…", "intro": "…", "accept": "…", "reject": "…", "settings": "…", "save": "…", "policyLink": "…" },
  "policyUrl": "/datenschutz",
  "placeholder": { "default": "…", "youtube": "…", "maps": "…" } }
```

## Endpunkte

`api/get.php` (GET, `{ok, config, services[]}`) und `api/save.php` (POST mit CSRF, `{config, bumpVersion?}` → `{ok, config}`), beide nur Admins (`require_admin()`, Redakteure 403); Kopf: `docs/knowledgebase/plugins/endpoints.md`.

- `config` darf ein Teil sein: Was fehlt, bleibt; `texts` und `placeholder` je Schlüssel, `categories` ersetzt die Liste als Ganzes. Gelesen, geändert und geschrieben unter `store_lock('cookie-banner')`.
- `version` aus `config` ignoriert `save.php` (ein alter Tab setzt sie sonst zurück); nur `bumpVersion` zählt hoch.
- Speichern scheitert: 500 mit `COOKIE_BANNER_TEXT['saveFailed']`, Grund ins Log.

## Für Agenten

Code: `lib/consent.php` (Konfig, Erkennen, Umschreiben, Einfügen), `lib/services.php` (Registry, per `require` aus `cookie_banner_services()`), `lib/hooks.php`, `templates/banner.php` (Banner mit Inline-CSS und -JS), `render/settings-link.php`, `admin/module.js`, `api/`.

### Darf

- Dienste in `lib/services.php` ergänzen (`category`, `hosts`, `type` `iframe`|`script`, optional `placeholder`); die Kategorie muss eine feste sein (`COOKIE_BANNER_FIXED_CATEGORIES`), sonst kann der Admin sie entfernen und der Dienst lädt nie. Tabelle oben nachziehen.
- Vorgaben (Texte, Kategorien) in `cookie_banner_default_config()` anpassen; Bestandsbesucher stimmen erst neu zu, wenn der Admin die Version hochzählt.
- Styles in `templates/banner.php` feintunen, Präfix `cc-` einhalten; Laden einzelner Platzhalter verbessern; Felder im Backend ergänzen, wenn neue Konfig-Werte dazukommen.

### Darf nicht

- Consent am Server speichern (DB, Log) oder als Cookie (wäre wieder zustimmungspflichtig).
- Die Registry im Backend bearbeitbar machen.
- „Akzeptieren“ prominenter als „Ablehnen“ machen, eine blockierende Cookie-Wall bauen oder Kategorien außer `necessary` vorab anhaken.
- Google Fonts in `necessary` einsortieren, um den Banner zu umgehen.
- Feste Kategorien entfernbar oder umbenennbar machen: `cookie_banner_merge_config()` ergänzt sie, das Backend sperrt ID und „Entfernen“ (Liste dort gleich halten).
- `filter_site_html` für Nebenwirkungen (DB, Mails) nutzen.

### Stolperfallen

- Der Filter läuft für jede Seite: früh zurück bei `enabled: false`.
- Umschreiben per Regex, bewusst defensiv: überspringt Tags mit `data-cc`, prüft `about:blank`/`data:`/`javascript:`. `data-src` zählt nie als `src` (die Regex braucht `(?<![\w-])src`). Passt eines der `src`-Attribute, fallen alle weg; iframes bekommen `src="about:blank"`, Scripts werden `text/plain` mit `data-cc-src`. Ohne Treffer bleibt der Tag byte-gleich, nie versehentlich alles blockieren.
- Inline-Scripts erkennt nur `cookie_banner_match_inline_service()`; Hosts von `iframe`-Diensten zählen dort bewusst nicht (ein YouTube-Link im Code ist kein Tracker), JSON-Blöcke und Module nie.
- Banner-JS idempotent halten: `applyConsent()` läuft bei jedem Speichern erneut und überspringt Scripts mit `data-cc-loaded`.
- `policyUrl` landet im `href`: nur über `cookie_banner_policy_url_valid()`, beim Speichern abweisen, beim Laden verwerfen.
