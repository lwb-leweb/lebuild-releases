# PDF Viewer (Plugin `pdf-viewer`)

## Zweck

Zeigt ein PDF der Website zum Durchblättern wie ein Heft (Gemeinde- oder Vereinszeitung) und die erste Seite eines PDFs als Titelbild. Gezeichnet wird im Browser mit PDF.js aus `assets/vendor/pdfjs/` (keine Drittanbieter, kein Cookie-Banner nötig). Keine Tabelle, keine Einstellungen; ohne Aktivierung bleiben die Platzhalter leer.

- Breite Bildschirme: Doppelseiten (Titelseite allein rechts), Umblättern als 3D-Drehung. Handy: eine Seite, Wischen oder Tippen links/rechts.
- Pfeiltasten, Vollbild, Seitenzahl, Download-Link; `#seite-<n>` öffnet eine Seite direkt.
- Zoom bis 300 %: Knöpfe, Doppelklick/Doppeltippen (200 % an dieser Stelle, nochmal: zurück), Strg+Mausrad, zwei Finger, Tasten `+`, `-`, `0`. Gezoomt verschieben Ziehen und Mausrad, Blättern bleibt gezoomt (oben links), danach zeichnet er scharf neu. Der Browser selbst zoomt im Viewer nicht.
- Titelseite: gezeichnet, sobald sie in den sichtbaren Bereich kommt (für Karten ohne eigenes Titelbild).
- Nur PDFs dieser Website, die es gibt (Upload oder Datei unter `/public/site/`); anderes ergibt `<!-- pdf-viewer: src invalid -->`.
- CSS und Skript kommen nur auf Seiten mit einem Platzhalter (Hook `filter_site_html`).

Grenzen:

- PDFs anderer Websites gehen nicht (ohne CORS lädt sie der Browser nicht, der Renderer lehnt sie ab).
- WebAssembly liefert der Server unter `/plugins` nicht aus: PDF.js nimmt die JavaScript-Fassung der Bild-Decoder (langsamer bei JPEG 2000). Nicht eingebettete Schriften außer Helvetica/Arial (Liberation Sans) ersetzt der Browser.
- Größe beim Hochladen: `UPLOAD_MAX_BYTES` (15 MB) und die PHP-Grenzen, wirksam ist die kleinste.
- Ein einfacher Klick auf eine Seitenhälfte blättert erst nach 260 ms (Warten auf Doppelklick).
- Leinwände höchstens 3200 px breit; darüber (sehr große Bildschirme bei 300 %) leicht unscharf.

## Einbinden

Shortcode-Regeln allgemein: `docs/knowledgebase/plugins/rendering.md`.

```html
<div data-plugin="pdf-viewer" data-view="blaettern" data-src="/public/site/uploads/zeitung-3-2026-a1b2c3.pdf"></div>
<span data-plugin="pdf-viewer" data-view="titelseite" data-src="/public/site/uploads/zeitung-3-2026-a1b2c3.pdf"></span>
```

| Shortcode | Attribute | Ausgabe |
|---|---|---|
| `blaettern` | `data-src` (Pflicht), `data-download="nein"` blendet „PDF herunterladen“ aus | `.pdf-blaetterer` mit `.pdf-blaetterer__buehne` (gezoomt `.pdf-blaetterer__ausschnitt`, am Element `ist-gezoomt`), `.pdf-blaetterer__leiste` (Knöpfe `.pdf-blaetterer__knopf`, Zoom/Vollbild `--zoom`, `--neben`; `.pdf-blaetterer__seite`, `.pdf-blaetterer__download`) |
| `titelseite` | `data-src` (Pflicht) | `.pdf-titelseite`, nach dem Laden `canvas.pdf-titelseite__bild` (füllt das Element, Größe und Seitenverhältnis gibt die Website vor) |

Mit Content-Typen: Feld der Art `file` für das PDF, die Vorlage gibt den Platzhalter aus. Zeitung: Typ mit `{ "name": "pdf", "type": "file" }` und `actions: ["page"]`; `detail.php` gibt `blaettern` aus, `card.php` `titelseite`, wenn kein eigenes Titelbild gesetzt ist.

```php
<div data-plugin="pdf-viewer" data-view="blaettern" data-src="<?= ct_text($item, 'pdf') ?>"></div>
```

- Auf der eigenen Seite eines Eintrags ersetzt der Renderer den Platzhalter wie auf jeder Seite.
- In Listen (`card.php`, auch `detail.php` im Modal) ersetzt ihn kein Renderer. Nur `titelseite` geht dort: Das Skript liest `data-src` selbst (auch nach `le-list-reloaded`). `blaettern` bleibt dort leer.

Aussehen: Variablen an `.pdf-blaetterer` (`--pdf-blaetterer-hoehe`, `--pdf-blaetterer-text`, `--pdf-blaetterer-knopf`, `--pdf-blaetterer-knopf-text`, `--pdf-blaetterer-knopf-neben`, `--pdf-blaetterer-schatten`). Alle Regeln des Plugins stehen unter `:where()`, jede Regel der Website gewinnt.

## Daten

Keine.

## Endpunkte

Keine.

## Für Agenten

Code: `lib/viewer.php` (Prüfung der Adresse `pdf_viewer_src`, Konstanten), `lib/hooks.php` (CSS in den Kopf, Skript als Modul vor `</body>`), `render/`, `assets/pdf-viewer.js` (Viewer und Titelseiten, ES-Modul), `assets/pdf-viewer.css`, `assets/vendor/pdfjs/` (PDF.js 6.3.289 samt Lizenzen).

### Darf

- Platzhalter in Seiten oder Content-Typ-Vorlagen einbauen.
- Aussehen in der Website über die Variablen und eigene Regeln anpassen.
- Texte in `PDF_VIEWER_TEXT` (`lib/viewer.php`) und `TEXT` (`assets/pdf-viewer.js`) anpassen.
- PDF.js aktualisieren: aus dem npm-Paket `pdfjs-dist` `build/pdf.min.mjs`, `build/pdf.worker.min.mjs`, `standard_fonts/LiberationSans-*.ttf`, `wasm/*_nowasm_fallback.js` und die Lizenzen kopieren, Version hier nennen, Seite mit dem Viewer im Browser prüfen.

### Darf nicht

- `assets/vendor/pdfjs/` von Hand ändern; nur als Ganzes tauschen, Lizenzdateien behalten.
- Fremde Adressen zulassen (`pdf_viewer_src`, `EIGENES_PDF` im Skript).
- PDF.js über ein CDN einbinden: Drittanbieter bräuchten den Cookie-Banner.

### Stolperfallen

- Neue Ansichten, die auch in Listen ohne Renderer funktionieren sollen: im Skript erkennen (wie `titelseite` über `data-plugin="pdf-viewer"` und `data-view`) und in `PDF_VIEWER_MARKS` ergänzen, sonst fehlen CSS und Skript.
- Dateien unter `assets/` mit Endungen außerhalb der Freigabe für `/plugins` (`.wasm`, `.pfb`) liefert der Server nicht aus; darum `useWasm: false`.
- Zoom: Gesten, Mausrad und Klicks hängen an der Bühne (`gesten`, `mausrad`, `tippen`); `touch-action: pan-y`, gezoomt `none`, sonst zoomt wieder der Browser. Stufen und Grenzen in den Konstanten `ZOOM_*` oben im Skript.
- `*.min.mjs` überspringt der Minifier des Kerns, andere JS-Dateien verkleinert er (`backend/site/minify.php`).
