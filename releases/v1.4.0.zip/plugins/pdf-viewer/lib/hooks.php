<?php
declare(strict_types=1);

// Hook des PDF Viewers (docs/knowledgebase/plugins/ref-hooks.md).

/** Hook filter_site_html: Seiten mit einem PDF Viewer oder einer Titelseite bekommen einmal CSS und Skript. */
function pdf_viewer_filter_site_html(string $html): string
{
    $found = false;
    foreach (PDF_VIEWER_MARKS as $mark) {
        if (str_contains($html, $mark)) {
            $found = true;
            break;
        }
    }
    if (!$found) {
        return $html;
    }

    return le_plugin_insert_script(le_plugin_insert_style($html, PDF_VIEWER_ASSETS['style']), PDF_VIEWER_ASSETS['script'], true);
}
