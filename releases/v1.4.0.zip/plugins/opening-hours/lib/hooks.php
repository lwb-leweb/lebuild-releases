<?php
declare(strict_types=1);

// Hook der Öffnungszeiten (docs/knowledgebase/plugins/ref-hooks.md).

/** Hook filter_site_html: Seiten mit Öffnungszeiten bekommen einmal das CSS vor </head>. */
function opening_hours_filter_site_html(string $html): string
{
    if (!str_contains($html, ' ' . OPENING_HOURS_MARK_ATTR)) {
        return $html;
    }

    return le_plugin_insert_style($html, OPENING_HOURS_STYLE);
}
