# Formulare (Plugin `contact-form`)

## Zweck

Rendert per Shortcode das feste Kontaktformular oder ein eigenes Formular aus einer Datei der Website (beliebige Felder, mehrere Schritte, Abhängigkeiten, Anhänge) und schickt es als Textmail über den Mailer des Kerns (SMTP aus den Einstellungen, sonst PHP `mail()`; `docs/knowledgebase/base/mail.md`). Im Admin heißt es „Formulare“, eigene Einstellungen hat es nicht.

- Empfänger: Standard-Empfänger der Einstellungen (beim Absenden gelesen), ein signierter `data-recipient` oder `recipient` der Formular-Datei.
- Spamschutz ohne externen Dienst: Honeypot-Feld `url` (Treffer: stiller 303 wie ein Erfolg, keine Mail) und Bremse je IP: höchstens 5 Versandversuche je Stunde (IPv6 je /64-Netz). Geprüft wird früh, der Platz reserviert erst nach Honeypot und Prüfung der Eingaben, unter einer Dateisperre, direkt vor dem Versand; scheitert er, wird der Platz wieder frei.
- Kontaktformular: Name, E-Mail, Nachricht Pflicht; optionale Zusatzfelder nur aus `contact_form_extra_fields()` (`company` Firma, `phone` Telefon, `telegram` Telegram, `subject` Betreff), je auf eine Zeile bereinigt, höchstens 200 Zeichen, leere übersprungen, mit Label über der Nachricht. Betreff fest `Kontaktformular: {name}`; `subject` ist nur ein Feld im Text.
- Absenden aus dem Browser (`Sec-Fetch-Mode: navigate`, ohne den Header: `Accept` beginnt mit `text/html` und kein `X-Requested-With`): Erfolg und jeder Fehler leiten per 303 auf die Seite zurück (Pfad und Query des Referers, nie ein fremder Host) mit `?kontakt=<ergebnis>#kontaktformular`; das Formular zeigt die Meldung (`p.contact-form__notice--ok`/`--error`), die Eingaben sind nach einem Fehler leer. Per `fetch`/curl gelten die Codes unter „Endpunkte“.

Grenzen:

- Kein Captcha, solange Honeypot und Bremse reichen.
- Die Bremse nutzt `REMOTE_ADDR`: Hinter Cloudflare/Proxy greift sie für alle gemeinsam; `X-Forwarded-For` wird bewusst nicht vertraut (fälschbar).
- Ihr Stand liegt im Cache und geht mit ihm verloren; Dateien, die eine Stunde nicht geschrieben wurden, löscht etwa jede 50. Reservierung.
- Nur Textmails; Anhänge nur bei Formularen aus einer Datei.

## Einbinden

```html
<div data-plugin="contact-form" data-view="form"></div>
<div data-plugin="contact-form" data-view="form" data-recipient="office@example.com"></div>
<div data-plugin="contact-form" data-view="form" data-form="projekt"></div>
```

- `data-recipient`: wird beim Ausgeben signiert (HMAC mit `app_secret()`). Ohne ihn stehen weder Adresse noch Signatur in der Seite.
- `data-form`: Name einer Datei `website/public/includes/forms/<name>.json`; dann gilt das Formular aus der Datei statt des Kontaktformulars. Die Datei liegt im Repo der Website, der Kunde bearbeitet sie nicht. Beispiel mit allen Feldtypen und einer Abhängigkeit: `website/public/includes/forms/projekt.json` (Testseite `/anfrage`).
- Eigenes Markup statt Shortcode: Zusatzfelder unter ihren Namen posten und das Honeypot-Feld `url` mitschicken (off-screen, `autocomplete=off`, `tabindex=-1`, `aria-hidden`).

Formular-Datei:

| Schlüssel | Bedeutung |
|---|---|
| `title` | erste Zeile der Mail, Vorgabe für den Betreff (sonst „Formular“) |
| `subject` | Betreff, `{feldname}` wird durch den Wert ersetzt (optional) |
| `recipient` | Empfänger (optional, sonst Standard-Empfänger) |
| `submit`, `next`, `back` | Knopftexte (Vorgabe Absenden, Weiter, Zurück) |
| `success` | eigene Erfolgsmeldung (optional) |
| `fields` oder `steps` | Liste der Felder oder Schritte `[{ "title": "…", "showIf": …, "fields": [...] }]` |

Feld: `name` (`a-z0-9_`, eindeutig, nicht `url`, `form`, `recipient`, `recipient_sig`), `label`, `type`, optional `required`, `placeholder`, `help`, `showIf`.

| `type` | Extra | In der Mail |
|---|---|---|
| `text`, `tel`, `textarea` | `maxlength` (höchstens 200, mehrzeilig 5000) | Wert |
| `email` | – | Wert; das erste E-Mail-Feld wird Reply-To |
| `number` | `min`, `max`, `step` | Wert |
| `date` | – | `JJJJ-MM-TT` |
| `select`, `radio` | `options` (Liste aus Texten) | gewählte Option |
| `checkbox` | mit `options` Mehrfachauswahl, ohne ein Kästchen (Zustimmung) | Optionen mit Komma bzw. „Ja“ |
| `file` | `multiple`, `accept` (Teilmenge von pdf, jpg, jpeg, png, webp, heic, docx, xlsx) | Dateinamen, Dateien als Anhang |

- `showIf` an Feld oder Schritt: `{ "field": "bestehend", "value": "Ja" }` oder `"value": ["A", "B"]` (eine genügt, bei Checkboxen: eine angehakt). Nur auf frühere Felder mit `options` und deren Optionen, sonst ist die Datei ungültig. Ausgeblendet heißt nicht ausgefüllt: im Browser `disabled`, `required` nur solange sichtbar, Schritte fallen aus „Weiter“ und der Zählung; Ketten gehen.
- Der Server prüft jede Eingabe gegen die Datei (Pflicht, Typ, Optionen, Bedingungen) und übergeht ausgeblendete Felder (keine Prüfung, nicht in der Mail, Anhänge verworfen). Andere POST-Felder zählen nicht.
- Anhänge: Endung und Inhalt (finfo, falls vorhanden, sonst nur die Endung); `docx`/`xlsx` mit der zip-Erweiterung nur echte Word- bzw. Excel-Dokumente (`[Content_Types].xml` nennt einen vorhandenen Hauptteil dieser Art; keine Makro-Dokumente), ohne sie reicht finfo. Zusammen höchstens 10 MB und 10 Dateien; nichts bleibt auf dem Server.
- `assets/form.js` zeigt Schritte einzeln mit Weiter/Zurück, prüft je Schritt und die Größe der Anhänge und setzt `--le-form-progress` (0 bis 1) an `.le-form__progress`. Ohne JavaScript stehen alle Schritte und Felder da, bedingte ohne `required`.
- Eine kaputte Datei gibt nur `<!-- contact-form: form invalid -->` aus, der Grund steht im PHP-Log.
- Klassen: `le-form`, `le-form__step`, `le-form__step-title`, `le-form__progress`, `le-form__field` (`--<type>`), `le-form__option`, `le-form__help`, `le-form__required`, `le-form__nav`, `le-form__back`, `le-form__next`, `le-form__submit`, `le-form__notice--ok`/`--error`.

## Daten

Keine Tabelle, keine Inhalte. Stand der Bremse: `website/private/cache/contact-form/ratelimit/<hash>.json`, nur HMAC der IP mit dem Installations-Schlüssel und Zeitstempel, wegwerfbar.

## Endpunkte

Öffentlich, ohne Anmeldung und CSRF (Besucher senden ab), nur POST (sonst 405); Kopf allgemein: `docs/knowledgebase/plugins/endpoints.md`.

- `api/submit.php`: Kontaktformular, Felder `name`, `email`, `message`, optional Zusatzfelder, `recipient` und `recipient_sig` (nur mit `data-recipient`), Honeypot `url`.
- `api/form.php?form=<name>` (multipart): Felder der Datei; der Name steht in der Adresse, damit er auch ankommt, wenn PHP eine zu große Anfrage samt `$_POST` verwirft. Aus dem Browser `?formular-<name>=<ergebnis>#formular-<name>`.

| Fall | Code | Text (`CONTACT_FORM_TEXT`) | Ergebnis in der Adresse |
|---|---|---|---|
| Erfolg, Honeypot-Treffer | 303 auf den Referer | – | `gesendet` |
| Pflichtfeld fehlt / E-Mail ungültig | 400 | „Fehlende Felder.“ / „Ungültige E-Mail.“ | `fehlende-felder` / `ungueltige-email` |
| nur `form.php`: Eingabe, Dateityp, Name | 400 | „Bitte die Eingaben prüfen.“, „Dieser Dateityp ist nicht erlaubt.“, „Unbekanntes Formular.“ | `ungueltig`, `dateityp`, `unbekannt` |
| nur `form.php`: zu groß | 413 | „Die Dateien sind zu groß.“ | `zu-gross` |
| Bremse | 429 | „Zu viele Anfragen, bitte später erneut.“ | `zu-viele` |
| kein Empfänger / Versand scheitert | 500 | „Empfänger-Adresse nicht konfiguriert.“ / „Versand fehlgeschlagen.“ | `kein-empfaenger` / `versand` |

## Für Agenten

Code: `lib/contact.php` (Empfänger, Signatur `CONTACT_FORM_SIGNATURE_CONTEXT`, Zusatzfelder, Mailtext `contact_form_mail`, Honeypot, Antworten), `lib/rate-limit.php` (`CONTACT_FORM_RATE_*`), `lib/definition.php` (Datei lesen und prüfen, Mailtext), `lib/input.php` (Eingaben und Anhänge), `api/`, `render/form.php`, `templates/definition.php`, `assets/form.js`; Tests in `tests/plugins/forms.test.php`.

### Darf

- Pflichtfeld im Kontaktformular: rendern in `render/form.php`, lesen und prüfen in `api/submit.php`, in `contact_form_mail()` aufnehmen.
- Zusatzfeld: Schlüssel und Label in `contact_form_extra_fields()` (Reihenfolge = Mailtext, Label generisch); Renderer und Mailtext ziehen von selbst nach. Nie ein reservierter Name (`name`, `email`, `message`, `recipient`, `recipient_sig`, Honeypot).
- Feldtyp für Formular-Dateien: `CONTACT_FORM_FIELD_TYPES`, Extras in `contact_form_definition_field()`, Wert in `contact_form_definition_input()`/`contact_form_value_valid()`, HTML in `templates/definition.php`, Test.
- Betreff, Textformat und Weiterleitung vorsichtig anpassen; Spamschutz ergänzen.

### Darf nicht

- SMTP-Logik ins Plugin kopieren oder Passwörter in Konfig, Seiten-JSON oder Manifest speichern; nur `core_mail_send()` aufrufen.
- Die Signatur des Empfängers entfernen: Sonst setzen Posts beliebige Empfänger. Standard-Empfänger nie im Plugin festschreiben.
- Eine Datenbank einbauen; beliebige `$_POST`-Schlüssel übernehmen.
- `subject` den Betreff setzen lassen (Header-Injection).

### Stolperfallen

- Dynamische Werte im Renderer und in `templates/definition.php` immer escapen (`docs/knowledgebase/plugins/rendering.md`).
- Formular-Dateien sind vertrauenswürdig, Besucher schicken nur den Namen; in einen Pfad nur nach `contact_form_definition_name_valid()`, ins Log nie roh.
- `showIf` wertet der Server selbst aus (`contact_form_condition_met()`), nie dem Browser glauben.
- Anhänge haben eine eigene Liste (`CONTACT_FORM_FILE_TYPES`, OOXML über `contact_form_ooxml_valid`), die Upload-Whitelist des Kerns gilt nicht: Sie werden nur gemailt.
- Werte kommen wörtlich in die Mail („<3“ bleibt), das geht nur mit `text/plain`; eine HTML-Mail müsste jeden Wert escapen.
- Besucher-E-Mail nur als `Reply-To`, nie als Absender. SMTP-Fehler nie an den Browser; Antworttexte nur aus `CONTACT_FORM_TEXT`.
- Honeypot-Treffer nie mit 400/500 beantworten, immer 303 (`contact_form_submit_redirect()`).
- Bremse: `contact_form_rate_check()` ist nur die frühe 429-Prüfung; `contact_form_rate_reserve()` erst nach Honeypot und Prüfung, vor `core_mail_send()`, bei Fehler `contact_form_rate_release()`. Früher reservieren hieße: Bots füllen das Fenster mit Müll und sperren echte Besucher aus.
- Nie die Roh-IP speichern, nur `hash_hmac('sha256', le_login_ip_key(IP), app_secret())`.
