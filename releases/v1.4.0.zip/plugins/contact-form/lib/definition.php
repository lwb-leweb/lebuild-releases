<?php
declare(strict_types=1);

// Formulare aus einer Datei: public/includes/forms/<name>.json (Aufbau in README.md, „Einbinden“).
// Die Datei kommt aus dem Repo der Website und ist vertrauenswürdig; Besucher schicken nur den Namen.

const CONTACT_FORM_DEFINITION_DIR = LE_SITE_ROOT . '/' . LE_SITE_INCLUDES_DIR . '/forms';
const CONTACT_FORM_FIELD_TYPES = ['text', 'textarea', 'email', 'tel', 'number', 'date', 'select', 'radio', 'checkbox', 'file'];
// Diese Namen belegt das Plugin selbst (Honeypot, Kontaktformular).
const CONTACT_FORM_RESERVED_FIELDS = [CONTACT_FORM_HONEYPOT, 'form', 'recipient', 'recipient_sig'];

function contact_form_definition_name_valid(string $name): bool
{
    return (bool) preg_match('/^[a-z0-9][a-z0-9-]{0,40}\z/', $name);
}

/** Anker und Markierung in der Adresse eines Formulars aus einer Datei (?formular-<name>=…#formular-<name>). */
function contact_form_definition_anchor(string $name): string
{
    return 'formular-' . $name;
}

/**
 * Lädt und prüft die Formular-Datei. Liefert die bereinigte Definition mit `steps` (immer eine Liste, ein Formular
 * ohne Schritte hat genau einen ohne Titel). Wirft RuntimeException mit dem ersten Fehler (für uns, nie an Besucher).
 */
function contact_form_definition(string $name): array
{
    if (!contact_form_definition_name_valid($name)) {
        throw new RuntimeException('Ungültiger Formularname.');
    }
    $raw = @file_get_contents(CONTACT_FORM_DEFINITION_DIR . '/' . $name . '.json');
    if ($raw === false) {
        throw new RuntimeException("Formular-Datei forms/$name.json fehlt.");
    }
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        throw new RuntimeException("forms/$name.json ist kein gültiges JSON-Objekt.");
    }

    $str = static fn (mixed $value): string => is_string($value) ? trim($value) : '';
    $title = $str($data['title'] ?? '');
    $recipient = $str($data['recipient'] ?? '');
    if ($recipient !== '' && !filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
        throw new RuntimeException('recipient ist keine E-Mail-Adresse.');
    }

    $rawSteps = isset($data['steps']) ? $data['steps'] : [['fields' => $data['fields'] ?? null]];
    if (!is_array($rawSteps) || $rawSteps === [] || !array_is_list($rawSteps)) {
        throw new RuntimeException('steps muss eine Liste sein.');
    }
    $steps = [];
    $seen = []; // name → bereinigtes Feld, in Reihenfolge (showIf darf nur auf frühere zeigen)
    foreach ($rawSteps as $i => $step) {
        if (!is_array($step) || !is_array($step['fields'] ?? null) || $step['fields'] === [] || array_values($step['fields']) !== $step['fields']) {
            throw new RuntimeException('Schritt ' . ($i + 1) . ': fields muss eine nicht leere Liste sein.');
        }
        $stepIf = contact_form_definition_condition($step['showIf'] ?? null, $seen, 'Schritt ' . ($i + 1));
        $fields = [];
        foreach ($step['fields'] as $field) {
            $raw = $field;
            $field = contact_form_definition_field($field);
            if (isset($seen[$field['name']])) {
                throw new RuntimeException('Feld ' . $field['name'] . ' kommt doppelt vor.');
            }
            $field['showIf'] = contact_form_definition_condition($raw['showIf'] ?? null, $seen, 'Feld ' . $field['name']);
            $seen[$field['name']] = $field;
            $fields[] = $field;
        }
        $steps[] = ['title' => $str($step['title'] ?? ''), 'showIf' => $stepIf, 'fields' => $fields];
    }

    return [
        'name' => $name,
        'title' => $title !== '' ? $title : 'Formular',
        'subject' => $str($data['subject'] ?? ''),
        'recipient' => $recipient,
        'submit' => $str($data['submit'] ?? '') ?: 'Absenden',
        'next' => $str($data['next'] ?? '') ?: 'Weiter',
        'back' => $str($data['back'] ?? '') ?: 'Zurück',
        'success' => $str($data['success'] ?? ''),
        'steps' => $steps,
    ];
}

/** Ein Feld der Definition prüfen und mit Vorgaben auffüllen. */
function contact_form_definition_field(mixed $field): array
{
    if (!is_array($field)) {
        throw new RuntimeException('Ein Feld ist kein Objekt.');
    }
    $name = is_string($field['name'] ?? null) ? $field['name'] : '';
    if (!preg_match('/^[a-z][a-z0-9_]{0,40}$/', $name) || in_array($name, CONTACT_FORM_RESERVED_FIELDS, true)) {
        throw new RuntimeException('Feldname „' . $name . '“ ungültig oder reserviert.');
    }
    $type = is_string($field['type'] ?? null) ? $field['type'] : 'text';
    if (!in_array($type, CONTACT_FORM_FIELD_TYPES, true)) {
        throw new RuntimeException("Feld $name: Typ „{$type}“ unbekannt.");
    }
    $label = is_string($field['label'] ?? null) ? trim($field['label']) : '';
    if ($label === '') {
        throw new RuntimeException("Feld $name: label fehlt.");
    }
    $clean = [
        'name' => $name,
        'type' => $type,
        'label' => $label,
        'required' => ($field['required'] ?? false) === true,
        'placeholder' => is_string($field['placeholder'] ?? null) ? $field['placeholder'] : '',
        'help' => is_string($field['help'] ?? null) ? $field['help'] : '',
        'options' => [],
    ];

    if (in_array($type, ['select', 'radio', 'checkbox'], true)) {
        $options = $field['options'] ?? [];
        if (!is_array($options) || array_values($options) !== $options || array_filter($options, static fn ($o): bool => !is_string($o) || trim($o) === '') !== []) {
            throw new RuntimeException("Feld $name: options muss eine Liste aus Texten sein.");
        }
        if ($options === [] && $type !== 'checkbox') {
            throw new RuntimeException("Feld $name: options fehlt.");
        }
        $clean['options'] = array_values(array_unique(array_map('trim', $options)));
    }
    if ($type === 'number') {
        foreach (['min', 'max', 'step'] as $key) {
            if (isset($field[$key]) && !is_int($field[$key]) && !is_float($field[$key])) {
                throw new RuntimeException("Feld $name: $key muss eine Zahl sein.");
            }
            $clean[$key] = $field[$key] ?? null;
        }
    }
    if ($type === 'file') {
        $accept = $field['accept'] ?? array_keys(CONTACT_FORM_FILE_TYPES);
        if (!is_array($accept) || $accept === [] || array_diff($accept, array_keys(CONTACT_FORM_FILE_TYPES)) !== []) {
            throw new RuntimeException("Feld $name: accept nur aus " . implode(', ', array_keys(CONTACT_FORM_FILE_TYPES)) . '.');
        }
        $clean['accept'] = array_values(array_unique($accept));
        $clean['multiple'] = ($field['multiple'] ?? false) === true;
    }
    if (in_array($type, ['text', 'textarea', 'tel'], true)) {
        $limit = $type === 'textarea' ? CONTACT_FORM_TEXTAREA_MAX : CONTACT_FORM_TEXT_MAX;
        $max = $field['maxlength'] ?? $limit;
        if (!is_int($max) || $max < 1 || $max > $limit) {
            throw new RuntimeException("Feld $name: maxlength zwischen 1 und $limit.");
        }
        $clean['maxlength'] = $max;
    }
    return $clean;
}

/**
 * Bedingung `showIf` eines Feldes oder Schritts: { "field": "<früheres Feld mit options>", "value": "<Option>" | [Optionen] }.
 * Erfüllt, wenn das Feld eine der Optionen hat (bei Checkboxen: eine davon angehakt). null ohne Bedingung.
 */
function contact_form_definition_condition(mixed $raw, array $known, string $where): ?array
{
    if ($raw === null) {
        return null;
    }
    $ref = is_array($raw) && is_string($raw['field'] ?? null) ? $raw['field'] : '';
    if (!isset($known[$ref]) || $known[$ref]['options'] === []) {
        throw new RuntimeException("$where: showIf.field muss ein früheres Feld mit options sein.");
    }
    $values = $raw['value'] ?? null;
    $values = is_string($values) ? [$values] : $values;
    if (!is_array($values) || $values === [] || array_values($values) !== $values
        || array_diff(array_map(static fn ($v) => is_string($v) ? trim($v) : null, $values), $known[$ref]['options']) !== []) {
        throw new RuntimeException("$where: showIf.value muss eine oder mehrere Optionen von $ref sein.");
    }
    return ['field' => $ref, 'values' => array_values(array_unique(array_map('trim', $values)))];
}

/** Bedingung erfüllt bei diesen (bereits geprüften) Werten? Ausgeblendete Felder haben keinen Wert. */
function contact_form_condition_met(?array $condition, array $values): bool
{
    if ($condition === null) {
        return true;
    }
    $value = $values[$condition['field']] ?? '';
    $list = is_array($value) ? $value : ($value === '' ? [] : [$value]);
    return array_intersect($list, $condition['values']) !== [];
}

/** Alle Felder der Definition in Reihenfolge. */
function contact_form_definition_fields(array $definition): array
{
    return array_merge(...array_map(static fn (array $step): array => $step['fields'], $definition['steps']));
}

/** Betreff und Text der Mail eines Formulars aus einer Datei (text/plain, Werte wörtlich). */
function contact_form_definition_mail(array $definition, array $values): array
{
    $lines = [];
    $multi = count($definition['steps']) > 1;
    foreach ($definition['steps'] as $step) {
        $stepLines = [];
        foreach ($step['fields'] as $field) {
            $value = $values[$field['name']] ?? '';
            if (is_array($value)) {
                $value = implode(', ', $value);
            }
            if ($value === '') {
                continue;
            }
            $stepLines[] = $field['type'] === 'textarea'
                ? $field['label'] . ":\n" . $value . "\n"
                : $field['label'] . ': ' . $value;
        }
        if ($stepLines === []) {
            continue;
        }
        if ($multi && $step['title'] !== '') {
            $lines[] = ($lines === [] ? '' : "\n") . '-- ' . $step['title'] . ' --';
        }
        array_push($lines, ...$stepLines);
    }

    // Betreff aus der Datei, {feld} wird durch den (einzeiligen) Wert ersetzt.
    $subject = $definition['subject'] !== '' ? $definition['subject'] : $definition['title'];
    $subject = preg_replace_callback('/\{([a-z][a-z0-9_]*)\}/', static function (array $m) use ($values): string {
        $value = $values[$m[1]] ?? '';
        return core_mail_clean_header(is_array($value) ? implode(', ', $value) : $value);
    }, $subject) ?? $subject;

    return [
        'subject' => mb_substr(core_mail_clean_header($subject), 0, 150) ?: $definition['title'],
        'text' => $definition['title'] . "\n\n" . rtrim(implode("\n", $lines)) . "\n",
    ];
}

/** Antwort-Adresse: das erste befüllte E-Mail-Feld. */
function contact_form_definition_reply_to(array $definition, array $values): string
{
    foreach (contact_form_definition_fields($definition) as $field) {
        if ($field['type'] === 'email' && ($values[$field['name']] ?? '') !== '') {
            return $values[$field['name']];
        }
    }
    return '';
}
