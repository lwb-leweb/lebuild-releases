# Typen definieren (`typen.json`)

Alle Typen einer Website stehen in `website/public/includes/content-types/typen.json`, einer Liste (JSON-Array) aus je einem Objekt pro Typ. Daneben je Typ ein Ordner `<name>/` mit den Vorlagen (`templates.md`) und optional dem Startpaket `eintraege.json`; `includes/` ist von außen gesperrt.

Änderungen gelten sofort, am Server nach `deploy`. Vorbild auf der Testseite: Typ `blog` (`website/public/includes/content-types/typen.json`).

## Aufbau

```json
{
  "name": "standorte",
  "label": "Standorte",
  "fields": [
    { "name": "city", "label": "Stadt", "type": "text", "required": true },
    { "name": "address", "label": "Adresse", "type": "text" },
    { "name": "image", "label": "Bild", "type": "image" }
  ]
}
```

| Schlüssel | Pflicht | Bedeutung |
|---|---|---|
| `name` | ja | Kennung und Ordner der Vorlagen, in `typen.json` eindeutig |
| `label` | ja | Beschriftung in der Seitenleiste |
| `fields` | ja, nicht leer | Felder des Typs |
| `actions`, `defaultAction`, `page` | nein | Klickziele, siehe unten |
| `orderBy`, `publishField`, `expireField` | nein | Reihenfolge und Veröffentlichung, siehe unten |
| `single` | nein | `{ "label": "Galerie" }`: Name auf den Knöpfen der Ansicht `single` („Galerie bearbeiten“, „Galerie anlegen“, `lists.md`); `label` ein nicht leerer Text, sonst ist der Typ ungültig |

Ein Typ mit Stadt, Adresse und Bild wie oben braucht nichts weiter: Beim nächsten Laden des Backends steht er in der Seitenleiste.

## Namen

- `name`: Kleinbuchstaben, Ziffern, `-`, `_`, beginnt mit einem Buchstaben (`referenzen`, `case-studies`). Zwei Typen gleichen Namens meldet `CONTENT_TYPES_FILE_TEXT['duplicate']`.
- `fields[].name`: Regel des Kerns (`docs/knowledgebase/plugins/ref-field-types.md`, „Schlüssel jedes Feldes“), also kein Bindestrich (`logo_url`).
- Kein Feld darf wie eine Spalte von `content_items` heißen (`CONTENT_TYPES_DB_COLUMNS`: `id`, `content_type`, `data`, `sort_order`, `created_at`, `updated_at`), sonst ist der Typ ungültig: Die Spalte überdeckte den Wert beim Lesen.
- `action` (ab zwei Zielen), `url` (mit `link`) und `slug` (mit `page`) legt das Plugin selbst an; ein eigenes Feld so zu nennen macht den Typ ungültig.
- `<bild>_focus` gehört dem Fokuspunkt jedes Bildfelds auf seiner Ebene (oben bzw. in einer Zeile von `list`); ein Feld dieses Namens auf derselben Ebene macht den Typ ungültig (Fehler nennt es in einer Zeile `liste.bild_focus`).

## Felder

Feldarten, `required`, `options`, `list`, `blocks` und ihre Speicherung: `docs/knowledgebase/plugins/ref-field-types.md`.
Dort auch `size` an Bildfeldern und `copy` (Wert nicht in eine Kopie übernehmen); anders als im Kern (dort fällt es weg) macht ein ungültiger Wert hier den Typ ungültig, ebenso `copy` an einem Unterfeld von `list` (an einem Unterfeld nennt der Fehler es `liste.feld`). Ein altes `fit` wird still ignoriert.
Nur hier gibt es diese Optionen, und nur an Feldern des Typs, nicht an Unterfeldern von `list`:

### `optionsFrom` (an `select`)

- `"optionsFrom": "<typ>"`: Die Optionen sind die Titel der Einträge dieses Typs (Textfeld `name` oder `title`, sonst das erste Textfeld) in dessen Reihenfolge, ohne leere und doppelte. Für Kategorien, die der Kunde selbst pflegt.
- Gespeichert wird der Titel als Text; `data-filter`, Filterleiste und Vorlagen behandeln ihn wie `options`.
- Im Formular steht am Ende „+ <Label> hinzufügen“: legt den Namen im anderen Typ an (`optionsCreate`, über `api/save.php`).
- Umbenennen dort zieht alle Einträge mit dem alten Wert nach, außer ein anderer Eintrag dort trägt den alten Namen noch (`content_types_rename_option`). Ein gelöschter Wert bleibt beim Eintrag erhalten und wählbar.
- Der andere Typ muss existieren, ein anderer sein und ein Textfeld haben, sonst ist der Typ ungültig.

### `column`

- `"column": true` zeigt das Feld in der Liste im Backend als Spalte neben dem Titel; ein Bild als Vorschau davor. Nur die zwei, drei Felder markieren, an denen der Kunde Einträge erkennt (Datum, Ort, Kategorie).
- Erlaubt an `text`, `textarea`, `number`, `date`, `datetime`, `select`, `boolean`, `image`, `url` (`CONTENT_TYPES_COLUMN_FIELD_TYPES`); ein anderer Wert als `true`/`false` oder eine andere Art macht den Typ ungültig.
- Ohne solche Felder zeigt die Liste das erste Bild und das erste Datumsfeld aus `orderBy`, `publishField` oder `expireField`.

### `fallback` (an `text`, `textarea`)

- `"fallback": "<feld>"`: Ist das Feld leer, zeigt die Website den Anfang des anderen Feldes als Klartext, höchstens 200 Zeichen inkl. „…“ (`CONTENT_TYPES_FALLBACK_MAX`). Gespeichert bleibt das Feld leer.
- Beispiel Kurzfassung: `{ "name": "kurz", "label": "Kurzfassung (leer: Anfang des Beitrags)", "type": "textarea", "fallback": "text" }`, dann ohne `required`.
- Quelle: ein anderes Feld der Art `text`, `textarea`, `richtext` oder `blocks` (dort zählen Text- und Zitat-Blöcke) ohne eigenes `fallback`; sonst ist der Typ ungültig.
- Gilt in den Vorlagen und für `descriptionField`, nicht in der Standardausgabe des Shortcodes und nicht in `public.php`.

## Klickziele: `actions`, `defaultAction`, `page`

Was ein Eintrag beim Klick tut. Ohne `actions` gilt `["none"]`.

```json
"actions": ["modal", "link", "page", "none"],
"defaultAction": "modal",
"page": { "path": "leistungen", "titleField": "title", "descriptionField": "tagline", "schema": "BlogPosting" }
```

| Schlüssel | Bedeutung |
|---|---|
| `actions` | Liste aus `none` (nicht klickbar), `link`, `page` (eigene Seite), `modal`, jedes höchstens einmal |
| `defaultAction` | Vorgabe für neue Einträge und Einträge ohne erlaubtes `action`; muss in `actions` stehen, fehlt er, gilt das erste Ziel |
| `page.path` | Pflicht mit `page`: erstes Stück der Adresse `/<path>/<slug>`; Buchstaben, Ziffern, `-`, `_` |
| `page.titleField` | Pflicht mit `page`: Feld der Art `text`, Titel der Seite und Quelle der Adresse |
| `page.descriptionField` | Pflicht mit `page`: Feld der Art `text`, `textarea`, `richtext` oder `blocks`, Meta-Beschreibung |
| `page.schema` | optional `Article`, `BlogPosting` oder `NewsArticle`: strukturierte Daten (`templates.md`, „Eigene Seite“) |

- `page.path` darf kein Ordner, keine Datei ohne Endung der Website, keine Adresse des Editors (`admin`, `login`, `api`, `plugins`, `public`, `includes`) und nicht der `path` eines anderen Typs sein (dann sind beide ungültig). Eine Seite gleichen Namens geht: `/aktuelles` bleibt die Seite mit der Liste, `/aktuelles/<slug>` sind die Einträge.
- Formular: ab zwei Zielen oben „Beim Klick“ (nur erlaubte Ziele, vorausgewählt `defaultAction`); mit `link` das Feld „Link“ (Pflicht beim Ziel Link), mit `page` „Adresse“ (aus `titleField`, eindeutig im Typ). Beide nur sichtbar, wenn „Beim Klick“ passt, bei genau einem Ziel immer.
- Ein verstecktes Feld übernimmt der Server nicht, es bleibt der gespeicherte Wert; es blockiert das Speichern also nie.
- Gespeichert im `data`-JSON des Eintrags unter `action`, `url`, `slug`.

## Reihenfolge und Veröffentlichung: `orderBy`, `publishField`, `expireField`

```json
"orderBy": { "field": "datum", "direction": "desc" },
"publishField": "datum"
```

| Schlüssel | Bedeutung |
|---|---|
| `orderBy` | `field`: Feld der Art `text`, `number`, `date`, `datetime` oder `created` (Anlegedatum, sofern kein eigenes Feld so heißt); `direction` `asc` (Vorgabe) oder `desc`. Ohne Wert zählt bei `date`/`datetime` das Anlegedatum, sonst steht der Eintrag am Ende |
| `publishField` | Feld der Art `date` oder `datetime`: Auf der Website (Liste, eigene Seite, `public.php`, Sitemap) erst ab diesem Zeitpunkt, leer heißt sofort |
| `expireField` | Feld der Art `date` oder `datetime`: Auf der Website nur bis zu diesem Zeitpunkt, bei `date` bis zum Ende des Tages; leer heißt immer. Darf dasselbe Feld wie `publishField` oder `orderBy` sein |

- Wirkung auf Liste und Ziehen: `lists.md`, „Reihenfolge“.
- Blog: `actions: ["page"]`, `orderBy` auf das Datum absteigend, `publishField` aufs selbe Feld.
- Veranstaltungen: `orderBy` aufs Datum aufsteigend, `expireField` aufs selbe Feld, bei mehrtägigen auf ein eigenes Feld `bis`.

## Ungültige Typen

Ein Typ ohne `label` oder `fields` oder mit einem Fehler aus diesem Artikel (Texte `CONTENT_TYPES_INVALID_TEXT`) fehlt in Seitenleiste, API und Website (Ausgabe der Liste: `lists.md`, „Fehler“). Den Grund zeigt das Backend unter „Ungültige Content-Typen“, bei ungültigen und unlesbaren Definitionen auch das Log. Ebenso dort, aber nicht im Log: kaputtes `typen.json`, Eintrag ohne gültigen `name`, doppelter Typ und Typen, die fehlen, aber noch Einträge in der Datenbank haben (die bleiben dort).

## Startpakete (`<typ>/eintraege.json`)

- Format wie beim Import (`import.md`). Beim ersten Zugriff des aktiven Plugins (Seite mit Liste, Backend, API) kommen die Einträge in die Datenbank, wenn der Typ noch keine hat (`content_types_seed`, ganz oder gar nicht, Bilder müssen existieren, z. B. unter `/public/site/`).
- Danach ist die Datei weg, auch wenn der Typ schon Einträge hatte. Gelöschte Einträge löschen Bilder der Website nie, nur Uploads.
- Ein Typ mit `optionsFrom` braucht die Einträge des anderen: Startpakete laufen in zwei Durchgängen.
- Scheitert eines (etwa weil Fotos am Server noch fehlen), bleibt es liegen und steht im Log. Erneut versucht wird es nur bei einem Aufruf mit angemeldeter Editor-Sitzung, nie bei einem Besucher (gemerkt in `website/private/cache/content-types-seed-failed`). Neue Startpakete versucht jeder Aufruf. Ein Lauf, in dem die Datenbank gerade gesperrt war (`db_error_transient`), merkt nichts als gescheitert, auch keinen Typ mit `optionsFrom` auf den gesperrten.
- Gleichzeitige Aufrufe warten auf eine Sperre (`store_lock('content-types-website')`); während eines Datenbank-Umzugs wird nichts eingespielt, ebenso nicht ohne Verbindung zur Datenbank und solange das Schema des Plugins nicht fertig oder fehlgeschlagen ist (auch erst bei dieser Verbindung, `le_plugin_schema_ready`); die Datei wartet dann ohne Fehlschlag auf eine spätere Anfrage (`docs/knowledgebase/plugins/versioning.md`).

## Frühere Ablage

Gibt es noch kein `typen.json`, fasst `content_types_migrate()` einmal zusammen, was früher einzeln lag: `website/private/plugins/content-types/<typ>.json` und `<typ>/typ.json` der Website (übernommene vermerkt in `.website-typen.json`).

- Inhalt unter `website/private/` gewinnt; nach Name sortiert, gleiche Dateien ergeben byte-gleich dieselbe `typen.json` (im Klon wie am Server).
- Danach sind die alten Dateien weg, ebenso `eintraege.json` übernommener Typen. Unlesbare Definitionen bleiben liegen und fehlen in `typen.json` (Log).
