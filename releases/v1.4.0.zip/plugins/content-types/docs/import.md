# Einträge importieren

Einträge eines Typs aus einer JSON-Datei anhängen: im Backend in der Liste „Importieren“ (nur Admins), Ergebnis oder Fehler mit Zeile und Feld stehen über der Liste. Dasselbe Format haben die Startpakete `<typ>/eintraege.json` (`types.md`, „Startpakete“).

## Endpunkt `api/import.php`

| | |
|---|---|
| Aufruf | POST, Anmeldung als Admin, CSRF; JSON `{type, entries: [{…}, …]}` |
| Erfolg | `{ok, imported}` |
| Ungültiger Eintrag | 422 `{ok:false, error, fields: [{line, id, label, reason}]}` |
| Fehler der ganzen Datei (keine Liste, leer, zu viele, Zeile kein Objekt) | 422 mit leerem `fields` |
| Größer als 5 MB (`CONTENT_TYPES_IMPORT_MAX_BYTES`) | 413, geprüft vor dem Einlesen |

Der Import läuft unter der Sperre der offenen Uploads (`le_open_uploads_hold`), damit kein Bild mitten im Import verschwindet.

## Format

Eine Liste von Einträgen wie `data` bei `api/save.php`, mit den Feldnamen des Typs. Beispiel für einen Typ mit `actions: ["modal", "link"]`:

```json
[
  { "title": "Pentest", "bild": "/public/site/uploads/pentest-a1b2c3.webp",
    "features": [ { "title": "Webanwendungen", "icon": "/public/site/img/web.svg" } ] },
  { "title": "Blog", "action": "link", "url": "https://example.com/blog" }
]
```

## Regeln

- Ganz oder gar nicht: Jeder Eintrag wird wie beim Speichern geprüft; ein Fehler und nichts ist importiert. Meldung „Zeile 3, Titel: Pflichtfeld ist leer.“ (Zeile = Position in der Liste ab 1), in Unterfeldern mit der Nummer der Zeile im Feld: „Zeile 3, Punkt 2 › Link: Bitte eine Adresse wie https://… eingeben.“
- Höchstens 500 Einträge (`CONTENT_TYPES_IMPORT_MAX`); leere Liste: 422.
- Neue Einträge kommen in dieser Reihenfolge ans Ende (`sort_order` ab `MAX+1`), vorhandene bleiben unverändert (angehängt, nie ersetzt).
- `id`, `sort_order` und Schlüssel, die kein Feld des Typs sind, fallen weg.
- Werte wie im Formular: Text, Zahl oder `true`/`false` (Objekte und Listen: `docs/knowledgebase/plugins/ref-field-types.md`). Ein leeres `[]` als Eintrag gilt wie `{}`.
- `action` fehlt: `defaultAction`. Ein Ziel, das der Typ nicht erlaubt, wird abgelehnt (auch bei nur einem Ziel); hat ein Typ mit einem Ziel ein eigenes Feld `action`, ist es ein normales Feld.
- Adressen (`slug`) werden wie beim Anlegen eindeutig, auch innerhalb der Datei (`-2`, `-3` …).
- Bilder und PDFs (auch in Zeilen von `list`) nur als vorhandene Dateien unter `/public/site/uploads/` oder `/public/site/` mit erlaubter Endung (`upload_image_exists`, Whitelist: `docs/knowledgebase/media/rules.md`). Fremde Adressen (auch `data:`, `ftp:`), fehlende Dateien, Pfade mit `..` und Links, die aus dem Ordner führen, werden abgelehnt. Fotos also vorher dort ablegen.
