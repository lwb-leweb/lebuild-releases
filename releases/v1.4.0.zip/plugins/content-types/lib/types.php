<?php
declare(strict_types=1);

// Content-Typen: Typ-Definition lesen und prüfen (Klickziele, eigene Seite, Reihenfolge, Zeitfenster, Spalten, fallback,
// Bild-Optionen, copy, single).

// Klickziele eines Eintrags (actions in der Typ-Definition) mit ihrer Beschriftung im Formular,
// in dieser Reihenfolge; ohne actions gilt CONTENT_TYPES_DEFAULT_ACTIONS.
const CONTENT_TYPES_ACTIONS = ['none' => 'Nichts', 'link' => 'Externer Link', 'page' => 'Eigene Seite', 'modal' => 'Modal'];
const CONTENT_TYPES_DEFAULT_ACTIONS = ['none'];
// Felder, die die Klickziele in den Eintrag bringen (im data-JSON): Name → Beschriftung. Ein Feld
// des Typs mit einem dieser Namen macht die Definition ungültig, sobald das Ziel es braucht.
const CONTENT_TYPES_ACTION_FIELDS = ['action' => 'Beim Klick', 'url' => 'Link', 'slug' => 'Adresse'];
// Ungültige Typ-Definition: Gründe (Typname, dann Wert) für den Hinweis im Backend und das Log.
const CONTENT_TYPES_INVALID_TEXT = [
    'unreadable' => '„%s“: kein gültiger Content-Typ (braucht label und fields).',
    'actions' => '„%s“: actions muss eine Liste aus %s sein.',
    'action' => '„%s“: Unbekanntes Klickziel „%s“ in actions.',
    'duplicate' => '„%s“: Das Klickziel „%s“ steht mehrfach in actions.',
    'defaultAction' => '„%s“: defaultAction „%s“ steht nicht in actions.',
    'page' => '„%s“: Mit dem Ziel page braucht der Typ page mit path, titleField und descriptionField.',
    'pagePath' => '„%s“: page.path „%s“ ist kein gültiger Name (Buchstaben, Ziffern, - und _).',
    'pageTaken' => '„%s“: page.path „%s“ ist schon vergeben (Ordner oder Datei der Website, Adresse des Editors; eine Seite gleichen Namens geht).',
    'pageField' => '„%s“: page.%s muss ein Feld des Typs nennen (erlaubte Arten: %s).',
    'pageShared' => '„%s“: page.path „%s“ nutzt auch der Typ „%s“.',
    'pageSchema' => '„%s“: page.schema muss einer dieser Werte sein: %s.',
    'reserved' => '„%s“: Das Feld „%s“ ist für die Klickziele reserviert.',
    'dbColumn' => '„%s“: Das Feld „%s“ heißt wie eine Spalte der Datenbank (%s), die seinen Wert überdecken würde.',
    'orderBy' => '„%s“: orderBy braucht field (created oder ein Feld des Typs, erlaubte Arten: %s) und optional direction (asc oder desc).',
    'publishField' => '„%s“: publishField muss ein Feld des Typs nennen (erlaubte Arten: %s).',
    'expireField' => '„%s“: expireField muss ein Feld des Typs nennen (erlaubte Arten: %s).',
    'column' => '„%s“: column von „%s“ muss true oder false sein, und nur diese Arten können Spalte sein: %s.',
    'optionsFrom' => '„%s“: optionsFrom von „%s“ muss einen anderen Content-Typ mit Textfeld nennen.',
    'fallback' => '„%s“: fallback von „%s“ muss ein anderes Feld des Typs ohne eigenes fallback nennen (erlaubte Arten: %s), und nur %s-Felder haben fallback.',
    'size' => '„%s“: size von „%s“ muss eine ganze Zahl ab 1 sein (größte Breite in Pixeln, in der das Bild erscheint).',
    'copy' => '„%s“: copy von „%s“ muss true oder false sein und gilt nur für Felder der obersten Ebene, nicht in einer Liste.',
    'focusName' => '„%s“: Das Feld „%s“ ist für den Bildausschnitt von „%s“ reserviert.',
    'single' => '„%s“: single braucht label, einen nicht leeren Text (Name auf dem Knopf der Einzelansicht, z. B. „Galerie“).',
];
// Spalten von content_items (Schema-Dateien unter sql/): Beim Lesen überdecken sie gleichnamige Felder (content_types_expand_row),
// ein Feld darf deshalb nicht so heißen.
const CONTENT_TYPES_DB_COLUMNS = ['id', 'content_type', 'data', 'sort_order', 'created_at', 'updated_at'];
// Auswahlfeld mit optionsFrom: Die Werte sind die Titel der Einträge eines anderen Typs (Feld name oder title,
// sonst das erste Textfeld, wie entryTitle im Formular), in dessen Listenreihenfolge. Das Formular bietet
// dazu „+ <Feld> hinzufügen“ an: Es legt über diesen Endpoint einen Eintrag im anderen Typ an.
const CONTENT_TYPES_TITLE_FIELDS = ['name', 'title'];

// orderBy in der Typ-Definition: Einträge nach einem Feld statt von Hand (kein Ziehen auf der Website), erlaubte Arten
// und Richtungen. Ohne Wert zählt bei date/datetime das Anlegedatum, sonst stehen solche Einträge am Ende.
// field "created" sortiert nach dem Anlegedatum (created_at), sofern der Typ kein eigenes Feld so nennt.
const CONTENT_TYPES_ORDER_FIELD_TYPES = ['text', 'number', 'date', 'datetime'];
const CONTENT_TYPES_ORDER_CREATED = 'created';
const CONTENT_TYPES_ORDER_DIRECTIONS = ['asc', 'desc'];
// publishField: Auf der Website erscheint ein Eintrag erst ab diesem Datum (leer: sofort), expireField: nur bis zu
// diesem Datum (ein Tag bis zu seinem Ende, leer: immer); das Backend zeigt alle. Erlaubte Arten für beide.
const CONTENT_TYPES_PUBLISH_FIELD_TYPES = ['date', 'datetime'];
const CONTENT_TYPES_VISIBILITY_KEYS = ['publishField', 'expireField'];

// Spalten der Liste im Backend: Felder mit "column": true in diesen Arten. Ohne solche Felder das erste Bild und das
// Datum aus orderBy, publishField oder expireField (content_types_admin_columns).
const CONTENT_TYPES_COLUMN_FIELD_TYPES = ['text', 'textarea', 'number', 'date', 'datetime', 'select', 'boolean', 'image', 'url'];

// Art der eigenen Seite für Suchmaschinen (page.schema, schema.org): strukturierte Daten mit Titel, Beschreibung,
// Datum und Bild (content_types_page_json_ld). Ohne page.schema keine.
const CONTENT_TYPES_PAGE_SCHEMAS = ['Article', 'BlogPosting', 'NewsArticle'];
// Erlaubte Arten der Felder, die Titel und Beschreibung der eigenen Seite liefern (page).
const CONTENT_TYPES_PAGE_FIELD_TYPES = ['titleField' => ['text'], 'descriptionField' => ['text', 'textarea', 'richtext', 'blocks']];
// fallback eines Feldes (z. B. Kurzfassung): Arten mit fallback und Arten, aus denen der Ersatz kommt (lib/render.php).
const CONTENT_TYPES_FALLBACK_FIELD_TYPES = ['text', 'textarea'];
const CONTENT_TYPES_FALLBACK_SOURCE_TYPES = ['text', 'textarea', 'richtext', 'blocks'];

function content_types_name_valid(string $name): bool
{
    return (bool) preg_match('/^[a-z][a-z0-9_-]*$/', $name);
}

/**
 * Typ-Definition aus CONTENT_TYPES_FILE mit den Vorgaben für actions und defaultAction, noch ohne deren Prüfung
 * (content_types_definition_problem). Wirft, wenn es den Typ nicht gibt oder er kein Content-Typ ist (label, fields).
 */
function content_types_read(string $name): array
{
    if (!content_types_name_valid($name)) {
        throw new InvalidArgumentException(API_TEXT['invalidType']);
    }
    $data = content_types_file_data()['types'][$name] ?? null;
    if ($data === null) {
        throw new RuntimeException('Content-type not found: ' . $name);
    }
    if (!is_string($data['label'] ?? null) || trim($data['label']) === '') {
        throw new RuntimeException('Content-type missing label: ' . $name);
    }
    if (!is_array($data['fields'] ?? null) || empty($data['fields'])) {
        throw new RuntimeException('Content-type has no fields: ' . $name);
    }

    $data['actions'] ??= CONTENT_TYPES_DEFAULT_ACTIONS;
    $data['defaultAction'] ??= is_array($data['actions']) ? ($data['actions'][0] ?? null) : null;

    return $data;
}

/** Gültige Typ-Definition (content_types_read + content_types_definition_problem); wirft mit dem Grund. */
function content_types_load(string $name): array
{
    $data = content_types_read($name);
    $problem = content_types_definition_problem($data);
    if ($problem !== null) {
        throw new RuntimeException('Invalid content-type: ' . $problem);
    }

    return $data;
}

/**
 * Grund, warum die Klickziele einer Definition (aus content_types_read) ungültig sind, als Text aus
 * CONTENT_TYPES_INVALID_TEXT; null, wenn sie gültig ist.
 */
function content_types_definition_problem(array $def): ?string
{
    $name = (string) $def['name'];
    $show = static fn (mixed $value): string => is_string($value) ? $value : (string) json_encode($value, JSON_UNESCAPED_UNICODE);
    $actions = $def['actions'];
    if (!is_array($actions) || $actions === [] || array_values($actions) !== $actions) {
        return sprintf(CONTENT_TYPES_INVALID_TEXT['actions'], $name, implode(', ', array_keys(CONTENT_TYPES_ACTIONS)));
    }
    foreach ($actions as $action) {
        if (!is_string($action) || !isset(CONTENT_TYPES_ACTIONS[$action])) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['action'], $name, $show($action));
        }
    }
    foreach (array_count_values($actions) as $action => $count) {
        if ($count > 1) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['duplicate'], $name, $action);
        }
    }
    if (!in_array($def['defaultAction'], $actions, true)) {
        return sprintf(CONTENT_TYPES_INVALID_TEXT['defaultAction'], $name, $show($def['defaultAction']));
    }

    // Nur Felder, die es im Formular gibt (Namen wie bei jedem Schema): Ein titleField auf ein Feld mit
    // ungültigem Namen gäbe sonst jeder eigenen Seite einen leeren Titel.
    $fieldTypes = array_column(content_types_schema_columns($def), 'type', 'name');
    $fieldNames = array_keys($fieldTypes);
    if (in_array('page', $actions, true)) {
        $page = $def['page'] ?? null;
        if (!is_array($page) || !is_string($page['path'] ?? null) || !isset($page['titleField'], $page['descriptionField'])) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['page'], $name);
        }
        if (!is_safe_page_name($page['path'])) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['pagePath'], $name, $page['path']);
        }
        if (content_types_page_path_taken($page['path'])) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['pageTaken'], $name, $page['path']);
        }
        $other = array_search($page['path'], content_types_page_paths($name), true);
        if ($other !== false) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['pageShared'], $name, $page['path'], $other);
        }
        foreach (CONTENT_TYPES_PAGE_FIELD_TYPES as $key => $types) {
            if (!is_string($page[$key]) || !in_array($fieldTypes[$page[$key]] ?? null, $types, true)) {
                return sprintf(CONTENT_TYPES_INVALID_TEXT['pageField'], $name, $key, implode(', ', $types));
            }
        }
        if (isset($page['schema']) && !in_array($page['schema'], CONTENT_TYPES_PAGE_SCHEMAS, true)) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['pageSchema'], $name, implode(', ', CONTENT_TYPES_PAGE_SCHEMAS));
        }
    }

    foreach (content_types_action_field_names($actions) as $reserved) {
        if (in_array($reserved, $fieldNames, true)) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['reserved'], $name, $reserved);
        }
    }
    foreach (CONTENT_TYPES_DB_COLUMNS as $column) {
        if (in_array($column, $fieldNames, true)) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['dbColumn'], $name, $column, implode(', ', CONTENT_TYPES_DB_COLUMNS));
        }
    }
    // Bild-Optionen und copy am Feld, wie es in typen.json steht (plugin_schema_field lässt ungültige still weg), auch an
    // Unterfeldern von list (Name „liste.feld“).
    foreach ($def['fields'] as $field) {
        if (!is_array($field) || !in_array($field['name'] ?? null, $fieldNames, true)) {
            continue;
        }
        $checks = [[$field, $field['name'], true]];
        foreach (($field['type'] ?? null) === 'list' && is_array($field['fields'] ?? null) ? $field['fields'] : [] as $sub) {
            if (is_array($sub)) {
                $checks[] = [$sub, $field['name'] . '.' . (string) ($sub['name'] ?? ''), false];
            }
        }
        foreach ($checks as [$checked, $label, $top]) {
            $problem = [...le_image_option_problems($checked), ...le_copy_option_problems($checked, $top)][0] ?? null;
            if ($problem !== null) {
                return sprintf(CONTENT_TYPES_INVALID_TEXT[$problem], $name, $label);
            }
        }
    }
    // Den Namen <feld>_focus belegt der Fokuspunkt jedes Bildfelds, oben wie in einer Zeile von list („liste.feld“).
    $clash = le_image_focus_name_clash(content_types_schema_columns($def));
    if ($clash !== null) {
        return sprintf(CONTENT_TYPES_INVALID_TEXT['focusName'], $name, ...$clash);
    }

    if (array_key_exists('orderBy', $def)) {
        $order = $def['orderBy'];
        $orderField = is_array($order) ? ($order['field'] ?? null) : null;
        $orderType = $fieldTypes[$orderField] ?? ($orderField === CONTENT_TYPES_ORDER_CREATED ? 'datetime' : null);
        if (!is_string($orderField) || !in_array($orderType, CONTENT_TYPES_ORDER_FIELD_TYPES, true)
            || !in_array($order['direction'] ?? 'asc', CONTENT_TYPES_ORDER_DIRECTIONS, true)) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['orderBy'], $name, implode(', ', CONTENT_TYPES_ORDER_FIELD_TYPES));
        }
    }
    foreach (CONTENT_TYPES_VISIBILITY_KEYS as $key) {
        if (array_key_exists($key, $def)
            && (!is_string($def[$key]) || !in_array($fieldTypes[$def[$key]] ?? null, CONTENT_TYPES_PUBLISH_FIELD_TYPES, true))) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT[$key], $name, implode(', ', CONTENT_TYPES_PUBLISH_FIELD_TYPES));
        }
    }
    // single.label: Name auf den Knöpfen der Ansicht single („Galerie bearbeiten“, content_types_single_label).
    if (array_key_exists('single', $def) && (!is_array($def['single']) || !is_string($def['single']['label'] ?? null) || trim($def['single']['label']) === '')) {
        return sprintf(CONTENT_TYPES_INVALID_TEXT['single'], $name);
    }
    $fallbacks = array_column(content_types_schema_columns($def), 'fallback', 'name');
    foreach (content_types_schema_columns($def) as $field) {
        if (array_key_exists('column', $field) && (!is_bool($field['column'])
            || ($field['column'] && !in_array($field['type'], CONTENT_TYPES_COLUMN_FIELD_TYPES, true)))) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['column'], $name, $field['name'], implode(', ', CONTENT_TYPES_COLUMN_FIELD_TYPES));
        }
        if ($field['type'] === 'select' && array_key_exists('optionsFrom', $field) && !content_types_options_source_valid($name, $field['optionsFrom'])) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['optionsFrom'], $name, $field['name']);
        }
        $from = $field['fallback'] ?? null;
        if (array_key_exists('fallback', $field) && (!in_array($field['type'], CONTENT_TYPES_FALLBACK_FIELD_TYPES, true)
            || !is_string($from) || $from === $field['name'] || isset($fallbacks[$from])
            || !in_array($fieldTypes[$from] ?? null, CONTENT_TYPES_FALLBACK_SOURCE_TYPES, true))) {
            return sprintf(CONTENT_TYPES_INVALID_TEXT['fallback'], $name, $field['name'], implode(', ', CONTENT_TYPES_FALLBACK_SOURCE_TYPES), implode('/', CONTENT_TYPES_FALLBACK_FIELD_TYPES));
        }
    }

    return null;
}

/** Ob $from (optionsFrom eines Feldes des Typs $name) ein anderer lesbarer Typ mit Titelfeld ist (content_types_title_field). */
function content_types_options_source_valid(string $name, mixed $from): bool
{
    if (!is_string($from) || $from === $name || !in_array($from, content_types_list_names(), true)) {
        return false;
    }
    try {
        return content_types_title_field(content_types_read($from)) !== null;
    } catch (Throwable $e) {
        return false;
    }
}

/** Feld, das einen Eintrag benennt: ein Textfeld name oder title, sonst das erste Textfeld; null ohne. */
function content_types_title_field(array $def): ?string
{
    $text = array_values(array_filter(content_types_schema_columns($def), static fn (array $field): bool => $field['type'] === 'text'));
    foreach ($text as $field) {
        if (in_array($field['name'], CONTENT_TYPES_TITLE_FIELDS, true)) {
            return $field['name'];
        }
    }

    return $text[0]['name'] ?? null;
}

/**
 * Ob page.path $path schon vergeben ist (le_site_path_taken). Eine Seite gleichen Namens ist erlaubt: /aktuelles
 * bleibt die Seite (etwa mit der Liste), /aktuelles/<slug> sind die Einträge, weil der Router Plugins erst ohne Datei
 * fragt. Ein Ordner oder eine Datei ohne Endung gleichen Namens und reservierte Adressen bleiben vergeben.
 */
function content_types_page_path_taken(string $path): bool
{
    if (!le_site_path_taken($path)) {
        return false;
    }
    $name = strtolower($path);
    if (in_array($name, array_map('strtolower', le_site_reserved_names()), true)) {
        return true;
    }
    $page = false;
    foreach (scandir(LE_SITE_ROOT) ?: [] as $entry) {
        if (strtolower($entry) === $name) {
            return true;
        }
        $page = $page || (le_site_is_document($entry) && strtolower(pathinfo($entry, PATHINFO_FILENAME)) === $name);
    }

    return !$page;
}

/** page.path der übrigen lesbaren Typen mit dem Ziel page (Typname → path), ohne $except. */
function content_types_page_paths(string $except): array
{
    $paths = [];
    foreach (content_types_list_names() as $name) {
        if ($name === $except) {
            continue;
        }
        try {
            $def = content_types_read($name);
        } catch (Throwable $e) {
            continue;
        }
        if (is_array($def['actions']) && in_array('page', $def['actions'], true) && is_string($def['page']['path'] ?? null)) {
            $paths[$name] = $def['page']['path'];
        }
    }

    return $paths;
}

/** Felder, die die Klickziele $actions brauchen: action ab zwei Zielen, url bei link, slug bei page. */
function content_types_action_field_names(array $actions): array
{
    $names = [];
    if (count($actions) > 1) {
        $names[] = 'action';
    }
    if (in_array('link', $actions, true)) {
        $names[] = 'url';
    }
    if (in_array('page', $actions, true)) {
        $names[] = 'slug';
    }

    return $names;
}

/**
 * Klickziel eines Eintrags: sein action, wenn der Typ es erlaubt, sonst defaultAction (Einträge ohne
 * Angabe, ältere oder importierte, und Ziele, die der Typ nicht mehr erlaubt). $def aus content_types_load.
 */
function content_types_item_action(array $def, array $item): string
{
    $action = $item['action'] ?? null;

    return content_types_action_allowed($def, $action) ? $action : $def['defaultAction'];
}

/** Ob $action ein Klickziel ist, das der Typ ($def aus content_types_load) erlaubt. */
function content_types_action_allowed(array $def, mixed $action): bool
{
    return is_string($action) && in_array($action, $def['actions'], true);
}

/** Gültiger Typ mit dem Ziel page, dessen page.path $path ist; null ohne. Ungültige Typen zählen nicht. */
function content_types_page_type(string $path): ?array
{
    foreach (content_types_list_names() as $name) {
        try {
            $def = content_types_load($name);
        } catch (Throwable $e) {
            continue;
        }
        if (in_array('page', $def['actions'], true) && $def['page']['path'] === $path) {
            return $def;
        }
    }

    return null;
}
