<?php
declare(strict_types=1);

// Content-Typen: Felder fürs Formular und fürs Speichern, Auswahl aus einem anderen Typ, Spalten im Backend, geprüfte Werte.

// Endpoint, über den das Formular bei optionsFrom „+ <Feld> hinzufügen“ einen Eintrag im anderen Typ anlegt.
const CONTENT_TYPES_SAVE_URL = PLUGINS_URL . 'content-types/api/save.php';

/**
 * Auswahlfeld mit optionsFrom fürs Formular und Speichern: options sind die Titel der Einträge des anderen Typs
 * (ohne leere und doppelte), optionsCreate sagt dem Formular, wie es dort einen neuen anlegt. Ein Wert $current,
 * den es dort nicht mehr gibt (gelöscht; Umbenennen zieht content_types_rename_option mit), bleibt als Option, damit der Eintrag ihn behält.
 */
function content_types_options_from(array $field, mixed $current): array
{
    $source = content_types_load((string) $field['optionsFrom']);
    $title = (string) content_types_title_field($source);
    $options = [];
    foreach (content_types_fetch_list($source['name'], null, null, $source) as $row) {
        $value = $row[$title] ?? null;
        if (is_string($value) && $value !== '' && !in_array($value, $options, true)) {
            $options[] = $value;
        }
    }
    if (is_string($current) && $current !== '' && !in_array($current, $options, true)) {
        $options[] = $current;
    }
    unset($field['optionLabels']);

    return ['options' => $options, 'optionsCreate' => ['url' => CONTENT_TYPES_SAVE_URL, 'type' => $source['name'], 'field' => $title]] + $field;
}

/** Felder des Typs ($def aus content_types_read), ohne die Klickziel-Felder; gültig wie bei jedem Schema (plugin_schema_columns). */
function content_types_schema_columns(array $def): array
{
    return plugin_schema_columns(['schema' => ['fields' => $def['fields']]]);
}

/**
 * Ob $field ein Bildfeld der obersten Ebene des Typs $def ist (data-le-field, Stellen eines Bildes). Die Bildfelder je Typ
 * (name) einmal je Anfrage, nicht je Bild; ein Typ ändert sich während einer Anfrage nicht.
 */
function content_types_image_field(array $def, string $field): bool
{
    static $images = [];
    $images[(string) $def['name']] ??= array_keys(array_filter(array_column(content_types_schema_columns($def + ['fields' => []]), 'type', 'name'), static fn (mixed $type): bool => $type === 'image'));

    return in_array($field, $images[(string) $def['name']], true);
}

/**
 * Felder des Formulars (Backend und Website) und fürs Speichern: vor denen des Typs die Klickziel-Felder
 * (content_types_action_field_names). „Beim Klick“ bietet nur die erlaubten Ziele, vorausgewählt
 * defaultAction; Link und Adresse erscheinen nur beim passenden Ziel (showWhen), bei genau einem
 * Ziel immer. Auswahlfelder mit optionsFrom bekommen ihre Werte (content_types_options_from; $stored ist
 * der gespeicherte Eintrag beim Bearbeiten), Bildfelder usage für imageUsage (le_image_usage_columns). Die Ausgabe auf
 * der Website nutzt content_types_schema_columns.
 */
function content_types_form_columns(array $def, ?array $stored = null): array
{
    $actions = array_values(array_intersect(array_keys(CONTENT_TYPES_ACTIONS), $def['actions']));
    $choice = count($actions) > 1;
    $when = static fn (string $action): array => $choice ? ['showWhen' => ['field' => 'action', 'value' => $action]] : [];
    $fields = [
        'action' => [
            'type' => 'select',
            'required' => true,
            'options' => $actions,
            'optionLabels' => array_intersect_key(CONTENT_TYPES_ACTIONS, array_flip($actions)),
            'default' => $def['defaultAction'],
        ],
        'url' => ['type' => 'url'] + ($choice ? $when('link') : ['required' => true]),
        // prefix: Anfang der Adresse, den das Formular vor den Slug schreibt (/aktuelles/).
        'slug' => ['type' => 'slug', 'from' => $def['page']['titleField'] ?? null, 'prefix' => isset($def['page']['path']) ? '/' . $def['page']['path'] . '/' : ''] + $when('page'),
    ];

    $columns = [];
    foreach (content_types_action_field_names($def['actions']) as $name) {
        $columns[] = ['name' => $name, 'label' => CONTENT_TYPES_ACTION_FIELDS[$name]] + $fields[$name];
    }

    foreach (le_image_usage_columns(content_types_schema_columns($def), 'content-types', (string) $def['name']) as $field) {
        $columns[] = $field['type'] === 'select' && isset($field['optionsFrom'])
            ? content_types_options_from($field, $stored[$field['name']] ?? null)
            : $field;
    }

    return $columns;
}

/**
 * Klickziel-Werte nach plugin_schema_values: Ein Link, der nur beim Ziel link erscheint (showWhen), ist
 * dann Pflicht (Meldung wie ein Pflichtfeld; bei genau einem Ziel ist er schon im Schema required);
 * mit dem Ziel page bekommt jeder Eintrag eine Adresse (slug, sonst aus titleField), eindeutig im Typ.
 */
function content_types_action_values(array $def, array $columns, array $values, ?int $id): array
{
    $byName = array_column($columns, null, 'name');
    $url = $byName['url'] ?? null;
    if (isset($url['showWhen']) && content_types_item_action($def, $values) === 'link' && plugin_schema_blank($url, $values['url'] ?? '')) {
        throw plugin_schema_required_error($url);
    }
    if (isset($byName['slug'])) {
        $slug = $values['slug'] ?? plugin_schema_normalize_value($byName['slug'], '', $values);
        $used = content_types_slugs_in_use((string) $def['name'], $id);
        $values['slug'] = plugin_unique_slug_with($slug, static fn (string $candidate): bool => in_array($candidate, $used, true));
    }

    return $values;
}

/**
 * Felder, die die Liste im Backend als Spalten zeigt (Namen, in der Reihenfolge des Typs): die mit "column": true,
 * ohne solche das erste Bild und das erste Datum aus orderBy, publishField, expireField.
 */
function content_types_admin_columns(array $def): array
{
    $fields = content_types_schema_columns($def);
    $chosen = array_column(array_filter($fields, static fn (array $field): bool => ($field['column'] ?? false) === true), 'name');
    if ($chosen !== []) {
        return $chosen;
    }
    $types = array_column($fields, 'type', 'name');
    $image = array_search('image', $types, true);
    $date = null;
    foreach ([$def['orderBy']['field'] ?? null, $def['publishField'] ?? null, $def['expireField'] ?? null] as $name) {
        if (is_string($name) && in_array($types[$name] ?? null, CONTENT_TYPES_PUBLISH_FIELD_TYPES, true)) {
            $date = $name;
            break;
        }
    }
    return array_values(array_filter(array_keys($types), static fn (string $name): bool => $name === $image || $name === $date));
}

/**
 * Geprüfte Werte eines Eintrags ($def aus content_types_load) wie beim Speichern: Klickziel (ohne erlaubtes
 * gilt defaultAction), Felder nach Schema, Link und Adresse; $stored ist beim Bearbeiten der gespeicherte Eintrag
 * (content_types_fetch_by_id), sonst null. $indexRows wie bei plugin_schema_values (Vorschau). Wirft
 * InvalidArgumentException (PluginFieldException mit Feld) bei ungültigen Werten.
 */
function content_types_values(array $def, array $rawValues, ?array $stored = null, ?string $indexRows = null): array
{
    if (count($def['actions']) > 1) {
        // Ohne erlaubtes Ziel (ältere Einträge, importierte ohne action) gilt defaultAction.
        $rawValues['action'] = content_types_item_action($def, $rawValues);
    }

    $columns = content_types_form_columns($def, $stored);
    // Versteckte Felder (showWhen passt nicht zum Ziel: Link, Adresse) zählen nicht und blockieren nie:
    // Es bleibt der gespeicherte Wert, ohne ihn entfällt das Feld (die Adresse kommt dann aus titleField).
    foreach ($columns as $column) {
        $when = $column['showWhen'] ?? null;
        if ($when !== null && ($rawValues[$when['field']] ?? null) !== $when['value']) {
            unset($rawValues[$column['name']]);
            if (isset($stored[$column['name']])) {
                $rawValues[$column['name']] = $stored[$column['name']];
            }
        }
    }

    $values = plugin_schema_values($columns, $rawValues, $stored ?? [], $indexRows);

    return content_types_action_values($def, $columns, $values, $stored !== null ? (int) $stored['id'] : null);
}
