<?php
declare(strict_types=1);

// Hooks der Content-Typen (docs/knowledgebase/plugins/ref-hooks.md): Seitenleiste, eigene Seiten, Sitemap, Assets und canonical, Bilder
// und ihre Stellen, Einspielen von Plugin-Daten.

// Eintrag in der Seitenleiste des Backends, wenn es ungültige Typen gibt (Gründe in seiner Ansicht).
const CONTENT_TYPES_INVALID_LABEL = 'Ungültige Content-Typen';

// Modal-Skript und sein CSS (nur Position, Scroll-Sperre, Fokus), eingebunden auf Seiten mit einer Liste
// eines Typs mit modal (content_types_filter_site_html).
const CONTENT_TYPES_MODAL_ASSETS = [
    'style' => PLUGINS_URL . 'content-types/assets/modal.css',
    'script' => PLUGINS_URL . 'content-types/assets/modal.js',
];
// CSS der Filterleiste und des Knopfes „Mehr laden“ (ganze Zeile im Grid der Website) und das Skript, das per Knopf
// nachlädt; nur auf Seiten mit Leiste bzw. Knopf (content_types_filter_site_html).
const CONTENT_TYPES_LIST_ASSETS = [
    'style' => PLUGINS_URL . 'content-types/assets/list.css',
    'script' => PLUGINS_URL . 'content-types/assets/list.js',
];

// Shortcode der Liste (plugin.json shortcodes, data-view), an dem der Kern Seiten mit einer Liste eines Typs erkennt
// (content_types_image_usage).
const CONTENT_TYPES_LIST_VIEW = 'list';

// Einspielen von Plugin-Daten (backend/database/dataSync.php, Hook entry_problem): Gründe, warum ein neuer oder geänderter Eintrag
// so nicht online gehen kann (%s: Typname bzw. Adresse).
const CONTENT_TYPES_DATA_TEXT = [
    'unknownType' => 'Content-Typ „%s“ gibt es online nicht, erst ausrollen (deploy).',
    'slugTaken' => 'Adresse „%s“ gibt es online schon in diesem Typ, lokal ändern und den Diff neu bilden.',
];

/**
 * Seitenleiste des Backends: je gültigem Typ ein Eintrag; gibt es ungültige oder unlesbare, steht
 * vorn ein Eintrag CONTENT_TYPES_INVALID_LABEL mit den Gründen (problems); ungültige und unlesbare Definitionen gehen auch ins Log.
 */
function content_types_admin_sidebar_entries(): array
{
    $entries = [];
    $problems = [...content_types_file_data()['problems'], ...content_types_orphaned_problems()];
    foreach (content_types_list_names() as $name) {
        try {
            $def = content_types_read($name);
        } catch (Throwable $e) {
            error_log('content-types: ' . $e->getMessage());
            $problems[] = sprintf(CONTENT_TYPES_INVALID_TEXT['unreadable'], $name);
            continue;
        }
        $problem = content_types_definition_problem($def);
        if ($problem !== null) {
            error_log('content-types: ' . $problem);
            $problems[] = $problem;
            continue;
        }
        $entries[] = [
            'name' => 'content-types',
            'route' => 'content-types/' . $name,
            'label' => (string) $def['label'],
            'hasAdminModule' => true,
            'hasSchema' => true,
            'type' => $name,
        ];
    }
    if ($problems !== []) {
        array_unshift($entries, [
            'name' => 'content-types',
            'route' => 'content-types',
            'label' => CONTENT_TYPES_INVALID_LABEL,
            'hasAdminModule' => true,
            'problems' => $problems,
        ]);
    }

    return $entries;
}

/**
 * Hook site_page: eigene Seite eines Eintrags unter /<page.path>/<slug>. Adressen unter page.path eines
 * gültigen Typs gehören dem Plugin; ohne passenden Eintrag mit Ziel page → PLUGIN_SITE_PAGE_NOT_FOUND.
 */
function content_types_site_page(string $path): ?array
{
    if (!preg_match('#^/([^/]+)(?:/([^/]*))?/?$#', $path, $m)) {
        return null;
    }
    $def = content_types_page_type($m[1]);
    if ($def === null) {
        return null;
    }
    $slug = $m[2] ?? '';
    $row = preg_match(PLUGIN_SLUG_PATTERN, $slug) ? content_types_fetch_by_slug($def['name'], $slug) : null;
    // Noch nicht fällig (publishField) oder abgelaufen (expireField): wie ein fehlender Eintrag.
    if ($row !== null && !content_types_published($def, $row)) {
        $row = null;
    }

    return ($row === null ? null : content_types_page($def, $row)) ?? PLUGIN_SITE_PAGE_NOT_FOUND;
}

/**
 * Hook sitemap_urls: eigene Seiten aller veröffentlichten Einträge mit Ziel page (gültige Typen), zuletzt geändert
 * am updated_at des Eintrags.
 */
function content_types_sitemap_urls(): array
{
    $urls = [];
    foreach (content_types_list_names() as $name) {
        try {
            $def = content_types_load($name);
        } catch (Throwable $e) {
            continue;
        }
        foreach (content_types_page_items($def) as $item) {
            $urls[] = ['path' => content_types_item_target($item)['href'], 'lastmod' => (string) ($item['updated_at'] ?? '')];
        }
    }

    return $urls;
}

/**
 * Hook image_usage: Wo ein Bildfeld der obersten Ebene ($field) des Typs $type auf der Website steht. Listen des Typs
 * findet der Kern über den Shortcode (CONTENT_TYPES_LIST_VIEW mit data-type), dazu die Adresse der eigenen Seite des
 * Eintrags $id, wenn er eine hat, sonst des ersten veröffentlichten Eintrags mit Ziel page (content_types_template_item).
 * null für einen unbekannten oder ungültigen Typ und ein Feld, das dort kein Bildfeld der obersten Ebene ist.
 */
function content_types_image_usage(string $type, string $field, ?int $id): ?array
{
    try {
        $def = content_types_name_valid($type) ? content_types_load($type) : null;
    } catch (Throwable $e) {
        $def = null;
    }
    if ($def === null || !content_types_image_field($def, $field)) {
        return null;
    }
    // Die Seite des Eintrags $id, sonst die des ersten mit eigener Seite (ein neuer Eintrag misst an einem anderen).
    $page = null;
    foreach (content_types_page_items($def) as $item) {
        if ($id !== null && (int) ($item['id'] ?? 0) === $id) {
            $page = content_types_item_target($item)['href'];
            break;
        }
        $page ??= content_types_item_target($item)['href'];
        if ($id === null) {
            break;
        }
    }

    return ['shortcode' => ['view' => CONTENT_TYPES_LIST_VIEW, 'type' => $type], 'page' => $page];
}

/**
 * Hook filter_site_html: Seiten mit einer Liste eines Typs mit modal (CONTENT_TYPES_MODAL_LIST_ATTR, vom
 * Renderer gesetzt) bekommen einmal Modal-Skript und -CSS vor </body> (le_plugin_insert_style, le_plugin_insert_script); Seiten mit
 * Filterleiste oder „Mehr laden“ das CSS der Liste in den Kopf, mit „Mehr laden“ auch ihr Skript (content_types_list_assets).
 * Liest eine Liste die Adresse und hat die Anfrage Parameter, zeigt canonical ohne sie auf die Seite, sofern die
 * Seite keinen eigenen hat. Sonst unverändert.
 */
function content_types_filter_site_html(string $html): string
{
    $html = content_types_list_assets(content_types_list_canonical($html));
    if (!str_contains($html, ' ' . CONTENT_TYPES_MODAL_LIST_ATTR)) {
        return $html;
    }

    return le_plugin_insert_script(le_plugin_insert_style($html, CONTENT_TYPES_MODAL_ASSETS['style'], 'body'), CONTENT_TYPES_MODAL_ASSETS['script']);
}

/**
 * CSS der Liste (CONTENT_TYPES_LIST_ASSETS) vor </head> bei Filterleiste oder „Mehr laden“, das Skript vor </body> nur
 * mit „Mehr laden“; je einmal (le_plugin_insert_style, le_plugin_insert_script).
 */
function content_types_list_assets(string $html): string
{
    $more = str_contains($html, ' ' . LE_MORE_ATTR);
    if ($more || str_contains($html, '<nav class="' . CONTENT_TYPES_FILTER_CLASS . '"')) {
        $html = le_plugin_insert_style($html, CONTENT_TYPES_LIST_ASSETS['style']);
    }

    return $more ? le_plugin_insert_script($html, CONTENT_TYPES_LIST_ASSETS['script']) : $html;
}

/** canonical ohne Parameter, wenn eine Liste die Adresse liest (content_types_list_ids), die Anfrage Parameter hat und die Seite keinen canonical. */
function content_types_list_canonical(string $html): string
{
    if (content_types_list_ids() === [] || $_GET === []) {
        return $html;
    }
    $doc = markup_parse($html);
    $head = markup_find_tag($doc, 'head');
    if ($head === null || isset(le_site_head_tags($doc, $head)['link:canonical'])) {
        return $html;
    }

    return le_site_html_set_head($html, ['canonical' => (le_site_base_url() ?? '') . content_types_request_path()]);
}

/**
 * Hook image_values (backend/plugins/entries.php): Bildwerte einer Zeile aus content_items laut Typ-Definition.
 * Für die Felder reicht content_types_read: Auch ein bei den Klickzielen ungültiger Typ verliert beim
 * Löschen eines Eintrags seine Bilder.
 */
function content_types_image_values(array $row): array
{
    return plugin_schema_image_values(content_types_schema_columns(content_types_read((string) $row['content_type'])), content_types_expand_row($row));
}

/** Hook upload_in_use (backend/media/usage.php): verweist ein Eintrag irgendeines Typs auf die Upload-Datei? */
function content_types_upload_in_use(string $file): bool
{
    $stmt = db()->prepare('SELECT 1 FROM content_items WHERE INSTR(data, ?) > 0 LIMIT 1');
    $stmt->execute([$file]);

    return $stmt->fetchColumn() !== false;
}

/** Hook entry_label (backend/plugins/hooks.php): Titel eines Eintrags (content_types_title_field), sonst seine Adresse; '' ohne. */
function content_types_entry_label(string $table, array $row): string
{
    if ($table !== 'content_items') {
        return '';
    }
    $item = content_types_expand_row($row);
    try {
        $title = content_types_title_field(content_types_read((string) $row['content_type']));
    } catch (Throwable $e) {
        $title = null; // Typ unbekannt: dann die Adresse
    }
    // Ohne Typ-Definition die üblichen Titelfelder.
    foreach ([$title, ...CONTENT_TYPES_TITLE_FIELDS, 'slug'] as $field) {
        if ($field !== null && is_string($item[$field] ?? null) && $item[$field] !== '') {
            return $item[$field];
        }
    }

    return '';
}

/**
 * Hook entry_problem (backend/plugins/plugins.php): Ein eingespielter Eintrag braucht einen Typ, den es online gibt, und eine
 * Adresse (slug), die kein anderer Eintrag des Typs hat. Sieht den neuen Stand, auch die übrigen eingespielten Einträge.
 */
function content_types_entry_problem(string $table, array $row): ?string
{
    if ($table !== 'content_items') {
        return null;
    }
    $type = (string) $row['content_type'];
    if (!in_array($type, content_types_list_names(), true)) {
        return sprintf(CONTENT_TYPES_DATA_TEXT['unknownType'], $type);
    }
    $slug = content_types_expand_row($row)['slug'] ?? null;
    if (is_string($slug) && $slug !== '' && in_array($slug, content_types_slugs_in_use($type, (int) $row['id']), true)) {
        return sprintf(CONTENT_TYPES_DATA_TEXT['slugTaken'], $slug);
    }

    return null;
}

/** Hook action_entry_updated (backend/plugins/hooks.php): Umbenannter Eintrag → Auswahlwerte anderer Typen ziehen nach (content_types_rename_option). */
function content_types_action_entry_updated(string $table, array $before, array $after): void
{
    $type = (string) ($after['content_type'] ?? '');
    // Unbekannten Typ meldet content_types_entry_problem.
    if ($table !== 'content_items' || $before['content_type'] !== $type || !in_array($type, content_types_list_names(), true)) {
        return;
    }
    $title = content_types_title_field(content_types_read($type));
    if ($title !== null) {
        content_types_rename_option($type, (int) $after['id'], content_types_expand_row($before)[$title] ?? null, content_types_expand_row($after)[$title] ?? null);
    }
}
