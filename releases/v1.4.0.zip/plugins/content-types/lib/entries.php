<?php
declare(strict_types=1);

// Content-Typen: Einträge in der Datenbank lesen, speichern, sortieren, löschen; Zeitfenster auf der Website.

// Reihenfolge der Einträge eines Typs; vor dem ersten Sortieren haben alle sort_order 0. Neue Einträge kommen
// oben dazu (MIN-1), importierte ans Ende (MAX+1), Kopien direkt hinter ihr Original (content_types_insert_after).
const CONTENT_TYPES_ORDER = 'sort_order ASC, id DESC';

// Stand eines Eintrags auf der Website (content_types_visibility), fürs Backend: noch nicht fällig bzw. abgelaufen.
const CONTENT_TYPES_SCHEDULED = 'scheduled';
const CONTENT_TYPES_EXPIRED = 'expired';

/** Anzahl der Einträge eines Typs in der Datenbank. */
function content_types_entry_count(string $name): int
{
    $stmt = db()->prepare('SELECT COUNT(*) FROM content_items WHERE content_type = ?');
    $stmt->execute([$name]);

    return (int) $stmt->fetchColumn();
}

/** Adressen (slug) der übrigen Einträge eines Typs; die Einträge stehen als JSON in data, daher in PHP gelesen. */
function content_types_slugs_in_use(string $type, ?int $id): array
{
    $stmt = db()->prepare('SELECT id, data FROM content_items WHERE content_type = ? AND id <> ?');
    $stmt->execute([$type, $id ?? 0]);
    $slugs = [];
    foreach ($stmt->fetchAll() as $row) {
        $slug = content_types_expand_row($row)['slug'] ?? null;
        if (is_string($slug)) {
            $slugs[] = $slug;
        }
    }

    return $slugs;
}

/**
 * Einträge eines Typs in Listenreihenfolge, höchstens $limit (1 bis CONTENT_TYPES_LIST_MAX; null: alle, z. B.
 * fürs Backend, das jeden Eintrag zeigt, auch nach mehreren Importen), die ersten $offset übersprungen (seitenweise).
 * $filter [feld, wert]
 * (content_types_list_filter) behält nur Einträge, deren gespeicherter Wert gleich ist (content_types_row_matches);
 * verglichen wird in PHP, weil die Werte als JSON in data stehen (JSON-SQL unterscheidet sich zwischen SQLite und MySQL). Dafür
 * wird der Typ ohne LIMIT gelesen, bis $offset + $limit Treffer da sind, dann geschnitten; ohne $filter, orderBy und
 * Zeitfenster liest SQL nur den Ausschnitt. $def (content_types_load) mit orderBy sortiert
 * nach dem Feld (dafür alle Einträge gelesen), $public lässt mit publishField/expireField die noch nicht fälligen
 * und abgelaufenen weg.
 */
function content_types_fetch_list(string $type, ?int $limit = 100, ?array $filter = null, ?array $def = null, bool $public = false, int $offset = 0): array
{
    if (!content_types_name_valid($type)) {
        return [];
    }
    $limit = $limit === null ? null : max(1, min(CONTENT_TYPES_LIST_MAX, $limit));
    $offset = max(0, $offset);
    $ordered = isset($def['orderBy']);
    $hidden = $public && (isset($def['publishField']) || isset($def['expireField']));
    $sql = $filter === null && !$ordered && !$hidden && $limit !== null;
    $stmt = db()->prepare(
        "SELECT id, data, sort_order, created_at, updated_at
         FROM content_items
         WHERE content_type = ?
         ORDER BY " . CONTENT_TYPES_ORDER .
        ($sql ? " LIMIT {$limit}" . ($offset > 0 ? " OFFSET {$offset}" : '') : '')
    );
    $stmt->execute([$type]);
    // Ohne SQL-Ausschnitt: die übersprungenen Einträge mitlesen, am Ende abschneiden.
    $skip = $sql ? 0 : $offset;
    $rows = [];
    $now = db_now();
    while (($ordered || $limit === null || count($rows) < $skip + $limit) && ($row = $stmt->fetch()) !== false) {
        $row = content_types_expand_row($row);
        if ($filter !== null && !content_types_row_matches($row, $filter)) {
            continue;
        }
        if ($hidden && !content_types_published($def, $row, $now)) {
            continue;
        }
        $rows[] = $row;
    }
    $stmt->closeCursor();
    if ($ordered) {
        $rows = content_types_sort_rows($def, $rows);
    }

    return array_slice($rows, $skip, $limit);
}

/** Ob ein Eintrag auf der Website erscheint (content_types_visibility ohne Einschränkung). */
function content_types_published(array $def, array $row, ?string $now = null): bool
{
    return content_types_visibility($def, $row, $now) === null;
}

/**
 * Warum ein Eintrag auf der Website fehlt: CONTENT_TYPES_SCHEDULED, solange das Datum in publishField noch nicht
 * erreicht ist, CONTENT_TYPES_EXPIRED, wenn das in expireField vorbei ist, sonst null (leer zählt nie). $now wie
 * db_now(); ein Tag „2026-11-02“ ist ab Mitternacht fällig, weil er als Text davor sortiert, und bleibt bis zu
 * seinem Ende, weil nur der Tag von $now verglichen wird.
 */
function content_types_visibility(array $def, array $row, ?string $now = null): ?string
{
    $now ??= db_now();
    $from = isset($def['publishField']) ? ($row[$def['publishField']] ?? null) : null;
    $until = isset($def['expireField']) ? ($row[$def['expireField']] ?? null) : null;
    if (is_string($from) && $from !== '' && $from > $now) {
        return CONTENT_TYPES_SCHEDULED;
    }
    if (is_string($until) && $until !== '' && $until < substr($now, 0, strlen($until))) {
        return CONTENT_TYPES_EXPIRED;
    }
    return null;
}

/**
 * Einträge nach orderBy ($def aus content_types_load): Zahlen als Zahl, sonst als Text; ohne Wert gilt bei
 * date/datetime das Anlegedatum, sonst steht der Eintrag am Ende. field "created" ohne eigenes Feld: das
 * Anlegedatum. Gleiche Werte behalten die Listenreihenfolge.
 */
function content_types_sort_rows(array $def, array $rows): array
{
    $field = (string) $def['orderBy']['field'];
    $types = array_column(content_types_schema_columns($def), 'type', 'name');
    $created = $field === CONTENT_TYPES_ORDER_CREATED && !isset($types[$field]);
    $type = $created ? 'datetime' : ($types[$field] ?? 'text');
    $desc = ($def['orderBy']['direction'] ?? 'asc') === 'desc';
    $key = static function (array $row) use ($field, $type, $created): mixed {
        $value = $created ? null : ($row[$field] ?? null);
        if ($value === null || $value === '') {
            return in_array($type, ['date', 'datetime'], true) ? (string) $row['created_at'] : null;
        }
        return $type === 'number' ? (float) $value : (string) $value;
    };
    $keyed = array_map(static fn (array $row, int $index): array => [$key($row), $index, $row], $rows, array_keys($rows));
    usort($keyed, static function (array $a, array $b) use ($desc): int {
        if ($a[0] === null || $b[0] === null) {
            return ($a[0] === null) <=> ($b[0] === null) ?: $a[1] <=> $b[1];
        }
        $cmp = is_string($a[0]) ? strcmp($a[0], $b[0]) : $a[0] <=> $b[0];
        return ($desc ? -$cmp : $cmp) ?: $a[1] <=> $b[1];
    });

    return array_column($keyed, 2);
}

function content_types_fetch_by_id(string $type, int $id): ?array
{
    if (!content_types_name_valid($type) || $id <= 0) {
        return null;
    }
    $stmt = db()->prepare(
        'SELECT id, data, sort_order, created_at, updated_at
         FROM content_items WHERE content_type = ? AND id = ? LIMIT 1'
    );
    $stmt->execute([$type, $id]);
    $row = $stmt->fetch();

    return $row ? content_types_expand_row($row) : null;
}

/** Stand eines Eintrags für die Konfliktprüfung (plugin_entry_version); die Reihenfolge zählt nicht mit. */
function content_types_entry_version(array $row): string
{
    return plugin_entry_version($row, ['sort_order']);
}

/** Eintrag eines Typs mit der Adresse (slug) $slug; data ist JSON, daher in PHP verglichen. */
function content_types_fetch_by_slug(string $type, string $slug): ?array
{
    if (!content_types_name_valid($type)) {
        return null;
    }
    $stmt = db()->prepare(
        'SELECT id, data, sort_order, created_at, updated_at
         FROM content_items WHERE content_type = ? ORDER BY ' . CONTENT_TYPES_ORDER
    );
    $stmt->execute([$type]);
    foreach ($stmt->fetchAll() as $row) {
        $item = content_types_expand_row($row);
        if (($item['slug'] ?? null) === $slug) {
            return $item;
        }
    }

    return null;
}

function content_types_expand_row(array $row): array
{
    $data = json_decode((string) ($row['data'] ?? '{}'), true);
    if (!is_array($data)) {
        $data = [];
    }
    unset($row['data']);
    return $row + $data;
}

/**
 * Eintrag, wie content_types_fetch_by_id ihn nach dem Speichern der geprüften Werte $values (content_types_values) liefert, ohne
 * zu speichern: beim Bearbeiten mit id, Reihenfolge und Anlegezeit von $stored, neu mit created_at; updated_at ist jetzt. Neu
 * ohne id und sort_order (vergibt erst das Anlegen). Für die Vorschau (api/preview.php).
 */
function content_types_saved_row(array $values, ?array $stored): array
{
    $now = db_now();
    $columns = $stored === null ? ['created_at' => $now] : ['id' => $stored['id'], 'sort_order' => $stored['sort_order'], 'created_at' => $stored['created_at']];

    return content_types_expand_row($columns + ['updated_at' => $now, 'data' => plugin_schema_json($values)]);
}

/**
 * Speichert einen Eintrag (neu ohne $id, oben in der Liste; mit $after direkt hinter dem Eintrag $after, etwa als
 * Kopie, außer der Typ sortiert nach einem Feld, orderBy). Beim Bearbeiten werden danach Bilder gelöscht,
 * die der Eintrag nicht mehr nutzt (ersetzt, Zeile entfernt), sofern sie sonst nirgends verwendet werden.
 * Liefert die id; 0, wenn es den Eintrag $id dieses Typs nicht (mehr) gibt (api/save.php antwortet dann 404).
 */
function content_types_save(string $type, array $rawValues, ?int $id = null, ?int $after = null): int
{
    if (!content_types_name_valid($type)) {
        throw new InvalidArgumentException(API_TEXT['invalidType']);
    }
    $def = content_types_load($type);
    if ($id === null || $id <= 0) {
        $values = content_types_values($def, $rawValues);
        // Mit orderBy bestimmt das Feld die Reihenfolge, wie beim Verschieben von Hand (content_types_move).
        return $after === null || isset($def['orderBy']) ? content_types_insert($type, $values) : content_types_insert_after($type, $values, $after);
    }
    $stored = content_types_fetch_by_id($type, $id);
    if ($stored === null) {
        return 0;
    }
    $values = content_types_values($def, $rawValues, $stored);

    $fields = content_types_schema_columns($def);
    $before = plugin_schema_image_values($fields, $stored);
    $title = content_types_title_field($def);
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('UPDATE content_items SET data = ?, updated_at = ? WHERE content_type = ? AND id = ?');
        $stmt->execute([plugin_schema_json($values), db_now(), $type, $id]);
        if ($title !== null) {
            content_types_rename_option($type, $id, $stored[$title] ?? null, $values[$title] ?? null);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    delete_unused_uploads(array_diff($before, plugin_schema_image_values($fields, $values)));

    return $id;
}

/**
 * Umbenannter Eintrag $id des Typs $type, dessen Titel ein Auswahlwert anderer Typen ist (optionsFrom): Deren
 * Einträge mit dem alten Titel $old bekommen den neuen $new. Nicht, solange ein anderer Eintrag des Typs den alten
 * Titel noch trägt (doppelte Werte zählen in der Auswahl einmal). Läuft in der Transaktion des Speicherns.
 */
function content_types_rename_option(string $type, int $id, mixed $old, mixed $new): void
{
    if (!is_string($old) || !is_string($new) || $old === '' || $new === '' || $old === $new) {
        return;
    }
    $targets = [];
    foreach (content_types_list_names() as $name) {
        try {
            $def = content_types_read($name);
        } catch (Throwable $e) {
            continue;
        }
        foreach (content_types_schema_columns($def) as $field) {
            if ($field['type'] === 'select' && ($field['optionsFrom'] ?? null) === $type) {
                $targets[$name][] = $field['name'];
            }
        }
    }
    if ($targets === []) {
        return;
    }
    $title = (string) content_types_title_field(content_types_read($type));
    foreach (content_types_fetch_list($type, null) as $row) {
        if ((int) $row['id'] !== $id && ($row[$title] ?? null) === $old) {
            return;
        }
    }
    $select = db()->prepare('SELECT id, data FROM content_items WHERE content_type = ?');
    $update = db()->prepare('UPDATE content_items SET data = ?, updated_at = ? WHERE id = ?');
    $now = db_now();
    foreach ($targets as $name => $names) {
        $select->execute([$name]);
        foreach ($select->fetchAll() as $row) {
            $data = json_decode((string) $row['data'], true);
            if (!is_array($data)) {
                continue;
            }
            $changed = false;
            foreach ($names as $field) {
                if (($data[$field] ?? null) === $old) {
                    $data[$field] = $new;
                    $changed = true;
                }
            }
            if ($changed) {
                $update->execute([plugin_schema_json($data), $now, $row['id']]);
            }
        }
    }
}

/** Legt einen Eintrag mit geprüften Werten (content_types_values) oben in der Liste an, mit $atEnd am Ende; liefert die id. */
function content_types_insert(string $type, array $values, bool $atEnd = false): int
{
    $stmt = db()->prepare('SELECT ' . ($atEnd ? 'MAX' : 'MIN') . '(sort_order) FROM content_items WHERE content_type = ?');
    $stmt->execute([$type]);
    $edge = $stmt->fetchColumn();
    $sortOrder = $edge === null ? 0 : (int) $edge + ($atEnd ? 1 : -1);

    $now = db_now();
    $stmt = db()->prepare('INSERT INTO content_items (content_type, data, sort_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([$type, plugin_schema_json($values), $sortOrder, $now, $now]);
    return (int) db()->lastInsertId();
}

/**
 * Legt einen Eintrag wie content_types_insert an und setzt ihn direkt hinter den Eintrag $after desselben Typs; der Typ
 * wird dabei in seiner Reihenfolge durchnummeriert (auch bei Gleichständen, etwa lauter sort_order 0). Ganz oder gar
 * nicht, unter der Sperre des Verschiebens (content_types_locked_ids). Gibt es $after in diesem Typ nicht, bleibt der
 * Eintrag oben. Liefert die id.
 */
function content_types_insert_after(string $type, array $values, int $after): int
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $ids = content_types_locked_ids($type);
        $id = content_types_insert($type, $values);
        $ids = content_types_placed($ids, $id, $after, true);
        if ($ids !== null) {
            content_types_renumber($type, $ids);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }

    return $id;
}

/** ids der Einträge eines Typs in ihrer Reihenfolge (CONTENT_TYPES_ORDER). */
function content_types_ordered_ids(string $type): array
{
    $stmt = db()->prepare('SELECT id FROM content_items WHERE content_type = ? ORDER BY ' . CONTENT_TYPES_ORDER);
    $stmt->execute([$type]);

    return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
}

/** Nummeriert die Einträge $ids des Typs in dieser Reihenfolge durch (sort_order 0 …); in der Transaktion des Aufrufers. */
function content_types_renumber(string $type, array $ids): void
{
    $update = db()->prepare('UPDATE content_items SET sort_order = ? WHERE content_type = ? AND id = ?');
    foreach ($ids as $index => $itemId) {
        $update->execute([$index, $type, $itemId]);
    }
}

/**
 * Wie content_types_ordered_ids, gesperrt bis zum Ende der laufenden Transaktion: Eine zweite Verschiebung (schnelles
 * Ziehen) oder Kopie liest erst, wenn die erste geschrieben hat, und überschreibt sie nicht. Dafür schreibt sie vor dem Lesen, ohne
 * etwas zu ändern: MySQL sperrt so die Zeilen des Typs, SQLite die Datenbank (sonst bräche SQLite das spätere Schreiben
 * ab, wenn ein anderer seit dem Lesen geschrieben hat).
 */
function content_types_locked_ids(string $type): array
{
    db()->prepare('UPDATE content_items SET sort_order = sort_order WHERE content_type = ?')->execute([$type]);

    return content_types_ordered_ids($type);
}

/**
 * Reihenfolge $ids mit $id direkt vor ($after false) bzw. hinter dem Eintrag $target; $id muss nicht darin stehen. null,
 * wenn es $target in $ids nicht gibt oder er $id selbst ist.
 */
function content_types_placed(array $ids, int $id, int $target, bool $after): ?array
{
    $ids = array_values(array_filter($ids, static fn (int $other): bool => $other !== $id));
    $pos = array_search($target, $ids, true);
    if ($target === $id || $pos === false) {
        return null;
    }
    array_splice($ids, $pos + ($after ? 1 : 0), 0, [$id]);

    return $ids;
}

/**
 * Setzt einen Eintrag in der ganzen Reihenfolge seines Typs direkt vor ($after false) bzw. hinter den Eintrag $target
 * (sichtbarer Nachbar auf der Seite, auch in einer gefilterten oder gekürzten Liste) und nummeriert den Typ dabei durch;
 * Lesen und Schreiben unter einer Sperre (content_types_locked_ids). Liefert false, wenn es einen der beiden in diesem
 * Typ nicht gibt, $target der Eintrag selbst ist, er schon dort steht oder der Typ nach einem Feld sortiert (orderBy).
 */
function content_types_move(string $type, int $id, int $target, bool $after): bool
{
    if (!content_types_name_valid($type) || $id <= 0) {
        return false;
    }
    // Mit orderBy bestimmt das Feld die Reihenfolge, von Hand verschieben gibt es nicht.
    if (isset(content_types_load($type)['orderBy'])) {
        return false;
    }

    $pdo = db();
    $pdo->beginTransaction();
    try {
        $ids = content_types_locked_ids($type);
        $placed = in_array($id, $ids, true) ? content_types_placed($ids, $id, $target, $after) : null;
        $moved = $placed !== null && $placed !== $ids;
        if ($moved) {
            content_types_renumber($type, $placed);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }

    return $moved;
}

/** Löscht den Eintrag samt seinen Bildern, sofern sie sonst nirgends verwendet werden (backend/plugins/entries.php). */
function content_types_delete(string $type, int $id): void
{
    if (!content_types_name_valid($type) || $id <= 0) {
        return;
    }
    plugin_delete_entry('content-types', $id, ['content_type' => $type]);
}
