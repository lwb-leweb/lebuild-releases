<?php
declare(strict_types=1);

// Vorlagen der Website für Content-Typen ausgeben: Eintrag für die Vorlagen, Vorlage und Blöcke rendern, eigene Seite
// samt Kopf und strukturierten Daten, Klartext, Adresse des Modals, Filterleiste und „Mehr laden“.

// Eigene Vorlagen für Blöcke (Feldart blocks, ct_blocks): CONTENT_TYPES_TEMPLATE_DIR/_blocks/<art>.php; der
// Unterstrich hält den Ordner frei von Typnamen (die mit einem Buchstaben beginnen).
const CONTENT_TYPES_BLOCK_DIR = '_blocks';
// Blockarten, deren Text als Klartext zählt (Beschreibung, fallback): Feld und ob es richtext ist (sonst wörtlich).
const CONTENT_TYPES_BLOCK_TEXT_FIELDS = ['text' => ['text', true], 'zitat' => ['text', false]];
// Dateien der Vorlagen in CONTENT_TYPES_TEMPLATE_DIR/<typ>/ (lib.php).
const CONTENT_TYPES_TEMPLATES = ['card' => 'card.php', 'detail' => 'detail.php', 'page' => 'page.php'];

// Versteckter Inhalt (detail.php) je Eintrag mit Ziel modal, angehängt an die Liste, mit der Adresse des
// Modals (#<typ>-<slug|id>, content_types_modal_hash) in CONTENT_TYPES_HASH_ATTR.
const CONTENT_TYPES_DETAIL_ATTR = 'data-ct-detail';
const CONTENT_TYPES_HASH_ATTR = 'data-ct-hash';
// Am Listen-Element eines Typs mit modal in actions (auch leer oder gerade ohne Modal-Eintrag): Seiten
// damit bekommen das Modal-Skript (content_types_filter_site_html), auch für später angelegte Einträge.
const CONTENT_TYPES_MODAL_LIST_ATTR = 'data-ct-modal';
// Schlüssel im $item der Vorlagen für das Klickziel (['action', 'href']); Feldnamen beginnen mit a–z.
const CONTENT_TYPES_ITEM_TARGET = '_target';
// HTML-Kommentare statt einer Vorlagen-Ausgabe bzw. des Filters (Details nur im Log); fehlt die ganze
// Liste, gilt CONTENT_TYPES_RENDER_FAILED, bei der Einzelansicht singleFailed.
const CONTENT_TYPES_RENDER_COMMENT = [
    'template' => 'template error',
    'detailMissing' => 'detail.php missing',
    'filter' => 'unknown filter field',
    'filterBy' => 'filter-by field is not a select or has the name of the page parameter',
    'listId' => 'data-id missing, invalid or duplicate',
    // Einzelansicht (data-view="single") ohne data-filter: welcher Eintrag gemeint ist, bliebe offen.
    'filterMissing' => 'data-filter missing',
    // Einzelansicht: Typ fehlt oder ist ungültig, Datenbankfehler (wie CONTENT_TYPES_RENDER_FAILED bei der Liste).
    'singleFailed' => 'single unavailable',
];
// Leere Liste.
const CONTENT_TYPES_EMPTY_TEXT = 'Noch keine Einträge.';
// Filterleiste (data-filter-by) als erstes Kind am Element des Shortcodes: <nav> mit dieser Klasse, Beschriftung
// (%s: Label des Feldes) und dem Link ohne Filter vor den Optionen.
const CONTENT_TYPES_FILTER_CLASS = 'content-filter';
const CONTENT_TYPES_FILTER_LABEL = 'Filter: %s';
const CONTENT_TYPES_FILTER_ALL = 'Alle';
// Link „Mehr laden“ (data-paging) als letztes Kind: lädt mit dem Skript der Liste (CONTENT_TYPES_LIST_ASSETS) nach,
// ohne Skript die nächste Seite.
const CONTENT_TYPES_MORE_CLASS = 'content-list__more';
const CONTENT_TYPES_MORE_TEXT = 'Mehr laden';
// Knopf an der Einzelansicht (eigene Seite, Modal) auf der Website (le_single_mark).
const CONTENT_TYPES_SINGLE_LABEL = 'Diesen Eintrag bearbeiten';
// Knöpfe an der Ansicht single (render/single.php) mit single.label des Typs (%s, z. B. „Galerie“): mit Eintrag bzw. ohne
// („noch keiner da“). Ohne single.label gelten die Vorgaben des Kerns (le_single_attrs).
const CONTENT_TYPES_SINGLE_LABELS = ['edit' => '%s bearbeiten', 'create' => '%s anlegen'];
// Höchstlänge der Meta-Beschreibung der eigenen Seite (descriptionField, z. B. richtext), sonst mit „…“.
const CONTENT_TYPES_DESCRIPTION_MAX = 160;
// Höchstlänge des Ersatzes für ein leeres Feld mit fallback (Anfang des anderen Feldes als Klartext), sonst mit „…“.
const CONTENT_TYPES_FALLBACK_MAX = 200;

/** Pfad einer Vorlage ($template: Schlüssel aus CONTENT_TYPES_TEMPLATES) oder null, wenn es sie nicht gibt. */
function content_types_template_path(string $type, string $template): ?string
{
    if (!content_types_name_valid($type) || !isset(CONTENT_TYPES_TEMPLATES[$template])) {
        return null;
    }
    $path = CONTENT_TYPES_TEMPLATE_DIR . '/' . $type . '/' . CONTENT_TYPES_TEMPLATES[$template];

    return is_file($path) ? $path : null;
}

/**
 * Knopftext der Ansicht single aus single.label des Typs ($kind: Schlüssel aus CONTENT_TYPES_SINGLE_LABELS); null ohne
 * single.label (dann die Vorgabe des Kerns).
 */
function content_types_single_label(array $def, string $kind): ?string
{
    $label = $def['single']['label'] ?? null;

    return is_string($label) ? sprintf(CONTENT_TYPES_SINGLE_LABELS[$kind], $label) : null;
}

/** HTML-Kommentar statt einer Ausgabe ($key aus CONTENT_TYPES_RENDER_COMMENT). */
function content_types_render_comment(string $key): string
{
    return '<!-- content-types: ' . CONTENT_TYPES_RENDER_COMMENT[$key] . ' -->';
}

/**
 * Eintrag für die Vorlagen: gespeicherte Werte mit id und dem Klickziel unter CONTENT_TYPES_ITEM_TARGET.
 * link führt auf url (nur erlaubte Schemata), page auf /<page.path>/<slug>; ohne Adresse gilt none.
 * Ein leeres Feld mit fallback bekommt den Anfang seines Quellfeldes (content_types_fill_fallbacks).
 */
function content_types_template_item(array $def, array $row): array
{
    $row = content_types_fill_fallbacks($def, $row);
    $action = content_types_item_action($def, $row);
    $href = match ($action) {
        'link' => is_string($row['url'] ?? null) ? sanitize_url($row['url'], TEXT_LINK_SCHEMES) : '',
        'page' => is_string($row['slug'] ?? null) && $row['slug'] !== '' ? '/' . $def['page']['path'] . '/' . rawurlencode($row['slug']) : '',
        default => '',
    };
    if (in_array($action, ['link', 'page'], true) && $href === '') {
        $action = 'none';
    }
    $row[CONTENT_TYPES_ITEM_TARGET] = ['action' => $action, 'href' => $href];

    return $row;
}

/**
 * Einträge für die Vorlagen (content_types_template_item) der veröffentlichten Einträge des Typs $def mit Ziel page, in
 * der Reihenfolge der Liste; ohne page in actions keine (für Sitemap und Stellen eines Bildes).
 */
function content_types_page_items(array $def): Generator
{
    if (!in_array('page', $def['actions'], true)) {
        return;
    }
    foreach (content_types_fetch_list($def['name'], null, null, $def, true) as $row) {
        $item = content_types_template_item($def, $row);
        if (content_types_item_target($item)['action'] === 'page') {
            yield $item;
        }
    }
}

/**
 * Felder mit fallback (Definition geprüft, content_types_definition_problem), die leer sind oder nur Leerraum
 * enthalten, bekommen den Anfang ihres Quellfeldes als Klartext (richtext ohne Auszeichnung, Umbrüche als
 * Leerzeichen), höchstens CONTENT_TYPES_FALLBACK_MAX Zeichen inkl. „…“. Gespeichert wird nichts.
 */
function content_types_fill_fallbacks(array $def, array $row): array
{
    foreach (content_types_schema_columns($def) as $field) {
        $from = $field['fallback'] ?? null;
        $value = $row[$field['name']] ?? '';
        if (is_string($from) && (!is_scalar($value) || trim((string) $value) === '')) {
            $row[$field['name']] = content_types_plain($def, $row, $from, CONTENT_TYPES_FALLBACK_MAX);
        }
    }

    return $row;
}

/**
 * Ausgabe einer Vorlage mit $item und $type (Typ-Definition), solange auch als ct_item()/ct_type(). Wirft sie,
 * wird die angefangene Ausgabe verworfen, der Fehler geloggt und null geliefert.
 */
function content_types_render_template(string $path, array $def, array $item): ?string
{
    $level = ob_get_level();
    $previous = content_types_current(['item' => $item, 'type' => $def, 'detail' => '']);
    ob_start();
    try {
        (static function (string $__path, array $item, array $type): void {
            require $__path;
        })($path, $item, $def);
    } catch (Throwable $e) {
        while (ob_get_level() > $level) {
            ob_end_clean();
        }
        error_log('content-types: ' . $def['name'] . '/' . basename($path) . ' item ' . ($item['id'] ?? '?') . ': ' . $e->getMessage());
        return null;
    } finally {
        content_types_current($previous);
    }

    return (string) ob_get_clean();
}

/**
 * Eintrag, den gerade eine Vorlage ausgibt (content_types_render_template, page.php): item, type und detail
 * (fertige Ausgabe von detail.php, nur für page.php). Mit $set ersetzt; liefert den bisherigen. Quelle von
 * ct_item(), ct_type() und ct_detail(), die Includes der Website nicht überschreiben können wie $item
 * (z. B. foreach ($NAV_ITEMS as $item) in einer Navigation auf oberster Ebene).
 */
function content_types_current(?array $set = null): array
{
    static $current = ['item' => [], 'type' => [], 'detail' => ''];
    $previous = $current;
    if ($set !== null) {
        $current = $set;
    }

    return $previous;
}

/**
 * Eigene Seite eines Eintrags (Hook site_page) als Dokument für den Router (le_site_document): detail.php, als
 * Einzelansicht markiert (le_single_mark), in page.php (sieht $item, $type, $detail, sicher vor Includes der
 * Website als ct_item(), ct_type(), ct_detail()) oder im Rahmen der
 * Startseite. Beide bindet der Router auf oberster Ebene ein wie jede Seite; danach setzt finish
 * Titel, Beschreibung, canonical, og und <base> auf die Startseite (relative Adressen des Rahmens).
 * null, wenn das Ziel nicht page ist oder detail.php fehlt bzw. wirft (Grund im Log).
 */
function content_types_page(array $def, array $row): ?array
{
    $item = content_types_template_item($def, $row);
    $target = content_types_item_target($item);
    if ($target['action'] !== 'page') {
        return null;
    }
    $detailPath = content_types_template_path($def['name'], 'detail');
    if ($detailPath === null) {
        error_log('content-types: ' . $def['name'] . ': ' . CONTENT_TYPES_RENDER_COMMENT['detailMissing']);
        return null;
    }
    $detail = content_types_render_template($detailPath, $def, $item);
    if ($detail === null) {
        return null;
    }
    $detail = le_single_mark($detail, 'content-types', $def['name'], (int) $item['id'], CONTENT_TYPES_SINGLE_LABEL);
    $head = [
        'title' => content_types_plain($def, $item, $def['page']['titleField']),
        'description' => content_types_plain($def, $item, $def['page']['descriptionField'], CONTENT_TYPES_DESCRIPTION_MAX),
        'canonical' => (le_site_base_url() ?? '') . $target['href'],
        'base' => LE_SITE_HOME_URL,
    ];
    $jsonLd = le_seo_json_ld_tag(content_types_page_json_ld($def, $item, $head));
    $setHead = static fn (string $html): string => le_seo_head_append(le_site_html_set_head($html, $head), $jsonLd);

    $pagePath = content_types_template_path($def['name'], 'page');
    if ($pagePath !== null) {
        // page.php läuft auf oberster Ebene: $item und $type können ihre Includes überschreiben, ct_item() usw. nicht.
        $entry = ['item' => $item, 'type' => $def, 'detail' => $detail];
        content_types_current($entry);
        return le_site_document($pagePath, 200, $entry, $setHead, $pagePath);
    }
    $home = le_site_request_file(LE_SITE_HOME_URL);
    $finish = static fn (string $html): string => $setHead(le_site_page_frame($html, $detail));

    return le_site_document($home !== null && le_site_is_document($home) ? $home : null, 200, [], $finish, $detailPath);
}

/**
 * Strukturierte Daten der eigenen Seite (schema.org, Art aus page.schema; ohne []): Titel und Beschreibung aus
 * $head, veröffentlicht am publishField (sonst Anlegedatum), geändert am updated_at, das erste Bild, Autor und
 * Herausgeber der Betreiber aus den Einstellungen. Ohne Website-Adresse [] (schema.org braucht absolute Adressen).
 */
function content_types_page_json_ld(array $def, array $item, array $head): array
{
    $schema = $def['page']['schema'] ?? null;
    $base = le_seo_base_url();
    if (!is_string($schema) || $base === null) {
        return [];
    }
    $date = static function (mixed $value): ?string {
        $time = is_string($value) && $value !== '' ? strtotime($value) : false;
        return $time === false ? null : date('c', $time);
    };
    $published = $date(isset($def['publishField']) ? ($item[$def['publishField']] ?? null) : null) ?? $date($item['created_at'] ?? null);
    $organization = ['@type' => 'Organization', '@id' => $base . '/#organization', 'name' => (string) (le_site_config()['name'] ?? LE_SITE_CONFIG_DEFAULTS['name'])];
    $data = [
        '@context' => 'https://schema.org',
        '@type' => $schema,
        'headline' => $head['title'],
        'description' => $head['description'],
        'url' => $head['canonical'],
        'mainEntityOfPage' => $head['canonical'],
        'author' => $organization,
        'publisher' => $organization,
    ];
    if ($published !== null) {
        $data['datePublished'] = $published;
    }
    if (($modified = $date($item['updated_at'] ?? null)) !== null) {
        $data['dateModified'] = $modified;
    }
    foreach (content_types_schema_columns($def) as $field) {
        $value = $item[$field['name']] ?? null;
        if ($field['type'] === 'image' && is_string($value) && $value !== '' && ($image = le_seo_absolute($value)) !== null) {
            $data['image'] = $image;
            break;
        }
    }

    return $data;
}

/**
 * Klartext eines Feldes des Typs $def (Titel, Beschreibung im Kopf der Seite): richtext ohne Auszeichnung,
 * text und textarea wörtlich (reiner Text, Umbrüche als Leerzeichen), höchstens $max Zeichen inkl. „…“; escaped wird beim Einsetzen.
 */
function content_types_plain(array $def, array $item, string $field, ?int $max = null): string
{
    $value = $item[$field] ?? '';
    $types = array_column(content_types_schema_columns($def), 'type', 'name');
    $text = match (true) {
        ($types[$field] ?? null) === 'blocks' => content_types_blocks_plain($value),
        !is_scalar($value) => '',
        ($types[$field] ?? null) === 'richtext' => text_markup_plain((string) $value),
        default => (string) $value,
    };

    return text_excerpt($text, $max ?? mb_strlen($text), true);
}

/** Klartext der Text- und Zitat-Blöcke eines blocks-Wertes (CONTENT_TYPES_BLOCK_TEXT_FIELDS), durch Leerzeichen getrennt. */
function content_types_blocks_plain(mixed $value): string
{
    $parts = [];
    foreach (plugin_schema_list_rows($value) as $block) {
        [$field, $rich] = CONTENT_TYPES_BLOCK_TEXT_FIELDS[$block[PLUGIN_SCHEMA_BLOCK_TYPE] ?? ''] ?? [null, false];
        if ($field !== null && is_string($block[$field] ?? null)) {
            $parts[] = $rich ? text_markup_plain($block[$field]) : $block[$field];
        }
    }

    return implode(' ', $parts);
}

/**
 * Adresse des Modals ohne #: <typ>-<slug>, wenn der Typ eigene Seiten hat und der Eintrag eine Adresse,
 * sonst <typ>-<id>. Ein eigenes Feld slug eines Typs ohne page zählt nicht (beliebiger Text).
 */
function content_types_modal_hash(array $def, array $item): string
{
    $slug = in_array('page', $def['actions'], true) && is_string($item['slug'] ?? null) ? $item['slug'] : '';

    return $def['name'] . '-' . ($slug !== '' ? $slug : (string) (int) ($item['id'] ?? 0));
}

/** Klickziel aus content_types_template_item(); ohne (z. B. Zeile aus ct_rows) none ohne Adresse. */
function content_types_item_target(array $item): array
{
    $target = $item[CONTENT_TYPES_ITEM_TARGET] ?? null;

    return is_array($target) ? $target : ['action' => 'none', 'href' => ''];
}

/** Schlichtes Markup eines Blocks der Art $type (PLUGIN_SCHEMA_BLOCKS), escaped über die ct_-Helfer. */
function content_types_block_html(string $type, array $block): string
{
    $caption = static fn (array $row): string => (string) ($row['text'] ?? '') !== '' ? '<figcaption>' . ct_text($row, 'text') . '</figcaption>' : '';
    $lazy = static fn (string $img): string => $img === '' ? '' : substr_replace($img, '<img loading="lazy" ', 0, 5); // le-img: setzt nur loading in ein fertiges Bild aus ct_image
    $class = 'ct-block ct-block--' . $type;

    return match ($type) {
        'text' => '<div class="' . $class . '">' . ct_rich($block, 'text') . '</div>',
        'bild' => '<figure class="' . $class . '">' . ct_image($block, 'bild', 'text') . $caption($block) . '</figure>',
        'galerie' => '<div class="' . $class . '">' . implode('', array_map(
            static fn (array $row): string => '<figure>' . $lazy(ct_image($row, 'bild', 'text')) . $caption($row) . '</figure>',
            ct_rows($block, 'bilder')
        )) . '</div>',
        'zitat' => '<blockquote class="' . $class . '"><p>' . ct_lines($block, 'text') . '</p>'
            . ((string) ($block['quelle'] ?? '') !== '' ? '<footer>' . ct_text($block, 'quelle') . '</footer>' : '') . '</blockquote>',
        // Je Zeile das PDF (datei), sonst der Link; Zeilen ohne beides fallen weg.
        'downloads' => '<ul class="' . $class . '">' . implode('', array_map(
            static function (array $row): string {
                $href = ct_url_attrs($row, (string) ($row['datei'] ?? '') !== '' ? 'datei' : 'link');
                return $href === '' ? '' : '<li><a ' . $href . '>' . ct_text($row, 'titel') . '</a></li>';
            },
            ct_rows($block, 'dateien')
        )) . '</ul>',
        default => '',
    };
}

/** Ausgabe der Vorlage eines Blocks mit $block und $item; wirft sie, null (angefangene Ausgabe verworfen, Grund im Log). */
function content_types_render_block(string $path, array $block, array $item): ?string
{
    $level = ob_get_level();
    ob_start();
    try {
        (static function (string $__path, array $block, array $item): void {
            require $__path;
        })($path, $block, $item);
    } catch (Throwable $e) {
        while (ob_get_level() > $level) {
            ob_end_clean();
        }
        error_log('content-types: ' . CONTENT_TYPES_BLOCK_DIR . '/' . basename($path) . ': ' . $e->getMessage());
        return null;
    }

    return (string) ob_get_clean();
}

/**
 * Filterleiste der Liste $id mit data-filter-by: „Alle“, dann die $options (schon ohne die ohne sichtbaren Eintrag),
 * die aktive ($active, sonst „Alle“) mit aria-current. Die Links führen auf $path mit allen übrigen Parametern von
 * $query (auch denen anderer Listen), ohne den eigenen Filter und die eigene Seite.
 */
function content_types_filter_nav(array $field, array $options, ?string $active, string $id, string $path, array $query): string
{
    $param = content_types_list_param($id, (string) $field['name']);
    $rest = array_diff_key($query, [$param => true, content_types_list_param($id, CONTENT_TYPES_PAGE_PARAM) => true]);
    $link = static fn (string $text, array $params, bool $current): string => '<a '
        . le_attrs(['class' => CONTENT_TYPES_FILTER_CLASS . '__link', 'href' => content_types_list_href($path, $params)] + ($current ? ['aria-current' => 'page'] : []))
        . '>' . markup_attr_escape($text) . '</a>';
    $html = $link(CONTENT_TYPES_FILTER_ALL, $rest, $active === null);
    foreach ($options as $option) {
        $html .= $link($option, $rest + [$param => plugin_schema_slugify($option)], $option === $active);
    }
    $label = sprintf(CONTENT_TYPES_FILTER_LABEL, (string) ($field['label'] ?? $field['name']));

    return '<nav ' . le_attrs(['class' => CONTENT_TYPES_FILTER_CLASS, 'aria-label' => $label]) . '>' . $html . '</nav>';
}

/** Link „Mehr laden“ auf Seite $page der Liste $id: $path mit allen Parametern von $query und der eigenen Seite. */
function content_types_more_link(int $page, string $id, string $path, array $query): string
{
    $param = content_types_list_param($id, CONTENT_TYPES_PAGE_PARAM);
    $params = array_diff_key($query, [$param => true]) + [$param => $page];

    return '<a ' . le_attrs(['class' => CONTENT_TYPES_MORE_CLASS, 'href' => content_types_list_href($path, $params)]) . ' ' . LE_MORE_ATTR . '>'
        . CONTENT_TYPES_MORE_TEXT . '</a>';
}
