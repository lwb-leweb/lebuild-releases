<?php
declare(strict_types=1);

// Sicher require_once-bar aus beliebigen PHP-Templates. Bei aktivem Plugin lädt sie lib.php (beim Laden tut die nichts),
// damit auch die Vorlagen-Helfer ct_* da sind, ebenso bei fehlgeschlagenem Schema. Jede Lesefunktion fragt zuerst
// le_plugin_public_ready: inaktiv oder Schema fehlgeschlagen → leeres Ergebnis, ohne Lesen aus dem halben Schema.

if (plugin_active('content-types')) {
    require_once __DIR__ . '/lib.php';
}

function content_types_public_list(string $type, int $limit = 100): array
{
    if (!le_plugin_public_ready('content-types')) {
        return [];
    }
    try {
        // Wie auf der Website: Reihenfolge nach orderBy, noch nicht fällige (publishField) und abgelaufene
        // (expireField) fehlen.
        return content_types_fetch_list($type, $limit, null, content_types_load($type), true);
    } catch (Throwable $e) {
        return [];
    }
}

function content_types_public_get(string $type, int $id): ?array
{
    if (!le_plugin_public_ready('content-types')) {
        return null;
    }
    try {
        $row = content_types_fetch_by_id($type, $id);
        // Noch nicht fällig (publishField) oder abgelaufen (expireField): wie ein fehlender Eintrag.
        return $row !== null && content_types_published(content_types_load($type), $row) ? $row : null;
    } catch (Throwable $e) {
        return null;
    }
}
