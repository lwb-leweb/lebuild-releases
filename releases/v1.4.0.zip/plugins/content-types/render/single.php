<?php
require_once __DIR__ . '/../lib.php';

// Einzelansicht (data-view="single", z. B. eine Galerie je Bereich): der erste Eintrag des Typs, der data-filter erfüllt
// (Pflicht), mit card.php bzw. der Standardausgabe. Die Markierung (le_single_attrs) trägt das Element des Shortcodes, an dem
// auch data-filter steht. Ohne veröffentlichten Eintrag bekommen Besucher nichts, Angemeldete das leere markierte Element:
// „… bearbeiten“ für einen passenden, der noch nicht fällig oder abgelaufen ist (sonst entstünde ein zweiter; mit
// LE_SINGLE_HIDDEN_ATTR), sonst „… anlegen“.

$type = (string) ($attrs['type'] ?? '');
$def = content_types_render_def($type);
if ($def === null) {
    echo content_types_render_comment('singleFailed');
    return;
}
$schema = content_types_schema_columns($def);

try {
    $filter = content_types_list_filter($schema, $attrs['filter'] ?? null);
} catch (InvalidArgumentException $e) {
    // Unbekanntes Feld in data-filter: Kommentar statt Ausgabe, Grund ins Log.
    error_log('content-types: ' . $type . ': ' . $e->getMessage());
    echo content_types_render_comment('filter');
    return;
}
if ($filter === null) {
    error_log('content-types: ' . $type . ': ' . CONTENT_TYPES_RENDER_COMMENT['filterMissing']);
    echo content_types_render_comment('filterMissing');
    return;
}

try {
    $row = content_types_fetch_list($type, 1, $filter, $def, true)[0] ?? null;
    // Angemeldete (Ausgabe nicht im Cache, backend/site/render.php: no-store) bearbeiten auch einen noch nicht fälligen oder
    // abgelaufenen Eintrag, statt einen zweiten anzulegen.
    $editor = $row === null && signed_in_user() !== null;
    $hidden = $editor ? content_types_fetch_list($type, 1, $filter, $def)[0] ?? null : null;
} catch (Throwable $e) {
    // Datenbankfehler: Grund nur ins Log.
    error_log('content-types: ' . $type . ': ' . $e->getMessage());
    echo content_types_render_comment('singleFailed');
    return;
}

if ($row === null) {
    if ($editor) {
        $hostAttrs = $hidden === null
            ? le_single_attrs('content-types', $type, null, content_types_single_label($def, 'create'))
            : le_single_attrs('content-types', $type, (int) $hidden['id'], content_types_single_label($def, 'edit')) . ' ' . LE_SINGLE_HIDDEN_ATTR;
    }
    return;
}

$hostAttrs = le_single_attrs('content-types', $type, (int) $row['id'], content_types_single_label($def, 'edit'));
echo content_types_single_html($def, $schema, $row);
