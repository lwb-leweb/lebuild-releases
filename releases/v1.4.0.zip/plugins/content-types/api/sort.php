<?php
declare(strict_types=1);

require_auth();
require_csrf();
le_indexnow_watch();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$type = (string) ($body['type'] ?? '');
$id = (int) ($body['id'] ?? 0);
// Sichtbarer Nachbar auf der Seite, vor bzw. hinter den der Eintrag kommt (position).
$target = (int) ($body['target'] ?? 0);
$position = $body['position'] ?? null;
if (!content_types_name_valid($type) || $id <= 0 || $target <= 0 || !in_array($position, LE_INLINE_EDIT_SORT_POSITIONS, true)) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidRequest']], 400);
}

try {
    $moved = content_types_move($type, $id, $target, $position === LE_INLINE_EDIT_SORT_AFTER);
} catch (Throwable $e) {
    plugin_failure_response('sort', $e);
}

json_response(['ok' => true, 'moved' => $moved]);
