<?php
declare(strict_types=1);

// Vorschau einer Einzelansicht mit ungespeicherten Werten (inlineEdit „preview“, docs/knowledgebase/plugins/endpoints.md):
// geprüft wie beim Speichern, ausgegeben wie render/single.php, gespeichert wird nichts. Ohne Schreiben weder
// le_open_uploads_hold noch le_indexnow_watch.

require_auth();
require_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

$body = read_json_body();
$type = (string) ($body['type'] ?? '');
if (!content_types_name_valid($type)) {
    json_response(['ok' => false, 'error' => API_TEXT['invalidType']], 400);
}
$rawValues = is_array($body['data'] ?? null) ? $body['data'] : [];
$id = (int) ($body['id'] ?? 0);
// list-Feld, dessen Zeilen ihre Stelle als LE_ROW_ATTR tragen (das Feld der Vorschau im Formular).
$field = $body['field'] ?? null;

try {
    $def = content_types_load($type);
    $stored = $id > 0 ? content_types_fetch_by_id($type, $id) : null;
} catch (Throwable $e) {
    plugin_failure_response('preview', $e);
}
if ($id > 0 && $stored === null) {
    // Inzwischen gelöscht, wie api/save.php.
    json_response(['ok' => false, 'error' => API_TEXT['notFound']], 404);
}
$schema = content_types_schema_columns($def);
if (!is_string($field) || (array_column($schema, 'type', 'name')[$field] ?? null) !== 'list') {
    json_response(['ok' => false, 'error' => API_TEXT['invalidRequest']], 400);
}

try {
    $values = content_types_values($def, $rawValues, $stored, $field);
    $html = content_types_single_html($def, $schema, content_types_saved_row($values, $stored));
} catch (InvalidArgumentException $e) {
    json_response(['ok' => false, 'error' => $e->getMessage()], 400);
} catch (Throwable $e) {
    plugin_failure_response('preview', $e);
}

json_response(['ok' => true, 'html' => $html]);
