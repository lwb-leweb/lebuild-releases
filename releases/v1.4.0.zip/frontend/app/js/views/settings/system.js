import { state, api, postJson, setMessage } from '../../../../shared/core.js';
import { ENDPOINTS } from '../../../../shared/endpoints.js';
import { row } from './updates.js';

// Karte „System“: Ergebnis der Systemprüfung, bei einem fehlgeschlagenen Plugin-Schema mit „Erneut versuchen“.

const SCHEMA_RETRY_DONE = 'Schema nachgezogen, das Plugin läuft wieder.';
// Antwort ohne Versuch: Das Schema war inzwischen schon geheilt (anderer Admin, neue Version).
const SCHEMA_RETRY_NOTHING = 'Kein Fehlerstand mehr, es war nichts zu tun.';

function setSystemMessage(text, ok) {
  setMessage(document.getElementById('systemMessage'), text, ok);
}

export function loadSystemChecks() {
  return api(ENDPOINTS.system.checks)
    .then(function (data) {
      renderSystemChecks(data.checks || []);
      // Für das Dashboard: dieselben Mängel wie aus bootstrap, nach „Erneut versuchen“ auf dem neuen Stand.
      state.systemProblems = data.problems || [];
      setSystemMessage('', true);
    })
    .catch(function (error) {
      setSystemMessage(error.message, false);
    });
}

function renderSystemChecks(checks) {
  const el = document.getElementById('systemChecks');
  if (!el) return;
  el.innerHTML = '';
  checks.forEach(function (check) {
    const r = row(check.label, check.ok ? 'OK' : (check.hint ? 'Hinweis' : 'Mangel'));
    // Ein Hinweis ist kein Fehler: ohne die rote Farbe eines Mangels.
    r.lastChild.className = check.ok ? 'message ok' : (check.hint ? '' : 'message');
    el.appendChild(r);
    if (!check.ok) {
      const purpose = document.createElement('small');
      purpose.className = check.hint ? '' : 'message';
      purpose.textContent = check.purpose;
      el.appendChild(purpose);
    }
    if (check.retryPlugin) el.appendChild(retryActions(check.retryPlugin));
  });
}

function retryActions(plugin) {
  const actions = document.createElement('div');
  actions.className = 'update-card__actions';
  const button = document.createElement('button');
  button.type = 'button';
  button.textContent = 'Erneut versuchen';
  button.dataset.retryPlugin = plugin;
  button.addEventListener('click', function () {
    retrySchema(plugin, button);
  });
  actions.appendChild(button);
  return actions;
}

// Danach die Prüfungen neu laden; die Meldung erst dann, sonst löscht das Neuladen sie. Der Fokus bleibt an der Stelle:
// am Knopf desselben Plugins, wenn es ihn noch gibt, sonst an der Meldung.
function retrySchema(plugin, button) {
  button.disabled = true;
  postJson(ENDPOINTS.plugins.retrySchema, { name: plugin })
    .then(function (data) { return { text: data.retried === false ? SCHEMA_RETRY_NOTHING : SCHEMA_RETRY_DONE, ok: true }; })
    .catch(function (error) { return { text: error.message, ok: false }; })
    .then(function (result) {
      return loadSystemChecks().then(function () {
        setSystemMessage(result.text, result.ok);
        const message = document.getElementById('systemMessage');
        const again = Array.from(document.querySelectorAll('#systemChecks [data-retry-plugin]'))
          .find(function (el) { return el.dataset.retryPlugin === plugin; });
        if (again) {
          again.focus();
        } else if (message) {
          message.tabIndex = -1;
          message.focus();
        }
      });
    });
}
