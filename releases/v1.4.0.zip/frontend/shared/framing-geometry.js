// Rechnung des Bausteins „Ausschnitt“ (image-framing.js): Quelle für den Server, Fokuspunkt, Rahmen des Zuschnitts,
// Formate, die Umrechnung in Pixel des Originals und die Vorschauen. Ohne DOM und
// ohne Importe, damit sie sich für sich prüfen lässt (tests/frontend/framing-geometry.test.php).
// Rahmen: { x, y, w, h } in Pixeln des Originals (W × H, wie angezeigt), beim Ziehen mit Nachkommastellen.

const PERCENT = 100;
// Trenner der zwei Werte eines Fokuspunkts „<x>% <y>%“ (Format am Server: LE_FOCUS_PATTERN).
const FOCUS_SEPARATOR = ' ';
const FOCUS_UNIT = '%';
// Ecken des Rahmens: w/e = links/rechts, n/s = oben/unten.
export const CORNERS = ['nw', 'ne', 'sw', 'se'];
// object-fit bzw. background-size, bei dem ein Rahmen das Bild beschneidet (die Vorschau füllt ihn dann).
export const FIT_COVER = 'cover';
// Bis zu dieser Abweichung der Seitenverhältnisse (Anteil) gelten zwei gemessene Formen als gleich (sameShape).
const SHAPE_TOLERANCE = 0.01;
// Ohne Fokuspunkt richtet object-position mittig aus.
const FOCUS_CENTER = 50;
// Nachkommastellen der Rundung eines Rahmens in Prozent (radiusPercent).
const RADIUS_DIGITS = 100;
// Hintergrundebene mit Bild im berechneten background-image (imageFit).
const URL_LAYER_PATTERN = /^url\(/i;

export function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

// Pfad eines Bildwerts url, wie der Browser ihn anfragt (framingSource, Höhe beim Bildtausch in page-sync.js): aufgelöst gegen base (Adresse der Seite bzw.
// ihr <base>), ab „/“, ohne Host, Query und Fragment, Namen prozent-kodiert (der Server dekodiert einmal). So gilt er auf
// jeder Seite gleich. null für eine andere Herkunft als origin (fremde Adresse, data:), Unlesbares und Endungen
// außerhalb von types (Kleinbuchstaben, ohne Punkt).
export function framingPath(url, base, origin, types) {
  if (!url) return null;
  let parsed;
  try {
    parsed = new URL(url, base);
  } catch (e) {
    return null;
  }
  if (parsed.origin !== origin) return null;
  const name = parsed.pathname.split('/').pop();
  const dot = name.lastIndexOf('.');
  return dot !== -1 && types.indexOf(name.slice(dot + 1).toLowerCase()) !== -1 ? parsed.pathname : null;
}

// { x, y } → „x% y%“, der Wert des Fokus-Felds.
export function focusText(point) {
  return point.x + FOCUS_UNIT + FOCUS_SEPARATOR + point.y + FOCUS_UNIT;
}

// Wert des Fokus-Felds → { x, y }; leer oder anders → null (der Server liefert nur geprüfte Werte, hier wird nur gelesen).
export function focusParse(value) {
  const parts = String(value).split(FOCUS_SEPARATOR);
  if (parts.length !== 2 || !parts.every(function (part) { return part.endsWith(FOCUS_UNIT); })) return null;
  const x = parseFloat(parts[0]);
  const y = parseFloat(parts[1]);
  return isNaN(x) || isNaN(y) ? null : { x: x, y: y };
}

// Seitenverhältnis eines Formats ([b, h]) als Zahl; null = frei.
export function ratioOf(ratio) {
  return ratio ? ratio[0] / ratio[1] : null;
}

export function fullRect(W, H) {
  return { x: 0, y: 0, w: W, h: H };
}

// Größter mittiger Rahmen im Seitenverhältnis ratio (Zahl, null = ganzes Bild).
function centeredRect(W, H, ratio) {
  if (!ratio) return fullRect(W, H);
  let w = W;
  let h = W / ratio;
  if (h > H) {
    h = H;
    w = H * ratio;
  }
  return { x: (W - w) / 2, y: (H - h) / 2, w: w, h: h };
}

// Rahmen im Format ratio (Zahl, null = frei: rect bleibt) um die Mitte von rect: so groß, dass er rect in einer Richtung
// abdeckt, höchstens der größte im Bild (centeredRect), ganz im Bild.
export function formatRect(rect, W, H, ratio) {
  if (!ratio) return rect;
  const largest = centeredRect(W, H, ratio);
  const scale = Math.min(1, Math.max(rect.w / largest.w, rect.h / largest.h));
  const w = largest.w * scale;
  const h = largest.h * scale;
  return { x: clamp(rect.x + (rect.w - w) / 2, 0, W - w), y: clamp(rect.y + (rect.h - h) / 2, 0, H - h), w: w, h: h };
}

// Rahmen um (dx, dy) verschoben, ganz im Bild.
export function movedRect(rect, dx, dy, W, H) {
  return { x: clamp(rect.x + dx, 0, W - rect.w), y: clamp(rect.y + dy, 0, H - rect.h), w: rect.w, h: rect.h };
}

// Gegenüberliegende Ecke von corner: Sie bleibt stehen, während an corner gezogen wird.
export function anchorOf(rect, corner) {
  return {
    x: corner.indexOf('w') !== -1 ? rect.x + rect.w : rect.x,
    y: corner.indexOf('n') !== -1 ? rect.y + rect.h : rect.y
  };
}

// Rahmen beim Ziehen an corner bis point, gegen anchor (anchorOf); mindestens min.w breit und min.h hoch (cropMin), soweit das Bild
// reicht, mit ratio (Zahl, null = frei) im Format. Der Rahmen bleibt auf der Seite der gezogenen Ecke.
export function resizedRect(anchor, point, corner, ratio, min, W, H) {
  const west = corner.indexOf('w') !== -1;
  const north = corner.indexOf('n') !== -1;
  const maxW = west ? anchor.x : W - anchor.x;
  const maxH = north ? anchor.y : H - anchor.y;
  let w = Math.abs(point.x - anchor.x);
  let h = Math.abs(point.y - anchor.y);
  if (ratio) {
    // Beide Seiten mindestens ihr min, beide im Bild; reicht der Platz nicht dafür, gilt der Platz.
    // Maßgeblich ist die Richtung, in die weiter gezogen wurde.
    const upper = Math.min(maxW, maxH * ratio);
    w = clamp(Math.max(w, h * ratio), Math.min(Math.max(min.w, min.h * ratio), upper), upper);
    h = w / ratio;
  } else {
    w = clamp(w, Math.min(min.w, maxW), maxW);
    h = clamp(h, Math.min(min.h, maxH), maxH);
  }
  return { x: west ? anchor.x - w : anchor.x, y: north ? anchor.y - h : anchor.y, w: w, h: h };
}

// Kleinste Breite und Höhe eines Rahmens in Pixeln des Originals ({ w, h }): je min, und so viel, dass sie angezeigt
// mindestens shownMin CSS-Pixel messen (das Bild ist shown CSS-Pixel breit); jede höchstens das Bild in ihrer Richtung
// (ein flaches Panorama bekommt so die volle Mindestbreite, nur die Höhe ist begrenzt).
export function cropMin(min, shownMin, shown, W, H) {
  const side = Math.max(min, shownMin * W / shown);
  return { w: Math.min(side, W), h: Math.min(side, H) };
}

// Rahmen → Ausschnitt für den Server: ganze Zahlen, mindestens 1, ganz im Bild; das ganze Bild ist keiner (null).
export function cropOf(rect, W, H) {
  const x = clamp(Math.round(rect.x), 0, W - 1);
  const y = clamp(Math.round(rect.y), 0, H - 1);
  const w = clamp(Math.round(rect.w), 1, W - x);
  const h = clamp(Math.round(rect.h), 1, H - y);
  return x === 0 && y === 0 && w === W && h === H ? null : { x: x, y: y, w: w, h: h };
}

// Ausschnitt (null = ganzes Bild) → Rahmen.
export function rectOf(crop, W, H) {
  return crop ? { x: crop.x, y: crop.y, w: crop.w, h: crop.h } : fullRect(W, H);
}

// Gleiche Ausschnitte (beide null = ganzes Bild)?
export function sameCrop(a, b) {
  if (!a || !b) return a === b;
  return a.x === b.x && a.y === b.y && a.w === b.w && a.h === b.h;
}

// Format aus formats ([{ ratio: [b, h] | null }]), zu dem ein Ausschnitt passt (Rundung auf ganze Pixel eingerechnet);
// sonst das freie. Ohne Ausschnitt (ganzes Bild) ebenfalls das freie.
export function formatOf(crop, formats) {
  const free = formats.find(function (format) { return !format.ratio; });
  if (!crop) return free;
  const match = formats.find(function (format) {
    if (!format.ratio) return false;
    const b = format.ratio[0];
    const h = format.ratio[1];
    return Math.abs(crop.w * h - crop.h * b) <= (b + h) / 2;
  });
  return match || free;
}

// Rahmen als Lage in Prozent des Bildes (für left/top/width/height).
export function rectPercent(rect, W, H) {
  return { left: rect.x / W * PERCENT, top: rect.y / H * PERCENT, width: rect.w / W * PERCENT, height: rect.h / H * PERCENT };
}

// Punkt (clientX/Y) über der Fläche box in Pixeln des Originals (W × H), ganz im Bild.
export function pointIn(px, py, box, W, H) {
  return { x: clamp((px - box.left) / box.width, 0, 1) * W, y: clamp((py - box.top) / box.height, 0, 1) * H };
}

// Fokus focus ({ x, y } in Prozent des Zuschnitts rect) als Punkt in Pixeln des Originals.
export function focusPoint(focus, rect) {
  return { x: rect.x + focus.x / PERCENT * rect.w, y: rect.y + focus.y / PERCENT * rect.h };
}

// Punkt in Pixeln des Originals als Fokus in ganzen Prozent des Zuschnitts rect, begrenzt auf 0–100: Die Website
// positioniert die abgeleitete Datei, der Fokus bezieht sich darum auf den Zuschnitt.
export function cropFocus(point, rect) {
  return {
    x: Math.round(clamp((point.x - rect.x) / rect.w, 0, 1) * PERCENT),
    y: Math.round(clamp((point.y - rect.y) / rect.h, 0, 1) * PERCENT)
  };
}

// Punkt, der im Rahmen rect bleibt (auf seine Kante gezogen, wenn er außerhalb liegt).
export function clampToRect(point, rect) {
  return { x: clamp(point.x, rect.x, rect.x + rect.w), y: clamp(point.y, rect.y, rect.y + rect.h) };
}

// Wie das Element sein Bild in den Rahmen setzt, aus dem berechneten Stil style ({ objectFit, backgroundImage,
// backgroundSize }): bei einem Bild object-fit, bei einem Hintergrund (background) background-size der ersten Ebene mit
// Bild (ohne eine solche der ersten). Das Messen (framing-measure.js) liest so, ob die Vorschau den Rahmen füllt.
export function imageFit(style, background) {
  if (!background) return style.objectFit;
  const index = cssLayers(style.backgroundImage).findIndex(function (layer) { return URL_LAYER_PATTERN.test(layer); });
  return layerValue(style.backgroundSize, Math.max(0, index));
}

// Seitenverhältnis der Vorschau eines gemessenen Rahmens frame für ein Bild im Seitenverhältnis ratio: Folgt der Rahmen
// dem Bild (follows: Höhe auto, framing-measure.js), das des Bildes, sonst das gemessene.
export function previewRatio(frame, ratio) {
  return frame.follows ? ratio : frame.w / frame.h;
}

// Wie die Website den Zuschnitt rect des Originals (W × H) in einer Vorschau im Seitenverhältnis box zeigt: cover füllt
// den Rahmen, sonst ganz; Position = Fokus focus ({ x, y } in Prozent des Zuschnitts, null = Mitte). clip: Lage des
// Zuschnitts in Prozent der Vorschau (schneidet ab, was nicht zu ihm gehört; bei ganz bleibt daneben Platz), image: Lage
// des Originals in Prozent von clip; je { left, top, width, height }.
export function previewPlacement(rect, W, H, box, cover, focus) {
  const scale = (cover ? Math.max : Math.min)(box / rect.w, 1 / rect.h);
  const fx = (focus ? focus.x : FOCUS_CENTER) / PERCENT;
  const fy = (focus ? focus.y : FOCUS_CENTER) / PERCENT;
  const w = rect.w * scale;
  const h = rect.h * scale;
  return {
    clip: { left: (box - w) * fx / box * PERCENT, top: (1 - h) * fy * PERCENT, width: w / box * PERCENT, height: h * PERCENT },
    image: { left: -rect.x / rect.w * PERCENT, top: -rect.y / rect.h * PERCENT, width: W / rect.w * PERCENT, height: H / rect.h * PERCENT }
  };
}

// Rundung eines gemessenen Rahmens (w × h) als border-radius in Prozent, damit sie in jeder Größe der Vorschau gleich
// aussieht. corners: berechnete Werte der vier Ecken (oben links, oben rechts, unten rechts, unten links), je „12px“,
// „50%“ oder elliptisch „10px 20px“.
export function radiusPercent(corners, w, h) {
  const across = [];
  const down = [];
  const percent = function (part, size) {
    const value = parseFloat(part) || 0;
    const share = part.endsWith(FOCUS_UNIT) ? value : value / size * PERCENT;
    return Math.round(share * RADIUS_DIGITS) / RADIUS_DIGITS + FOCUS_UNIT;
  };
  corners.forEach(function (corner) {
    const parts = String(corner).trim().split(/\s+/);
    across.push(percent(parts[0], w));
    down.push(percent(parts[1] || parts[0], h));
  });
  return across.join(' ') + ' / ' + down.join(' ');
}

// Gleiche Form an zwei Stellen: dieselben Breiten (key), je Breite dieselbe Art (fit, follows), dieselbe Rundung und ein
// Seitenverhältnis innerhalb von SHAPE_TOLERANCE. Eine Breite, die an einer Stelle fehlt, macht die Form anders.
export function sameShape(a, b) {
  return a.length === b.length && a.every(function (frame) {
    const other = b.find(function (item) { return item.key === frame.key; });
    return Boolean(other) && frame.fit === other.fit && Boolean(frame.follows) === Boolean(other.follows) && frame.radius === other.radius
      && Math.abs(frame.w / frame.h / (other.w / other.h) - 1) < SHAPE_TOLERANCE;
  });
}

// Stellen ([{ label, frames }]) mit gleicher Form (sameShape) zusammengefasst: [{ labels, frames }] in der Reihenfolge,
// in der die erste Stelle jeder Form kam.
export function groupPlaces(places) {
  const groups = [];
  places.forEach(function (place) {
    const group = groups.find(function (item) { return sameShape(item.frames, place.frames); });
    if (group) group.labels.push(place.label);
    else groups.push({ labels: [place.label], frames: place.frames });
  });
  return groups;
}

// Gemeinsames Messen der Bildfelder eines Formulars (framing-measure.js): Adressen aller Stellen aus lists (je Feld
// [{ label, url }]), jede einmal, in der Reihenfolge, in der sie zuerst vorkommen.
export function measureUrls(lists) {
  const urls = [];
  lists.forEach(function (list) {
    list.forEach(function (place) { if (urls.indexOf(place.url) !== -1) return; urls.push(place.url); });
  });
  return urls;
}

// Stellen des Feldes index aus seiner Liste list und den Messungen measured (Adresse → je Feld eine Liste von Rahmen):
// [{ label, frames }], Stellen ohne Rahmen fallen weg.
export function fieldPlaces(list, measured, index) {
  return list.map(function (place) {
    return { label: place.label, frames: (measured[place.url] || [])[index] || [] };
  }).filter(function (place) { return place.frames.length > 0; });
}

// Ist eine Messung gelungen? lists je Element die Rahmen wie von measureAll (mit key der Breite), keys die gemessenen
// Breiten: Jede Breite hat bei mindestens einem Element einen Rahmen (scheitert oder läuft eine ab, fehlt sie bei allen).
// Ohne Elemente gelungen.
export function everyWidthMeasured(lists, keys) {
  if (!lists.length) return true;
  return keys.every(function (key) {
    return lists.some(function (frames) { return frames.some(function (frame) { return frame.key === key; }); });
  });
}

// Namen als Aufzählung: „A“, „A und B“, „A, B und C“ (Trenner comma, vor dem letzten and).
export function joinNames(names, comma, and) {
  if (names.length < 2) return names.join('');
  return names.slice(0, -1).join(comma) + and + names[names.length - 1];
}

// Ebenen einer CSS-Liste (berechnetes background-image, background-size), getrennt an Kommas außerhalb von
// Klammern und Strings (url("a,b"), linear-gradient(…, …)).
function cssLayers(value) {
  const layers = [];
  let depth = 0;
  let quote = '';
  let start = 0;
  for (let i = 0; i < value.length; i++) {
    const ch = value[i];
    if (quote) {
      if (ch === '\\') i++;
      else if (ch === quote) quote = '';
    } else if (ch === '"' || ch === '\'') {
      quote = ch;
    } else if (ch === '(') {
      depth++;
    } else if (ch === ')') {
      depth = Math.max(0, depth - 1);
    } else if (ch === ',' && depth === 0) {
      layers.push(value.slice(start, i).trim());
      start = i + 1;
    }
  }
  layers.push(value.slice(start).trim());
  return layers;
}

// Wert der Ebene index aus einer CSS-Liste; ist sie kürzer, wiederholt sie sich wie im Browser.
function layerValue(value, index) {
  const layers = cssLayers(value);
  return layers[index % layers.length];
}
