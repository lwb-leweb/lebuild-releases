// Knopf-Bausteine des Seiten-Editors und das leere Element, aus dem die Bausteine ihre Teile bauen, ohne Abhängigkeiten
// (auch für richtext.js im Backend); bar.js gibt sie weiter.

// Element tag mit Klasse className und Text text (beides optional), gebaut per DOM.
export function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text) node.textContent = text;
  return node;
}

// Knopf des Editors (Leiste, Dialoge, Panels, Knöpfe am Element); className aus bar.css und ui/overlay/panel/form.css.
export function editorButton(label, className, onClick) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = className;
  button.textContent = label;
  button.addEventListener('click', onClick);
  return button;
}

// Knopf, der beim Drücken die Auswahl in einem gerade bearbeiteten Text stehen lässt (Mini-Leiste, Knöpfe am Element).
export function keepSelection(button) {
  button.addEventListener('mousedown', function (event) { event.preventDefault(); });
  return button;
}
