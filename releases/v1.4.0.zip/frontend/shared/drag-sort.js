import { icon, symbolButton } from './icons.js';
import { element } from './buttons.js';
import { DRAG_HOLD, FLIP_DURATION, FLIP_EASING, HOLD, clipLine, dropIndex, dropPlace, edgeScroll, flipDelta, visiblePart, holdState, keyStep, pastSlop, revealStep, stepIndex, wheelStep } from './drag-geometry.js';

// Ziehen zum Sortieren, ein Baustein für Seiten-Editor und Verwaltung (Listen auf der Seite, Zeilen, Blöcke, Bildraster).
// Während des Ziehens bleibt das Layout stehen: das gezogene Element blass an seinem Platz (vorübergehender Stil, danach wie
// vorher), Linie an der Einfügestelle und Kopie am Zeiger in einer eigenen Ebene über allem; neu geordnet wird erst beim
// Loslassen (onDrop), danach gleiten die Elemente an ihren Platz. Regeln und Grenzen in drag-geometry.js, Aussehen in
// drag-sort.css.

export const DRAG_TEXT = {
  handle: 'Ziehen zum Sortieren',
  // Ansage für Screenreader nach dem Verschieben, z. B. „Foto 3 von 7“.
  position: '{label} {position} von {count}'
};

const CLASSES = {
  handle: 'le-drag-handle',
  layer: 'le-drag-layer',
  line: 'le-drag-line',
  lineVertical: 'le-drag-line le-drag-line--vertical',
  ghost: 'le-drag-ghost',
  ghostImage: 'le-drag-ghost le-drag-ghost--image',
  status: 'le-drag-status'
};
// Selektor der Ziehpunkte aus dragHandle, für die Option handle.
export const DRAG_HANDLE = '.' + CLASSES.handle;
// Ereignisse, die schon ein Baustein übernommen hat: Liegt ein sortierbarer Bereich in einem anderen (Bildraster in einem
// Block), zieht bzw. verschiebt nur der innerste.
const claimed = new WeakSet();
// Blässe des gezogenen Elements an seinem Platz (gegen Regeln der Website mit !important), aus dem Token.
const SOURCE_TOKEN = '--le-drag-source-opacity';
const SOURCE_STYLE = { name: 'opacity', value: 'var(' + SOURCE_TOKEN + ')', priority: 'important' };
const REDUCED_MOTION = '(prefers-reduced-motion: reduce)';
// Ohne eigenen Ziehpunkt beginnt hier kein Ziehen und keine Taste verschiebt: Texteingaben bleiben bedienbar.
const TEXT_INPUTS = 'input, textarea, select, [contenteditable]';
const SCROLLING = ['auto', 'scroll', 'overlay'];
// Bild für die Kopie am Zeiger (ghostOf).
const IMAGE = 'img';
const PRIMARY_BUTTON = 0;
const TOUCH = 'touch';
const MOUSE = 'mouse';
const ESCAPE = 'Escape';
// Finger und Mausrad dürfen beim Ziehen die Seite nicht selbst scrollen (touchmove und wheel nur so abzufangen).
const BLOCKING_LISTEN = { capture: true, passive: false };

// Ziehpunkt (Symbol grip) für einen Kopf oder Chip; className aus dem Look des Gastgebers.
export function dragHandle(className) {
  return symbolButton('grip', DRAG_TEXT.handle, (className ? className + ' ' : '') + CLASSES.handle, null);
}

// „Foto 3 von 7“: Stelle index (ab 0) von count Elementen mit dem Namen label (Ansage, Popover der Galerie-Vorschau).
export function positionText(label, index, count) {
  return DRAG_TEXT.position.replace('{label}', function () { return label; }).replace('{position}', String(index + 1)).replace('{count}', String(count));
}

// Gleiten (FLIP) des Elements vom Rechteck before an seinen Platz after (Rechtecke im Fenster bzw. im selben Bezug), nicht
// bei prefers-reduced-motion; ohne Rückstand am Element (Element.animate). scale (optional) wie bei flipDelta: Element in
// einem verkleinerten Rahmen (Vorschau der Galerie, die nach dem Umordnen neu rendert und dann selbst gleiten lässt).
// Liefert ein Promise, erfüllt am Ende des Gleitens (abgebrochen zählt als Ende), ohne Gleiten sofort: Wer Rechtecke
// misst, wartet darauf, sonst zählt der Versatz mit.
export function glide(element, before, after, scale) {
  const delta = window.matchMedia(REDUCED_MOTION).matches ? null : flipDelta(before, after, scale);
  if (!delta) return Promise.resolve();
  const ended = function () { /* zu Ende oder abgebrochen */ };
  return element.animate(flipFrames(delta), { duration: FLIP_DURATION, easing: FLIP_EASING }).finished.then(ended, ended);
}

// Setzt am Element einen Stil für die Dauer des Ziehens; die Funktion, die es zurückgibt, stellt ihn wie vorher her
// (ohne style-Attribut bleibt keins zurück).
export function holdStyle(element, name, value, priority) {
  const hadStyle = element.hasAttribute('style');
  const before = element.style.getPropertyValue(name);
  const beforePriority = element.style.getPropertyPriority(name);
  element.style.setProperty(name, value, priority);
  return function () {
    if (before) element.style.setProperty(name, before, beforePriority);
    else element.style.removeProperty(name);
    if (!hadStyle && !element.getAttribute('style')) element.removeAttribute('style');
  };
}

// container: Element um die sortierbaren Elemente. options:
// - items(): die Elemente in ihrer Reihenfolge (jedes Mal neu gefragt);
// - onDrop(from, to, glided): Element von Index from nach to (Index danach); der Gastgeber ordnet um, dann gleitet es,
//   glided ist das Ende des Gleitens (Promise, ohne Gleiten gleich erfüllt);
// - label(item): Name für die Ansage („Foto“ → „Foto 3 von 7“);
// - handle (optional): Selektor des Ziehpunkts im Element, sonst das ganze Element ohne seine Texteingaben;
// - layer (optional): wohin Linie, Kopie und Ansage kommen, sonst body bzw. der Shadow-Root des containers; für eine Liste
//   der Kundenseite der Shadow-Root des Editors (die Ebene nimmt den Zeiger selbst, auch unter einem Host ohne Zeiger);
// - rectOf(item) (optional): Rechteck im Fenster, sonst getBoundingClientRect (Elemente in einem skalierten Rahmen);
// - external (optional): true = nur über begin und key gesteuert, kein Zuhörer an container (Liste der Kundenseite mit
//   Ziehpunkt in der Ebene des Editors);
// - scrollFrom() (optional): Element, ab dem beim Ziehen die scrollbaren Bereiche gesucht werden, sonst container (der
//   Gastgeber tauscht das Element um die sortierbaren aus, z. B. eine Liste der Kundenseite beim Neuladen).
// Liefert { begin(event, item), key(event, item), dispose() }: begin und key für einen Ziehpunkt außerhalb von container
// (pointerdown bzw. keydown daran), dispose löst alles.
export function dragSort(container, options) {
  const rectOf = options.rectOf || function (item) { return item.getBoundingClientRect(); };
  let session = null;
  // Ansage dieser Instanz, beim ersten Verschieben angelegt, mit dispose() weg.
  let status = null;

  const layerParent = function () {
    if (options.layer) return options.layer;
    const root = container.getRootNode();
    return root.body || root;
  };
  const itemOf = function (target) {
    return options.items().find(function (item) { return item.contains(target); }) || null;
  };
  // Darf an target (im Element item) gezogen bzw. per Taste verschoben werden?
  const startsAt = function (target, item) {
    if (options.handle) {
      const handle = target.closest(options.handle);
      return Boolean(handle && item.contains(handle));
    }
    const input = target.closest(TEXT_INPUTS);
    return !(input && item.contains(input));
  };

  // Der Druck bleibt, was er ohne Baustein wäre (Fokus, Klick); Textauswahl und Ziehen des Browsers verhindert block.
  const begin = function (event, item) {
    if (session || (event.pointerType !== TOUCH && event.button !== PRIMARY_BUTTON)) return;
    const start = { x: event.clientX, y: event.clientY };
    session = { item: item, id: event.pointerId, touch: event.pointerType === TOUCH, mouse: event.pointerType === MOUSE, at: event.timeStamp, start: start, point: start, active: false, timer: null, frame: null, place: null };
    if (session.touch) {
      const waiting = session;
      waiting.timer = setTimeout(function () {
        if (session === waiting && holdState(DRAG_HOLD, waiting.start, waiting.point) === HOLD.drag && activate()) track();
      }, DRAG_HOLD);
    }
    listen(true);
  };

  const onMove = function (event) {
    if (event.pointerId !== session.id) return;
    // Maustaste außerhalb losgelassen, ohne dass pointerup ankam: abbrechen statt beim nächsten Klick ablegen.
    if (session.mouse && !event.buttons) {
      end(false, false);
      return;
    }
    session.point = { x: event.clientX, y: event.clientY };
    if (!session.active) {
      const phase = session.touch ? holdState(event.timeStamp - session.at, session.start, session.point) : pastSlop(session.start, session.point) ? HOLD.drag : HOLD.wait;
      if (phase === HOLD.scroll) end(false, false);
      if (phase !== HOLD.drag || !activate()) return;
    }
    track();
  };
  const onUp = function (event) {
    if (event.pointerId === session.id) end(true, true);
  };
  const onCancel = function (event) {
    if (event.pointerId === session.id) end(false, false);
  };
  // Fenster verlassen (Alt+Tab, anderer Tab): abbrechen.
  const onBlur = function () { end(false, false); };
  // Gescrollt (Mausrad, Tastatur, Mitscrollen): Linie nachführen.
  const onScroll = function () {
    if (session && session.active) place();
  };
  // Esc bricht ab, bevor Panel, Modal oder Ebene es bekommen.
  const onEscape = function (event) {
    if (event.key !== ESCAPE || !session.active) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    end(false, false);
  };
  const onTouchMove = function (event) {
    if (session.active) event.preventDefault();
  };
  // Mausrad über der Ebene: an den innersten der Bereiche um container unter dem Zeiger, der in die Richtung noch kann
  // (sonst das Fenster). Strg+Rad (Zoom, auch Zwei-Finger-Zoom am Trackpad) bleibt dem Browser.
  const onWheel = function (event) {
    if (!session.active || event.ctrlKey) return;
    event.preventDefault();
    if (scrollWheel(session.areas, session.point, event)) place();
  };
  // Textauswahl, Ziehen des Browsers und Menü beim langen Drücken, solange gedrückt ist.
  const block = function (event) { event.preventDefault(); };
  const listen = function (on) {
    const method = on ? 'addEventListener' : 'removeEventListener';
    window[method]('pointermove', onMove, true);
    window[method]('pointerup', onUp, true);
    window[method]('pointercancel', onCancel, true);
    window[method]('keydown', onEscape, true);
    window[method]('touchmove', onTouchMove, BLOCKING_LISTEN);
    window[method]('wheel', onWheel, BLOCKING_LISTEN);
    window[method]('blur', onBlur);
    // Auch am container: Ereignisse aus einem Shadow-Root kommen nicht alle bis zum window.
    ['selectstart', 'dragstart', 'contextmenu'].forEach(function (type) {
      window[method](type, block, true);
      if (!options.external) container[method](type, block);
    });
  };

  // Liefert false, wenn das Element nicht mehr in der Liste steht (neu geladen, fremdes Element): dann abgebrochen.
  const activate = function () {
    const s = session;
    s.items = options.items();
    s.from = s.items.indexOf(s.item);
    if (s.from === -1) {
      end(false, false);
      return false;
    }
    s.active = true;
    s.areas = scrollAreas(options.scrollFrom ? options.scrollFrom() : container);
    s.scrollers = s.areas.map(function (area) { return area === document.scrollingElement ? window : area; });
    s.scrollers.forEach(function (target) { target.addEventListener('scroll', onScroll); });
    s.layer = element('div', CLASSES.layer);
    s.line = element('div', CLASSES.line);
    s.line.hidden = true;
    s.ghost = ghostOf(s.item, options.label(s.item));
    // Linie über der Kopie: Die Kopie am Zeiger verdeckt sonst die Einfügestelle.
    s.layer.append(s.ghost, s.line);
    layerParent().appendChild(s.layer);
    s.restore = holdStyle(s.item, SOURCE_STYLE.name, sourceValue(s.item, s.layer), SOURCE_STYLE.priority);
    // Alle weiteren Ereignisse des Zeigers an die Ebene (auch außerhalb des Fensters, am Touchgerät statt am Ziehpunkt).
    s.layer.setPointerCapture(s.id);
    return true;
  };
  // Kopie an den Zeiger, Linie an die Einfügestelle, Mitscrollen am Rand.
  const track = function () {
    session.ghost.style.left = session.point.x + 'px';
    session.ghost.style.top = session.point.y + 'px';
    place();
    if (!session.frame) session.frame = requestAnimationFrame(scrollFrame);
  };
  const place = function () {
    const s = session;
    const found = dropPlace(s.point, s.items.map(rectOf), s.from);
    // Nur im Teil, der in allen Bereichen zu sehen ist (Vorschau in einem Panel: nicht unter dessen Kopf oder Fuß).
    const line = found && clipLine(found.line, visiblePart(s.areas.map(boxOf)));
    // Ohne sichtbare Linie (zu weit, neben sich selbst, weggescrollt) bricht Loslassen ab.
    s.place = line ? found : null;
    s.line.hidden = !line;
    if (!line) return;
    s.line.className = line.vertical ? CLASSES.lineVertical : CLASSES.line;
    s.line.style.left = line.x + 'px';
    s.line.style.top = line.y + 'px';
    s.line.style.width = line.vertical ? '' : line.length + 'px';
    s.line.style.height = line.vertical ? line.length + 'px' : '';
  };
  const scrollFrame = function () {
    session.frame = null;
    if (scrollAtEdge(session.areas, session.point)) place();
    session.frame = requestAnimationFrame(scrollFrame);
  };

  // dropped: Loslassen (der Klick danach gehört nicht dem Element darunter); commit: an der Einfügestelle ablegen.
  const end = function (commit, dropped) {
    const s = session;
    session = null;
    clearTimeout(s.timer);
    if (s.frame) cancelAnimationFrame(s.frame);
    listen(false);
    if (!s.active) return;
    s.scrollers.forEach(function (target) { target.removeEventListener('scroll', onScroll); });
    s.layer.remove();
    s.restore();
    if (dropped) swallowClick();
    if (commit && s.place) move(s.items, s.from, dropIndex(s.from, s.place.index), null);
  };

  // Umordnen über den Gastgeber, Gleiten (FLIP) und Ansage; focused behält den Fokus (Alt+Pfeil). onDrop bekommt das Ende
  // des Gleitens als Promise (glide), schon bevor es beginnt.
  const move = function (items, from, to, focused) {
    const before = items.map(rectOf);
    let ended = null;
    options.onDrop(from, to, new Promise(function (resolve) { ended = resolve; }));
    if (focused && focused.isConnected && focused.getRootNode().activeElement !== focused) focused.focus({ preventScroll: true });
    const glides = [];
    items.forEach(function (item, index) {
      if (item.isConnected) glides.push(glide(item, before[index], rectOf(item)));
    });
    ended(Promise.all(glides));
    announce(items[from], to, options.items().length);
  };

  const key = function (event, item) {
    const step = keyStep(event.key, event.altKey);
    const items = options.items();
    const from = items.indexOf(item);
    if (session || !step || from === -1) return false;
    event.preventDefault();
    const to = stepIndex(from, step, items.length);
    // Am Rand bleibt alles, die Ansage nennt die Stelle.
    if (to === null) announce(item, from, items.length);
    else move(items, from, to, event.target);
    return true;
  };

  const announce = function (item, index, count) {
    if (!status) {
      status = element('div', CLASSES.status);
      status.setAttribute('role', 'status');
      status.setAttribute('aria-live', 'polite');
      layerParent().appendChild(status);
    }
    const shown = status;
    const text = positionText(options.label(item), index, count);
    // Erst leeren, im nächsten Bild setzen: So wird auch derselbe Text noch einmal angesagt.
    shown.textContent = '';
    requestAnimationFrame(function () { shown.textContent = text; });
  };

  const onPointerDown = function (event) {
    const item = claimed.has(event) ? null : itemOf(event.target);
    if (!item || !startsAt(event.target, item)) return;
    claimed.add(event);
    begin(event, item);
  };
  const onKeyDown = function (event) {
    const item = claimed.has(event) ? null : itemOf(event.target);
    if (item && startsAt(event.target, item) && key(event, item)) claimed.add(event);
  };
  if (!options.external) {
    container.addEventListener('pointerdown', onPointerDown);
    container.addEventListener('keydown', onKeyDown);
  }

  return {
    begin: begin,
    key: key,
    dispose: function () {
      if (session) end(false, false);
      if (status) status.remove();
      status = null;
      container.removeEventListener('pointerdown', onPointerDown);
      container.removeEventListener('keydown', onKeyDown);
    }
  };
}

// Wert der Blässe für item: das Token; ein Element in einem anderen Dokument (Seite im Rahmen der Galerie-Vorschau) kennt die
// Token nicht und bekommt den Wert, der an der Ebene layer gilt.
function sourceValue(item, layer) {
  if (!item.ownerDocument || item.ownerDocument === document) return SOURCE_STYLE.value;
  return window.getComputedStyle(layer).getPropertyValue(SOURCE_TOKEN).trim();
}

// Kopie am Zeiger, klein und mit festen Kosten (unabhängig davon, wie groß das Element ist): das erste Bild des Elements
// (oder es selbst, ein Bild als Karte der Galerie-Vorschau) im Seitenverhältnis, wie es dasteht, sonst Ziehpunkt und Name
// (label). Nichts vom Element selbst (kein Klon, keine Formularfelder), Aussehen aus drag-sort.css.
function ghostOf(item, label) {
  const image = item.matches(IMAGE) ? item : item.querySelector(IMAGE);
  // Nur ein geladenes Bild; leeres src (image.src wäre die Adresse der Seite), noch nicht geladen oder kaputt: das Schild.
  const source = image && image.complete && image.naturalWidth ? image.currentSrc : '';
  const ghost = element('div', source ? CLASSES.ghostImage : CLASSES.ghost);
  ghost.setAttribute('aria-hidden', 'true');
  if (source) {
    const copy = document.createElement('img');
    copy.src = source;
    copy.alt = '';
    const shown = image.getBoundingClientRect();
    if (shown.width && shown.height) copy.style.aspectRatio = shown.width + ' / ' + shown.height;
    ghost.appendChild(copy);
    return ghost;
  }
  const name = document.createElement('span');
  name.textContent = label;
  ghost.append(icon('grip'), name);
  return ghost;
}

// Der Klick nach dem Loslassen gehört nicht dem Element darunter (er folgt pointerup in derselben Aufgabe).
function swallowClick() {
  const swallow = function (event) {
    event.preventDefault();
    event.stopImmediatePropagation();
  };
  window.addEventListener('click', swallow, true);
  setTimeout(function () { window.removeEventListener('click', swallow, true); }, 0);
}

function flipFrames(delta) {
  return [
    { transformOrigin: 'top left', transform: 'translate(' + delta.dx + 'px, ' + delta.dy + 'px) scale(' + delta.sx + ', ' + delta.sy + ')' },
    { transformOrigin: 'top left', transform: 'none' }
  ];
}

// Scrollbare Bereiche um container, der innerste zuerst (auch über einen Shadow-Root hinaus), zuletzt das Fenster.
function scrollAreas(container) {
  const page = document.scrollingElement;
  const areas = [];
  let node = container;
  while (node && node !== page) {
    const style = window.getComputedStyle(node);
    if ((SCROLLING.indexOf(style.overflowY) !== -1 && node.scrollHeight > node.clientHeight) || (SCROLLING.indexOf(style.overflowX) !== -1 && node.scrollWidth > node.clientWidth)) areas.push(node);
    node = node.parentElement || node.getRootNode().host || null;
  }
  areas.push(page);
  return areas;
}

// Sichtbare Teile (Rechtecke im Fenster) der scrollbaren Bereiche um element, samt element, falls es selbst scrollt,
// der innerste zuerst, zuletzt das Fenster: Was in allen liegt, ist zu sehen (Popover der Galerie-Vorschau).
export function visibleBoxes(element) {
  return scrollAreas(element).map(boxOf);
}

// Sichtbarer Teil eines scrollbaren Bereichs im Fenster.
function boxOf(area) {
  if (area === document.scrollingElement) return { left: 0, top: 0, right: window.innerWidth, bottom: window.innerHeight };
  return area.getBoundingClientRect();
}

// Scrollt den innersten Bereich, der um stepOf(area, index) ({ x, y }) noch kann; true, wenn einer scrollte.
function scrollFirst(areas, stepOf) {
  return areas.some(function (area, index) {
    const step = stepOf(area, index);
    const x = canScroll(step.x, area.scrollLeft, area.clientWidth, area.scrollWidth) ? step.x : 0;
    const y = canScroll(step.y, area.scrollTop, area.clientHeight, area.scrollHeight) ? step.y : 0;
    if (!x && !y) return false;
    area.scrollBy(x, y);
    return true;
  });
}

// Mitscrollen: am Rand des Bereichs, an dem point liegt (edgeScroll); ein äußerer nur, bis der innere darin ganz zu sehen
// ist (revealStep).
function scrollAtEdge(areas, point) {
  return scrollFirst(areas, function (area, index) {
    const step = edgeScroll(point, boxOf(area));
    return index ? revealStep(step, areas[index - 1].getBoundingClientRect(), boxOf(area)) : step;
  });
}

// Mausrad über der Ebene (wheelStep): im innersten Bereich unter point.
function scrollWheel(areas, point, wheel) {
  return scrollFirst(areas, function (area) { return wheelStep(point, boxOf(area), wheel); });
}

function canScroll(step, offset, client, total) {
  return step < 0 ? offset > 0 : step > 0 && offset + client < total;
}
