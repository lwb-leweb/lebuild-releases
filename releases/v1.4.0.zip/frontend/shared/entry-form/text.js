// Texte des Formulars und Namen eines Eintrags (Titelfeld, Anzeigename, Titel einer Kopie, Rückfrage beim Löschen).

export const ENTRY_TEXT = {
  add: 'Neu',
  edit: 'Bearbeiten',
  // Kopieren eines Eintrags (Knopf auf der Seite und in der Verwaltung) und Titel des Formulars der Kopie (copyTitle).
  copy: 'Kopieren',
  copyTitle: 'Kopie: {name}',
  save: 'Speichern',
  cancel: 'Abbrechen',
  untitled: '(ohne Titel)',
  // Speichern mit veraltetem Stand (409 conflict, plugin_entry_conflict_check): Rückfrage im Backend-Modal.
  conflictPanel: 'Jemand anderes hat diesen Eintrag gespeichert, seit du ihn geöffnet hast. Deine Fassung überschreibt die andere ganz.',
  conflictAsk: 'Jemand anderes hat diesen Eintrag inzwischen geändert.\n\nOK: deine Fassung speichern (überschreibt die andere).\nAbbrechen: nichts speichern.',
  conflictTheirs: 'Stattdessen die andere Fassung ins Formular laden? Deine Eingaben gehen dabei verloren.',
  // Ebene „Ausschnitt“ mit Änderungen schließen (×, Esc, Klick daneben), Rückfrage im Backend-Modal.
  framingDiscard: 'Änderungen am Ausschnitt verwerfen?',
  emptyOption: '—',
  deleteQuestion: '‚{name}‘ löschen?',
  remove: 'Entfernen',
  richtextRequired: '„{name}“ bitte ausfüllen.',
  addRow: '+ {name} hinzufügen',
  addRowFallback: '+ Zeile hinzufügen',
  addOption: '+ {name} hinzufügen',
  addOptionPrompt: '{name} hinzufügen:',
  // Name einer Zeile ohne itemLabel in der Ansage beim Sortieren („Zeile 2 von 3“).
  row: 'Zeile',
  slugEdit: 'Adresse ändern',
  slugAuto: 'entsteht beim Speichern aus „{name}“',
  addImages: '+ {name} hinzufügen',
  imagesUploaded: '{count} Bilder hochgeladen.',
  imageReplace: 'Bild ersetzen',
  imageMissing: 'Bild wählen',
  otherFile: 'Anderes PDF',
  fileOpen: 'Datei in neuem Tab öffnen',
  imageUploading: 'Lädt …',
  imageRemove: 'Bild entfernen',
  imagesTooMany: 'Höchstens {max} {name}; die übrigen Dateien sind nicht hochgeladen.',
  addBlock: '+ {name}',
  blockCollapse: 'Einklappen',
  blockExpand: 'Aufklappen',
  blockImages: '{count} Fotos',
  blockFiles: '{count} Downloads',
  blockRemove: 'Block entfernen',
  // Vorschau der Galerie im Seitenpanel (gallery-preview.js): Umschalter der Breiten samt Breite der Galerie, Hinweise.
  previewWidths: 'Breite der Vorschau',
  previewPx: '{width} px',
  previewLoading: 'Die Vorschau der Seite lädt …',
  previewFailed: 'Die Vorschau der Seite lässt sich nicht laden. Die Fotos lassen sich unten im Raster bearbeiten.',
  // Bedienung in der Vorschau (gallery-controls.js): leere Galerie, Popover an einem Foto („Foto 3 von 7 · Hochformat 2:3“).
  previewEmpty: 'Noch keine {name}. Besucher sehen an dieser Stelle nichts.',
  replace: 'Ersetzen',
  photoTitle: '{position} · {shape}',
  photoRatio: '{shape} {width}:{height}',
  // Formen aus photoShape (PHOTO_SHAPES in preview-rules.js).
  photoShapes: { square: 'Quadrat', landscape: 'Querformat', portrait: 'Hochformat' }
};
// Felder, die einen Eintrag benennen (vor dem ersten Textfeld).
const TITLE_FIELDS = ['name', 'title'];
const TITLE_FALLBACK_TYPE = 'text';

// Beschriftung eines Feldes: label aus dem Schema, sonst sein Name.
export function fieldLabel(field) {
  return field.label ? field.label : field.name;
}

// Feld, das einen Eintrag benennt: name oder title, sonst das erste Textfeld (null ohne).
export function titleField(schema) {
  const named = schema.find(function (field) { return TITLE_FIELDS.indexOf(field.name) !== -1; });
  if (named) return named.name;
  const text = schema.find(function (field) { return field.type === TITLE_FALLBACK_TYPE; });
  return text ? text.name : null;
}

// Anzeigename eines Eintrags (Listen im Backend, Nachfrage beim Löschen).
export function entryTitle(schema, row) {
  const name = titleField(schema);
  if (!name) return '#' + row.id;
  return row[name] ? String(row[name]) : ENTRY_TEXT.untitled;
}

// „‚Max Muster‘ löschen?“ – als Text für confirm(), nie als HTML.
export function deleteQuestion(schema, row) {
  // Ersatz als Funktion: „$&“ o. Ä. im Namen bleibt wörtlich stehen.
  const title = entryTitle(schema, row);
  return ENTRY_TEXT.deleteQuestion.replace('{name}', function () { return title; });
}

// „Kopie: Max Muster“ – Titel des Formulars einer Kopie, Name aus dem Original (ohne Titelfeld „Kopie: #12“).
export function copyTitle(schema, row) {
  const title = entryTitle(schema, row);
  return ENTRY_TEXT.copyTitle.replace('{name}', function () { return title; });
}

// Überschrift des Popovers an einem Foto: position („Foto 3 von 7“, positionText) und Form aus photoShape (null: noch
// nicht geladen, dann nur die Stelle), z. B. „Foto 3 von 7 · Hochformat 2:3“.
export function photoTitle(position, shape) {
  if (!shape) return position;
  const name = ENTRY_TEXT.photoShapes[shape.shape];
  const text = shape.ratio ? ENTRY_TEXT.photoRatio.replace('{shape}', name).replace('{width}', String(shape.ratio[0])).replace('{height}', String(shape.ratio[1])) : name;
  return ENTRY_TEXT.photoTitle.replace('{position}', function () { return position; }).replace('{shape}', text);
}
