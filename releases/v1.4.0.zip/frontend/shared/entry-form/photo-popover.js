import { editorButton, element } from '../buttons.js';
import { framingSource, FRAMING_TEXT } from '../image-framing.js';
import { ENTRY_TEXT, fieldLabel } from './text.js';
import { popoverPlace } from './preview-rules.js';

// Popover an einem Foto der Galerie-Vorschau (gallery-controls.js), über dem Eintragsformular in der Fläche der Vorschau
// (frontend/rules.md, Ausnahme): oben „Foto 3 von 7 · Hochformat 2:3“, darin die Textfelder der Zeile, „Ersetzen“,
// „Ausschnitt“ (nur mit framingSource) und „Entfernen“. Die Textfelder sind dieselben Eingaben wie in der Kachel des
// Rasters: Solange das Popover offen ist, stehen sie hier (input geht weiter ans Formular), danach wieder in der Kachel.
// Ersetzen und Ausschnitt laufen über die Zeile (row.pick, row.frame: imagePicker, openImageFraming).

// Abstand des Popovers zum Foto und zum Rand der Vorschau.
const GAP_VAR = '--le-space-2';

// options: { row (Zeile des Rasters), host (Fläche der Vorschau, Bezug der Lage), look (Klassen, look.preview),
// onRemove() }. Liefert { row, element, update(title), place(anchor, view) (Rechtecke im Fenster: Foto, sichtbarer Teil
// der Vorschau, popoverPlace), focus(), close() (Textfelder zurück in die Kachel) }.
export function photoPopover(options) {
  const look = options.look;
  const row = options.row;
  const box = element('div', look.popover);
  box.setAttribute('role', 'dialog');
  const title = element('div', look.popoverTitle);
  const body = element('div', look.popoverBody);
  // Die Textfelder stehen in der Kachel hintereinander: zurück vor das, was danach kam.
  const inputs = row.captions.map(function (caption) { return caption.input; });
  const home = inputs.length ? { parent: inputs[0].parentNode, next: inputs[inputs.length - 1].nextSibling } : null;
  row.captions.forEach(function (caption) {
    const label = element('label', look.popoverField);
    const name = element('span', look.popoverLabel);
    name.textContent = fieldLabel(caption.field);
    label.append(name, caption.input);
    body.appendChild(label);
  });
  const actions = element('div', look.popoverActions);
  const replace = editorButton(ENTRY_TEXT.replace, look.popoverButton, function () { row.pick(); });
  const crop = editorButton(FRAMING_TEXT.title, look.popoverButton, function () { row.frame(crop); });
  actions.append(replace, crop, editorButton(ENTRY_TEXT.remove, look.popoverButton, options.onRemove));
  box.append(title, body, actions);
  options.host.appendChild(box);

  return {
    row: row,
    element: box,
    update: function (text) {
      title.textContent = text;
      box.setAttribute('aria-label', text);
      crop.hidden = !framingSource(row.image);
    },
    place: function (anchor, view) {
      const gap = parseFloat(window.getComputedStyle(box).getPropertyValue(GAP_VAR));
      const at = popoverPlace(anchor, { width: box.offsetWidth, height: box.offsetHeight }, view, gap);
      const base = options.host.getBoundingClientRect();
      box.style.left = (at.left - base.left) + 'px';
      box.style.top = (at.top - base.top) + 'px';
    },
    focus: function () {
      (body.querySelector('input') || replace).focus({ preventScroll: true });
    },
    close: function () {
      if (home) inputs.forEach(function (input) { home.parent.insertBefore(input, home.next); });
      box.remove();
    }
  };
}
