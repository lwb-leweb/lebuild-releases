import { filePicker, draggingFiles, uploadPending } from '../upload.js';
import { editorButton } from '../buttons.js';
import { iconGrid, ICON_TEXT } from '../icon-grid.js';
import { symbolButton } from '../icons.js';
import { errorNotice, editorPost } from '../request.js';
import { framingField, mountFraming, openFramingLayer } from '../image-framing.js';
import { ENTRY_TEXT, fieldLabel } from './text.js';

// Eingabe eines einzelnen Feldes: Feldart → Eingabefeld, Auswahl samt „+ hinzufügen“, Bild, Datei (PDF), Icon,
// Adresse (slug) und was Zeilen, Blöcke und Bildraster teilen (Ausschnitt, Fokuspunkt).

// Feldart → type des <input>; alle übrigen Arten (text, slug, …) sind Textfelder.
export const INPUT_TYPES = {
  number: 'number',
  datetime: 'datetime-local',
  date: 'date'
};
export const INPUT_TYPE_TEXT = 'text';

// Feldart → inputmode (Tastatur am Handy); geprüft wird die Adresse auf dem Server.
export const INPUT_MODES = {
  url: 'url'
};

// Wert für das Eingabefeld: Datum aus der Datenbank („2026-10-15 09:30:00“) für datetime-local.
export function formatInputValue(field, value) {
  if (field.type === 'datetime' && value) {
    return String(value).replace(' ', 'T').slice(0, 16);
  }
  return value == null ? '' : String(value);
}

export function fieldBox(look, field, tag) {
  const box = document.createElement(tag);
  box.className = look.field;
  const label = document.createElement(look.labelTag);
  if (look.label) label.className = look.label;
  label.textContent = fieldLabel(field);
  box.appendChild(label);
  return box;
}

// Wert der Option „+ … hinzufügen“: Steuerzeichen, die in keinem gespeicherten Wert vorkommen (sanitize_plain_text).
const CREATE_OPTION_VALUE = '\u0000create';

// Auswahl: Wert ist die Option, angezeigt wird ihre Beschriftung aus optionLabels, sonst die Option selbst.
// Mit optionsCreate (Content-Typen, optionsFrom) kommt „+ <Feld> hinzufügen“ dazu (createOption).
export function selectInput(field, value, notify) {
  const select = document.createElement('select');
  if (!field.required) select.add(new Option(ENTRY_TEXT.emptyOption, ''));
  const labels = field.optionLabels && typeof field.optionLabels === 'object' ? field.optionLabels : {};
  (Array.isArray(field.options) ? field.options : []).forEach(function (option) {
    if (typeof option !== 'string') return;
    select.add(new Option(Object.prototype.hasOwnProperty.call(labels, option) ? labels[option] : option, option));
  });
  const create = field.optionsCreate && typeof field.optionsCreate === 'object' ? new Option('', CREATE_OPTION_VALUE) : null;
  if (create) select.add(create);
  select.value = value;
  // Pflichtfeld ohne passende Option: nichts gewählt (der Browser meldet es), nie „+ … hinzufügen“.
  if (select.value === CREATE_OPTION_VALUE) select.selectedIndex = -1;
  if (create) createOption(field, select, create, notify);
  return select;
}

// „+ <Feld> hinzufügen“ am Ende der Auswahl: fragt nach dem Namen, legt ihn als Eintrag im anderen Typ an
// (optionsCreate: { url, type, field }) und wählt ihn. Gibt es ihn schon, wird er nur gewählt; abgebrochen
// oder fehlgeschlagen (Hinweis über notify) gilt wieder die vorige Auswahl.
function createOption(field, select, option, notify) {
  const create = field.optionsCreate;
  const name = fieldLabel(field);
  const fill = function (text) { return text.replace('{name}', function () { return name; }); };
  option.text = fill(ENTRY_TEXT.addOption);
  let previous = select.value;
  // Wert wählen; gibt es ihn nicht (leer bei Pflicht), ist nichts gewählt.
  const choose = function (value) {
    select.value = value;
    if (select.value !== value) select.selectedIndex = -1;
    previous = select.value;
  };
  select.addEventListener('change', function () {
    if (select.value !== CREATE_OPTION_VALUE) {
      previous = select.value;
      return;
    }
    choose(previous);
    const text = (window.prompt(fill(ENTRY_TEXT.addOptionPrompt)) || '').trim();
    if (!text) return;
    if (Array.prototype.some.call(select.options, function (entry) { return entry !== option && entry.value === text; })) {
      choose(text);
      return;
    }
    const data = {};
    data[create.field] = text;
    select.disabled = true;
    editorPost(create.url, { type: create.type, data: data }).then(function () {
      select.insertBefore(new Option(text, text), option);
      choose(text);
      select.dispatchEvent(new Event('input', { bubbles: true }));
    }).catch(function (error) {
      const notice = errorNotice(error);
      if (notify) notify(notice.message, notice.action);
    }).finally(function () {
      select.disabled = false;
      select.focus();
    });
  });
}

// Gespeicherter Fokuspunkt des Feldes field in values (Eintrag, Zeile, Block; null ohne), Startwert für buildField und
// das Bildraster.
export function storedFocus(field, values) {
  return values && field.focusField ? values[field.focusField] : null;
}

// Bildfeld: Ausschnitt im Feld (framingField; ohne Bild die Ablagefläche), Bezeichnung in seiner Kopfzeile neben
// „Anderes Bild“ und „Entfernen“. Die URL steht im versteckten Eingabefeld, der Fokuspunkt im versteckten Feld focus
// (Name field.focusField); Änderungen melden sich als input am Formular (ungespeicherte Eingaben). Hochgeladen und
// zugeschnitten wird für das Formular ctx.uploads, mit size aus dem Schema als höchster Anzeigebreite. Vorschauen gibt es
// an den Stellen aus field.usage (nur oberste Ebene; ctx.places misst einmal je Formular für alle Felder, im
// Hintergrund). Ein neues Bild und Entfernen leeren den Fokuspunkt.
export function imageField(field, input, ctx, focus) {
  const look = ctx.look;
  const box = fieldBox(look, field, 'div');
  input.type = 'hidden';
  const changed = function (target, value) {
    if (target.value === value) return;
    target.value = value;
    target.dispatchEvent(new Event('input', { bubbles: true }));
  };
  const framing = framingField({
    url: input.value,
    focus: focus.value,
    maxWidth: field.size,
    form: ctx.uploads,
    notify: ctx.notify,
    buttons: { text: look.framing.text, option: look.framing.option, icon: look.iconButton },
    drop: { drop: look.imageDrop, active: look.imageDropActive, image: look.image, empty: look.imageEmpty },
    replace: true,
    removeLabel: ENTRY_TEXT.remove,
    onChange: function (result) {
      changed(focus, result.focus);
      changed(input, result.url);
    }
  });
  ctx.framings.push(framing);
  if (field.usage) ctx.places(field.usage).then(framing.setPlaces);
  framing.head.prepend(box.firstChild);
  box.append(input, framing.element, focus);
  return box;
}

// Ausschnitt einer Kachel des Bildrasters in einer eigenen Ebene über dem Formular (openFramingLayer, das Formular bleibt
// offen): Zuschnitt und Fokuspunkt, ohne Vorschauen; size aus dem Schema als höchste Anzeigebreite. near ist der Knopf
// (bekommt danach den Fokus), url und focus die Werte im Formular, onApply wie bei mountFraming. Es gilt erst mit
// dem Speichern des Eintrags: Ein Zuschnitt ist ein offener Upload von ctx.uploads, close() des Formulars schließt auch
// die Ebene (ctx.layer) und verwirft, was nicht gespeichert ist. Eine Ebene zur Zeit; solange ein Upload läuft, keine
// (es gibt noch kein Bild, auf dem sie arbeiten könnte; Hinweis von uploadPending).
export function openImageFraming(field, ctx, near, url, focus, onApply) {
  if (ctx.layer.close || uploadPending(ctx.notify)) return;
  let framing = null;
  const frame = openFramingLayer(near, {
    eyebrow: fieldLabel(field),
    buttons: ctx.look.framing,
    // Mit Änderungen fragen ×, Esc und Klick daneben nach, wie das Panel (confirmClose der Oberfläche).
    isDirty: function () { return framing !== null && framing.isDirty(); },
    confirmClose: ctx.confirmClose,
    onClose: function () {
      if (framing) framing.dispose();
      if (ctx.layer.close === frame.close) ctx.layer.close = null;
    }
  });
  ctx.layer.close = frame.close;
  framing = mountFraming(frame, {
    url: url,
    focus: focus,
    maxWidth: field.size,
    form: ctx.uploads,
    notify: ctx.notify,
    onApply: onApply
  });
}

// Dateifeld (PDF): Name der Datei als Link (neuer Tab), Auswahl mit sofortigem Upload und „Entfernen“; abgelegte
// Datei lädt ebenso hoch. Die URL steht im versteckten Eingabefeld, Änderungen melden sich als input am Formular.
export function fileField(look, field, input, notify, uploads) {
  const box = fieldBox(look, field, 'div');
  input.type = 'hidden';
  const set = function (url) {
    input.value = url;
    show();
    input.dispatchEvent(new Event('input', { bubbles: true }));
  };
  const picker = filePicker(set, notify, look.picker, uploads);
  const link = document.createElement('a');
  link.className = look.file;
  link.target = '_blank';
  link.rel = 'noopener';
  link.title = ENTRY_TEXT.fileOpen;
  const remove = editorButton(ENTRY_TEXT.remove, look.picker, function () { set(''); });
  const chooseText = picker.element.firstChild.nodeValue;
  const show = function () {
    link.hidden = !input.value;
    link.href = input.value || '#';
    link.textContent = input.value ? decodeURIComponent(input.value.split('/').pop()) : '';
    remove.hidden = !input.value;
    picker.element.firstChild.nodeValue = input.value ? ENTRY_TEXT.otherFile : chooseText;
  };
  show();
  box.addEventListener('dragover', function (event) {
    if (!draggingFiles(event)) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = 'copy';
  });
  box.addEventListener('drop', function (event) {
    if (!draggingFiles(event)) return;
    event.preventDefault();
    const file = event.dataTransfer.files[0];
    if (file) picker.upload(file);
  });
  const actions = document.createElement('div');
  actions.className = look.imageActions;
  actions.append(picker.element, remove);
  box.append(input, link, actions);
  return box;
}

// Icon-Feld: Suche und Raster aller Icons wie im Seiten-Editor (icon-grid.js); der Name steht im
// versteckten Eingabefeld, ohne Pflicht gibt es „Entfernen“. Änderungen melden sich als input am Formular.
export function iconField(look, field, input, notify) {
  const box = fieldBox(look, field, 'div');
  input.type = 'hidden';
  const set = function (name) {
    input.value = name;
    remove.hidden = !name;
    input.dispatchEvent(new Event('input', { bubbles: true }));
  };
  const icons = iconGrid(look.iconGrid, input.value, set);
  icons.search.placeholder = ICON_TEXT.search;
  icons.search.setAttribute('aria-label', ICON_TEXT.search);
  const remove = editorButton(ENTRY_TEXT.remove, look.picker, function () {
    icons.select('');
    set('');
  });
  remove.hidden = !input.value;
  box.append(input, icons.search, icons.grid, icons.empty);
  if (!field.required) box.appendChild(remove);
  icons.ready.catch(function (error) {
    const notice = errorNotice(error);
    if (notify) notify(notice.message, notice.action);
  });
  return box;
}

// Mehrzeiliges Textfeld wächst mit seinem Inhalt (bis zur Höchsthöhe aus dem CSS, dann scrollt es),
// statt den Text unten abzuschneiden. Gemessen wird erst, wenn es im Dokument steht.
export function autoGrow(textarea) {
  const fit = function () {
    if (!textarea.isConnected) return;
    textarea.style.height = 'auto';
    textarea.style.height = (textarea.scrollHeight + textarea.offsetHeight - textarea.clientHeight) + 'px';
  };
  textarea.addEventListener('input', fit);
  textarea.addEventListener('focus', fit);
  window.requestAnimationFrame(fit);
}

// Adresse (slug): als Text unter ihrem Quellfeld (Präfix aus dem Schema, z. B. „/aktuelles/“), erst der
// Stift macht sie zum Eingabefeld; leer steht da, woraus sie beim Speichern entsteht.
export function slugField(look, field, input, sourceLabel) {
  const box = document.createElement('div');
  box.className = look.slug;
  const text = document.createElement('span');
  text.className = look.slugText;
  const auto = ENTRY_TEXT.slugAuto.replace('{name}', function () { return sourceLabel || fieldLabel(field); });
  const show = function () {
    text.textContent = input.value ? (field.prefix || '') + input.value : auto;
    text.classList.toggle(look.slugAuto, !input.value);
  };
  let editing = false;
  // Beim Bearbeiten bleibt nur das Präfix als Text vor dem Feld.
  const edit = symbolButton('pencil', ENTRY_TEXT.slugEdit, look.iconButton, function () {
    editing = true;
    text.textContent = field.prefix || '';
    text.classList.remove(look.slugAuto);
    text.hidden = !field.prefix;
    edit.hidden = true;
    input.hidden = false;
    input.focus();
  });
  input.className = look.slugInput;
  input.hidden = true;
  input.setAttribute('aria-label', fieldLabel(field));
  input.addEventListener('input', function () { if (!editing) show(); });
  show();
  box.append(text, edit, input);
  return box;
}
