import { dragSort, DRAG_HANDLE } from '../drag-sort.js';

// Sortieren der Zeilen, Blöcke und Kacheln des Formulars; eigene Datei, weil die übrigen beim Laden das DOM brauchen und
// node sie so prüfen kann (tests/frontend/drag-sort.test.php).

// Zeilen, Blöcke bzw. Kacheln (rows, je mit element(row) im container) durch Ziehen und Alt+Pfeil sortieren
// (dragSort): mit handle nur am Ziehpunkt (dragHandle im Kopf), sonst an der ganzen Karte außer ihren
// Texteingaben. Ordnet rows und DOM um und ruft changed() (input am Formular); label(row) nennt die Ansage
// und die Kopie am Zeiger („Foto 3 von 7“). Schließen des Formulars bricht ein laufendes Ziehen ab (ctx.sorters, je
// { container, dispose }).
// options.view (optional): eine zweite Ansicht derselben Zeilen (Vorschau der Galerie, gallery-controls.js), gezogen
// wird an ihren Elementen: { container (um die Elemente: Mitscrollen, Ebene), items() → [{ row, element }] in der
// Reihenfolge von rows (Zeilen ohne Element fehlen), rectOf(element) (Rechteck im Fenster) }. Dann hört niemand an den
// Elementen, der Gastgeber ruft begin und key der Rückgabe; umgeordnet werden rows und ihre Karten in container wie sonst.
// Liefert { begin(event, element), key(event, element), dispose() } (dragSort).
export function sortRows(container, rows, ctx, options) {
  const view = options.view || null;
  const shown = view ? view.items : function () {
    return rows.map(function (row) { return { row: row, element: options.element(row) }; });
  };
  const rowOf = function (element) { return shown().find(function (entry) { return entry.element === element; }).row; };
  const sorter = dragSort(view ? view.container : container, {
    items: function () { return shown().map(function (entry) { return entry.element; }); },
    handle: options.handle ? DRAG_HANDLE : null,
    rectOf: view ? view.rectOf : null,
    external: Boolean(view),
    label: function (element) { return options.label(rowOf(element)); },
    onDrop: function (from, to) {
      const list = shown().map(function (entry) { return entry.row; });
      const at = moveRow(rows, list, from, to);
      container.insertBefore(options.element(rows[at]), rows[at + 1] ? options.element(rows[at + 1]) : null);
      options.changed();
    }
  });
  ctx.sorters.push({ container: container, dispose: sorter.dispose });
  return sorter;
}

// Zeile list[from] an die Stelle to von list (Index danach, wie onDrop); list sind die Zeilen aus rows, die gerade zu
// sehen sind (alle bzw. in der Vorschau nur die mit Bild), in ihrer Reihenfolge. Ordnet rows um: vor die Zeile, die
// danach an to steht, sonst hinter die letzte von list (allein in list: wo sie war); die übrigen Zeilen bleiben an ihrem
// Platz. Liefert die neue Stelle in rows.
export function moveRow(rows, list, from, to) {
  const moved = list[from];
  const rest = list.filter(function (row) { return row !== moved; });
  let at = rows.indexOf(moved);
  rows.splice(at, 1);
  if (to < rest.length) at = rows.indexOf(rest[to]);
  else if (rest.length) at = rows.indexOf(rest[rest.length - 1]) + 1;
  rows.splice(at, 0, moved);
  return at;
}

// Entfernte Karte (Zeile, Block): Sortieren darin (Bildraster, Zeilen im Block) gleich beenden, nicht erst beim Schließen.
export function disposeSortersIn(ctx, element) {
  for (let index = ctx.sorters.length - 1; index >= 0; index--) {
    if (!element.contains(ctx.sorters[index].container)) continue;
    ctx.sorters[index].dispose();
    ctx.sorters.splice(index, 1);
  }
}
