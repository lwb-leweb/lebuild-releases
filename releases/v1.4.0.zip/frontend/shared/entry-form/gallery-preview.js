import { state } from '../core.js';
import { editorButton, element } from '../buttons.js';
import { errorNotice, isAuthLost, isRenewed } from '../request.js';
import { measureFrame, MEASURE_TIMEOUT } from '../framing-measure.js';
import { holdStyle } from '../drag-sort.js';
import { withinTime, inOrder, debounce } from '../pending.js';
import { ENTRY_TEXT } from './text.js';
import { previewDelay, keepsPreview, previewRequest, formRow, liveRow, cardOf, previewFit, previewRect, stageLimit, frameScroll, hidesOverlay, checksOverlays, authRetry, showsError, AUTH_RETRY } from './preview-rules.js';

// Vorschau des ersten Bildrasters im Seitenpanel einer Einzelansicht: die Seite ohne Editor (Messseite) je Breite aus
// state.preview.widths in einem iframe, gezeigt nur das Element der Einzelansicht, auf die Breite des Panels verkleinert.
// Sein Inhalt kommt aus dem Endpunkt preview mit den ungespeicherten Werten des Formulars. Die Zeilen bleiben die Daten
// des Bildrasters (galleryField); die Vorschau ist eine zweite Ansicht davon und ändert nichts am Formular.

// Höchsthöhe der Vorschau (tokens.css); die sichtbare Höhe begrenzt zusätzlich das Fenster des Geräts (stageLimit).
const MAX_HEIGHT_TOKEN = '--le-gallery-preview-max-height';

// Vorschau für das Galerie-Feld field (Bildfeld imageSub) des Formulars form. options (vom Seitenpanel, plugin-lists.js):
// { page (Adresse der Seite), pick(document) → Element der Einzelansicht in der Messseite oder null, rowAttr (Name von
// data-le-row), render(data, feldname) → Promise mit dem HTML des Elements }. values() liest das Formular.
// Rendert nach jedem input am Formular (previewDelay), eine ältere Antwort überholt nie eine neuere (inOrder). Bei
// ungültigen Werten bleibt die letzte Vorschau ohne Meldung (die kommt beim Speichern, showsError); bei abgelaufener oder
// erneuerter Anmeldung zeigt ctx.notify die Meldung (errorNotice, mit „Neu anmelden“) und sie rendert von selbst neu (authRetry: erneuert gleich, abgelaufen, sobald das Fenster
// wieder den Fokus hat); lädt die Seite nicht, fehlt das Element oder scheitert der Endpunkt anders, zeigt das Feld nur
// den Hinweis (galleryField zeigt dann das Raster).
// Der Rahmen ist ein Fenster in der Höhe des Geräts (nie nach dem Inhalt oder dem Panel, sonst stimmten vh und
// Medienabfragen nicht), die Vorschau zeigt höchstens so viel davon (stageLimit); er steht über ihrem sichtbaren Teil und
// scrollt mit ihr (frameScroll). Feste und klebende Elemente der Seite außerhalb des Elements (Kopfleiste, Cookie-Hinweis)
// sind im Rahmen unsichtbar, sonst lägen sie über der Galerie (hidesOverlay, nach jedem Rendern und Scrollen neu geprüft).
// Liefert { field, box, head, layer, scroller, follow(rows), images(), scale(), onRender(fn), onFail(fn), onClose(fn),
// failed(), dispose() }; die Bedienung darauf legt gallery-controls.js. Das erste Mal rendert sie, sobald sie im offenen
// Panel Breite hat (ein abgelehntes Panel fragt nicht).
export function galleryPreview(form, ctx, field, imageSub, options, values) {
  const look = ctx.look.preview;
  const widths = state.preview.widths;
  const keys = Object.keys(widths);
  const box = element('div', look.box);
  // Kopf über der Vorschau: Umschalter der Breiten, davor legt das Feld „+ … hinzufügen“ (galleryField).
  const head = element('div', look.head);
  const switcher = element('div', look.widths);
  switcher.setAttribute('role', 'group');
  switcher.setAttribute('aria-label', ENTRY_TEXT.previewWidths);
  // Senkrechter Scrollbereich bis zur Höchsthöhe; darin die Fläche (Breite des Panels, Höhe der verkleinerten Galerie) und
  // auf ihr der Ausschnitt, genau so groß wie die verkleinerte Galerie (der Rest der Seite samt Scrollleiste bleibt
  // verdeckt), mit den Rahmen und der Ebene darüber.
  const scroller = element('div', look.stage);
  const sizer = element('div', look.sizer);
  const cut = element('div', look.cut);
  const layer = element('div', look.layer);
  const hint = element('p', look.hint);
  hint.textContent = ENTRY_TEXT.previewLoading;
  cut.appendChild(layer);
  sizer.appendChild(cut);
  scroller.appendChild(sizer);
  head.appendChild(switcher);
  box.append(head, scroller, hint);

  // Je Breite: { button, px (Breite der Galerie), frame, el (Element der Einzelansicht), observer, fit }; frame erst beim
  // ersten Umschalten.
  const views = {};
  let active = keys[0];
  // Zu sehende Antwort: { html, indexes, rows } (indexes aus previewRequest, rows die Zeilen des Rasters beim Rendern),
  // null vor der ersten.
  let shown = null;
  // Zeilen des Rasters (follow), dasselbe Array, das galleryField umordnet.
  let followed = [];
  let failed = false;
  let disposed = false;
  let pending = 0;
  // Anmeldung verloren: neu rendern, sobald das Fenster wieder den Fokus hat (authRetry); der Hinweis dazu (dismiss aus
  // notify) geht, sobald wieder gerendert ist.
  let loginLost = false;
  let loginNotice = null;
  // Im Rahmen ausgeblendete Elemente → stellt ihren Stil wieder her (holdStyle), falls sie nicht mehr fest sind.
  const hidden = new WeakMap();
  // Neue Lage (Inhalt, Breite, Größe) seit dem letzten fit; nur Scrollen der Vorschau meldet onRender nicht.
  let moved = false;
  const rendered = [];
  const failures = [];
  const closers = [];
  const order = inOrder();
  const later = debounce(function () { render(false); });

  const fail = function () {
    if (failed || disposed) return;
    failed = true;
    stop();
    // Zuhörer vor dem Abbau: Sie lesen den Fokus an der Bedienung, solange sie noch im Dokument steht.
    failures.forEach(function (fn) { fn(); });
    head.remove();
    scroller.remove();
    hint.hidden = false;
    hint.textContent = ENTRY_TEXT.previewFailed;
  };

  // Lage neu rechnen: Fenster des Rahmens (Höhe des Geräts) gescrollt (sofort, auch bei scroll-behavior: smooth der Seite)
  // auf den sichtbaren Teil der Galerie, verkleinert auf die Breite des Panels; die Fläche bekommt die Höhe der
  // verkleinerten Galerie, der Rahmen steht so, dass das Element bei 0, 0 des Ausschnitts liegt. Die Vorschau zeigt nie
  // mehr als das Fenster (stageLimit).
  const fit = function () {
    pending = 0;
    const view = views[active];
    if (failed || disposed || !view || !view.el) return;
    const win = view.frame.contentWindow;
    const avail = sizer.clientWidth;
    if (checksOverlays(moved, view.changed)) {
      view.changed = false;
      hideOverlays(view.el);
    }
    let rect = view.el.getBoundingClientRect();
    const top = frameScroll(rect.top + win.scrollY, scroller.scrollTop - sizer.offsetTop, previewFit(avail, rect).scale);
    win.scrollTo({ left: 0, top: top, behavior: 'instant' });
    rect = view.el.getBoundingClientRect();
    const at = previewFit(avail, rect);
    view.fit = at;
    view.frame.style.left = at.frameLeft + 'px';
    view.frame.style.top = at.frameTop + 'px';
    view.frame.style.transform = 'scale(' + at.scale + ')';
    const limit = stageLimit(widths[active], at.scale);
    scroller.style.maxHeight = limit === null ? '' : 'min(var(' + MAX_HEIGHT_TOKEN + '), ' + limit + 'px)';
    sizer.style.height = at.height + 'px';
    cut.style.left = at.x + 'px';
    cut.style.width = at.width + 'px';
    cut.style.height = at.height + 'px';
    view.px.textContent = ENTRY_TEXT.previewPx.replace('{width}', String(Math.round(rect.width)));
    hint.hidden = true;
    if (!moved) return;
    moved = false;
    rendered.forEach(function (fn) { fn(); });
  };
  // Neue Lage im nächsten Bild; scrolled: nur die Vorschau gescrollt (Rahmen nachziehen, ohne onRender).
  const refit = function (scrolled) {
    if (scrolled !== true) moved = true;
    if (!pending) pending = window.requestAnimationFrame(fit);
  };
  const onScroll = function () { refit(true); };
  scroller.addEventListener('scroll', onScroll);
  // Feste und klebende Elemente der Seite im Rahmen unsichtbar (hidesOverlay: nur außerhalb von el; Platz und Lage
  // bleiben, nur gezeichnet wird es nicht). Bei jeder neuen Lage und beim Scrollen, wenn sich die Seite seitdem geändert hat
  // (checksOverlays), auch für später eingeblendete oder fest gewordene (Cookie-Hinweis); ist eins nicht mehr fest, ist es
  // wieder zu sehen. Nur im Dokument des Rahmens.
  const hideOverlays = function (el) {
    const doc = el.ownerDocument;
    Array.prototype.forEach.call(doc.body.querySelectorAll('*'), function (node) {
      const hide = hidesOverlay(doc.defaultView.getComputedStyle(node), !node.contains(el) && !el.contains(node));
      if (hide && !hidden.has(node)) hidden.set(node, holdStyle(node, 'visibility', 'hidden', 'important'));
      if (!hide && hidden.has(node)) {
        hidden.get(node)();
        hidden.delete(node);
      }
    });
  };
  // Die Fläche bekommt erst im offenen Panel eine Breite: dann lädt der erste Rahmen (die Zeitgrenze läuft erst ab da),
  // danach rechnet jede neue Breite des Panels die Lage neu.
  const outer = new ResizeObserver(function () {
    if (!sizer.clientWidth) return;
    if (views[active].frame) {
      refit();
      return;
    }
    show(active);
    render(true);
  });
  outer.observe(sizer);

  const load = function (key) {
    const view = views[key];
    view.frame = measureFrame(options.page, widths[key].width, look.frame);
    view.frame.style.height = widths[key].height + 'px';
    const loaded = new Promise(function (resolve) {
      view.frame.addEventListener('load', function () { resolve(true); }, { once: true });
    });
    cut.insertBefore(view.frame, layer);
    withinTime(loaded, MEASURE_TIMEOUT, false).then(function (ok) {
      if (failed || disposed) return;
      let el = null;
      try {
        el = ok ? options.pick(view.frame.contentDocument) : null;
      } catch (e) {
        el = null;
      }
      if (!el) {
        fail();
        return;
      }
      view.el = el;
      if (shown) fill(el, shown.html);
      view.observer = new view.frame.contentWindow.ResizeObserver(refit);
      view.observer.observe(el);
      // Geändert (Klasse, Stil, neue Elemente, etwa ein Cookie-Hinweis oder eine Kopfleiste, die beim Scrollen fest wird):
      // beim nächsten Scrollen Überlagerndes neu prüfen (checksOverlays), sonst nur bei neuer Lage.
      view.mutations = new view.frame.contentWindow.MutationObserver(function () { view.changed = true; });
      view.mutations.observe(view.frame.contentDocument.documentElement, { subtree: true, childList: true, attributes: true });
      // Wird die Seite kürzer (weniger Fotos), setzt der Browser ihr Scrollen zurück, ohne dass sich el ändert: nachziehen.
      view.frame.contentWindow.addEventListener('scroll', onScroll);
      if (key === active) refit();
    });
  };

  const show = function (key) {
    active = key;
    keys.forEach(function (name) {
      views[name].button.setAttribute('aria-pressed', String(name === key));
      if (views[name].frame) views[name].frame.hidden = name !== key;
    });
    if (!views[key].frame) load(key);
    else refit();
  };

  keys.forEach(function (key) {
    const button = editorButton(widths[key].label, look.width, function () { if (!failed) show(key); });
    button.setAttribute('aria-pressed', String(key === active));
    const px = element('span', look.widthPx);
    button.appendChild(px);
    switcher.appendChild(button);
    views[key] = { button: button, px: px, frame: null, el: null, observer: null, mutations: null, changed: true, fit: null };
  });

  // Inhalt des Elements el ersetzen: HTML aus dem Renderer des Plugins (wie die Seite selbst), gelesen wie beim Neuladen
  // einer Liste (DOMParser, importNode); Skripte darin laufen nicht.
  const fill = function (el, html) {
    const fresh = new DOMParser().parseFromString(html, 'text/html');
    el.replaceChildren.apply(el, Array.prototype.map.call(fresh.body.childNodes, function (node) { return el.ownerDocument.importNode(node, true); }));
  };
  const apply = function (html, indexes, rows) {
    shown = { html: html, indexes: indexes, rows: rows };
    keys.forEach(function (key) {
      if (views[key].el) fill(views[key].el, html);
    });
    refit();
  };

  // quiet: erstes Rendern beim Öffnen und erneuter Versuch beim Fokus, ohne Meldung (der Eintrag ist noch unverändert,
  // „… anlegen“ noch leer; die Meldung zur Anmeldung stand schon da). retried: Versuch nach verlorener Anmeldung.
  const render = function (quiet, retried) {
    if (failed || disposed) return;
    const request = previewRequest(values(), field, imageSub.name);
    const rows = followed.slice();
    const number = order.next();
    if (request.empty) {
      order.fresh(number);
      apply('', [], rows);
      return;
    }
    options.render(request.data, field.name).then(function (html) {
      if (disposed || !order.fresh(number)) return;
      loginLost = false;
      if (loginNotice) loginNotice();
      loginNotice = null;
      if (typeof html !== 'string') {
        fail();
        return;
      }
      apply(html, request.indexes, rows);
    }, function (error) {
      if (disposed || !order.fresh(number)) return;
      const authLost = isAuthLost(error);
      if (!keepsPreview(error, authLost)) {
        fail();
        return;
      }
      const retry = authRetry(authLost, isRenewed(error), Boolean(retried));
      loginLost = retry === AUTH_RETRY.focus;
      if (retry === AUTH_RETRY.now) {
        render(quiet, true);
        return;
      }
      if (!showsError(authLost, quiet, retried)) return;
      const notice = errorNotice(error);
      const dismiss = ctx.notify(notice.message, notice.action);
      if (authLost) loginNotice = dismiss;
    });
  };
  const onInput = function (event) { later.soon(previewDelay(event)); };
  form.addEventListener('input', onInput);
  // Zurück von „Neu anmelden“ (Login in einem neuen Tab): mit der neuen Anmeldung neu rendern.
  const onFocus = function () {
    if (loginLost) render(true, true);
  };
  window.addEventListener('focus', onFocus);

  const stop = function () {
    later.cancel();
    form.removeEventListener('input', onInput);
    window.removeEventListener('focus', onFocus);
    scroller.removeEventListener('scroll', onScroll);
    outer.disconnect();
    if (pending) window.cancelAnimationFrame(pending);
    keys.forEach(function (key) {
      const view = views[key];
      if (view.observer) view.observer.disconnect();
      if (view.mutations) view.mutations.disconnect();
      if (view.frame) view.frame.remove();
    });
  };

  return {
    field: field,
    box: box,
    head: head,
    // Ebene über dem Rahmen, genau über der verkleinerten Galerie; scrollt mit.
    layer: layer,
    scroller: scroller,
    // Zeilen des Rasters (rows, dasselbe Array, das umgeordnet wird): images() ordnet jedes Bild der Zeile zu, die beim
    // Rendern an seiner Stelle stand, auch wenn sie inzwischen woanders steht.
    follow: function (rows) { followed = rows; },
    // Bilder der zu sehenden Antwort mit Zeile: [{ row (Stelle in rows jetzt), element (<img> in der Seite), card (Fläche
    // des Bildes in der Seite, cardOf), rect (der Karte, im Maßstab des Panels, bezogen auf layer) }], ohne Bilder
    // entfernter Zeilen; leer vor der ersten Antwort.
    images: function () {
      const view = views[active];
      if (failed || !shown || !view.el || !view.fit) return [];
      const el = view.el.getBoundingClientRect();
      return Array.prototype.map.call(view.el.querySelectorAll('[' + options.rowAttr + ']'), function (img) {
        const card = cardOf(img, view.el);
        const row = liveRow(shown.rows, followed, formRow(shown.indexes, img.getAttribute(options.rowAttr)));
        return { row: row, element: img, card: card, rect: previewRect(view.fit, el, card.getBoundingClientRect()) };
      }).filter(function (image) { return image.row !== null; });
    },
    // Maßstab der zu sehenden Breite (Gleiten in der Seite, glide).
    scale: function () {
      const view = views[active];
      return view.fit ? view.fit.scale : 0;
    },
    // fn() nach jeder neuen Lage: neuer Inhalt, andere Breite, Größe von Panel oder Galerie geändert.
    onRender: function (fn) { rendered.push(fn); },
    // fn() einmal, wenn die Vorschau nicht lädt, noch vor dem Abbau von Ebene und Popover (danach zeigt das Feld das Raster).
    onFail: function (fn) { failures.push(fn); },
    // fn() einmal beim Schließen des Formulars (dispose).
    onClose: function (fn) { closers.push(fn); },
    failed: function () { return failed; },
    dispose: function () {
      if (disposed) return;
      stop();
      disposed = true;
      closers.forEach(function (fn) { fn(); });
    }
  };
}
