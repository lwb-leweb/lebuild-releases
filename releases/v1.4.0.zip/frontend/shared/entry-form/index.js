import { uploadPending, uploadForm, settledAction } from '../upload.js';
import { ENTRY_TEXT, fieldLabel, copyTitle } from './text.js';
import { copyValues } from './copy.js';
import { SIDE_FIELD_TYPES, BACKEND_LOOK } from './looks.js';
import { entryPlaces } from '../framing-measure.js';
import { buildField, focusFirst, applyShowWhen, readField } from './fields.js';
import { storedFocus } from './inputs.js';
import { galleryImage } from './gallery.js';
import { galleryPreview } from './gallery-preview.js';
export { ENTRY_TEXT, fieldLabel, titleField, entryTitle, deleteQuestion, copyTitle } from './text.js';
export { copyValues } from './copy.js';

// Formular für einen Plugin-Eintrag aus dem Schema seines Typs (schema.fields bzw. Typ-JSON der
// Content-Typen). Die eine Quelle für Seiten-Editor (Panel im Shadow-DOM, plugin-lists.js) und
// Backend (Modal: generische Plugin-Ansicht, Plugins über ctx.ui.openEntryForm). Gebaut wird per
// DOM (textContent, value), Eintragswerte und Feldnamen können kein Markup einschleusen.
// Von außen nur über diese Datei; die Teile liegen daneben (text, looks, inputs, gallery, fields).

// Baut das Formular. options: { look (Klassen, siehe BACKEND_LOOK), notify (Hinweise beim Upload),
// onSubmit() (Enter in einem Feld), confirmClose() (Rückfrage der Oberfläche, bevor die Ebene „Ausschnitt“ Änderungen
// verwirft; Promise mit true = verwerfen), split (zwei Spalten, SIDE_FIELD_TYPES; Klassen look.split, look.main, look.side, look.full),
// preview (nur Seitenpanel einer Einzelansicht: das erste Bildraster bekommt die Vorschau der Seite, gallery-preview.js;
// Klassen look.preview) }. Felder ohne Wert im Eintrag (neu, ältere Einträge) starten mit
// default aus dem Schema, sofern angegeben. Liefert { form, check(), values(), focus(), close() }: Speichern wartet vor
// check() auf ausstehende Zuschnitte (settledAction in upload.js, dann kommen sie mit); check() = Pflichtfelder gefüllt
// (sonst zeigt der Browser die Meldung am Feld; in list nur in Zeilen mit Inhalt) und kein Upload läuft (sonst Hinweis über notify), values() = { feldname: wert }
// (boolean '1'/'0', list als Array von { unterfeld: wert }, dazu <focusField> je Bildfeld, auch in Zeilen und Blöcken), close() =
// Formular ist fertig (gespeichert oder verworfen): schließt eine offene Ebene „Ausschnitt“, verwirft ausstehende
// Zuschnitte, beendet die Vorschau; hochgeladene und zugeschnittene Bilder, die nicht gespeichert sind, löscht der Server (upload.js, uploadForm).
export function buildEntryForm(schema, row, options) {
  // layer.close: offene Ebene „Ausschnitt“ (openImageFraming), geteilt mit den Zeilen und Blöcken; framings: Bildfelder
  // (framingField), die beim Schließen einen ausstehenden Zuschnitt verwerfen; sorters: Sortieren der Zeilen, Blöcke und
  // Kacheln (sortRows), beim Schließen bricht ein laufendes Ziehen ab.
  const ctx = { look: options.look, notify: options.notify, confirmClose: options.confirmClose, uploads: uploadForm(), editors: [], beforeCheck: [], layer: { close: null }, framings: [], sorters: [] };
  const fields = {};
  // Adresse mit Quellfeld (from, meist der Titel): als Text unter diesem (slugField).
  const source = function (name) { return schema.find(function (field) { return field.name === name && field.type !== 'slug'; }); };
  ctx.slugSource = function (name) { const field = source(name); return field ? fieldLabel(field) : null; };
  const form = document.createElement('form');
  form.className = ctx.look.form;
  // Stellen der Bildfelder: einmal je Formular gemessen, alle Felder zusammen (iframes im Formular, mit ihm weg).
  ctx.places = entryPlaces(form, row && row.id ? row.id : null);
  const values = function () {
    const data = {};
    Object.keys(fields).forEach(function (name) { readField(data, name, fields[name]); });
    return data;
  };
  // Vorschau der Seite für das erste Bildraster der obersten Ebene; galleryField zeigt sie über seinen Kacheln.
  const previewField = options.preview ? schema.find(function (field) { return field.type === 'list' && galleryImage(field) !== null; }) : null;
  ctx.preview = previewField ? galleryPreview(form, ctx, previewField, galleryImage(previewField), options.preview, values) : null;

  const isSide = function (field) { return SIDE_FIELD_TYPES.indexOf(field.type) !== -1; };
  const split = options.split && schema.some(isSide) && !schema.every(isSide);
  const columns = { main: form, side: form, full: form };
  if (split) {
    // Angaben zuerst: Tab-Reihenfolge und schmale Ansicht wie einspaltig (Kategorie oben), Zeilen zuletzt.
    form.classList.add(ctx.look.split);
    ['side', 'main', 'full'].forEach(function (name) {
      columns[name] = document.createElement('div');
      columns[name].className = ctx.look[name];
      form.appendChild(columns[name]);
    });
  }
  schema.forEach(function (field) {
    const value = row && row[field.name] != null ? row[field.name] : field.default;
    fields[field.name] = buildField(field, value != null ? value : '', ctx, storedFocus(field, row));
    columns[isSide(field) ? 'side' : (field.type === 'list' || field.type === 'blocks' ? 'full' : 'main')].appendChild(fields[field.name].box);
  });
  schema.forEach(function (field) {
    if (field.type === 'slug' && source(field.from)) fields[field.from].box.after(fields[field.name].box);
  });
  applyShowWhen(schema, fields);

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    options.onSubmit();
  });
  // Enter in einem einzeiligen Feld speichert (ohne Absenden-Knopf im Formular tut der Browser das nicht).
  form.addEventListener('keydown', function (event) {
    if (event.key !== 'Enter' || event.target.tagName !== 'INPUT' || event.target.type === 'file') return;
    event.preventDefault();
    options.onSubmit();
  });

  return {
    form: form,
    values: values,
    check: function () {
      if (uploadPending(options.notify)) return false;
      ctx.beforeCheck.forEach(function (prepare) { prepare(); });
      if (!form.reportValidity()) return false;
      // Texteditoren entfernter oder leerer Zeilen zählen nicht.
      const empty = ctx.editors.find(function (entry) {
        return entry.field.required && form.contains(entry.input) && !(entry.row && entry.row.empty()) && entry.input.value === '';
      });
      if (!empty) return true;
      options.notify(ENTRY_TEXT.richtextRequired.replace('{name}', function () { return fieldLabel(empty.field); }));
      empty.editor.focus();
      return false;
    },
    focus: function () {
      focusFirst(form);
    },
    close: function () {
      ctx.sorters.forEach(function (sorter) { sorter.dispose(); });
      if (ctx.preview) ctx.preview.dispose();
      if (ctx.layer.close) ctx.layer.close();
      ctx.framings.forEach(function (framing) { framing.dispose(); });
      ctx.uploads.close();
    }
  };
}

// code der 409-Antwort, wenn der Eintrag seit dem Laden geändert wurde (PLUGIN_ENTRY_CONFLICT_CODE in backend/plugins/entries.php).
export const ENTRY_CONFLICT_CODE = 'conflict';

// Formular im Backend-Modal (app/js/modal.js). options: { schema, row, copyOf, save(data, extra) → Promise,
// onSaved(), notify, reload() }; extra { overwrite: true } nach der Rückfrage zu einem Konflikt (409 conflict);
// reload (optional) öffnet den Eintrag neu mit der anderen Fassung. copyOf (Original-Eintrag, ohne row): neuer Eintrag mit
// dessen Werten (copyValues), Titel „Kopie: …“, extra { after: id des Originals } (plugins/inline-lists.md).
// Titel sonst „Neu“/„Bearbeiten“, Fehler des Servers stehen im Modal. Wie auch immer
// das Modal zugeht (onClose), danach schließt sich das Formular (entry.close), bei laufendem Speichern
// erst, wenn es fertig ist (sonst fehlte dem Eintrag sein neues Bild).
export function openEntryModal(openModal, options) {
  let modal = null;
  let saving = false;
  const submit = function () { modal.submitButton.click(); };
  const copyOf = options.copyOf || null;
  const entry = buildEntryForm(options.schema, copyOf ? copyValues(options.schema, copyOf) : options.row, {
    look: BACKEND_LOOK,
    notify: options.notify,
    onSubmit: submit,
    // Rückfragen der Verwaltung laufen über window.confirm (wie beim Konflikt).
    confirmClose: function () { return Promise.resolve(window.confirm(ENTRY_TEXT.framingDiscard)); }
  });
  // Speichern: geprüft und geschickt erst, wenn kein Zuschnitt mehr gerechnet wird (er kommt dann mit); nach der
  // Zeitgrenze bleibt das Formular offen. Solange gewartet wird, ist nur Speichern gesperrt: Abbrechen, × und Esc
  // verwerfen wie sonst.
  const waiting = settledAction(options.notify, function (busy) { modal.submitButton.disabled = busy; });
  const save = function (ctx) {
    if (!ctx.isOpen() || !entry.check()) return;
    saving = true;
    ctx.setBusy(true);
    const values = entry.values();
    let theirs = false;
    options.save(values, copyOf ? { after: copyOf.id } : {}).catch(function (error) {
      if (error.code !== ENTRY_CONFLICT_CODE) throw error;
      if (window.confirm(ENTRY_TEXT.conflictAsk)) return options.save(values, { overwrite: true });
      // Abbrechen bleibt harmlos: die andere Fassung nur nach eigener Rückfrage laden, sonst bleibt das Formular.
      if (!options.reload || !window.confirm(ENTRY_TEXT.conflictTheirs)) throw error;
      theirs = true;
    }).then(function () {
      if (theirs) {
        saving = false;
        if (ctx.isOpen()) ctx.close('cancel');
        else entry.close();
        options.reload();
        return;
      }
      saving = false;
      if (ctx.isOpen()) ctx.close('submit');
      else entry.close();
      options.onSaved();
    }).catch(function (error) {
      saving = false;
      if (!ctx.isOpen()) entry.close();
      ctx.setBusy(false);
      ctx.setMessage(error.message || String(error), false);
    });
  };
  modal = openModal({
    title: copyOf ? copyTitle(options.schema, copyOf) : (options.row ? ENTRY_TEXT.edit : ENTRY_TEXT.add),
    bodyHtml: '',
    submitLabel: ENTRY_TEXT.save,
    cancelLabel: ENTRY_TEXT.cancel,
    onClose: function () { if (!saving) entry.close(); },
    onSubmit: function (ctx) {
      waiting.run(function () { save(ctx); });
    }
  });
  modal.body.appendChild(entry.form);
  entry.focus();
  return modal;
}
