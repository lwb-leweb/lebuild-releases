import { glide, positionText, visibleBoxes } from '../drag-sort.js';
import { visiblePart } from '../drag-geometry.js';
import { editorButton } from '../buttons.js';
import { symbolButton } from '../icons.js';
import { ENTRY_TEXT, fieldLabel, photoTitle } from './text.js';
import { photoShape, freshCards, drawsNow, redrawsAfterGlide, glideFrom, isNewPhoto, fallbackRow, NEW_PHOTO_MARK } from './preview-rules.js';
import { sortRows } from './sort-rows.js';
import { photoPopover } from './photo-popover.js';

// Bedienung in der Vorschau der Galerie (gallery-preview.js) auf den Zeilen des Bildrasters (galleryField): je Bild eine
// Fläche in der Ebene über dem Rahmen mit Nummer, × (Entfernen) und Rahmen beim Zeigen; Klick bzw. Enter öffnet das
// Popover am Foto (photo-popover.js), Ziehen und Alt+Pfeil sortieren mit dem Baustein (sortRows mit view: gezogen werden
// die Bilder der Seite, Rechtecke aus dem verkleinerten Rahmen). Im Rahmen ändert sich nur der Inhalt des Elements (beim
// Ziehen kurz die Blässe des Bildes). Nach jedem neuen Rendern entsteht die Ebene neu; offenes Popover und Fokus bleiben,
// umgeordnete und nachgerückte Bilder gleiten samt ihrer Fläche an ihren Platz (gemessen wird erst wieder, wenn das Gleiten
// zu Ende ist), neue sind NEW_PHOTO_MARK ms markiert. Die Nummern sind die Stellen der Zeilen im Formular, auch bevor die
// nächste Antwort da ist.

// gallery: { field, imageSub, rows (Zeilen des Rasters), grid (Raster, nur als Rückfall zu sehen), ctx, element(row)
// (Kachel), label() (Name eines Fotos, „Foto“), changed() (input am Formular) }.
export function galleryControls(preview, gallery) {
  const ctx = gallery.ctx;
  const look = ctx.look.preview;
  const rows = gallery.rows;
  const layer = preview.layer;
  const note = document.createElement('p');
  note.className = look.note;
  note.hidden = true;
  preview.box.appendChild(note);
  gallery.grid.hidden = true;
  preview.follow(rows);
  // Gezeigte Bilder in der Reihenfolge der Seite: [{ row, card, element (<img>), rect (relativ zu layer), spot, open }].
  let spots = [];
  // Rechteck je Karte (relativ zu layer), auch von einer älteren Antwort, falls sie während des Ziehens neu kam.
  const rects = new WeakMap();
  // Karten der zu sehenden Antwort: Eine Antwort mit anderen ist neu gerendert.
  let drawn = new WeakSet();
  // Zeilen beim Öffnen und alle seitdem gezeigten: Eine Zeile, die erst später zu sehen ist (hochgeladen), ist neu.
  const initial = new Set(rows);
  const seen = new WeakSet();
  // Rechtecke je Zeile vor dem Umordnen oder Entfernen: Mit der nächsten Antwort gleiten die Bilder von dort.
  let before = null;
  // Gleiten nach der letzten neuen Antwort (Ende aus glide): Solange misst draw nicht (die Karten tragen noch den Versatz),
  // sondern merkt sich, dass es danach neu zeichnen soll (redraw).
  let gliding = null;
  let redraw = false;
  // Neue Zeilen → Zeitgeber, bis zu dessen Ende sie markiert sind.
  const marked = new Map();
  let popover = null;
  const rootOf = function () { return preview.box.getRootNode(); };
  const byRow = function (a, b) { return rows.indexOf(a.row) - rows.indexOf(b.row); };
  const remember = function () {
    before = new Map(spots.map(function (entry) { return [entry.row, entry.rect]; }));
  };

  const sorter = sortRows(gallery.grid, rows, ctx, {
    handle: false,
    element: gallery.element,
    label: gallery.label,
    changed: function () {
      remember();
      renumber();
      gallery.changed();
    },
    view: {
      container: layer,
      items: function () {
        return spots.slice().sort(byRow).map(function (entry) { return { row: entry.row, element: entry.card }; });
      },
      rectOf: function (card) {
        const rect = rects.get(card);
        const base = layer.getBoundingClientRect();
        const left = base.left + rect.left;
        const top = base.top + rect.top;
        return { left: left, top: top, width: rect.width, height: rect.height, right: left + rect.width, bottom: top + rect.height };
      }
    }
  });

  const spotOf = function (row) {
    return spots.find(function (entry) { return entry.row === row; }) || null;
  };
  const titleOf = function (entry) {
    const position = positionText(gallery.label(), rows.indexOf(entry.row), rows.length);
    const image = entry.element;
    return photoTitle(position, image.complete ? photoShape(image.naturalWidth, image.naturalHeight) : null);
  };
  // Popover an sein Foto (im sichtbaren Teil der Vorschau, auch innerhalb des Panels zwischen Kopf und Fuß) und Überschrift
  // neu (ein Foto, das noch lädt: draw setzt sie danach).
  const showPopover = function () {
    const entry = popover ? spotOf(popover.row) : null;
    if (!entry) return;
    popover.update(titleOf(entry));
    popover.place(entry.spot.getBoundingClientRect(), visiblePart([preview.scroller.getBoundingClientRect()].concat(visibleBoxes(preview.scroller))));
  };
  const onOutside = function (event) {
    const target = event.composedPath()[0];
    // Während der Ebene „Ausschnitt“ (aus dem Popover) bleibt es offen.
    if (ctx.layer.close || popover.element.contains(target) || spots.some(function (entry) { return entry.spot.contains(target); })) return;
    closePopover(false);
  };
  const onEscape = function (event) {
    if (event.key !== 'Escape' || ctx.layer.close) return;
    event.preventDefault();
    event.stopPropagation();
    closePopover(true);
  };
  const openPopover = function (row) {
    closePopover(false);
    popover = photoPopover({ row: row, host: preview.box, look: look, onRemove: function () { removeRow(row); } });
    const root = rootOf();
    root.addEventListener('pointerdown', onOutside, true);
    root.addEventListener('keydown', onEscape, true);
    const entry = spotOf(row);
    if (entry) entry.spot.classList.add(look.spotActive);
    showPopover();
    popover.focus();
  };
  // refocus: Fokus zurück an das Foto (Esc).
  const closePopover = function (refocus) {
    if (!popover) return;
    const row = popover.row;
    popover.close();
    popover = null;
    const root = rootOf();
    root.removeEventListener('pointerdown', onOutside, true);
    root.removeEventListener('keydown', onEscape, true);
    const entry = spotOf(row);
    if (entry) entry.spot.classList.remove(look.spotActive);
    if (refocus && entry) entry.open.focus({ preventScroll: true });
  };

  const removeRow = function (row) {
    const index = rows.indexOf(row);
    if (popover && popover.row === row) closePopover(false);
    remember();
    row.remove();
    renumber();
    const next = spots.slice().sort(byRow).find(function (entry) { return rows.indexOf(entry.row) >= index; }) || spots[spots.length - 1];
    if (next) next.open.focus({ preventScroll: true });
  };

  // Fläche über einem Bild: Knopf über dem ganzen Bild (Klick, Enter: Popover; Ziehen, Alt+Pfeil), darin die Nummer, × daneben.
  const build = function (entry) {
    const index = rows.indexOf(entry.row);
    const spot = document.createElement('div');
    spot.className = look.spot;
    spot.style.left = entry.rect.left + 'px';
    spot.style.top = entry.rect.top + 'px';
    spot.style.width = entry.rect.width + 'px';
    spot.style.height = entry.rect.height + 'px';
    const open = editorButton('', look.spotOpen, function () {
      if (popover && popover.row === entry.row) closePopover(false);
      else openPopover(entry.row);
    });
    open.setAttribute('aria-label', positionText(gallery.label(), index, rows.length));
    const number = document.createElement('span');
    number.className = look.spotNumber;
    number.setAttribute('aria-hidden', 'true');
    number.textContent = String(index + 1);
    open.appendChild(number);
    entry.number = number;
    const remove = symbolButton('close', ENTRY_TEXT.imageRemove, look.spotRemove, function () { removeRow(entry.row); });
    spot.append(open, remove);
    spot.addEventListener('pointerdown', function (event) {
      if (!remove.contains(event.target)) sorter.begin(event, entry.card);
    });
    spot.addEventListener('keydown', function (event) { sorter.key(event, entry.card); });
    if (popover && popover.row === entry.row) spot.classList.add(look.spotActive);
    if (marked.has(entry.row)) spot.classList.add(look.spotNew);
    entry.spot = spot;
    entry.open = open;
    layer.appendChild(spot);
  };

  // Neue Zeile markieren, bis NEW_PHOTO_MARK um ist (über jedes Neuzeichnen hinweg, build setzt die Klasse).
  const mark = function (row) {
    marked.set(row, setTimeout(function () {
      marked.delete(row);
      const entry = spotOf(row);
      if (entry) entry.spot.classList.remove(look.spotNew);
    }, NEW_PHOTO_MARK));
  };
  // Nach dem Gleiten (alle glide zu Ende) neu zeichnen, wenn inzwischen eine neue Lage kam; eine neuere Antwort löst ab.
  const settle = function (glides) {
    const current = Promise.all(glides);
    gliding = current;
    redraw = false;
    current.then(function () {
      const latest = gliding === current;
      if (latest) gliding = null;
      if (redrawsAfterGlide(latest, redraw, preview.failed())) draw();
    });
  };

  // Ohne neue Antwort (umgeordnet, entfernt): Flächen entfernter Zeilen weg, Nummern und Namen aus den Zeilen jetzt; Lage
  // und Bilder bleiben bis zur Antwort.
  const renumber = function () {
    spots = spots.filter(function (entry) {
      const index = rows.indexOf(entry.row);
      if (index === -1) {
        entry.spot.remove();
        return false;
      }
      entry.number.textContent = String(index + 1);
      entry.open.setAttribute('aria-label', positionText(gallery.label(), index, rows.length));
      return true;
    });
    settled();
  };

  // Popover, Überschrift und Hinweis nach dem Zeichnen bzw. Umnummerieren.
  const settled = function () {
    if (popover && rows.indexOf(popover.row) === -1) closePopover(false);
    showPopover();
    const shown = popover ? spotOf(popover.row) : null;
    if (shown && !shown.element.complete) shown.element.addEventListener('load', showPopover, { once: true });
    const name = fieldLabel(gallery.field);
    note.textContent = rows.length ? (rows.some(function (row) { return !row.image; }) ? ENTRY_TEXT.imageUploading : '') : ENTRY_TEXT.previewEmpty.replace('{name}', function () { return name; });
    note.hidden = !note.textContent;
  };

  const draw = function () {
    const images = preview.images();
    const fresh = freshCards(images.map(function (image) { return image.card; }), drawn);
    if (!drawsNow(gliding !== null, fresh)) {
      redraw = true;
      return;
    }
    const active = rootOf().activeElement;
    const had = spots.find(function (entry) { return entry.spot.contains(active); });
    const scale = preview.scale();
    const glides = [];
    let added = null;
    layer.replaceChildren();
    drawn = new WeakSet();
    spots = images.map(function (image) {
      const entry = { row: rows[image.row], card: image.card, element: image.element, rect: image.rect };
      rects.set(entry.card, entry.rect);
      drawn.add(entry.card);
      if (isNewPhoto(entry.row, initial, seen)) {
        mark(entry.row);
        added = added || entry;
      }
      seen.add(entry.row);
      build(entry);
      // Karte und Fläche gleiten zusammen: Was man sieht, lässt sich auch während des Gleitens anklicken.
      const from = glideFrom(fresh, before, entry.row);
      if (from) glides.push(glide(entry.card, from, entry.rect, scale), glide(entry.spot, from, entry.rect));
      return entry;
    });
    if (fresh) {
      before = null;
      settle(glides);
    }
    if (added) added.spot.scrollIntoView({ block: 'nearest' });
    const focus = had ? spotOf(had.row) : null;
    if (focus) focus.open.focus({ preventScroll: true });
    settled();
  };

  preview.onRender(draw);
  preview.scroller.addEventListener('scroll', showPopover);
  // Rückfall: Bedienung weg, das Raster übernimmt. Lag der Fokus am Popover oder an einem Foto, geht er an die Kachel
  // derselben Zeile (ein Textfeld aus dem Popover steht wieder dort und behält ihn). Läuft, bevor die Vorschau Ebene und
  // Popover abbaut (gallery-preview.js, fail).
  preview.onFail(function () {
    const active = rootOf().activeElement;
    const spot = spots.find(function (entry) { return entry.spot.contains(active); });
    const at = fallbackRow(popover && popover.element.contains(active) ? popover.row : null, spot ? spot.row : null, rows);
    closePopover(false);
    layer.replaceChildren();
    spots = [];
    note.hidden = true;
    gallery.grid.hidden = false;
    if (at === null) return;
    const tile = gallery.element(at);
    (tile.contains(active) ? active : tile.querySelector('button')).focus({ preventScroll: true });
  });
  preview.onClose(function () {
    closePopover(false);
    marked.forEach(function (timer) { clearTimeout(timer); });
    marked.clear();
  });
  // Pflicht-Textfeld leer: Popover dieser Zeile öffnen, damit der Browser die Meldung am Feld zeigen kann.
  ctx.beforeCheck.push(function () {
    if (preview.failed()) return;
    const row = rows.find(function (item) { return item.captions.some(function (caption) { return !caption.input.checkValidity(); }); });
    if (row && !(popover && popover.row === row)) openPopover(row);
  });
}
