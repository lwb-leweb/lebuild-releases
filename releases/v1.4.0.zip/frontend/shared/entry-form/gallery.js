import { imagePicker, uploadImage, imageAccept, draggingFiles } from '../upload.js';
import { framingSource, FRAMING_TEXT } from '../image-framing.js';
import { editorButton } from '../buttons.js';
import { symbolButton } from '../icons.js';
import { dragHandle } from '../drag-sort.js';
import { ENTRY_TEXT, fieldLabel } from './text.js';
import { fieldBox, openImageFraming, storedFocus } from './inputs.js';
import { sortRows } from './sort-rows.js';
import { galleryControls } from './gallery-controls.js';

// Bildraster: eine list mit genau einem image-Unterfeld und sonst nur Texten erscheint als Kacheln (galleryField).

// Bildfeld einer list, die als Raster erscheint (galleryField): genau ein image-Unterfeld, sonst nur Texte.
export function galleryImage(field) {
  const subs = Array.isArray(field.fields) ? field.fields : [];
  const images = subs.filter(function (sub) { return sub.type === 'image'; });
  const plain = subs.every(function (sub) { return sub.type === 'image' || sub.type === 'text'; });
  return images.length === 1 && plain ? images[0] : null;
}

// list mit Bildern (galleryImage) als Raster: je Zeile eine Kachel mit Bild (Klick ersetzt es), kleinen Textfeldern für
// die übrigen Unterfelder, Ausschnitt (Zuschnitt und Fokuspunkt, openImageFraming) und Entfernen; ein neues Bild leert
// den Fokuspunkt. Die ganze Kachel außer ihren Textfeldern lässt sich ziehen, Alt+Pfeil an ihren Knöpfen verschiebt sie
// (sortRows); der Ziehpunkt oben links zeigt es beim Zeigen. size des Bildfelds gilt als höchste
// Anzeigebreite bei Upload und Zuschnitt. „+ … hinzufügen“
// und auf das Raster gezogene Dateien laden mehrere Bilder auf einmal hoch (höchstens field.max Zeilen),
// jedes wird eine Zeile. Änderungen melden sich als input am Formular; read() wie listField.
// Mit Vorschau der Seite (ctx.preview für dieses Feld, gallery-preview.js) steht statt der Kacheln die Galerie der Seite
// mit ihrer Bedienung (gallery-controls.js) auf denselben Zeilen; das Raster erscheint nur, wenn die Vorschau nicht lädt.
export function galleryField(field, value, ctx, imageSub) {
  const look = ctx.look;
  const box = fieldBox(look, field, 'div');
  const grid = document.createElement('div');
  grid.className = look.gallery;
  const texts = field.fields.filter(function (sub) { return sub !== imageSub; });
  const max = Number(field.max) > 0 ? Number(field.max) : Infinity;
  const rows = [];
  const changed = function () { grid.dispatchEvent(new Event('input', { bubbles: true })); };
  const refresh = function () { add.hidden = rows.length >= max; };
  const addTile = function (values) {
    const tile = document.createElement('div');
    tile.className = look.galleryTile;
    const focus = storedFocus(imageSub, values);
    const row = { tile: tile, image: values && values[imageSub.name] ? String(values[imageSub.name]) : '', focus: focus == null ? '' : String(focus), captions: [] };
    const media = editorButton('', look.galleryMedia, function () { row.pick(); });
    const img = document.createElement('img');
    img.alt = '';
    img.loading = 'lazy';
    const missing = document.createElement('span');
    missing.textContent = ENTRY_TEXT.imageMissing;
    media.append(img, missing);
    row.missing = missing;
    row.show = function () {
      img.hidden = !row.image;
      missing.hidden = Boolean(row.image);
      if (row.image) img.src = row.image;
      crop.hidden = !framingSource(row.image);
      media.title = row.image ? ENTRY_TEXT.imageReplace : ENTRY_TEXT.imageMissing;
      media.setAttribute('aria-label', media.title);
    };
    const replace = imagePicker(function (url) {
      row.image = url;
      row.focus = '';
      row.show();
      changed();
    }, ctx.notify, look.picker, ctx.uploads, imageSub.size);
    replace.element.hidden = true;
    // Ersetzen (Dateiauswahl) und Ausschnitt (Ebene neben near): Kachel und Popover der Vorschau.
    row.pick = function () { replace.input.click(); };
    row.frame = function (near) {
      openImageFraming(imageSub, ctx, near, row.image, row.focus, function (result) {
        row.image = result.url;
        row.focus = result.focus;
        row.show();
        changed();
      });
    };
    // Nur ein Zeichen: Gezogen wird die ganze Kachel, per Tastatur an ihren Knöpfen (kein eigener Tab-Halt).
    const grip = dragHandle(look.iconButton + ' ' + look.galleryHandle);
    grip.tabIndex = -1;
    tile.append(media, grip, replace.element);
    texts.forEach(function (sub) {
      const input = document.createElement('input');
      input.type = 'text';
      input.name = sub.name;
      input.className = look.galleryCaption;
      input.placeholder = fieldLabel(sub);
      input.setAttribute('aria-label', fieldLabel(sub));
      input.value = values && values[sub.name] != null ? String(values[sub.name]) : '';
      if (sub.required) input.required = true;
      row.captions.push({ field: sub, input: input });
      tile.appendChild(input);
    });
    const actions = document.createElement('div');
    actions.className = look.galleryActions;
    row.remove = function () {
      const index = rows.indexOf(row);
      if (index === -1) return;
      rows.splice(index, 1);
      tile.remove();
      refresh();
      changed();
    };
    const crop = symbolButton('crop', FRAMING_TEXT.title, look.iconButton, function () { row.frame(crop); });
    actions.append(crop, symbolButton('trash', ENTRY_TEXT.imageRemove, look.iconButton, function () {
      const index = rows.indexOf(row);
      row.remove();
      const next = rows[index] || rows[index - 1];
      (next ? next.tile.querySelector('button') : add).focus();
    }));
    tile.appendChild(actions);
    row.show();
    rows.push(row);
    grid.appendChild(tile);
    refresh();
    return row;
  };
  // Mehrere Dateien: je eine Kachel, die bis zum Upload wartet; scheitert er, fällt sie weg (Meldung über notify).
  const uploadFiles = function (files) {
    const free = max - rows.length;
    const name = fieldLabel(field);
    if (files.length > free) ctx.notify(ENTRY_TEXT.imagesTooMany.replace('{max}', String(max)).replace('{name}', function () { return name; }));
    const jobs = files.slice(0, Math.max(free, 0)).map(function (file) {
      const row = addTile(null);
      row.tile.classList.add(look.galleryPending);
      row.missing.textContent = ENTRY_TEXT.imageUploading;
      return uploadImage(file, ctx.notify, ctx.uploads, { quiet: true, maxWidth: imageSub.size }).then(function (url) {
        row.image = url;
        row.tile.classList.remove(look.galleryPending);
        row.show();
        changed();
      }, function (error) {
        row.remove();
        throw error;
      });
    });
    if (!jobs.length) return;
    changed();
    Promise.allSettled(jobs).then(function (results) {
      const done = results.filter(function (result) { return result.status === 'fulfilled'; }).length;
      if (done) ctx.notify(ENTRY_TEXT.imagesUploaded.replace('{count}', String(done)));
    });
  };
  // Knopf (per Tastatur erreichbar), der die versteckte Dateiauswahl öffnet.
  const many = document.createElement('input');
  many.type = 'file';
  many.multiple = true;
  many.accept = imageAccept();
  many.hidden = true;
  many.addEventListener('change', function () {
    const files = Array.from(many.files || []);
    many.value = '';
    uploadFiles(files);
  });
  const add = editorButton(ENTRY_TEXT.addImages.replace('{name}', function () { return fieldLabel(field); }), look.picker, function () { many.click(); });
  // Dateien auf das Raster bzw. die Vorschau ziehen (Zähler wie imageDropArea: Kinder melden dragleave am Rahmen).
  const takeFiles = function (target, activeClass) {
    let depth = 0;
    target.addEventListener('dragenter', function (event) {
      if (!draggingFiles(event)) return;
      event.preventDefault();
      if (++depth === 1) target.classList.add(activeClass);
    });
    target.addEventListener('dragover', function (event) {
      if (!draggingFiles(event)) return;
      event.preventDefault();
      event.dataTransfer.dropEffect = 'copy';
    });
    target.addEventListener('dragleave', function () {
      if (depth > 0 && --depth === 0) target.classList.remove(activeClass);
    });
    target.addEventListener('drop', function (event) {
      if (!draggingFiles(event)) return;
      event.preventDefault();
      depth = 0;
      target.classList.remove(activeClass);
      uploadFiles(Array.from(event.dataTransfer.files));
    });
  };
  takeFiles(grid, look.galleryActive);
  const tileOf = function (row) { return row.tile; };
  const label = function () { return fieldLabel(imageSub); };
  sortRows(grid, rows, ctx, {
    handle: false,
    element: tileOf,
    label: label,
    changed: changed
  });
  (Array.isArray(value) ? value : []).forEach(addTile);
  // Vorschau der Seite (nur das erste Raster im Seitenpanel einer Einzelansicht, buildEntryForm) statt der Kacheln.
  // „+ … hinzufügen“ dann im Kopf der Vorschau, vor den Breiten (gleich zu sehen, in der Tab-Reihenfolge vor den Fotos), beim
  // Rückfall wieder unter dem Raster.
  box.append(grid, add, many);
  if (ctx.preview && ctx.preview.field === field) {
    box.insertBefore(ctx.preview.box, grid);
    ctx.preview.head.prepend(add);
    ctx.preview.onFail(function () { grid.after(add); });
    takeFiles(ctx.preview.scroller, look.preview.stageActive);
    galleryControls(ctx.preview, { field: field, imageSub: imageSub, rows: rows, grid: grid, ctx: ctx, element: tileOf, label: label, changed: changed });
  }
  refresh();
  return {
    box: box,
    input: null,
    read: function () {
      return rows.map(function (row) {
        const data = {};
        data[imageSub.name] = row.image;
        // Fokuspunkt immer mit, wie readField.
        data[imageSub.focusField] = row.focus;
        row.captions.forEach(function (caption) { data[caption.field.name] = caption.input.value; });
        return data;
      });
    }
  };
}
