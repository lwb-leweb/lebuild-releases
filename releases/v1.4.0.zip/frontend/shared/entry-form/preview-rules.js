// Regeln der Vorschau einer Galerie im Seitenpanel (gallery-preview.js, gallery-controls.js): wann sie neu rendert, welche
// Zeilen sie schickt, welches Bild zu welcher Zeile gehört, Maßstab und Lage im Panel, sichtbare Höhe und Scrollen des
// Rahmens, was darin ausgeblendet ist, Neu-Rendern nach verlorener Anmeldung, Format eines Fotos, Platz des Popovers, Gleiten und Neu-Zeichnen der Bedienung, neue Fotos und Fokus beim Rückfall. Ohne Importe und ohne DOM, damit node sie prüfen kann (tests/frontend/gallery-preview.test.php).

// So lange (ms) wartet die Vorschau nach einem Tastendruck, bevor sie neu rendert; jede andere Änderung rendert sofort.
export const TYPING_DELAY = 300;
// Antwort von preview bei ungültigen Werten (wie save.php): Die letzte Vorschau bleibt, gemeldet wird erst beim Speichern.
export const INVALID_STATUS = 400;
// Eingaben, bei denen input eine Wahl ist, kein Tippen.
const CHOICE_INPUT_TYPES = ['checkbox', 'radio', 'file'];
// Wert von data-le-row: Stelle unter den geschickten Zeilen.
const ROW_PATTERN = /^(0|[1-9][0-9]*)$/;
// Bis zu dieser Abweichung (px) zählt ein Vorfahr eines Bildes als dieselbe Fläche (cardOf).
const CARD_TOLERANCE = 1;
// Übliche Formate eines Fotos ([Breite, Höhe] quer; hoch umgekehrt), erkannt bis RATIO_TOLERANCE Abweichung (Anteil).
const PHOTO_RATIOS = [[1, 1], [5, 4], [4, 3], [3, 2], [16, 9]];
const RATIO_TOLERANCE = 0.02;
// Form eines Fotos (photoShape; Texte in ENTRY_TEXT.photoShapes).
export const PHOTO_SHAPES = { square: 'square', landscape: 'landscape', portrait: 'portrait' };
// Lage von Elementen, die beim Scrollen im Fenster stehen bleiben und über der Galerie lägen (hidesOverlay).
const OVERLAY_POSITIONS = ['fixed', 'sticky'];
// Neu rendern nach verlorener Anmeldung (authRetry): gleich bzw., sobald das Fenster wieder den Fokus hat.
export const AUTH_RETRY = { now: 'now', focus: 'focus' };
// So lange (ms) ist ein neu hinzugekommenes Foto markiert, über jedes neue Zeichnen der Bedienung hinweg.
export const NEW_PHOTO_MARK = 1400;

// Wartezeit (ms) bis zum Rendern nach dem input-Ereignis event: TYPING_DELAY, wenn jemand tippt (Text-, Zahlen- oder
// Datumsfeld, mehrzeiliges Feld, Texteditor), sonst 0. Vom Formular selbst ausgelöste Ereignisse (Raster sortiert, Bild
// hochgeladen, isTrusted false) sind kein Tippen.
export function previewDelay(event) {
  const target = event.target || {};
  if (!event.isTrusted) return 0;
  if (target.isContentEditable || target.tagName === 'TEXTAREA') return TYPING_DELAY;
  return target.tagName === 'INPUT' && CHOICE_INPUT_TYPES.indexOf(target.type) === -1 ? TYPING_DELAY : 0;
}

// Bleibt die letzte Vorschau nach dem Fehler error stehen? Bei ungültigen Werten (INVALID_STATUS) und bei abgelaufener
// oder erneuerter Anmeldung (authLost, isAuthLost in request.js: der nächste Aufruf holt das neue Token); sonst lädt die
// Vorschau nicht.
export function keepsPreview(error, authLost) {
  return Boolean(error) && (error.status === INVALID_STATUS || Boolean(authLost));
}

// Anfrage für die Werte data des Formulars und das Galerie-Feld field (Bildfeld imageName): Es gehen nur Zeilen mit Bild
// mit (eine ohne, etwa beim Hochladen, wäre am Server ein leeres Pflichtfeld). Liefert { data, indexes, empty }: data mit
// diesen Zeilen, indexes[i] = Stelle der i-ten geschickten Zeile im Formular, empty = ohne Bild bei Pflichtfeld (dann
// fragt die Vorschau nicht, die Galerie ist leer).
export function previewRequest(data, field, imageName) {
  const rows = Array.isArray(data[field.name]) ? data[field.name] : [];
  const sent = [];
  const indexes = [];
  rows.forEach(function (row, index) {
    if (!row || !row[imageName]) return;
    sent.push(row);
    indexes.push(index);
  });
  const request = Object.assign({}, data);
  request[field.name] = sent;
  return { data: request, indexes: indexes, empty: Boolean(field.required) && sent.length === 0 };
}

// Zeile im Formular zum Wert value von data-le-row an einem Bild der Vorschau (indexes aus previewRequest der Antwort,
// die gerade zu sehen ist); null, wenn er keine Stelle unter den geschickten Zeilen ist.
export function formRow(indexes, value) {
  if (typeof value !== 'string' || !ROW_PATTERN.test(value)) return null;
  const at = Number(value);
  return at < indexes.length ? indexes[at] : null;
}

// Stelle der Zeile jetzt: index ist ihre Stelle beim Rendern (formRow), before die Zeilen von damals (Kopie), rows die
// Zeilen jetzt (umgeordnet, entfernt). null, wenn es sie nicht mehr gibt oder index null ist.
export function liveRow(before, rows, index) {
  if (index === null) return null;
  const at = rows.indexOf(before[index]);
  return at === -1 ? null : at;
}

// Karte eines Bildes der Vorschau: der äußerste Vorfahr unter root mit derselben Fläche wie das Bild (bei card.php die
// figure mit Bild und Bildtext), sonst das Bild selbst. Sie wird gezogen, gleitet und trägt die Bedienung.
export function cardOf(image, root) {
  const box = image.getBoundingClientRect();
  let card = image;
  for (let up = card.parentElement; up && up !== root && sameBox(up.getBoundingClientRect(), box); up = up.parentElement) card = up;
  return card;
}

function sameBox(a, b) {
  return ['left', 'top', 'width', 'height'].every(function (side) { return Math.abs(a[side] - b[side]) <= CARD_TOLERANCE; });
}

// Form eines Fotos mit width × height px (natürliche Größe): { shape (PHOTO_SHAPES), ratio ([Breite, Höhe] eines
// üblichen Formats oder null) }; null ohne Größe (noch nicht geladen).
export function photoShape(width, height) {
  if (!(width > 0 && height > 0)) return null;
  const ratio = width / height;
  const near = function (value) { return Math.abs(ratio - value) / value <= RATIO_TOLERANCE; };
  const shape = near(1) ? PHOTO_SHAPES.square : (ratio > 1 ? PHOTO_SHAPES.landscape : PHOTO_SHAPES.portrait);
  const found = PHOTO_RATIOS.map(function (pair) { return ratio < 1 ? [pair[1], pair[0]] : pair; }).find(function (pair) { return near(pair[0] / pair[1]); });
  return { shape: shape, ratio: found || null };
}

// Platz des Popovers (size: width, height) an einem Bild (anchor: left, top, width, height) im sichtbaren Teil view (left,
// top, right, bottom) der Vorschau, alles im selben Bezug, Abstand gap: mittig unter dem Bild, passt es dort nicht, darüber;
// sonst neben dem Bild (rechts, dann links), solange es zu sehen ist, damit es das Bild nicht verdeckt (hohes Foto, auch
// nach „Ersetzen“); sonst so nah wie möglich im sichtbaren Teil (auch, wenn das Bild weggescrollt ist); nie über den linken
// oder oberen Rand. Liefert { left, top }.
export function popoverPlace(anchor, size, view, gap) {
  const fits = function (top) { return top >= view.top + gap && top + size.height <= view.bottom - gap; };
  const fitsBeside = function (left) { return left >= view.left + gap && left + size.width <= view.right - gap; };
  const below = anchor.top + anchor.height + gap;
  const above = anchor.top - gap - size.height;
  const centered = within(anchor.left + (anchor.width - size.width) / 2, view.left + gap, view.right - gap - size.width);
  const near = within(anchor.top + gap, view.top + gap, view.bottom - gap - size.height);
  if (fits(below)) return { left: centered, top: below };
  if (fits(above)) return { left: centered, top: above };
  const shown = anchor.top < view.bottom && anchor.top + anchor.height > view.top;
  const right = anchor.left + anchor.width + gap;
  const left = anchor.left - gap - size.width;
  if (shown && fitsBeside(right)) return { left: right, top: near };
  if (shown && fitsBeside(left)) return { left: left, top: near };
  return { left: centered, top: near };
}

// value zwischen min und max; reicht der Platz nicht, gilt min.
function within(value, min, max) {
  return Math.max(min, Math.min(value, max));
}

// Maßstab und Lage des Ausschnitts: Das Element (el, Rahmen in der Seite: left, top, width, height) passt in die Breite
// avail des Panels, nie größer als auf der Seite, schmaler mittig. Liefert { scale, x (Abstand des Ausschnitts links),
// width, height (Ausschnitt im Panel), frameLeft, frameTop (Lage des Rahmens im Ausschnitt, damit das Element bei 0, 0
// steht) }; ohne Breite scale 0.
export function previewFit(avail, el) {
  const scale = avail > 0 && el.width > 0 ? Math.min(1, avail / el.width) : 0;
  return {
    scale: scale,
    x: Math.max(0, (avail - el.width * scale) / 2),
    width: el.width * scale,
    height: el.height * scale,
    frameLeft: -el.left * scale,
    frameTop: -el.top * scale
  };
}

// Rechteck rect eines Bildes in der Seite im Maßstab des Panels (fit aus previewFit zum Element el), bezogen auf den
// Ausschnitt und die Ebene darüber: { left, top, width, height }.
export function previewRect(fit, el, rect) {
  return {
    left: (rect.left - el.left) * fit.scale,
    top: (rect.top - el.top) * fit.scale,
    width: rect.width * fit.scale,
    height: rect.height * fit.scale
  };
}

// Höchstens so hoch (px im Panel) darf der sichtbare Teil der Vorschau sein, damit er ins Fenster des Rahmens passt: Das
// Fenster ist immer so hoch wie das Gerät (size aus state.preview.widths, Maß für vh und Medienabfragen nach der Höhe),
// im Maßstab scale. Bei kleinem Maßstab (schmales Panel) scrollt die Vorschau also früher; null ohne Maßstab.
export function stageLimit(size, scale) {
  return scale > 0 ? size.height * scale : null;
}

// Ein Element im Rahmen der Vorschau ausblenden? style: sein berechneter Stil (position, zIndex), outside: liegt weder
// im Element der Einzelansicht noch um es. Nur feste und klebende Elemente außerhalb (Kopfleiste, Cookie-Hinweis), die
// über der Galerie lägen; was in ihr liegt, bleibt (auch eine fest positionierte Hintergrund-Ebene), ebenso Ebenen
// hinter dem Inhalt (z-index negativ) und Hintergründe mit background-attachment: fixed (keine eigene Lage).
export function hidesOverlay(style, outside) {
  if (!outside || OVERLAY_POSITIONS.indexOf(style.position) === -1) return false;
  return !(parseInt(style.zIndex, 10) < 0);
}

// Meldet die Vorschau einen Fehler, bei dem sie stehen bleibt (keepsPreview), über notify? Nur eine verlorene Anmeldung
// (authLost), außer beim Rendern ohne Meldung (quiet: Öffnen, Fokus zurück) nach einem zweiten Versuch (retried). Ungültige
// Werte (INVALID_STATUS) meldet erst check() bzw. Speichern wie im übrigen Formular, nicht schon beim Tippen; nach der
// Korrektur steht so auch nichts mehr da.
export function showsError(authLost, quiet, retried) {
  return Boolean(authLost) && !(quiet && retried);
}

// Feste und klebende Elemente im Rahmen neu prüfen (hidesOverlay für jedes Element der Seite)? Bei neuer Lage (moved: Inhalt,
// Breite, Größe) und wenn sich die Seite seit der letzten Prüfung geändert hat (changed: Klasse, Stil, neue Elemente); beim
// bloßen Scrollen einer unveränderten Seite nicht.
export function checksOverlays(moved, changed) {
  return Boolean(moved || changed);
}

// Wann die Vorschau nach einem Fehler von selbst neu rendert (AUTH_RETRY), null: nicht. authLost: Anmeldung abgelaufen
// oder erneuert (isAuthLost in request.js), renewed: erneuert (403 CSRF; der nächste Aufruf holt das neue Token), retried:
// war schon ein Versuch danach. Erneuert gleich einmal, sonst, sobald das Fenster wieder den Fokus hat (zurück von
// „Neu anmelden“ im neuen Tab).
export function authRetry(authLost, renewed, retried) {
  if (!authLost) return null;
  return renewed && !retried ? AUTH_RETRY.now : AUTH_RETRY.focus;
}

// Neue Antwort für die Bedienung? Eine der Karten cards ist nicht unter den gezeichneten (drawn, mit has).
export function freshCards(cards, drawn) {
  return cards.some(function (card) { return !drawn.has(card); });
}

// Nach einer neuen Lage (onRender) die Flächen gleich neu messen und zeichnen? Nicht, solange dieselben Karten noch gleiten
// (gliding, fresh aus freshCards): gemessen lägen sie am Versatz. Die gezeichneten Flächen gleiten mit und bleiben bedienbar.
export function drawsNow(gliding, fresh) {
  return !gliding || fresh;
}

// Am Ende eines Gleitens neu zeichnen? Nur am Ende des letzten (latest: kein neueres hat es abgelöst), wenn inzwischen eine
// neue Lage kam, die drawsNow zurückgestellt hat (redraw), und die Vorschau nicht zurückgefallen ist (failed).
export function redrawsAfterGlide(latest, redraw, failed) {
  return latest && redraw && !failed;
}

// Von wo Karte und Fläche der Zeile row gleiten: ihr Rechteck vor dem Umordnen oder Entfernen (before: Zeile → Rechteck, null
// ohne), nur mit einer neuen Antwort (fresh); null, wenn sie nicht gleitet.
export function glideFrom(fresh, before, row) {
  return fresh && before && before.has(row) ? before.get(row) : null;
}

// Neues Foto (NEW_PHOTO_MARK ms markiert ab dem ersten Zeichnen)? Die Zeile row war beim Öffnen nicht da (initial) und war
// noch nie zu sehen (seen).
export function isNewPhoto(row, initial, seen) {
  return !initial.has(row) && !seen.has(row);
}

// Zeile, deren Kachel beim Rückfall aufs Raster den Fokus bekommt: popoverRow ist die Zeile des Popovers, wenn der Fokus
// darin liegt, spotRow die Zeile der Fläche mit dem Fokus (sonst je null), rows die Zeilen jetzt. null: Der Fokus lag nicht
// in der Vorschau, oder die Zeile ist inzwischen entfernt.
export function fallbackRow(popoverRow, spotRow, rows) {
  const row = popoverRow !== null ? popoverRow : spotRow;
  return row !== null && rows.indexOf(row) !== -1 ? row : null;
}

// Wohin das Fenster des Rahmens scrollt (Seiten-px), damit es den sichtbaren Teil der Vorschau zeigt: Oberkante des
// Elements in der Seite (top) plus das, was von der verkleinerten Galerie oben aus dem Panel gescrollt ist (scrolled, px
// im Panel), im Maßstab der Seite. Ohne Maßstab die Oberkante.
export function frameScroll(top, scrolled, scale) {
  return scale > 0 ? top + Math.max(0, scrolled) / scale : top;
}
