// Werte für einen neuen Eintrag als Kopie eines bestehenden (Kopieren auf der Seite und in der Verwaltung). Ohne Importe
// und ohne DOM, damit node es prüfen kann (tests/frontend/entry-copy.test.php).

// Kennung und Stand des Originals: Die Kopie ist ein neuer Eintrag.
const COPY_DROPPED_KEYS = ['id', 'version'];
// Feldarten, deren Wert die Kopie nie übernimmt: Die Adresse entsteht beim Speichern neu aus ihrem Quellfeld.
const COPY_DROPPED_TYPES = ['slug'];

// Startwerte der Kopie von row: der ganze Eintrag ohne id, version, Felder aus COPY_DROPPED_TYPES und Felder mit
// copy: false (nur oberste Ebene, plugins/ref-field-types.md), diese samt ihrem Fokuspunkt (focusField). Geht vom Eintrag
// aus, nicht vom Schema, damit Zusatzwerte wie <feld>_focus bleiben. Fehlende Felder starten im Formular mit default.
// Tief kopiert (structuredClone): Zeilen, Blöcke und Bildraster der Kopie teilen nichts mit row, row bleibt unverändert.
export function copyValues(schema, row) {
  const dropped = COPY_DROPPED_KEYS.slice();
  schema.forEach(function (field) {
    if (COPY_DROPPED_TYPES.indexOf(field.type) === -1 && field.copy !== false) return;
    dropped.push(field.name);
    if (field.focusField) dropped.push(field.focusField);
  });
  const values = {};
  Object.keys(row).forEach(function (key) {
    if (dropped.indexOf(key) === -1) values[key] = structuredClone(row[key]);
  });
  return values;
}
