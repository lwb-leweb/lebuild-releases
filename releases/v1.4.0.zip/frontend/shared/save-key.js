// Strg+S bzw. ⌘S speichert, im Seiten-Editor (main.js) und in der Verwaltung (app/js/save-button.js).
// Den Dialog „Seite speichern unter“ des Browsers gibt es dort nie, auch wenn es nichts zu speichern
// gibt; was gespeichert wird (und ob überhaupt), entscheidet fn. Ein Speichern, das schon läuft,
// fängt fn ab (Knopf gesperrt bzw. eigener Merker); gehaltene Tasten zählen nur einmal.
// Capture am window: Der Zuhörer kommt vor allen anderen dran, auch bei Tasten aus dem Shadow-DOM, aus
// einem Text in Bearbeitung oder dem Texteditor (interact.js stoppt dort nur die Weitergabe an die
// Seite, nicht weitere Zuhörer am window).
export function onSaveKey(fn) {
  window.addEventListener('keydown', function (event) {
    if (!isSaveKey(event)) return;
    event.preventDefault();
    if (!event.repeat && !held()) fn();
  }, true);
}

// Dialoge mit eigener Übernahme (Ebene „Ausschnitt“ über dem Eintragsformular): Solange einer nicht übernommene Änderungen hat,
// speichert Strg+S nicht daran vorbei. hold() liefert dann true und fragt selbst nach (wie ×); sonst false. Liefert die
// Funktion zum Lösen.
const holds = new Set();

export function holdSaveKey(hold) {
  holds.add(hold);
  return function () { holds.delete(hold); };
}

function held() {
  return Array.from(holds).some(function (hold) { return hold(); });
}

// Nur Strg/⌘ mit S: Alt (auch AltGr) und Umschalt bleiben beim Browser.
function isSaveKey(event) {
  return (event.ctrlKey || event.metaKey) && !event.altKey && !event.shiftKey && typeof event.key === 'string' && event.key.toLowerCase() === 's';
}
