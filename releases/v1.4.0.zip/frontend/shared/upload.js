import { state } from './core.js';
import { editorApi, editorPost, errorNotice } from './request.js';
import { ENDPOINTS } from './endpoints.js';
import { createHolds, createWait } from './pending.js';

const UPLOAD_TEXT = {
  done: 'Bild hochgeladen.',
  fileDone: 'Datei hochgeladen.',
  choose: 'Bild auswählen',
  chooseFile: 'PDF auswählen',
  drop: 'Bild hierher ziehen oder klicken',
  running: 'Das Bild wird noch hochgeladen.',
  cropping: 'Der Zuschnitt wird noch berechnet.',
  slow: 'Der Zuschnitt dauert zu lange. Bitte gleich noch einmal versuchen.'
};

// Laufende Uploads dieser Oberfläche (Panel „Bild“, „Alle Texte“, Formular für Plugin-Einträge).
let running = 0;
// Ausstehende Zuschnitte (holdUpload), auf die Speichern und Übernehmen höchstens SETTLE_TIMEOUT ms warten (settledAction).
const crops = createHolds();
const SETTLE_TIMEOUT = 30000;
// Zufallsbytes der Formular-Kennung (LE_UPLOAD_FORM_PATTERN in backend/media/openUploads.php: 16–64 Zeichen, hier 32 hex).
const FORM_ID_BYTES = 16;
// Formulare, über die schon hochgeladen und die noch nicht geschlossen wurden.
const openForms = new Set();

// Erledigt die offenen Uploads des Formulars id (mit urls nur diese), auch beim Verlassen der Seite
// (keepalive); scheitert es, räumt der Server sie nach seiner Frist weg.
function discard(id, urls) {
  editorPost(ENDPOINTS.media.discardUploads, { form: id, urls: urls }, { keepalive: true }).catch(function () { /* Frist auf dem Server */ });
}

// Formular, das Bilder hochlädt (Eintragsformular, Seiten-Editor): Seine Uploads führt der Server als
// offen, bis close() sie erledigt: Was nicht gespeichert ist, löscht er, Gespeichertes bleibt. close()
// nach Speichern und nach Verwerfen aufrufen, close(urls) erledigt nur diese (Panel „Bild“). Beim
// Verlassen der Seite schließen sich alle noch offenen Formulare.
export function uploadForm() {
  const bytes = window.crypto.getRandomValues(new Uint8Array(FORM_ID_BYTES));
  const form = {
    id: Array.from(bytes, function (byte) { return byte.toString(16).padStart(2, '0'); }).join(''),
    closed: false,
    close: function (urls) {
      if (!urls) form.closed = true;
      if (!openForms.has(form) || (urls && !urls.length)) return;
      if (!urls) openForms.delete(form);
      discard(form.id, urls);
    }
  };
  return form;
}

// Zurück aus dem Cache des Browsers (persisted) geht es mit denselben Formularen weiter.
window.addEventListener('pagehide', function (event) {
  if (event.persisted) return;
  Array.from(openForms).forEach(function (form) { form.close(); });
});

// Läuft noch ein Upload oder steht ein Zuschnitt aus, wird nicht übernommen oder gespeichert (das Bild käme sonst nicht
// mit): dann Hinweis über notify und true. Die eine Regel für Übernehmen, Speichern und Verlassen; wer auf Zuschnitte
// warten kann, wartet erst mit settledAction.
export function uploadPending(notify) {
  const busy = running > 0 || crops.count() > 0;
  if (busy && notify) notify(running > 0 ? UPLOAD_TEXT.running : UPLOAD_TEXT.cropping);
  return busy;
}

// Ein Zuschnitt, der gleich gerechnet wird (nach dem Loslassen, image-framing.js), zählt ab jetzt wie ein laufender
// Upload (uploadPending), bis release() kommt: einmal aufrufen, wenn sein Ergebnis eingetragen ist oder er entfällt.
export function holdUpload() {
  return crops.hold();
}

// Promise mit true, sobald kein Zuschnitt mehr aussteht (sofort, wenn keiner aussteht). Nach SETTLE_TIMEOUT false mit
// Hinweis über notify; der Gastgeber ist dann wieder bedienbar.
function uploadsSettled(notify) {
  return crops.settled(SETTLE_TIMEOUT).then(function (ok) {
    if (!ok) notify(UPLOAD_TEXT.slow);
    return ok;
  });
}

// Speichern bzw. Übernehmen, das auf ausstehende Zuschnitte wartet, statt abzulehnen (sie kommen dann mit): createWait mit
// uploadsSettled. run(then) wartet höchstens SETTLE_TIMEOUT und ruft then() nur, wenn keiner mehr aussteht; solange ist es
// gesperrt (ein zweites run zählt nicht), lock(busy) sperrt dazu den Knopf. Abbrechen bleibt frei. Ein laufender Upload
// lehnt danach in then() über uploadPending ab.
export function settledAction(notify, lock) {
  return createWait(function () { return uploadsSettled(notify); }, lock);
}

// accept der Dateiauswahl: erlaubte Endungen (upload_config) plus image/*, damit das Handy auch
// die Kamera anbietet (kein capture, sonst gäbe es nur die Kamera).
export function imageAccept() {
  return state.upload.extensions.map(function (ext) { return '.' + ext; }).concat('image/*').join(',');
}

// accept der Dateiauswahl eines Dateifeldes (Feldart file): Dokumente aus upload_config, z. B. .pdf.
export function fileAccept() {
  return state.upload.documents.map(function (ext) { return '.' + ext; }).join(',');
}

// Lädt ein Bild (oder mit options.doneText ein Dokument) über api/upload.php für das Formular form (uploadForm) hoch und liefert seine URL.
// notify ist die Hinweis-Funktion der jeweiligen Oberfläche (Erfolg und Fehler). Zu große Dateien lehnt
// schon der Browser ab, mit der Grenze und Meldung des Servers (upload_config: kleinste aus eigener
// Grenze und PHP-Konfiguration). Ist das Formular inzwischen geschlossen, wird das Bild gleich erledigt.
// options (optional): quiet (ohne Erfolgsmeldung, mehrere Bilder auf einmal melden sich gesammelt), doneText,
// maxWidth (höchste Anzeigebreite in CSS-Pixeln, data-le-size bzw. size im Schema; die Antwort ist dann die
// schmalere abgeleitete Datei, media/derived-images.md).
export function uploadImage(file, notify, form, options) {
  const opts = options || {};
  if (file.size > state.upload.maxBytes) {
    notify(state.upload.tooLarge);
    return Promise.reject(new Error(state.upload.tooLarge));
  }
  const formData = new FormData();
  formData.append('file', file);
  formData.append('form', form.id);
  // Aus einem Bildfeld nimmt der Server nur Bilder (le_upload_accept), ein Dokument fürs Dateifeld kommt mit doneText.
  if (!opts.doneText) formData.append('kind', state.upload.imageKind);
  if (opts.maxWidth) formData.append('maxWidth', String(opts.maxWidth));
  openForms.add(form);
  running++;
  return editorApi(ENDPOINTS.media.upload, { method: 'POST', body: formData }).then(function (data) {
    if (form.closed) discard(form.id, [data.url]);
    if (!opts.quiet) notify(opts.doneText || UPLOAD_TEXT.done);
    return data.url;
  }, function (error) {
    const notice = errorNotice(error);
    notify(notice.message, notice.action);
    throw error;
  }).finally(function () { running--; });
}

// Original und bisheriger Ausschnitt eines Bildes (api/imageInfo.php): { original (zum Anzeigen), address (dasselbe in
// der Form für den Bildwert), crop, width, originalWidth, originalHeight }, crop null bei einem Original. Einen Fehler zeigt der Aufrufer (errorNotice).
export function imageInfo(source) {
  return editorApi(ENDPOINTS.media.info + '?source=' + encodeURIComponent(source));
}

// Ausschnitt crop ({ x, y, w, h } in Pixeln des Originals, null = ganzes Bild) und Breite maxWidth (null = keine
// Angabe) aus dem Original info.address (imageInfo; die Form, in der es kam, der Server merkt sie sich) für das Formular
// form (api/imageDerive.php). Liefert { url, fresh }: fresh = neue Datei, ein offener Upload von form; sonst ist url das
// Original in dieser Form. Läuft wie ein Upload (uploadPending
// wartet darauf, form schließt sich beim Verlassen); ist form inzwischen geschlossen, wird die neue Datei gleich erledigt.
// Einen Fehler zeigt der Aufrufer (errorNotice).
export function deriveImage(form, info, crop, maxWidth) {
  const body = { source: info.address, form: form.id };
  if (crop) body.crop = crop;
  if (maxWidth) body.maxWidth = maxWidth;
  openForms.add(form);
  running++;
  return editorPost(ENDPOINTS.media.derive, body).then(function (data) {
    const fresh = data.url !== info.address;
    if (fresh && form.closed) discard(form.id, [data.url]);
    return { url: data.url, fresh: fresh };
  }).finally(function () { running--; });
}

// Lädt eine Datei hoch und gibt die URL an onUrl; bei zwei Dateien kurz nacheinander gilt die
// letzte, auch wenn die erste später fertig wird. options wie bei uploadImage.
function latestUpload(onUrl, notify, form, options) {
  let latest = 0;
  return function (file) {
    const choice = ++latest;
    uploadImage(file, notify, form, options)
      .then(function (url) {
        if (choice === latest) onUrl(url);
      })
      .catch(function () { /* Meldung kam über notify */ });
  };
}

// Knopf mit verstecktem Datei-Feld (Bild am Element, „Alle Texte“, Formular für Plugin-Einträge im
// Seiten-Editor und im Backend): Upload gleich bei Auswahl, onUrl(url) bekommt das hochgeladene
// Bild; solange er läuft, sperrt uploadPending Übernehmen und Speichern. notify, className und das
// Formular form (uploadForm) kommen von der jeweiligen Oberfläche, maxWidth (optional) wie bei uploadImage.
// upload(file) lädt eine abgelegte Datei auf demselben Weg hoch.
export function imagePicker(onUrl, notify, className, form, maxWidth) {
  const upload = latestUpload(onUrl, notify, form, { maxWidth: maxWidth });
  const label = document.createElement('label');
  label.className = className;
  label.textContent = UPLOAD_TEXT.choose;
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = imageAccept();
  input.hidden = true;
  input.addEventListener('change', function () {
    const file = input.files && input.files[0];
    input.value = '';
    if (file) upload(file);
  });
  label.appendChild(input);
  return { element: label, input: input, upload: upload };
}

// Wie imagePicker, für ein Dateifeld (PDF): Auswahl nur der Dokumente aus upload_config.
export function filePicker(onUrl, notify, className, form) {
  const upload = latestUpload(onUrl, notify, form, { doneText: UPLOAD_TEXT.fileDone });
  const label = document.createElement('label');
  label.className = className;
  label.textContent = UPLOAD_TEXT.chooseFile;
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = fileAccept();
  input.hidden = true;
  input.addEventListener('change', function () {
    const file = input.files && input.files[0];
    input.value = '';
    if (file) upload(file);
  });
  label.appendChild(input);
  return { element: label, input: input, upload: upload };
}

// Zieht jemand Dateien (nicht Text oder einen Link der Seite)?
export function draggingFiles(event) {
  return Boolean(event.dataTransfer) && Array.prototype.indexOf.call(event.dataTransfer.types, 'Files') !== -1;
}

// Dateien auf target ziehen (Ablagefläche, Bild im Ausschnitt): solange eine darüber ist, onActive(true), danach
// onActive(false); abgelegt bekommt onFile die erste Datei. Text oder Links der Seite bleiben unberührt (draggingFiles).
export function dropFiles(target, onActive, onFile) {
  // Zähler statt dragleave allein: Betreten eines Kindes (Vorschau) meldet dragleave am Rahmen.
  let depth = 0;
  target.addEventListener('dragenter', function (event) {
    if (!draggingFiles(event)) return;
    event.preventDefault();
    depth++;
    onActive(true);
  });
  target.addEventListener('dragover', function (event) {
    if (!draggingFiles(event)) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = 'copy';
  });
  target.addEventListener('dragleave', function () {
    if (depth > 0 && --depth === 0) onActive(false);
  });
  target.addEventListener('drop', function (event) {
    if (!draggingFiles(event)) return;
    event.preventDefault();
    depth = 0;
    onActive(false);
    const file = event.dataTransfer.files[0];
    if (file) onFile(file);
  });
}

// Ablagefläche eines Bildfeldes (Formular ohne Bild, „Alle Texte“): Vorschau bzw. Hinweis
// „Bild hierher ziehen oder klicken“. Klick öffnet die Dateiauswahl von picker, eine abgelegte Datei
// lädt picker.upload hoch; solange eine Datei darüber ist, trägt die Fläche classes.active.
// classes: { drop, active, image, empty }. Liefert { element, show(url) } (leere URL = Hinweis).
export function imageDropArea(picker, classes) {
  const area = document.createElement('div');
  area.className = classes.drop;
  const preview = document.createElement('img');
  preview.className = classes.image;
  preview.alt = '';
  const empty = document.createElement('div');
  empty.className = classes.empty;
  empty.textContent = UPLOAD_TEXT.drop;
  area.append(preview, empty);
  area.addEventListener('click', function () { picker.input.click(); });
  dropFiles(area, function (on) { area.classList.toggle(classes.active, on); }, picker.upload);
  return {
    element: area,
    show: function (url) {
      preview.hidden = !url;
      empty.hidden = Boolean(url);
      if (url) preview.src = url;
    }
  };
}
