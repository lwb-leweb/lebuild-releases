// Regeln des Bausteins „Ziehen zum Sortieren“ (drag-sort.js): wann Ziehen beginnt, Einfügestelle und Linie aus Zeiger und
// Rechtecken, Index nach dem Loslassen, Alt+Pfeil, Mitscrollen am Rand, Mausrad und Gleiten (FLIP). Ohne DOM und ohne
// Importe, damit sie sich für sich prüfen lassen (tests/frontend/drag-sort.test.php).
// Punkt: { x, y }; Rechteck: { left, top, right, bottom, width, height } wie getBoundingClientRect, alles in px des Fensters.

// Ab dieser Bewegung (px) zieht Maus oder Stift; darunter bleibt ein Klick ein Klick.
export const DRAG_SLOP = 6;
// So lange (ms) hält der Finger still, bevor er zieht; bewegt er sich vorher um DRAG_SLOP, scrollt die Seite.
export const DRAG_HOLD = 300;
// Weiter (px) vom nächsten Element zeigt sich keine Linie; Loslassen dort bricht ab.
export const DRAG_REACH = 80;
// Breite (px) des Rands eines scrollbaren Bereichs, an dem beim Ziehen mitgescrollt wird.
export const SCROLL_EDGE = 48;
// Je px tiefer im Rand ein Bruchteil davon an Schritt je Bild (ganz am Rand SCROLL_EDGE / SCROLL_DAMPING px).
const SCROLL_DAMPING = 4;
// Gleiten an den neuen Platz: Dauer (ms) und Verlauf.
export const FLIP_DURATION = 320;
export const FLIP_EASING = 'cubic-bezier(0.2, 0.7, 0.2, 1)';
// Mausrad in Zeilen (WheelEvent.deltaMode 1, Firefox mit Mausrad): px je Zeile.
export const WHEEL_LINE = 16;
// Einheiten des Mausrads (WheelEvent.deltaMode): Pixel, Zeilen, Seiten.
const WHEEL_MODE = { pixel: 0, line: 1, page: 2 };
// Maßstab eines Elements, das nicht verkleinert zu sehen ist (flipDelta).
const UNSCALED = 1;
// Phasen des Haltens am Touchgerät (holdState).
export const HOLD = { wait: 'wait', drag: 'drag', scroll: 'scroll' };
// Tasten für Alt+Pfeil: eine Stelle nach vorne bzw. hinten.
const KEY_STEPS = { ArrowLeft: -1, ArrowUp: -1, ArrowRight: 1, ArrowDown: 1 };

function distance(a, b) {
  return Math.hypot(b.x - a.x, b.y - a.y);
}

// Hat sich der Zeiger von start bis point so weit bewegt, dass Ziehen beginnt (bzw. am Touchgerät gescrollt wird)?
export function pastSlop(start, point) {
  return distance(start, point) >= DRAG_SLOP;
}

// Touch: nach elapsed ms und Bewegung von start bis point warten, ziehen oder (bewegt vor der Zeit) die Seite scrollen lassen.
export function holdState(elapsed, start, point) {
  if (pastSlop(start, point)) return HOLD.scroll;
  return elapsed >= DRAG_HOLD ? HOLD.drag : HOLD.wait;
}

// Abstand eines Punkts zu einem Rechteck, 0 darin.
function rectDistance(point, rect) {
  const dx = Math.max(rect.left - point.x, 0, point.x - rect.right);
  const dy = Math.max(rect.top - point.y, 0, point.y - rect.bottom);
  return Math.hypot(dx, dy);
}

// Stehen a und b in derselben Zeile? Ja, wenn die Mitte des einen in der Höhe des anderen liegt (auch ein großes Bild neben
// zwei kleinen übereinander).
export function sameRow(a, b) {
  const middle = function (r) { return (r.top + r.bottom) / 2; };
  const inside = function (y, r) { return y >= r.top && y <= r.bottom; };
  return inside(middle(a), b) || inside(middle(b), a);
}

// Freier Platz zwischen a und b nebeneinander bzw. untereinander (a vor b), 0 ohne.
function rowGap(a, b) {
  return a && b && sameRow(a, b) ? Math.max(0, b.left - a.right) : 0;
}

function columnGap(a, b) {
  return a && b && !sameRow(a, b) ? Math.max(0, b.top - a.bottom) : 0;
}

// Linie an der Einfügestelle vor (after false) bzw. hinter rect, mitten im Abstand zum Nachbarn; ohne Nachbarn auf der
// Seite so weit draußen wie auf der anderen. inRow: senkrecht (Elemente nebeneinander), sonst waagrecht.
// { x, y, length, vertical, gap }: Anfang der Linie, Länge nach unten (senkrecht) bzw. rechts (waagrecht) und Breite der
// Lücke, in deren Mitte sie steht (clipLine).
function gapLine(rect, prev, next, after, inRow) {
  if (inRow) {
    const other = after ? next : prev;
    const beside = other && sameRow(rect, other);
    const gap = (after ? rowGap(rect, next) : rowGap(prev, rect)) || (after ? rowGap(prev, rect) : rowGap(rect, next));
    const top = beside ? Math.max(rect.top, other.top) : rect.top;
    const bottom = beside ? Math.min(rect.bottom, other.bottom) : rect.bottom;
    return { x: after ? rect.right + gap / 2 : rect.left - gap / 2, y: top, length: bottom - top, vertical: true, gap: gap };
  }
  const gap = (after ? columnGap(rect, next) : columnGap(prev, rect)) || (after ? columnGap(prev, rect) : columnGap(rect, next));
  return { x: rect.left, y: after ? rect.bottom + gap / 2 : rect.top - gap / 2, length: rect.width, vertical: false, gap: gap };
}

// Einfügestelle für den Zeiger point über den Elementen mit den Rechtecken rects (in ihrer Reihenfolge), from = Index des
// gezogenen Elements. Am nächsten Element (höchstens DRAG_REACH entfernt): in einer Zeile mit einem Nachbarn entscheidet die
// linke bzw. rechte Hälfte, sonst die obere bzw. untere. Liefert { index, line } mit index = Lücke vor dem Element
// rects[index] (rects.length = am Ende) und line wie gapLine, oder null: zu weit weg oder neben dem gezogenen Element selbst.
export function dropPlace(point, rects, from) {
  let near = -1;
  let best = Infinity;
  rects.forEach(function (rect, index) {
    const d = rectDistance(point, rect);
    if (d < best) {
      best = d;
      near = index;
    }
  });
  if (near === -1 || best > DRAG_REACH) return null;
  const rect = rects[near];
  const prev = rects[near - 1];
  const next = rects[near + 1];
  const inRow = Boolean((prev && sameRow(prev, rect)) || (next && sameRow(rect, next)));
  const after = inRow ? point.x > (rect.left + rect.right) / 2 : point.y > (rect.top + rect.bottom) / 2;
  const index = near + (after ? 1 : 0);
  if (index === from || index === from + 1) return null;
  return { index: index, line: gapLine(rect, prev, next, after, inRow) };
}

// Linie, soweit sie im sichtbaren Teil box eines scrollbaren Bereichs liegt; null, wenn nichts davon. Liegt nur die Mitte
// der Lücke (line.gap) draußen, ihr Rand aber im Bereich (erste oder letzte Stelle einer Liste, die bündig scrollt), steht
// die Linie am Rand des Bereichs.
export function clipLine(line, box) {
  const start = Math.max(line.vertical ? line.y : line.x, line.vertical ? box.top : box.left);
  const end = Math.min((line.vertical ? line.y : line.x) + line.length, line.vertical ? box.bottom : box.right);
  const across = line.vertical ? line.x : line.y;
  const low = line.vertical ? box.left : box.top;
  const high = line.vertical ? box.right : box.bottom;
  const reach = (line.gap || 0) / 2;
  if (end <= start || across + reach < low || across - reach > high) return null;
  const at = Math.min(Math.max(across, low), high);
  return line.vertical ? { x: at, y: start, length: end - start, vertical: true } : { x: start, y: at, length: end - start, vertical: false };
}

// Neuer Index des gezogenen Elements (vorher from), abgelegt in der Lücke index (dropPlace).
export function dropIndex(from, index) {
  return index > from ? index - 1 : index;
}

// Alt+Pfeil: -1 (links, oben), 1 (rechts, unten), sonst 0.
export function keyStep(key, altKey) {
  return altKey ? KEY_STEPS[key] || 0 : 0;
}

// Ziel von from um step bei count Elementen; null am Rand (nichts verschiebt sich).
export function stepIndex(from, step, count) {
  const to = from + step;
  return step && to >= 0 && to < count ? to : null;
}

// Schritt (px je Bild) für die Lage pos im Bereich start bis end: im Rand SCROLL_EDGE zurück (negativ) bzw. weiter, tiefer
// im Rand schneller, außerhalb so schnell wie ganz am Rand; sonst 0.
export function edgeSpeed(pos, start, end) {
  const edge = Math.min(SCROLL_EDGE, (end - start) / 2);
  if (pos < start + edge) return -Math.min(start + edge - pos, edge) / SCROLL_DAMPING;
  if (pos > end - edge) return Math.min(pos - (end - edge), edge) / SCROLL_DAMPING;
  return 0;
}

// Schritt { x, y } für den Zeiger point am sichtbaren Teil box eines scrollbaren Bereichs: senkrecht nur, solange der Zeiger
// in seiner Breite ist, waagrecht nur in seiner Höhe.
export function edgeScroll(point, box) {
  return {
    x: point.y >= box.top && point.y <= box.bottom ? edgeSpeed(point.x, box.left, box.right) : 0,
    y: point.x >= box.left && point.x <= box.right ? edgeSpeed(point.y, box.top, box.bottom) : 0
  };
}

// Mitscrollen eines äußeren Bereichs (box: sein sichtbarer Teil) um step (edgeScroll), wenn der innere Bereich darin nicht
// mehr kann: nur so weit, wie vom inneren (inner: sein Rechteck im Fenster) in die Richtung noch etwas verdeckt ist. Ist
// er dort ganz zu sehen, schöbe das Scrollen nur die Elemente unter dem Zeiger weg (Vorschau im Panel, darunter weitere
// Felder). Liefert { x, y }.
export function revealStep(step, inner, box) {
  const along = function (value, low, high, boxLow, boxHigh) {
    if (value < 0) return Math.max(value, Math.min(0, low - boxLow));
    return value > 0 ? Math.min(value, Math.max(0, high - boxHigh)) : 0;
  };
  return { x: along(step.x, inner.left, inner.right, box.left, box.right), y: along(step.y, inner.top, inner.bottom, box.top, box.bottom) };
}

// Mausrad wheel ({ deltaX, deltaY, deltaMode }) beim Zeiger point: Schritt { x, y } in px für einen scrollbaren Bereich
// mit sichtbarem Teil box, wenn point darin liegt (sonst 0); Zeilen zu je WHEEL_LINE, Seiten so groß wie box.
export function wheelStep(point, box, wheel) {
  if (rectDistance(point, box) > 0) return { x: 0, y: 0 };
  const unit = function (page) {
    if (wheel.deltaMode === WHEEL_MODE.line) return WHEEL_LINE;
    return wheel.deltaMode === WHEEL_MODE.page ? page : 1;
  };
  return { x: wheel.deltaX * unit(box.right - box.left), y: wheel.deltaY * unit(box.bottom - box.top) };
}

// Sichtbarer Teil (left, top, right, bottom) im Fenster, in dem alle Rechtecke boxes liegen (scrollbare Bereiche von
// innen nach außen, etwa Vorschau und Körper des Panels zwischen Kopf und Fuß, zuletzt das Fenster): Dort bleiben Linie
// (clipLine) und Popover der Galerie-Vorschau. Leer: Höhe bzw. Breite 0.
export function visiblePart(boxes) {
  const part = boxes.reduce(function (inner, box) {
    return { left: Math.max(inner.left, box.left), top: Math.max(inner.top, box.top), right: Math.min(inner.right, box.right), bottom: Math.min(inner.bottom, box.bottom) };
  });
  return { left: part.left, top: part.top, right: Math.max(part.left, part.right), bottom: Math.max(part.top, part.bottom) };
}

// Gleiten (FLIP): Versatz und Maßstab, mit denen ein Element von seinem neuen Rechteck after aus am alten before beginnt;
// null, wenn es an seinem Platz geblieben ist. scale (optional): Maßstab, in dem das Element zu sehen ist (in einem mit
// transform: scale verkleinerten Rahmen, Rechtecke im Fenster); der Versatz gilt dann in px des Elements.
export function flipDelta(before, after, scale) {
  const shown = scale === undefined ? UNSCALED : scale;
  const delta = { dx: (before.left - after.left) / shown, dy: (before.top - after.top) / shown, sx: after.width ? before.width / after.width : 1, sy: after.height ? before.height / after.height : 1 };
  return delta.dx || delta.dy || delta.sx !== 1 || delta.sy !== 1 ? delta : null;
}
