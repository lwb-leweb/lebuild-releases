import { state } from './core.js';
import { editorApi } from './request.js';
import { ENDPOINTS } from './endpoints.js';
import { radiusPercent, measureUrls, fieldPlaces, imageFit } from './framing-geometry.js';
import { withinTime } from './pending.js';

// Messen, wie ein Bild auf der Website sitzt (Vorschauen im Ausschnitt, image-framing.js): Die Seite lädt
// unsichtbar in je einem iframe pro Breite aus state.preview.widths, als Messseite ohne Editor (state.preview
// measureParam/measureValue); das <img> eines Bildfelds trägt state.preview.fieldAttr mit <typ><fieldSeparator><feld>; gelesen werden Größe, object-fit (bzw. background-size) und Rundung des gerenderten Bildes
// bzw. Elements mit Hintergrundbild und ob der Rahmen dem Bild folgt.

// Unsichtbares iframe (image-framing.css), Breite je Messung im Stil.
const MEASURE_CLASS = 'le-framing__measure';
// So lange (ms) darf eine Seite samt Bild laden, sonst gilt die Breite als nicht gemessen; ebenso lange die Stellen aus
// imageUsage (usagePlaces) und das Laden der Vorschau einer Galerie (entry-form/gallery-preview.js).
export const MEASURE_TIMEOUT = 8000;
// Berechnete Rundung der vier Ecken in der Reihenfolge von border-radius.
const RADIUS_CORNERS = ['borderTopLeftRadius', 'borderTopRightRadius', 'borderBottomRightRadius', 'borderBottomLeftRadius'];
// Ein Element um das Bild gilt als sein Rahmen, solange es höchstens so viele CSS-Pixel größer ist (Rundung am Rahmen);
// ebenso viel darf sich der Rahmen mit dem Probebild ändern, ohne dass er als dem Bild folgend gilt.
const SAME_BOX = 1;
// Probebild in einem deutlich anderen Seitenverhältnis: Ändert der Rahmen damit seine Form (Höhe auto), folgt er dem Bild.
const PROBE_SRC = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="10" height="37"/>');

// Messung der Bildfelder eines Formulars in host (die iframes hängen dort, solange sie laden). Liefert measure(usage):
// Promise mit den Stellen des Bildfelds der obersten Ebene (usage aus dem Formular-Schema: { plugin, type, field },
// Endpunkt imageUsage, mit id des Eintrags seine eigene Seite) als [{ label, frames }], frames je Breite
// { key, label, w, h, fit, radius, follows }. Alle Felder, die im selben Durchlauf fragen, messen zusammen: jede Seite
// lädt je Breite einmal, eine Seite nach der anderen. Was nicht zu messen ist (kein Bild mit der Markierung,
// Zeitgrenze), fällt weg. Lehnt nie ab: Fehler → [] (keine Vorschauen).
export function entryPlaces(host, id) {
  const jobs = [];
  const run = function () {
    const wanted = jobs.splice(0);
    const lists = wanted.map(function (job) {
      const query = { plugin: job.usage.plugin, type: job.usage.type, field: job.usage.field };
      if (id) query.id = id;
      return usagePlaces(query);
    });
    Promise.all(lists).then(function (places) {
      const urls = measureUrls(places);
      const picks = wanted.map(function (job) {
        const selector = 'img[' + state.preview.fieldAttr + '="' + CSS.escape(job.usage.type + state.preview.fieldSeparator + job.usage.field) + '"]';
        return function (doc) { return doc.querySelector(selector); };
      });
      const measured = {};
      return urls.reduce(function (done, url) {
        return done.then(function () {
          return measureAll(host, url, picks).then(function (frames) { measured[url] = frames; });
        });
      }, Promise.resolve()).then(function () {
        wanted.forEach(function (job, index) { job.resolve(fieldPlaces(places[index], measured, index)); });
      });
    }).catch(function () {
      wanted.forEach(function (job) { job.resolve([]); });
    });
  };
  return function (usage) {
    if (!state.preview.fieldAttr) return Promise.resolve([]);
    return new Promise(function (resolve) {
      jobs.push({ usage: usage, resolve: resolve });
      if (jobs.length === 1) Promise.resolve().then(run);
    });
  };
}

// Kurzer Name der Seite page als Stelle ihrer eigenen Bilder (Panel „Bild“ des Seiten-Editors; imageUsage mit page, wie
// die Stellen eines Bildfelds): Promise mit dem Namen, '' ohne ihn, bei einem Fehler oder nach MEASURE_TIMEOUT.
export function pageLabel(page) {
  return usagePlaces({ page: page }).then(function (places) { return places.length ? places[0].label : ''; });
}

// Stellen aus imageUsage zu query (Formular: plugin, type, field, id; Panel „Bild“: page): Promise mit [{ label, url }],
// [] bei einem Fehler oder nach MEASURE_TIMEOUT (wie lange eine Messung darf, so lange auch die Frage danach).
function usagePlaces(query) {
  const search = Object.keys(query).map(function (key) { return key + '=' + encodeURIComponent(query[key]); }).join('&');
  const request = editorApi(ENDPOINTS.media.usage + '?' + search).then(function (data) {
    return Array.isArray(data.places) ? data.places : [];
  });
  return withinTime(request, MEASURE_TIMEOUT, []);
}

// Rahmen der Elemente, die picks (je pick(document) → Element) in der Seite url finden (<img> oder Element mit
// Hintergrundbild), alle in je einem iframe pro Breite aus state.preview.widths: je pick eine Liste
// [{ key, label, w, h, fit, radius, follows }] in deren Reihenfolge; Breiten ohne Ergebnis fallen weg. Lehnt nie ab.
export function measureAll(host, url, picks) {
  const widths = state.preview.widths;
  const keys = Object.keys(widths);
  return Promise.all(keys.map(function (key) {
    return measureAt(host, url, widths[key].width, picks);
  })).then(function (byWidth) {
    return picks.map(function (pick, index) {
      return keys.map(function (key, at) {
        const frame = byWidth[at][index];
        return frame ? Object.assign({ key: key, label: widths[key].label }, frame) : null;
      }).filter(Boolean);
    });
  });
}

// iframe der Messseite zu url (Pfad der Website) in der Breite width mit der Klasse className, noch nicht eingehängt; aus
// der Tab-Reihenfolge und für Screenreader verborgen. Die Höhe gibt der Aufrufer: Messen über die Klasse
// (--le-framing-measure-height), die Vorschau einer Galerie im Formular die Höhe des Geräts (gallery-preview.js).
export function measureFrame(url, width, className) {
  const frame = document.createElement('iframe');
  frame.className = className;
  frame.tabIndex = -1;
  frame.setAttribute('aria-hidden', 'true');
  frame.style.width = width + 'px';
  frame.src = measureUrl(url);
  return frame;
}

// Adresse der Messseite zu url (Pfad der Website).
function measureUrl(url) {
  const target = new URL(url, window.location.origin);
  target.searchParams.set(state.preview.measureParam, state.preview.measureValue);
  return target.pathname + target.search;
}

// Eine Messung der Seite url in der Breite width: je pick ein Rahmen oder null (nichts gefunden, Zeit abgelaufen). Lazy-Bilder laden
// sofort, gemessen wird, wenn sie da sind (sonst hätten sie noch keine Höhe); danach die Probe (frameFollows). Ein
// Hintergrund ändert die Größe nicht und folgt nie dem Bild.
function measureAt(host, url, width, picks) {
  const frame = measureFrame(url, width, MEASURE_CLASS);
  const measured = new Promise(function (resolve) {
    frame.addEventListener('load', function () {
      const found = picks.map(function (pick) {
        try {
          return pick(frame.contentDocument);
        } catch (e) {
          return null;
        }
      });
      const images = found.filter(function (el) { return el && isImage(el); });
      images.forEach(function (el) { el.loading = 'eager'; });
      Promise.all(images.map(loaded)).then(function () {
        const frames = found.map(function (el) { return el ? frameOf(el) : null; });
        // Die Probe tauscht das Bild aus, darum erst nach allen Messungen und eine nach der anderen.
        return found.reduce(function (done, el, index) {
          return done.then(function () {
            if (!frames[index]) return;
            if (!isImage(el)) {
              frames[index].follows = false;
              return;
            }
            return frameFollows(el, frames[index]).then(function (follows) { frames[index].follows = follows; });
          });
        }, Promise.resolve()).then(function () { resolve(frames); });
      });
    });
  });
  host.appendChild(frame);
  return withinTime(measured, MEASURE_TIMEOUT, picks.map(function () { return null; })).then(function (frames) {
    frame.remove();
    return frames;
  });
}

// Promise, erfüllt, wenn das Bild geladen ist (auch nach einem Fehler: gemessen wird, was da ist).
function loaded(el) {
  if (el.complete && el.naturalWidth) return Promise.resolve();
  return el.decode().catch(function () { /* gemessen wird trotzdem */ });
}

// Folgt der Rahmen dem Bild (Höhe auto, object-fit greift dann nie)? Das Bild bekommt ein Probebild in anderem
// Seitenverhältnis (ohne srcset und <source>); ändert sich die Form des Rahmens, folgt er ihm. Danach ist alles wie vorher
// (src, srcset, <source>), damit die Probe keine weitere Messung derselben Seite verschiebt.
function frameFollows(el, frame) {
  const picture = el.parentElement && el.parentElement.tagName === 'PICTURE' ? el.parentElement : null;
  const sources = picture ? Array.prototype.slice.call(picture.querySelectorAll('source')) : [];
  const attrs = ['src', 'srcset'].map(function (name) { return { name: name, value: el.getAttribute(name) }; });
  sources.forEach(function (source) { source.remove(); });
  el.removeAttribute('srcset');
  el.src = PROBE_SRC;
  return loaded(el).then(function () {
    const box = el.getBoundingClientRect();
    const follows = Math.abs(box.width - frame.w) > SAME_BOX || Math.abs(box.height - frame.h) > SAME_BOX;
    sources.forEach(function (source) { picture.insertBefore(source, el); });
    attrs.forEach(function (attr) {
      if (attr.value === null) el.removeAttribute(attr.name);
      else el.setAttribute(attr.name, attr.value);
    });
    return loaded(el).then(function () { return follows; });
  });
}

function isImage(el) {
  return el.tagName.toLowerCase() === 'img';
}

// Gerenderter Rahmen eines <img> bzw. Elements mit Hintergrundbild: { w, h, fit (imageFit), radius } (Rundung in
// Prozent, radiusOf); null ohne Fläche.
function frameOf(el) {
  const box = el.getBoundingClientRect();
  if (!box.width || !box.height) return null;
  return {
    w: box.width,
    h: box.height,
    fit: imageFit(el.ownerDocument.defaultView.getComputedStyle(el), !isImage(el)),
    radius: radiusOf(el, box)
  };
}

// Rundung des Rahmens: am Bild selbst oder am nächsten Element darum, das gleich groß ist und abschneidet (overflow,
// z. B. ein runder Rahmen um ein Foto mit object-fit: cover); ohne eine solche die des Bildes (eckig).
function radiusOf(el, box) {
  const view = el.ownerDocument.defaultView;
  const corners = function (style) { return RADIUS_CORNERS.map(function (name) { return style[name]; }); };
  for (let node = el; node instanceof view.Element; node = node.parentElement) {
    const rect = node.getBoundingClientRect();
    if (Math.abs(rect.width - box.width) > SAME_BOX || Math.abs(rect.height - box.height) > SAME_BOX) break;
    const style = view.getComputedStyle(node);
    const round = corners(style).some(function (value) { return parseFloat(value) > 0; });
    if (round && (node === el || style.overflow !== 'visible')) return radiusPercent(corners(style), box.width, box.height);
  }
  return radiusPercent(corners(view.getComputedStyle(el)), box.width, box.height);
}
