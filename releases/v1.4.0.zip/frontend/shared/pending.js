// Warten ohne DOM und ohne Importe, damit es sich für sich prüfen lässt (tests/frontend/framing-geometry.test.php): Zähler
// für Arbeit, auf die Speichern und Übernehmen warten (ausstehende Zuschnitte, upload.js), Warten vor einer Aktion
// (Speichern und Übernehmen), Zeitgrenze für eine Anfrage, Merken nur gelungener Ergebnisse (Panel „Bild“), Antworten in
// der Reihenfolge der Anfragen und Entprellen (Vorschau der Galerie).

// Liefert { hold(), count(), settled(timeout) }: hold() zählt eine Arbeit und gibt release() zurück (zählt nur beim ersten
// Aufruf); settled(timeout) ist eine Promise, die sich mit true erfüllt, sobald keine mehr aussteht (sofort, wenn keine
// aussteht), und mit false nach timeout ms, damit niemand für immer wartet.
export function createHolds() {
  let count = 0;
  let waiting = [];
  return {
    count: function () { return count; },
    hold: function () {
      count++;
      let open = true;
      return function () {
        if (!open) return;
        open = false;
        count--;
        if (count) return;
        const done = waiting;
        waiting = [];
        done.forEach(function (wake) { wake(true); });
      };
    },
    settled: function (timeout) {
      if (!count) return Promise.resolve(true);
      return new Promise(function (resolve) {
        let timer = null;
        const wake = function (ok) {
          clearTimeout(timer);
          waiting = waiting.filter(function (item) { return item !== wake; });
          resolve(ok);
        };
        timer = setTimeout(function () { wake(false); }, timeout);
        waiting.push(wake);
      });
    }
  };
}

// Eine Aktion, die erst auf etwas wartet (Speichern, Übernehmen; mit Zuschnitten settledAction in upload.js): run(then)
// ruft wait() (Promise mit true oder false) und danach then() nur bei true; solange es wartet, startet kein zweites (run
// liefert dann false, sonst true). onChange(busy) läuft zu Beginn (true) und am Ende des Wartens (false), z. B. um den Knopf
// zu sperren; busy() sagt, ob gerade gewartet wird. Anderes (Abbrechen) sperrt es nicht.
export function createWait(wait, onChange) {
  let busy = false;
  return {
    busy: function () { return busy; },
    run: function (then) {
      if (busy) return false;
      busy = true;
      onChange(true);
      wait().then(function (ok) {
        busy = false;
        onChange(false);
        if (ok) then();
      });
      return true;
    }
  };
}

// Promise mit dem Ergebnis von promise, mit fallback, wenn es ablehnt oder nach timeout ms noch aussteht.
export function withinTime(promise, timeout, fallback) {
  return new Promise(function (resolve) {
    const timer = setTimeout(function () { resolve(fallback); }, timeout);
    promise.then(function (value) {
      clearTimeout(timer);
      resolve(value);
    }, function () {
      clearTimeout(timer);
      resolve(fallback);
    });
  });
}

// Merkt sich das Ergebnis von load() (Promise), solange es kept(Ergebnis) erfüllt: get() lädt beim ersten Mal und nach
// einem Ergebnis, das nicht gilt (gescheitert, abgelaufen), oder einer Ablehnung neu und liefert sonst das gemerkte;
// forget() verwirft es.
export function keepSuccess(load, kept) {
  let cached = null;
  return {
    get: function () {
      if (cached) return cached;
      const current = load().then(function (value) {
        if (!kept(value) && cached === current) cached = null;
        return value;
      }, function (error) {
        if (cached === current) cached = null;
        throw error;
      });
      cached = current;
      return current;
    },
    forget: function () { cached = null; }
  };
}

// Antworten in der Reihenfolge der Anfragen (Vorschau der Galerie im Formular): next() gibt einer neuen Anfrage ihre
// Nummer, fresh(nummer) sagt bei ihrer Antwort, ob sie gilt, und merkt sie sich. Es gilt nur eine Antwort, die neuer ist
// als jede bisher geltende, ob gelungen oder Fehler: Eine ältere, die erst danach ankommt, überholt sie nie.
export function inOrder() {
  let sent = 0;
  let shown = 0;
  return {
    next: function () { return ++sent; },
    fresh: function (number) {
      if (number <= shown) return false;
      shown = number;
      return true;
    }
  };
}

// Ein Aufruf von run(), der warten darf (Vorschau: Tippen entprellt, sonst sofort): soon(delay) verwirft einen wartenden
// und ruft run() nach delay ms, ohne delay gleich; cancel() verwirft ihn.
export function debounce(run) {
  let timer = null;
  const cancel = function () {
    clearTimeout(timer);
    timer = null;
  };
  return {
    soon: function (delay) {
      cancel();
      if (!(delay > 0)) {
        run();
        return;
      }
      timer = setTimeout(function () {
        timer = null;
        run();
      }, delay);
    },
    cancel: cancel
  };
}
