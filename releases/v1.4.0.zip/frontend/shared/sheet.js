import { editorButton } from './buttons.js';
import { icon } from './icons.js';

// Karte mit Kopf (Überzeile, Titel, ×), Inhalt und Fuß: der eine Rahmen für das Panel des Seiten-Editors
// (site-editor/panel.js) und die Ebene „Ausschnitt“ über dem Eintragsformular (image-framing.js). Aussehen in
// sheet.css; Lage und Größe setzt der Gastgeber über seine Klasse. options: { className, title, eyebrow (Überzeile,
// optional), closeClass, closeLabel, onClose (×) }. Liefert { element, body, foot, setEyebrow(text) (Überzeile später
// setzen oder ändern) }; ein leerer Fuß bleibt unsichtbar.

const SHEET_CLASSES = {
  sheet: 'le-sheet',
  head: 'le-sheet__head',
  titles: 'le-sheet__titles',
  eyebrow: 'le-sheet__eyebrow',
  title: 'le-sheet__title',
  body: 'le-sheet__body',
  foot: 'le-sheet__foot'
};

function part(tag, className, text) {
  const node = document.createElement(tag);
  node.className = className;
  if (text) node.textContent = text;
  return node;
}

export function sheet(options) {
  const element = part('section', SHEET_CLASSES.sheet + ' ' + options.className);
  element.setAttribute('role', 'dialog');
  element.setAttribute('aria-label', options.title);
  const titles = part('div', SHEET_CLASSES.titles);
  titles.appendChild(part('strong', SHEET_CLASSES.title, options.title));
  let eyebrow = null;
  const setEyebrow = function (text) {
    if (!eyebrow) eyebrow = titles.insertBefore(part('span', SHEET_CLASSES.eyebrow), titles.firstChild);
    eyebrow.textContent = text;
  };
  if (options.eyebrow) setEyebrow(options.eyebrow);
  const close = editorButton('', options.closeClass, options.onClose);
  close.append(icon('close'));
  close.title = options.closeLabel;
  close.setAttribute('aria-label', options.closeLabel);
  const head = part('div', SHEET_CLASSES.head);
  head.append(titles, close);
  const body = part('div', SHEET_CLASSES.body);
  const foot = part('div', SHEET_CLASSES.foot);
  element.append(head, body, foot);
  return { element: element, body: body, foot: foot, setEyebrow: setEyebrow };
}
