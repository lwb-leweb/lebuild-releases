import { editorRoot } from './bar.js';
import { sheet } from '../shared/sheet.js';
import { askConfirm } from './confirm.js';

// Seitenpanel: schwebende Karte rechts (oder links) über die ganze Höhe, über der Leiste (am Handy über die
// ganze Ansicht), im Shadow-DOM: Verlauf, „Alle Texte dieser Seite“, Panel „Bild“ und das Formular für
// Plugin-Einträge. Kopf mit Überzeile und Titel, Inhalt scrollt, Fuß (panelFooter) bleibt stehen.
// Es ist immer höchstens eins offen.

const PANEL_TEXT = {
  close: 'Schließen',
  discardTitle: 'Eingaben verwerfen?',
  discardText: 'Was du hier eingegeben hast, ist noch nicht gespeichert.',
  discard: 'Verwerfen'
};

let current = null;

// Schließt das offene Panel; onClose des Panels läuft dabei.
export function closePanel() {
  if (!current) return;
  const panel = current;
  current = null;
  panel.element.remove();
  if (panel.scrim) panel.scrim.remove();
  if (panel.onClose) panel.onClose();
}

// Rückfrage „Eingaben verwerfen?“; Promise mit true, wenn ja. Auch für die Ebene „Ausschnitt“ im Formular (plugin-lists.js).
export function askDiscard() {
  return askConfirm({ title: PANEL_TEXT.discardTitle, text: PANEL_TEXT.discardText, confirm: PANEL_TEXT.discard, danger: true });
}

// Darf panel zugehen? Mit ungespeicherten Eingaben (isDirty) erst nachfragen; Promise mit true, wenn ja.
function confirmDiscard(panel) {
  if (!panel || !panel.isDirty || !panel.isDirty()) return Promise.resolve(true);
  return askDiscard();
}

// Darf das offene Panel zugehen (Weg von außen, z. B. Esc auf der Seite beim Panel „Bild“)? Mit ungespeicherten Eingaben erst
// nachfragen wie ×; Promise mit true, wenn ja. Schließen muss der Aufrufer selbst (closePanel).
export function confirmPanelClose() {
  return confirmDiscard(current);
}

// Schließen über ×, Esc oder Klick daneben: mit ungespeicherten Eingaben erst nachfragen.
function requestClose() {
  if (!current) return;
  const panel = current;
  confirmDiscard(panel).then(function (yes) {
    if (yes && current === panel) closePanel();
  });
}

// Hat das offene Panel ungespeicherte Eingaben (Eintragsformular)? Zählt beim Verlassen der Seite mit
// (hasUnsavedChanges in session.js).
export function isPanelDirty() {
  return current !== null && Boolean(current.isDirty) && current.isDirty();
}

// Strg+S (save-key.js) bei offenem Panel: dessen Speichern (options.onSave), z. B. das Eintragsformular.
// false, wenn das offene Panel nichts zu speichern hat (dann gilt Speichern der Seite).
export function savePanel() {
  if (!current || !current.onSave) return false;
  current.onSave();
  return true;
}

// Ist das Panel mit diesem Schlüssel offen?
export function isPanelOpen(key) {
  return current !== null && current.key === key;
}

// Überzeile des Panels mit dem Inhaltsbereich body (von openPanel) nachtragen, z. B. sobald ein Name geladen ist; ist es
// inzwischen zu, nichts.
export function setPanelEyebrow(body, text) {
  if (current && current.body === body) current.setEyebrow(text);
}

// Fuß des offenen Panels (Knöpfe wie Speichern/Abbrechen); leer bleibt er unsichtbar.
export function panelFooter() {
  return current ? current.foot : null;
}

// Öffnet ein Panel und liefert ein Promise mit seinem Inhaltsbereich. Ein offenes anderes schließt
// vorher; hat es ungespeicherte Eingaben, fragt es wie × nach, lehnt man ab, bleibt es offen und das
// Promise liefert null.
// options: { key, title, eyebrow (Überzeile, z. B. „Mitarbeiter“), dim (Seite abdunkeln, für
// Formulare), wide (breit und mittig, für große Formulare; am Handy wie jedes Panel), left (links statt rechts, z. B.
// damit es das bearbeitete Element nicht verdeckt; am Handy wie jedes Panel), isDirty() (ungespeicherte Eingaben: vor dem Schließen nachfragen), onSave (Strg+S),
// onClose }. Esc im Panel schließt es (wie ×), auch während einer Bearbeitung, die dann bleibt; nur Esc in
// einem Feld der laufenden Bearbeitung (owns) fängt interact.js vorher ab und verwirft diese.
export function openPanel(options) {
  return confirmDiscard(current).then(function (yes) {
    if (!yes) return null;
    closePanel();
    return buildPanel(options);
  });
}

function buildPanel(options) {
  const frame = sheet({
    className: 'le-panel' + (options.wide ? ' le-panel--wide' : '') + (options.left ? ' le-panel--left' : ''),
    title: options.title,
    eyebrow: options.eyebrow,
    closeClass: 'le-icon-btn',
    closeLabel: PANEL_TEXT.close,
    onClose: requestClose
  });
  const element = frame.element;
  const body = frame.body;
  const foot = frame.foot;
  element.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') requestClose();
  });

  let scrim = null;
  if (options.dim) {
    scrim = document.createElement('div');
    scrim.className = 'le-scrim';
    scrim.addEventListener('click', requestClose);
    editorRoot().appendChild(scrim);
  }
  // Nach der Leiste einhängen: das Panel liegt über ihr.
  editorRoot().appendChild(element);
  current = { key: options.key, element: element, scrim: scrim, body: body, foot: foot, setEyebrow: frame.setEyebrow, isDirty: options.isDirty, onSave: options.onSave, onClose: options.onClose };
  return body;
}
