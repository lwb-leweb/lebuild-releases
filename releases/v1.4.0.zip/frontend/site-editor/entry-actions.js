// Welche Knöpfe ein Eintrag einer Plugin-Liste auf der Seite bekommt, in dieser Reihenfolge (plugin-lists.js baut sie), und
// wohin ein gezogener Eintrag kommt. Ohne Importe und ohne DOM, damit node es prüfen kann (tests/frontend/entry-copy.test.php).

// Einzelansicht (le_single_attrs): nur Bearbeiten, ohne Eintrag (create: leere id) nur Anlegen. Sonst Bearbeiten, Ziehpunkt
// (sortable: sort-Endpoint und keine feste Reihenfolge; nur mit mehr als einem Eintrag, count), Kopieren, Löschen.
export function entryActions(single, sortable, count, create) {
  if (single) return [create ? 'create' : 'edit'];
  const actions = ['edit'];
  if (sortable && count > 1) actions.push('drag');
  actions.push('copy', 'remove');
  return actions;
}

// Eintrag von Index from nach to gezogen (Index danach, drag-sort.js onDrop) in einer Liste mit den sichtbaren ids (vor dem
// Umordnen): Er kommt vor (to < from) bzw. hinter (to > from) den Eintrag, der vorher an der Stelle to stand.
// { target: dessen id (sort), after }; null, wenn er bleibt, wo er ist, oder eine Stelle außerhalb der Liste liegt.
export function sortPlace(ids, from, to) {
  const inside = function (index) { return index >= 0 && index < ids.length; };
  if (from === to || !inside(from) || !inside(to)) return null;
  return { target: ids[to], after: to > from };
}

// Nach dem Neuladen einer Liste, in der seitdem moves ([{ failure }], in ihrer Reihenfolge) verschoben wurden: reloaded, ob
// das Neuladen gelang. { failure: der letzte Fehler eines sort (null ohne), undo: die Verschiebungen, die zurückgehen,
// letzte zuerst }. Zurück nur, wenn ein sort scheiterte und die Seite die Reihenfolge des Servers nicht zeigen kann (kein
// Netz); dann alle, so steht wieder da, was vor dem Ziehen zu sehen war.
export function settleMoves(moves, reloaded) {
  const failed = moves.filter(function (moved) { return moved.failure; });
  const failure = failed.length ? failed[failed.length - 1].failure : null;
  return { failure: failure, undo: failure && !reloaded ? moves.slice().reverse() : [] };
}

// Nach dem sort der Verschiebung index von count seit dem letzten Neuladen einer Liste (failed: gescheitert, waiting: so viele
// warten noch auf ihren Abruf): { reload: jetzt neu laden, drop: Indizes, die nicht mehr an den Server gehen }. Gescheitert
// lädt gleich neu und verwirft, was danach kam (dessen Ziele bauen auf der gescheiterten auf); sonst lädt erst die letzte.
export function afterSort(count, index, failed, waiting) {
  if (!failed) return { reload: waiting === 0, drop: [] };
  const drop = [];
  for (let later = index + 1; later < count; later++) drop.push(later);
  return { reload: true, drop: drop };
}

// Name eines Eintrags für Ansage und Kopie am Zeiger (drag-sort.js label): Text der ersten Überschrift der Karte (headings:
// Selektor), sonst der Alt-Text ihres ersten Bildes, sonst fallback („Eintrag“).
export function entryName(item, headings, fallback) {
  const heading = item.querySelector(headings);
  const image = item.querySelector('img[alt]');
  return (heading && heading.textContent.trim()) || (image && image.alt.trim()) || fallback;
}
