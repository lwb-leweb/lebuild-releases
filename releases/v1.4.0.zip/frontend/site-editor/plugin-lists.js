import { notify, notifyError, editorButton, labeledButton, iconButton, addBarButton, onModeChange, editorRoot } from './bar.js';
import { editorApi, editorPost } from '../shared/request.js';
import { settledAction } from '../shared/upload.js';
import { SESSION_TEXT } from './session.js';
import { showHover, pin, CHIP_PLACE, PIN_PLACE } from './overlay.js';
import { addChipSource, showEntry, HEADING_SELECTOR } from './interact.js';
import { askConfirm } from './confirm.js';
import { icon } from '../shared/icons.js';
import { openPanel, closePanel, panelFooter, isPanelOpen, askDiscard } from './panel.js';
import { buildEntryForm, deleteQuestion, entryTitle, copyTitle, copyValues, ENTRY_TEXT, ENTRY_CONFLICT_CODE } from '../shared/entry-form/index.js';
import { PICKER_CLASS, ICON_GRID_LOOK, FRAMING_BUTTONS } from './field-editors.js';
import { entryActions, sortPlace, settleMoves, afterSort, entryName } from './entry-actions.js';
import { dragSort, dragHandle, DRAG_HANDLE } from '../shared/drag-sort.js';
import { keyStep } from '../shared/drag-geometry.js';
import { withFilterDefault, singleMatch, swapsAlong, shownAfterSave } from './list-filter.js';

// Plugin-Listen auf der Seite: Renderer markieren Liste, Eintrag und Einzelansicht
// (le_list_attrs/le_item_attrs/le_single_attrs, Namen aus dem JSON-Block). Für Plugins mit
// inlineEdit in plugin.json steht unter jeder Liste beim Bearbeiten immer ihre Leiste
// („Mitarbeiter · 5 Einträge“, „+ Neuer Eintrag“; page.css hält dort Platz frei). Ein Klick auf
// einen Eintrag öffnet sein Formular, beim Überfahren (Handy: erstes Antippen) zeigt er seine
// Knöpfe (Bearbeiten, Ziehpunkt mit sort-Endpoint und ohne attrs.fixedOrder an der Liste, Kopieren, Löschen; eine Einzelansicht nur
// ihren Knopf zum Bearbeiten, ohne Eintrag (leere id) zum Anlegen; ist sie leer, steht er beim Bearbeiten immer auf ihrer
// Fläche). Einträge speichern sofort über ihr Formular
// (shared/entry-form/) und gehören nicht zu Speichern/Rückgängig der Seite; danach werden nur die Listen
// dieses Typs aus der neu abgerufenen Seite getauscht, Ungespeichertes auf der Seite bleibt; am neuen Element kommt
// dann das Ereignis listReloaded (Skripte der Website, z. B. das Modal der Content-Typen). Listen mit
// itemForm (Content-Typen-Karten) öffnen beim Klick immer das Formular, auch wenn ein Eintrag ein Link
// ist (formOnly, interact.js). Zeigt ein Skript der Website einen Eintrag in einem Dialog (Ereignis
// itemDialog), bietet die Leiste den Knopf der Einzelansicht (Text vom Plugin), die Leisten unter den
// Listen sind solange weg; der Wechsel von „Ansehen“ auf „Bearbeiten“ öffnet dann gleich sein Formular.

const LIST_TEXT = {
  add: 'Neuer Eintrag',
  entryEyebrow: 'Eintrag',
  edit: ENTRY_TEXT.edit,
  copy: ENTRY_TEXT.copy,
  remove: 'Löschen',
  removeNote: 'Das lässt sich nicht rückgängig machen.',
  entry: 'Eintrag',
  entries: 'Einträge',
  saved: SESSION_TEXT.saved,
  deleted: 'Gelöscht.',
  hidden: SESSION_TEXT.saved + ' Der Eintrag ist in dieser Liste nicht zu sehen.',
  singleGone: SESSION_TEXT.saved + ' Der Eintrag ist unter dieser Adresse nicht mehr zu sehen.',
  singleHidden: SESSION_TEXT.saved + ' Der Eintrag ist an dieser Stelle nicht zu sehen.',
  reloadFailed: 'Die Liste lässt sich nicht neu laden. Bitte die Seite neu laden.'
};
// Panel-Schlüssel des Formulars (panel.js).
const FORM_KEY = 'entry';
// Formulare mit einem dieser Feldtypen öffnen breit und mittig (openPanel wide) in zwei Spalten (split), sonst wird es eng.
const WIDE_FIELD_TYPES = ['richtext', 'list', 'blocks'];
// Platz unter Listen (page.css): eigener Abstand der Website unter der Liste (hier gemessen) und
// Klasse an <html>, die die Abstandsregel zum Messen aussetzt.
const LIST_SPACE = {
  ownMarginVar: '--le-list-own-margin',
  measuringClass: 'le-list-measuring'
};
// Klassen des Formulars im Shadow-DOM (form.css).
const PAGE_LOOK = {
  form: 'le-form',
  split: 'le-form--split',
  main: 'le-form__main',
  side: 'le-form__side',
  full: 'le-form__full',
  field: 'le-field le-field--panel',
  labelTag: 'span',
  label: 'le-field__label',
  checkbox: 'le-field le-field--checkbox',
  picker: PICKER_CLASS,
  image: 'le-field__image',
  imageEmpty: 'le-field__image-empty',
  imageDrop: 'le-field__drop',
  imageDropActive: 'le-field__drop--active',
  imageActions: 'le-field__image-actions',
  file: 'le-field__file',
  list: 'le-field__list',
  listRow: 'le-field__row',
  listRowHead: 'le-field__row-head',
  iconGrid: ICON_GRID_LOOK,
  iconButton: 'le-icon-btn le-icon-btn--small',
  slug: 'le-field__slug',
  slugText: 'le-field__slug-text',
  slugAuto: 'le-field__slug-text--auto',
  slugInput: 'le-field__slug-input',
  gallery: 'le-gallery',
  galleryActive: 'le-gallery--active',
  galleryTile: 'le-gallery__tile',
  galleryPending: 'le-gallery__tile--pending',
  galleryMedia: 'le-gallery__media',
  galleryCaption: 'le-gallery__caption',
  galleryActions: 'le-gallery__actions',
  galleryHandle: 'le-gallery__handle',
  blocks: 'le-blocks',
  block: 'le-block',
  blockHead: 'le-block__head',
  blockTitle: 'le-block__title',
  blockSummary: 'le-block__summary',
  blockBody: 'le-block__body',
  blockCollapsed: 'le-block--collapsed',
  blockAdd: 'le-block__add',
  // Knöpfe des Ausschnitts im Bildfeld und der Ebene „Ausschnitt“ wie im Panel „Bild“, dazu × im Kopf.
  framing: Object.assign({ close: 'le-icon-btn' }, FRAMING_BUTTONS),
  // Vorschau der Seite statt des Bildrasters einer Einzelansicht (gallery-preview.js); Breiten wie die Formate im
  // Ausschnitt. Bedienung darauf (gallery-controls.js): Fläche je Bild, Popover (photo-popover.js) wie der Dialog am Element.
  preview: {
    box: 'le-gallery-preview',
    head: 'le-gallery-preview__head',
    widths: 'le-gallery-preview__widths',
    width: FRAMING_BUTTONS.option,
    widthPx: 'le-gallery-preview__px',
    stage: 'le-gallery-preview__stage',
    stageActive: 'le-gallery-preview__stage--active',
    sizer: 'le-gallery-preview__sizer',
    cut: 'le-gallery-preview__cut',
    frame: 'le-gallery-preview__frame',
    layer: 'le-gallery-preview__layer',
    hint: 'le-framing__hint',
    note: 'le-framing__hint',
    spot: 'le-gallery-preview__spot',
    spotActive: 'le-gallery-preview__spot--open',
    spotNew: 'le-gallery-preview__spot--new',
    spotOpen: 'le-gallery-preview__open',
    spotNumber: 'le-gallery-preview__number',
    spotRemove: 'le-icon-btn le-icon-btn--small le-gallery-preview__remove',
    popover: 'le-popover le-gallery-preview__popover',
    popoverTitle: 'le-popover__title',
    popoverBody: 'le-popover__body',
    popoverField: 'le-field',
    popoverLabel: 'le-field__label',
    popoverActions: 'le-popover__actions',
    popoverButton: FRAMING_BUTTONS.secondary
  }
};

// plugin_lists_config() (backend/plugins/markers.php): { endpoints je Plugin, attrs, separator, positions, singleLabel, singleCreateLabel, events }.
let lists = null;
let attrs = null;
let events = null;
// Ein Abruf (Laden, Löschen, Sortieren) zur Zeit, running ist er (für runAfter).
let busy = false;
let running = Promise.resolve();
// Name der Liste je Schlüssel („Mitarbeiter“), aus dem list-Endpoint (listInfo); null, solange unbekannt.
const listLabels = new Map();
// Sortieren durch Ziehen (drag-sort.js) je Liste: { list, sorter }, beim ersten Ziehen angelegt. Beim Tausch der Liste
// (reload) geht es an das neue Element über (list), damit die Ansage (aria-live) stehen bleibt: Einen frisch angelegten
// Bereich lesen Screenreader oft nicht vor. Beim Wechsel auf „Ansehen“ wird der Sortierer gelöst (sorter null, Ansage weg).
const sortings = [];
// Sortieren je Listen-Schlüssel (Listen desselben Schlüssels lädt reload zusammen), queueOf: moves = Verschiebungen seit dem
// letzten Neuladen ({ id, target, position, undo, failure, dropped }), waiting = wie viele davon auf einen Abruf warten
// (runAfter; solange lädt die davor nicht neu, die nächste baut auf der Seite auf, wie sie gerade aussieht), reloading =
// lädt gerade neu, keys = in dieser Zeit gedrücktes Alt+Pfeil ({ id, key }), danach ausgeführt.
const queues = new Map();
// Eintrag (id), der per Tastatur verschoben wurde: Nach dem Neuladen bekommt sein Ziehpunkt wieder den Fokus (itemChips).
let focusDrag = null;
// Alt+Pfeil am Ziehpunkt läuft gerade (drop kommt dann aus sorter.key).
let keying = false;
// Lösen der Leisten unter den Listen und der Knöpfe auf leeren Einzelansichten (overlay.js pin).
let unpinBars = [];
// Eintrag, den ein Skript der Website gerade in einem Dialog zeigt (Element mit attrs.item), sonst null;
// Knopf dafür in der Leiste.
let dialogItem = null;
let dialogButton = null;

function attrSelector(attr, value) {
  return value === undefined ? '[' + attr + ']' : '[' + attr + '="' + CSS.escape(value) + '"]';
}

function withQuery(url, params) {
  const target = new URL(url, window.location.origin);
  Object.keys(params).forEach(function (name) { target.searchParams.set(name, params[name]); });
  return target.pathname + target.search;
}

// Liste oder Einzelansicht mit Plugin, Typ und Endpoints; null, wenn das Plugin nicht mitmacht.
function placeOf(container) {
  const single = container.hasAttribute(attrs.single);
  const key = container.getAttribute(single ? attrs.single : attrs.list);
  const cut = key.indexOf(lists.separator);
  const plugin = cut > 0 ? key.slice(0, cut) : '';
  if (!plugin || !Object.prototype.hasOwnProperty.call(lists.endpoints, plugin)) return null;
  return { container: container, single: single, key: key, type: key.slice(cut + lists.separator.length), urls: lists.endpoints[plugin] };
}

// Beschriftung für „diesen Eintrag bearbeiten“ (Einzelansicht, Eintrag im Dialog) bzw. „… anlegen“ (Einzelansicht ohne
// Eintrag): vom Plugin am Element, sonst die Vorgabe des Kerns.
function singleLabelOf(container) {
  return container.getAttribute(attrs.singleLabel) || (creates(container) ? lists.singleCreateLabel : lists.singleLabel);
}

// Einzelansicht ohne Eintrag (le_single_attrs mit leerer id): Klick und Knopf legen einen an.
function creates(item) {
  return item.getAttribute(attrs.item) === '';
}

function containerOf(item) {
  return item.closest(attrSelector(attrs.list) + ',' + attrSelector(attrs.single));
}

function idOf(item) {
  return parseInt(item.getAttribute(attrs.item), 10);
}

// Einträge genau dieser Liste (nicht die einer Liste darin).
function itemsOf(place) {
  return Array.prototype.filter.call(place.container.querySelectorAll(attrSelector(attrs.item)), function (item) {
    return containerOf(item) === place.container;
  });
}

// Listen mitmachender Plugins auf der Seite.
function listsOnPage() {
  return Array.prototype.filter.call(document.querySelectorAll(attrSelector(attrs.list)), function (list) {
    return placeOf(list) !== null;
  });
}

// Leere Einzelansichten mitmachender Plugins (Fläche aus page.css): noch kein Eintrag („… anlegen“) oder keiner für Besucher
// sichtbar (attrs.singleHidden).
function emptySinglesOnPage() {
  return Array.prototype.filter.call(document.querySelectorAll(attrSelector(attrs.single) + ':empty'), function (single) {
    return placeOf(single) !== null;
  });
}

// Eigenen Abstand der Website unter jeder Liste messen (ohne die Regel aus page.css) und an der
// Liste ablegen: page.css nimmt den größeren davon und den Platz für „+ Hinzufügen“. Neu nach dem
// Neuladen einer Liste und bei Größenänderung (Media Queries der Website).
function measureListSpace() {
  const found = document.querySelectorAll(attrSelector(attrs.list));
  const root = document.documentElement;
  const scrollX = window.scrollX;
  const scrollY = window.scrollY;
  root.classList.add(LIST_SPACE.measuringClass);
  const margins = Array.prototype.map.call(found, function (list) { return window.getComputedStyle(list).marginBottom; });
  root.classList.remove(LIST_SPACE.measuringClass);
  Array.prototype.forEach.call(found, function (list, index) { list.style.setProperty(LIST_SPACE.ownMarginVar, margins[index]); });
  // Ohne die Regel ist die Seite kurz kürzer; der Browser kann dabei die Scrollposition kappen.
  if (window.scrollX !== scrollX || window.scrollY !== scrollY) window.scrollTo({ left: scrollX, top: scrollY, behavior: 'instant' });
}

function run(task) {
  if (busy) return null;
  busy = true;
  running = task()
    .catch(notifyError)
    .finally(function () { busy = false; });
  return running;
}

// Wie run, wartet aber, bis der laufende Abruf fertig ist, statt nichts zu tun (Sortieren: die Karte steht schon an der neuen
// Stelle, ein zweites schnelles Alt+Pfeil geht nicht verloren); queue.waiting zählt, solange gewartet wird.
function runAfter(queue, task) {
  if (!busy) return run(task);
  queue.waiting++;
  return running.then(function () {
    queue.waiting--;
    return runAfter(queue, task);
  });
}

function hasItem(node, id) {
  const selector = attrSelector(attrs.item, String(id));
  return node.matches(selector) || node.querySelector(selector) !== null;
}

function itemCount(node) {
  return node.querySelectorAll(attrSelector(attrs.item)).length;
}

// Ob der Eintrag id auf einer späteren Seite der neu geladenen Liste node steht (Neuladen zeigt nur die erste): folgt
// „Mehr laden“ Seite für Seite, dieselbe Liste per Reihenfolge wie reload, bis er auftaucht, kein Link mehr kommt oder
// die vor dem Speichern nachgeladenen Einträge (left: so viele noch) durchsucht sind; nur dort kann er gestanden haben.
function onLaterPage(node, selector, index, id, left) {
  const more = node.querySelector(':scope > ' + attrSelector(attrs.more) + '[href]');
  if (!more || left <= 0) return Promise.resolve(false);
  return fetch(more.getAttribute('href'), { credentials: 'same-origin', cache: 'no-store' })
    .then(function (response) {
      if (!response.ok) throw new Error(LIST_TEXT.reloadFailed);
      return response.text();
    })
    .then(function (html) {
      const next = new DOMParser().parseFromString(html, 'text/html').querySelectorAll(selector)[index];
      if (!next) return false;
      return hasItem(next, id) || onLaterPage(next, selector, index, id, left - itemCount(next));
    });
}

// Holt die Seite neu und tauscht die Liste bzw. Einzelansicht samt allen Listen und Einzelansichten mit data-filter desselben
// Typs auf der Seite (swapsAlong; z. B. eine zweite Liste mit data-filter, die Galerie, in die ein Eintrag gewechselt ist), jede
// per Reihenfolge unter den gleichen (Einzelansichten: singleMatch). Ein Weg für
// Speichern, Hinzufügen, Löschen und Sortieren. listReloaded kommt erst, wenn alle getauscht sind, und
// zuerst an place (das Modal sucht seinen Inhalt in der ersten neuen Liste ohne seine alte Hülle).
// id: gespeicherter Eintrag, der danach in place zu sehen sein sollte, auch erst nach „Mehr laden“ (null ohne).
// Ohne message (Sortieren) liefert das Promise das neue Element von place (sonst nichts). Der Sortierer einer getauschten
// Liste geht an das neue Element über (sortings).
function reload(place, id, message) {
  const listSelector = attrSelector(attrs.list, place.key);
  const others = Array.prototype.filter.call(document.querySelectorAll(listSelector + ',' + attrSelector(attrs.single, place.key)), function (other) {
    return other !== place.container && swapsAlong(other.hasAttribute(attrs.single), other.getAttribute(FILTER_ATTR));
  });
  const spots = [place.container].concat(others).map(function (container) { return spotOf(container, place.key); });
  // Einträge, die vor dem Speichern zu sehen waren (samt per „Mehr laden“ nachgeladenen).
  const shownBefore = itemsOf(place).length;
  return fetch(window.location.href, { credentials: 'same-origin', cache: 'no-store' })
    .then(function (response) {
      if (!response.ok) throw new Error(LIST_TEXT.reloadFailed);
      return response.text();
    })
    .then(function (html) {
      const fresh = new DOMParser().parseFromString(html, 'text/html');
      const nodes = spots.map(function (spot) {
        const found = spot.index === -1 ? null : fresh.querySelectorAll(spot.selector)[spot.index];
        if (!found) return null;
        const node = document.importNode(found, true);
        const sorting = sortingOf(spot.container);
        if (sorting) sorting.list = node;
        spot.container.replaceWith(node);
        return node;
      });
      measureListSpace();
      // Die Leisten stellt der Empfänger von listReloaded neu (mountPluginLists).
      nodes.forEach(function (node) {
        if (node) node.dispatchEvent(new CustomEvent(events.listReloaded, { bubbles: true }));
      });
      showHover(null, []);
      const node = nodes[0];
      if (!node) {
        notify(place.single ? LIST_TEXT.singleGone : LIST_TEXT.reloadFailed);
        return;
      }
      if (nodes.indexOf(null) !== -1) {
        notify(LIST_TEXT.reloadFailed);
        return;
      }
      if (!message) return node;
      // Je getauschter Stelle: steht der Eintrag darin, trägt sie attrs.singleHidden (nur für Angemeldete, z. B. noch nicht
      // fällig). Von einer Einzelansicht aus zählt jede Stelle (Filterwert geändert: er steht an der Galerie daneben).
      if (id === null || shownAfterSave(place.single, nodes.map(function (fresh) { return [hasItem(fresh, id), fresh.hasAttribute(attrs.singleHidden)]; }))) {
        notify(message);
        return;
      }
      // Einzelansicht: kein „Mehr laden“; der Eintrag steht an keiner Stelle der Seite oder ist für Besucher nicht zu sehen.
      if (place.single) {
        notify(LIST_TEXT.singleHidden);
        return;
      }
      // Nicht auf der ersten Seite: Hinweis nur, wenn er auch auf keiner der vorher nachgeladenen steht.
      return onLaterPage(node, spots[0].selector, spots[0].index, id, shownBefore - itemCount(node)).then(function (later) {
        notify(later ? message : LIST_TEXT.hidden);
      }, function () { notify(message); });
    })
    .catch(function () { notify(LIST_TEXT.reloadFailed); });
}

// Stelle einer Liste bzw. Einzelansicht (Schlüssel key) in einer anderen Fassung der Seite wiederfinden: { container, selector,
// index }, das Element ist dort das index-te zu selector (-1: hier keins). Listen per Reihenfolge, Einzelansichten nach
// singleMatch. Für das Neuladen (reload) und die Vorschau einer Galerie (previewOf).
function spotOf(container, key) {
  const selector = container.hasAttribute(attrs.single)
    ? attrSelector(attrs.single, key) + singleMatch(container.getAttribute(attrs.item), container.getAttribute(FILTER_ATTR), { item: attrs.item, filter: FILTER_ATTR })
      .map(function (pair) { return attrSelector(pair[0], pair[1]); }).join('')
    : attrSelector(attrs.list, key);
  return { container: container, selector: selector, index: Array.prototype.indexOf.call(document.querySelectorAll(selector), container) };
}

// Vorschau der Seite im Formular (buildEntryForm preview, frontend/shared/entry-form/gallery-preview.js): nur für den Eintrag
// einer Einzelansicht mit data-filter (auch ohne Eintrag, „… anlegen“) und mit dem Endpunkt preview; sonst null (Raster).
// Die Messseite zeigt dieselbe Seite, das Element steht dort an derselben Stelle (spotOf, über data-filter). Den Wert des
// Filters trägt beim Anlegen schon das Formular (withFilterDefault). row: Eintrag (null beim Anlegen).
function previewOf(place, row) {
  if (!place.single || place.container.getAttribute(FILTER_ATTR) === null || !place.urls.preview) return null;
  const spot = spotOf(place.container, place.key);
  return {
    page: window.location.href,
    pick: function (doc) { return doc.querySelectorAll(spot.selector)[spot.index] || null; },
    rowAttr: attrs.row,
    render: function (data, field) {
      const payload = { type: place.type, field: field, data: data };
      if (row) payload.id = row.id;
      return editorPost(place.urls.preview, payload).then(function (answer) { return answer.html; });
    }
  };
}

// Formular im Seitenpanel (panel.js); Speichern (Knopf, Enter, Strg+S) schließt es und lädt die Liste
// neu. Ein geändertes Formular zählt als ungespeichert (Nachfrage vor dem Ersetzen, beim Verlassen der
// Seite). Wie auch immer das Panel zugeht, danach schließt sich das Formular (entry.close: nicht
// gespeicherte Uploads weg), bei laufendem Speichern erst, wenn es fertig ist (sonst fehlte dem Eintrag
// sein neues Bild).
// version: Stand beim Laden (get); ist der Eintrag seitdem geändert, fragt das Formular wie bei Seiten nach.
// copyOf (Original-Eintrag, row null): neuer Eintrag mit dessen Werten (copyValues), Titel „Kopie: …“, save mit after.
function openForm(place, schema, row, version, copyOf) {
  let dirty = false;
  let saving = false;
  let saveButton = null;
  let body = null;
  let asking = false;
  // Ein Zuschnitt, der noch gerechnet wird, kommt mit: erst darauf warten (settledAction, mit Zeitgrenze), dann prüfen
  // und speichern. Solange gewartet wird, ist nur Speichern gesperrt; zugemacht verwirft das Panel wie sonst (onClose).
  const waiting = settledAction(notify, function (busy) { saveButton.disabled = busy; });
  const submit = function (overwrite) {
    if (saving || asking) return;
    waiting.run(function () {
      if (body.isConnected && entry.check()) send(overwrite);
    });
  };
  const send = function (overwrite) {
    saving = true;
    saveButton.disabled = true;
    const payload = { type: place.type, data: entry.values() };
    if (row) payload.id = row.id;
    if (row && version) payload.version = version;
    if (copyOf) payload.after = copyOf.id;
    if (overwrite === true) payload.overwrite = true;
    editorPost(place.urls.save, payload)
      .then(function (data) {
        saving = false;
        if (body.isConnected) closePanel();
        else entry.close();
        return reload(place, Number(data.id), LIST_TEXT.saved);
      }, function (error) {
        saving = false;
        saveButton.disabled = false;
        if (error.code === ENTRY_CONFLICT_CODE && body.isConnected) {
          askConflict(place, row);
          return;
        }
        if (!body.isConnected) entry.close();
        notifyError(error);
      });
  };
  // Inzwischen von jemand anderem geändert: eigene Fassung speichern oder die andere ins Formular laden.
  const askConflict = function () {
    asking = true;
    askConfirm({ title: SESSION_TEXT.conflictTitle, text: ENTRY_TEXT.conflictPanel, confirm: SESSION_TEXT.conflictMine, alternative: SESSION_TEXT.conflictTheirs })
      .then(function (choice) {
        asking = false;
        if (choice === true) submit(true);
        else if (choice === 'alternative') {
          dirty = false;
          closePanel();
          edit(place, row.id);
        }
      });
  };
  const wide = schema.some(function (field) { return WIDE_FIELD_TYPES.indexOf(field.type) !== -1; });
  const entry = buildEntryForm(schema, copyOf ? copyValues(schema, copyOf) : row, { look: PAGE_LOOK, notify: notify, onSubmit: submit, split: wide, confirmClose: askDiscard, preview: copyOf ? null : previewOf(place, row) });
  openPanel({
    key: FORM_KEY,
    eyebrow: listLabels.get(place.key) || LIST_TEXT.entryEyebrow,
    title: copyOf ? copyTitle(schema, copyOf) : (row ? entryTitle(schema, row) : LIST_TEXT.add),
    dim: true,
    wide: wide,
    isDirty: function () { return dirty; },
    onSave: submit,
    onClose: function () { if (!saving) entry.close(); }
  }).then(function (panelBody) {
    // Abgelehnt (anderes Formular mit Eingaben bleibt offen): dieses Formular ist nie aufgegangen.
    if (!panelBody) {
      entry.close();
      return;
    }
    body = panelBody;
    // Bild-Upload und Texteditor melden Änderungen ebenfalls über input.
    entry.form.addEventListener('input', function () { dirty = true; });
    entry.form.addEventListener('change', function () { dirty = true; });
    saveButton = editorButton(ENTRY_TEXT.save, 'le-btn le-panel__primary', submit);
    panelFooter().append(saveButton, editorButton(ENTRY_TEXT.cancel, 'le-btn le-btn--secondary', closePanel));
    body.append(entry.form);
    entry.focus();
  });
}

// Schema und Name der Liste brauchen keine Einträge: Liste nur mit einem Eintrag holen, sonst lädt
// jede angemeldete Seitenansicht alle Einträge des Typs.
const SCHEMA_ONLY_LIMIT = 1;

// Schema und Name der Liste aus dem list-Endpoint; den Namen merkt sich listLabels (Leiste, Überzeile des Formulars).
function listInfo(place) {
  return editorApi(withQuery(place.urls.list, { type: place.type, limit: SCHEMA_ONLY_LIMIT })).then(function (data) {
    listLabels.set(place.key, typeof data.label === 'string' ? data.label : null);
    return data;
  });
}

// Gefilterte Liste (data-filter="kategorie=Blog", content-types): Wert des Filters für neue Einträge (withFilterDefault),
// ebenso an einer Einzelansicht ohne Eintrag (Galerie je Bereich).
const FILTER_ATTR = 'data-filter';

function add(place) {
  run(function () {
    return listInfo(place).then(function (data) {
      openForm(place, withFilterDefault(data.schema, place.container.getAttribute(FILTER_ATTR)), null);
    });
  });
}

function loadEntry(place, id) {
  return editorApi(withQuery(place.urls.get, { type: place.type, id: id }));
}

// Eine Einzelansicht hat keine Leiste, die den Namen schon geholt hätte: er kommt wie dort aus listInfo, ohne ihn heißt die
// Überzeile wie bisher „Eintrag“.
function edit(place, id) {
  run(function () {
    const label = place.single && !listLabels.has(place.key) ? listInfo(place).catch(function () { return null; }) : null;
    return Promise.all([loadEntry(place, id), label]).then(function (results) {
      const data = results[0];
      openForm(place, data.schema, data.row, data.version);
    });
  });
}

// Formular wie „+ Neuer Eintrag“ mit den Werten des Eintrags id; der Filter der Liste bleibt (withFilterDefault, auch für
// ein Feld mit copy: false). Gespeichert steht die Kopie hinter dem Original (after), Abbrechen legt nichts an.
function copy(place, id) {
  run(function () {
    return loadEntry(place, id).then(function (data) {
      openForm(place, withFilterDefault(data.schema, place.container.getAttribute(FILTER_ATTR)), null, null, data.row);
    });
  });
}

// Fragt einmal nach („‚Max Muster‘ löschen?“), der Server entfernt auch ungenutzte Bilder.
function remove(place, id) {
  run(function () {
    return loadEntry(place, id).then(function (data) {
      return askConfirm({ title: deleteQuestion(data.schema, data.row), text: LIST_TEXT.removeNote, confirm: LIST_TEXT.remove, danger: true });
    }).then(function (yes) {
      if (!yes) return null;
      return editorPost(place.urls.delete, { type: place.type, id: id }).then(function () {
        return reload(place, null, LIST_TEXT.deleted);
      });
    });
  });
}

function queueOf(key) {
  if (!queues.has(key)) queues.set(key, { moves: [], waiting: 0, reloading: false, keys: [] });
  return queues.get(key);
}

// moved.target: sichtbarer Nachbar in dieser Liste (in einer gefilterten oder gekürzten Liste nicht unbedingt der in der
// Gesamtreihenfolge), moved.position: lists.positions.before oder .after; der Server setzt den Eintrag in der ganzen
// Reihenfolge davor bzw. dahinter. Die Karte steht da schon an ihrer neuen Stelle (drop), moved.undo hängt sie zurück.
// Danach neu laden (reloadQueue, auch bei moved: false ohne Hinweis) oder nicht, und was nicht mehr an den Server geht
// (dropped), sagt afterSort; neu geladen wird erst am Ende des Gleitens (glided aus onDrop). Liefert das neu geladene
// Element der Liste (null ohne).
function move(sorting, moved, glided) {
  const queue = queueOf(placeOf(sorting.list).key);
  queue.moves.push(moved);
  return runAfter(queue, function () {
    if (moved.dropped) return Promise.resolve(null);
    // Erst jetzt: Hat ein Sortieren davor neu geladen, ist es ein anderes Element.
    const place = placeOf(sorting.list);
    return editorPost(place.urls.sort, { type: place.type, id: moved.id, target: moved.target, position: moved.position })
      .then(function () { return null; }, function (error) { return error; })
      .then(function (failure) {
        moved.failure = failure;
        const next = afterSort(queue.moves.length, queue.moves.indexOf(moved), Boolean(failure), queue.waiting);
        next.drop.forEach(function (index) { queue.moves[index].dropped = true; });
        return next.reload ? reloadQueue(queue, place, glided) : null;
      });
  });
}

// Neu laden, sobald die Karten zu Ende geglitten sind: danach die Reihenfolge des Servers; ein gescheitertes sort mit
// Hinweis, ließ sich auch nicht neu laden (kein Netz), alle Karten zurück (settle). Alt+Pfeil währenddessen (queue.keys)
// geht danach an die neue Liste, sonst spränge die Karte beim Tausch zurück.
function reloadQueue(queue, place, glided) {
  const moves = queue.moves;
  queue.moves = [];
  queue.reloading = true;
  return glided.then(function () { return reload(place, null, null); }).then(function (node) {
    queue.reloading = false;
    settle(moves, node);
    const keys = queue.keys;
    queue.keys = [];
    if (node) keys.forEach(function (pressed) { pressKey(node, pressed); });
    return node || null;
  });
}

// Nach dem Neuladen (node fehlt: gescheitert): Karten zurück und Hinweis eines gescheiterten sort (Regel: settleMoves).
function settle(moves, node) {
  const result = settleMoves(moves, Boolean(node));
  result.undo.forEach(function (moved) { moved.undo(); });
  if (result.failure) notifyError(result.failure);
}

// Knöpfe des Eintrags id in der Liste list zeigen, sein Ziehpunkt bekommt den Fokus; liefert ihn (null, wenn er fehlt).
function focusDragOf(list, id) {
  const item = itemsOf(placeOf(list)).find(function (entry) { return idOf(entry) === id; });
  if (!item) return null;
  focusDrag = id;
  showEntry(item);
  focusDrag = null;
  const focused = editorRoot().activeElement;
  return focused && focused.matches(DRAG_HANDLE) ? focused : null;
}

// Alt+Pfeil, gedrückt während des Neuladens, am Ziehpunkt desselben Eintrags in der neuen Liste ausführen.
function pressKey(list, pressed) {
  const handle = focusDragOf(list, pressed.id);
  if (handle) handle.dispatchEvent(new KeyboardEvent('keydown', { key: pressed.key, altKey: true }));
}

// Gezogene Karte sofort an die neue Stelle (optimistisch): vor bzw. hinter die Karte, die dort stand, im selben Elternelement
// wie diese (so bleibt „Mehr laden“ letztes Kind). Das Umhängen gilt nur bis zum Neuladen (move), frontend/rules.md.
// Per Alt+Pfeil (keying) stehen danach die Knöpfe der Karte wieder da, ihr Ziehpunkt hat den Fokus. glided: Ende des
// Gleitens (onDrop, drag-sort.js).
function drop(sorting, from, to, glided) {
  const items = itemsOf(placeOf(sorting.list));
  const spot = sortPlace(items.map(idOf), from, to);
  if (!spot) return;
  const card = items[from];
  const id = idOf(card);
  const other = items[to];
  const parent = card.parentNode;
  const next = card.nextSibling;
  const keyboard = keying;
  other.parentNode.insertBefore(card, spot.after ? other.nextSibling : other);
  const undo = function () {
    parent.insertBefore(card, next && next.parentNode === parent ? next : null);
  };
  const moved = { id: id, target: spot.target, position: spot.after ? lists.positions.after : lists.positions.before, undo: undo, failure: null, dropped: false };
  move(sorting, moved, glided).then(function (node) {
    if (keyboard && node) focusDragOf(node, id);
  });
}

function sortingOf(list) {
  return sortings.find(function (sorting) { return sorting.list === list; }) || null;
}

// Sortierer der Liste von place: nur über den Ziehpunkt gesteuert (external, an der Liste der Kundenseite hängt nichts),
// Ebene und Ansage im Shadow-Root des Editors. Er hängt am Elternelement der Liste, das beim Neuladen bleibt (nur die Liste
// wird getauscht); die scrollbaren Bereiche sucht er ab der jeweils aktuellen Liste (scrollFrom), auch in ihr selbst.
// Name in Ansage und Kopie am Zeiger: entryName („Anna Muster 3 von 7“).
function sorterOf(place) {
  let sorting = sortingOf(place.container);
  if (!sorting) {
    sorting = { list: place.container, sorter: null };
    sortings.push(sorting);
  }
  if (!sorting.sorter) {
    sorting.sorter = dragSort(place.container.parentElement, {
      external: true,
      layer: editorRoot(),
      scrollFrom: function () { return sorting.list; },
      items: function () { return itemsOf(placeOf(sorting.list)); },
      label: function (item) { return entryName(item, HEADING_SELECTOR, LIST_TEXT.entry); },
      onDrop: function (from, to, glided) { drop(sorting, from, to, glided); }
    });
  }
  return sorting.sorter;
}

// „Ansehen“: Sortierer lösen, ihre Ansage ist weg; beim nächsten Ziehen neu angelegt.
function disposeSorters() {
  sortings.forEach(function (sorting) {
    if (sorting.sorter) sorting.sorter.dispose();
    sorting.sorter = null;
  });
}

// Ziehpunkt als Knopf am Eintrag (overlay.js chip.button): Ziehen mit dem Zeiger nur, wenn gerade nichts geladen wird;
// Alt+Pfeil auch dann (das Sortieren wartet, runAfter), während die Liste neu geladen wird erst danach (queue.keys). Ein Klick
// tut nichts.
function dragChip(place, item) {
  const button = dragHandle();
  button.addEventListener('pointerdown', function (event) {
    if (!busy) sorterOf(place).begin(event, item);
  });
  button.addEventListener('keydown', function (event) {
    const queue = queueOf(place.key);
    if (queue.reloading && keyStep(event.key, event.altKey)) {
      event.preventDefault();
      queue.keys.push({ id: idOf(item), key: event.key });
      return;
    }
    keying = true;
    sorterOf(place).key(event, item);
    keying = false;
  });
  return button;
}

// Knopf-Quelle für interact.js: Eintrag (bzw. Einzelansicht) oder Liste eines mitmachenden Plugins. „Mehr laden“
// gehört nicht dazu: Sonst finge interact.js den Klick als Link mit Bearbeitbarem ab („Öffnen →“), statt dass das
// Skript des Plugins die nächsten Einträge anhängt (danach listReloaded, mountListBars).
const entrySource = {
  anchorFor: function (el) {
    if (el.closest(attrSelector(attrs.more))) return null;
    const item = el.closest(attrSelector(attrs.item));
    const container = item ? containerOf(item) : el.closest(attrSelector(attrs.list));
    return container && placeOf(container) ? item || container : null;
  },
  chips: function (anchor) {
    if (!anchor.hasAttribute(attrs.item)) return [];
    return itemChips(placeOf(containerOf(anchor)), anchor);
  },
  // Klick auf einen Eintrag (nicht auf die Liste daneben) öffnet sein Formular, an einer Einzelansicht ohne Eintrag das
  // für einen neuen.
  activate: function (anchor) {
    if (!anchor.hasAttribute(attrs.item)) return null;
    const place = placeOf(containerOf(anchor));
    if (creates(anchor)) return function () { add(place); };
    const id = idOf(anchor);
    return function () { edit(place, id); };
  },
  // Eintrag einer Liste mit attrs.itemForm: auch als Link öffnet der Klick das Formular, keine Link-Knöpfe.
  formOnly: function (anchor) {
    return anchor.hasAttribute(attrs.item) && containerOf(anchor).hasAttribute(attrs.itemForm);
  }
};

// Knöpfe am Eintrag, welche und in welcher Reihenfolge sagt entryActions; die Einzelansicht hat nur Bearbeiten bzw. ohne
// Eintrag Anlegen mit dem Text vom Plugin (singleLabelOf).
function itemChips(place, item) {
  const id = idOf(item);
  const items = itemsOf(place);
  const sortable = Boolean(place.urls.sort) && !place.container.hasAttribute(attrs.fixedOrder);
  const chip = function (label, name, onClick, extra) {
    return Object.assign({ anchor: item, place: CHIP_PLACE.corner, label: label, icon: name, iconOnly: true, onClick: onClick }, extra);
  };
  const chips = {
    edit: function () { return chip(LIST_TEXT.edit, 'pencil', function () { edit(place, id); }, Object.assign({ iconOnly: false, tone: 'primary' }, place.single ? { label: singleLabelOf(place.container) } : null)); },
    create: function () { return chip(singleLabelOf(place.container), 'plus', function () { add(place); }, { iconOnly: false, tone: 'primary' }); },
    drag: function () { return { anchor: item, place: CHIP_PLACE.corner, button: dragChip(place, item), focus: id === focusDrag }; },
    copy: function () { return chip(LIST_TEXT.copy, 'copy', function () { copy(place, id); }); },
    remove: function () { return chip(LIST_TEXT.remove, 'trash', function () { remove(place, id); }, { tone: 'danger' }); }
  };
  return entryActions(place.single, sortable, items.length, creates(item)).map(function (name) { return chips[name](); });
}

function countText(n) {
  return n + ' ' + (n === 1 ? LIST_TEXT.entry : LIST_TEXT.entries);
}

// Leiste unter einer Liste: Name (sobald bekannt), Zahl der Einträge, „+ Neuer Eintrag“.
function listBar(place) {
  const bar = document.createElement('div');
  bar.className = 'le-listbar';
  const label = document.createElement('span');
  label.className = 'le-listbar__label';
  const name = document.createElement('strong');
  const count = document.createElement('span');
  const fill = function () {
    const known = listLabels.get(place.key);
    name.textContent = known ? known + ' · ' : '';
    count.textContent = countText(itemsOf(place).length);
  };
  fill();
  label.append(name, count);
  bar.append(icon('items'), label, labeledButton('plus', LIST_TEXT.add, 'le-btn le-btn--small', function () { add(place); }));
  if (!listLabels.has(place.key)) {
    listLabels.set(place.key, null);
    listInfo(place).then(mountListBars, function () { /* ohne Namen bleibt die Zahl */ });
  }
  return bar;
}

// Knopf auf der ganzen Fläche einer leeren Einzelansicht, beim Bearbeiten immer da (auch am Handy ohne erstes Antippen):
// derselbe wie beim Überfahren (itemChips: „… anlegen“ bzw. „… bearbeiten“ mit Text vom Plugin).
function emptySingleButton(single) {
  const chip = itemChips(placeOf(single), single)[0];
  return labeledButton(chip.icon, chip.label, 'le-single-empty', chip.onClick);
}

// Leisten unter allen Listen und Knöpfe auf leeren Einzelansichten neu anheften (beim Start und nachdem eine Liste neu
// geladen wurde); bei offenem Dialog lägen sie über ihm und bleiben weg.
function mountListBars() {
  unpinBars.forEach(function (unpin) { unpin(); });
  unpinBars = dialogItem ? [] : listsOnPage().map(function (list) {
    return pin(list, listBar(placeOf(list)));
  }).concat(emptySinglesOnPage().map(function (single) {
    return pin(single, emptySingleButton(single), PIN_PLACE.cover);
  }));
}

// itemDialog: detail.item ist ein Element im gezeigten Eintrag oder null (Dialog zu). Nur Einträge
// mitmachender Listen bekommen den Knopf in der Leiste.
function onItemDialog(event) {
  const shown = event.detail && event.detail.item instanceof Element ? event.detail.item.closest(attrSelector(attrs.item)) : null;
  const container = shown ? containerOf(shown) : null;
  dialogItem = container && placeOf(container) ? shown : null;
  dialogButton.hidden = !dialogItem;
  if (dialogItem) {
    const label = singleLabelOf(container);
    dialogButton.setAttribute('aria-label', label);
  }
  mountListBars();
}

function editDialogItem() {
  if (dialogItem && dialogItem.isConnected) edit(placeOf(containerOf(dialogItem)), idOf(dialogItem));
}

// Wechsel auf „Bearbeiten“ (bar.js onModeChange, hält ihn nie auf): Im Dialog ist nichts anklickbar,
// also gleich das Formular seines Eintrags; ohne Dialog nichts, ein schon offenes Formular bleibt.
function onModeSwitch(preview) {
  if (preview) disposeSorters();
  if (!preview && !isPanelOpen(FORM_KEY)) editDialogItem();
}

// Knopf in der Leiste für den Eintrag im Dialog, nur mit Symbol (aria-label und Tooltip setzt onItemDialog).
function buildDialogButton() {
  const button = iconButton('items', '', 'le-icon-btn', editDialogItem);
  button.hidden = true;
  return addBarButton(button);
}

export function mountPluginLists(config) {
  lists = config.pluginLists;
  attrs = lists.attrs;
  events = lists.events;
  addChipSource(entrySource);
  dialogButton = buildDialogButton();
  document.addEventListener(events.itemDialog, onItemDialog);
  // Auch Skripte der Website melden nachgeladene Einträge so („Mehr laden“ der Content-Typen): Leisten mit neuer
  // Zahl an die gewachsene Liste.
  document.addEventListener(events.listReloaded, mountListBars);
  onModeChange(onModeSwitch);
  measureListSpace();
  mountListBars();
  let scheduled = false;
  window.addEventListener('resize', function () {
    if (scheduled) return;
    scheduled = true;
    window.requestAnimationFrame(function () {
      scheduled = false;
      measureListSpace();
    });
  });
}
