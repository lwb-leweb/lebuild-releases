import { state, labelFor } from '../shared/core.js';
import { setImageSource, setBackgroundImage, setIcon, setFocus, fieldValue, hasFieldValue, focusPathOf, displaySize, imageElement, FIELD_KIND, IMAGE_KINDS, EDIT_ATTR } from './page-sync.js';
import { imagePicker as uploadPicker, imageDropArea, uploadPending, settledAction } from '../shared/upload.js';
import { framingField, FRAMING_TEXT } from '../shared/image-framing.js';
import { measureAll, pageLabel } from '../shared/framing-measure.js';
import { everyWidthMeasured } from '../shared/framing-geometry.js';
import { keepSuccess } from '../shared/pending.js';
import { record, resync, editChanged, pageUploads, beginEdit, endEdit, activeEdit, onPageSaved } from './session.js';
import { openPopover } from './popover.js';
import { openPanel, closePanel, isPanelOpen, panelFooter, confirmPanelClose, setPanelEyebrow } from './panel.js';
import { showActive } from './overlay.js';
import { iconGrid, ICON_TEXT } from '../shared/icon-grid.js';
import { notify, notifyError, editorButton, editorRoot } from './bar.js';

// Bild und Hintergrundbild am Element: Panel „Bild“ mit dem Ausschnitt im Feld (framingField, shared/image-framing.js):
// „Anderes Bild“ und Ablegen laden gleich hoch (mit der höchsten Anzeigebreite des Elements), Zuschnitt und Fokuspunkt
// liegen im Bild, Vorschauen zeigen die aktuelle Seite je Breite (gemessen in unsichtbaren iframes). Das Element der Seite
// zeigt jede Änderung sofort; am Desktop liegt das Panel auf der Seite, auf der es das Element nicht verdeckt. Das Panel ist die laufende Bearbeitung: Übernehmen (auch Klick daneben, Strg+S) macht aus
// Bild, Alt-Text und Fokuspunkt eine Änderung; Abbrechen zeigt wieder den bisherigen Wert. Hochgeladene und
// zugeschnittene Bilder, die nicht übernommen wurden, löscht der Server beim Schließen.

const IMAGE_TEXT = {
  alt: 'Alt-Text',
  image: 'Bild',
  background: 'Hintergrund'
};

// Raster der Feldart icon (form.css); auch Plugin-Formular (PAGE_LOOK).
export const ICON_GRID_LOOK = {
  grid: 'le-icon-grid',
  item: 'le-icon-grid__item',
  empty: 'le-icon-grid__empty'
};

// Knopf der Dateiauswahl im Seiten-Editor (ui.css); auch „Alle Texte“ und Plugin-Formular.
export const PICKER_CLASS = 'le-btn le-btn--secondary le-picker';

// Panel „Bild“ (isPanelOpen) und Klassen der Knöpfe des Ausschnitts und seines Fußes (panel.css, ui.css); auch
// Plugin-Formular (PAGE_LOOK).
const IMAGE_KEY = 'image';
export const FRAMING_BUTTONS = {
  primary: 'le-btn le-panel__primary',
  secondary: 'le-btn le-btn--secondary',
  text: 'le-btn le-btn--text',
  option: 'le-btn le-btn--secondary le-btn--small'
};

// Ablagefläche eines Bildfeldes im Seiten-Editor (form.css); auch Plugin-Formular (PAGE_LOOK).
const DROP_CLASSES = {
  drop: 'le-field__drop',
  active: 'le-field__drop--active',
  image: 'le-field__image',
  empty: 'le-field__image-empty'
};

// Dateiauswahl mit Upload (upload.js) im Aussehen des Seiten-Editors, für das Formular der Seite; maxWidth: höchste
// Anzeigebreite des Bildes (displaySize), null ohne.
export function pageImagePicker(onUrl, maxWidth) {
  return uploadPicker(onUrl, notify, PICKER_CLASS, pageUploads, maxWidth);
}

// Bildtausch am Element el (Bild- oder Hintergrund-Feld path) als Werte einer Änderung: neues Bild, dazu ist dessen
// Fokuspunkt leer (er gehörte zum alten Bild).
export function imageSwapValues(el, path, url) {
  const values = [{ path: path, before: fieldValue(path), after: url }];
  const focusPath = el ? focusPathOf(el, el.getAttribute(EDIT_ATTR.bg) === path) : '';
  if (focusPath) values.push({ path: focusPath, before: fieldValue(focusPath), after: '' });
  return values;
}

// Ablagefläche zur Dateiauswahl picker (pageImagePicker): Vorschau, Hineinziehen, Klick.
export function pageImageDropArea(picker) {
  return imageDropArea(picker, DROP_CLASSES);
}

// Die aktuelle Seite als Stelle ihrer Bilder, beim ersten Panel „Bild“ geholt und gemerkt, solange es gelingt (keepSuccess;
// die Messseite zeigt den gespeicherten Stand: nach dem Speichern lädt die Seite neu, nach einem Speichern mit Konflikten
// gilt beides nicht mehr). pageName: Promise mit dem kurzen Namen der Seite ('' ohne, gemerkt nur ein Name). pageFrames:
// Promise mit den Rahmen je Pfad, alle Bild- und Hintergrund-Felder der Seite auf einmal gemessen, die iframes in der
// Ebene des Editors (gemerkt nur, wenn jede Breite gemessen ist).
const pageName = keepSuccess(function () { return pageLabel(state.currentPage); }, Boolean);
const pageFrames = keepSuccess(function () {
  const paths = Object.keys(state.fieldKinds).filter(function (path) {
    return IMAGE_KINDS.indexOf(state.fieldKinds[path]) !== -1 && imageElement(path) !== null;
  });
  const picks = paths.map(function (path) { return function (doc) { return imageElement(path, doc); }; });
  return measureAll(editorRoot(), window.location.href, picks).then(function (lists) {
    const byPath = {};
    paths.forEach(function (path, index) { byPath[path] = lists[index]; });
    return byPath;
  });
}, function (byPath) {
  return everyWidthMeasured(Object.values(byPath), Object.keys(state.preview.widths));
});
onPageSaved(function () {
  pageName.forget();
  pageFrames.forget();
});

// Stellen des Felds path in framing (framingField setPlaces): die Seite, sobald das Feld gemessen ist, erst unter
// fallback, ihr kurzer Name wird nachgetragen (er wartet nicht auf die Messung und sie nicht auf ihn); ohne Messung keine.
function showPagePlaces(framing, path, fallback) {
  pageFrames.get().then(function (byPath) {
    const frames = byPath[path] || [];
    if (!frames.length) return;
    framing.setPlaces([{ label: fallback, frames: frames }]);
    pageName.get().then(function (name) {
      if (name) framing.setPlaces([{ label: name, frames: frames }]);
    });
  });
}

// Liegt das Element eher rechts auf der Seite? Dann öffnet das Panel links (openPanel left).
function onRightSide(el) {
  const box = el.getBoundingClientRect();
  return box.left + box.width / 2 > window.innerWidth / 2;
}

// Panel „Bild“ für ein Bild-Feld (path) oder Hintergrund-Feld (background); altPath nur bei Bildern, preview(url) zeigt
// einen Wert am Element. Es geht sofort auf; die Überzeile ist die Bezeichnung des Felds, bis der kurze Name der Seite da
// ist (ohne ihn bleibt sie).
function openImagePanel(el, path, altPath, preview, background) {
  const before = fieldValue(path);
  const focusPath = focusPathOf(el, background);
  const focusBefore = focusPath ? fieldValue(focusPath) : '';
  const altBefore = altPath ? fieldValue(altPath) : '';
  const title = background ? IMAGE_TEXT.background : IMAGE_TEXT.image;
  const draft = { url: before, focus: focusBefore, closed: false, committed: false };
  // Hier hochgeladene und zugeschnittene Bilder (neue Dateien); was beim Schließen nicht übernommen ist, wird gleich erledigt.
  const uploaded = [];
  let editor = null;
  openPanel({
    key: IMAGE_KEY,
    eyebrow: labelFor(path),
    title: title,
    left: onRightSide(el),
    // Mit Änderungen fragen ×, Esc und ein anderes Panel nach; zu geht das Panel dann ohne seine Eingaben.
    isDirty: function () { return editor !== null && editor.isDirty(); },
    onClose: function () {
      if (editor && activeEdit() === editor) endEdit(false);
    }
  }).then(function (body) {
    if (!body) return;
    pageName.get().then(function (name) {
      if (name) setPanelEyebrow(body, name);
    });
    if (!endEdit(true)) {
      closePanel();
      return;
    }
    const framing = framingField({
      url: before,
      // Ohne Fokus-Feld kein Punkt (er ginge beim Übernehmen verloren), nur Zuschnitt.
      focus: focusPath ? focusBefore : null,
      maxWidth: displaySize(el),
      form: pageUploads,
      notify: notify,
      buttons: FRAMING_BUTTONS,
      drop: DROP_CLASSES,
      replace: true,
      removeLabel: null,
      onChange: function (result) {
        if (draft.closed) {
          if (result.fresh) pageUploads.close([result.url]);
          return;
        }
        if (result.fresh) uploaded.push(result.url);
        if (result.focus !== draft.focus) {
          draft.focus = result.focus;
          if (focusPath) setFocus(el, result.focus);
        }
        if (result.url !== draft.url) {
          draft.url = result.url;
          preview(result.url);
        }
        editChanged();
      }
    });
    showPagePlaces(framing, path, labelFor(path));
    // Im Feldkopf nur die Knöpfe: Bild bzw. Hintergrund steht schon im Titel des Panels.
    body.appendChild(framing.element);
    let altInput = null;
    if (altPath) {
      const altLabel = document.createElement('label');
      altLabel.className = 'le-field';
      altLabel.appendChild(document.createElement('span')).textContent = IMAGE_TEXT.alt;
      altInput = document.createElement('input');
      altInput.type = 'text';
      altInput.value = altBefore;
      altInput.addEventListener('input', function () {
        el.alt = altInput.value;
        editChanged();
      });
      // Enter im Alt-Text wie Übernehmen (wartet ebenso auf einen Zuschnitt).
      altInput.addEventListener('keydown', function (event) {
        if (event.key !== 'Enter') return;
        event.preventDefault();
        apply.click();
      });
      altLabel.appendChild(altInput);
      body.appendChild(altLabel);
    }
    // Übernehmen wartet gesperrt auf einen ausstehenden Zuschnitt (settledAction, mit Zeitgrenze), ein laufender Upload
    // lehnt ab (commit).
    const applying = settledAction(notify, function (busy) { apply.disabled = busy; });
    const apply = editorButton(FRAMING_TEXT.apply, FRAMING_BUTTONS.primary, function () {
      applying.run(function () {
        if (activeEdit() === editor) endEdit(true);
      });
    });
    panelFooter().append(editorButton(FRAMING_TEXT.cancel, FRAMING_BUTTONS.secondary, function () { endEdit(false); }), apply);

    editor = {
      contains: function (node) { return node === el; },
      // Esc im Panel gehört dem Panel (fragt mit Änderungen nach), nicht der Bearbeitung.
      owns: function () { return false; },
      handlers: null,
      // Esc auf der Seite: wie × am Panel.
      escape: function () {
        confirmPanelClose().then(function (yes) {
          if (yes && activeEdit() === editor) endEdit(false);
        });
        return true;
      },
      isDirty: function () { return framing.isDirty() || (altInput !== null && altInput.value !== altBefore); },
      // Solange ein Upload oder Zuschnitt läuft, bleibt das Panel offen (Hinweis von uploadPending; Klick daneben, Strg+S).
      commit: function () {
        if (uploadPending(notify)) return false;
        const values = [{ path: path, before: before, after: draft.url }];
        if (altInput) values.push({ path: altPath, before: altBefore, after: altInput.value });
        if (focusPath) values.push({ path: focusPath, before: focusBefore, after: draft.focus });
        record(values);
        draft.committed = true;
        return true;
      },
      cancel: function () {},
      close: function () {
        draft.closed = true;
        framing.dispose();
        showActive(null);
        if (isPanelOpen(IMAGE_KEY)) closePanel();
        pageUploads.close(uploaded.filter(function (url) { return !draft.committed || url !== draft.url; }));
        resync();
      }
    };
    beginEdit(editor);
    showActive(el);
    // Übernehmen hat den Fokus, Esc gilt dann dem Panel.
    apply.focus({ preventScroll: true });
  });
}

// Bild (img): Datei und Alt-Text, wenn das Bild ein Alt-Feld hat.
export function openImage(el, field) {
  const altPath = state.fieldKinds[field.altPath] === FIELD_KIND.alt && hasFieldValue(field.altPath) ? field.altPath : '';
  openImagePanel(el, field.path, altPath, function (url) { setImageSource(el, url); }, false);
}

// Hintergrundbild eines Elements (Knopf am Element).
export function openBackground(el, path) {
  openImagePanel(el, path, '', function (url) { setBackgroundImage(el, url); }, true);
}

// Icon (svg): Raster aller Icons mit Suche (icon-grid.js); ein Klick zeigt das Icon gleich auf der
// Seite, Übernehmen macht daraus eine Änderung.
export function openIcon(el, field) {
  const path = field.path;
  const before = fieldValue(path);
  const draft = { value: before };
  const icons = iconGrid(ICON_GRID_LOOK, before, function (name) {
    draft.value = name;
    setIcon(el, name);
    editChanged();
  });
  const body = document.createElement('div');
  body.className = 'le-popover__body';
  const label = document.createElement('label');
  label.className = 'le-field';
  label.appendChild(document.createElement('span')).textContent = ICON_TEXT.search;
  label.appendChild(icons.search);
  body.append(label, icons.grid, icons.empty);

  const popover = openPopover({
    anchor: el,
    title: labelFor(path),
    body: body,
    isDirty: function () { return draft.value !== before; },
    commit: function () {
      record([{ path: path, before: before, after: draft.value }]);
      return true;
    },
    cancel: function () {},
    close: function () { resync(); }
  });
  icons.search.focus({ preventScroll: true });
  icons.ready.then(function () { popover.reposition(); }, notifyError);
}
