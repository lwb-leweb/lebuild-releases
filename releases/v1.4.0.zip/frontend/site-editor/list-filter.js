// Gefilterte Liste (data-filter="kategorie=Blog", content-types): Ein neuer Eintrag bekommt den Wert des Filters vorab
// (default), damit er in dieser Liste landet. Das gilt auch für eine Kopie, deren Filterfeld copy: false hat: copyValues
// lässt das Feld weg, das Formular startet mit default. Getrennt am ersten „=“ wie auf dem Server
// (content_types_list_filter). Ohne Importe und ohne DOM, damit node es prüfen kann (tests/frontend/entry-copy.test.php).
export function withFilterDefault(schema, filter) {
  const cut = filter ? filter.indexOf('=') : -1;
  if (cut <= 0) return schema;
  const name = filter.slice(0, cut);
  const value = filter.slice(cut + 1);
  return schema.map(function (field) {
    return field.name === name ? Object.assign({}, field, { default: value }) : field;
  });
}

// Einzelansicht (le_single_attrs) in der neu geladenen Seite wiederfinden (plugin-lists.js, reload): Attribute neben ihrem
// Schlüssel als [Name, Wert] (names: { item, filter }). Mit data-filter (Ansicht single der Content-Typen) immer über den
// Filter, gefüllt wie leer: Die Stelle bleibt, der Eintrag darin kann ein anderer sein (neu angelegt, Filterfeld geändert).
// Ohne Filter (eigene Seite, Hinweis, Öffnungszeiten) über die id (item); ohne beides nur der Schlüssel (Reihenfolge).
export function singleMatch(item, filter, names) {
  if (filter !== null) return [[names.filter, filter]];
  return item === '' ? [] : [[names.item, item]];
}

// Wird ein Element desselben Schlüssels nach dem Speichern mitgetauscht (plugin-lists.js, reload)? Jede Liste und jede
// Einzelansicht mit data-filter (ihr Eintrag kann gewechselt haben). Eine Einzelansicht ohne Filter (eigene Seite, Hinweis,
// Öffnungszeiten) nicht, wie vor der Ansicht single: Ihr Eintrag hängt nicht an der Stelle (Status zeigt nach dem Löschen
// den nächsten Bereich), über ihre alte id fände der Tausch nichts.
export function swapsAlong(single, filter) {
  return !single || filter !== null;
}

// Ist der gespeicherte Eintrag nach dem Tausch zu sehen (plugin-lists.js, reload: sonst „nicht zu sehen“)? found: je getauschter
// Stelle, die bediente zuerst, [steht er darin, trägt sie singleHidden (nur für Angemeldete, z. B. noch nicht fällig)]. Eine
// Liste zählt nur sich selbst (danach prüft reload „Mehr laden“), eine Einzelansicht jede Stelle der Seite: Mit geändertem
// Filterwert steht er an einer anderen Einzelansicht (Galerie praxis → team).
export function shownAfterSave(single, found) {
  const shown = function (spot) { return spot[0] && !spot[1]; };
  return single ? found.some(shown) : shown(found[0]);
}
