<?php
declare(strict_types=1);

// Vorlagen der Website für Content-Typen (public/site/includes/content-types/<typ>/) und die Helfer,
// die sie nutzen. Die Helfer escapen selbst, auch für Attribute (data-category="…" mit ct_text).

require_once __DIR__ . '/lib.php';

// Eigene Vorlagen für Blöcke (Feldart blocks, ct_blocks): CONTENT_TYPES_TEMPLATE_DIR/_blocks/<art>.php; der
// Unterstrich hält den Ordner frei von Typnamen (die mit einem Buchstaben beginnen).
const CONTENT_TYPES_BLOCK_DIR = '_blocks';
// Blockarten, deren Text als Klartext zählt (Beschreibung, fallback): Feld und ob es richtext ist (sonst wörtlich).
const CONTENT_TYPES_BLOCK_TEXT_FIELDS = ['text' => ['text', true], 'zitat' => ['text', false]];
// Dateien der Vorlagen in CONTENT_TYPES_TEMPLATE_DIR/<typ>/ (lib.php).
const CONTENT_TYPES_TEMPLATES = ['card' => 'card.php', 'detail' => 'detail.php', 'page' => 'page.php'];
// Karte mit Ziel modal: öffnet den versteckten Inhalt mit gleicher id (Modal-Skript des Plugins).
const CONTENT_TYPES_OPEN_ATTR = 'data-ct-open';
const CONTENT_TYPES_MODAL_ATTRS = ['role' => 'button', 'tabindex' => '0', 'aria-haspopup' => 'dialog'];
// Versteckter Inhalt (detail.php) je Eintrag mit Ziel modal, angehängt an die Liste, mit der Adresse des
// Modals (#<typ>-<slug|id>, content_types_modal_hash) in CONTENT_TYPES_HASH_ATTR.
const CONTENT_TYPES_DETAIL_ATTR = 'data-ct-detail';
const CONTENT_TYPES_HASH_ATTR = 'data-ct-hash';
// Am Listen-Element eines Typs mit modal in actions (auch leer oder gerade ohne Modal-Eintrag): Seiten
// damit bekommen das Modal-Skript (content_types_filter_site_html), auch für später angelegte Einträge.
const CONTENT_TYPES_MODAL_LIST_ATTR = 'data-ct-modal';
// Schlüssel im $item der Vorlagen für das Klickziel (['action', 'href']); Feldnamen beginnen mit a–z.
const CONTENT_TYPES_ITEM_TARGET = '_target';
// HTML-Kommentare statt einer Vorlagen-Ausgabe bzw. des Filters (Details nur im Log); fehlt die ganze
// Liste, gilt CONTENT_TYPES_RENDER_FAILED.
const CONTENT_TYPES_RENDER_COMMENT = [
    'template' => 'template error',
    'detailMissing' => 'detail.php missing',
    'filter' => 'unknown filter field',
];
// Leere Liste.
const CONTENT_TYPES_EMPTY_TEXT = 'Noch keine Einträge.';
// Knopf an der Einzelansicht (eigene Seite, Modal) auf der Website (le_single_mark).
const CONTENT_TYPES_SINGLE_LABEL = 'Diesen Eintrag bearbeiten';
// Höchstlänge der Meta-Beschreibung der eigenen Seite (descriptionField, z. B. richtext), sonst mit „…“.
const CONTENT_TYPES_DESCRIPTION_MAX = 160;
// Höchstlänge des Ersatzes für ein leeres Feld mit fallback (Anfang des anderen Feldes als Klartext), sonst mit „…“.
const CONTENT_TYPES_FALLBACK_MAX = 200;
// Eigene Seite ohne page.php: detail.php kommt in dieses Element der Startseite, ohne es in <body>; ohne
// Startseite in dieses schlichte Dokument (%s = detail.php).
const CONTENT_TYPES_PAGE_FRAME = 'main';
const CONTENT_TYPES_PAGE_FALLBACK = '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"></head><body><main>%s</main></body></html>';

/** Pfad einer Vorlage ($template: Schlüssel aus CONTENT_TYPES_TEMPLATES) oder null, wenn es sie nicht gibt. */
function content_types_template_path(string $type, string $template): ?string
{
    if (!content_types_name_valid($type) || !isset(CONTENT_TYPES_TEMPLATES[$template])) {
        return null;
    }
    $path = CONTENT_TYPES_TEMPLATE_DIR . '/' . $type . '/' . CONTENT_TYPES_TEMPLATES[$template];

    return is_file($path) ? $path : null;
}

/** HTML-Kommentar statt einer Ausgabe ($key aus CONTENT_TYPES_RENDER_COMMENT). */
function content_types_render_comment(string $key): string
{
    return '<!-- content-types: ' . CONTENT_TYPES_RENDER_COMMENT[$key] . ' -->';
}

/**
 * Eintrag für die Vorlagen: gespeicherte Werte mit id und dem Klickziel unter CONTENT_TYPES_ITEM_TARGET.
 * link führt auf url (nur erlaubte Schemata), page auf /<page.path>/<slug>; ohne Adresse gilt none.
 * Ein leeres Feld mit fallback bekommt den Anfang seines Quellfeldes (content_types_fill_fallbacks).
 */
function content_types_template_item(array $def, array $row): array
{
    $row = content_types_fill_fallbacks($def, $row);
    $action = content_types_item_action($def, $row);
    $href = match ($action) {
        'link' => is_string($row['url'] ?? null) ? sanitize_url($row['url'], TEXT_LINK_SCHEMES) : '',
        'page' => is_string($row['slug'] ?? null) && $row['slug'] !== '' ? '/' . $def['page']['path'] . '/' . rawurlencode($row['slug']) : '',
        default => '',
    };
    if (in_array($action, ['link', 'page'], true) && $href === '') {
        $action = 'none';
    }
    $row[CONTENT_TYPES_ITEM_TARGET] = ['action' => $action, 'href' => $href];

    return $row;
}

/**
 * Felder mit fallback (Definition geprüft, content_types_definition_problem), die leer sind oder nur Leerraum
 * enthalten, bekommen den Anfang ihres Quellfeldes als Klartext (richtext ohne Auszeichnung, Umbrüche als
 * Leerzeichen), höchstens CONTENT_TYPES_FALLBACK_MAX Zeichen inkl. „…“. Gespeichert wird nichts.
 */
function content_types_fill_fallbacks(array $def, array $row): array
{
    foreach (content_types_schema_columns($def) as $field) {
        $from = $field['fallback'] ?? null;
        $value = $row[$field['name']] ?? '';
        if (is_string($from) && (!is_scalar($value) || trim((string) $value) === '')) {
            $row[$field['name']] = content_types_plain($def, $row, $from, CONTENT_TYPES_FALLBACK_MAX);
        }
    }

    return $row;
}

/**
 * Ausgabe einer Vorlage mit $item und $type (Typ-Definition), solange auch als ct_item()/ct_type(). Wirft sie,
 * wird die angefangene Ausgabe verworfen, der Fehler geloggt und null geliefert.
 */
function content_types_render_template(string $path, array $def, array $item): ?string
{
    $level = ob_get_level();
    $previous = content_types_current(['item' => $item, 'type' => $def, 'detail' => '']);
    ob_start();
    try {
        (static function (string $__path, array $item, array $type): void {
            require $__path;
        })($path, $item, $def);
    } catch (Throwable $e) {
        while (ob_get_level() > $level) {
            ob_end_clean();
        }
        error_log('content-types: ' . $def['name'] . '/' . basename($path) . ' item ' . ($item['id'] ?? '?') . ': ' . $e->getMessage());
        return null;
    } finally {
        content_types_current($previous);
    }

    return (string) ob_get_clean();
}

/**
 * Eintrag, den gerade eine Vorlage ausgibt (content_types_render_template, page.php): item, type und detail
 * (fertige Ausgabe von detail.php, nur für page.php). Mit $set ersetzt; liefert den bisherigen. Quelle von
 * ct_item(), ct_type() und ct_detail(), die Includes der Website nicht überschreiben können wie $item
 * (z. B. foreach ($NAV_ITEMS as $item) in einer Navigation auf oberster Ebene).
 */
function content_types_current(?array $set = null): array
{
    static $current = ['item' => [], 'type' => [], 'detail' => ''];
    $previous = $current;
    if ($set !== null) {
        $current = $set;
    }

    return $previous;
}

/**
 * Eigene Seite eines Eintrags (Hook site_page) als Dokument für index.php (le_site_document): detail.php, als
 * Einzelansicht markiert (le_single_mark), in page.php (sieht $item, $type, $detail, sicher vor Includes der
 * Website als ct_item(), ct_type(), ct_detail()) oder im Rahmen der
 * Startseite. Beide bindet index.php auf oberster Ebene ein wie jede Seite; danach setzt finish
 * Titel, Beschreibung, canonical, og und <base> auf die Startseite (relative Adressen des Rahmens).
 * null, wenn das Ziel nicht page ist oder detail.php fehlt bzw. wirft (Grund im Log).
 */
function content_types_page(array $def, array $row): ?array
{
    $item = content_types_template_item($def, $row);
    $target = content_types_item_target($item);
    if ($target['action'] !== 'page') {
        return null;
    }
    $detailPath = content_types_template_path($def['name'], 'detail');
    if ($detailPath === null) {
        error_log('content-types: ' . $def['name'] . ': ' . CONTENT_TYPES_RENDER_COMMENT['detailMissing']);
        return null;
    }
    $detail = content_types_render_template($detailPath, $def, $item);
    if ($detail === null) {
        return null;
    }
    $detail = le_single_mark($detail, 'content-types', $def['name'], (int) $item['id'], CONTENT_TYPES_SINGLE_LABEL);
    $head = [
        'title' => content_types_plain($def, $item, $def['page']['titleField']),
        'description' => content_types_plain($def, $item, $def['page']['descriptionField'], CONTENT_TYPES_DESCRIPTION_MAX),
        'canonical' => (le_site_base_url() ?? '') . $target['href'],
        'base' => LE_SITE_HOME_URL,
    ];

    $pagePath = content_types_template_path($def['name'], 'page');
    if ($pagePath !== null) {
        // page.php läuft auf oberster Ebene: $item und $type können ihre Includes überschreiben, ct_item() usw. nicht.
        $entry = ['item' => $item, 'type' => $def, 'detail' => $detail];
        content_types_current($entry);
        $finish = static fn (string $html): string => le_site_html_set_head($html, $head);
        return le_site_document($pagePath, 200, $entry, $finish, $pagePath);
    }
    $home = le_site_request_file(LE_SITE_HOME_URL);
    $finish = static fn (string $html): string => le_site_html_set_head(content_types_page_frame($html, $detail), $head);

    return le_site_document($home !== null && le_site_is_document($home) ? $home : null, 200, [], $finish, $detailPath);
}

/**
 * Rahmen der eigenen Seite ohne page.php: $home ist die gerenderte Startseite (mit ihrem Kopf und Fuß, bei
 * PHP-Seiten aus ihren Includes); ihr CONTENT_TYPES_PAGE_FRAME bzw. <body> enthält danach nur $detail.
 * Ohne Startseite oder ohne beides CONTENT_TYPES_PAGE_FALLBACK.
 */
function content_types_page_frame(string $home, string $detail): string
{
    $doc = markup_parse($home);
    $index = markup_find_tag($doc, CONTENT_TYPES_PAGE_FRAME) ?? markup_find_tag($doc, 'body');

    return $index !== null ? markup_apply($home, [markup_set_inner($doc, $index, $detail)]) : sprintf(CONTENT_TYPES_PAGE_FALLBACK, $detail);
}

/**
 * Klartext eines Feldes des Typs $def (Titel, Beschreibung im Kopf der Seite): richtext ohne Auszeichnung,
 * text und textarea wörtlich (reiner Text, Umbrüche als Leerzeichen), höchstens $max Zeichen inkl. „…“; escaped wird beim Einsetzen.
 */
function content_types_plain(array $def, array $item, string $field, ?int $max = null): string
{
    $value = $item[$field] ?? '';
    $types = array_column(content_types_schema_columns($def), 'type', 'name');
    $text = match (true) {
        ($types[$field] ?? null) === 'blocks' => content_types_blocks_plain($value),
        !is_scalar($value) => '',
        ($types[$field] ?? null) === 'richtext' => text_markup_plain((string) $value),
        default => (string) $value,
    };

    return text_excerpt($text, $max ?? mb_strlen($text), true);
}

/** Klartext der Text- und Zitat-Blöcke eines blocks-Wertes (CONTENT_TYPES_BLOCK_TEXT_FIELDS), durch Leerzeichen getrennt. */
function content_types_blocks_plain(mixed $value): string
{
    $parts = [];
    foreach (plugin_schema_list_rows($value) as $block) {
        [$field, $rich] = CONTENT_TYPES_BLOCK_TEXT_FIELDS[$block[PLUGIN_SCHEMA_BLOCK_TYPE] ?? ''] ?? [null, false];
        if ($field !== null && is_string($block[$field] ?? null)) {
            $parts[] = $rich ? text_markup_plain($block[$field]) : $block[$field];
        }
    }

    return implode(' ', $parts);
}

/**
 * Adresse des Modals ohne #: <typ>-<slug>, wenn der Typ eigene Seiten hat und der Eintrag eine Adresse,
 * sonst <typ>-<id>. Ein eigenes Feld slug eines Typs ohne page zählt nicht (beliebiger Text).
 */
function content_types_modal_hash(array $def, array $item): string
{
    $slug = in_array('page', $def['actions'], true) && is_string($item['slug'] ?? null) ? $item['slug'] : '';

    return $def['name'] . '-' . ($slug !== '' ? $slug : (string) (int) ($item['id'] ?? 0));
}

/** Klickziel aus content_types_template_item(); ohne (z. B. Zeile aus ct_rows) none ohne Adresse. */
function content_types_item_target(array $item): array
{
    $target = $item[CONTENT_TYPES_ITEM_TARGET] ?? null;

    return is_array($target) ? $target : ['action' => 'none', 'href' => ''];
}

/** Eintrag, den die Vorlage gerade ausgibt (wie $item, aber sicher vor Includes der Website); außerhalb []. */
function ct_item(): array
{
    return content_types_current()['item'];
}

/** Typ-Definition des Eintrags, den die Vorlage gerade ausgibt (wie $type); außerhalb []. */
function ct_type(): array
{
    return content_types_current()['type'];
}

/** In page.php: fertige Ausgabe von detail.php (wie $detail); sonst ''. */
function ct_detail(): string
{
    return content_types_current()['detail'];
}

/** Text eines Feldes, escaped (auch für Attribute); Listen und fehlende Felder ergeben ''. */
function ct_text(array $item, string $field): string
{
    $value = $item[$field] ?? '';

    return is_scalar($value) ? markup_attr_escape((string) $value) : '';
}

/** Mehrzeiliger Text (textarea) eines Feldes, escaped, Zeilenumbrüche als <br>; Listen und fehlende Felder ergeben ''. */
function ct_lines(array $item, string $field): string
{
    $value = $item[$field] ?? '';

    return is_scalar($value) ? le_text_lines((string) $value) : '';
}

/** Formatierter Text (richtext) eines Feldes, bereinigt wie beim Speichern. */
function ct_rich(array $item, string $field): string
{
    $value = $item[$field] ?? '';

    return is_string($value) ? plugin_sanitize_richtext($value) : '';
}

/** <img> eines Bildfeldes (Regel wie beim Speichern), Alt-Text aus dem Feld $altField; ohne Bild ''. */
function ct_image(array $item, string $field, string $altField = ''): string
{
    $value = $item[$field] ?? '';
    $src = is_string($value) ? sanitize_field_value('image', $value) : '';
    if ($src === '') {
        return '';
    }
    $alt = $altField !== '' && is_scalar($item[$altField] ?? null) ? (string) $item[$altField] : '';

    return '<img ' . le_attrs(['src' => $src, 'alt' => $alt]) . '>';
}

/**
 * <svg> eines Icon-Feldes (Satz des Seiten-Editors, Attribute wie beim Tausch auf der Seite), $size Pixel
 * breit und hoch, aria-hidden; ohne Icon ''.
 */
function ct_icon(array $item, string $field, int $size = 24): string
{
    require_once __DIR__ . '/../../core/icons.php';
    $name = is_string($item[$field] ?? null) ? le_icon_name($item[$field]) : '';
    if ($name === '') {
        return '';
    }
    $attrs = ['xmlns' => 'http://www.w3.org/2000/svg', 'width' => (string) $size, 'height' => (string) $size]
        + LE_ICON_SVG_ATTRS + LE_ICON_SVG_DEFAULTS + ['aria-hidden' => 'true'];

    return '<svg ' . le_attrs($attrs) . '>' . LE_ICON_SET[$name][0] . '</svg>';
}

/** Zeilen eines list-Feldes; jede lässt sich wie $item mit den Helfern ausgeben. */
function ct_rows(array $item, string $field): array
{
    return plugin_schema_list_rows($item[$field] ?? null);
}

/**
 * Attribute für das Element, das die Vorlage mit ct_tag() öffnet: link und page href (extern mit
 * target/rel), modal CONTENT_TYPES_OPEN_ATTR mit der id und Rolle eines Knopfes; none ''.
 */
function ct_action_attrs(array $item): string
{
    $target = content_types_item_target($item);
    if ($target['href'] !== '') {
        return ct_url_attrs($target, 'href');
    }
    if ($target['action'] === 'modal') {
        return le_attrs([CONTENT_TYPES_OPEN_ATTR => (int) ($item['id'] ?? 0)] + CONTENT_TYPES_MODAL_ATTRS);
    }

    return '';
}

/**
 * Attribute für einen Link auf die Adresse eines url-Feldes (auch in Zeilen aus ct_rows): href, bei einem
 * anderen Host mit target/rel (le_url_link_attrs, wie beim Klickziel); ohne erlaubte Adresse ''.
 */
function ct_url_attrs(array $item, string $field): string
{
    $value = $item[$field] ?? '';
    $href = is_string($value) ? sanitize_url($value, TEXT_LINK_SCHEMES) : '';

    return $href === '' ? '' : le_attrs(['href' => $href] + le_url_link_attrs($href));
}

/**
 * Blöcke eines blocks-Feldes als HTML in ihrer Reihenfolge: je Art die Vorlage der Website
 * (CONTENT_TYPES_TEMPLATE_DIR/_blocks/<art>.php mit $block und $item, Werte über die ct_-Helfer), sonst
 * das schlichte Markup aus content_types_block_html (Klassen ct-block, ct-block--<art>). Unbekannte Arten
 * fallen weg; wirft eine Vorlage, steht für den Block ein Kommentar (Grund im Log).
 */
function ct_blocks(array $item, string $field): string
{
    $html = '';
    foreach (plugin_schema_list_rows($item[$field] ?? []) as $block) {
        $type = $block[PLUGIN_SCHEMA_BLOCK_TYPE] ?? null;
        if (!is_string($type) || !isset(PLUGIN_SCHEMA_BLOCKS[$type])) {
            continue;
        }
        $path = CONTENT_TYPES_TEMPLATE_DIR . '/' . CONTENT_TYPES_BLOCK_DIR . '/' . $type . '.php';
        $html .= is_file($path) ? (content_types_render_block($path, $block, $item) ?? content_types_render_comment('template')) : content_types_block_html($type, $block);
    }

    return $html;
}

/** Schlichtes Markup eines Blocks der Art $type (PLUGIN_SCHEMA_BLOCKS), escaped über die ct_-Helfer. */
function content_types_block_html(string $type, array $block): string
{
    $caption = static fn (array $row): string => (string) ($row['text'] ?? '') !== '' ? '<figcaption>' . ct_text($row, 'text') . '</figcaption>' : '';
    $lazy = static fn (string $img): string => $img === '' ? '' : substr_replace($img, '<img loading="lazy" ', 0, 5);
    $class = 'ct-block ct-block--' . $type;

    return match ($type) {
        'text' => '<div class="' . $class . '">' . ct_rich($block, 'text') . '</div>',
        'bild' => '<figure class="' . $class . '">' . ct_image($block, 'bild', 'text') . $caption($block) . '</figure>',
        'galerie' => '<div class="' . $class . '">' . implode('', array_map(
            static fn (array $row): string => '<figure>' . $lazy(ct_image($row, 'bild', 'text')) . $caption($row) . '</figure>',
            ct_rows($block, 'bilder')
        )) . '</div>',
        'zitat' => '<blockquote class="' . $class . '"><p>' . ct_lines($block, 'text') . '</p>'
            . ((string) ($block['quelle'] ?? '') !== '' ? '<footer>' . ct_text($block, 'quelle') . '</footer>' : '') . '</blockquote>',
        'downloads' => '<ul class="' . $class . '">' . implode('', array_map(
            static fn (array $row): string => '<li><a ' . ct_url_attrs($row, 'link') . '>' . ct_text($row, 'titel') . '</a></li>',
            ct_rows($block, 'dateien')
        )) . '</ul>',
        default => '',
    };
}

/** Ausgabe der Vorlage eines Blocks mit $block und $item; wirft sie, null (angefangene Ausgabe verworfen, Grund im Log). */
function content_types_render_block(string $path, array $block, array $item): ?string
{
    $level = ob_get_level();
    ob_start();
    try {
        (static function (string $__path, array $block, array $item): void {
            require $__path;
        })($path, $block, $item);
    } catch (Throwable $e) {
        while (ob_get_level() > $level) {
            ob_end_clean();
        }
        error_log('content-types: ' . CONTENT_TYPES_BLOCK_DIR . '/' . basename($path) . ': ' . $e->getMessage());
        return null;
    }

    return (string) ob_get_clean();
}

/** Element für einen Eintrag: a bei link und page, sonst div. */
function ct_tag(array $item): string
{
    return content_types_item_target($item)['href'] !== '' ? 'a' : 'div';
}
