<?php
require_once __DIR__ . '/../template.php';

$type = (string) ($attrs['type'] ?? '');
$limit = content_types_list_limit($attrs['limit'] ?? null);

if (!content_types_name_valid($type)) {
    echo CONTENT_TYPES_RENDER_FAILED;
    return;
}

try {
    $def = content_types_load($type);
    $schema = content_types_schema_columns($def);
} catch (Throwable $e) {
    // Ungültige oder unlesbare Definition: nie ein Fehler auf der Website, Grund nur ins Log.
    error_log('content-types: ' . $e->getMessage());
    echo CONTENT_TYPES_RENDER_FAILED;
    return;
}

try {
    $filter = content_types_list_filter($schema, $attrs['filter'] ?? null);
} catch (InvalidArgumentException $e) {
    // Unbekanntes Feld in data-filter: leere Liste (bleibt bearbeitbar), Grund ins Log.
    error_log('content-types: ' . $type . ': ' . $e->getMessage());
    echo content_types_render_comment('filter');
    $filter = false;
}

try {
    $rows = $filter === false ? [] : content_types_fetch_list($type, $limit, $filter, $def, true);
} catch (Throwable $e) {
    // Datenbankfehler: Grund nur ins Log.
    error_log('content-types: ' . $type . ': ' . $e->getMessage());
    echo CONTENT_TYPES_RENDER_FAILED;
    return;
}

// Mit card.php: Karten direkt im Element des Shortcodes (z. B. dem Grid der Website), das dafür die
// Markierung der Liste bekommt; jede Karte trägt ihre in ihrem Wurzelelement (le_item_mark). Karten sind
// als Ganzes Link oder Knopf, beim Bearbeiten öffnet ein Klick daher immer das Formular
// (LE_ITEM_FORM_ATTR); ein Typ mit Modal bringt das Modal-Skript mit (CONTENT_TYPES_MODAL_LIST_ATTR) und
// die Beschriftung des Knopfes, den die Leiste bei offenem Modal zeigt (wie an der eigenen Seite).
$card = content_types_template_path($type, 'card');
$listAttrs = le_list_attrs('content-types', $type) . (isset($def['orderBy']) ? ' ' . LE_FIXED_ORDER_ATTR : '');
if ($card !== null) {
    $hostAttrs = $listAttrs . ' ' . LE_ITEM_FORM_ATTR
        . (in_array('modal', $def['actions'], true) ? ' ' . CONTENT_TYPES_MODAL_LIST_ATTR . ' ' . le_attrs([LE_SINGLE_LABEL_ATTR => CONTENT_TYPES_SINGLE_LABEL]) : '');
}
if (empty($rows)) {
    // Ohne Vorlage trägt der Platzhalter die Markierung (sonst gäbe es kein „+ Hinzufügen“).
    echo '<p class="content-list content-list--empty"' . ($card === null ? ' ' . $listAttrs : '') . '>' . CONTENT_TYPES_EMPTY_TEXT . '</p>';
    return;
}
if ($card !== null) {
    $modal = [];
    foreach ($rows as $row) {
        $item = content_types_template_item($def, $row);
        $html = content_types_render_template($card, $def, $item);
        echo $html === null ? content_types_render_comment('template') : le_item_mark($html, (int) $item['id']);
        if ($item[CONTENT_TYPES_ITEM_TARGET]['action'] === 'modal') {
            $modal[] = $item;
        }
    }
    // Inhalte der Modals versteckt an der Liste: kein zusätzlicher Request, für Suchmaschinen lesbar.
    $detail = $modal === [] ? null : content_types_template_path($type, 'detail');
    if ($modal !== [] && $detail === null) {
        error_log('content-types: ' . $type . ': ' . CONTENT_TYPES_RENDER_COMMENT['detailMissing']);
        echo content_types_render_comment('detailMissing');
        return;
    }
    foreach ($modal as $item) {
        $html = content_types_render_template($detail, $def, $item);
        echo $html === null
            ? content_types_render_comment('template')
            : '<div hidden ' . le_attrs([CONTENT_TYPES_DETAIL_ATTR => (int) $item['id'], CONTENT_TYPES_HASH_ATTR => content_types_modal_hash($def, $item)]) . '>' . $html . '</div>';
    }
    return;
}
?>
<ul class="content-list content-list--<?= htmlspecialchars($type) ?>" <?= $listAttrs ?>>
  <?php foreach ($rows as $row): ?>
    <li class="content-list__item" <?= le_item_attrs((int) $row['id']) ?>>
      <?php foreach ($schema as $field): ?>
        <?php
          $name = $field['name'];
          $fieldType = $field['type'] ?? 'text';
          $value = $row[$name] ?? '';
          // Zeilen eines list-Feldes zeigt die Standardausgabe nicht.
          if ($value === '' || $value === null || is_array($value)) continue;
        ?>
        <?php if ($fieldType === 'image'): ?>
          <img class="content-list__image" src="<?= htmlspecialchars((string) $value) ?>" alt="">
        <?php elseif ($fieldType === 'richtext'): ?>
          <div class="content-list__richtext"><?= plugin_sanitize_richtext((string) $value) ?></div>
        <?php elseif ($fieldType === 'icon'): ?>
          <span class="content-list__icon"><?= ct_icon($row, $name) ?></span>
        <?php else: ?>
          <div class="content-list__field content-list__field--<?= htmlspecialchars($name) ?>">
            <?= $fieldType === 'textarea' ? le_text_lines((string) $value) : htmlspecialchars((string) $value) ?>
          </div>
        <?php endif ?>
      <?php endforeach ?>
    </li>
  <?php endforeach ?>
</ul>
