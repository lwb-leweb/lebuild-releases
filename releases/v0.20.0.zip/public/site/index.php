<?php
$page = [
    'title'       => 'LeBuild – Wir denken Websites neu',
    'description' => 'Mit LeBuild änderst du deine Website selbst, direkt auf der Seite. Und jede Anpassung oder Automatisierung setzt LEWEB schneller und günstiger um als in WordPress, TYPO3 und Co.',
    'slug'        => '',
    'demos'       => true,
];
require __DIR__ . '/includes/header.php';
?>

<section id="hero" class="hero">
    <div class="container">
        <div class="hero__grid">
            <div class="hero__content">
                <span class="hero__eyebrow" data-edit-id="hero_grid.text">Ohne Vorkenntnisse</span>
                <h1 data-edit-id="hero_grid.title" data-edit-label="Wir denken Websites neu. – Überschrift">Wir denken Websites neu.</h1>
                <p class="hero__lead" data-edit-id="hero_grid.text_2" data-edit-label="Wir denken Websites neu. – Absatz">Kein kompliziertes System, keine hohen Wartungskosten für Änderungen, Anpassungen und Updates. Bestehende Inhalte änderst du einfach mit einem Klick, größere Änderungen machen wir mit modernster Technik zu unschlagbaren Preisen.</p>
                <div class="hero__actions">
                    <a class="button button--accent button--arrow" href="#kontakt" data-edit-id="link_1.url" data-edit-text-id="link_1.text">Jetzt loslegen</a>
                    <a class="button button--ghost" href="#revolution" data-edit-id="link_2.url" data-edit-text-id="link_2.text">Wie das funktioniert</a>
                </div>
            </div>

            <div class="hero__visual">
                <div class="slides" data-slides>
                    <div class="slides__stage">
                        <div class="slide is-active" data-slide>
                            <?php require __DIR__ . '/includes/demos/texte.php'; ?>
                        </div>
                        <div class="slide" data-slide>
                            <?php require __DIR__ . '/includes/demos/eintraege.php'; ?>
                        </div>
                        <div class="slide" data-slide>
                            <?php require __DIR__ . '/includes/demos/oeffnungszeiten.php'; ?>
                        </div>
                    </div>
                    <div class="slides__tabs">
                        <button class="slides__tab is-active" type="button" data-slide-tab data-edit-id="slides_tabs.text">Texte, Bilder, Buttons</button>
                        <button class="slides__tab" type="button" data-slide-tab data-edit-id="slides_tabs.text_2">Einträge verwalten</button>
                        <button class="slides__tab" type="button" data-slide-tab data-edit-id="slides_tabs.text_3">Öffnungszeiten ändern</button>
                    </div>
                    <ul class="perks" aria-label="Deine Vorteile">
                        <li class="perk perk--1"><span class="perk__icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="perk_icon.icon" data-edit-label="Wir denken Websites neu. – Icon 1"><path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/></svg></span><span class="perk__text" data-edit-id="perk.text"><b>Selbst ändern, wann du willst</b><span>Ohne E-Mail an die Agentur, ohne Warten.</span></span></li>
                        <li class="perk perk--2"><span class="perk__icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="perk_icon.icon_2" data-edit-label="Wir denken Websites neu. – Icon 2"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/></svg></span><span class="perk__text" data-edit-id="perk.text_2"><b>Sofort online</b><span>Speichern heißt live. Keine Rechnung für Kleinigkeiten.</span></span></li>
                        <li class="perk perk--3"><span class="perk__icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="perk_icon.icon_3" data-edit-label="Wir denken Websites neu. – Icon 3"><path d="M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z"/></svg></span><span class="perk__text" data-edit-id="perk.text_3"><b>Neues in Minuten</b><span>Unser System ist so schnell, dass auch wir Änderungen im Nu erledigen.</span></span></li>
                        <li class="perk perk--4"><span class="perk__icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="perk_icon.icon_4" data-edit-label="Wir denken Websites neu. – Icon 4"><path d="M4 10h12"/><path d="M4 14h9"/><path d="M19 6a7.7 7.7 0 0 0-5.2-2A7.9 7.9 0 0 0 6 12c0 4.4 3.5 8 7.8 8 2 0 3.8-.8 5.2-2"/></svg></span><span class="perk__text" data-edit-id="perk.text_4"><b>Für ein paar Euro</b><span>Keine Lust, selbst zu ändern? Wir machen’s, günstig und ohne Wartezeit.</span></span></li>
                        <li class="perk perk--5 perk--primary"><span class="perk__icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="perk_icon.icon_5" data-edit-label="Wir denken Websites neu. – Icon 5"><path d="M14 4.1 12 6"/><path d="m5.1 8-2.9-.8"/><path d="m6 12-1.9 2"/><path d="M7.2 2.2 8 5.1"/><path d="M9.037 9.69a.498.498 0 0 1 .653-.653l11 4.5a.5.5 0 0 1-.074.949l-4.349 1.041a1 1 0 0 0-.74.739l-1.04 4.35a.5.5 0 0 1-.95.074z"/></svg></span><span class="perk__text" data-edit-id="perk.text_5"><b>Probier es selbst</b><span>Klick in der Vorschau auf einen Text oder ein Bild und ändere es. Genau so pflegst du später deine Website.</span></span></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="revolution" class="section revolution">
    <div class="container">
        <header class="section__header">
            <h2 data-edit-id="section_header.title_4" data-edit-label="So funktioniert LeBuild – Überschrift">So funktioniert LeBuild</h2>
        </header>
    </div>

    <div class="rev" data-rev>
        <div class="rev__track" data-rev-track>
            <article class="rev-card rev-card--step1">
                <div class="rev-card__top">
                    <h3 class="rev-card__label" data-edit-id="step_card.label" data-edit-label="Schritt 1 · Wir bauen – Überschrift">Schritt 1 · Wir bauen</h3>
                    <button class="rev-card__toggle" type="button" aria-expanded="false" aria-label="Mehr dazu" data-rev-toggle></button>
                </div>
                <p class="rev-card__title" data-edit-id="step_card.title">In wenigen Tagen online.</p>
                <div class="rev-card__visual" aria-hidden="true">
                    <div class="rev-chat" data-rev-chat data-phase="1">
                        <ol class="rev-plan">
                            <li><i><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/></svg></i><span data-edit-id="step_plan.text">Gespräch und Plan</span></li>
                            <li><i><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22a1 1 0 0 1 0-20 10 9 0 0 1 10 9 5 5 0 0 1-5 5h-2.25a1.75 1.75 0 0 0-1.4 2.8l.3.4a1.75 1.75 0 0 1-1.4 2.8z"/><circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/></svg></i><span data-edit-id="step_plan.text_2">Design und Inhalte</span></li>
                            <li><i><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/></svg></i><span data-edit-id="step_plan.text_3">Deine Website ist online</span></li>
                        </ol>
                        <div class="rev-chat__window">
                            <div class="rev-chat__phase" data-chat-phase="1">
                                <p class="rev-msg rev-msg--us" data-edit-id="step_chat.text">Hallo! Erzähl mal: Was soll deine Website können?</p>
                                <p class="rev-msg rev-msg--you" data-edit-id="step_chat.text_2">Sortiment zeigen, Öffnungszeiten und Vorbestellen.</p>
                                <p class="rev-msg rev-msg--us" data-edit-id="step_chat.text_3">Perfekt, daraus mache ich dir einen Plan.</p>
                            </div>
                            <div class="rev-chat__phase" data-chat-phase="2">
                                <p class="rev-msg rev-msg--us rev-msg--preview"><span class="rev-msg__shot"><i></i><i></i><i></i></span><span data-edit-id="step_chat.text_4">Hier ist die Vorschau deiner Website.</span></p>
                                <p class="rev-msg rev-msg--us" data-edit-id="step_chat.text_5">Ich freu mich auf dein Feedback!</p>
                                <p class="rev-msg rev-msg--you" data-edit-id="step_chat.text_6">Wow, genau so hab ich sie mir vorgestellt!</p>
                            </div>
                            <div class="rev-chat__phase" data-chat-phase="3">
                                <p class="rev-msg rev-msg--us" data-edit-id="step_chat.text_7">Deine Website ist jetzt online.</p>
                                <p class="rev-msg rev-msg--you" data-edit-id="step_chat.text_8">Super, danke! Und die Öffnungszeiten ändere ich selbst?</p>
                                <p class="rev-msg rev-msg--us" data-edit-id="step_chat.text_9">Genau. Einfach draufklicken und tippen.</p>
                            </div>
                        </div>
                    </div>
                    <span class="rev-plan__price" data-edit-id="step_plan.text_4">Weit unter Agenturpreis</span>
                </div>
                <div class="rev-card__detail">
                    <p data-edit-id="step_detail.text">Wir bauen deine Website professionell und schnell, in wenigen Tagen statt in Monaten.</p>
                    <p data-edit-id="step_detail.text_2">Weil wir dafür modernste Technik nutzen, liegt der Preis weit unter dem, was Agenturen sonst verlangen.</p>
                </div>
            </article>

            <article class="rev-card rev-card--step2">
                <div class="rev-card__top">
                    <h3 class="rev-card__label" data-edit-id="step_card.label_2" data-edit-label="Schritt 2 · Du änderst – Überschrift">Schritt 2 · Du änderst</h3>
                    <button class="rev-card__toggle" type="button" aria-expanded="false" aria-label="Mehr dazu" data-rev-toggle></button>
                </div>
                <p class="rev-card__title" data-edit-id="step_card.title_2">Alles, was du siehst, änderst du selbst.</p>
                <div class="rev-card__visual" aria-hidden="true">
                    <span class="rev-stat rev-stat--good" data-edit-id="rev_card_visual.text_2"><b>2</b><span><i>Minuten</i><em>Gespeichert</em></span></span>
                    <span class="rev-lists" data-edit-id="rev_card_visual.text_4"><span>Team</span><span>Speisekarte</span><span>Termine</span><b>+ Neuer Eintrag</b></span>
                </div>
                <div class="rev-card__detail">
                    <p data-edit-id="step_detail.text_3">Texte, Bilder, Buttons, Öffnungszeiten: Alles auf deiner Website änderst du direkt auf der Seite.</p>
                    <p data-edit-id="step_detail.text_4">Mit Listen erweiterst du sie sogar selbst, etwa um neue Teammitglieder, Gerichte, Jobs oder Termine.</p>
                    <p data-edit-id="step_detail.text_5">Keine Lust, selbst zu ändern? Dann machen wir das, schnell und für ein paar Euro.</p>
                </div>
            </article>

            <article class="rev-card rev-card--step3">
                <div class="rev-card__top">
                    <h3 class="rev-card__label" data-edit-id="step_card.label_3" data-edit-label="Schritt 3 · Wir bauen um – Überschrift">Schritt 3 · Wir bauen um</h3>
                    <button class="rev-card__toggle" type="button" aria-expanded="false" aria-label="Mehr dazu" data-rev-toggle></button>
                </div>
                <p class="rev-card__title" data-edit-id="step_card.title_3">Größeres macht der Profi.</p>
                <div class="rev-card__visual" aria-hidden="true">
                    <span class="rev-build">
                        <span class="rev-house"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg></span>
                        <span class="rev-build__chip rev-build__chip--1" data-edit-id="step_build.text">Wartung der Technik</span>
                        <span class="rev-build__chip rev-build__chip--2" data-edit-id="step_build.text_2">Neuer Bereich</span>
                        <span class="rev-build__chip rev-build__chip--3" data-edit-id="step_build.text_3">Neues Design</span>
                    </span>
                </div>
                <div class="rev-card__detail">
                    <blockquote class="rev-quote">
                        <p data-edit-id="step_quote.text">Stell dir deine Website wie ein Haus vor: Wir bauen es fix fertig und richten es ein. Um die Technik dahinter kümmern wir uns. Kleinere Dinge tauschst du selbst aus oder stellst sie um. Für Größeres, einen Zubau oder ein neues Design, kommst du zu uns, zu Preisen weit unter Agenturniveau.</p>
                        <cite data-edit-id="step_quote.text_2">Johannes Lehner, Gründer von LeBuild</cite>
                    </blockquote>
                </div>
            </article>
        </div>
        <div class="rev__dots" data-rev-dots></div>
    </div>
</section>

<section id="ki" class="section ki">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="ki_header.text">Und was ist mit KI?</span>
            <h2 data-edit-id="ki_header.title" data-edit-label="Warum nicht einfach mit KI selbst bauen? – Überschrift">Warum nicht einfach mit KI selbst bauen?</h2>
            <p class="section__lead" data-edit-id="ki_header.text_2" data-edit-label="Warum nicht einfach mit KI selbst bauen? – Absatz">Kannst du. Aber im Chat bastelst du keine Website wie vom Profi, und schwierig wird es erst danach.</p>
        </header>

        <ol class="card-grid card-grid--3 ki__steps">
            <li class="feature-card ki-step">
                <span class="feature-card__icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="ki_step.icon" data-edit-label="Im Chat erstellt. – Icon"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></span>
                <span class="ki-step__time" data-edit-id="ki_step.text">Tag 1</span>
                <h3 data-edit-id="ki_step.title" data-edit-label="Im Chat erstellt. – Überschrift">Im Chat erstellt.</h3>
                <p data-edit-id="ki_step.text_2" data-edit-label="Im Chat erstellt. – Absatz">Mit einer Chat-KI steht schnell eine Website. Wirklich schön wird sie so selten: An Design und Technik eines Profis kommt sie bei Weitem nicht heran.</p>
            </li>
            <li class="feature-card ki-step">
                <span class="feature-card__icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="ki_step.icon_2" data-edit-label="Die erste Änderung. – Icon"><path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/></svg></span>
                <span class="ki-step__time" data-edit-id="ki_step.text_3">Woche 2</span>
                <h3 data-edit-id="ki_step.title_2" data-edit-label="Die erste Änderung. – Überschrift">Die erste Änderung.</h3>
                <p data-edit-id="ki_step.text_4" data-edit-label="Die erste Änderung. – Absatz">Neue Öffnungszeiten, ein neues Foto: Die KI baut die Seite wieder neu. Und ändert dabei oft mehr, als du wolltest.</p>
            </li>
            <li class="feature-card ki-step">
                <span class="feature-card__icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="ki_step.icon_3" data-edit-label="Und jede weitere. – Icon"><path d="M5 22h14"/><path d="M5 2h14"/><path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22"/><path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"/></svg></span>
                <span class="ki-step__time" data-edit-id="ki_step.text_5">Jeden Monat</span>
                <h3 data-edit-id="ki_step.title_3" data-edit-label="Und jede weitere. – Überschrift">Und jede weitere.</h3>
                <p data-edit-id="ki_step.text_6" data-edit-label="Und jede weitere. – Absatz">Es gibt keinen Ort, an dem du eine KI-Website einfach pflegst. Sicherheitsupdates bekommst du keine, für alles bist du selbst verantwortlich.</p>
            </li>
        </ol>

        <div class="ki-calc">
            <header class="ki-calc__header">
                <span class="section__eyebrow" data-edit-id="ki_calc.text">Beispielrechnung</span>
                <h3 data-edit-id="ki_calc.title" data-edit-label="Was dich die Website wirklich kostet – Überschrift">Was dich die Website wirklich kostet</h3>
            </header>
            <div class="ki-calc__cols">
                <div class="ki-calc__col">
                    <h4 data-edit-id="ki_calc.title_2" data-edit-label="Selbst mit KI – Überschrift">Selbst mit KI</h4>
                    <ul class="ki-calc__rows">
                        <li data-edit-id="ki_calc_rows.text"><span>Im Chat bauen lassen und nachbessern</span><b>12 Std.</b></li>
                        <li data-edit-id="ki_calc_rows.text_2"><span>Texte und Bilder zusammenstellen</span><b>5 Std.</b></li>
                        <li data-edit-id="ki_calc_rows.text_3"><span>Domain, Hosting, online stellen</span><b>4 Std.</b></li>
                        <li data-edit-id="ki_calc_rows.text_4"><span>Impressum, Datenschutz, Google</span><b>3 Std.</b></li>
                        <li data-edit-id="ki_calc_rows.text_9"><span>Sicherheitsupdates und Wartung</span><b>du allein</b></li>
                    </ul>
                    <p class="ki-calc__total" data-edit-id="ki_calc_col.text" data-edit-label="Selbst mit KI – Absatz 1"><span>Deine Zeit</span><b>rund 24 Std.</b></p>
                    <p class="ki-calc__note" data-edit-id="ki_calc.text_12" data-edit-label="Selbst mit KI – Absatz 2">Bei nur 40 € pro Stunde sind das fast 1.000 €. Und das Ergebnis sieht trotzdem nicht aus wie vom Profi.</p>
                </div>
                <div class="ki-calc__col ki-calc__col--pro">
                    <h4 data-edit-id="ki_calc.title_3" data-edit-label="Mit LeBuild – Überschrift">Mit LeBuild</h4>
                    <ul class="ki-calc__rows">
                        <li data-edit-id="ki_calc_rows.text_5"><span>Gespräch über deine Website</span><b>1 Std.</b></li>
                        <li data-edit-id="ki_calc_rows.text_6"><span>Texte und Bilder zusammenstellen</span><b>5 Std.</b></li>
                        <li data-edit-id="ki_calc_rows.text_7"><span>Design, Technik, online stellen</span><b>machen wir</b></li>
                        <li data-edit-id="ki_calc_rows.text_8"><span>Impressum, Datenschutz, Google</span><b>machen wir</b></li>
                        <li data-edit-id="ki_calc_rows.text_10"><span>Sicherheitsupdates und Wartung</span><b>laufend, von uns</b></li>
                    </ul>
                    <p class="ki-calc__total" data-edit-id="ki_calc_col.text_2" data-edit-label="Mit LeBuild – Absatz 1"><span>Deine Zeit</span><b>rund 6 Std.</b></p>
                    <p class="ki-calc__note" data-edit-id="ki_calc.text_23" data-edit-label="Mit LeBuild – Absatz 2">Dafür bekommst du eine professionelle Website, schon ab 500 €.</p>
                </div>
            </div>
        </div>

        <div class="ki__answer">
            <p class="ki__answer-text" data-edit-id="ki_answer.text"><b>Vom Profi gebaut. Von dir geändert.</b> Mit LeBuild bekommst du eine professionelle Website. Danach klickst du auf den Text, tippst und speicherst. Der Rest bleibt, wie er ist.</p>
            <span class="rev-bar ki__bar" aria-hidden="true" data-edit-id="ki_answer.text_2"><span>Bearbeiten</span><em>Speichern</em></span>
        </div>
    </div>
</section>

<section id="vorteile" class="section">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text_10">Deine Vorteile</span>
            <h2 data-edit-id="section_header.title_9" data-edit-label="Schneller. Einfacher. Besser gefunden. – Überschrift">Schneller. Einfacher. Besser gefunden.</h2>
            <p class="section__lead" data-edit-id="section_header.text_11" data-edit-label="Schneller. Einfacher. Besser gefunden. – Absatz">Eine Website, die nicht nur gut aussieht, sondern auch gefunden wird, bei Google und in KI-Chats.</p>
        </header>

        <div class="card-grid card-grid--3" data-plugin="content-types" data-view="list" data-type="karten" data-filter="kategorie=Startseite – Vorteile" data-limit="50"></div>
    </div>
</section>

<section id="stimmen" class="section quotes">
    <div class="container">
        <header class="section__header">
            <h2 data-edit-id="section_header.title_8" data-edit-label="Das sagen die ersten Kunden – Überschrift">Das sagen die ersten Kunden</h2>
        </header>
    </div>
    <div class="quotes__slider" data-slider>
        <div class="quotes__track" data-slider-track data-plugin="content-types" data-view="list" data-type="stimmen" data-limit="12"></div>
        <div class="rev__dots" data-slider-dots></div>
    </div>
</section>

<section id="mehr" class="section section--soft">
    <div class="container">
        <header class="section__header">
            <h2 data-edit-id="section_header.title_5" data-edit-label="Nicht nur Text. So ziemlich alles. – Überschrift">Nicht nur Text. So ziemlich alles.</h2>
            <p class="section__lead" data-edit-id="section_header.text_8" data-edit-label="Nicht nur Text. So ziemlich alles. – Absatz 1">Alles, was deine Website braucht. Pflegen tust du es selbst.</p>
        </header>

        <div class="showcase" data-showcase>
            <details class="showcase__item" name="mehr" open>
                <summary><span data-edit-id="anything_list.text_9">Speisekarte</span></summary>
                <p data-edit-id="showcase_item.text">Gerichte, Preise und Allergene änderst du in Sekunden, die Tageskarte gleich mit.</p>
                <img class="showcase__image" src="assets/img/mehr/speisekarte.jpg" alt="Angerichtetes Gericht vor dunklem Hintergrund" width="1600" height="1066" loading="lazy" data-edit-id="showcase_item.image" data-edit-alt-id="showcase_item.image_alt">
            </details>
            <details class="showcase__item" name="mehr">
                <summary><span data-edit-id="anything_list.text_10">Angebote</span></summary>
                <p data-edit-id="showcase_item.text_2">Aktionen mit Bild und Preis stellst du online, sobald sie gelten.</p>
                <img class="showcase__image" src="assets/img/mehr/angebote.jpg" alt="Croissants und Kaffee auf dunklem Tisch" width="1600" height="800" loading="lazy" data-edit-id="showcase_item.image_2" data-edit-alt-id="showcase_item.image_2_alt">
            </details>
            <details class="showcase__item" name="mehr">
                <summary><span data-edit-id="anything_list.text_11">Jobs</span></summary>
                <p data-edit-id="showcase_item.text_3">Offene Stellen mit eigener Seite, damit Bewerber dich auch über Google finden.</p>
                <img class="showcase__image" src="assets/img/mehr/jobs.jpg" alt="Junger Mann mit Schürze in der Küche" width="1600" height="1066" loading="lazy" data-edit-id="showcase_item.image_3" data-edit-alt-id="showcase_item.image_3_alt">
            </details>
            <details class="showcase__item" name="mehr">
                <summary><span data-edit-id="anything_list.text_12">Termine</span></summary>
                <p data-edit-id="showcase_item.text_4">Veranstaltungen, Kurse oder Lesungen, immer nach Datum sortiert.</p>
                <img class="showcase__image" src="assets/img/mehr/termine.jpg" alt="Konzert unter Bäumen bei Nacht" width="1600" height="933" loading="lazy" data-edit-id="showcase_item.image_4" data-edit-alt-id="showcase_item.image_4_alt">
            </details>
            <details class="showcase__item" name="mehr">
                <summary><span data-edit-id="anything_list.text_13">Referenzen</span></summary>
                <p data-edit-id="showcase_item.text_5">Deine besten Projekte mit Fotos, Beschreibung und eigener Seite.</p>
                <img class="showcase__image" src="assets/img/mehr/referenzen.jpg" alt="Handwerker in der Werkstatt" width="1600" height="900" loading="lazy" data-edit-id="showcase_item.image_5" data-edit-alt-id="showcase_item.image_5_alt">
            </details>
            <details class="showcase__item" name="mehr">
                <summary><span data-edit-id="anything_list.text_14">Produkte</span></summary>
                <p data-edit-id="showcase_item.text_6">Dein Sortiment mit Bildern, Preisen und Details, so umfangreich, wie du willst.</p>
                <img class="showcase__image" src="assets/img/mehr/produkte.jpg" alt="Weißer Sneaker vor dunklem Hintergrund" width="1600" height="1066" loading="lazy" data-edit-id="showcase_item.image_6" data-edit-alt-id="showcase_item.image_6_alt">
            </details>
            <details class="showcase__item" name="mehr">
                <summary><span data-edit-id="anything_list.text_15">FAQ</span></summary>
                <p data-edit-id="showcase_item.text_7">Häufige Fragen einmal beantworten, statt jeden Tag am Telefon.</p>
                <img class="showcase__image" src="assets/img/mehr/faq.jpg" alt="Nachdenkliche Frau bei Nacht" width="1600" height="900" loading="lazy" data-edit-id="showcase_item.image_7" data-edit-alt-id="showcase_item.image_7_alt">
            </details>
            <details class="showcase__item" name="mehr">
                <summary><span data-edit-id="anything_list.text_16">Blog</span></summary>
                <p data-edit-id="showcase_item.text_8">Neuigkeiten mit Bild, auf Wunsch zu einem festen Termin veröffentlicht.</p>
                <img class="showcase__image" src="assets/img/mehr/blog.jpg" alt="Hände tippen auf einem Laptop" width="1600" height="537" loading="lazy" data-edit-id="showcase_item.image_8" data-edit-alt-id="showcase_item.image_8_alt">
            </details>
            <details class="showcase__item" name="mehr">
                <summary><span data-edit-id="anything_list.text_17">Öffnungszeiten</span></summary>
                <p data-edit-id="showcase_item.text_9">Wochenzeiten, Urlaub und Feiertage, dazu „Jetzt geöffnet“ wie bei Google.</p>
                <img class="showcase__image" src="assets/img/mehr/oeffnungszeiten.jpg" alt="Leuchtschild „Open“ in einem dunklen Raum" width="1600" height="896" loading="lazy" data-edit-id="showcase_item.image_9" data-edit-alt-id="showcase_item.image_9_alt">
            </details>
        </div>
        <p class="showcase__more" data-edit-id="anything_list.text_18" data-edit-label="Nicht nur Text. So ziemlich alles. – Absatz 2">… und alles, was deine Website sonst braucht</p>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="pro">
            <div class="pro__text">
                <h2 data-edit-id="pro_text.title_2" data-edit-label="U name it, we make it. – Überschrift">U name it, we make it.</h2>
                <p data-edit-id="pro_text.text_2" data-edit-label="U name it, we make it. – Absatz">WordPress, TYPO3 und die anderen großen CMS sind schwer anzupassen und kaum zu automatisieren. Bei uns gehen Änderungen, neue Funktionen und Automatisierungen so leicht wie noch nie: schneller umgesetzt und günstiger.</p>
            </div>
            <ul class="pro__list">
                <li><span class="pro__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="pro_icon.icon" data-edit-label="U name it, we make it. – Icon 1"><path d="M12 22a1 1 0 0 1 0-20 10 9 0 0 1 10 9 5 5 0 0 1-5 5h-2.25a1.75 1.75 0 0 0-1.4 2.8l.3.4a1.75 1.75 0 0 1-1.4 2.8z"/><circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/></svg></span><span data-edit-id="pro_list.text">Neues Design</span></li>
                <li><span class="pro__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="pro_icon.icon_2" data-edit-label="U name it, we make it. – Icon 2"><rect width="18" height="7" x="3" y="3" rx="1"/><rect width="9" height="7" x="3" y="14" rx="1"/><rect width="5" height="7" x="16" y="14" rx="1"/></svg></span><span data-edit-id="pro_list.text_2">Neue Bereiche</span></li>
                <li><span class="pro__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="pro_icon.icon_3" data-edit-label="U name it, we make it. – Icon 3"><path d="M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z"/><path d="M20 2v4"/><path d="M22 4h-4"/><circle cx="4" cy="20" r="2"/></svg></span><span data-edit-id="pro_list.text_3">Neue Funktionen</span></li>
                <li><span class="pro__icon"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-edit-id="pro_icon.icon_4" data-edit-label="U name it, we make it. – Icon 4"><path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/></svg></span><span data-edit-id="pro_list.text_4">Automatisierungen</span></li>
            </ul>
        </div>
    </div>
</section>

<section class="section section--soft">
    <div class="container">
        <header class="section__header">
            <h2 data-edit-id="section_header.title_6" data-edit-label="Blitzschnell. Ohne Ballast. – Überschrift">Blitzschnell. Ohne Ballast.</h2>
            <p class="section__lead" data-edit-id="section_header.text_9" data-edit-label="Blitzschnell. Ohne Ballast. – Absatz">Kein schwerfälliges CMS dahinter. Du siehst nur, was du brauchst.</p>
        </header>

        <div class="versus">
            <div class="versus__col">
                <div class="compare__shot compare__shot--cms" aria-hidden="true">
                    <span class="compare__top"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><b>12 Updates</b></span>
                    <span class="compare__body">
                        <span class="compare__side"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></span>
                        <span class="compare__main"><i></i><i></i><i></i><i></i></span>
                    </span>
                </div>
                <h3 data-edit-id="versus_col.title" data-edit-label="Klassisches CMS – Überschrift">Klassisches CMS</h3>
                <ul class="versus__list">
                    <li class="is-con"><span data-edit-id="versus_list.text_2">Eigenes Backend mit hunderten Menüs</span></li>
                    <li class="is-con"><span data-edit-id="versus_list.text_4">Jede Seite wird aus Datenbank und Erweiterungen zusammengebaut, ob nötig oder nicht</span></li>
                    <li class="is-con"><span data-edit-id="versus_list.text_6">Tausend Funktionen, die du nie brauchst</span></li>
                    <li class="is-con"><span data-edit-id="versus_list.text_8">Ständig Updates, die etwas kaputt machen können</span></li>
                    <li class="is-con"><span data-edit-id="versus_list.text_18">Sonderwünsche und Automatisierungen sind aufwendig und teuer</span></li>
                </ul>
            </div>
            <div class="versus__col versus__col--live">
                <div class="compare__shot compare__shot--live" aria-hidden="true">
                    <span class="compare__page"><i></i><i></i><i></i></span>
                    <span class="compare__bar" data-edit-id="compare_shot.text_2"><b>Bearbeiten</b><em>Speichern</em></span>
                </div>
                <h3 data-edit-id="versus_col.title_2" data-edit-label="LeBuild – Überschrift">LeBuild</h3>
                <ul class="versus__list">
                    <li class="is-pro"><span data-edit-id="versus_list.text_10">Direkt auf der Seite: draufklicken, ändern</span></li>
                    <li class="is-pro"><span data-edit-id="versus_list.text_12">Datenbank nur, wo sie Sinn macht, alles andere lädt sofort</span></li>
                    <li class="is-pro"><span data-edit-id="versus_list.text_14">Genau die Funktionen, die du brauchst</span></li>
                    <li class="is-pro"><span data-edit-id="versus_list.text_16">Updates laufen von selbst im Hintergrund</span></li>
                    <li class="is-pro"><span data-edit-id="versus_list.text_20">Jede Anpassung und Automatisierung schnell und günstig umgesetzt</span></li>
                </ul>
            </div>
        </div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
