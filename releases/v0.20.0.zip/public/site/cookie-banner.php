<?php
$page = [
    'title'       => 'Cookie-Banner',
    'description' => 'Ein Cookie-Banner nach DSGVO: YouTube, Google Maps und Statistik laden erst nach Zustimmung, ohne Cookie-Wall und ohne fremden Dienst.',
    'slug'        => 'cookie-banner',
];
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/funktionen-nav.php';
?>

<section class="section section--soft">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text">Cookie-Banner</span>
            <h1 data-edit-id="section_header.title" data-edit-label="Fair zu Besuchern, sicher für dich. – Überschrift">Fair zu Besuchern, sicher für dich.</h1>
            <p class="section__lead" data-edit-id="section_header.text_2" data-edit-label="Fair zu Besuchern, sicher für dich. – Absatz">Videos, Karten und Statistik laden erst, wenn Besucher zustimmen. Das erkennt die Website von selbst, du musst nichts markieren.</p>
        </header>

        <div class="card-grid card-grid--3" data-plugin="content-types" data-view="list" data-type="karten" data-filter="kategorie=Cookie-Banner" data-limit="50"></div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
