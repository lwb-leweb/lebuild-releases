<?php
$page = [
    'title'       => 'Blog',
    'description' => 'Neuigkeiten und Beiträge mit Bild schreibst du direkt auf deiner Website, jeder Beitrag bekommt eine eigene Seite.',
    'slug'        => 'blog',
];
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/funktionen-nav.php';
?>

<section class="section section--soft">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text">Blog</span>
            <h1 data-edit-id="section_header.title" data-edit-label="Neuigkeiten, so schnell wie ein Posting. – Überschrift">Neuigkeiten, so schnell wie ein Posting.</h1>
            <p class="section__lead" data-edit-id="section_header.text_2" data-edit-label="Neuigkeiten, so schnell wie ein Posting. – Absatz">Titel, Bild, Text: Ein Beitrag ist in Minuten online und bleibt dauerhaft auf deiner Website, nicht nur im Feed.</p>
        </header>

        <div id="beitraege" class="beispiele" data-plugin="content-types" data-view="list" data-type="blog" data-limit="6"></div>
    </div>
</section>

<section class="section">
    <div class="container">
        <header class="section__header">
            <h2 data-edit-id="section_header.title_3" data-edit-label="So geht&apos;s – Überschrift">So geht's</h2>
        </header>

        <div class="card-grid card-grid--3 card-grid--steps" data-plugin="content-types" data-view="list" data-type="karten" data-filter="kategorie=Blog – Schritte" data-limit="50"></div>
    </div>
</section>

<section class="section section--soft">
    <div class="container">
        <header class="section__header">
            <h2 data-edit-id="section_header.title_2" data-edit-label="Was der Blog kann – Überschrift">Was der Blog kann</h2>
        </header>

        <div class="card-grid card-grid--3" data-plugin="content-types" data-view="list" data-type="karten" data-filter="kategorie=Blog – Funktionen" data-limit="50"></div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
