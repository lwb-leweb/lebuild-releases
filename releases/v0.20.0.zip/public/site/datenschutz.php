<?php
$page = [
    'title'       => 'Datenschutz',
    'description' => 'Datenschutzerklärung von LeBuild, einem Service von LEWEB Werbeagentur, Johannes Lehner.',
    'slug'        => 'datenschutz',
];
require __DIR__ . '/includes/header.php';
?>

<section class="section section--narrow">
    <div class="container prose">
        <header class="page-header">
            <span class="section__eyebrow" data-edit-id="page_header.text">Rechtliches</span>
            <h1 data-edit-id="page_header.title" data-edit-label="Datenschutz – Überschrift">Datenschutz</h1>
            <p class="section__lead" data-edit-id="page_header.text_2" data-edit-label="Datenschutz – Absatz">Wir speichern so wenig wie möglich: keine Cookies für Besucher, keine Statistik, keine Inhalte von fremden Servern.</p>
        </header>

        <h2 data-edit-id="privacy.title" data-edit-label="Verantwortlich – Überschrift">Verantwortlich</h2>
        <p data-edit-id="privacy.text" data-edit-label="Verantwortlich – Absatz">
            <strong>LEWEB Werbeagentur</strong><br>
            Johannes Lehner<br>
            St. Stefan am Walde 40<br>
            4170 St. Stefan-Afiesl<br>
            Österreich<br>
            E-Mail: <a href="mailto:office@leweb.at">office@leweb.at</a><br>
            Telefon: <a href="tel:+436641327098">+43 664 1327098</a>
        </p>

        <h2 data-edit-id="privacy.title_2" data-edit-label="Hosting und Server-Protokolle – Überschrift">Hosting und Server-Protokolle</h2>
        <p data-edit-id="privacy.text_2" data-edit-label="Hosting und Server-Protokolle – Absatz">
            Diese Website läuft auf einem eigenen Server bei der Hetzner Online GmbH, Industriestr. 25, 91710 Gunzenhausen,
            Deutschland. Mit Hetzner besteht ein Vertrag zur Auftragsverarbeitung nach Art. 28 DSGVO.
        </p>
        <p data-edit-id="privacy.text_3" data-edit-label="Hosting und Server-Protokolle – Absatz 2">
            Bei jedem Aufruf speichert der Server kurz technische Daten: IP-Adresse, Datum und Uhrzeit, aufgerufene Seite,
            Browser und Betriebssystem. Das ist nötig, um die Seite auszuliefern und vor Angriffen zu schützen
            (berechtigtes Interesse, Art. 6 Abs. 1 lit. f DSGVO). Die Protokolle werden nach 14 Tagen gelöscht.
        </p>

        <h2 data-edit-id="privacy.title_3" data-edit-label="Cookies und Speicher im Browser – Überschrift">Cookies und Speicher im Browser</h2>
        <p data-edit-id="privacy.text_4" data-edit-label="Cookies und Speicher im Browser – Absatz">
            Besucher bekommen keine Cookies. Wer auf das dunkle Design umschaltet, dessen Wahl merkt sich der Browser
            selbst; sie wird nicht an uns übertragen. Nur wer sich im Editor anmeldet, erhält ein technisch notwendiges
            Cookie für die Anmeldung, das beim Abmelden gelöscht wird.
        </p>

        <h2 data-edit-id="privacy.title_4" data-edit-label="Kontakt per E-Mail – Überschrift">Kontakt per E-Mail</h2>
        <p data-edit-id="privacy.text_5" data-edit-label="Kontakt per E-Mail – Absatz">
            Wenn du uns schreibst, verwenden wir deine Angaben nur, um deine Anfrage zu beantworten und gegebenenfalls ein
            Angebot oder einen Auftrag abzuwickeln (Art. 6 Abs. 1 lit. b DSGVO). Wir geben sie nicht weiter und löschen
            sie, sobald sie nicht mehr gebraucht werden und keine gesetzliche Aufbewahrungspflicht besteht.
        </p>

        <h2 data-edit-id="privacy.title_5" data-edit-label="Deine Rechte – Überschrift">Deine Rechte</h2>
        <p data-edit-id="privacy.text_6" data-edit-label="Deine Rechte – Absatz">
            Du hast das Recht auf Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung, Datenübertragbarkeit
            und Widerspruch. Schreib dazu einfach an <a href="mailto:office@leweb.at">office@leweb.at</a>.
            Wenn du meinst, dass wir deine Daten nicht korrekt verarbeiten, kannst du dich bei der Österreichischen
            Datenschutzbehörde beschweren: <a href="https://www.dsb.gv.at" target="_blank" rel="noopener">dsb.gv.at</a>.
        </p>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
