<?php
$page = [
    'title'       => 'Öffnungszeiten',
    'description' => 'Öffnungszeiten wie im Google-Unternehmensprofil: mehrere Bereiche, Urlaub und Feiertage, „Jetzt geöffnet“. Du änderst sie direkt auf der Website.',
    'slug'        => 'oeffnungszeiten',
];
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/funktionen-nav.php';
?>

<section class="section section--soft">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text">Öffnungszeiten</span>
            <h1 data-edit-id="section_header.title" data-edit-label="Immer aktuell, auch am Feiertag. – Überschrift">Immer aktuell, auch am Feiertag.</h1>
            <p class="section__lead" data-edit-id="section_header.text_2" data-edit-label="Immer aktuell, auch am Feiertag. – Absatz">Wochenzeiten, Urlaub und Sonderzeiten trägst du einmal ein. Die Website zeigt von selbst, ob gerade offen ist.</p>
        </header>

        <div class="live-demo live-demo--wide area-tabs" data-tabs>
            <div class="area-tabs__list" role="tablist" aria-label="Bereiche">
                <button type="button" class="area-tabs__tab" role="tab" id="tab-wirtshaus" aria-controls="bereich-wirtshaus" aria-selected="true">
                    <span class="area-tabs__name" data-edit-id="tab_wirtshaus.text">Wirtshaus</span>
                    <span data-plugin="opening-hours" data-view="status" data-area="Wirtshaus"></span>
                </button>
                <button type="button" class="area-tabs__tab" role="tab" id="tab-kueche" aria-controls="bereich-kueche" aria-selected="false" tabindex="-1">
                    <span class="area-tabs__name" data-edit-id="tab_kueche.text">Küche</span>
                    <span data-plugin="opening-hours" data-view="status" data-area="Küche"></span>
                </button>
                <button type="button" class="area-tabs__tab" role="tab" id="tab-hofladen" aria-controls="bereich-hofladen" aria-selected="false" tabindex="-1">
                    <span class="area-tabs__name" data-edit-id="tab_hofladen.text">Hofladen</span>
                    <span data-plugin="opening-hours" data-view="status" data-area="Hofladen"></span>
                </button>
            </div>
            <div class="area-tabs__panel" role="tabpanel" id="bereich-wirtshaus" aria-labelledby="tab-wirtshaus">
                <div data-plugin="opening-hours" data-view="week" data-area="Wirtshaus" data-notices="no"></div>
            </div>
            <div class="area-tabs__panel" role="tabpanel" id="bereich-kueche" aria-labelledby="tab-kueche" hidden>
                <div data-plugin="opening-hours" data-view="week" data-area="Küche" data-notices="no"></div>
            </div>
            <div class="area-tabs__panel" role="tabpanel" id="bereich-hofladen" aria-labelledby="tab-hofladen" hidden>
                <div data-plugin="opening-hours" data-view="week" data-area="Hofladen" data-notices="no"></div>
            </div>
            <div class="area-tabs__notices">
                <h3 data-edit-id="area_tabs.title" data-edit-label="Urlaub und Sonderzeiten – Überschrift">Urlaub und Sonderzeiten</h3>
                <div data-plugin="opening-hours" data-view="notices"></div>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <header class="section__header">
            <h2 data-edit-id="section_header.title_2" data-edit-label="Was die Öffnungszeiten können – Überschrift">Was die Öffnungszeiten können</h2>
            <p class="section__lead" data-edit-id="section_header.text_3" data-edit-label="Was die Öffnungszeiten können – Absatz">So viel wie im Google-Unternehmensprofil, nur auf deiner eigenen Website.</p>
        </header>

        <div class="card-grid card-grid--3" data-plugin="content-types" data-view="list" data-type="karten" data-filter="kategorie=Öffnungszeiten" data-limit="50"></div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
