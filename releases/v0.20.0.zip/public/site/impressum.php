<?php
$page = [
    'title'       => 'Impressum',
    'description' => 'Impressum von LeBuild, einem Service von LEWEB Werbeagentur, Johannes Lehner.',
    'slug'        => 'impressum',
];
require __DIR__ . '/includes/header.php';
?>

<section class="section section--narrow">
    <div class="container prose">
        <header class="page-header">
            <span class="section__eyebrow" data-edit-id="page_header.text">Rechtliches</span>
            <h1 data-edit-id="page_header.title" data-edit-label="Impressum – Überschrift">Impressum</h1>
            <p class="section__lead" data-edit-id="page_header.text_2" data-edit-label="Impressum – Absatz">Angaben gemäß § 5 E-Commerce-Gesetz und Offenlegung gemäß § 25 Mediengesetz.</p>
        </header>

        <h2 data-edit-id="container.title" data-edit-label="Anbieter – Überschrift">Anbieter</h2>
        <p data-edit-id="container.text" data-edit-label="Anbieter – Absatz">
            LeBuild ist ein Service von<br>
            <strong>LEWEB Werbeagentur</strong><br>
            Johannes Lehner<br>
            St. Stefan am Walde 40<br>
            4170 St. Stefan-Afiesl<br>
            Österreich
        </p>

        <h2 data-edit-id="container.title_2" data-edit-label="Kontakt – Überschrift">Kontakt</h2>
        <p data-edit-id="container.text_2" data-edit-label="Kontakt – Absatz">
            Telefon: <a href="tel:+436641327098">+43 664 1327098</a><br>
            E-Mail: <a href="mailto:office@leweb.at">office@leweb.at</a><br>
            Web: <a href="https://www.leweb.at" target="_blank" rel="noopener">www.leweb.at</a>
        </p>

        <h2 data-edit-id="container.title_3" data-edit-label="Unternehmensgegenstand – Überschrift">Unternehmensgegenstand</h2>
        <p data-edit-id="container.text_3" data-edit-label="Unternehmensgegenstand – Absatz">Werbegrafik-Design, Webdesign und Webentwicklung.</p>

        <h2 data-edit-id="container.title_4" data-edit-label="UID-Nummer – Überschrift">UID-Nummer</h2>
        <p data-edit-id="container.text_4" data-edit-label="UID-Nummer – Absatz">ATU68283519</p>

        <h2 data-edit-id="container.title_5" data-edit-label="Aufsichtsbehörde / Kammer – Überschrift">Aufsichtsbehörde / Kammer</h2>
        <p data-edit-id="container.text_5" data-edit-label="Aufsichtsbehörde / Kammer – Absatz">
            Mitglied der Wirtschaftskammer Oberösterreich, Fachgruppe Werbung und Marktkommunikation (Werbegrafik-Design)<br>
            Gewerbebehörde: Bezirkshauptmannschaft Rohrbach<br>
            Berufsrecht: Gewerbeordnung, abrufbar unter <a href="https://www.ris.bka.gv.at" target="_blank" rel="noopener">ris.bka.gv.at</a>
        </p>


        <h2 data-edit-id="container.title_7" data-edit-label="Haftungsausschluss – Überschrift">Haftungsausschluss</h2>
        <p data-edit-id="container.text_7" data-edit-label="Haftungsausschluss – Absatz">
            Die Inhalte dieser Website wurden mit größtmöglicher Sorgfalt erstellt. Für die
            Richtigkeit, Vollständigkeit und Aktualität der Inhalte kann jedoch keine Gewähr
            übernommen werden. Für die Inhalte verlinkter Seiten außerhalb unseres Angebots
            übernehmen wir keine Haftung.
        </p>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
