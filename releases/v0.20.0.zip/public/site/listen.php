<?php
$page = [
    'title'       => 'Listen',
    'description' => 'Fragen, Leistungen, Projekte, Team: Alles, was auf deiner Website mehrfach vorkommt, pflegst du als Liste. Und du bestimmst, was beim Klick auf einen Eintrag passiert.',
    'slug'        => 'listen',
];
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/funktionen-nav.php';
?>

<section class="section section--soft">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text">Listen</span>
            <h1 data-edit-id="section_header.title" data-edit-label="Alles, was mehrfach vorkommt, ist eine L… – Überschrift">Alles, was mehrfach vorkommt, ist eine Liste.</h1>
            <p class="section__lead" data-edit-id="section_header.text_2" data-edit-label="Alles, was mehrfach vorkommt, ist eine L… – Absatz">Fragen, Leistungen, Projekte, Team: Für jeden Eintrag füllst du ein kurzes Formular aus, die Website zeigt ihn so, wie es zu ihr passt. Und du bestimmst, was beim Klick passiert.</p>
        </header>

        <div class="targets" data-plugin="content-types" data-view="list" data-type="karten" data-filter="kategorie=Listen – Klickziele" data-limit="50"></div>
    </div>
</section>

<section id="faq" class="section section--narrow">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text_3">Ohne Klickziel</span>
            <h2 data-edit-id="section_header.title_2" data-edit-label="Häufige Fragen – Überschrift">Häufige Fragen</h2>
            <p class="section__lead" data-edit-id="section_header.text_4" data-edit-label="Häufige Fragen – Absatz">Einfach aufklappen. Eine neue Frage ist ein neuer Eintrag, die Reihenfolge änderst du mit den Pfeilen.</p>
        </header>

        <div class="faq" data-plugin="content-types" data-view="list" data-type="faq" data-limit="50"></div>
    </div>
</section>

<section id="bausteine" class="section section--soft">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text_5">Details im Fenster</span>
            <h2 data-edit-id="section_header.title_3" data-edit-label="Woraus ein Eintrag bestehen kann – Überschrift">Woraus ein Eintrag bestehen kann</h2>
            <p class="section__lead" data-edit-id="section_header.text_6" data-edit-label="Woraus ein Eintrag bestehen kann – Absatz">Klick auf eine Karte: Die Details öffnen sich über der Seite, du bleibst, wo du bist.</p>
        </header>

        <div class="card-grid bausteine" data-plugin="content-types" data-view="list" data-type="bausteine" data-limit="50"></div>
    </div>
</section>

<section id="beispiele" class="section">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text_7">Eigene Seite oder Link</span>
            <h2 data-edit-id="section_header.title_4" data-edit-label="So könnte das bei dir aussehen – Überschrift">So könnte das bei dir aussehen</h2>
            <p class="section__lead" data-edit-id="section_header.text_8" data-edit-label="So könnte das bei dir aussehen – Absatz">Jeder Eintrag entscheidet selbst: Er bekommt eine eigene Seite, oder er führt woandershin. Umstellen geht mit einem Klick im Formular.</p>
        </header>

        <div class="beispiele" data-plugin="content-types" data-view="list" data-type="beispiele" data-limit="50"></div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
