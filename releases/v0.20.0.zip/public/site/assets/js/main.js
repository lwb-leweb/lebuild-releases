// LEWEB · main.js
// Schlanke Interaktionen: Mobile-Navigation, Scroll-Header, helles/dunkles Design.

(function () {
    'use strict';

    const onReady = (fn) => {
        if (document.readyState !== 'loading') fn();
        else document.addEventListener('DOMContentLoaded', fn);
    };

    onReady(() => {
        initNavToggle();
        initHeaderShadow();
        initThemeToggle();
        document.querySelectorAll('[data-tabs]').forEach(initTabs);
        document.querySelectorAll('[data-showcase]').forEach(initShowcase);
        document.querySelectorAll('.perks').forEach(initPerks);
        document.querySelectorAll('[data-rev]').forEach(initRevCards);
        document.querySelectorAll('[data-slider]').forEach((box) => initDots(box.querySelector('[data-slider-track]'), box.querySelector('[data-slider-dots]')));
    });

    // Die Wahl merkt sich der Browser; header.php setzt sie vor dem ersten Zeichnen.
    function initThemeToggle() {
        const toggle = document.querySelector('[data-theme-toggle]');
        if (!toggle) return;
        toggle.addEventListener('click', () => {
            const root = document.documentElement;
            const dark = root.dataset.theme !== 'dark';
            if (dark) root.dataset.theme = 'dark';
            else delete root.dataset.theme;
            try { localStorage.setItem('theme', dark ? 'dark' : 'light'); } catch (e) {}
        });
    }

    function initNavToggle() {
        const toggle = document.querySelector('[data-nav-toggle]');
        const nav = document.querySelector('[data-nav]');
        if (!toggle || !nav) return;

        const close = () => {
            nav.classList.remove('is-open');
            toggle.setAttribute('aria-expanded', 'false');
        };

        toggle.addEventListener('click', () => {
            const isOpen = nav.classList.toggle('is-open');
            toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });

        // Beim Wechsel auf Desktop-Breite Menü zurücksetzen
        const mq = window.matchMedia('(min-width: 960px)');
        mq.addEventListener('change', (e) => { if (e.matches) close(); });

        // ESC schließt das Menü
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') close();
        });

        // Klick außerhalb schließt das Menü (nur mobile)
        document.addEventListener('click', (e) => {
            if (!nav.classList.contains('is-open')) return;
            if (e.target.closest('[data-nav]') || e.target.closest('[data-nav-toggle]')) return;
            close();
        });
    }

    // Tabs (z. B. Bereiche der Öffnungszeiten): Klick oder Pfeiltasten wählen, nur das zugehörige Panel ist sichtbar.
    function initTabs(box) {
        const tabs = Array.from(box.querySelectorAll('[role="tab"]'));
        const select = (tab) => {
            tabs.forEach((t) => {
                const on = t === tab;
                t.setAttribute('aria-selected', on ? 'true' : 'false');
                t.tabIndex = on ? 0 : -1;
                const panel = document.getElementById(t.getAttribute('aria-controls'));
                if (panel) panel.hidden = !on;
            });
        };
        tabs.forEach((tab, i) => {
            tab.addEventListener('click', () => select(tab));
            tab.addEventListener('keydown', (e) => {
                const step = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[e.key];
                if (!step) return;
                e.preventDefault();
                const next = tabs[(i + step + tabs.length) % tabs.length];
                next.focus();
                select(next);
            });
        });
    }

    // Punkte mit Bild (Startseite „So ziemlich alles“): immer genau einer offen, auch in Browsern ohne <details name>.
    function initShowcase(box) {
        const items = Array.from(box.querySelectorAll('details'));
        items.forEach((item) => {
            item.querySelector('summary').addEventListener('click', (e) => {
                if (item.open) e.preventDefault();
            });
            item.addEventListener('toggle', () => {
                if (item.open) items.forEach((other) => { if (other !== item) other.open = false; });
            });
        });
    }

    // Karten „So funktioniert LeBuild“: Plus klappt den ganzen Text auf, Punkte zeigen und wählen die Karte.
    function initRevCards(box) {
        const track = box.querySelector('[data-rev-track]');
        const cards = Array.from(track.children);
        // Immer nur eine Karte offen; auf breiten Bildschirmen wird sie breit (CSS), danach fährt die Leiste zu ihr.
        const setOpen = (card, open) => {
            card.classList.toggle('is-open', open);
            card.querySelector('[data-rev-toggle]').setAttribute('aria-expanded', String(open));
        };
        cards.forEach((card) => {
            card.querySelector('[data-rev-toggle]').addEventListener('click', () => {
                const open = !card.classList.contains('is-open');
                cards.forEach((other) => { if (other !== card) setOpen(other, false); });
                setOpen(card, open);
                box.classList.toggle('has-open', open);
                follow(card);
            });
        });
        // Während die Breiten wachsen oder schrumpfen (0,6 s), gleitet die Leiste mit, bis die Karte links steht:
        // jedes Bild ein Stück weiter zum gerade gültigen Ziel. Danach die Punkte neu setzen, auch ohne Scroll.
        const follow = (card) => {
            track.classList.add('is-moving');
            const from = track.scrollLeft;
            const start = performance.now();
            const duration = 650;
            const step = (now) => {
                const t = Math.min(1, (now - start) / duration);
                const eased = 1 - Math.pow(1 - t, 3);
                track.scrollLeft = from + (card.offsetLeft - cards[0].offsetLeft - from) * eased;
                if (t < 1) {
                    requestAnimationFrame(step);
                } else {
                    track.classList.remove('is-moving');
                    track.dispatchEvent(new Event('scroll'));
                }
            };
            requestAnimationFrame(step);
        };
        initDots(track, box.querySelector('[data-rev-dots]'));
        const chats = new Map();
        cards.forEach((card) => {
            const chat = card.querySelector('[data-rev-chat]');
            if (chat) chats.set(card, initRevChat(chat));
        });
        // Bildchen spielen ab, sobald ihre Karte gut zu sehen ist, und wieder von vorn, wenn sie zurückkommt.
        if ('IntersectionObserver' in window) {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach((entry) => {
                    const chat = chats.get(entry.target);
                    if (entry.intersectionRatio >= 0.6) {
                        entry.target.classList.add('is-playing');
                        if (chat) chat.start();
                    } else if (!entry.isIntersecting) {
                        entry.target.classList.remove('is-playing');
                        if (chat) chat.stop();
                    }
                });
            }, { threshold: [0, 0.6] });
            cards.forEach((card) => observer.observe(card));
            box.classList.add('is-ready');
        }
    }

    // Chat in Schritt 1: schaltet die Abschnitte (Gespräch, Vorschau, online) der Reihe nach weiter, im Kreis.
    function initRevChat(chat) {
        const count = chat.querySelectorAll('[data-chat-phase]').length;
        let timer = null;
        const show = (phase) => { chat.dataset.phase = String(phase); };
        return {
            start() {
                if (timer) return;
                show(1);
                timer = setInterval(() => show(Number(chat.dataset.phase) % count + 1), 9000);
            },
            stop() {
                clearInterval(timer);
                timer = null;
                show(1);
            },
        };
    }

    // Leiste zum Wischen (Karten oben, Kundenstimmen): je Karte ein Punkt, der aktuelle ist lang, ein Klick fährt hin.
    function initDots(track, dotsBox) {
        const cards = Array.from(track.children).filter((card) => !card.hidden);
        const dots = cards.map((card, i) => {
            const dot = document.createElement('button');
            dot.type = 'button';
            dot.className = 'rev__dot';
            dot.setAttribute('aria-label', 'Karte ' + (i + 1));
            dot.addEventListener('click', () => {
                track.scrollTo({ left: card.offsetLeft - cards[0].offsetLeft, behavior: 'smooth' });
            });
            dotsBox.appendChild(dot);
            return dot;
        });
        const update = () => {
            const max = track.scrollWidth - track.clientWidth;
            // Am Ende ist die letzte Karte die aktuelle, auch wenn sie nicht ganz links anschlagen kann.
            let current = track.scrollLeft >= max - 2 ? cards.length - 1 : 0;
            if (current === 0) {
                cards.forEach((card, i) => {
                    if (card.offsetLeft - cards[0].offsetLeft <= track.scrollLeft + card.offsetWidth / 2) current = i;
                });
            }
            dots.forEach((dot, i) => dot.classList.toggle('is-active', i === current));
        };
        update();
        track.addEventListener('scroll', update, { passive: true });
        window.addEventListener('resize', update);
    }

    // Vorteile neben dem Beispiel: fliegen beim ersten Scrollen von ihrer Seite herein (links von links, rechts
    // von rechts), eines nach dem anderen, und bleiben dann neben dem Fenster stehen. Herein gemessen am
    // Scrollweg der Seite (das Beispiel steht ganz oben), damit sie auf jeder Bildschirmhöhe erst mit dem
    // Scrollen kommen; hinaus genauso zur Seite, sobald ein Kärtchen oben dem Rand nahekommt.
    // Nur wenn sie neben dem Fenster schweben und Bewegung erwünscht ist.
    function initPerks(list) {
        const perks = Array.from(list.children);
        const distance = 320;
        // Scrollweg in px, ab dem ein Kärtchen losfliegt (das fünfte, „Probier es selbst“, zuerst), und wie lang es dafür braucht.
        const starts = [70, 130, 190, 250, 10];
        const span = 240;
        // Abstand zum oberen Rand in px, ab dem ein Kärtchen wieder hinausfliegt (unter dem Kopf der Seite).
        const leaveAt = 120;
        const header = document.querySelector('[data-header]');
        const wide = window.matchMedia('(min-width: 1280px)');
        const still = window.matchMedia('(prefers-reduced-motion: reduce)');
        let queued = false;
        const update = () => {
            queued = false;
            const on = wide.matches && !still.matches;
            const top = (header ? header.offsetHeight : 0) + leaveAt;
            perks.forEach((perk, i) => {
                if (!on) {
                    perk.style.translate = '';
                    perk.style.opacity = '';
                    return;
                }
                const come = Math.min(1, Math.max(0, (window.scrollY - starts[i % starts.length]) / span));
                const leave = Math.min(1, Math.max(0, (top - perk.getBoundingClientRect().top) / span));
                const t = Math.min(come, 1 - leave);
                const eased = 1 - Math.pow(1 - t, 3);
                // Gerade Plätze (1, 3, 5) stehen links, ungerade (2, 4) rechts.
                const side = i % 2 === 0 ? -1 : 1;
                perk.style.translate = (side * distance * (1 - eased)).toFixed(1) + 'px 0';
                perk.style.opacity = Math.min(1, t * 1.6).toFixed(3);
            });
        };
        const queue = () => {
            if (!queued) { queued = true; requestAnimationFrame(update); }
        };
        update();
        window.addEventListener('scroll', queue, { passive: true });
        window.addEventListener('resize', queue);
    }

    function initHeaderShadow() {
        const header = document.querySelector('[data-header]');
        if (!header) return;
        const update = () => {
            header.classList.toggle('is-scrolled', window.scrollY > 4);
        };
        update();
        window.addEventListener('scroll', update, { passive: true });
    }
})();
