<?php
$page = [
    'title'       => 'Für Entwickler',
    'description' => 'Wie LeBuild technisch funktioniert: Import, Marker, JSON, Backups, jeder PHP-Hoster.',
    'slug'        => 'entwickler',
];
require __DIR__ . '/includes/header.php';
?>

<section class="section section--soft">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text_4">Für Entwickler</span>
            <h1 data-edit-id="section_header.title_3" data-edit-label="So funktioniert LeBuild unter der Haube. – Überschrift">So funktioniert LeBuild unter der Haube.</h1>
            <p class="section__lead" data-edit-id="section_header.text_5" data-edit-label="So funktioniert LeBuild unter der Haube. – Absatz">Statische Website rein, Marker drauf, Inhalte in JSON. Ohne Datenbank, auf jedem PHP-Hoster.</p>
        </header>
    </div>
</section>

<section class="section">
    <div class="container about">
        <div class="prose">
        <h2 data-edit-id="container.title" data-edit-label="Was ist LeBuild? – Überschrift">Was ist LeBuild?</h2>
        <p data-edit-id="container.text" data-edit-label="Was ist LeBuild? – Absatz 1">Ein schlankes PHP-Tool, das bestehende statische Websites in editierbare Websites
            verwandelt – ohne sie zu zerstören. Ein einmaliger Import ergänzt die HTML-Elemente
            um data-edit-id-Marker und lagert die Inhalte in JSON aus.</p>
        <p data-edit-id="container.text_2" data-edit-label="Was ist LeBuild? – Absatz 2">Ab da pflegst du Inhalte über einen passwortgeschützten Editor: Texte, Links, Bilder
            ändern sich live, Backups werden automatisch angelegt, das Original bleibt vorhanden.</p>
        <blockquote data-edit-id="container.text_3" data-edit-label="Was ist LeBuild? – Text">
            Gedacht für Agenturen, Freelancer und Hobbyisten, die schnelle, individuelle Websites
            für Kunden bauen und dann eine einfache Pflegelösung übergeben möchten.
        </blockquote>
        </div>
        <figure class="about__media">
            <img src="assets/img/editor.svg" alt="Website im Browser, deren Überschrift gerade bearbeitet wird" width="640" height="520" loading="lazy" data-edit-id="about_media.image" data-edit-alt-id="about_media.image_alt">
        </figure>
    </div>
</section>

<section id="how" class="section section--soft">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text">In drei Schritten</span>
            <h2 data-edit-id="section_header.title" data-edit-label="So funktioniert&apos;s – Überschrift">So funktioniert&apos;s</h2>
            <p class="section__lead" data-edit-id="section_header.text_2" data-edit-label="So funktioniert&apos;s – Absatz">Von der statischen Datei zur pflegbaren Website – ohne deinen Code zu zerstören.</p>
        </header>

        <div class="card-grid card-grid--3 card-grid--steps" data-plugin="content-types" data-view="list" data-type="karten" data-filter="kategorie=Entwickler – Schritte" data-limit="50"></div>
    </div>
</section>

<section class="section">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text_3">Eigenschaften</span>
            <h2 data-edit-id="section_header.title_2" data-edit-label="Was LeBuild besonders macht – Überschrift">Was LeBuild besonders macht</h2>
        </header>

        <div class="card-grid card-grid--2" data-plugin="content-types" data-view="list" data-type="karten" data-filter="kategorie=Entwickler – Eigenschaften" data-limit="50"></div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
