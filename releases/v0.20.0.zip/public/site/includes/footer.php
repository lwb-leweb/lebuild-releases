    </main>

    <section id="kontakt" class="cta-band" aria-labelledby="cta-heading">
        <div class="container cta-band__inner">
            <div>
                <h2 id="cta-heading" class="cta-band__title" data-edit-id="footer.container.title" data-edit-label="Das will ich für meine Website. – Überschrift">Das will ich für meine Website.</h2>
                <p class="cta-band__lead" data-edit-id="footer.container.text" data-edit-label="Das will ich für meine Website. – Absatz">Schreib uns. Wir zeigen dir, wie das bei dir aussieht.</p>
            </div>
            <div class="cta-band__actions">
<?php if (SITE_EMAIL !== ''): ?>
                <a class="button button--accent" href="mailto:<?= e(SITE_EMAIL) ?>" data-edit-text-id="footer.cta_band_actions.text">Kontakt aufnehmen</a>
<?php endif; ?>
                <a class="button button--ghost" href="../admin/" data-edit-id="footer.link_1.url" data-edit-text-id="footer.link_1.text">Anmelden</a>
            </div>
        </div>
    </section>

    <footer class="site-footer">
        <div class="container site-footer__grid">
            <div class="site-footer__brand">
                <a class="brand" href="/" aria-label="<?= e(SITE_NAME) ?> Startseite" data-edit-id="footer.link_5.url">
                    <img class="brand__logo brand__logo--dark" src="assets/img/logo-dark.svg" alt="" width="352" height="278" data-edit-id="footer.brand.image" data-edit-alt-id="footer.brand.image_alt">
                    <img class="brand__logo brand__logo--light" src="assets/img/logo-light.svg" alt="" width="352" height="278" data-edit-id="footer.brand.image_2" data-edit-alt-id="footer.brand.image_2_alt">
                </a>
                <p class="site-footer__tagline" data-edit-id="footer.site_footer_brand.text_3">Websites, die du selbst aktuell hältst. Ein Produkt von LEWEB.</p>
            </div>

            <nav class="site-footer__col" aria-label="Seiten">
                <h2 class="site-footer__heading" data-edit-id="footer.site_footer_pages.title" data-edit-label="Seiten – Überschrift">Seiten</h2>
                <ul>
<?php foreach ($NAV_ITEMS as $item): ?>
                    <li><a href="<?= e($item['href']) ?>"><?= e($item['label']) ?></a></li>
<?php endforeach; ?>
                </ul>
            </nav>

            <div class="site-footer__col">
                <h2 class="site-footer__heading" data-edit-id="footer.site_footer_legal.title" data-edit-label="Kontakt – Überschrift">Kontakt</h2>
                <ul>
<?php if (SITE_EMAIL !== ''): ?>
                    <li><a href="mailto:<?= e(SITE_EMAIL) ?>"><?= e(SITE_EMAIL) ?></a></li>
<?php endif; ?>
                    <li><a href="../admin/" data-edit-id="footer.link_3.url" data-edit-text-id="footer.link_3.text" data-edit-label="Kontakt – Link">Admin-Editor</a></li>
                </ul>
            </div>
        </div>

        <div class="container site-footer__bottom">
            <p>&copy; <?= e((string)date('Y')) ?> <?= e(SITE_NAME) ?><?= SITE_OWNER !== '' ? ' · ' . e(SITE_OWNER) : '' ?></p>
            <nav class="site-footer__legal" aria-label="Rechtliches">
                <a href="/impressum" data-edit-id="footer.link_2.url" data-edit-text-id="footer.link_2.text">Impressum</a>
                <a href="/datenschutz" data-edit-id="footer.link_4.url" data-edit-text-id="footer.link_4.text">Datenschutz</a>
            </nav>
        </div>
    </footer>

    <script src="assets/js/main.js" defer></script>
<?php if (!empty($page['demos'])): ?>
    <script src="assets/js/demos.js" defer></script>
<?php endif; ?>
</body>
</html>
