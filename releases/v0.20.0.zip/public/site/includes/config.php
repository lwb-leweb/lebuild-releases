<?php
// Zentrale Konfiguration für Seiten-Metadaten und Navigation.
// Jede Seite definiert vor dem Einbinden des Headers ihre eigene $page-Variable.

declare(strict_types=1);

require_once __DIR__ . '/icons.php';
require_once LE_PROJECT_ROOT . '/core/siteRoutes.php';

$_cfg = le_site_config();
// Geleerte Werte wie fehlende behandeln, außer $empty ist gesetzt (dann '' statt der Vorgabe).
$_value = static function (string $key, ?string $empty = null) use ($_cfg): string {
    if (!array_key_exists($key, $_cfg)) {
        return LE_SITE_CONFIG_DEFAULTS[$key];
    }
    $value = is_string($_cfg[$key]) ? trim($_cfg[$key]) : '';
    return $value !== '' ? $value : ($empty ?? LE_SITE_CONFIG_DEFAULTS[$key]);
};

define('SITE_NAME',    $_value('name'));
define('SITE_TAGLINE', $_value('tagline'));
// Website-Adresse ohne „/“ am Ende; '' ohne gültige eigene Adresse (die Vorgabe zählt nicht), dann
// fehlen canonical und og:url.
define('SITE_URL',     ($_url = le_site_base_url()) !== null && $_url !== LE_SITE_CONFIG_DEFAULTS['url'] ? $_url : '');
// Geleert: '' – dann keine mailto:-Links bzw. kein Inhaber.
define('SITE_EMAIL',   $_value('email', ''));
define('SITE_OWNER',   $_value('owner', ''));
define('SITE_LOCALE',  $_value('locale'));

unset($_cfg, $_value, $_url);

// Unterseiten von „Funktionen“, je Plugin eine – Reihenfolge bestimmt Anzeige.
$FUNCTION_ITEMS = [
    ['href' => '/listen',          'label' => 'Listen'],
    ['href' => '/oeffnungszeiten', 'label' => 'Öffnungszeiten'],
    ['href' => '/blog',            'label' => 'Blog'],
    ['href' => '/kontaktformular', 'label' => 'Kontaktformular'],
    ['href' => '/cookie-banner',   'label' => 'Cookie-Banner'],
];

// Hauptnavigation – Reihenfolge bestimmt Anzeige. children: Unterseiten, auf denen der Punkt als aktuell gilt.
$NAV_ITEMS = [
    ['href' => '/',           'label' => 'Start'],
    ['href' => '/funktionen', 'label' => 'Funktionen', 'children' => array_column($FUNCTION_ITEMS, 'href')],
    ['href' => '/entwickler', 'label' => 'Für Entwickler'],
];

// Adresse der aktuellen Seite ohne Endung aus ihrem Slug ($page['slug'], leer = Startseite), wie in den
// Links der Navigation. PHP_SELF taugt nicht: Alle Seiten laufen über den Front-Controller /index.php.
function current_page(string $slug = ''): string {
    return '/' . $slug;
}

function e(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
