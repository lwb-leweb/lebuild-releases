<?php if (ct_tag($item) === 'a'): ?>
<a class="targets__item" <?= ct_action_attrs($item) ?>>
    <span class="feature-card__icon"><?= ct_icon($item, 'icon', 22) ?></span>
    <span class="targets__title"><?= ct_text($item, 'titel') ?></span>
    <span><?= ct_lines($item, 'text') ?></span>
<?php if (($item['linktext'] ?? '') !== ''): ?>
    <span class="targets__go"><?= ct_text($item, 'linktext') ?></span>
<?php endif; ?>
</a>
<?php else: ?>
<div class="feature-card">
    <span class="feature-card__icon"><?= ct_icon($item, 'icon', 22) ?></span>
    <h3><?= ct_text($item, 'titel') ?></h3>
    <p><?= ct_lines($item, 'text') ?></p>
</div>
<?php endif; ?>
