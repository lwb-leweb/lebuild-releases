<?php
$firmaOrt = implode(', ', array_filter([ct_text($item, 'firma'), ct_text($item, 'ort')], 'strlen'));
?>
<figure class="quote">
<?php if (ct_text($item, 'bewertung') !== ''): ?>
    <span class="quote__rating"><?= icon('star', 14) ?><span class="visually-hidden">Bewertung: </span><?= str_replace('.', ',', ct_text($item, 'bewertung')) ?><span class="visually-hidden"> von 5</span></span>
<?php endif; ?>
    <blockquote><?= ct_lines($item, 'zitat') ?></blockquote>
    <figcaption><?= ct_image($item, 'bild') ?><span><b><?= ct_text($item, 'name') ?></b><small><?= $firmaOrt ?></small></span></figcaption>
</figure>
