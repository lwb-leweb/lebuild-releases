            <?php /* Leiste des Editors wie auf der echten Seite: Logo, Schalter Bearbeiten, Rückgängig, Speichern,
                     Hilfe, Mehr; der Stand hängt als Lasche daran, solange etwas ungespeichert ist (demos.js). */ ?>
            <div class="demo__bar">
                <span class="demo__status" data-demo-status hidden><i></i><span data-demo-count>1</span><span class="demo__status-word"> ungespeichert</span></span>
                <span class="demo__bar-logo" title="LeBuild"><svg viewBox="0 0 71.81 50.47" aria-hidden="true"><path transform="translate(34.464 43.755)" d="M0,-36.822L0,-41.972C0,-43 -0.873,-43.842 -1.897,-43.747C-20.135,-42.058 -34.463,-26.677 -34.463,-8.005C-34.463,-3.202 -33.513,1.382 -31.795,5.573C-31.381,6.581 -30.197,7.02 -29.251,6.478L-24.77,3.911C-23.994,3.467 -23.694,2.524 -24.014,1.689C-25.171,-1.325 -25.818,-4.588 -25.818,-8.005C-25.818,-21.996 -15.214,-33.527 -1.626,-35.057C-0.71,-35.16 0,-35.9 0,-36.822"/><path transform="translate(37.346 48.905)" d="M0,-47.123L0,-41.973C0,-41.051 0.71,-40.311 1.626,-40.208C15.216,-38.678 25.819,-27.147 25.819,-13.156C25.819,-9.739 25.173,-6.475 24.016,-3.461C23.695,-2.626 23.996,-1.683 24.771,-1.239L29.252,1.328C30.198,1.87 31.382,1.431 31.796,0.422C33.515,-3.769 34.464,-8.353 34.464,-13.156C34.464,-31.828 20.136,-47.209 1.897,-48.898C0.873,-48.993 0,-48.151 0,-47.123"/></svg></span>
                <span class="demo__bar-divider"></span>
                <span class="demo__tool demo__tool--on" title="Bearbeiten ist an"><svg viewBox="0 0 24 24"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg></span>
                <span class="demo__bar-actions">
                    <span class="demo__tool demo__undo" title="Rückgängig" data-demo-undo><svg viewBox="0 0 24 24"><path d="M9 14 4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/></svg></span>
                    <span class="demo__tool demo__save" title="Speichern" data-demo-target="save"><svg viewBox="0 0 24 24"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2Z"/><path d="M17 21v-8H7v8"/><path d="M7 3v5h8"/></svg></span>
                </span>
                <span class="demo__tool" title="Hilfe"><svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 1 0 0-20"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3"/><path d="M12 17h.01"/></svg></span>
                <span class="demo__tool demo__tool--more" title="Mehr"><svg viewBox="0 0 24 24"><path d="M5 12h.01"/><path d="M12 12h.01"/><path d="M19 12h.01"/></svg></span>
            </div>
