<div class="demo" data-demo>
    <template data-demo-template>
        <div class="demo__window">
            <div class="demo__chrome">
                <span class="demo__dots"><i></i><i></i><i></i></span>
                <span class="demo__url">www.baeckerei-huber.at</span>
            </div>
            <div class="demo__page">
                <div class="demo__nav">
                    <span class="demo__logo">huber<b>.</b></span>
                    <span class="demo__links"><i>Sortiment</i><i>Café</i><i>Über uns</i></span>
                    <span class="demo__order">Bestellen</span>
                </div>
                <div class="demo__hero">
                    <div class="demo__text">
                        <h3 class="demo__title" data-demo-target="title" data-demo-new="Jetzt auch sonntags offen!">Frisches Brot jeden Morgen</h3>
                        <p class="demo__lead" data-demo-target="lead">Mit Liebe gebacken, aus <span class="demo__word" data-demo-word>regionalem Mehl</span> – täglich ab 6 Uhr.</p>
                        <span class="demo__actions"><span class="demo__button" data-demo-target="button" data-demo-new="Jetzt bestellen" data-demo-href="/vorbestellen" data-demo-new-href="/bestellen">Vorbestellen</span><span class="demo__button demo__button--light">Sortiment</span></span>
                        <span class="demo__proof">
                            <span class="demo__avatars"><img src="assets/img/demo/kundin-maria.jpg" alt="" width="120" height="120"><img src="assets/img/demo/kundin-julia.jpg" alt="" width="120" height="120"><img src="assets/img/demo/kunde-david.jpg" alt="" width="120" height="120"></span>
                            <span><b>4,9 ★</b> 320 Bewertungen</span>
                        </span>
                    </div>
                    <div class="demo__media">
                        <div class="demo__image" data-demo-target="image">
                            <img class="demo__img demo__img--a" src="assets/img/demo/brot.jpg" alt="" width="800" height="640">
                            <img class="demo__img demo__img--b" src="assets/img/demo/torte.jpg" alt="" width="800" height="640">
                        </div>
                        <span class="demo__float demo__float--open"><i></i>Heute offen · 6–18 Uhr</span>
                        <span class="demo__float demo__float--new"><img src="assets/img/demo/croissants.jpg" alt="" width="480" height="320"><span><small>Neu im Sortiment</small>Butter-Croissant</span></span>
                    </div>
                </div>
                <div class="demo__cards">
                    <span><i class="demo__icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3c.5 3-2.5 4.5-2.5 7.5a2.5 2.5 0 0 0 5 0c0-1-.4-1.8-.8-2.5 2.3 1.2 4.3 3.6 4.3 6.5a6 6 0 0 1-12 0C6 9.5 10 7 12 3z"/></svg></i><span><b>Frisch gebacken</b>Jeden Morgen aus dem Ofen</span></span>
                    <span><i class="demo__icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-6.5-5.6-6.5-11a6.5 6.5 0 0 1 13 0c0 5.4-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.3"/></svg></i><span><b>Regionales Mehl</b>Aus dem Weinviertel</span></span>
                    <span><i class="demo__icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5.5 8h13l-1 12h-11z"/><path d="M9 10V7a3 3 0 0 1 6 0v3"/></svg></i><span><b>Abholen</b>Online vorbestellen</span></span>
                </div>
            </div>
            <?php require __DIR__ . '/leiste.php'; ?>
            <div class="demo__mini" data-demo-mini>
                <span class="demo__mini-tools">
                    <button type="button" data-mini="bold"><b>Fett</b></button>
                    <button type="button" data-mini="italic"><i>Kursiv</i></button>
                    <button type="button" data-mini="link">Link</button>
                </span>
                <span class="demo__mini-link">
                    <input autocomplete="off" placeholder="https://… oder /seite" data-mini-input>
                    <button type="button" data-mini="apply">Übernehmen</button>
                </span>
                <label class="demo__mini-target">Link-Ziel <input autocomplete="off" data-mini-target></label>
            </div>
            <div class="demo__chips" data-demo-chips>
                <button type="button" data-chip="edit">Bearbeiten</button>
                <button type="button" data-chip="open">Öffnen →</button>
            </div>
            <div class="demo__popover" data-demo-popover>
                <b class="demo__popover-title">Bild</b>
                <label class="demo__drop" data-demo-drop>
                    <input type="file" accept="image/*" hidden>
                    <img src="assets/img/demo/brot.jpg" alt="" width="480" height="320" data-demo-drop-img>
                </label>
                <span class="demo__picker" data-demo-picker>Bild auswählen</span>
                <label class="demo__alt">Alt-Text <input name="alt" autocomplete="off" value="Frisches Brot auf dem Holzbrett" data-demo-alt></label>
                <span class="demo__popover-actions">
                    <button class="demo__btn demo__btn--secondary" type="button" data-demo-cancel>Abbrechen</button>
                    <button class="demo__btn" type="button" data-demo-apply>Übernehmen</button>
                </span>
            </div>
            <div class="demo__glow" data-demo-glow><span class="demo__tag" data-demo-tag></span></div>
            <div class="demo__toast" data-demo-toast>Gespeichert – die Seite ist online.</div>
            <div class="demo__pointer" data-demo-cursor>
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 2l16 11-7 1.5L9.5 21z" fill="#0c1b4d" stroke="#fff" stroke-width="1.6" stroke-linejoin="round"/></svg>
                <span class="demo__file" data-demo-file>torte.jpg</span>
            </div>
        </div>
    </template>
</div>
