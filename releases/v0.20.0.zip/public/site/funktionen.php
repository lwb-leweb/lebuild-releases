<?php
$page = [
    'title'       => 'Funktionen',
    'description' => 'Listen, Öffnungszeiten, Blog, Kontaktformular und Cookie-Banner: alles, was LeBuild für deine Website mitbringt, und alles pflegst du selbst.',
    'slug'        => 'funktionen',
];
require __DIR__ . '/includes/header.php';
?>

<section class="section section--soft">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text">Funktionen</span>
            <h1 data-edit-id="section_header.title" data-edit-label="Alles, was deine Website braucht. – Überschrift">Alles, was deine Website braucht.</h1>
            <p class="section__lead" data-edit-id="section_header.text_2" data-edit-label="Alles, was deine Website braucht. – Absatz">Jede Funktion schaltest du nur ein, wenn du sie brauchst. Gepflegt wird alles gleich: draufklicken, ändern, speichern.</p>
        </header>

        <div class="targets targets--3" data-plugin="content-types" data-view="list" data-type="karten" data-filter="kategorie=Funktionen – Übersicht" data-limit="50"></div>
    </div>
</section>

<section class="section">
    <div class="container">
        <header class="section__header">
            <h2 data-edit-id="section_header.title_2" data-edit-label="Eine Bedienung für alles. – Überschrift">Eine Bedienung für alles.</h2>
            <p class="section__lead" data-edit-id="section_header.text_3" data-edit-label="Eine Bedienung für alles. – Absatz">Egal welche Funktion: Du lernst nichts Neues dazu.</p>
        </header>

        <div class="card-grid card-grid--3" data-plugin="content-types" data-view="list" data-type="karten" data-filter="kategorie=Funktionen – Bedienung" data-limit="50"></div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
