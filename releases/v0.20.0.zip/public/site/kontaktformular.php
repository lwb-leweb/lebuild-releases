<?php
$page = [
    'title'       => 'Kontaktformular',
    'description' => 'Anfragen von deiner Website landen direkt in deinem Postfach, mit Spamschutz ohne Rätsel und ohne fremde Dienste.',
    'slug'        => 'kontaktformular',
];
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/funktionen-nav.php';
?>

<section class="section section--soft">
    <div class="container">
        <header class="section__header">
            <span class="section__eyebrow" data-edit-id="section_header.text">Kontaktformular</span>
            <h1 data-edit-id="section_header.title" data-edit-label="Anfragen direkt ins Postfach. – Überschrift">Anfragen direkt ins Postfach.</h1>
            <p class="section__lead" data-edit-id="section_header.text_2" data-edit-label="Anfragen direkt ins Postfach. – Absatz">Besucher schreiben dir, ohne ihr Mailprogramm zu öffnen. Du antwortest einfach auf die Mail.</p>
        </header>

        <div class="card-grid card-grid--3" data-plugin="content-types" data-view="list" data-type="karten" data-filter="kategorie=Kontaktformular" data-limit="50"></div>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
