import { api, postJson } from '../core.js';

// Verwaltung → Mediathek (nur Admins): alle Bilder der Website aus api/media.php mit Vorschau und Status, filterbar;
// unbenutzte lassen sich auswählen und löschen (api/deleteMedia.php). Gebaut per DOM (textContent), Dateinamen können
// kein Markup einschleusen.
const MEDIA_TEXT = {
  title: 'Mediathek',
  loading: 'Lade…',
  empty: 'Keine Bilder für diesen Filter.',
  kind: 'Herkunft',
  status: 'Status',
  all: 'Alle',
  kinds: { upload: 'Hochgeladen', site: 'Website' },
  statuses: { used: 'Verwendet', history: 'Nur im Verlauf', unused: 'Unbenutzt' },
  selectUnused: 'Alle unbenutzten auswählen',
  delete: 'Ausgewählte löschen',
  deleting: 'Wird gelöscht…',
  confirm: '{n} Bild(er) endgültig löschen?',
  deleted: '{n} Bild(er) gelöscht.',
  kept: '{n} Bild(er) blieben: ',
  count: '{shown} von {total} Bildern',
  hint: 'Unbenutzte hochgeladene Bilder löscht LeBuild nach {days} Tagen von selbst. „Nur im Verlauf“ heißt: Das Bild steht nur noch in älteren Fassungen einer Seite (die letzten {backups} je Seite bleiben zum Wiederherstellen); danach wird es unbenutzt. Bilder, die zur Website gehören, bleiben, bis du sie hier löschst. Ob sie in CSS oder JavaScript stecken, erkennt die Suche nicht immer, darum vor dem Löschen kurz prüfen.'
};
const DATE_FORMAT = { day: '2-digit', month: '2-digit', year: 'numeric' };

const TEMPLATE = `
  <section class="view-area">
    <div class="card-grid">
      <div class="view-card span-12">
        <div class="topbar">
          <strong>${MEDIA_TEXT.title}</strong>
          <div class="media-filters">
            <label class="activity-filter">${MEDIA_TEXT.kind}
              <select id="mediaKind">
                <option value="">${MEDIA_TEXT.all}</option>
                <option value="upload">${MEDIA_TEXT.kinds.upload}</option>
                <option value="site">${MEDIA_TEXT.kinds.site}</option>
              </select>
            </label>
            <label class="activity-filter">${MEDIA_TEXT.status}
              <select id="mediaStatus">
                <option value="">${MEDIA_TEXT.all}</option>
                <option value="used">${MEDIA_TEXT.statuses.used}</option>
                <option value="history">${MEDIA_TEXT.statuses.history}</option>
                <option value="unused">${MEDIA_TEXT.statuses.unused}</option>
              </select>
            </label>
          </div>
        </div>
        <div class="media-actions">
          <span id="mediaCount" class="media-count"></span>
          <button id="mediaSelectUnused" type="button" class="secondary">${MEDIA_TEXT.selectUnused}</button>
          <button id="mediaDelete" type="button" class="danger" disabled>${MEDIA_TEXT.delete}</button>
        </div>
        <p id="mediaMessage" class="message"></p>
        <div id="mediaGrid" class="media-grid"><p class="message">${MEDIA_TEXT.loading}</p></div>
        <p id="mediaHint" class="activity-hint"></p>
      </div>
    </div>
  </section>
`;

let outletRef = null;
let items = [];
const selected = new Set();
let requestToken = 0;

export function mount(outlet) {
  outletRef = outlet;
  selected.clear();
  outlet.innerHTML = TEMPLATE;
  outlet.querySelector('#mediaKind').addEventListener('change', render);
  outlet.querySelector('#mediaStatus').addEventListener('change', render);
  outlet.querySelector('#mediaSelectUnused').addEventListener('click', selectUnused);
  outlet.querySelector('#mediaDelete').addEventListener('click', removeSelected);
  load();
}

export function unmount() {
  requestToken++;
  outletRef = null;
}

function load() {
  const token = ++requestToken;
  api('/api/media.php')
    .then(function (data) {
      if (token !== requestToken || !outletRef) return;
      items = data.items || [];
      outletRef.querySelector('#mediaHint').textContent = MEDIA_TEXT.hint
        .replace('{days}', String(data.unusedDays))
        .replace('{backups}', String(data.backupRetention));
      render();
    })
    .catch(function (error) {
      if (token !== requestToken || !outletRef) return;
      outletRef.querySelector('#mediaGrid').textContent = '';
      outletRef.querySelector('#mediaMessage').textContent = error.message;
    });
}

function visibleItems() {
  const kind = outletRef.querySelector('#mediaKind').value;
  const status = outletRef.querySelector('#mediaStatus').value;
  return items.filter(function (item) {
    return (!kind || item.kind === kind) && (!status || item.status === status);
  });
}

function render() {
  if (!outletRef) return;
  const grid = outletRef.querySelector('#mediaGrid');
  const shown = visibleItems();
  grid.textContent = '';
  if (!shown.length) {
    const empty = document.createElement('p');
    empty.className = 'message';
    empty.textContent = MEDIA_TEXT.empty;
    grid.appendChild(empty);
  }
  shown.forEach(function (item) { grid.appendChild(tile(item)); });
  outletRef.querySelector('#mediaCount').textContent = MEDIA_TEXT.count
    .replace('{shown}', String(shown.length))
    .replace('{total}', String(items.length));
  updateDeleteButton();
}

// Kachel: Vorschau, Name, Herkunft, Größe und Datum, Status; nur unbenutzte sind auswählbar.
function tile(item) {
  const card = document.createElement('label');
  card.className = 'media-tile media-tile--' + item.status;
  const preview = document.createElement('span');
  preview.className = 'media-tile__preview';
  const img = document.createElement('img');
  img.src = item.url;
  img.alt = '';
  img.loading = 'lazy';
  preview.appendChild(img);
  const name = document.createElement('span');
  name.className = 'media-tile__name';
  name.textContent = item.name;
  name.title = item.url;
  const meta = document.createElement('span');
  meta.className = 'media-tile__meta';
  meta.textContent = [MEDIA_TEXT.kinds[item.kind], formatSize(item.size), formatDay(item.time)].join(' · ');
  const badge = document.createElement('span');
  badge.className = 'media-tile__status';
  badge.textContent = MEDIA_TEXT.statuses[item.status] || item.status;
  card.append(preview, name, meta, badge);
  if (item.status === 'unused') {
    const box = document.createElement('input');
    box.type = 'checkbox';
    box.className = 'media-tile__check';
    box.checked = selected.has(item.url);
    box.setAttribute('aria-label', item.name);
    box.addEventListener('change', function () {
      if (box.checked) selected.add(item.url);
      else selected.delete(item.url);
      card.classList.toggle('is-selected', box.checked);
      updateDeleteButton();
    });
    card.classList.toggle('is-selected', box.checked);
    card.prepend(box);
  }
  return card;
}

function selectUnused() {
  visibleItems().forEach(function (item) {
    if (item.status === 'unused') selected.add(item.url);
  });
  render();
}

function updateDeleteButton() {
  if (!outletRef) return;
  // Auswahl gilt nur für Bilder, die es noch gibt und die noch unbenutzt sind.
  const unused = new Set(items.filter(function (item) { return item.status === 'unused'; }).map(function (item) { return item.url; }));
  Array.from(selected).forEach(function (url) { if (!unused.has(url)) selected.delete(url); });
  const button = outletRef.querySelector('#mediaDelete');
  button.disabled = selected.size === 0;
  button.textContent = selected.size ? MEDIA_TEXT.delete + ' (' + selected.size + ')' : MEDIA_TEXT.delete;
}

function removeSelected() {
  const urls = Array.from(selected);
  if (!urls.length || !window.confirm(MEDIA_TEXT.confirm.replace('{n}', String(urls.length)))) return;
  const button = outletRef.querySelector('#mediaDelete');
  const message = outletRef.querySelector('#mediaMessage');
  button.disabled = true;
  button.textContent = MEDIA_TEXT.deleting;
  postJson('/api/deleteMedia.php', { urls: urls })
    .then(function (data) {
      if (!outletRef) return;
      selected.clear();
      items = data.items || [];
      const kept = Object.keys(data.kept || {});
      message.textContent = MEDIA_TEXT.deleted.replace('{n}', String((data.deleted || []).length))
        + (kept.length ? ' ' + MEDIA_TEXT.kept.replace('{n}', String(kept.length)) + kept.map(function (url) { return data.kept[url]; }).filter(function (v, i, a) { return a.indexOf(v) === i; }).join(' ') : '');
      render();
    })
    .catch(function (error) {
      if (!outletRef) return;
      message.textContent = error.message;
      updateDeleteButton();
    });
}

function formatSize(bytes) {
  if (bytes >= 1024 * 1024) return (bytes / 1024 / 1024).toFixed(1).replace('.', ',') + ' MB';
  return Math.max(1, Math.round(bytes / 1024)) + ' KB';
}

function formatDay(seconds) {
  return new Date(seconds * 1000).toLocaleDateString('de-DE', DATE_FORMAT);
}
