import { editorRoot, iconButton } from './bar.js';
import { askConfirm } from './confirm.js';

// Seitenpanel: schwebende Karte rechts über die ganze Höhe, über der Leiste (am Handy über die
// ganze Ansicht), im Shadow-DOM: Verlauf, „Alle Texte dieser Seite“ und das Formular für
// Plugin-Einträge. Kopf mit Überzeile und Titel, Inhalt scrollt, Fuß (panelFooter) bleibt stehen.
// Es ist immer höchstens eins offen.

const PANEL_TEXT = {
  close: 'Schließen',
  discardTitle: 'Eingaben verwerfen?',
  discardText: 'Was du hier eingegeben hast, ist noch nicht gespeichert.',
  discard: 'Verwerfen'
};

let current = null;

// Schließt das offene Panel; onClose des Panels läuft dabei.
export function closePanel() {
  if (!current) return;
  const panel = current;
  current = null;
  panel.element.remove();
  if (panel.scrim) panel.scrim.remove();
  if (panel.onClose) panel.onClose();
}

// Darf panel zugehen? Mit ungespeicherten Eingaben (isDirty) erst nachfragen; Promise mit true, wenn ja.
function confirmDiscard(panel) {
  if (!panel || !panel.isDirty || !panel.isDirty()) return Promise.resolve(true);
  return askConfirm({ title: PANEL_TEXT.discardTitle, text: PANEL_TEXT.discardText, confirm: PANEL_TEXT.discard, danger: true });
}

// Schließen über ×, Esc oder Klick daneben: mit ungespeicherten Eingaben erst nachfragen.
function requestClose() {
  if (!current) return;
  const panel = current;
  confirmDiscard(panel).then(function (yes) {
    if (yes && current === panel) closePanel();
  });
}

// Hat das offene Panel ungespeicherte Eingaben (Eintragsformular)? Zählt beim Verlassen der Seite mit
// (hasUnsavedChanges in session.js).
export function isPanelDirty() {
  return current !== null && Boolean(current.isDirty) && current.isDirty();
}

// Strg+S (save-key.js) bei offenem Panel: dessen Speichern (options.onSave), z. B. das Eintragsformular.
// false, wenn das offene Panel nichts zu speichern hat (dann gilt Speichern der Seite).
export function savePanel() {
  if (!current || !current.onSave) return false;
  current.onSave();
  return true;
}

// Ist das Panel mit diesem Schlüssel offen?
export function isPanelOpen(key) {
  return current !== null && current.key === key;
}

// Fuß des offenen Panels (Knöpfe wie Speichern/Abbrechen); leer bleibt er unsichtbar.
export function panelFooter() {
  return current ? current.foot : null;
}

// Öffnet ein Panel und liefert ein Promise mit seinem Inhaltsbereich. Ein offenes anderes schließt
// vorher; hat es ungespeicherte Eingaben, fragt es wie × nach, lehnt man ab, bleibt es offen und das
// Promise liefert null.
// options: { key, title, eyebrow (Überzeile, z. B. „Mitarbeiter“), dim (Seite abdunkeln, für
// Formulare), wide (breit und mittig, für große Formulare; am Handy wie jedes Panel), isDirty() (ungespeicherte Eingaben: vor dem Schließen nachfragen), onSave (Strg+S),
// onClose }. Esc schließt, wenn gerade nichts bearbeitet wird (interact.js fängt Esc während einer
// Bearbeitung vorher ab).
export function openPanel(options) {
  return confirmDiscard(current).then(function (yes) {
    if (!yes) return null;
    closePanel();
    return buildPanel(options);
  });
}

function buildPanel(options) {
  const element = document.createElement('section');
  element.className = options.wide ? 'le-panel le-panel--wide' : 'le-panel';
  element.setAttribute('role', 'dialog');
  element.setAttribute('aria-label', options.title);

  const head = document.createElement('div');
  head.className = 'le-panel__head';
  const titles = document.createElement('div');
  titles.className = 'le-panel__titles';
  if (options.eyebrow) {
    const eyebrow = document.createElement('span');
    eyebrow.className = 'le-panel__eyebrow';
    eyebrow.textContent = options.eyebrow;
    titles.appendChild(eyebrow);
  }
  const title = document.createElement('strong');
  title.className = 'le-panel__title';
  title.textContent = options.title;
  titles.appendChild(title);
  head.append(titles, iconButton('close', PANEL_TEXT.close, 'le-icon-btn', requestClose));

  const body = document.createElement('div');
  body.className = 'le-panel__body';
  const foot = document.createElement('div');
  foot.className = 'le-panel__foot';
  element.append(head, body, foot);
  element.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') requestClose();
  });

  let scrim = null;
  if (options.dim) {
    scrim = document.createElement('div');
    scrim.className = 'le-scrim';
    scrim.addEventListener('click', requestClose);
    editorRoot().appendChild(scrim);
  }
  // Nach der Leiste einhängen: das Panel liegt über ihr.
  editorRoot().appendChild(element);
  current = { key: options.key, element: element, scrim: scrim, foot: foot, isDirty: options.isDirty, onSave: options.onSave, onClose: options.onClose };
  return body;
}
