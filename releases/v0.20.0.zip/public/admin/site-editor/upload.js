import { state } from '../modules/core.js';
import { editorApi, editorPost, errorNotice } from './request.js';

const UPLOAD_TEXT = {
  done: 'Bild hochgeladen.',
  choose: 'Bild auswählen',
  drop: 'Bild hierher ziehen oder klicken',
  running: 'Das Bild wird noch hochgeladen.'
};

// Laufende Uploads dieser Oberfläche (Dialog am Bild, „Alle Texte“, Formular für Plugin-Einträge).
let running = 0;
// Erledigt offene Uploads eines Formulars (uploadForm).
const DISCARD_URL = '/api/discardUploads.php';
// Zufallsbytes der Formular-Kennung (LE_UPLOAD_FORM_PATTERN in core/uploads.php: 16–64 Zeichen, hier 32 hex).
const FORM_ID_BYTES = 16;
// Formulare, über die schon hochgeladen und die noch nicht geschlossen wurden.
const openForms = new Set();

// Erledigt die offenen Uploads des Formulars id (mit urls nur diese), auch beim Verlassen der Seite
// (keepalive); scheitert es, räumt der Server sie nach seiner Frist weg.
function discard(id, urls) {
  editorPost(DISCARD_URL, { form: id, urls: urls }, { keepalive: true }).catch(function () { /* Frist auf dem Server */ });
}

// Formular, das Bilder hochlädt (Eintragsformular, Seiten-Editor): Seine Uploads führt der Server als
// offen, bis close() sie erledigt: Was nicht gespeichert ist, löscht er, Gespeichertes bleibt. close()
// nach Speichern und nach Verwerfen aufrufen, close(urls) erledigt nur diese (Dialog am Bild). Beim
// Verlassen der Seite schließen sich alle noch offenen Formulare.
export function uploadForm() {
  const bytes = window.crypto.getRandomValues(new Uint8Array(FORM_ID_BYTES));
  const form = {
    id: Array.from(bytes, function (byte) { return byte.toString(16).padStart(2, '0'); }).join(''),
    closed: false,
    close: function (urls) {
      if (!urls) form.closed = true;
      if (!openForms.has(form) || (urls && !urls.length)) return;
      if (!urls) openForms.delete(form);
      discard(form.id, urls);
    }
  };
  return form;
}

// Zurück aus dem Cache des Browsers (persisted) geht es mit denselben Formularen weiter.
window.addEventListener('pagehide', function (event) {
  if (event.persisted) return;
  Array.from(openForms).forEach(function (form) { form.close(); });
});

// Läuft noch ein Upload, wird nicht übernommen oder gespeichert (das Bild käme sonst nicht mit):
// dann Hinweis über notify und true. Die eine Regel für Übernehmen, Speichern und Verlassen.
export function uploadPending(notify) {
  if (running && notify) notify(UPLOAD_TEXT.running);
  return running > 0;
}

// accept der Dateiauswahl: erlaubte Endungen (upload_config) plus image/*, damit das Handy auch
// die Kamera anbietet (kein capture, sonst gäbe es nur die Kamera).
export function imageAccept() {
  return state.upload.extensions.map(function (ext) { return '.' + ext; }).concat('image/*').join(',');
}

// Lädt ein Bild über api/upload.php für das Formular form (uploadForm) hoch und liefert seine URL.
// notify ist die Hinweis-Funktion der jeweiligen Oberfläche (Erfolg und Fehler). Zu große Dateien lehnt
// schon der Browser ab, mit der Grenze und Meldung des Servers (upload_config: kleinste aus eigener
// Grenze und PHP-Konfiguration). Ist das Formular inzwischen geschlossen, wird das Bild gleich erledigt.
// quiet: ohne Erfolgsmeldung (mehrere Bilder auf einmal melden sich gesammelt).
export function uploadImage(file, notify, form, quiet) {
  if (file.size > state.upload.maxBytes) {
    notify(state.upload.tooLarge);
    return Promise.reject(new Error(state.upload.tooLarge));
  }
  const formData = new FormData();
  formData.append('file', file);
  formData.append('form', form.id);
  openForms.add(form);
  running++;
  return editorApi('/api/upload.php', { method: 'POST', body: formData }).then(function (data) {
    if (form.closed) discard(form.id, [data.url]);
    if (!quiet) notify(UPLOAD_TEXT.done);
    return data.url;
  }, function (error) {
    const notice = errorNotice(error);
    notify(notice.message, notice.action);
    throw error;
  }).finally(function () { running--; });
}

// Lädt eine Datei hoch und gibt die URL an onUrl; bei zwei Dateien kurz nacheinander gilt die
// letzte, auch wenn die erste später fertig wird.
function latestUpload(onUrl, notify, form) {
  let latest = 0;
  return function (file) {
    const choice = ++latest;
    uploadImage(file, notify, form)
      .then(function (url) {
        if (choice === latest) onUrl(url);
      })
      .catch(function () { /* Meldung kam über notify */ });
  };
}

// Knopf mit verstecktem Datei-Feld (Bild am Element, „Alle Texte“, Formular für Plugin-Einträge im
// Seiten-Editor und im Backend): Upload gleich bei Auswahl, onUrl(url) bekommt das hochgeladene
// Bild; solange er läuft, sperrt uploadPending Übernehmen und Speichern. notify, className und das
// Formular form (uploadForm) kommen von der jeweiligen Oberfläche. upload(file) lädt eine abgelegte
// Datei auf demselben Weg hoch.
export function imagePicker(onUrl, notify, className, form) {
  const upload = latestUpload(onUrl, notify, form);
  const label = document.createElement('label');
  label.className = className;
  label.textContent = UPLOAD_TEXT.choose;
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = imageAccept();
  input.hidden = true;
  input.addEventListener('change', function () {
    const file = input.files && input.files[0];
    input.value = '';
    if (file) upload(file);
  });
  label.appendChild(input);
  return { element: label, input: input, upload: upload };
}

// Zieht jemand Dateien (nicht Text oder einen Link der Seite)?
export function draggingFiles(event) {
  return Boolean(event.dataTransfer) && Array.prototype.indexOf.call(event.dataTransfer.types, 'Files') !== -1;
}

// Ablagefläche eines Bildfeldes (Formular, „Alle Texte“, Dialog am Bild): Vorschau bzw. Hinweis
// „Bild hierher ziehen oder klicken“. Klick öffnet die Dateiauswahl von picker, eine abgelegte Datei
// lädt picker.upload hoch; solange eine Datei darüber ist, trägt die Fläche classes.active.
// classes: { drop, active, image, empty }. Liefert { element, show(url) } (leere URL = Hinweis).
export function imageDropArea(picker, classes) {
  const area = document.createElement('div');
  area.className = classes.drop;
  const preview = document.createElement('img');
  preview.className = classes.image;
  preview.alt = '';
  const empty = document.createElement('div');
  empty.className = classes.empty;
  empty.textContent = UPLOAD_TEXT.drop;
  area.append(preview, empty);
  area.addEventListener('click', function () { picker.input.click(); });
  // Zähler statt dragleave allein: Betreten eines Kindes (Vorschau) meldet dragleave am Rahmen.
  let depth = 0;
  const highlight = function (on) { area.classList.toggle(classes.active, on); };
  area.addEventListener('dragenter', function (event) {
    if (!draggingFiles(event)) return;
    event.preventDefault();
    depth++;
    highlight(true);
  });
  area.addEventListener('dragover', function (event) {
    if (!draggingFiles(event)) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = 'copy';
  });
  area.addEventListener('dragleave', function () {
    if (depth > 0 && --depth === 0) highlight(false);
  });
  area.addEventListener('drop', function (event) {
    if (!draggingFiles(event)) return;
    event.preventDefault();
    depth = 0;
    highlight(false);
    const file = event.dataTransfer.files[0];
    if (file) picker.upload(file);
  });
  return {
    element: area,
    show: function (url) {
      preview.hidden = !url;
      empty.hidden = Boolean(url);
      if (url) preview.src = url;
    }
  };
}
