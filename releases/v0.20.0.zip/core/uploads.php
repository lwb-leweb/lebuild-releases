<?php
declare(strict_types=1);

// Hochgeladene Dateien wieder entfernen, sobald nichts mehr auf sie verweist
// (z. B. beim Löschen eines Plugin-Eintrags). Verweise zählen als Treffer des
// Dateinamens (zufälliger Suffix aus api/upload.php). Im Zweifel bleibt die
// Datei liegen: ein falscher Treffer, eine unlesbare Datei oder ein Fehler bei
// der Suche zählen als „verwendet“. Uploads aus Formularen, die noch nicht
// gespeichert oder verworfen sind, führt die Liste offener Uploads (le_open_*).

require_once __DIR__ . '/utils.php';
require_once __DIR__ . '/plugins.php';
require_once __DIR__ . '/pluginSchema.php';
require_once __DIR__ . '/siteRoutes.php';
require_once __DIR__ . '/fileStore.php';

// Hier können Seiten auf Uploads verweisen: Seiten-JSON, Seiten-Backups, Snapshots der Quelldateien, Site-Dateien.
const UPLOAD_REFERENCE_ROOTS = [PAGES_ROOT, BACKUPS_ROOT, ORIGINALS_ROOT, LE_SITE_ROOT];
// Binärdateien mit diesen Endungen werden nicht durchsucht; alle anderen Dateien gelten als Text.
const UPLOAD_REFERENCE_SKIP_EXTENSIONS = [
    'jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'ico', 'bmp', 'tif', 'tiff',
    'mp4', 'mov', 'webm', 'm4v', 'avi', 'mkv', 'mp3', 'wav', 'ogg', 'm4a',
    'woff', 'woff2', 'ttf', 'otf', 'eot', 'pdf', 'zip', 'gz', 'tar', '7z', 'rar',
];
// Größere Dateien werden nicht eingelesen, sondern zählen als Verwendung (im Zweifel behalten).
const UPLOAD_REFERENCE_MAX_BYTES = 5 * 1024 * 1024;
// Offene Uploads: hochgeladen (api/upload.php), aber noch nicht durch Speichern oder Verwerfen erledigt; je Dateiname
// Formular, Benutzer und Zeit. Liegt außerhalb von UPLOAD_REFERENCE_ROOTS, sonst zählte jede offene Datei als verwendet.
const LE_OPEN_UPLOADS_FILE = CACHE_ROOT . '/open-uploads.json';
// Sperre der Liste (atomic_write ersetzt die Datei selbst, an ihr ließe sich nicht warten), le_open_uploads_hold.
const LE_OPEN_UPLOADS_LOCK = CACHE_ROOT . '/open-uploads.lock';
// Kopie einer kaputten Liste, bevor die aus den Dateien rekonstruierte sie ersetzt (le_open_uploads_recover).
const LE_OPEN_UPLOADS_BROKEN_FILE = CACHE_ROOT . '/open-uploads.broken.json';
// Belegte Sperre der Liste: so viele Sekunden höchstens warten (le_open_uploads_hold), dabei alle so viele Millisekunden nachsehen.
const LE_OPEN_UPLOADS_LOCK_TIMEOUT = 10;
const LE_OPEN_UPLOADS_LOCK_POLL_MS = 50;
// Formulare, die nie geschlossen wurden (Tab zu, Absturz, abgelaufene Anmeldung): Ihre offenen Uploads räumt nach
// so vielen Sekunden der nächste Upload bzw. das nächste Schließen eines Formulars weg.
const LE_OPEN_UPLOAD_MAX_AGE = 86400;
// Kennung eines Formulars, vom Browser zufällig gewählt (site-editor/upload.js).
const LE_UPLOAD_FORM_PATTERN = '/^[A-Za-z0-9]{16,64}$/';

/**
 * Dateiname in UPLOADS_ROOT zu einem Bildwert wie „/public/site/uploads/x.png“ (auch unter der alten Adresse
 * LE_LEGACY_UPLOADS_URL); null für alles andere (fremde Pfade, Unterordner, Traversal, versteckte Dateien, Endungen
 * außerhalb der Upload-Whitelist).
 */
function upload_file_name(string $url): ?string
{
    $prefix = str_starts_with($url, UPLOADS_URL) ? UPLOADS_URL : (str_starts_with($url, LE_LEGACY_UPLOADS_URL) ? LE_LEGACY_UPLOADS_URL : null);
    if ($prefix === null) {
        return null;
    }
    $file = substr($url, strlen($prefix));
    if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]*$/', $file)
        || !isset(UPLOAD_MIME_TYPES[strtolower(pathinfo($file, PATHINFO_EXTENSION))])) {
        return null;
    }

    return $file;
}

/**
 * Ob $url ein vorhandenes Bild dieses Projekts ist: eine Upload-Datei (upload_file_name) oder eine Datei der
 * Website unter LE_SITE_FILES_URL, die index.php ausliefert (le_site_request_file: Zeichen-Whitelist, kein „..“, nicht
 * unter includes), jeweils mit Endung aus der Upload-Whitelist. Pfade nur in kanonischer Schreibweise
 * (kein „//“ oder „/./“), Links nur, wenn ihr Ziel im selben Ordner bleibt; fremde URLs, relative Pfade
 * und alles andere: false.
 */
function upload_image_exists(string $url): bool
{
    $file = upload_file_name($url);
    if ($file !== null) {
        return upload_path_inside(UPLOADS_ROOT . '/' . $file, UPLOADS_ROOT);
    }
    if (!str_starts_with($url, LE_SITE_FILES_URL) || le_site_canonical_path($url) !== $url
        || !isset(UPLOAD_MIME_TYPES[strtolower(pathinfo($url, PATHINFO_EXTENSION))])) {
        return false;
    }
    $path = LE_SITE_ROOT . '/' . substr($url, strlen(LE_SITE_FILES_URL));

    return le_site_request_file($url) === $path && upload_path_inside($path, LE_SITE_ROOT);
}

/** Ob $path eine Datei ist, die (auch über Links aufgelöst) unter dem Ordner $root liegt. */
function upload_path_inside(string $path, string $root): bool
{
    $real = realpath($path);
    $rootReal = realpath($root);

    return $real !== false && $rootReal !== false && str_starts_with($real, $rootReal . '/') && is_file($real);
}

/**
 * Ob eine Seite, ein Backup, eine Site-Datei oder ein Plugin die Upload-Datei $file noch verwendet.
 * Im Zweifel ja: bei Fehlern, unlesbaren oder zu großen Textdateien und Ordner-Links (werden nicht verfolgt).
 */
function upload_in_use(string $file): bool
{
    try {
        foreach (UPLOAD_REFERENCE_ROOTS as $root) {
            if (!is_dir($root)) {
                continue;
            }
            $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
            foreach ($files as $entry) {
                if ($entry->isLink() && $entry->isDir()) {
                    return true;
                }
                // Die Uploads selbst (unter LE_SITE_ROOT) verweisen auf nichts, auch ein SVG nicht.
                if (str_starts_with($entry->getPathname(), UPLOADS_ROOT . '/')) {
                    continue;
                }
                if (!$entry->isFile() || in_array(strtolower($entry->getExtension()), UPLOAD_REFERENCE_SKIP_EXTENSIONS, true)) {
                    continue;
                }
                if ($entry->getSize() > UPLOAD_REFERENCE_MAX_BYTES) {
                    return true;
                }
                $content = @file_get_contents($entry->getPathname());
                if ($content === false || str_contains($content, $file)) {
                    return true;
                }
            }
        }

        return plugins_upload_in_use($file);
    } catch (Throwable $e) {
        error_log('upload_in_use failed: ' . $e->getMessage());
        return true;
    }
}

/**
 * Plugin-Daten: Spalten aus schema.fields der Haupttabelle (jedes Plugin mit Schema) und der Hook
 * „<plugin>_upload_in_use(string $file): bool“ für alles andere (z. B. JSON-Spalten der Content-Typen).
 * Gilt für installierte Plugins, aktiv oder nicht (die Daten bleiben). Wirft bei Fehlern.
 */
function plugins_upload_in_use(string $file): bool
{
    $state = load_plugins_state();
    foreach (array_unique(array_merge($state['active'], array_keys($state['installed']))) as $name) {
        if (plugin_schema_upload_in_use(plugin_manifest($name), $file)) {
            return true;
        }
        $fn = plugin_hook_function($name, 'upload_in_use');
        if ($fn !== null && $fn($file) !== false) {
            return true;
        }
    }

    return false;
}

/**
 * Löscht die Upload-Dateien zu den Bildwerten $urls, die nirgends mehr verwendet werden. Aufruf erst,
 * nachdem der Eintrag selbst gelöscht ist; wirft nie (der Eintrag ist dann schon weg), Fehler lassen
 * die Datei liegen. Liefert die gelöschten Dateinamen.
 */
function delete_unused_uploads(array $urls): array
{
    $deleted = [];
    foreach (array_unique(array_filter($urls, 'is_string')) as $url) {
        try {
            $file = upload_file_name($url);
            $uploadsDir = realpath(UPLOADS_ROOT);
            if ($file === null || $uploadsDir === false) {
                continue;
            }
            $path = UPLOADS_ROOT . '/' . $file;
            $real = realpath($path);
            // Nur echte Dateien direkt in UPLOADS_ROOT, keine Links nach draußen.
            if ($real === false || is_link($path) || !is_file($real) || dirname($real) !== $uploadsDir || upload_in_use($file)) {
                continue;
            }
            if (@unlink($real)) {
                $deleted[] = $file;
            }
        } catch (Throwable $e) {
            error_log('delete_unused_uploads failed: ' . $e->getMessage());
        }
    }

    return $deleted;
}

/**
 * Löscht den Eintrag $id aus der Haupttabelle des Plugins samt Bildern, die sonst nirgends verwendet werden:
 * lesen, Bildwerte bestimmen, löschen, aufräumen. $where schränkt zusätzlich ein (Spalte => Wert).
 * Bildwerte liefert der Hook „<plugin>_image_values(array $row): array“, sonst die image-Felder aus
 * schema.fields. Kann er sie nicht bestimmen, bleiben die Dateien liegen. Liefert, ob es den Eintrag gab.
 */
function plugin_delete_entry(string $plugin, int $id, array $where = []): bool
{
    $manifest = plugin_manifest($plugin);
    $table = plugin_main_table($manifest);
    if ($table === null) {
        throw new RuntimeException('Plugin has no main table');
    }
    $conditions = ['`id` = ?'];
    $params = [$id];
    foreach ($where as $column => $value) {
        if (!is_string($column) || !plugin_table_name_valid($column)) {
            throw new InvalidArgumentException('Invalid column: ' . $column);
        }
        $conditions[] = "`{$column}` = ?";
        $params[] = $value;
    }
    $condition = implode(' AND ', $conditions);

    $stmt = db()->prepare("SELECT * FROM `{$table}` WHERE {$condition} LIMIT 1");
    $stmt->execute($params);
    $row = $stmt->fetch();
    if (!$row) {
        return false;
    }
    try {
        $fn = plugin_hook_function($plugin, 'image_values');
        $images = $fn !== null ? $fn($row) : plugin_schema_image_values(plugin_schema_columns($manifest), $row);
    } catch (Throwable $e) {
        $images = [];
    }
    db()->prepare("DELETE FROM `{$table}` WHERE {$condition}")->execute($params);
    delete_unused_uploads(is_array($images) ? $images : []);

    return true;
}

/** Offene Uploads: Dateiname => ['form' => …, 'user' => Benutzer-ID, 'time' => …]; ohne Liste leer, kaputt rekonstruiert. */
function le_open_uploads(): array
{
    return le_open_uploads_stored() ?? le_open_uploads_recover();
}

/** Gespeicherte Liste; [] ohne Datei, null wenn sie kaputt oder unlesbar ist. */
function le_open_uploads_stored(): ?array
{
    if (!is_file(LE_OPEN_UPLOADS_FILE)) {
        return [];
    }
    $list = json_decode((string) @file_get_contents(LE_OPEN_UPLOADS_FILE), true);

    return is_array($list) ? $list : null;
}

/**
 * Ersatz für eine kaputte Liste: Jede Upload-Datei, die seit dem letzten Schreiben der Liste abzüglich der Frist
 * entstanden ist, kann darin gestanden haben (ältere nicht, jedes Schreiben räumt danach Abgelaufenes weg). Sie gilt als
 * offen ohne Formular, so erledigt sie nur die Frist ab ihrer Entstehung und löscht sie nur, wenn sie unbenutzt ist.
 */
function le_open_uploads_recover(): array
{
    $since = (int) @filemtime(LE_OPEN_UPLOADS_FILE) - LE_OPEN_UPLOAD_MAX_AGE;
    $list = [];
    foreach (dir_entries(UPLOADS_ROOT) as $file) {
        $time = upload_file_name(UPLOADS_URL . $file) !== null ? @filemtime(UPLOADS_ROOT . '/' . $file) : false;
        if ($time !== false && $time >= $since) {
            $list[$file] = ['form' => '', 'user' => '', 'time' => $time];
        }
    }

    return $list;
}

/**
 * Führt $work unter der Sperre der Liste aus und liefert sein Ergebnis; die Sperre gilt nur so lange (verschachtelt: schon
 * gehalten). Erledigen offener Uploads und Speichern (Seite, Plugin-Einträge, Import) halten sie vom Prüfen der Bilder bis
 * zum Schreiben, so laufen sie nacheinander, unabhängig von der Sperre der PHP-Session: Verwerfen löscht nie ein Bild, das
 * ein Speichern gerade festschreibt, und ein Speichern danach merkt, dass die Datei fehlt (le_upload_missing).
 * Ist sie belegt, wartet es höchstens LE_OPEN_UPLOADS_LOCK_TIMEOUT Sekunden, dann 503 (API_TEXT['uploadsBusy']); geht sie
 * gar nicht (Cache nicht beschreibbar), 500 wie beim Schreiben. Mit $wait = false (Aufräumen nebenher) weder Warten
 * noch Antwort: Ohne Sperre entfällt $work, null.
 */
function le_open_uploads_hold(callable $work, bool $wait = true): mixed
{
    static $held = false;
    if ($held) {
        return $work();
    }
    $lock = le_open_uploads_lock($wait);
    if ($lock === null) {
        return null;
    }
    $held = true;
    try {
        return $work();
    } finally {
        $held = false;
        updater_release_lock($lock);
    }
}

/** Sperre für le_open_uploads_hold: Handle, sonst (nur ohne $wait) null; mit $wait antwortet es selbst. */
function le_open_uploads_lock(bool $wait)
{
    try {
        ensure_dir(CACHE_ROOT);
        $lock = @fopen(LE_OPEN_UPLOADS_LOCK, 'c');
    } catch (RuntimeException $e) {
        $lock = false;
    }
    $deadline = microtime(true) + LE_OPEN_UPLOADS_LOCK_TIMEOUT;
    $busy = 0;
    while ($lock !== false) {
        if (flock($lock, LOCK_EX | LOCK_NB, $busy)) {
            return $lock;
        }
        if (!$busy || !$wait || microtime(true) >= $deadline) {
            fclose($lock);
            break;
        }
        usleep(LE_OPEN_UPLOADS_LOCK_POLL_MS * 1000);
    }
    if ($wait || !$busy) {
        error_log($busy ? 'open uploads: lock busy, gave up' : 'open uploads: lock failed');
    }
    if (!$wait) {
        return null;
    }
    json_response(['ok' => false, 'error' => $busy ? API_TEXT['uploadsBusy'] : write_failed_message()], $busy ? 503 : 500);
}

/**
 * Ändert die Liste unter Sperre (le_open_uploads_hold): $change(array $list): array liefert die neue (unverändert: kein
 * Schreiben). Eine kaputte Liste wird vorher nach LE_OPEN_UPLOADS_BROKEN_FILE kopiert und rekonstruiert. Wirft, wenn sich
 * die Liste nicht schreiben lässt (keine Antwort an den Browser: Aufrufer wie das Aufräumen nach einem Upload loggen nur).
 */
function le_open_uploads_change(callable $change): void
{
    le_open_uploads_hold(static function () use ($change): void {
        $stored = le_open_uploads_stored();
        if ($stored === null) {
            error_log('open uploads: broken list, rebuilt from files, copy in ' . LE_OPEN_UPLOADS_BROKEN_FILE);
            if (@copy(LE_OPEN_UPLOADS_FILE, LE_OPEN_UPLOADS_BROKEN_FILE)) {
                @chmod(LE_OPEN_UPLOADS_BROKEN_FILE, PRIVATE_FILE_MODE);
            }
        }
        $list = $stored ?? le_open_uploads_recover();
        $changed = $change($list);
        if (($changed !== $list || $stored === null)
            // Mit Benutzernamen: nur für den Eigentümer lesbar wie das Aktivitäts-Log.
            && !le_atomic_write(LE_OPEN_UPLOADS_FILE, (string) json_encode($changed, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), true)) {
            throw new RuntimeException('Cannot write open uploads');
        }
    });
}

/** Merkt sich die Upload-Datei $file als offen für das Formular $form ('' ohne: nur die Frist räumt sie weg). */
function le_open_upload_add(string $file, string $form, string $user, int $now): void
{
    le_open_uploads_change(static function (array $list) use ($file, $form, $user, $now): array {
        $list[$file] = ['form' => $form, 'user' => $user, 'time' => $now];
        return $list;
    });
}

/**
 * Erledigt offene Uploads: Einträge, für die $match(array $entry, string $file) zutrifft, fallen aus der Liste, ihre
 * Dateien werden gelöscht, sofern unbenutzt (delete_unused_uploads: gespeicherte bleiben). Liefert die gelöschten Dateinamen.
 */
function le_open_uploads_close(callable $match): array
{
    return le_open_uploads_hold(static function () use ($match): array {
        $closed = [];
        le_open_uploads_change(static function (array $list) use ($match, &$closed): array {
            foreach ($list as $file => $entry) {
                if ($match((array) $entry, (string) $file)) {
                    $closed[] = UPLOADS_URL . $file;
                    unset($list[$file]);
                }
            }
            return $list;
        });

        return delete_unused_uploads($closed);
    });
}

/**
 * Erledigt die offenen Uploads, die älter als LE_OPEN_UPLOAD_MAX_AGE sind (Formular nie geschlossen). Aufräumen nebenher
 * (nach Upload und Verwerfen): Ist die Sperre gerade belegt, entfällt es diesmal; ein Fehler (z. B. Liste nicht
 * schreibbar) kommt nur ins Log, die Anfrage davor bleibt gelungen. Liefert die gelöschten Dateinamen.
 */
function le_open_uploads_expire(int $now): array
{
    $expired = static fn (array $entry): bool => (int) ($entry['time'] ?? 0) < $now - LE_OPEN_UPLOAD_MAX_AGE;
    try {
        return le_open_uploads_hold(static fn (): array => le_open_uploads_close($expired), false) ?? [];
    } catch (Throwable $e) {
        error_log('open uploads expire failed: ' . $e->getMessage());
        return [];
    }
}

/**
 * Erledigt die offenen Uploads des Formulars $form von $user, mit $files (Dateinamen) nur diese. null, wenn eine
 * davon dort nicht offen ist (fremd, schon erledigt, erfunden): dann bleibt alles, wie es ist.
 */
function le_open_uploads_discard(string $form, string $user, ?array $files): ?array
{
    $mine = static fn (array $entry, string $file): bool => ($entry['form'] ?? null) === $form && ($entry['user'] ?? null) === $user
        && ($files === null || in_array($file, $files, true));

    return le_open_uploads_hold(static function () use ($mine, $files): ?array {
        $open = le_open_uploads();
        foreach ($files ?? [] as $file) {
            if (!isset($open[$file]) || !$mine((array) $open[$file], $file)) {
                return null;
            }
        }

        return le_open_uploads_close($mine);
    });
}

/**
 * Prüfung beim Speichern, die eine Regel für Seiten und Plugin-Einträge: ob der Bildwert $url ein Upload ist, dessen Datei
 * fehlt, und sich gegenüber dem gespeicherten Stand geändert hat ($stored: die gespeicherten Bildwerte). Ein neu gewähltes
 * fehlendes Bild (z. B. von der Frist gelöscht) lehnt das Speichern ab, ein unverändertes (z. B. per FTP gelöscht) nicht.
 * Bilder der Website und fremde Adressen prüft es nicht. Wiederherstellen prüft gar nicht, der Import vorher strenger
 * (content_types_import_values).
 */
function le_upload_missing(string $url, array $stored): bool
{
    return upload_file_name($url) !== null && !in_array($url, $stored, true) && !upload_image_exists($url);
}
