<?php
declare(strict_types=1);

// Mediathek (Verwaltung → Mediathek, nur Admins): alle Bilder der Website, die Uploads (UPLOADS_ROOT) und die Bilder,
// die zur Website gehören (übriges LE_SITE_ROOT), je mit Status. Verwendet heißt: der Dateiname steht in einer Seite,
// einem Eintrag oder einer Datei der Website; nur im Verlauf: nur noch in Sicherungen der Seiten (Wiederherstellen
// braucht ihn); unbenutzt: nirgends. Gelöscht wird nur Unbenutztes. Unbenutzte Uploads räumt le_media_cleanup_if_due
// nach LE_MEDIA_UNUSED_DAYS von selbst weg; Bilder der Website nie, ihre Verwendung (CSS, Pfade im JavaScript) lässt
// sich nicht sicher erkennen.

require_once __DIR__ . '/uploads.php';
require_once __DIR__ . '/activity.php';

const LE_MEDIA_UNUSED_DAYS = 30;
// Letzter Lauf des Aufräumens (höchstens einmal am Tag).
const LE_MEDIA_CLEANUP_FILE = CACHE_ROOT . '/media-cleanup.json';
const LE_MEDIA_CLEANUP_INTERVAL = 86400;
// Urheber im Aktivitäts-Log fürs Aufräumen (kein gültiger Benutzername, users_validate_username).
const LE_MEDIA_CLEANUP_AUTHOR = 'Automatisch (Mediathek)';
// Bilder der Website: Endungen (Fotos und SVG) und Ordner, die nicht dazugehören.
const LE_MEDIA_SITE_EXTENSIONS = [...LE_SITE_PHOTO_EXTENSIONS, 'svg'];
// Status eines Bildes.
const LE_MEDIA_USED = 'used';
const LE_MEDIA_HISTORY = 'history';
const LE_MEDIA_UNUSED = 'unused';
const LE_MEDIA_TEXT = [
    'notFound' => 'Dieses Bild gibt es nicht mehr.',
    'inUse' => 'Dieses Bild wird noch verwendet und bleibt.',
    'failed' => 'Das Bild ließ sich nicht löschen.',
];

/**
 * Alle Bilder: [{url, name, kind (upload|site), size, time, status}], neueste zuerst. Uploads unter UPLOADS_URL, Bilder
 * der Website unter LE_SITE_FILES_URL; Links und Dateien außerhalb der Ordner fehlen.
 */
function le_media_list(): array
{
    $files = le_media_files();
    $status = le_media_status(array_column($files, 'name'));
    $list = [];
    foreach ($files as $file) {
        $list[] = [
            'url' => $file['url'],
            'name' => $file['name'],
            'kind' => $file['kind'],
            'size' => (int) @filesize($file['path']),
            'time' => (int) @filemtime($file['path']),
            'status' => $status[$file['name']] ?? LE_MEDIA_USED,
        ];
    }
    usort($list, static fn (array $a, array $b): int => $b['time'] <=> $a['time'] ?: strcmp($a['url'], $b['url']));

    return $list;
}

/** Bilddateien [{url, name, kind, path}]: Uploads (upload_file_name) und Bilder der Website mit LE_MEDIA_SITE_EXTENSIONS. */
function le_media_files(): array
{
    $files = [];
    foreach (dir_entries(UPLOADS_ROOT) as $name) {
        $path = UPLOADS_ROOT . '/' . $name;
        if (upload_file_name(UPLOADS_URL . $name) !== null && !is_link($path) && is_file($path)) {
            $files[] = ['url' => UPLOADS_URL . $name, 'name' => $name, 'kind' => 'upload', 'path' => $path];
        }
    }
    if (!is_dir(LE_SITE_ROOT)) {
        return $files;
    }
    $entries = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(LE_SITE_ROOT, FilesystemIterator::SKIP_DOTS));
    foreach ($entries as $entry) {
        $path = $entry->getPathname();
        $relative = substr($path, strlen(LE_SITE_ROOT) + 1);
        if ($entry->isLink() || !$entry->isFile() || str_starts_with($path, UPLOADS_ROOT . '/')
            || !in_array(strtolower($entry->getExtension()), LE_MEDIA_SITE_EXTENSIONS, true)
            || le_site_request_file(LE_SITE_FILES_URL . $relative) !== $path) {
            continue;
        }
        $files[] = ['url' => LE_SITE_FILES_URL . $relative, 'name' => $entry->getFilename(), 'kind' => 'site', 'path' => $path];
    }

    return $files;
}

/**
 * Status je Dateiname ($names): einmal alle Textdateien lesen statt je Bild (upload_in_use), Plugin-Daten je Name.
 * Im Zweifel verwendet (unlesbare, zu große Dateien, Fehler). Offene Uploads (Formular noch offen) gelten als verwendet.
 */
function le_media_status(array $names): array
{
    $status = array_fill_keys($names, LE_MEDIA_UNUSED);
    $open = le_open_uploads();
    $mark = static function (?string $content, string $found) use (&$status): void {
        foreach ($status as $name => $current) {
            if ($current !== LE_MEDIA_USED && ($content === null || str_contains($content, (string) $name))) {
                $status[$name] = $found;
            }
        }
    };
    try {
        // Erst der Verlauf, dann alles Lebende: Was dort steht, gilt als verwendet, auch wenn es im Verlauf auch steht.
        foreach ([[BACKUPS_ROOT, ORIGINALS_ROOT], [PAGES_ROOT, LE_SITE_ROOT]] as $i => $roots) {
            foreach ($roots as $root) {
                foreach (le_media_text_files($root) as $content) {
                    $mark($content, $i === 0 ? LE_MEDIA_HISTORY : LE_MEDIA_USED);
                }
            }
        }
        foreach ($status as $name => $current) {
            if ($current !== LE_MEDIA_USED && (isset($open[$name]) || plugins_upload_in_use((string) $name))) {
                $status[$name] = LE_MEDIA_USED;
            }
        }
    } catch (Throwable $e) {
        error_log('le_media_status failed: ' . $e->getMessage());
        return array_fill_keys($names, LE_MEDIA_USED);
    }

    return $status;
}

/**
 * Inhalte der Textdateien unter $root wie upload_in_use (ohne Bilder, ohne die Uploads selbst); null für eine Datei,
 * die nicht gelesen werden kann oder zu groß ist, und für einen Ordner-Link (zählen als Treffer für jedes Bild).
 */
function le_media_text_files(string $root): Generator
{
    if (!is_dir($root)) {
        return;
    }
    $entries = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
    foreach ($entries as $entry) {
        if ($entry->isLink() && $entry->isDir()) {
            yield null;
            continue;
        }
        if (!$entry->isFile() || str_starts_with($entry->getPathname(), UPLOADS_ROOT . '/')
            || in_array(strtolower($entry->getExtension()), UPLOAD_REFERENCE_SKIP_EXTENSIONS, true)) {
            continue;
        }
        if ($entry->getSize() > UPLOAD_REFERENCE_MAX_BYTES) {
            yield null;
            continue;
        }
        $content = @file_get_contents($entry->getPathname());
        yield $content === false ? null : $content;
    }
}

/**
 * Löscht die Bilder $urls (aus le_media_list), sofern unbenutzt (neu geprüft): Uploads über delete_unused_uploads,
 * Bilder der Website nur als echte Datei unter LE_SITE_ROOT (le_media_files: kein Link, keine Uploads). Liefert
 * ['deleted' => [url…], 'kept' => [url => Grund]].
 */
function le_media_delete(array $urls): array
{
    $byUrl = array_column(le_media_files(), null, 'url');
    $wanted = array_values(array_unique(array_filter($urls, 'is_string')));
    $status = le_media_status(array_values(array_unique(array_map(static fn (string $url): string => $byUrl[$url]['name'] ?? '', array_filter($wanted, static fn (string $url): bool => isset($byUrl[$url]))))));
    $deleted = [];
    $kept = [];
    foreach ($wanted as $url) {
        $file = $byUrl[$url] ?? null;
        if ($file === null) {
            $kept[$url] = LE_MEDIA_TEXT['notFound'];
            continue;
        }
        if (($status[$file['name']] ?? LE_MEDIA_USED) !== LE_MEDIA_UNUSED) {
            $kept[$url] = LE_MEDIA_TEXT['inUse'];
            continue;
        }
        $ok = $file['kind'] === 'upload' ? delete_unused_uploads([$url]) !== [] : @unlink($file['path']);
        if ($ok) {
            $deleted[] = $url;
        } else {
            $kept[$url] = LE_MEDIA_TEXT['failed'];
        }
    }

    return ['deleted' => $deleted, 'kept' => $kept];
}

/**
 * Unbenutzte Uploads, älter als LE_MEDIA_UNUSED_DAYS, löschen; höchstens einmal je LE_MEDIA_CLEANUP_INTERVAL (Aufruf
 * beim Laden der Verwaltung). Bilder der Website nie. Wirft nie; liefert die gelöschten Dateinamen.
 */
function le_media_cleanup_if_due(?int $now = null): array
{
    $now ??= time();
    try {
        $last = json_decode((string) @file_get_contents(LE_MEDIA_CLEANUP_FILE), true);
        if (is_array($last) && (int) ($last['time'] ?? 0) > $now - LE_MEDIA_CLEANUP_INTERVAL) {
            return [];
        }
        ensure_dir(CACHE_ROOT);
        write_file_atomic(LE_MEDIA_CLEANUP_FILE, (string) json_encode(['time' => $now]));
        $cutoff = $now - LE_MEDIA_UNUSED_DAYS * 86400;
        $old = array_values(array_filter(le_media_files(), static fn (array $file): bool => $file['kind'] === 'upload' && (int) @filemtime($file['path']) < $cutoff));
        $status = le_media_status(array_column($old, 'name'));
        $urls = array_column(array_filter($old, static fn (array $file): bool => ($status[$file['name']] ?? LE_MEDIA_USED) === LE_MEDIA_UNUSED), 'url');
        $deleted = delete_unused_uploads($urls);
        if ($deleted !== []) {
            le_activity_log('media_cleaned', implode(', ', $deleted), LE_MEDIA_CLEANUP_AUTHOR);
        }
        return $deleted;
    } catch (Throwable $e) {
        error_log('le_media_cleanup_if_due failed: ' . $e->getMessage());
        return [];
    }
}
