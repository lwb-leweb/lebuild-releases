<?php
declare(strict_types=1);

require_once __DIR__ . '/../core/auth.php';
require_once __DIR__ . '/../core/media.php';

// Mediathek (nur Admins): alle Bilder der Website mit Status (le_media_list) und der Frist fürs Aufräumen.
require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_response(['ok' => false, 'error' => API_TEXT['method']], 405);
}

json_response(['ok' => true, 'items' => le_media_list(), 'unusedDays' => LE_MEDIA_UNUSED_DAYS, 'backupRetention' => BACKUP_RETENTION]);
