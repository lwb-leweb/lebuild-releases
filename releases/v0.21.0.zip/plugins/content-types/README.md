# Content-Types Plugin

Framework-Plugin, das beliebig viele Content-Typen (Referenzen, Leistungen, Mitarbeiter, Standorte etc.) als eigene Sidebar-Einträge im Admin bereitstellt. Die Typ-Definitionen liegen pro Kunde als JSON-Dateien in `content/plugins/content-types/` — damit kann jeder Kunde eigene Strukturen haben, ohne dass das Plugin-Repo geforkt werden muss. Eine Website kann Typen samt Einträgen mitbringen, die beim ersten Start angelegt werden (siehe „Typen der Website“).

## Aktivierung

1. Im Admin auf "Plugins" → "Content-Typen" → aktivieren
2. Beim Aktivieren wird die DB-Tabelle `content_items` angelegt (gemeinsam für alle Typen)
3. Solange `content/plugins/content-types/` leer oder nicht existent ist, erscheint **kein** Sidebar-Eintrag — das ist gewollt
4. Sobald eine Typ-Definition unter `content/plugins/content-types/<name>.json` liegt, taucht "<label>" als eigener Sidebar-Eintrag auf
5. Bringt die Website Typen mit (`typ.json`), legt das Plugin sie beim ersten Zugriff danach an

## Was es kann

- Beliebig viele Content-Typen pro Kunde definieren — jeweils mit eigenem Sidebar-Eintrag
- Jeder Typ hat eigene Felder, unterstützte Typen: `text`, `textarea`, `richtext`, `image`, `url`, `datetime`, `date`, `number`, `boolean`, `slug`, `select`, `icon`, `list`
- CRUD-UI im Admin pro Typ (Liste, Bearbeiten, Neu, Löschen)
- Bearbeiten auf der Website: Angemeldete sehen an der Liste "+ Hinzufügen" und an jedem Eintrag "Bearbeiten", "Löschen" und ↑/↓ (`inlineEdit` in `plugin.json`)
- Listen-Rendering im Frontend per Shortcode
- Eigene Seite je Eintrag unter `/<page.path>/<slug>` (Ziel `page`)
- Reihenfolge nach einem Feld statt von Hand (`orderBy`, z. B. neueste zuerst) und Veröffentlichen zu einem Termin (`publishField`): damit ist ein Blog ein Typ wie jeder andere
- Presets als Kopiervorlagen unter `plugins/content-types/presets/` (Leistungen, Referenzen, Fakten)

## Im Admin verwenden

**Neuen Typ anlegen:**
1. JSON-Definition unter `content/plugins/content-types/<name>.json` ablegen (Schema siehe unten oder in `AGENT.md`), oder als Typ der Website mitliefern (siehe „Typen der Website“)
2. Admin neu laden → Typ erscheint als Sidebar-Eintrag mit dem `label` aus der Datei
3. Klick auf den Eintrag → CRUD-UI

**Eintrag anlegen:** Sidebar → Typ wählen → "Neuer Eintrag" → Felder ausfüllen → "Speichern"
**Bearbeiten:** In der Liste → "Bearbeiten" → ändern → "Speichern". Bilder, die der Eintrag danach nicht mehr nutzt (ersetzt, Zeile entfernt), werden gelöscht, wenn sie sonst nirgends verwendet werden.
**Löschen:** In der Liste → "Löschen" → bestätigen. Bilder des Eintrags werden mit gelöscht, wenn sie sonst nirgends verwendet werden.
**Sortieren:** Neue Einträge kommen ans Ende. ↑/↓ an der Liste auf der Website tauschen mit dem Nachbarn in dieser Liste (`sort.php`), auch in einer gefilterten oder gekürzten; die übrigen Einträge bleiben, wo sie sind.
**Importieren:** In der Liste → "Importieren" → JSON-Datei wählen (Format unter „Einträge importieren“). Ergebnis oder Fehler mit Zeile und Feld erscheinen über der Liste.

## API-Endpoints

Alle Endpoints unter `/plugins/content-types/api/`. Auth: gültige Admin-Session. Schreib-Endpoints zusätzlich mit CSRF-Token im Header.

| Endpoint | Methode | Auth | Parameter | Response |
|---|---|---|---|---|
| `list.php` | GET | Session | `?type=<name>&limit=<n>` (ohne limit alle Einträge, sonst 1 bis 500) | `{ok, type, label, schema, rows[]}` |
| `get.php` | GET | Session | `?type=<name>&id=<int>` | `{ok, type, schema, row}` oder 404 |
| `save.php` | POST | Session + CSRF | JSON-Body `{type, data: {...}, id?}` (id nur beim Update) | `{ok, id}`, gelöschte `id` → 404 |
| `delete.php` | POST | Session + CSRF | JSON-Body `{type, id}` | `{ok}` |
| `sort.php` | POST | Session + CSRF | JSON-Body `{type, id, direction: "up"\|"down", target?}`; `target`: id des Eintrags, mit dem getauscht wird (ohne: Nachbar in der Gesamtreihenfolge) | `{ok, moved}` (`moved:false` am Rand oder bei unbekannter id) |
| `import.php` | POST | Session + CSRF + Admin | JSON-Body `{type, entries: [{...}, …]}` (höchstens 500) | `{ok, imported}`; Fehler 422 `{ok:false, error, fields: [{line, id, label, reason}]}` (`fields` leer bei Fehlern der ganzen Datei), über 5 MB 413 |

### Einträge importieren

`entries` ist eine Liste von Einträgen wie `data` bei `save.php`. Beispiel für einen Typ mit `actions: ["modal", "link"]`:

```json
[
  { "title": "Pentest", "bild": "/public/site/uploads/pentest-a1b2c3.webp",
    "features": [ { "title": "Webanwendungen", "icon": "/public/site/img/web.svg" } ] },
  { "title": "Blog", "action": "link", "url": "https://example.com/blog" }
]
```

- Ganz oder gar nicht: Jeder Eintrag wird wie beim Speichern geprüft; ein Fehler → nichts importiert, Meldung „Zeile 3, Titel: Pflichtfeld ist leer.“ (Zeile = Position in der Liste ab 1), bei Unterfeldern mit der Nummer der Zeile im Feld: „Zeile 3, Punkt 2 › Link: Bitte eine Adresse wie https://… eingeben.“.
- Neue Einträge kommen in dieser Reihenfolge ans Ende, vorhandene bleiben unverändert. `id`, `sort_order` und Schlüssel, die kein Feld des Typs sind, fallen weg.
- Werte wie im Formular: Text, Zahl oder `true`/`false`; Objekte und Listen nur bei `list`-Feldern (sonst abgelehnt). Ein leeres `[]` als Eintrag gilt wie `{}`.
- `action` fehlt → `defaultAction`; ein Ziel, das der Typ nicht erlaubt, wird abgelehnt (auch bei nur einem Ziel). Hat ein Typ mit einem Ziel ein eigenes Feld `action`, gilt es wie beim Speichern als normales Feld. Adressen (`slug`) werden wie beim Anlegen eindeutig, auch innerhalb der Datei (`-2`, `-3` …).
- Bilder (auch in `list`-Zeilen) nur als vorhandene Dateien unter `/public/site/uploads/` oder `/public/site/` mit erlaubter Endung (jpg, jpeg, png, webp, svg); fremde URLs (auch `data:`, `ftp:`), fehlende Dateien, Pfade mit `..` und Links, die aus dem Ordner führen, werden abgelehnt.
- Höchstens 500 Einträge (`CONTENT_TYPES_IMPORT_MAX`) und 5 MB (`CONTENT_TYPES_IMPORT_MAX_BYTES`, sonst 413), leere Liste → 422.

**Beispiel — Eintrag erstellen:**

```bash
curl -X POST https://example.com/plugins/content-types/api/save.php \
  -H "Content-Type: application/json" \
  -H "X-CSRF-Token: <token>" \
  -b "session=..." \
  -d '{"type":"referenzen","data":{"kunde":"Acme GmbH","testimonial":"<p>Super Arbeit.</p>"}}'
```

**Beispiel — Liste holen:**

```bash
curl 'https://example.com/plugins/content-types/api/list.php?type=referenzen&limit=20' \
  -b "session=..."
```

## Shortcodes

### `list` — Einträge eines Typs als Liste rendern

Eingebunden via HTML-Container:

```html
<div data-plugin="content-types" data-view="list" data-type="referenzen" data-limit="20"></div>
```

| Attribut (`data-*`) | Type | Default | Pflicht? | Beschreibung |
|---|---|---|---|---|
| `data-type` | string | — | ja | Name des Content-Typs (= Dateiname ohne `.json`) |
| `data-limit` | int | 20 | nein | Max. Anzahl Einträge (ab 1, höchstens 500; sonst 20) |
| `data-filter` | `<feld>=<wert>` | — | nein | Nur Einträge, deren gespeicherter Wert gleich ist (ein Feld, z. B. `kategorie=Tooling`; getrennt am ersten `=`; durchsucht alle Einträge des Typs; `boolean` als `1`/`0`; „+ Neuer Eintrag“ an dieser Liste trägt den Wert vorab ein). Unbekanntes Feld oder `list`-Feld → leere Liste und `<!-- content-types: unknown filter field -->` |

Liegt eine Vorlage `card.php` für den Typ vor, gibt der Shortcode sie aus (siehe „Vorlagen“), sonst die Standardausgabe.

**Standardausgabe (bei Einträgen):**

```html
<ul class="content-list content-list--<typname>" data-le-list="content-types/<typname>">
  <li class="content-list__item" data-le-item="<id>">
    <img class="content-list__image" src="<image-path>" alt="">       <!-- für image-Felder -->
    <div class="content-list__richtext">…sanitized HTML…</div>          <!-- für richtext -->
    <span class="content-list__icon"><svg …></span>                    <!-- für icon -->
    <div class="content-list__field content-list__field--<feldname>">  <!-- für text/number/select/etc., textarea mit <br> -->
      …Wert…
    </div>
  </li>
  …
</ul>
```

**Wenn keine Einträge:**

```html
<p class="content-list content-list--empty" data-le-list="content-types/<typname>">Noch keine Einträge.</p>
```

Die `data-le-*`-Attribute markieren Liste und Einträge für den Seiten-Editor (`le_list_attrs`, `le_item_attrs`).

**Bei Fehler:** HTML-Kommentar statt sichtbarer Fehlermeldung, der Grund steht nur im Log: fehlender oder ungültiger Typ und Datenbankfehler `<!-- content-types: list unavailable -->`.

### Vorlagen (`card.php`, `detail.php`, `page.php`)

Pro Website eigenes Markup unter `public/site/includes/content-types/<typ>/` (von außen gesperrt):

| Datei | Wofür |
|---|---|
| `card.php` | ein Eintrag in der Liste; fehlt sie, gilt die Standardausgabe |
| `detail.php` | Inhalt des Modals und der eigenen Seite (Pflicht, sobald Einträge das Ziel `modal` oder `page` haben) |
| `page.php` | ganze eigene Seite um `detail.php`; fehlt sie, gilt der Rahmen der Startseite (siehe „Eigene Seite“) |

Die Vorlagen bekommen `$item` (gespeicherte Werte mit `id`) und `$type` (Typ-Definition) und geben Werte nur über diese Helfer aus (`template.php`, alle escapen, auch für Attribute). Bindet eine Vorlage Teile der Website ein, die selbst `$item` oder `$type` setzen (z. B. `foreach ($NAV_ITEMS as $item)` in der Navigation), gelten danach `ct_item()` und `ct_type()`: Sie liefern immer den Eintrag, den die Vorlage gerade ausgibt.

| Helfer | Ergebnis |
|---|---|
| `ct_text($item, 'feld')` | Text escaped (Listen/fehlend: leer) |
| `ct_lines($item, 'feld')` | textarea escaped, Zeilenumbrüche als `<br>` |
| `ct_rich($item, 'feld')` | richtext bereinigt |
| `ct_image($item, 'feld', 'altFeld', [attrs])` | `<img src alt>`, Alt-Text aus `altFeld`; Bildregel wie beim Speichern, sonst nichts. `attrs` übernimmt `loading`, `fetchpriority`, `decoding`, `class`, `sizes`; `'size' => true` setzt `width`/`height` aus der Bilddatei (kein Verrutschen beim Laden), nur wenn das CSS die Höhe regelt (`height: auto` oder fest). Großes Bild oben auf der eigenen Seite: `['size' => true, 'fetchpriority' => 'high']`, Listen weiter unten: `['size' => true, 'loading' => 'lazy']` |
| `ct_icon($item, 'feld', 24)` | `<svg>` eines `icon`-Feldes aus dem Icon-Satz des Seiten-Editors, Größe in Pixel, `aria-hidden`; ohne Icon leer |
| `ct_rows($item, 'feld')` | Zeilen eines `list`-Feldes, jede wie `$item` nutzbar |
| `ct_blocks($item, 'feld')` | Blöcke eines `blocks`-Feldes als HTML: je Art die Vorlage `public/site/includes/content-types/_blocks/<art>.php` (bekommt `$block` und `$item`, Werte über die Helfer), sonst schlichtes Markup mit Klassen `ct-block ct-block--<art>` (`<figure>`, `<blockquote>`, `<ul>` …); wirft eine Vorlage, steht für den Block `<!-- content-types: template error -->` |
| `ct_url_attrs($item, 'feld')` | `href` eines `url`-Feldes (auch in Zeilen), auf einen anderen Host mit `target="_blank" rel="noopener"`; ohne erlaubte Adresse leer: `<a <?= ct_url_attrs($row, 'link') ?>>` |
| `ct_tag($item)` | `a` bei Ziel Link und Eigene Seite, sonst `div` |
| `ct_action_attrs($item)` | Link: `href` (extern mit `target="_blank" rel="noopener"`); Eigene Seite: `href="/<page.path>/<slug>"`; Modal: `data-ct-open="<id>" role="button" tabindex="0" aria-haspopup="dialog"`; Nichts: leer |

```php
<<?= ct_tag($item) ?> class="card" data-category="<?= ct_text($item, 'category') ?>" <?= ct_action_attrs($item) ?>>
  <h3><?= ct_text($item, 'title') ?></h3>
  <?= ct_image($item, 'image', 'title') ?>
  <ul><?php foreach (ct_rows($item, 'features') as $row): ?><li><?= ct_text($row, 'title') ?></li><?php endforeach ?></ul>
</<?= ct_tag($item) ?>>
```

- Die Karten stehen direkt im Element des Shortcodes, das dafür `data-le-list` bekommt; Klassen der Website (z. B. ein Grid) gehören an dieses Element: `<div class="grid" data-plugin="content-types" data-view="list" data-type="leistungen"></div>`.
- `data-le-item` setzt der Renderer ins Wurzelelement jeder Karte (`le_item_mark`). Die Vorlage soll genau ein Element ausgeben, sonst wird sie in ein `<div>` gehüllt.
- Für jeden Eintrag mit Ziel `modal` hängt der Renderer `<div hidden data-ct-detail="<id>" data-ct-hash="<typ>-<slug|id>">` mit der Ausgabe von `detail.php` an die Liste (siehe „Modal“).
- Mit `card.php` trägt das Element des Shortcodes zusätzlich `data-le-item-form` (beim Bearbeiten öffnet ein Klick auf eine Karte immer das Formular, auch wenn sie ein Link ist) und bei Typen mit `modal` in `actions` `data-ct-modal` (bindet das Modal-Skript ein).
- Funktionen mit `ct_`, `le_` und `content_types_` sowie Konstanten mit `LE_` und `CONTENT_TYPES_` gehören dem Editor; die Website definiert keine eigenen mit diesen Anfängen.
- Fehler erscheinen nie auf der Website: Wirft eine Vorlage, steht für diesen Eintrag `<!-- content-types: template error -->` (angefangene Ausgabe verworfen); fehlt `detail.php`, `<!-- content-types: detail.php missing -->`. Der Grund steht im Log.

### Modal

Seiten mit einer Liste eines Typs mit `modal` in `actions` (auch leer) bekommen `assets/modal.js` und `assets/modal.css` vor `</body>` (Hook `filter_site_html`). Das Skript:

- öffnet beim Klick oder mit Enter/Leertaste auf `[data-ct-open]` einen Dialog `<div class="ct-modal" role="dialog" aria-modal="true">` → `.ct-modal__dialog` → `button.ct-modal__close` („Schließen“) und den Inhalt von `detail.php`. Der Inhalt wird aus der versteckten Hülle verschoben (nicht geklont), IDs darin stehen also nie doppelt; beim Schließen wandert er zurück.
- Fokus im Dialog (Tab bleibt darin), Esc, Klick auf den Hintergrund, Schließen-Knopf und jedes Element mit `data-ct-close` im Inhalt schließen; der Fokus geht zurück auf die Karte. Ein Link mit `data-ct-close` und `href` schließt und folgt dann dem Link (Strg/⌘-Klick öffnet nur den Tab).
- Seite scrollt nicht, solange es offen ist (Klasse `ct-modal-open` an `<html>`). Kein `showModal()`: die Leiste des Seiten-Editors bleibt darüber bedienbar.
- Adresse `#<typ>-<slug>` (Typen mit eigener Seite) bzw. `#<typ>-<id>`: Öffnen legt sie in den Verlauf, Zurück schließt, eine Seite mit dieser Adresse öffnet das Modal direkt, Links wie `<a href="#leistungen-12">` öffnen es. Unbekannte Adressen tun nichts.
- Aussehen nur über das CSS der Website (`.ct-modal` als Hintergrund, `.ct-modal__dialog`, `.ct-modal__close`). `modal.css` bringt nur Position, Scroll und Fokusring, ohne Farben. Position und Größe stehen unter `:where()` (Spezifität 0), jede Regel der Website gewinnt; Fokusring (`:focus-visible`, zählt wie eine Klasse) und Scroll-Sperre haben bewusst Spezifität, damit z. B. `button { outline: none }` den Fokus nicht unsichtbar macht. Blendet die Website den Schließen-Knopf aus, bekommt das erste sichtbare fokussierbare Element im Dialog den Fokus, sonst der Dialog selbst. Ohne CSS der Website ist der Dialog durchsichtig. z-index `2147482000`, unter der Leiste des Seiten-Editors.
- Beim Bearbeiten auf der Website: Klick (auch Enter) auf eine Karte öffnet das Formular, nie Modal oder Link; in „Ansehen“ wie beim Besucher. Bei offenem Modal zeigt die Leiste „Diesen Eintrag bearbeiten“, die Leisten unter den Listen sind solange weg; der Wechsel von „Ansehen“ auf „Bearbeiten“ öffnet gleich das Formular des Eintrags im Modal. Nach dem Speichern bleibt das Modal mit dem neuen Stand offen; ist der Eintrag danach kein Modal mehr oder gelöscht, schließt es.
- Eigene Skripte der Website an einer Liste: Nach dem Neuladen einer Liste durch den Editor kommt am neuen Element das Ereignis `le-list-reloaded` (bubbelt).

## Frontend einbinden

### Shortcode (HTML)

In einer beliebigen HTML- oder PHP-Seite unter `public/site/`:

```html
<section>
  <h2>Unsere Referenzen</h2>
  <div data-plugin="content-types" data-view="list" data-type="referenzen" data-limit="20"></div>
</section>
```

`data-type` muss zum Dateinamen einer JSON-Definition in `content/plugins/content-types/` passen.

### PHP-Direktzugriff

Für eigenes Rendering oder wenn nur bestimmte Felder/Formate gebraucht werden:

```php
// Liste holen
$eintraege = content_types_public_list('referenzen', 20);

// Einzelnen Eintrag holen
$eintrag = content_types_public_get('referenzen', $id);
```

`public.php` lädt der Site-Header (`public/site/includes/header.php`) nur für aktive Plugins. Eine Seite, die auch bei inaktivem Plugin laufen soll, bindet sie selbst per `require_once` ein (`PROJECT_ROOT . '/plugins/content-types/public.php'`); dann gibt sie `[]` bzw. `null` zurück — kein Crash. Vorteil gegenüber Shortcode: volle Kontrolle über Markup, Felder und Datenstruktur. Nachteil: kein Standard-Rendering, eigenes HTML nötig.

## Datenbank

**Tabelle `content_items`** — wird beim Plugin-Aktivieren angelegt. Eine Tabelle für ALLE Typen.

| Spalte | Typ | Beschreibung |
|---|---|---|
| `id` | `INT UNSIGNED AUTO_INCREMENT PK` | Eindeutige ID pro Eintrag |
| `content_type` | `VARCHAR(64) NOT NULL` | Name des Typs (= Dateiname ohne `.json`) |
| `data` | `JSON NOT NULL` | Typ-spezifische Felder als JSON-Objekt |
| `sort_order` | `INT NOT NULL DEFAULT 0` | Reihenfolge; neue Einträge `MAX+1`, ↑/↓ auf der Website nummerieren den Typ 0…n-1 durch |
| `created_at` | `DATETIME` | Erstellungszeitpunkt, setzt `content_types_save()` |
| `updated_at` | `DATETIME` | Letzte Änderung, setzt `content_types_save()` bei jedem Update (kein `ON UPDATE`) |

Index `idx_type_sort` auf `(content_type, sort_order, id)` für schnelles Filtern/Sortieren.

Standard ist SQLite (`install.sqlite.sql`, Datei `content/data/site.sqlite`): `data` ist dort `TEXT` (Lesen/Schreiben über `json_encode`/`json_decode`), `content_type` hat `CHECK (length(content_type) <= 64)`, der Index heißt `idx_content_items_type_sort`. Mit MySQL-Zugangsdaten gilt `install.sql`.

## Typ-Definition (JSON-Schema)

Datei `content/plugins/content-types/<name>.json`:

```json
{
  "name": "<name>",
  "label": "<Sidebar-Label>",
  "fields": [
    { "name": "<feldname>", "label": "<Label>", "type": "<typ>", "required": <true|false> }
  ]
}
```

`name` und Dateiname müssen exakt übereinstimmen.

**Verfügbare Feld-Typen:**

| Type | Verwendung | Zusatz-Attribute |
|---|---|---|
| `text` | Kurzer reiner Text, wörtlich gespeichert (`<` bleibt), Ausgabe escaped | — |
| `textarea` | Mehrzeiliger reiner Text ohne Formatierung, wörtlich gespeichert (Umbrüche und `<` bleiben), Ausgabe escaped | — |
| `richtext` | HTML mit Sanitizing | — |
| `image` | Bild-Pfad (z.B. `/public/site/uploads/foo.jpg`) | — |
| `datetime` | Datum + Uhrzeit | — |
| `date` | Kalendertag (`YYYY-MM-DD`) | — |
| `number` | Zahl | — |
| `boolean` | Ja/Nein | — |
| `slug` | URL-Slug, optional aus anderem Feld generiert | `from: "<feldname>"` |
| `select` | Auswahl aus festen Werten oder aus den Einträgen eines anderen Typs | `options: ["A", "B", ...]` oder `optionsFrom: "<typ>"` |
| `url` | Link: `https://`, `http://`, `mailto:`, `tel:` oder Pfad ab `/` bzw. `#`; sonst Meldung mit dem Feld, z. B. „Link: Bitte eine Adresse wie https://… eingeben.“ (in Zeilen „Punkt 2 › Link: …“) | — |
| `list` | Wiederholbare Zeilen mit Unterfeldern, gespeichert als Array von Objekten | `fields: [...]` (Unterfelder), `itemLabel`, `min` (0), `max` (50) |
| `blocks` | Kleiner Builder: Blöcke in beliebiger Reihenfolge, gespeichert als Array von Objekten mit `type` | `blocks: ["text", "bild", "galerie", "zitat", "downloads"]` (Vorgabe: alle), `min` (0), `max` (50) |

**`select` mit `optionsFrom`:** Die Werte sind die Titel der Einträge des Typs `<typ>` (Textfeld `name` oder `title`, sonst das erste Textfeld) in dessen Reihenfolge, z. B. Kategorien, die der Kunde selbst pflegt. Gespeichert wird der Titel als Text, `data-filter` und Vorlagen bleiben wie bei `options`. Im Formular steht am Ende „+ <Label> hinzufügen“: fragt nach dem Namen und legt ihn im anderen Typ an. Wird ein Eintrag dort umbenannt, bekommen alle Einträge mit dem alten Wert den neuen (außer ein anderer Eintrag dort trägt den alten Namen noch). Ein Wert, den es dort nicht mehr gibt (gelöscht), bleibt beim Eintrag erhalten und wählbar. Der Typ muss existieren, ein anderer sein und ein Textfeld haben, sonst ist die Definition ungültig. Nur für Felder des Typs, nicht für Unterfelder von `list`. Ohne `optionsFrom` bleibt `select` eine feste Liste.

**`blocks`:** Ein Typ bekommt den Builder nur mit so einem Feld, etwa `{ "name": "inhalt", "label": "Inhalt", "type": "blocks", "blocks": ["text", "bild", "galerie"] }`. Die Blockarten bringt der Kern mit (`PLUGIN_SCHEMA_BLOCKS`): `text` (`text` richtext), `bild` (`bild`, `text` als Bildtext), `galerie` (`bilder`: Zeilen mit `bild`, `text`), `zitat` (`text` textarea, `quelle`), `downloads` (`dateien`: Zeilen mit `titel`, `link`). Unbekannte Arten fallen weg, leere Blöcke auch. Im Formular „+ Text“, „+ Bild“ …, ↑/↓ und Ziehen am Kopf; die Galerie ist ein Bildraster. Ausgabe in Vorlagen mit `ct_blocks($item, 'inhalt')`; als `descriptionField` oder Quelle eines `fallback` zählt der Text der Text- und Zitat-Blöcke. Nur für Felder des Typs, nicht in `list`.

**`fallback`:** Ein `text`- oder `textarea`-Feld mit `"fallback": "<feld>"` zeigt, wenn es leer ist, auf der Website den Anfang dieses Feldes als Klartext (höchstens 200 Zeichen inkl. „…“, `CONTENT_TYPES_FALLBACK_MAX`), etwa eine Kurzfassung aus dem Beitrag: `{ "name": "kurz", "type": "textarea", "fallback": "text" }`. Das gilt in Vorlagen (`card.php`, `detail.php`, `page.php`) und für `descriptionField`, nicht in der Standardausgabe und nicht in `public.php`; gespeichert bleibt das Feld leer. Das Quellfeld ist ein anderes `text`-, `textarea`- oder `richtext`-Feld ohne eigenes `fallback`, sonst ist die Definition ungültig. Nur für Felder des Typs, nicht für Unterfelder von `list`.

**`list`:** Unterfelder wie oben, aber nur `text`, `textarea`, `richtext`, `image`, `url`, `number`, `boolean`, `select`; andere fallen weg. Jede Zeile wird wie ein eigenes Feld bereinigt, leere Zeilen (auch nur leeres Kästchen oder Richtext ohne Text) fallen weg, Pflicht-Unterfelder gelten nur für Zeilen mit Inhalt (auch im Formular). `min`/`max` sind ganze Zahlen (min ab 0, max ab 1, max nicht unter min), sonst gelten 0/50; `min` greift auch, wenn das Feld beim Speichern fehlt. Zu viele oder zu wenige Zeilen → „Höchstens 12 Punkte.“ bzw. „Mindestens 1 Punkt.“ (bei 1 `itemLabel`, sonst `label`). Im Formular ist jede Zeile eine Karte mit ↑/↓ und Entfernen, darunter „+ <itemLabel> hinzufügen“ (ohne `itemLabel`: „+ Zeile hinzufügen“). Hat die Liste genau ein `image`-Unterfeld und sonst nur `text` (Fotos mit Bildtext), ist sie ein Bildraster: mehrere Bilder auf einmal hochladen oder hineinziehen, Reihenfolge per Ziehen oder ←/→. Bilder in Zeilen zählen beim Löschen mit. Die Standardausgabe des Shortcodes zeigt `list`-Felder nicht.

```json
{ "name": "features", "label": "Punkte", "itemLabel": "Punkt", "type": "list", "max": 12,
  "fields": [
    { "name": "title", "label": "Überschrift", "type": "text", "required": true },
    { "name": "text", "label": "Text", "type": "text" }
  ] }
```

### Klickziele: `actions`, `defaultAction`, `page`

Was ein Eintrag beim Klick tut. Ohne `actions` gilt `["none"]`, der Typ verhält sich wie bisher.

```json
"actions": ["modal", "link", "page", "none"],
"defaultAction": "modal",
"page": { "path": "leistungen", "titleField": "title", "descriptionField": "tagline" }
```

| Schlüssel | Bedeutung |
|---|---|
| `actions` | Erlaubte Ziele aus `none` (nicht klickbar), `link`, `page` (eigene Seite), `modal`, jedes höchstens einmal |
| `defaultAction` | Vorgabe für neue Einträge und Einträge ohne `action`; muss in `actions` stehen, fehlt er, gilt das erste Ziel |
| `page` | Pflicht mit dem Ziel `page`: `path` (erstes Stück der Adresse, darf keine Seite, Datei oder Adresse des Editors und nicht der `path` eines anderen Typs sein; sonst sind beide ungültig), `titleField` (Feld der Art `text`), `descriptionField` (`text`, `textarea` oder `richtext`; Umbrüche werden zu Leerzeichen), optional `schema` (`Article`, `BlogPosting` oder `NewsArticle`: strukturierte Daten für Suchmaschinen, siehe „Eigene Seite“) |

- Formular: ab zwei Zielen oben „Beim Klick“ (nur erlaubte Ziele, vorausgewählt `defaultAction`); mit `link` das Feld „Link“ (`url`, Pflicht beim Ziel Link), mit `page` „Adresse“ (`slug` aus `titleField`, eindeutig im Typ). Beide nur sichtbar, wenn „Beim Klick“ passt; bei genau einem Ziel immer. Ein verstecktes Feld übernimmt der Server nicht (es bleibt der gespeicherte Wert), es blockiert das Speichern also nie.
- Gespeichert im `data`-JSON des Eintrags unter `action`, `url`, `slug`. Felder des Typs dürfen nicht so heißen, sobald das Ziel sie braucht.
- Klickziel eines Eintrags immer über `content_types_item_action($def, $item)` (fehlt oder ist nicht erlaubt → `defaultAction`).
- Ungültige Definition (auch kaputtes JSON): Der Typ erscheint weder in der Seitenleiste noch über die API, der Shortcode gibt nur den Kommentar `<!-- content-types: list unavailable -->` aus. Der Grund steht im Log und im Backend unter „Ungültige Content-Typen“.

### Reihenfolge und Veröffentlichung: `orderBy`, `publishField`

```json
"orderBy": { "field": "datum", "direction": "desc" },
"publishField": "datum"
```

| Schlüssel | Bedeutung |
|---|---|
| `orderBy` | Einträge nach `field` (Art `text`, `number`, `date` oder `datetime`), `direction` `asc` (Vorgabe) oder `desc`. Ohne Wert zählt bei `date`/`datetime` das Anlegedatum, sonst steht der Eintrag am Ende. ↑/↓ entfällt (Liste mit `data-le-fixed-order`, `sort.php` liefert `moved: false`). |
| `publishField` | Feld der Art `date` oder `datetime`: Auf der Website (Liste, eigene Seite, `public.php`) erscheint ein Eintrag erst ab diesem Zeitpunkt, leer heißt sofort. Backend und `api/list.php` zeigen alle. |

- Mit `orderBy` liest die Liste alle Einträge des Typs und sortiert in PHP (Werte stehen als JSON in `data`), `data-limit` gilt danach.
- Beispiel: der Typ `blog` der Demo-Website (`public/site/includes/content-types/blog/`).

### Eigene Seite (`/<page.path>/<slug>`)

Einträge mit dem Ziel `page` haben eine eigene Adresse, z. B. `/leistungen/datenschutz-audit` (Hook `site_page`, `content_types_site_page`).

- Echte Dateien und Seiten der Website gehen vor; ein `page.path`, der ein Ordner oder eine Datei der Website ist, macht den Typ ungültig. Eine Seite gleichen Namens ist erlaubt: `/aktuelles` bleibt die Seite mit der Liste, `/aktuelles/<slug>` sind die Einträge.
- Inhalt: `detail.php`, als Einzelansicht markiert (`le_single_mark`, Angemeldete sehen „Diesen Eintrag bearbeiten“, Text `CONTENT_TYPES_SINGLE_LABEL`).
- Mit `page.php`: deren Ausgabe; sie läuft wie jede Seite der Website auf oberster Ebene (Includes wie `header.php` funktionieren), bekommt `$item`, `$type` und `$detail` (fertige Ausgabe von `detail.php`) und gibt ein ganzes Dokument aus: `<html><head>…</head><body>… <?= ct_detail() ?> …</body></html>`. Nach Includes der Website `ct_item()`, `ct_type()` und `ct_detail()` statt der Variablen nehmen (die Includes teilen sich mit `page.php` die globalen Variablen).
- Ohne `page.php`: die Startseite der Website als Rahmen, also alles außer ihrem `<main>` (Kopf, Fuß, bei PHP-Seiten aus ihren Includes, auch Blöcke zwischen `<main>` und Fuß); `detail.php` ersetzt den Inhalt von `<main>`, ohne `<main>` den von `<body>`.
- Im Kopf setzt das Plugin `<title>` (`titleField`), Meta-Beschreibung (`descriptionField` als Klartext, höchstens 160 Zeichen inkl. „…“), `canonical` und vorhandene `og:title`/`og:description`/`og:url` und `twitter:title`/`twitter:description` (Namen ohne Groß/klein, doppelte fallen weg). `canonical` ist absolut mit der „Website-URL“ aus den Einstellungen, sonst relativ.
- Fehlt ein `<base>`, kommt `<base href="/">` an den Anfang des Kopfes, damit relative Adressen des Rahmens (`styles.css`) gelten. Anker und Links in `detail.php`/`page.php` deshalb mit vollem Pfad schreiben (`/kontakt#formular`, nicht `#formular`).
- Mit `page.schema` und Website-URL kommt JSON-LD (schema.org) in den Kopf: Titel, Beschreibung, Adresse, veröffentlicht am `publishField` (sonst Anlegedatum), geändert am `updated_at`, das erste Bild, Autor und Herausgeber der Name aus den Einstellungen (`content_types_page_json_ld`).
- Die Sitemap des Kerns (`/sitemap.xml`) enthält alle veröffentlichten Einträge mit eigener Seite (Hook `sitemap_urls`).
- Shortcodes und Plugin-Filter laufen wie auf jeder Seite.
- 404 (Status 404, `404.php`/`404.html` der Website, sonst die Startseite als Rahmen mit Hinweis): unbekannte Adresse, Eintrag mit anderem Ziel, Eintrag noch nicht fällig (`publishField`), `detail.php` fehlt oder eine Vorlage wirft (Grund im Log).

### Typen der Website (`typ.json`, `eintraege.json`)

Eine Website bringt Typen mit, die sie braucht, neben ihren Vorlagen unter `public/site/includes/content-types/<typ>/`: `typ.json` (Definition wie oben, `name` = Ordnername) und optional `eintraege.json` (Liste wie beim Import). So reisen sie mit der Website, auch im Release-ZIP, in dem `content/` fehlt.

- Beim ersten Zugriff des aktiven Plugins (Seite mit Liste, Backend, API) wird jeder noch nicht übernommene Typ angelegt: Fehlt `content/plugins/content-types/<typ>.json`, wird `typ.json` dorthin kopiert; hat der Typ noch keine Einträge, kommen die aus `eintraege.json` dazu (`content_types_import`: ganz oder gar nicht, Bilder müssen existieren, z. B. unter `/public/site/`).
- Danach steht der Typ in `content/plugins/content-types/.website-typen.json` und wird nie wieder angefasst: Was der Admin ändert oder löscht (Einträge, die Datei des Typs), bleibt so. Gelöschte Einträge löschen Bilder der Website nie, nur Uploads.
- Gleichzeitige Requests warten auf eine Sperre (`store_lock('content-types-website')`), Dateien atomar. Scheitert ein Typ (Datenbank, ungültige Datei), steht der Grund im Log und der nächste Request versucht ihn erneut.
- Ohne `typ.json` (Kundenseiten) passiert nichts; bei übernommenen Typen kostet ein Request nur das Lesen des Ordners und der Liste.

Für eine ausführliche KI-Anleitung zum Anlegen neuer Typen siehe `AGENT.md` in diesem Ordner.

## Bekannte Einschränkungen

- **Keine Übersichtsseite** unter `/<page.path>` selbst; die Liste bindet eine Seite der Website per Shortcode ein, gern die gleichnamige.
- **Sortieren nur auf der Website** (↑/↓ an der Liste), im Admin gibt es dafür keine Oberfläche. Sortiert wird nach `sort_order ASC, id DESC`, mit `orderBy` nach dem Feld.
- **Typ-Erstellung nur per JSON-Datei** im Dateisystem, keine Admin-UI dafür. Das ist bewusst — Typen sind Code-Artefakte und gehören in den Deploy-Workflow, nicht in die Live-DB.
- **Updater-Schutz** — `content/plugins/content-types/` liegt unter `content/` und ist damit kunden-spezifisch (wird vom Updater nicht überschrieben). Typen der Website liegen unter `public/site/`, das der Updater ebenfalls nicht anfasst; neue `typ.json` einer geänderten Website werden beim nächsten Zugriff übernommen.

## Changelog

- **2026-11-05** — `ct_image` nimmt optional `loading`, `fetchpriority`, `decoding`, `class`, `sizes` und mit `size` die Maße aus der Bilddatei.
- **2026-11-04** — `page.schema` (Article, BlogPosting, NewsArticle) für strukturierte Daten der Eintragsseite; Eintragsseiten stehen in der Sitemap des Kerns.
- **2026-11-04** — Feldart `blocks` (kleiner Builder mit Text, Bild, Galerie, Zitat, Downloads) und `ct_blocks`, eigene Vorlagen je Art unter `_blocks/`.
- **2026-11-04** — `fallback: "<feld>"` an `text`/`textarea`: leer zeigt es auf der Website den Anfang des anderen Feldes (Kurzfassung aus dem Beitrag), auch als `descriptionField`.
- **2026-10-28** — `orderBy` (Reihenfolge nach einem Feld, ohne ↑/↓) und `publishField` (auf der Website erst ab Datum) in der Typ-Definition; ersetzt das frühere Blog-Plugin.

- **2026-11-04** — `page.path` darf wie eine Seite der Website heißen (`/aktuelles` Seite, `/aktuelles/<slug>` Einträge).
- **2026-11-04** — `select` mit `optionsFrom: "<typ>"`: Werte aus den Einträgen eines anderen Typs, im Formular „+ <Label> hinzufügen“, Umbenennen dort zieht die Einträge mit. Typen der Website, deren Einträge so einen Typ brauchen, werden nach ihm übernommen.
- **2026-10-28** — Typen der Website: `public/site/includes/content-types/<typ>/typ.json` und `eintraege.json` werden beim ersten Zugriff einmal angelegt (`content_types_adopt_site_types`, gemerkt in `.website-typen.json`).
- **2026-10-28** — Speichern eines inzwischen gelöschten Eintrags meldet 404 statt Erfolg. Version in `plugin.json` auf 1.2.0 angeglichen. `text`-Felder werden wörtlich gespeichert („<3“, „a < b“ bleiben), escaped wird bei der Ausgabe; Titel der eigenen Seite aus `text` ebenso.
- **2026-10-25** — `ct_url_attrs` für eigene `url`-Felder, `ct_item()`/`ct_type()`/`ct_detail()` für Vorlagen mit Includes der Website; Bilder, die ein Eintrag beim Speichern nicht mehr nutzt, werden gelöscht, wenn sie sonst nirgends vorkommen; `list.php` ohne `limit` liefert alle Einträge; eigene Seite setzt auch `twitter:title`/`twitter:description`; Meldungen zu ungültigen Werten nennen das Feld (in Zeilen mit Nummer).
- **2026-10-25** — `sort.php` nimmt optional `target` (sichtbarer Nachbar); ↑/↓ in gefilterten Listen tauscht mit ihm.
- **2026-10-25** — Modal: `assets/modal.js`/`modal.css` auf Seiten mit Liste eines Modal-Typs, Adresse `#<typ>-<slug|id>` (`data-ct-hash`), `data-ct-close`; beim Bearbeiten öffnen Karten (auch Links) das Formular, „Diesen Eintrag bearbeiten“ bei offenem Modal.
- **2026-10-25** — Import: `api/import.php` (nur Admins, höchstens 500, ganz oder gar nicht, Bilder nur vorhandene Dateien) und Knopf „Importieren“ im Backend.
- **2026-10-25** — Eigene Seite je Eintrag unter `/<page.path>/<slug>` mit `page.php` oder dem Rahmen der Startseite, Titel/Beschreibung/canonical aus der Typ-Definition, 404-Seite der Website.
- **2026-10-25** — Vorlagen `card.php`/`detail.php` je Website mit Helfern `ct_*`, versteckte Modal-Inhalte, Shortcode-Attribut `data-filter`; `data-limit` ohne gültige Zahl → 20.
- **2026-10-25** — Klickziele je Typ (`actions`, `defaultAction`, `page`) mit Feld „Beim Klick“ und Link/Adresse im Formular; ungültige Definitionen erscheinen nicht und werden im Backend gemeldet.
- **2026-10-25** — Feldtypen `url` und `list` (gelten für alle Plugins mit Schema, `core/pluginSchema.php`, Formular `entry-form.js`).
- **2026-10-15** — Einträge sind auf der Website bearbeitbar: `inlineEdit` in `plugin.json`, Markierungen `data-le-list`/`data-le-item` im Listen-Renderer (auch bei leerer Liste). Neuer Endpoint `api/sort.php` (↑/↓), neue Einträge landen am Ende (`sort_order` MAX+1). Admin-Formular über `ctx.ui.openEntryForm` (geteilt mit der Website, deutsche Pflichtfeld-Meldungen). Löschen entfernt Bilder, die sonst nirgends verwendet werden (Hooks `content_types_image_values`, `content_types_upload_in_use`). Datenbankfehler erscheinen nie im Wortlaut.
- **2026-10-13** — SQLite als Standard-Datenbank: `install.sqlite.sql`/`uninstall.sqlite.sql`; `created_at`/`updated_at` setzt `content_types_save()` (kein `ON UPDATE` mehr).
- **2026-05-21 — v1.2.0** — `public.php` hinzugefügt: PHP-Direktzugriff auf Einträge ohne HTTP-Umweg. `content_types_public_list()` und `content_types_public_get()` mit eingebautem Plugin-Active-Guard. README und AGENT.md aktualisiert.
- **2026-05-21 — v1.1.0** — `select`-Feldtyp ergänzt (Schema-Attribut `options: [...]` Pflicht). Betrifft `core/pluginSchema.php` (Normalizer) und `plugins/content-types/admin/module.js` (rendert `<select>`). Erstes Beispiel: `content/plugins/content-types/mitarbeiter.json`.
- **2026-05-21 — Security-Fix** — In `api/list.php` und `api/get.php` Reihenfolge von `require_auth()` und `require_plugin_active()` getauscht (Auth zuerst, analog zu save/delete). Defense-in-Depth.
- **2026-05-20 — v1.0.0** — Erstes Release: Manifest, install/uninstall-SQL für `content_items`, `lib.php` (Typ-Loader, CRUD-Helfer, Multi-Entry-Sidebar-Hook), 4 CRUD-API-Endpoints (`list`/`get`/`save`/`delete`), generisches Admin-Modul mit Form-Renderer für alle Feldtypen, Listen-Shortcode-Renderer, 3 Presets (Leistungen, Referenzen, Fakten), `AGENT.md` für KI-Agenten. Begleitende Core-Änderungen: `core/plugins.php` lernt Multi-Entry-Sidebar-Hook, Admin-Frontend (`main.js` + `router.js`) lernt Sub-Routes (`plugin/<name>/<sub>`).
