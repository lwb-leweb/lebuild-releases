<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/auth.php';
require_once __DIR__ . '/../../core/mail.php';
require_once __DIR__ . '/../../core/utils.php';

// Spamschutz-Konstanten (Ablauf in AGENT.md, „Fehlervermeidung“).
const CONTACT_FORM_HONEYPOT   = 'url';   // verstecktes Feld; nur Bots fuellen es aus
const CONTACT_FORM_RATE_MAX   = 5;       // max. Submits pro IP (IPv6: je /64) und Fenster
const CONTACT_FORM_RATE_WINDOW = 3600;   // Fenster in Sekunden (60 Min)
const CONTACT_FORM_RATE_PRUNE_ODDS = 50; // etwa jede 50. Reservierung raeumt alte Dateien weg

// Antworten von api/submit.php an den Besucher (Klartext).
const CONTACT_FORM_TEXT = [
    'rateLimit' => 'Zu viele Anfragen, bitte später erneut.',
    'missingFields' => 'Fehlende Felder.',
    'invalidEmail' => 'Ungültige E-Mail.',
    'noRecipient' => 'Empfänger-Adresse nicht konfiguriert.',
    'sendFailed' => 'Versand fehlgeschlagen.',
    'sent' => 'Danke, Ihre Nachricht ist angekommen.',
    'invalidValue' => 'Bitte die Eingaben prüfen.',
    'fileType' => 'Dieser Dateityp ist nicht erlaubt.',
    'fileSize' => 'Die Dateien sind zu groß.',
    'unknownForm' => 'Unbekanntes Formular.',
];
// Markierung in der Adresse nach dem Absenden aus dem Browser (?kontakt=…#kontaktformular): Wert → Text der Meldung.
const CONTACT_FORM_RESULT_PARAM = 'kontakt';
const CONTACT_FORM_ANCHOR = 'kontaktformular';
const CONTACT_FORM_RESULTS = [
    'gesendet' => 'sent',
    'fehlende-felder' => 'missingFields',
    'ungueltige-email' => 'invalidEmail',
    'zu-viele' => 'rateLimit',
    'kein-empfaenger' => 'noRecipient',
    'versand' => 'sendFailed',
    'ungueltig' => 'invalidValue',
    'dateityp' => 'fileType',
    'zu-gross' => 'fileSize',
    'unbekannt' => 'unknownForm',
];

function contact_form_config_recipient(): string
{
    return core_mail_default_recipient();
}

// Kontext der Signatur eines Empfängers aus data-recipient. Bis 2026-11 stand auch der Standard-Empfänger signiert in
// jeder Seite; mit neuem Kontext gelten diese alten Signaturen nicht mehr (alte Kopien gehen an den aktuellen Empfänger).
const CONTACT_FORM_SIGNATURE_CONTEXT = 'contact-form-recipient-attr|';

function contact_form_signature(string $recipient): string
{
    return hash_hmac('sha256', CONTACT_FORM_SIGNATURE_CONTEXT . $recipient, app_secret());
}

/** Empfänger aus data-recipient, wenn die Signatur passt; sonst (auch ohne) der beim Absenden eingestellte. */
function contact_form_verified_recipient(string $recipient, string $signature): string
{
    if ($recipient !== '' && filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
        $expected = contact_form_signature($recipient);
        if (hash_equals($expected, $signature)) {
            return $recipient;
        }
    }

    return contact_form_config_recipient();
}

/**
 * Whitelist optionaler Zusatzfelder. Schluessel = POST-Feldname, Wert = Label im
 * Mailtext. Reihenfolge = Reihenfolge im Mailtext. Labels generisch halten; ein
 * site-spezifisches Body-Label ist ein spaeteres, admin-konfigurierbares v2-Thema.
 * Nur Felder aus dieser Liste landen in der Mail -- niemals beliebige $_POST-Keys.
 */
function contact_form_extra_fields(): array
{
    return [
        'company'  => 'Firma',
        'phone'    => 'Telefon',
        'telegram' => 'Telegram',
        'subject'  => 'Betreff',
    ];
}

/** Nachricht wörtlich (kein strip_tags, „a < b“ bleibt): Umbrüche als \n, Steuerzeichen außer Tab und Umbruch fallen weg. */
function contact_form_message_text(string $value): string
{
    return trim(preg_replace(['/\r\n?/', '/[\x00-\x08\x0B-\x1F\x7F]/'], ["\n", ''], $value) ?? '');
}

/**
 * Betreff und Text der Mail (text/plain, nichts wird als HTML gelesen): Name einzeilig, die befüllten
 * Whitelist-Felder (Registry-Reihenfolge), eine Leerzeile, die Nachricht. Alle Werte wörtlich; niemals
 * beliebige $post-Keys. Der Betreff bleibt fest, ein Feld `subject` ist nur ein Body-Feld.
 */
function contact_form_mail(string $name, string $email, string $message, array $post): array
{
    $lines = [
        'Name: ' . $name,
        'E-Mail: ' . $email,
    ];
    foreach (contact_form_extra_fields() as $key => $label) {
        $value = core_mail_clean_header(is_string($post[$key] ?? null) ? $post[$key] : '');
        if ($value !== '') {
            // mb_substr: ein Umlaut an der Grenze darf nicht halbiert werden.
            $lines[] = $label . ': ' . mb_substr($value, 0, 200);
        }
    }

    return [
        'subject' => 'Kontaktformular: ' . mb_substr($name, 0, 60),
        'text' => implode("\n", $lines) . "\n\n" . $message . "\n",
    ];
}

/**
 * Honeypot: ist das versteckte Feld vorhanden UND befuellt, ist es ein Bot.
 * Fehlt das Feld (alte Formulare), wird nicht geblockt.
 */
function contact_form_honeypot_tripped(): bool
{
    return trim((string) ($_POST[CONTACT_FORM_HONEYPOT] ?? '')) !== '';
}

/**
 * Erfolgs-/Honeypot-Antwort: 303-Redirect auf den Referer. Bewusst identisch
 * fuer beide Faelle, damit ein Honeypot-Treffer wie ein Erfolg aussieht. Aus dem
 * Browser abgeschickt (contact_form_navigation) mit Markierung „gesendet“.
 */
function contact_form_submit_redirect(string $param = CONTACT_FORM_RESULT_PARAM, string $anchor = CONTACT_FORM_ANCHOR): void
{
    if (contact_form_navigation()) {
        contact_form_back('gesendet', $param, $anchor);
        return;
    }
    http_response_code(303);
    header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? '/'));
}

/** Abgeschickt als Seitenaufruf des Browsers (normales Formular), nicht per fetch: Antwort ist dann eine Rückleitung. */
function contact_form_navigation(): bool
{
    // Ohne Sec-Fetch-Mode (alte Browser, http): Formulare schicken Accept mit text/html vorne; jQuery & Co. setzen
    // X-Requested-With.
    $mode = (string) ($_SERVER['HTTP_SEC_FETCH_MODE'] ?? '');
    if ($mode !== '') {
        return $mode === 'navigate';
    }
    return !isset($_SERVER['HTTP_X_REQUESTED_WITH']) && str_starts_with(strtolower(trim((string) ($_SERVER['HTTP_ACCEPT'] ?? ''))), 'text/html');
}

/**
 * Zurück auf die Seite des Formulars (Pfad und Query des Referers, nie ein fremder Host) mit ?kontakt=$result
 * (CONTACT_FORM_RESULTS) und Sprung zum Formular. Formulare aus einer Datei nehmen ?formular-<name>=…#formular-<name>.
 */
function contact_form_back(string $result, string $param = CONTACT_FORM_RESULT_PARAM, string $anchor = CONTACT_FORM_ANCHOR): void
{
    $referer = parse_url((string) ($_SERVER['HTTP_REFERER'] ?? '')) ?: [];
    $path = (string) ($referer['path'] ?? '');
    // Nur ein Pfad dieser Website: kein //host, kein Backslash (Browser lesen /\host wie //host), keine Steuerzeichen.
    if (!preg_match('#^/(?![/\\\\])[^\\\\\x00-\x20\x7f]*$#', $path)) {
        $path = '/';
    }
    // Die übrige Query bleibt wörtlich, nur eine alte Markierung fällt weg.
    $keep = array_filter(explode('&', (string) ($referer['query'] ?? '')), static fn (string $part): bool => $part !== ''
        && !preg_match('/[\x00-\x20\x7f]/', $part) && explode('=', $part, 2)[0] !== $param);
    $keep[] = $param . '=' . rawurlencode($result);
    http_response_code(303);
    header('Location: ' . $path . '?' . implode('&', $keep) . '#' . $anchor);
}

/** Fehlerantwort: aus dem Browser als Rückleitung mit Markierung, sonst Status mit Text (fetch, curl). */
function contact_form_fail(int $status, string $result, string $param = CONTACT_FORM_RESULT_PARAM, string $anchor = CONTACT_FORM_ANCHOR): void
{
    if (contact_form_navigation()) {
        contact_form_back($result, $param, $anchor);
        return;
    }
    http_response_code($status);
    echo CONTACT_FORM_TEXT[CONTACT_FORM_RESULTS[$result]];
}

/** Meldung nach der Rückleitung (?kontakt=…) für das Formular; null ohne oder bei unbekannter Markierung. */
function contact_form_result_notice(string $param = CONTACT_FORM_RESULT_PARAM): ?array
{
    $result = $_GET[$param] ?? '';
    $key = is_string($result) ? (CONTACT_FORM_RESULTS[$result] ?? null) : null;
    return $key === null ? null : ['ok' => $key === 'sent', 'text' => CONTACT_FORM_TEXT[$key]];
}

function contact_form_rate_dir(): string
{
    return CACHE_ROOT . '/contact-form/ratelimit';
}

/**
 * Datei pro IP, IPv6 je /64-Netz wie bei der Login-Sperre (sonst nimmt ein Spammer für jede Anfrage eine neue
 * Adresse aus seinem Netz). Keine Roh-IP speichern -- nur per HMAC mit dem Installations-Schlüssel.
 */
function contact_form_rate_file(): string
{
    $ip = le_login_ip_key((string) ($_SERVER['REMOTE_ADDR'] ?? ''));
    $hash = substr(hash_hmac('sha256', $ip, app_secret()), 0, 32);

    return contact_form_rate_dir() . '/' . $hash . '.json';
}

/**
 * Liest die Timestamps der aktuellen IP und verwirft alles ausserhalb des Fensters.
 */
function contact_form_rate_timestamps(): array
{
    $raw = @file_get_contents(contact_form_rate_file());
    if ($raw === false) {
        return [];
    }

    $data = json_decode($raw, true);
    if (!is_array($data)) {
        return [];
    }

    $cutoff = time() - CONTACT_FORM_RATE_WINDOW;
    $valid = [];
    foreach ($data as $ts) {
        $ts = (int) $ts;
        if ($ts > $cutoff) {
            $valid[] = $ts;
        }
    }

    return $valid;
}

/**
 * false = gesperrt. Prueft nur, schreibt nichts (frueher 429 vor der Validierung).
 * Entscheidend ist contact_form_rate_reserve() direkt vor dem Versand.
 */
function contact_form_rate_check(): bool
{
    return count(contact_form_rate_timestamps()) < CONTACT_FORM_RATE_MAX;
}

/**
 * Fuehrt $fn unter einer exklusiven Sperre fuer alle Rate-Limit-Dateien aus. Ohne Sperre
 * (Verzeichnis nicht beschreibbar) laeuft $fn trotzdem, damit das Formular nicht ausfaellt.
 */
function contact_form_rate_locked(callable $fn): mixed
{
    try {
        ensure_dir(contact_form_rate_dir());
    } catch (Throwable $e) {
        error_log('contact-form rate limit: ' . $e->getMessage());
    }
    $lock = @fopen(contact_form_rate_dir() . '/.lock', 'c');
    if ($lock !== false && !flock($lock, LOCK_EX)) {
        fclose($lock);
        $lock = false;
    }
    try {
        return $fn();
    } finally {
        if ($lock !== false) {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }
}

/** Schreibt die Timestamps der aktuellen IP atomar via tmp + rename. */
function contact_form_rate_write(array $timestamps): void
{
    $file = contact_form_rate_file();
    $tmp = $file . '.' . bin2hex(random_bytes(4)) . '.tmp';
    if (file_put_contents($tmp, json_encode(array_values($timestamps)), LOCK_EX) === false) {
        @unlink($tmp);
        return;
    }
    if (!rename($tmp, $file)) {
        @unlink($tmp);
    }
}

/**
 * Reserviert vor dem Versand einen Slot: Pruefen und Eintragen unter einer Sperre, damit
 * parallele Anfragen das Limit nicht gemeinsam unterlaufen. Liefert den Timestamp des
 * Slots (fuer contact_form_rate_release()) oder null, wenn das Limit erreicht ist.
 * Erst nach Honeypot und Validierung aufrufen -- sonst fuellen Bots das Fenster mit
 * Garbage und sperren echte Nutzer aus.
 */
function contact_form_rate_reserve(): ?int
{
    return contact_form_rate_locked(static function (): ?int {
        $timestamps = contact_form_rate_timestamps();
        if (count($timestamps) >= CONTACT_FORM_RATE_MAX) {
            return null;
        }
        $now = time();
        $timestamps[] = $now;
        contact_form_rate_write($timestamps);
        // Gelegentlich alte Dateien anderer IPs wegraeumen.
        if (random_int(1, CONTACT_FORM_RATE_PRUNE_ODDS) === 1) {
            contact_form_rate_prune();
        }
        return $now;
    });
}

/** Gibt einen Slot wieder frei, wenn der Versand gescheitert ist. */
function contact_form_rate_release(int $slot): void
{
    contact_form_rate_locked(static function () use ($slot): void {
        $timestamps = contact_form_rate_timestamps();
        $pos = array_search($slot, $timestamps, true);
        if ($pos !== false) {
            unset($timestamps[$pos]);
            contact_form_rate_write($timestamps);
        }
    });
}

/**
 * Loescht Rate-Limit-Dateien, die seit einem ganzen Fenster nicht geschrieben wurden (und
 * liegengebliebene .tmp). Laeuft unter der Sperre aus contact_form_rate_reserve().
 */
function contact_form_rate_prune(): int
{
    $dir = contact_form_rate_dir();
    $cutoff = time() - CONTACT_FORM_RATE_WINDOW;
    $removed = 0;
    foreach (array_merge(glob($dir . '/*.json') ?: [], glob($dir . '/*.tmp') ?: []) as $file) {
        $mtime = @filemtime($file);
        if ($mtime !== false && $mtime < $cutoff && @unlink($file)) {
            $removed++;
        }
    }
    return $removed;
}

// ---------------------------------------------------------------------------
// Formulare aus einer Datei: public/site/includes/forms/<name>.json (Aufbau in README, „Formulare aus einer Datei“).
// Die Datei kommt aus dem Repo der Website und ist vertrauenswürdig; Besucher schicken nur den Namen.
// ---------------------------------------------------------------------------

const CONTACT_FORM_DEFINITION_DIR = LE_SITE_ROOT . '/includes/forms';
const CONTACT_FORM_FIELD_TYPES = ['text', 'textarea', 'email', 'tel', 'number', 'date', 'select', 'radio', 'checkbox', 'file'];
// Diese Namen belegt das Plugin selbst (Honeypot, Kontaktformular).
const CONTACT_FORM_RESERVED_FIELDS = [CONTACT_FORM_HONEYPOT, 'form', 'recipient', 'recipient_sig'];
// Erlaubte Anhänge: Endung → MIME-Typen, die finfo dafür melden darf (Office-Dateien sind ZIP-Archive).
const CONTACT_FORM_FILE_TYPES = [
    'pdf' => ['application/pdf'],
    'jpg' => ['image/jpeg'],
    'jpeg' => ['image/jpeg'],
    'png' => ['image/png'],
    'webp' => ['image/webp'],
    'heic' => ['image/heic', 'image/heif'],
    'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip', 'application/octet-stream'],
    'xlsx' => ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip', 'application/octet-stream'],
];
// docx/xlsx sind ZIP-Archive, finfo erkennt sie oft nur als ZIP: Mit der zip-Erweiterung muss das Archiv ein
// OOXML-Dokument dieser Art sein (ohne sie bleibt nur die Prüfung oben, README). Den Hauptteil nennt [Content_Types].xml
// mit seinem Inhaltstyp; sein Name ist frei (Word Online: word/document2.xml), Teilnamen ohne Rücksicht auf Groß/klein.
// Makro-Varianten (docm, xlsm) haben einen anderen Inhaltstyp und fallen durch.
const CONTACT_FORM_OOXML_CONTENT_TYPES = '[Content_Types].xml';
const CONTACT_FORM_OOXML_TYPES_NS = 'http://schemas.openxmlformats.org/package/2006/content-types';
const CONTACT_FORM_OOXML_MAIN_TYPES = [
    'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml',
    'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml',
];
const CONTACT_FORM_OOXML_TYPES_MAX = 1024 * 1024; // [Content_Types].xml, entpackt
const CONTACT_FORM_FILE_MAX_TOTAL = 10 * 1024 * 1024; // alle Anhänge einer Anfrage zusammen
const CONTACT_FORM_FILE_MAX_COUNT = 10;
const CONTACT_FORM_TEXT_MAX = 200;       // einzeilige Felder
const CONTACT_FORM_TEXTAREA_MAX = 5000;  // mehrzeilige Felder

function contact_form_definition_name_valid(string $name): bool
{
    return (bool) preg_match('/^[a-z0-9][a-z0-9-]{0,40}\z/', $name);
}

/** Anker und Markierung in der Adresse eines Formulars aus einer Datei (?formular-<name>=…#formular-<name>). */
function contact_form_definition_anchor(string $name): string
{
    return 'formular-' . $name;
}

/**
 * Lädt und prüft die Formular-Datei. Liefert die bereinigte Definition mit `steps` (immer eine Liste, ein Formular
 * ohne Schritte hat genau einen ohne Titel). Wirft RuntimeException mit dem ersten Fehler (für uns, nie an Besucher).
 */
function contact_form_definition(string $name): array
{
    if (!contact_form_definition_name_valid($name)) {
        throw new RuntimeException('Ungültiger Formularname.');
    }
    $raw = @file_get_contents(CONTACT_FORM_DEFINITION_DIR . '/' . $name . '.json');
    if ($raw === false) {
        throw new RuntimeException("Formular-Datei forms/$name.json fehlt.");
    }
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        throw new RuntimeException("forms/$name.json ist kein gültiges JSON-Objekt.");
    }

    $str = static fn (mixed $value): string => is_string($value) ? trim($value) : '';
    $title = $str($data['title'] ?? '');
    $recipient = $str($data['recipient'] ?? '');
    if ($recipient !== '' && !filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
        throw new RuntimeException('recipient ist keine E-Mail-Adresse.');
    }

    $rawSteps = isset($data['steps']) ? $data['steps'] : [['fields' => $data['fields'] ?? null]];
    if (!is_array($rawSteps) || $rawSteps === [] || !array_is_list($rawSteps)) {
        throw new RuntimeException('steps muss eine Liste sein.');
    }
    $steps = [];
    $seen = []; // name → bereinigtes Feld, in Reihenfolge (showIf darf nur auf frühere zeigen)
    foreach ($rawSteps as $i => $step) {
        if (!is_array($step) || !is_array($step['fields'] ?? null) || $step['fields'] === [] || array_values($step['fields']) !== $step['fields']) {
            throw new RuntimeException('Schritt ' . ($i + 1) . ': fields muss eine nicht leere Liste sein.');
        }
        $stepIf = contact_form_definition_condition($step['showIf'] ?? null, $seen, 'Schritt ' . ($i + 1));
        $fields = [];
        foreach ($step['fields'] as $field) {
            $raw = $field;
            $field = contact_form_definition_field($field);
            if (isset($seen[$field['name']])) {
                throw new RuntimeException('Feld ' . $field['name'] . ' kommt doppelt vor.');
            }
            $field['showIf'] = contact_form_definition_condition($raw['showIf'] ?? null, $seen, 'Feld ' . $field['name']);
            $seen[$field['name']] = $field;
            $fields[] = $field;
        }
        $steps[] = ['title' => $str($step['title'] ?? ''), 'showIf' => $stepIf, 'fields' => $fields];
    }

    return [
        'name' => $name,
        'title' => $title !== '' ? $title : 'Formular',
        'subject' => $str($data['subject'] ?? ''),
        'recipient' => $recipient,
        'submit' => $str($data['submit'] ?? '') ?: 'Absenden',
        'next' => $str($data['next'] ?? '') ?: 'Weiter',
        'back' => $str($data['back'] ?? '') ?: 'Zurück',
        'success' => $str($data['success'] ?? ''),
        'steps' => $steps,
    ];
}

/** Ein Feld der Definition prüfen und mit Vorgaben auffüllen. */
function contact_form_definition_field(mixed $field): array
{
    if (!is_array($field)) {
        throw new RuntimeException('Ein Feld ist kein Objekt.');
    }
    $name = is_string($field['name'] ?? null) ? $field['name'] : '';
    if (!preg_match('/^[a-z][a-z0-9_]{0,40}$/', $name) || in_array($name, CONTACT_FORM_RESERVED_FIELDS, true)) {
        throw new RuntimeException('Feldname „' . $name . '“ ungültig oder reserviert.');
    }
    $type = is_string($field['type'] ?? null) ? $field['type'] : 'text';
    if (!in_array($type, CONTACT_FORM_FIELD_TYPES, true)) {
        throw new RuntimeException("Feld $name: Typ „{$type}“ unbekannt.");
    }
    $label = is_string($field['label'] ?? null) ? trim($field['label']) : '';
    if ($label === '') {
        throw new RuntimeException("Feld $name: label fehlt.");
    }
    $clean = [
        'name' => $name,
        'type' => $type,
        'label' => $label,
        'required' => ($field['required'] ?? false) === true,
        'placeholder' => is_string($field['placeholder'] ?? null) ? $field['placeholder'] : '',
        'help' => is_string($field['help'] ?? null) ? $field['help'] : '',
        'options' => [],
    ];

    if (in_array($type, ['select', 'radio', 'checkbox'], true)) {
        $options = $field['options'] ?? [];
        if (!is_array($options) || array_values($options) !== $options || array_filter($options, static fn ($o): bool => !is_string($o) || trim($o) === '') !== []) {
            throw new RuntimeException("Feld $name: options muss eine Liste aus Texten sein.");
        }
        if ($options === [] && $type !== 'checkbox') {
            throw new RuntimeException("Feld $name: options fehlt.");
        }
        $clean['options'] = array_values(array_unique(array_map('trim', $options)));
    }
    if ($type === 'number') {
        foreach (['min', 'max', 'step'] as $key) {
            if (isset($field[$key]) && !is_int($field[$key]) && !is_float($field[$key])) {
                throw new RuntimeException("Feld $name: $key muss eine Zahl sein.");
            }
            $clean[$key] = $field[$key] ?? null;
        }
    }
    if ($type === 'file') {
        $accept = $field['accept'] ?? array_keys(CONTACT_FORM_FILE_TYPES);
        if (!is_array($accept) || $accept === [] || array_diff($accept, array_keys(CONTACT_FORM_FILE_TYPES)) !== []) {
            throw new RuntimeException("Feld $name: accept nur aus " . implode(', ', array_keys(CONTACT_FORM_FILE_TYPES)) . '.');
        }
        $clean['accept'] = array_values(array_unique($accept));
        $clean['multiple'] = ($field['multiple'] ?? false) === true;
    }
    if (in_array($type, ['text', 'textarea', 'tel'], true)) {
        $limit = $type === 'textarea' ? CONTACT_FORM_TEXTAREA_MAX : CONTACT_FORM_TEXT_MAX;
        $max = $field['maxlength'] ?? $limit;
        if (!is_int($max) || $max < 1 || $max > $limit) {
            throw new RuntimeException("Feld $name: maxlength zwischen 1 und $limit.");
        }
        $clean['maxlength'] = $max;
    }
    return $clean;
}

/**
 * Bedingung `showIf` eines Feldes oder Schritts: { "field": "<früheres Feld mit options>", "value": "<Option>" | [Optionen] }.
 * Erfüllt, wenn das Feld eine der Optionen hat (bei Checkboxen: eine davon angehakt). null ohne Bedingung.
 */
function contact_form_definition_condition(mixed $raw, array $known, string $where): ?array
{
    if ($raw === null) {
        return null;
    }
    $ref = is_array($raw) && is_string($raw['field'] ?? null) ? $raw['field'] : '';
    if (!isset($known[$ref]) || $known[$ref]['options'] === []) {
        throw new RuntimeException("$where: showIf.field muss ein früheres Feld mit options sein.");
    }
    $values = $raw['value'] ?? null;
    $values = is_string($values) ? [$values] : $values;
    if (!is_array($values) || $values === [] || array_values($values) !== $values
        || array_diff(array_map(static fn ($v) => is_string($v) ? trim($v) : null, $values), $known[$ref]['options']) !== []) {
        throw new RuntimeException("$where: showIf.value muss eine oder mehrere Optionen von $ref sein.");
    }
    return ['field' => $ref, 'values' => array_values(array_unique(array_map('trim', $values)))];
}

/** Bedingung erfüllt bei diesen (bereits geprüften) Werten? Ausgeblendete Felder haben keinen Wert. */
function contact_form_condition_met(?array $condition, array $values): bool
{
    if ($condition === null) {
        return true;
    }
    $value = $values[$condition['field']] ?? '';
    $list = is_array($value) ? $value : ($value === '' ? [] : [$value]);
    return array_intersect($list, $condition['values']) !== [];
}

/** Alle Felder der Definition in Reihenfolge. */
function contact_form_definition_fields(array $definition): array
{
    return array_merge(...array_map(static fn (array $step): array => $step['fields'], $definition['steps']));
}

/**
 * Prüft die Eingaben gegen die Definition. Liefert ['values' => name → Wert (string oder Liste), 'files' => Anhänge
 * für core_mail_send] oder ['error' => Ergebnis aus CONTACT_FORM_RESULTS]. Andere POST-Felder werden ignoriert.
 */
function contact_form_definition_input(array $definition, array $post, array $files): array
{
    $values = [];
    $attachments = [];
    $total = 0;
    foreach ($definition['steps'] as $step) {
        $stepShown = contact_form_condition_met($step['showIf'], $values);
        foreach ($step['fields'] as $field) {
            $name = $field['name'];
            // Ausgeblendet (showIf nicht erfüllt): nicht prüfen, nichts übernehmen, Anhänge verwerfen.
            if (!$stepShown || !contact_form_condition_met($field['showIf'], $values)) {
                $values[$name] = $field['type'] === 'file' || ($field['type'] === 'checkbox' && $field['options'] !== []) ? [] : '';
                continue;
            }
            if ($field['type'] === 'file') {
                $uploads = contact_form_uploaded_files($files[$name] ?? null);
                if ($uploads === null) {
                    return ['error' => 'zu-gross'];
                }
                if (!$field['multiple'] && count($uploads) > 1) {
                    return ['error' => 'ungueltig'];
                }
                if ($uploads === [] && $field['required']) {
                    return ['error' => 'fehlende-felder'];
                }
                $names = [];
                foreach ($uploads as $upload) {
                    $total += $upload['size'];
                    if ($total > CONTACT_FORM_FILE_MAX_TOTAL || count($attachments) >= CONTACT_FORM_FILE_MAX_COUNT) {
                        return ['error' => 'zu-gross'];
                    }
                    $attachment = contact_form_file_attachment($upload, $field['accept']);
                    if ($attachment === null) {
                        return ['error' => 'dateityp'];
                    }
                    $attachments[] = $attachment;
                    $names[] = $attachment['name'];
                }
                $values[$name] = $names;
                continue;
            }

            $raw = $post[$name] ?? null;
            if ($field['type'] === 'checkbox' && $field['options'] !== []) {
                $list = is_array($raw) ? $raw : ($raw === null ? [] : [$raw]);
                $list = array_values(array_unique(array_filter($list, 'is_string')));
                if (array_diff($list, $field['options']) !== []) {
                    return ['error' => 'ungueltig'];
                }
                if ($list === [] && $field['required']) {
                    return ['error' => 'fehlende-felder'];
                }
                // In der Reihenfolge der Definition.
                $values[$name] = array_values(array_intersect($field['options'], $list));
                continue;
            }
            if ($raw !== null && !is_string($raw)) {
                return ['error' => 'ungueltig'];
            }
            $value = $field['type'] === 'textarea' ? contact_form_message_text((string) $raw) : core_mail_clean_header((string) $raw);
            if ($field['type'] === 'checkbox') {
                $value = $value !== '' ? 'Ja' : '';
            }
            if ($value === '') {
                if ($field['required']) {
                    return ['error' => 'fehlende-felder'];
                }
                $values[$name] = '';
                continue;
            }
            if (!contact_form_value_valid($field, $value)) {
                return ['error' => $field['type'] === 'email' ? 'ungueltige-email' : 'ungueltig'];
            }
            $values[$name] = $value;
        }
    }
    return ['values' => $values, 'files' => $attachments];
}

/** Wert eines befüllten Feldes passt zu Typ und Grenzen. */
function contact_form_value_valid(array $field, string $value): bool
{
    if (isset($field['maxlength']) && mb_strlen($value) > $field['maxlength']) {
        return false;
    }
    switch ($field['type']) {
        case 'email':
            return mb_strlen($value) <= CONTACT_FORM_TEXT_MAX && filter_var($value, FILTER_VALIDATE_EMAIL) !== false;
        case 'tel':
            return (bool) preg_match('#^[0-9 +()/.\-]{3,40}$#', $value);
        case 'number':
            if (!is_numeric($value) || strlen($value) > 30) {
                return false;
            }
            return ($field['min'] === null || (float) $value >= $field['min']) && ($field['max'] === null || (float) $value <= $field['max']);
        case 'date':
            $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
            return $date !== false && $date->format('Y-m-d') === $value;
        case 'select':
        case 'radio':
            return in_array($value, $field['options'], true);
        default:
            return true;
    }
}

/**
 * Hochgeladene Dateien eines Feldes als Liste (eins oder name[] mehrere). Leere Auswahl fällt weg.
 * null: zu groß (Grenze von PHP) oder kaputter Upload.
 */
function contact_form_uploaded_files(mixed $entry): ?array
{
    if (!is_array($entry) || !isset($entry['error'])) {
        return [];
    }
    $keys = ['name', 'type', 'tmp_name', 'error', 'size'];
    $list = [];
    if (is_array($entry['error'])) {
        foreach (array_keys($entry['error']) as $i) {
            $list[] = array_combine($keys, array_map(static fn (string $k) => $entry[$k][$i] ?? null, $keys));
        }
    } else {
        $list[] = $entry;
    }
    $files = [];
    foreach ($list as $file) {
        $error = (int) $file['error'];
        if ($error === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        if ($error !== UPLOAD_ERR_OK || !is_string($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            return null;
        }
        $files[] = ['name' => (string) $file['name'], 'tmp' => $file['tmp_name'], 'size' => (int) $file['size']];
    }
    return $files;
}

/** Datei als Anhang, wenn Endung erlaubt und Inhalt dazu passt; sonst null. */
function contact_form_file_attachment(array $upload, array $accept): ?array
{
    $ext = strtolower(pathinfo($upload['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $accept, true)) {
        return null;
    }
    $data = @file_get_contents($upload['tmp']);
    if ($data === false || $data === '') {
        return null;
    }
    $type = CONTACT_FORM_FILE_TYPES[$ext][0];
    if (class_exists('finfo')) {
        $detected = (string) (new finfo(FILEINFO_MIME_TYPE))->buffer($data);
        if (!in_array($detected, CONTACT_FORM_FILE_TYPES[$ext], true)) {
            return null;
        }
    }
    if (isset(CONTACT_FORM_OOXML_MAIN_TYPES[$ext]) && class_exists('ZipArchive') && !contact_form_ooxml_valid($upload['tmp'], CONTACT_FORM_OOXML_MAIN_TYPES[$ext])) {
        return null;
    }
    return ['name' => $upload['name'], 'type' => $type, 'data' => $data];
}

/**
 * Ist die Datei $path ein OOXML-Dokument, dessen [Content_Types].xml (höchstens CONTACT_FORM_OOXML_TYPES_MAX) einen Teil
 * mit dem Inhaltstyp $mainType nennt, den es im ZIP auch gibt?
 */
function contact_form_ooxml_valid(string $path, string $mainType): bool
{
    $zip = new ZipArchive();
    if ($zip->open($path, ZipArchive::RDONLY) !== true) {
        return false;
    }
    try {
        $stat = $zip->statName(CONTACT_FORM_OOXML_CONTENT_TYPES, ZipArchive::FL_NOCASE);
        if ($stat === false || $stat['size'] > CONTACT_FORM_OOXML_TYPES_MAX) {
            return false;
        }
        $raw = $zip->getFromIndex($stat['index'], CONTACT_FORM_OOXML_TYPES_MAX);
        $types = is_string($raw) && strlen($raw) === $stat['size'] ? @simplexml_load_string($raw, 'SimpleXMLElement', LIBXML_NONET) : false;
        if ($types === false) {
            return false;
        }
        foreach ($types->children(CONTACT_FORM_OOXML_TYPES_NS)->Override as $override) {
            // Attribute ohne Präfix stehen in keinem Namensraum, nur attributes() findet sie hier.
            $attrs = $override->attributes();
            $part = ltrim(rawurldecode((string) $attrs['PartName']), '/');
            if (strcasecmp(trim((string) $attrs['ContentType']), $mainType) === 0 && $part !== '' && $zip->locateName($part, ZipArchive::FL_NOCASE) !== false) {
                return true;
            }
        }
        return false;
    } finally {
        $zip->close();
    }
}

/** Betreff und Text der Mail eines Formulars aus einer Datei (text/plain, Werte wörtlich). */
function contact_form_definition_mail(array $definition, array $values): array
{
    $lines = [];
    $multi = count($definition['steps']) > 1;
    foreach ($definition['steps'] as $step) {
        $stepLines = [];
        foreach ($step['fields'] as $field) {
            $value = $values[$field['name']] ?? '';
            if (is_array($value)) {
                $value = implode(', ', $value);
            }
            if ($value === '') {
                continue;
            }
            $stepLines[] = $field['type'] === 'textarea'
                ? $field['label'] . ":\n" . $value . "\n"
                : $field['label'] . ': ' . $value;
        }
        if ($stepLines === []) {
            continue;
        }
        if ($multi && $step['title'] !== '') {
            $lines[] = ($lines === [] ? '' : "\n") . '-- ' . $step['title'] . ' --';
        }
        array_push($lines, ...$stepLines);
    }

    // Betreff aus der Datei, {feld} wird durch den (einzeiligen) Wert ersetzt.
    $subject = $definition['subject'] !== '' ? $definition['subject'] : $definition['title'];
    $subject = preg_replace_callback('/\{([a-z][a-z0-9_]*)\}/', static function (array $m) use ($values): string {
        $value = $values[$m[1]] ?? '';
        return core_mail_clean_header(is_array($value) ? implode(', ', $value) : $value);
    }, $subject) ?? $subject;

    return [
        'subject' => mb_substr(core_mail_clean_header($subject), 0, 150) ?: $definition['title'],
        'text' => $definition['title'] . "\n\n" . rtrim(implode("\n", $lines)) . "\n",
    ];
}

/** Antwort-Adresse: das erste befüllte E-Mail-Feld. */
function contact_form_definition_reply_to(array $definition, array $values): string
{
    foreach (contact_form_definition_fields($definition) as $field) {
        if ($field['type'] === 'email' && ($values[$field['name']] ?? '') !== '') {
            return $values[$field['name']];
        }
    }
    return '';
}
