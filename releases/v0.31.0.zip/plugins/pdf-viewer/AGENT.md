# PDF Viewer Plugin — Anleitung für KI-Agenten

## Was das Plugin tut

Zeigt PDFs der Website zum Durchblättern (Shortcode `blaettern`) und deren erste Seite als Bild (`titelseite`). Gezeichnet wird im Browser mit PDF.js aus `assets/pdfjs/`.

## Was du als KI tun darfst

- Platzhalter in Seiten oder Content-Typ-Vorlagen einbauen (README, „Frontend einbinden“); das PDF kommt aus einem Feld der Art `file`.
- Aussehen in der Website über die Variablen an `.pdf-blaetterer` und eigene Regeln anpassen.
- Texte in `PDF_VIEWER_TEXT` (lib.php) und `TEXT` (assets/pdf-viewer.js) anpassen.

## Was du NICHT anfassen darfst

- `assets/pdfjs/` nur als Ganzes gegen eine neuere Fassung von `pdfjs-dist` tauschen (Lizenzdateien behalten), nie von Hand ändern.
- Keine fremden Adressen zulassen (`pdf_viewer_src`, `EIGENES_PDF`): PDFs nur von dieser Website.
- Keine CDN-Einbindung: Drittanbieter bräuchten den Cookie-Banner.

## Dateistruktur

- `plugin.json` — Manifest mit den Shortcodes `blaettern` und `titelseite`
- `lib.php` — Prüfung der Adresse (`pdf_viewer_src`), Hook `filter_site_html` (CSS in den Kopf, Skript als Modul vor `</body>`)
- `render/blaettern.php`, `render/titelseite.php` — Ausgabe der Shortcodes
- `assets/pdf-viewer.js` — Viewer und Titelseiten (ES-Modul)
- `assets/pdf-viewer.css` — Aufbau und Bewegung, alles unter `:where()`
- `assets/pdfjs/` — PDF.js (`pdf.min.mjs`, Worker, Liberation Sans, JavaScript-Fassung der Decoder) samt Lizenzen

## Datenbank

Keine.

## Häufige Anpassungen — wie geht das?

1. **Zeitung mit Content-Typen:** Typ mit Feld `{ "name": "pdf", "type": "file" }` und `actions: ["page"]`; `detail.php` gibt `blaettern` mit `ct_text($item, 'pdf')` aus, `card.php` `titelseite`, wenn kein eigenes Titelbild gesetzt ist.
2. **Download ausblenden:** `data-download="nein"`.
3. **PDF.js aktualisieren:** `build/pdf.min.mjs`, `build/pdf.worker.min.mjs`, `standard_fonts/LiberationSans-*.ttf`, `wasm/*_nowasm_fallback.js` und die Lizenzen aus dem npm-Paket `pdfjs-dist` kopieren, Version im README-Changelog nennen, Seite mit dem Viewer im Browser prüfen.

## Fehlervermeidung

- Platzhalter bleibt leer, kein `>` in Attributwerten, nie in `<script>` oder Kommentaren.
- Platzhalter in Listen-Karten werden nicht serverseitig ersetzt; das Skript erkennt sie an `data-plugin="pdf-viewer"` und `data-view="titelseite"`. Neue Ansichten, die so funktionieren sollen, dort und in `PDF_VIEWER_MARKS` ergänzen.
- Dateien unter `assets/` mit Endungen außerhalb der Freigabe für `/plugins` (`.wasm`, `.pfb`) liefert der Server nicht aus; darum `useWasm: false`.
- Zoom: Gesten, Mausrad und Klicks hängen an der Bühne (`gesten`, `mausrad`, `tippen`); `touch-action: pan-y` bzw. gezoomt `none`, sonst zoomt wieder der Browser. Stufen und Grenzen in den Konstanten `ZOOM_*` oben in `pdf-viewer.js`.
- `*.min.mjs` überspringt der Minifier des Kerns; andere JS-Dateien verkleinert er (`core/minify.php`).
