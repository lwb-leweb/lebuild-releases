<?php
declare(strict_types=1);

// PDF Viewer: Shortcodes blaettern und titelseite (render/), Skript und CSS kommen per filter_site_html nur auf
// Seiten, die einen davon enthalten. Gezeichnet wird im Browser mit PDF.js (assets/pdfjs, Apache-2.0).

require_once __DIR__ . '/../../core/uploads.php';

const PDF_VIEWER_ASSETS = [
    'style' => PLUGINS_URL . 'pdf-viewer/assets/pdf-viewer.css',
    'script' => PLUGINS_URL . 'pdf-viewer/assets/pdf-viewer.js',
];
// Markierungen im HTML: fertige Ausgabe der Renderer und Platzhalter, die kein Renderer ersetzt hat (etwa in der
// Karte einer Content-Typ-Liste; das Skript liest dort data-src selbst).
const PDF_VIEWER_MARKS = ['data-pdf-blaetterer=', 'data-pdf-titelseite=', 'data-plugin="pdf-viewer"', "data-plugin='pdf-viewer'"];
const PDF_VIEWER_TEXT = [
    'loading' => 'Wird geladen …',
    'previous' => 'Vorherige Seite',
    'next' => 'Nächste Seite',
    'zoomOut' => 'Verkleinern',
    'zoomIn' => 'Vergrößern',
    'fullscreen' => 'Vollbild',
    'download' => 'PDF herunterladen',
    'noscript' => 'Zum Durchblättern bitte JavaScript einschalten oder das PDF herunterladen.',
];
// Wert von data-download, der den Download-Link ausblendet.
const PDF_VIEWER_NO_DOWNLOAD = 'nein';
const PDF_VIEWER_INVALID = '<!-- pdf-viewer: src invalid -->';

/**
 * Adresse eines PDFs dieser Website aus data-src oder null: Upload (UPLOADS_URL) oder Datei der Website unter
 * LE_SITE_FILES_URL (le_upload_document_url), die es gibt (upload_image_exists). Fremde Adressen lädt der Browser
 * ohne CORS ohnehin nicht.
 */
function pdf_viewer_src(mixed $src): ?string
{
    $url = is_string($src) ? trim($src) : '';

    return $url !== '' && le_upload_document_url($url) && upload_image_exists($url) ? $url : null;
}

/** Hook filter_site_html: Seiten mit einem PDF Viewer oder einer Titelseite bekommen einmal CSS und Skript. */
function pdf_viewer_filter_site_html(string $html): string
{
    $found = false;
    foreach (PDF_VIEWER_MARKS as $mark) {
        if (str_contains($html, $mark)) {
            $found = true;
            break;
        }
    }
    if (!$found || str_contains($html, PDF_VIEWER_ASSETS['script'])) {
        return $html;
    }
    $head = stripos($html, '</head>');
    if ($head !== false) {
        $html = substr_replace($html, '<link rel="stylesheet" href="' . PDF_VIEWER_ASSETS['style'] . '">', $head, 0);
    }
    $body = strripos($html, '</body>');
    $script = '<script type="module" src="' . PDF_VIEWER_ASSETS['script'] . '"></script>';

    return $body === false ? $html . $script : substr_replace($html, $script, $body, 0);
}
