// PDF Viewer (Plugin pdf-viewer): zeichnet PDFs dieser Website mit PDF.js (./pdfjs, Apache-2.0).
// [data-pdf-blaetterer]: breit Doppelseiten wie ein Heft (Titelseite allein rechts), Umblättern als 3D-Drehung des
// Blatts; schmal eine Seite, Wischen oder Tippen links/rechts. Pfeiltasten, Vollbild, Seitenzahl, #seite-<n>.
// Zoom bis ZOOM_MAX: Knöpfe, Doppelklick/Doppeltippen, Strg+Mausrad, zwei Finger, Tasten + - 0; gezoomt verschieben
// mit Ziehen oder Mausrad, die Seiten werden danach in der neuen Größe scharf neu gezeichnet.
// [data-pdf-titelseite] und nicht ersetzte Platzhalter mit data-view="titelseite": erste Seite als Leinwand.
import * as pdfjsLib from './pdfjs/pdf.min.mjs';

pdfjsLib.GlobalWorkerOptions.workerSrc = new URL('./pdfjs/pdf.worker.min.mjs', import.meta.url).href;
// WebAssembly-Dateien liefert der Server unter /plugins nicht aus: PDF.js nimmt seine JavaScript-Fassung (wasm/*_nowasm_fallback.js).
const PDF_OPTIONEN = {
    standardFontDataUrl: new URL('./pdfjs/standard_fonts/', import.meta.url).href,
    wasmUrl: new URL('./pdfjs/wasm/', import.meta.url).href,
    useWasm: false,
};
const TEXT = {
    fehler: 'Das PDF konnte nicht geladen werden. Bitte laden Sie es herunter.',
    seite: 'Seite {a} von {n}',
    doppel: 'Seite {a}–{b} von {n}',
};
// Nur eigene Pfade (kein //host, kein Schema) mit Endung .pdf; geprüft hat sie schon der Renderer, nicht aber Platzhalter in Listen.
const EIGENES_PDF = /^\/(?!\/)[^?#]*\.pdf$/i;

const DOPPEL_AB = 720;          // ab dieser Breite der Bühne Doppelseiten
const DAUER_BLATT = 850;        // ms, wie .pdf-blaetterer__blatt im CSS
const DAUER_EINZEL = 450;
const ZOOM_STUFEN = [1, 1.5, 2, 3];  // Knöpfe und Tasten
const ZOOM_MAX = 3;
const ZOOM_DOPPELKLICK = 2;
const ZOOM_PIXEL_MAX = 3200;    // breiteste Leinwand je Seite (Speicher), darüber skaliert der Browser
const ZOOM_SCHARF_NACH = 200;   // ms Ruhe, dann scharf neu zeichnen
const DOPPEL_TIPP = 260;        // ms zwischen zwei Klicks, die als Doppelklick zählen
const reduziert = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

class Blaetterer {
    constructor(wurzel) {
        this.wurzel = wurzel;
        this.buehne = wurzel.querySelector('[data-buehne]');
        this.status = wurzel.querySelector('[data-status]');
        this.anzeige = wurzel.querySelector('[data-seite]');
        this.knopfZurueck = wurzel.querySelector('[data-zurueck]');
        this.knopfWeiter = wurzel.querySelector('[data-weiter]');
        this.knopfVollbild = wurzel.querySelector('[data-vollbild]');
        this.knopfZoomEin = wurzel.querySelector('[data-zoom-ein]');
        this.knopfZoomAus = wurzel.querySelector('[data-zoom-aus]');
        this.cache = new Map();   // "<seite>@<faktor>" → Promise<Canvas> in der aktuellen Größe
        this.ansicht = 0;          // Index in this.ansichten
        this.beschaeftigt = false;
        this.zoom = 1;             // angezeigter Zoom
        this.zGerendert = 1;       // Zoom, in dem die Leinwände der Zoom-Ansicht gezeichnet sind
        this.pan = { x: 0, y: 0 }; // Lage der Seiten in der Zoom-Ansicht
        this.ausschnitt = null;    // Zoom-Ansicht (nur bei zoom > 1)
        this.kette = Promise.resolve();
    }

    async start() {
        try {
            this.doc = await pdfjsLib.getDocument({ url: this.wurzel.dataset.pdfBlaetterer, ...PDF_OPTIONEN }).promise;
        } catch (fehler) {
            console.error(fehler);
            this.status.textContent = TEXT.fehler;
            return;
        }
        this.seiten = this.doc.numPages;
        const erste = (await this.doc.getPage(1)).getViewport({ scale: 1 });
        this.verhaeltnis = erste.width / erste.height;

        this.wurzel.tabIndex = 0;
        this.knopfZurueck.addEventListener('click', () => this.blaettern(-1));
        this.knopfWeiter.addEventListener('click', () => this.blaettern(1));
        this.knopfVollbild?.addEventListener('click', () => this.vollbild());
        this.knopfZoomEin?.addEventListener('click', () => this.stufe(1));
        this.knopfZoomAus?.addEventListener('click', () => this.stufe(-1));
        document.addEventListener('keydown', (e) => {
            if (e.target.closest('input, textarea, select, [contenteditable="true"]')) return;
            // Mehrere auf einer Seite: der mit dem Fokus, sonst der erste.
            const aktiv = e.target.closest('[data-pdf-blaetterer]') || document.querySelector('[data-pdf-blaetterer]');
            if (aktiv !== this.wurzel) return;
            if (e.key === 'ArrowRight') { e.preventDefault(); this.blaettern(1); }
            if (e.key === 'ArrowLeft') { e.preventDefault(); this.blaettern(-1); }
            if (e.ctrlKey || e.metaKey || e.altKey) return;
            if (e.key === '+' || e.key === '=') { e.preventDefault(); this.stufe(1); }
            if (e.key === '-') { e.preventDefault(); this.stufe(-1); }
            if (e.key === '0' || (e.key === 'Escape' && this.zoom > 1 && !document.fullscreenElement)) this.zoomen(1);
        });
        this.gesten();
        this.mausrad();
        document.addEventListener('fullscreenchange', () => {
            // Vollbild verlassen: wieder ganze Seiten.
            if (!document.fullscreenElement) this.zoom = 1;
            this.aufbauen(true);
        });
        let warte;
        new ResizeObserver(() => {
            clearTimeout(warte);
            warte = setTimeout(() => this.aufbauen(), 150);
        }).observe(this.buehne);

        // Startseite aus der Adresse (#seite-5)
        const aus = Number((location.hash.match(/^#seite-(\d+)$/) || [])[1]);
        await this.aufbauen(false, aus >= 1 && aus <= this.seiten ? aus : 1);
    }

    /** Größe und Modus neu bestimmen; $seite: diese Seite zeigen (sonst die aktuelle). */
    async aufbauen(erzwingen = false, seite = null) {
        const breite = this.buehne.clientWidth;
        const doppel = breite >= DOPPEL_AB && this.seiten > 1;
        const hoeheMax = document.fullscreenElement
            ? this.buehne.clientHeight - 8
            : Math.min(window.innerHeight * 0.78, 760);
        const spalten = doppel ? 2 : 1;
        let w = Math.floor(Math.min((breite - 8) / spalten, hoeheMax * this.verhaeltnis));
        w = Math.max(w, 120);
        const h = Math.round(w / this.verhaeltnis);
        const gleich = this.doppel === doppel && this.w === w;
        if (gleich && !erzwingen && seite === null) return;

        const aktuelleSeite = seite ?? this.ersteSeite();
        this.doppel = doppel;
        if (!gleich) this.cache.clear();
        this.w = w;
        this.h = h;
        this.ansichten = this.bildeAnsichten();
        this.ansicht = Math.max(0, this.ansichten.findIndex((a) => a.includes(aktuelleSeite)));
        await this.zeigen();
    }

    /** Doppelseiten [links, rechts] (null = leer) bzw. Einzelseiten [seite]. */
    bildeAnsichten() {
        if (!this.doppel) return Array.from({ length: this.seiten }, (_, i) => [i + 1]);
        const liste = [[null, 1]];
        for (let s = 2; s <= this.seiten; s += 2) {
            liste.push([s, s + 1 <= this.seiten ? s + 1 : null]);
        }
        return liste;
    }

    ersteSeite() {
        const a = this.ansichten?.[this.ansicht];
        return a ? a.find((s) => s !== null) : 1;
    }

    /** Seite in der aktuellen Größe mal faktor zeichnen (einmal je Größe und Faktor). */
    leinwand(nr, faktor = 1) {
        const schluessel = `${nr}@${faktor}`;
        if (!this.cache.has(schluessel)) {
            this.cache.set(schluessel, (async () => {
                const seite = await this.doc.getPage(nr);
                const dpr = Math.min(window.devicePixelRatio || 1, 2);
                const basis = seite.getViewport({ scale: 1 });
                const viewport = seite.getViewport({ scale: Math.min(this.w * faktor * dpr, ZOOM_PIXEL_MAX) / basis.width });
                const canvas = document.createElement('canvas');
                canvas.width = Math.round(viewport.width);
                canvas.height = Math.round(viewport.height);
                await seite.render({ canvas, canvasContext: canvas.getContext('2d'), viewport }).promise;
                return canvas;
            })());
        }
        return this.cache.get(schluessel);
    }

    /** Kopie einer gezeichneten Seite (eine Leinwand kann nur an einer Stelle hängen). */
    async kopie(nr, faktor = 1) {
        const quelle = await this.leinwand(nr, faktor);
        const c = document.createElement('canvas');
        c.width = quelle.width;
        c.height = quelle.height;
        c.getContext('2d').drawImage(quelle, 0, 0);
        c.setAttribute('role', 'img');
        c.setAttribute('aria-label', TEXT.seite.replace('{a}', String(nr)).replace('{n}', String(this.seiten)));
        return c;
    }

    async seitenBox(nr, seite, faktor = 1) {
        const box = document.createElement('div');
        box.className = 'pdf-blaetterer__blattseite' + (seite ? ` pdf-blaetterer__blattseite--${seite}` : '');
        box.style.width = `${this.w * faktor}px`;
        box.style.height = `${this.h * faktor}px`;
        if (nr === null) box.classList.add('pdf-blaetterer__blattseite--leer');
        else box.append(await this.kopie(nr, faktor));
        return box;
    }

    /** Verschiebung, damit eine allein stehende Seite (Titel, letzte) in der Mitte steht. */
    versatz(ansicht) {
        if (!this.doppel) return 0;
        if (ansicht[0] === null) return -this.w / 2;
        if (ansicht[1] === null) return this.w / 2;
        return 0;
    }

    async zeigen() {
        if (this.zoom > 1) return this.zeigeZoom(this.zoom);
        this.ausschnitt = null;
        this.zGerendert = 1;
        this.wurzel.classList.remove('ist-gezoomt');
        const a = this.ansichten[this.ansicht];
        const buch = document.createElement('div');
        buch.className = 'pdf-blaetterer__buch';
        if (this.doppel) {
            buch.append(await this.seitenBox(a[0], 'links'), await this.seitenBox(a[1], 'rechts'));
        } else {
            buch.classList.add('pdf-blaetterer__einzel');
            buch.append(await this.seitenBox(a[0], null));
        }
        buch.style.transform = `translateX(${this.versatz(a)}px)`;
        this.buch = buch;
        this.buehne.replaceChildren(buch, ...this.klickzonen());
        this.aktualisieren();
        this.vorladen();
    }

    klickzonen() {
        return [-1, 1].map((richtung) => {
            const z = document.createElement('div');
            z.className = 'pdf-blaetterer__klickzone pdf-blaetterer__klickzone--' + (richtung < 0 ? 'links' : 'rechts');
            z.setAttribute('aria-hidden', 'true');
            z.addEventListener('click', (e) => this.tippen(richtung, e));
            return z;
        });
    }

    /** Klick auf eine Hälfte: einmal blättert (kurz verzögert), zweimal zoomt an diese Stelle. */
    tippen(richtung, e) {
        if (this.gesteVorbei) return;
        if (this.tippTimer) {
            clearTimeout(this.tippTimer);
            this.tippTimer = null;
            const r = this.buehne.getBoundingClientRect();
            this.zoomen(ZOOM_DOPPELKLICK, e.clientX - r.left, e.clientY - r.top);
            return;
        }
        this.tippTimer = setTimeout(() => {
            this.tippTimer = null;
            this.blaettern(richtung);
        }, DOPPEL_TIPP);
    }

    /** Seiten der aktuellen Ansicht ohne leere Hälfte. */
    sichtbareSeiten() {
        return this.ansichten[this.ansicht].filter((s) => s !== null);
    }

    /** Zoom-Ansicht: die Seiten in faktor-facher Größe in einem Ausschnitt, verschiebbar. */
    async zeigeZoom(faktor) {
        const seiten = this.sichtbareSeiten();
        const buch = document.createElement('div');
        buch.className = 'pdf-blaetterer__buch pdf-blaetterer__buch--zoom';
        const boxen = await Promise.all(seiten.map((nr, i) => this.seitenBox(nr, seiten.length === 2 ? (i === 0 ? 'links' : 'rechts') : null, faktor)));
        buch.append(...boxen);
        const ausschnitt = document.createElement('div');
        ausschnitt.className = 'pdf-blaetterer__ausschnitt';
        ausschnitt.append(buch);
        this.buch = buch;
        this.ausschnitt = ausschnitt;
        this.zGerendert = faktor;
        this.buehne.replaceChildren(ausschnitt);
        this.wurzel.classList.add('ist-gezoomt');
        this.verschieben();
        this.aktualisieren();
        // Leinwände anderer Zoomstufen freigeben (Speicher).
        for (const schluessel of this.cache.keys()) {
            const f = Number(schluessel.split('@')[1]);
            if (f !== 1 && f !== faktor) this.cache.delete(schluessel);
        }
    }

    /** Lage der Seiten im Ausschnitt begrenzen (kleiner als der Ausschnitt: mittig) und anwenden. */
    verschieben() {
        if (!this.ausschnitt) return;
        const sw = this.buehne.clientWidth;
        const sh = this.buehne.clientHeight;
        const cw = this.sichtbareSeiten().length * this.w * this.zoom;
        const ch = this.h * this.zoom;
        this.pan.x = cw <= sw ? (sw - cw) / 2 : Math.min(0, Math.max(sw - cw, this.pan.x));
        this.pan.y = ch <= sh ? (sh - ch) / 2 : Math.min(0, Math.max(sh - ch, this.pan.y));
        this.buch.style.transform = `translate(${this.pan.x}px, ${this.pan.y}px) scale(${this.zoom / this.zGerendert})`;
    }

    /** Auf neu zoomen, der Punkt (px, py) der Bühne bleibt stehen; ohne Punkt die Mitte. Nacheinander abgearbeitet. */
    zoomen(neu, px = null, py = null) {
        this.kette = this.kette.then(() => this.zoomenJetzt(neu, px, py)).catch((fehler) => console.error(fehler));
        return this.kette;
    }

    async zoomenJetzt(neu, px, py) {
        neu = Math.min(ZOOM_MAX, Math.max(1, neu));
        px ??= this.buehne.clientWidth / 2;
        py ??= this.buehne.clientHeight / 2;
        if (neu < 1.02) {
            if (this.zoom === 1) return;
            clearTimeout(this.scharfTimer);
            this.zoom = 1;
            await this.zeigen();
            return;
        }
        if (!this.ausschnitt) {
            // Aus der normalen Ansicht: dieselbe Lage wie dort (mittig), Leinwände der normalen Größe weiterverwenden.
            const sw = this.buehne.clientWidth;
            const sh = this.buehne.clientHeight;
            this.zoom = 1;
            this.pan = { x: (sw - this.sichtbareSeiten().length * this.w) / 2, y: (sh - this.h) / 2 };
            await this.zeigeZoom(1);
        }
        const alt = this.zoom;
        const cx = (px - this.pan.x) / alt;
        const cy = (py - this.pan.y) / alt;
        this.zoom = neu;
        this.pan = { x: px - cx * neu, y: py - cy * neu };
        this.verschieben();
        this.zoomKnoepfe();
        clearTimeout(this.scharfTimer);
        this.scharfTimer = setTimeout(() => {
            this.kette = this.kette.then(() => (this.zoom > 1 && this.zGerendert !== this.zoom ? this.zeigeZoom(this.zoom) : null));
        }, ZOOM_SCHARF_NACH);
    }

    /** Nächste Zoomstufe (Knöpfe, Tasten) um die Mitte. */
    stufe(richtung) {
        const ziel = richtung > 0
            ? (ZOOM_STUFEN.find((s) => s > this.zoom + 0.01) ?? ZOOM_MAX)
            : ([...ZOOM_STUFEN].reverse().find((s) => s < this.zoom - 0.01) ?? 1);
        this.zoomen(ziel);
    }

    zoomKnoepfe() {
        if (this.knopfZoomEin) this.knopfZoomEin.disabled = this.zoom >= ZOOM_MAX - 0.01;
        if (this.knopfZoomAus) this.knopfZoomAus.disabled = this.zoom <= 1;
    }

    /** Strg+Mausrad (auch Zwei-Finger-Zoom am Touchpad) zoomt im Viewer statt im Browser; gezoomt verschiebt das Mausrad. */
    mausrad() {
        this.buehne.addEventListener('wheel', (e) => {
            if (e.ctrlKey) {
                e.preventDefault();
                const r = this.buehne.getBoundingClientRect();
                this.zoomen(this.zoom * Math.exp(-e.deltaY * 0.01), e.clientX - r.left, e.clientY - r.top);
            } else if (this.zoom > 1 && this.ausschnitt) {
                e.preventDefault();
                this.pan.x -= e.deltaX;
                this.pan.y -= e.deltaY;
                this.verschieben();
            }
        }, { passive: false });
        this.buehne.addEventListener('dblclick', (e) => {
            if (this.ausschnitt) {
                e.preventDefault();
                this.zoomen(1);
            }
        });
    }

    aktualisieren() {
        const a = this.ansichten[this.ansicht].filter((s) => s !== null);
        this.anzeige.textContent = (a.length === 2 ? TEXT.doppel : TEXT.seite)
            .replace('{a}', String(a[0])).replace('{b}', String(a[1])).replace('{n}', String(this.seiten));
        this.knopfZurueck.disabled = this.ansicht === 0;
        this.knopfWeiter.disabled = this.ansicht === this.ansichten.length - 1;
        this.zoomKnoepfe();
        history.replaceState(null, '', a[0] === 1 ? location.pathname + location.search : `#seite-${a[0]}`);
    }

    vorladen() {
        [this.ansicht - 1, this.ansicht + 1, this.ansicht + 2].forEach((i) => {
            (this.ansichten[i] || []).forEach((s) => s !== null && this.leinwand(s));
        });
    }

    async blaettern(richtung) {
        const ziel = this.ansicht + richtung;
        if (this.beschaeftigt || ziel < 0 || ziel >= this.ansichten.length) return;
        this.beschaeftigt = true;
        try {
            if (this.zoom > 1) {
                // Gezoomt: gleich die nächste Ansicht, oben links.
                this.ansicht = ziel;
                this.pan = { x: 0, y: 0 };
                await this.zeigeZoom(this.zoom);
            } else if (reduziert) {
                this.ansicht = ziel;
                await this.zeigen();
            } else if (this.doppel) {
                await this.umblaettern(richtung, ziel);
            } else {
                await this.schieben(richtung, ziel);
            }
        } finally {
            this.beschaeftigt = false;
        }
    }

    /** Doppelseite: Das Blatt dreht sich um den Falz, darunter liegt schon die nächste Seite. */
    async umblaettern(richtung, ziel) {
        const alt = this.ansichten[this.ansicht];
        const neu = this.ansichten[ziel];
        const [boxLinks, boxRechts] = this.buch.children;
        const vorwaerts = richtung > 0;

        // Blatt: vorne die Seite, die sich hebt, hinten die, die danach liegt
        const vorn = vorwaerts ? alt[1] : alt[0];
        const hinten = vorwaerts ? neu[0] : neu[1];
        const blatt = document.createElement('div');
        blatt.className = 'pdf-blaetterer__blatt';
        blatt.style.width = `${this.w}px`;
        blatt.style.height = `${this.h}px`;
        blatt.style.left = vorwaerts ? `${this.w}px` : '0px';
        blatt.style.transformOrigin = vorwaerts ? 'left center' : 'right center';
        const seiteVorn = document.createElement('div');
        seiteVorn.className = 'pdf-blaetterer__blatt-vorn';
        const seiteHinten = document.createElement('div');
        seiteHinten.className = 'pdf-blaetterer__blatt-rueck';
        const [cVorn, cHinten] = await Promise.all([
            vorn === null ? null : this.kopie(vorn),
            hinten === null ? null : this.kopie(hinten),
        ]);
        if (cVorn) seiteVorn.append(cVorn);
        if (cHinten) seiteHinten.append(cHinten);
        blatt.append(seiteVorn, seiteHinten);

        // Darunter: die Seite, die nach dem Umblättern sichtbar bleibt
        const unten = await this.seitenBox(vorwaerts ? neu[1] : neu[0], vorwaerts ? 'rechts' : 'links');
        (vorwaerts ? boxRechts : boxLinks).replaceWith(unten);
        this.buch.append(blatt);
        void blatt.offsetWidth;
        blatt.classList.add('ist-am-drehen');
        blatt.style.transform = `rotateY(${vorwaerts ? -180 : 180}deg)`;
        this.buch.style.transform = `translateX(${this.versatz(neu)}px)`;
        await new Promise((fertig) => setTimeout(fertig, DAUER_BLATT));

        this.ansicht = ziel;
        await this.zeigen();
    }

    /** Einzelseite: alte Seite gleitet hinaus, neue hinein. */
    async schieben(richtung, ziel) {
        const weg = this.buch;
        weg.style.transform = `translateX(${-richtung * 40}px)`;
        weg.style.opacity = '0';
        await new Promise((fertig) => setTimeout(fertig, DAUER_EINZEL * 0.6));
        this.ansicht = ziel;
        await this.zeigen();
        const neu = this.buch;
        neu.style.transition = 'none';
        neu.style.transform = `translateX(${richtung * 40}px)`;
        neu.style.opacity = '0';
        void neu.offsetWidth;
        neu.style.transition = '';
        neu.style.transform = 'translateX(0)';
        neu.style.opacity = '1';
    }

    /**
     * Finger und Maus auf der Bühne: zwei Finger zoomen, gezoomt verschiebt ein Finger bzw. die Maus die Seiten,
     * ungezoomt wechselt Wischen die Seite. Nach einer Geste zählt der folgende Klick nicht (gesteVorbei).
     */
    gesten() {
        const zeiger = new Map();
        let zwei = null;    // { abstand, zoom } beim Aufsetzen des zweiten Fingers
        let start = null;   // { x, y, pan } beim Aufsetzen des ersten
        let bewegt = false;
        const abstand = () => {
            const [a, b] = [...zeiger.values()];
            return { d: Math.hypot(a.x - b.x, a.y - b.y), x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
        };
        this.buehne.addEventListener('pointerdown', (e) => {
            zeiger.set(e.pointerId, { x: e.clientX, y: e.clientY });
            if (zeiger.size === 2) {
                zwei = { abstand: abstand().d, zoom: this.zoom };
                start = null;
            } else if (zeiger.size === 1) {
                start = { x: e.clientX, y: e.clientY, pan: { ...this.pan } };
                bewegt = false;
                if (this.ausschnitt) {
                    this.buehne.setPointerCapture?.(e.pointerId);
                    this.ausschnitt.classList.add('ist-am-ziehen');
                }
            }
        });
        this.buehne.addEventListener('pointermove', (e) => {
            if (!zeiger.has(e.pointerId)) return;
            zeiger.set(e.pointerId, { x: e.clientX, y: e.clientY });
            if (zwei && zeiger.size === 2) {
                const m = abstand();
                const r = this.buehne.getBoundingClientRect();
                bewegt = true;
                this.zoomen(zwei.zoom * (m.d / Math.max(zwei.abstand, 1)), m.x - r.left, m.y - r.top);
            } else if (start && this.ausschnitt && zeiger.size === 1) {
                const dx = e.clientX - start.x;
                const dy = e.clientY - start.y;
                if (Math.abs(dx) + Math.abs(dy) > 4) bewegt = true;
                this.pan = { x: start.pan.x + dx, y: start.pan.y + dy };
                this.verschieben();
            }
        });
        const ende = (e) => {
            if (!zeiger.has(e.pointerId)) return;
            zeiger.delete(e.pointerId);
            this.ausschnitt?.classList.remove('ist-am-ziehen');
            if (zwei) {
                if (zeiger.size < 2) zwei = null;
                this.gesteVorbei = true;
                setTimeout(() => { this.gesteVorbei = false; }, DOPPEL_TIPP);
                start = null;
                return;
            }
            if (!start || e.type === 'pointercancel') { start = null; return; }
            const dx = e.clientX - start.x;
            const dy = e.clientY - start.y;
            const war = start;
            start = null;
            if (this.ausschnitt) {
                if (bewegt) {
                    this.gesteVorbei = true;
                    setTimeout(() => { this.gesteVorbei = false; }, 50);
                }
                return;
            }
            // Ungezoomt: Wischen mit dem Finger blättert.
            if (e.pointerType !== 'mouse' && war && Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.5) {
                this.gesteVorbei = true;
                setTimeout(() => { this.gesteVorbei = false; }, DOPPEL_TIPP);
                this.blaettern(dx < 0 ? 1 : -1);
            }
        };
        this.buehne.addEventListener('pointerup', ende);
        this.buehne.addEventListener('pointercancel', ende);
    }

    vollbild() {
        if (document.fullscreenElement) document.exitFullscreen();
        else this.wurzel.requestFullscreen?.().catch(() => {});
    }
}

document.querySelectorAll('[data-pdf-blaetterer]').forEach((wurzel) => {
    if (EIGENES_PDF.test(wurzel.dataset.pdfBlaetterer || '')) new Blaetterer(wurzel).start();
});

// ---------------------------------------------------------------------------
// Titelseite: erste Seite als Leinwand in der Breite des Elements, sobald es (fast) sichtbar ist.

async function zeichneTitelseite(box) {
    if (box.dataset.pdfFertig) return;
    box.dataset.pdfFertig = '1';
    try {
        const aufgabe = pdfjsLib.getDocument({ url: box.dataset.pdfTitelseite || box.dataset.src, ...PDF_OPTIONEN });
        const doc = await aufgabe.promise;
        const seite = await doc.getPage(1);
        const breite = Math.max(box.clientWidth, 120) * Math.min(window.devicePixelRatio || 1, 2);
        const viewport = seite.getViewport({ scale: breite / seite.getViewport({ scale: 1 }).width });
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(viewport.width);
        canvas.height = Math.round(viewport.height);
        canvas.className = 'pdf-titelseite__bild';
        canvas.setAttribute('aria-hidden', 'true');
        await seite.render({ canvas, canvasContext: canvas.getContext('2d'), viewport }).promise;
        box.prepend(canvas);
        aufgabe.destroy();
    } catch (fehler) {
        console.warn('pdf-viewer: Titelseite nicht geladen', fehler);
    }
}

const beobachter = 'IntersectionObserver' in window ? new IntersectionObserver((eintraege) => {
    eintraege.forEach((e) => {
        if (!e.isIntersecting) return;
        beobachter.unobserve(e.target);
        zeichneTitelseite(e.target);
    });
}, { rootMargin: '200px' }) : null;

function titelseiten(wurzel) {
    wurzel.querySelectorAll('[data-pdf-titelseite], [data-plugin="pdf-viewer"][data-view="titelseite"][data-src]').forEach((box) => {
        if (!EIGENES_PDF.test(box.dataset.pdfTitelseite || box.dataset.src || '')) return;
        box.classList.add('pdf-titelseite');
        if (beobachter) beobachter.observe(box); else zeichneTitelseite(box);
    });
}
titelseiten(document);
// Der Seiten-Editor lädt Listen nach dem Speichern neu.
document.addEventListener('le-list-reloaded', (e) => titelseiten(e.target));
