// „Mehr laden“ der Content-Typ-Listen auf der Website (eingebunden von content_types_filter_site_html, nur auf Seiten
// mit data-ct-more). Ein Klick holt die Seite hinter dem Link, sucht darin dieselbe Liste über ihre data-id (auf der
// Seite eindeutig), hängt ihre Einträge samt versteckter Modal-Inhalte an und ersetzt den Knopf durch den neuen bzw.
// entfernt ihn. Danach Fokus auf den ersten neuen Eintrag und das
// Ereignis le-list-reloaded an der Liste (Modal, Seiten-Editor). Geht etwas schief, öffnet der Link wie ohne Skript.

(function () {
  'use strict';

  // Namen wie in PHP (template.php, core/plugins.php; ein Test hält sie gleich).
  const ATTR = {
    more: 'data-ct-more',
    list: 'data-le-list',
    item: 'data-le-item',
    id: 'data-id'
  };
  const FILTER_CLASS = 'content-filter';
  const EVENTS = {
    listReloaded: 'le-list-reloaded'
  };

  // Ein Nachladen zur Zeit.
  let busy = false;

  // Element, in dem die Einträge stehen: die Liste selbst (Karten aus card.php) oder die <ul> darin (Standardausgabe).
  function itemsParent(list) {
    const item = list.querySelector('[' + ATTR.item + ']');
    return item ? item.parentElement : null;
  }

  // Einträge samt versteckter Modal-Inhalte, ohne Filterleiste und Knopf.
  function entriesOf(parent) {
    return Array.prototype.filter.call(parent.children, function (node) {
      return !node.hasAttribute(ATTR.more) && !node.classList.contains(FILTER_CLASS);
    });
  }

  // Der Knopf steht als letztes Kind in der Liste (Element des Shortcodes mit ATTR.list und ATTR.id).
  function load(more) {
    const list = more.parentElement;
    const parent = list && list.hasAttribute(ATTR.list) && list.hasAttribute(ATTR.id) ? itemsParent(list) : null;
    if (!parent) return Promise.reject(new Error('list missing'));
    const selector = '[' + ATTR.list + '][' + ATTR.id + '="' + CSS.escape(list.getAttribute(ATTR.id)) + '"]';
    return fetch(more.href, { credentials: 'same-origin' })
      .then(function (response) {
        if (!response.ok) throw new Error('status ' + response.status);
        return response.text();
      })
      .then(function (html) {
        const fresh = new DOMParser().parseFromString(html, 'text/html').querySelector(selector);
        const freshParent = fresh ? itemsParent(fresh) : null;
        if (!freshParent) throw new Error('no entries');
        const next = fresh.querySelector(':scope > [' + ATTR.more + ']');
        const added = entriesOf(freshParent).map(function (node) {
          const copy = document.importNode(node, true);
          if (parent === list) list.insertBefore(copy, more);
          else parent.append(copy);
          return copy;
        });
        if (next) more.replaceWith(document.importNode(next, true));
        else more.remove();
        const first = added.find(function (node) { return node.hasAttribute(ATTR.item); });
        // Karten ohne Link oder Knopf bekommen den Fokus nur per Skript.
        if (first.tabIndex < 0) first.tabIndex = -1;
        first.focus();
        list.dispatchEvent(new CustomEvent(EVENTS.listReloaded, { bubbles: true }));
      });
  }

  document.addEventListener('click', function (event) {
    if (event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    const more = event.target instanceof Element ? event.target.closest('a[' + ATTR.more + '][href]') : null;
    if (!more) return;
    event.preventDefault();
    if (busy) return;
    busy = true;
    load(more)
      .catch(function () { window.location.href = more.href; })
      .finally(function () { busy = false; });
  });
}());
