<?php
require_once __DIR__ . '/../template.php';

$type = (string) ($attrs['type'] ?? '');
$limit = content_types_list_limit($attrs['limit'] ?? null);
$filterBy = $attrs['filter-by'] ?? null;
$paging = ($attrs['paging'] ?? null) === CONTENT_TYPES_PAGING_ON;
// Liste mit Filterleiste bzw. „Mehr laden“: liest ihre eigenen Parameter aus der Adresse (data-id).
$urlList = $filterBy !== null || $paging;

if (!content_types_name_valid($type)) {
    echo CONTENT_TYPES_RENDER_FAILED;
    return;
}

try {
    $def = content_types_load($type);
    $schema = content_types_schema_columns($def);
} catch (Throwable $e) {
    // Ungültige oder unlesbare Definition: nie ein Fehler auf der Website, Grund nur ins Log.
    error_log('content-types: ' . $e->getMessage());
    echo CONTENT_TYPES_RENDER_FAILED;
    return;
}

try {
    $filter = content_types_list_filter($schema, $attrs['filter'] ?? null);
} catch (InvalidArgumentException $e) {
    // Unbekanntes Feld in data-filter: leere Liste (bleibt bearbeitbar), Grund ins Log.
    error_log('content-types: ' . $type . ': ' . $e->getMessage());
    echo content_types_render_comment('filter');
    $filter = false;
}
try {
    $filterField = content_types_list_filter_by($schema, $filterBy);
} catch (InvalidArgumentException $e) {
    // data-filter-by ohne Auswahlfeld bzw. mit dem Namen des Seiten-Parameters: wie ein unbekanntes Feld in data-filter.
    error_log('content-types: ' . $type . ': ' . $e->getMessage());
    echo content_types_render_comment('filterBy');
    $filterField = null;
    $filter = false;
}
if ($urlList) {
    try {
        $listId = content_types_list_id($attrs[CONTENT_TYPES_LIST_ID_ATTR] ?? null);
    } catch (InvalidArgumentException $e) {
        // Ohne eindeutige data-id wären die Parameter nicht zuzuordnen: wie ein unbekanntes Feld in data-filter.
        error_log('content-types: ' . $type . ': ' . $e->getMessage());
        echo content_types_render_comment('listId');
        $filter = false;
    }
}

// Filterleiste (erstes Kind) und „Mehr laden“ (letztes Kind des Elements des Shortcodes), sonst leer.
$nav = '';
$more = '';
try {
    if ($filter === false) {
        $rows = [];
    } elseif (!$urlList) {
        $rows = content_types_fetch_list($type, $limit, $filter, $def, true);
    } else {
        $path = content_types_request_path();
        $page = $paging ? content_types_list_page($_GET[content_types_list_param($listId, CONTENT_TYPES_PAGE_PARAM)] ?? null, $limit) : 1;
        if ($filterField === null && $limit < CONTENT_TYPES_LIST_MAX) {
            // Nur „Mehr laden“: nur diese Seite lesen, einen Eintrag mehr für „gibt es mehr“ (bei CONTENT_TYPES_LIST_MAX je
            // Seite ginge der nicht, dann wie mit Leiste).
            $slice = content_types_list_slice(content_types_fetch_list($type, $limit + 1, $filter, $def, true, ($page - 1) * $limit), 1, $limit);
        } else {
            // Grundmenge einmal ganz lesen, daraus Optionen, Filter aus der Adresse, Ausschnitt und „gibt es mehr“.
            $rows = content_types_fetch_list($type, null, $filter, $def, true);
            if ($filterField !== null) {
                $options = content_types_select_options($filterField);
                $active = content_types_filter_option($options, $_GET[content_types_list_param($listId, $filterField['name'])] ?? null);
                $nav = content_types_filter_nav($filterField, content_types_filter_options($filterField, $options, $rows), $active, $listId, $path, $_GET);
                if ($active !== null) {
                    $rows = array_values(array_filter($rows, static fn (array $row): bool => content_types_row_matches($row, [$filterField['name'], $active])));
                }
            }
            $slice = content_types_list_slice($rows, $page, $limit);
        }
        $rows = $slice['rows'];
        if ($paging && $slice['more']) {
            $more = content_types_more_link($page + 1, $listId, $path, $_GET);
        }
    }
} catch (Throwable $e) {
    // Datenbankfehler: Grund nur ins Log.
    error_log('content-types: ' . $type . ': ' . $e->getMessage());
    echo CONTENT_TYPES_RENDER_FAILED;
    return;
}

// Mit card.php: Karten direkt im Element des Shortcodes (z. B. dem Grid der Website), das dafür die
// Markierung der Liste bekommt; jede Karte trägt ihre in ihrem Wurzelelement (le_item_mark). Karten sind
// als Ganzes Link oder Knopf, beim Bearbeiten öffnet ein Klick daher immer das Formular
// (LE_ITEM_FORM_ATTR); ein Typ mit Modal bringt das Modal-Skript mit (CONTENT_TYPES_MODAL_LIST_ATTR) und
// die Beschriftung des Knopfes, den die Leiste bei offenem Modal zeigt (wie an der eigenen Seite).
$card = content_types_template_path($type, 'card');
$listAttrs = le_list_attrs('content-types', $type) . (isset($def['orderBy']) ? ' ' . LE_FIXED_ORDER_ATTR : '');
if ($card !== null) {
    $hostAttrs = $listAttrs . ' ' . LE_ITEM_FORM_ATTR
        . (in_array('modal', $def['actions'], true) ? ' ' . CONTENT_TYPES_MODAL_LIST_ATTR . ' ' . le_attrs([LE_SINGLE_LABEL_ATTR => CONTENT_TYPES_SINGLE_LABEL]) : '');
} elseif ($urlList) {
    // Ohne Vorlage mit Leiste bzw. „Mehr laden“ trägt das Element des Shortcodes die Markierung: Der Seiten-Editor
    // tauscht beim Neuladen Leiste, Liste und Knopf zusammen (sonst bliebe ein veralteter Knopf stehen).
    $hostAttrs = $listAttrs;
}
// Markierung an <ul> bzw. Platzhalter, wenn das Element des Shortcodes sie nicht trägt.
$innerAttrs = $card === null && !$urlList ? ' ' . $listAttrs : '';
echo $nav;
if (empty($rows)) {
    // Ohne Vorlage trägt der Platzhalter die Markierung (sonst gäbe es kein „+ Hinzufügen“).
    echo '<p class="content-list content-list--empty"' . $innerAttrs . '>' . CONTENT_TYPES_EMPTY_TEXT . '</p>';
    return;
}
if ($card !== null) {
    $modal = [];
    foreach ($rows as $row) {
        $item = content_types_template_item($def, $row);
        $html = content_types_render_template($card, $def, $item);
        echo $html === null ? content_types_render_comment('template') : le_item_mark($html, (int) $item['id']);
        if ($item[CONTENT_TYPES_ITEM_TARGET]['action'] === 'modal') {
            $modal[] = $item;
        }
    }
    // Inhalte der Modals versteckt an der Liste: kein zusätzlicher Request, für Suchmaschinen lesbar.
    $detail = $modal === [] ? null : content_types_template_path($type, 'detail');
    if ($modal !== [] && $detail === null) {
        error_log('content-types: ' . $type . ': ' . CONTENT_TYPES_RENDER_COMMENT['detailMissing']);
        echo content_types_render_comment('detailMissing');
        $modal = [];
    }
    foreach ($modal as $item) {
        $html = content_types_render_template($detail, $def, $item);
        echo $html === null
            ? content_types_render_comment('template')
            : '<div hidden ' . le_attrs([CONTENT_TYPES_DETAIL_ATTR => (int) $item['id'], CONTENT_TYPES_HASH_ATTR => content_types_modal_hash($def, $item)]) . '>' . $html . '</div>';
    }
    echo $more;
    return;
}
?>
<ul class="content-list content-list--<?= htmlspecialchars($type) ?>"<?= $innerAttrs ?>>
  <?php foreach ($rows as $row): ?>
    <li class="content-list__item" <?= le_item_attrs((int) $row['id']) ?>>
      <?php foreach ($schema as $field): ?>
        <?php
          $name = $field['name'];
          $fieldType = $field['type'] ?? 'text';
          $value = $row[$name] ?? '';
          // Zeilen eines list-Feldes zeigt die Standardausgabe nicht.
          if ($value === '' || $value === null || is_array($value)) continue;
        ?>
        <?php if ($fieldType === 'image'): ?>
          <img class="content-list__image" src="<?= htmlspecialchars((string) $value) ?>" alt="">
        <?php elseif ($fieldType === 'richtext'): ?>
          <div class="content-list__richtext"><?= plugin_sanitize_richtext((string) $value) ?></div>
        <?php elseif ($fieldType === 'icon'): ?>
          <span class="content-list__icon"><?= ct_icon($row, $name) ?></span>
        <?php else: ?>
          <div class="content-list__field content-list__field--<?= htmlspecialchars($name) ?>">
            <?= $fieldType === 'textarea' ? le_text_lines((string) $value) : htmlspecialchars((string) $value) ?>
          </div>
        <?php endif ?>
      <?php endforeach ?>
    </li>
  <?php endforeach ?>
</ul>
<?= $more ?>
