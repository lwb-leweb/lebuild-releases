<?php
declare(strict_types=1);

// Hooks der Plugins (docs/knowledgebase/plugins/hooks.md, docs/knowledgebase/plugins/ref-hooks.md): Hook-Funktion finden und aufrufen für Seiten, Filter, Sitemap und Einträge;
// dazu die Helfer, mit denen Filter Markup, CSS und Skripte vor </head> und </body> einfügen.

require_once LE_BACKEND . '/html/markup.php';
require_once LE_BACKEND . '/plugins/plugins.php';

// Hooks, die ein Plugin mit fehlgeschlagenem Schema (le_plugin_schema_blocked) nicht beantwortet: Website und Seitenleiste.
// Sein Code läuft dafür nicht, der Hook lädt nicht einmal seine lib.php (seine public.php darf sie laden, deren
// Lesefunktionen sperrt le_plugin_public_ready). Hooks für Daten (upload_in_use, Einspielen) laufen weiter.
// Scheitert das Schema während eines solchen Hooks (er baute die erste Verbindung der Anfrage auf,
// le_plugins_schema_update), verwirft der Aufrufer seine Antwort: Sie käme aus dem halben Schema.
const LE_PLUGIN_SITE_HOOKS = ['filter_site_html', 'site_page', 'sitemap_urls', 'admin_sidebar_entries'];
// Datei eines Plugins mit allen seinen Hook-Funktionen (R6, docs/knowledgebase/plugins/rules.md).
const LE_PLUGIN_HOOKS_FILE = 'lib/hooks.php';

/**
 * Hook-Funktion „<plugin>_<hook>“ aus der lib.php des Plugins (siehe docs/knowledgebase/plugins/hooks.md), null ohne;
 * null auch für einen Hook aus LE_PLUGIN_SITE_HOOKS, solange das Schema des Plugins fehlgeschlagen ist.
 */
function plugin_hook_function(string $name, string $hook): ?string
{
    if (!plugin_name_valid($name) || (in_array($hook, LE_PLUGIN_SITE_HOOKS, true) && le_plugin_schema_blocked($name))) {
        return null;
    }
    if (!le_plugin_load_lib($name)) {
        return null;
    }
    $fn = le_plugin_hook_name($name, $hook);

    return function_exists($fn) ? $fn : null;
}

/** Name der Hook-Funktion „<plugin>_<hook>“, Bindestriche im Plugin-Namen als Unterstriche (docs/knowledgebase/plugins/hooks.md). */
function le_plugin_hook_name(string $name, string $hook): string
{
    return str_replace('-', '_', $name) . '_' . $hook;
}

/**
 * Namen der Funktionen, die die PHP-Quelle $source auf oberster Ebene oder in Blöcken definiert, klein geschrieben (PHP
 * unterscheidet bei Funktionsnamen nicht), auch mit & vor dem Namen; keine Methoden (Rumpf einer Klasse, eines Interfaces,
 * Traits oder Enums), keine Closures. Ohne sie auszuführen; braucht den Tokenizer.
 */
function le_plugin_source_functions(string $source): array
{
    return array_column(array_filter(le_plugin_source_function_heads($source), static fn (array $f): bool => !$f['method']), 'name');
}

/**
 * Funktionen wie le_plugin_source_functions, dazu Methoden, je mit dem Anfang ihres Rumpfs: Liste aus ['name' => klein,
 * 'method' => im Rumpf einer Klasse, eines Interfaces, Traits oder Enums, 'head' => Text der Tokens nach der öffnenden {
 * bis einschließlich der ersten ; oder } danach, ohne Kommentare und Leerraum (außer einem Leerzeichen zwischen zwei
 * Wörtern), leer ohne Rumpf]. So lässt sich ohne Ausführen prüfen, womit eine Funktion beginnt
 * (R10: if(!le_plugin_public_ready('x')){return[];).
 */
function le_plugin_source_function_heads(string $source): array
{
    $tokens = array_values(array_filter(token_get_all($source), static fn (mixed $t): bool => !is_array($t) || !in_array($t[0], [T_WHITESPACE, T_COMMENT, T_DOC_COMMENT], true)));
    $text = static fn (mixed $t): string => is_array($t) ? $t[1] : $t;
    $functions = [];
    $depth = 0;
    // Tiefe der offenen Klassenrümpfe; $classNext: Die nächste { öffnet einen (nicht bei Name::class).
    $classes = [];
    $classNext = false;
    foreach ($tokens as $i => $token) {
        $id = is_array($token) ? $token[0] : $token;
        if (in_array($id, [T_CLASS, T_INTERFACE, T_TRAIT, T_ENUM], true) && !(is_array($tokens[$i - 1] ?? null) && $tokens[$i - 1][0] === T_DOUBLE_COLON)) {
            $classNext = true;
        } elseif (in_array($id, ['{', T_CURLY_OPEN, T_DOLLAR_OPEN_CURLY_BRACES], true)) {
            $depth++;
            if ($classNext) {
                $classes[] = $depth;
                $classNext = false;
            }
        } elseif ($id === '}') {
            if (end($classes) === $depth) {
                array_pop($classes);
            }
            $depth--;
        } elseif ($id === T_FUNCTION) {
            $at = $i + 1;
            if ($text($tokens[$at] ?? '') === '&') {
                $at++;
            }
            $next = $tokens[$at] ?? null;
            if (!is_array($next) || $next[0] !== T_STRING) {
                continue;
            }
            // Die Signatur hat keine { oder ; (Vorgaben, Typen, Attribute): Die erste { öffnet den Rumpf, ein ; heißt ohne Rumpf.
            do {
                $at++;
            } while (isset($tokens[$at]) && $tokens[$at] !== '{' && $tokens[$at] !== ';');
            $head = '';
            for ($at = ($tokens[$at] ?? null) === '{' ? $at + 1 : count($tokens); isset($tokens[$at]); $at++) {
                $piece = $text($tokens[$at]);
                $head .= (preg_match('/\w$/', $head) === 1 && preg_match('/^\w/', $piece) === 1 ? ' ' : '') . $piece;
                if ($tokens[$at] === ';' || $tokens[$at] === '}') {
                    break;
                }
            }
            $functions[] = ['name' => strtolower($next[1]), 'method' => $classes !== [], 'head' => $head];
        }
    }
    return $functions;
}

/**
 * Hat $name eine Funktion für den Hook $hook, ohne seinen Code zu laden? LE_PLUGIN_HOOKS_FILE wird nur als Text gelesen
 * (für ein Plugin mit fehlgeschlagenem Schema, dessen Code nicht laufen darf). Ohne Tokenizer im Zweifel ja.
 */
function le_plugin_hook_declared(string $name, string $hook): bool
{
    $file = plugin_path($name, LE_PLUGIN_HOOKS_FILE);
    if (!is_file($file)) {
        return false;
    }
    if (!function_exists('token_get_all')) {
        return true;
    }

    return in_array(strtolower(le_plugin_hook_name($name, $hook)), le_plugin_source_functions((string) file_get_contents($file)), true);
}

function filter_site_html(string $html): string
{
    $state = load_plugins_state();
    foreach ($state['active'] as $name) {
        $fn = plugin_hook_function($name, 'filter_site_html');
        if ($fn === null) {
            continue;
        }
        try {
            $next = $fn($html);
        } catch (Throwable $e) {
            error_log('filter_site_html ' . $name . ' failed: ' . $e->getMessage());
            continue;
        }
        if (is_string($next) && !le_plugin_schema_blocked($name)) {
            $html = $next;
        }
    }

    return $html;
}

/**
 * Für filter_site_html: $markup vor das schließende $tag ('head' oder 'body') der Seite (le_html_close_tag), höchstens
 * einmal: Steht $once schon in der Seite oder gibt es keine Stelle (JSON, Teilstück, ohne </head>), bleibt $html, wie es ist.
 */
function le_plugin_insert_html(string $html, string $tag, string $markup, string $once): string
{
    if ($once === '' || str_contains($html, $once)) {
        return $html;
    }
    $at = le_html_close_tag($html, $tag);

    return $at === null ? $html : substr_replace($html, $markup, $at, 0);
}

/** CSS-Datei $url als <link rel="stylesheet"> vor das schließende $tag (Vorgabe </head>), höchstens einmal. */
function le_plugin_insert_style(string $html, string $url, string $tag = 'head'): string
{
    $href = htmlspecialchars($url, ENT_QUOTES);

    return le_plugin_insert_html($html, $tag, '<link rel="stylesheet" href="' . $href . '">', $href);
}

/** Skript $url vor </body>, höchstens einmal (le_plugin_insert_html): mit defer, mit $module als ES-Modul (type="module"). */
function le_plugin_insert_script(string $html, string $url, bool $module = false): string
{
    $href = htmlspecialchars($url, ENT_QUOTES);
    $src = 'src="' . $href . '"';

    return le_plugin_insert_html($html, 'body', '<script ' . ($module ? 'type="module" ' . $src : $src . ' defer') . '></script>', $href);
}

/**
 * Seite eines Plugins unter einer Adresse, die keine Datei der Website ist (Abfrage-Hook site_page,
 * z. B. /<pfad>/<slug> von Content-Typen): ein Dokument wie le_site_document() (der Router bindet es auf oberster
 * Ebene ein) oder PLUGIN_SITE_PAGE_NOT_FOUND; null, wenn die Adresse keinem aktiven Plugin gehört. Beantwortet kein
 * Plugin die Adresse und hat ein aktives Plugin mit fehlgeschlagenem Schema Seiten (le_plugin_hook_declared, sein Code
 * läuft nicht), könnte sie diesem gehören: PLUGIN_SITE_PAGE_UNAVAILABLE (503) statt der 404-Seite. Ebenso, wenn sein
 * Schema erst während seines Hooks scheiterte (LE_PLUGIN_SITE_HOOKS).
 */
function plugin_site_page(string $path): ?array
{
    $unavailable = false;
    foreach (load_plugins_state()['active'] as $name) {
        if (le_plugin_schema_blocked($name)) {
            $unavailable = $unavailable || le_plugin_hook_declared($name, 'site_page');
            continue;
        }
        $fn = plugin_hook_function($name, 'site_page');
        if ($fn === null) {
            continue;
        }
        try {
            $page = $fn($path);
        } catch (Throwable $e) {
            error_log('site_page ' . $name . ' failed: ' . $e->getMessage());
            $page = null;
        }
        if (le_plugin_schema_blocked($name)) {
            $unavailable = true;
        } elseif (is_array($page)) {
            return $page;
        }
    }

    return $unavailable ? PLUGIN_SITE_PAGE_UNAVAILABLE : null;
}

/**
 * Titel bzw. Adresse einer Rohzeile der Tabelle $table des Plugins $plugin für Meldungen (Abfrage-Hook entry_label,
 * z. B. Konfliktliste beim Einspielen von Plugin-Daten); '' ohne Hook oder wenn er wirft.
 */
function le_plugin_entry_label(string $plugin, string $table, array $row): string
{
    $fn = plugin_hook_function($plugin, 'entry_label');
    try {
        $label = $fn !== null ? $fn($table, $row) : '';
    } catch (Throwable $e) {
        error_log('entry_label ' . $plugin . ' failed: ' . $e->getMessage());
        return '';
    }

    return is_string($label) ? $label : '';
}

/**
 * Grund, warum eine eben geschriebene Rohzeile (mit id) der Tabelle $table so nicht bleiben darf (Abfrage-Hook
 * entry_problem, z. B. Adresse schon vergeben, Typ unbekannt); null ohne. Läuft in der Transaktion des Schreibens,
 * sieht also den neuen Stand. Eine Exception geht weiter (der Aufrufer bricht ab).
 */
function le_plugin_entry_problem(string $plugin, string $table, array $row): ?string
{
    $fn = plugin_hook_function($plugin, 'entry_problem');
    $problem = $fn !== null ? $fn($table, $row) : null;

    return is_string($problem) && $problem !== '' ? $problem : null;
}

/**
 * Aktion entry_updated: Zeile $before der Tabelle $table ist jetzt $after (beide Rohzeilen), geändert außerhalb des
 * Speicherns des Plugins (Einspielen von Plugin-Daten). Jedes aktive Plugin kann nachziehen (z. B. Verweise auf einen
 * umbenannten Eintrag), in derselben Transaktion; eine Exception geht weiter und alles wird zurückgenommen.
 */
function le_action_entry_updated(string $table, array $before, array $after): void
{
    foreach (load_plugins_state()['active'] as $name) {
        $fn = plugin_hook_function($name, 'action_entry_updated');
        if ($fn !== null) {
            $fn($table, $before, $after);
        }
    }
}

// Adresse aus dem Hook sitemap_urls: Pfad auf der Website, Sonderzeichen kodiert (rawurlencode).
const PLUGIN_SITEMAP_PATH_PATTERN = '#^/[A-Za-z0-9._~/%@-]*$#';

/**
 * Eigene Adressen der aktiven Plugins für die Sitemap (Abfrage-Hook sitemap_urls, z. B. Eintragsseiten von
 * Content-Typen) als [Pfad => Zeitstempel der letzten Änderung oder null]. Der Hook liefert eine Liste von
 * ['path' => '/beitraege/x', 'lastmod' => Zeitstempel, Datumstext oder null]; ungültige Pfade fallen weg,
 * ein werfender Hook zählt nicht (Log).
 */
function plugin_sitemap_urls(): array
{
    $urls = [];
    foreach (load_plugins_state()['active'] as $name) {
        $fn = plugin_hook_function($name, 'sitemap_urls');
        if ($fn === null) {
            continue;
        }
        try {
            $list = $fn();
        } catch (Throwable $e) {
            error_log('sitemap_urls ' . $name . ' failed: ' . $e->getMessage());
            continue;
        }
        foreach (is_array($list) && !le_plugin_schema_blocked($name) ? $list : [] as $url) {
            $path = is_array($url) ? ($url['path'] ?? null) : null;
            if (!is_string($path) || !preg_match(PLUGIN_SITEMAP_PATH_PATTERN, $path) || str_contains($path, '..')) {
                continue;
            }
            $lastmod = $url['lastmod'] ?? null;
            $urls[$path] = match (true) {
                is_int($lastmod) => $lastmod,
                is_string($lastmod) && $lastmod !== '' => strtotime($lastmod) ?: null,
                default => null,
            };
        }
    }

    return $urls;
}
