<?php
declare(strict_types=1);

// Uploads der Website: Dateiname zu einem gespeicherten Wert und ob die Datei noch da ist. Wer sie verwendet: usage.php,
// noch nicht gespeicherte Uploads: openUploads.php.

require_once LE_BACKEND . '/base/files.php';
require_once LE_BACKEND . '/base/http.php';


/**
 * Dateiname in UPLOADS_ROOT zu einem Wert wie „/public/site/uploads/x.png“ oder „…/x.pdf“; null für alles andere (fremde
 * Pfade, auch die frühere Adresse /public/uploads/, Unterordner, Traversal, versteckte Dateien, Endungen außerhalb der
 * Upload-Whitelist).
 */
function upload_file_name(string $url): ?string
{
    if (!str_starts_with($url, UPLOADS_URL)) {
        return null;
    }
    $file = substr($url, strlen(UPLOADS_URL));
    if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]*$/', $file)
        || !isset(LE_UPLOAD_TYPES[strtolower(pathinfo($file, PATHINFO_EXTENSION))])) {
        return null;
    }

    return $file;
}

/**
 * Ob $url eine vorhandene Datei dieses Projekts ist (Bild oder Dokument, LE_UPLOAD_TYPES): eine Upload-Datei
 * (upload_file_name) oder eine Datei der Website unter LE_SITE_FILES_URL, die der Router ausliefert
 * (le_site_request_file: kein „..“, nicht unter includes), jeweils mit Endung aus der Upload-Whitelist. Pfade nur in kanonischer Schreibweise
 * (kein „//“, „/./“ oder %XX), Links nur, wenn ihr Ziel im selben Ordner bleibt; fremde URLs, relative Pfade
 * und alles andere: false.
 */
function upload_image_exists(string $url): bool
{
    $file = upload_file_name($url);
    if ($file !== null) {
        return upload_path_inside(UPLOADS_ROOT . '/' . $file, UPLOADS_ROOT);
    }
    if (!str_starts_with($url, LE_SITE_FILES_URL) || le_site_canonical_path($url) !== $url
        || !isset(LE_UPLOAD_TYPES[strtolower(pathinfo($url, PATHINFO_EXTENSION))])) {
        return false;
    }
    $path = LE_SITE_ROOT . '/' . substr($url, strlen(LE_SITE_FILES_URL));

    return le_site_request_file($url) === $path && upload_path_inside($path, LE_SITE_ROOT);
}

/** Ob $path eine Datei ist, die (auch über Links aufgelöst) unter dem Ordner $root liegt. */
function upload_path_inside(string $path, string $root): bool
{
    $real = realpath($path);
    $rootReal = realpath($root);

    return $real !== false && $rootReal !== false && str_starts_with($real, $rootReal . '/') && is_file($real);
}

/**
 * Prüfung beim Speichern, die eine Regel für Seiten und Plugin-Einträge: ob der Bildwert $url ein Upload ist, dessen Datei
 * fehlt, und sich gegenüber dem gespeicherten Stand geändert hat ($stored: die gespeicherten Bildwerte). Ein neu gewähltes
 * fehlendes Bild (z. B. von der Frist gelöscht) lehnt das Speichern ab, ein unverändertes (z. B. per FTP gelöscht) nicht.
 * Bilder der Website und fremde Adressen prüft es nicht. Wiederherstellen prüft gar nicht, der Import vorher strenger
 * (content_types_import_values).
 */
function le_upload_missing(string $url, array $stored): bool
{
    return upload_file_name($url) !== null && !in_array($url, $stored, true) && !upload_image_exists($url);
}

/**
 * Ob $url als Wert eines Dateifeldes (Feldart file) taugt: eigener Pfad in kanonischer Schreibweise unter
 * UPLOADS_URL oder LE_SITE_FILES_URL mit Endung aus LE_UPLOAD_DOCUMENT_TYPES. Ob es die Datei gibt, prüfen
 * le_upload_missing (Speichern) und upload_image_exists (Import, Einspielen).
 */
function le_upload_document_url(string $url): bool
{
    return (upload_file_name($url) !== null || str_starts_with($url, LE_SITE_FILES_URL))
        && le_site_canonical_path($url) === $url
        && le_upload_is_document($url);
}

/**
 * Die eine Regel „ein Bildfeld nimmt keine Dokumente“: ob $url (Pfad ohne Query) eine Endung aus LE_UPLOAD_DOCUMENT_TYPES hat.
 * Gilt beim Speichern von Seiten (rewrite_source) und Plugin-Einträgen (plugin_schema_normalize_value) für jeden neuen
 * Wert, egal ob frisch hochgeladen oder eine vorhandene Datei; Uploads aus einem Bildfeld prüft le_upload_accept vorher.
 */
function le_upload_is_document(string $url): bool
{
    return isset(LE_UPLOAD_DOCUMENT_TYPES[strtolower(pathinfo((string) parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION))]);
}

// Erlaubte Endungen für Uploads (siehe docs/knowledgebase/media/rules.md, Whitelist) mit den MIME-Typen, die der
// Inhalt dazu haben muss (sonst landet z. B. ein SVG als .jpg an der Skript-Prüfung vorbei).
const UPLOAD_MIME_TYPES = [
    'jpg' => ['image/jpeg'],
    'jpeg' => ['image/jpeg'],
    'png' => ['image/png'],
    'webp' => ['image/webp'],
    'svg' => ['image/svg+xml', 'text/xml', 'application/xml'],
];
// Dokumente, die außer Bildern hochgeladen werden dürfen (Feldart file, Mediathek), mit dem MIME-Typ des Inhalts;
// ein PDF muss außerdem mit LE_UPLOAD_PDF_SIGNATURE beginnen. Bildfelder nehmen sie nicht.
const LE_UPLOAD_DOCUMENT_TYPES = [
    'pdf' => ['application/pdf'],
];
const LE_UPLOAD_PDF_SIGNATURE = '%PDF-';
// Alles, was in UPLOADS_ROOT liegen darf: Bilder und Dokumente.
const LE_UPLOAD_TYPES = UPLOAD_MIME_TYPES + LE_UPLOAD_DOCUMENT_TYPES;
// Upload aus einem Bildfeld (Feld kind in api/upload.php, im Browser upload_config imageKind): nur UPLOAD_MIME_TYPES.
const LE_UPLOAD_KIND_IMAGE = 'image';
// Eigene Obergrenze für Uploads; wirksam ist das Minimum mit der PHP-Konfiguration (upload_max_bytes()).
// Handyfotos mit 48 MP haben oft 8–15 MB; JPG und PNG werden ohnehin auf LE_IMAGE_MAX_WIDTH verkleinert.
const UPLOAD_MAX_BYTES = 15 * 1024 * 1024;
// Meldungen beim Hochladen (le_upload_accept; auch im Browser: upload_config()).
const UPLOAD_TEXT = [
    'noFile' => 'Es wurde keine Datei hochgeladen.',
    'failed' => 'Das Hochladen ist fehlgeschlagen.',
    'tooLarge' => 'Die Datei ist größer als %s MB.',
    'type' => 'Dieser Dateityp ist nicht erlaubt (erlaubt: %s).',
    'content' => 'Der Inhalt der Datei passt nicht zu ihrer Endung.',
    'svg' => 'SVG enthält Skripte oder externe Verweise und wurde abgelehnt.',
    'store' => 'Die Datei konnte nicht gespeichert werden.',
    // Datei mit Endung .pdf, die nicht mit LE_UPLOAD_PDF_SIGNATURE beginnt.
    'pdf' => 'Die Datei ist kein gültiges PDF. Bitte neu exportieren und erneut hochladen.',
    // JPG, das der Server nicht umrechnen kann: nie im Original (EXIF mit GPS-Position) veröffentlichen.
    'notConvertible' => 'Das Foto lässt sich auf dem Server nicht verarbeiten (zu groß für den Server oder Bildbearbeitung fehlt). Bitte kleiner exportieren und erneut hochladen.',
    // PNG/WebP, dessen Aufbau sich nicht lesen lässt: nie mit unbekannten Metadaten veröffentlichen.
    'damaged' => 'Das Bild ist beschädigt oder hat einen unbekannten Aufbau. Bitte neu exportieren und erneut hochladen.',
    // Beim Speichern (Seite, Plugin-Eintrag): Bild aus den Uploads gibt es nicht mehr (z. B. nach der Frist offener Uploads).
    'missing' => 'Bilddatei fehlt, bitte neu auswählen',
    // Dasselbe für ein Dateifeld (Feldart file, z. B. ein PDF).
    'missingFile' => 'Datei fehlt, bitte neu auswählen',
    // Beim Speichern: ein Dokument (LE_UPLOAD_DOCUMENT_TYPES) im Bildfeld (le_upload_is_document).
    'imageDocument' => 'Hier gehört ein Bild hin, kein PDF.',
];
const BYTES_PER_MB = 1024 * 1024;

/** Größe aus der php.ini („2M“, „512K“, „1G“, Bytes) in Bytes; null ohne Grenze („0“, leer). */
function ini_size_bytes(string $value): ?int
{
    $value = trim($value);
    $factors = ['k' => 1024, 'm' => 1024 ** 2, 'g' => 1024 ** 3];
    $bytes = (int) $value * ($factors[strtolower(substr($value, -1))] ?? 1);
    return $bytes > 0 ? $bytes : null;
}

/** Größte Datei, die tatsächlich ankommt: UPLOAD_MAX_BYTES, upload_max_filesize und post_max_size. */
function upload_max_bytes(): int
{
    $limits = [UPLOAD_MAX_BYTES];
    foreach (['upload_max_filesize', 'post_max_size'] as $setting) {
        $bytes = ini_size_bytes((string) ini_get($setting));
        if ($bytes !== null) {
            $limits[] = $bytes;
        }
    }
    return min($limits);
}

/** „Die Datei ist größer als 2 MB.“ mit der wirksamen Grenze (eine Nachkommastelle, deutsches Komma). */
function upload_too_large_message(): string
{
    $megabytes = rtrim(rtrim(number_format(upload_max_bytes() / BYTES_PER_MB, 1, ',', ''), '0'), ',');
    return sprintf(UPLOAD_TEXT['tooLarge'], $megabytes);
}

/** Für die Dateiauswahl im Browser: accept (Bilder, Dokumente), Größenprüfung vor dem Upload und ihre Meldung. */
function upload_config(): array
{
    return [
        'extensions' => array_keys(UPLOAD_MIME_TYPES),
        'documents' => array_keys(LE_UPLOAD_DOCUMENT_TYPES),
        'imageKind' => LE_UPLOAD_KIND_IMAGE,
        'maxBytes' => upload_max_bytes(),
        'tooLarge' => upload_too_large_message(),
    ];
}

/**
 * SVG darf nur rein, wenn es nichts Ausführbares enthält. Lieber zu streng
 * als zu lax: abgelehnt wird, was nicht nach reiner Grafik aussieht.
 */
function svg_is_safe(string $svg): bool
{
    // Nur UTF-8: In UTF-16 o. Ä. fände die Suche nach DOCTYPE/ENTITY nichts, libxml liest die Datei trotzdem.
    if (!preg_match('//u', $svg) || str_contains($svg, "\0")) {
        return false;
    }
    if (stripos($svg, '<!ENTITY') !== false || stripos($svg, '<!DOCTYPE') !== false) {
        return false;
    }

    $doc = new DOMDocument();
    $previous = libxml_use_internal_errors(true);
    $loaded = $doc->loadXML($svg, LIBXML_NONET);
    libxml_clear_errors();
    libxml_use_internal_errors($previous);
    if (!$loaded || $doc->documentElement === null || strtolower($doc->documentElement->localName) !== 'svg') {
        return false;
    }
    // Was libxml tatsächlich gelesen hat: keine andere Kodierung, kein DOCTYPE, keine Entity-Referenz
    // (die Prüfung unten sieht nicht hinein, Browser setzen interne Entities aber ein).
    if (($doc->xmlEncoding !== null && strtolower($doc->xmlEncoding) !== 'utf-8') || $doc->doctype !== null || svg_has_entity_reference($doc)) {
        return false;
    }

    $forbiddenElements = ['script', 'foreignobject', 'iframe', 'embed', 'object', 'handler', 'listener'];
    foreach ($doc->getElementsByTagName('*') as $element) {
        $name = strtolower($element->localName);
        if (in_array($name, $forbiddenElements, true)) {
            return false;
        }
        foreach ($element->attributes as $attr) {
            $attrName = strtolower($attr->localName);
            $value = strtolower((string) preg_replace('/[\s\x00-\x1f]+/', '', $attr->value));
            if (str_starts_with($attrName, 'on')) {
                return false;
            }
            if (str_contains($value, 'javascript:') || str_contains($value, 'data:text') || str_contains($value, 'data:image/svg')) {
                return false;
            }
            // Verweise nur innerhalb der Datei (#id) oder auf eingebettete Rastergrafiken.
            if ($attrName === 'href' && $value !== '' && !str_starts_with($value, '#') && !preg_match('#^data:image/(png|jpe?g|gif|webp);#', $value)) {
                return false;
            }
            // <animate attributeName="href" …> könnte einen Link nachträglich umbiegen.
            if ($attrName === 'attributename' && str_contains($value, 'href')) {
                return false;
            }
        }
    }

    return true;
}

/** Steckt irgendwo im Dokument ein Entity-Referenz-Knoten? */
function svg_has_entity_reference(DOMNode $node): bool
{
    foreach ($node->childNodes as $child) {
        if ($child->nodeType === XML_ENTITY_REF_NODE || svg_has_entity_reference($child)) {
            return true;
        }
    }
    if ($node instanceof DOMElement) {
        foreach ($node->attributes as $attr) {
            if (svg_has_entity_reference($attr)) {
                return true;
            }
        }
    }
    return false;
}

// Sandbox für hochgeladene SVGs, wenn jemand sie direkt öffnet: Skripte laufen nicht, auch ohne
// mod_headers (der Router setzt sie selbst).
const UPLOADS_SVG_CSP = "default-src 'none'; img-src data:; style-src 'unsafe-inline'; sandbox";

const UPLOADS_HTACCESS = <<<'HTACCESS'
# Von LeBuild angelegt. Uploads sind reine Dateien: nichts ausführen,
# SVGs ohne Skripte ausliefern.
<IfModule mod_headers.c>
  Header set X-Content-Type-Options "nosniff"
  <FilesMatch "(?i)\.svg$">
    Header set Content-Security-Policy "default-src 'none'; img-src data:; style-src 'unsafe-inline'; sandbox"
  </FilesMatch>
</IfModule>
<FilesMatch "(?i)\.(php[0-9]?|phtml|phar|cgi|pl|py|sh)$">
  <IfModule mod_authz_core.c>
    Require all denied
  </IfModule>
  <IfModule !mod_authz_core.c>
    Order deny,allow
    Deny from all
  </IfModule>
</FilesMatch>

HTACCESS;

/** Ordner der Uploads samt UPLOADS_HTACCESS anlegen (Upload, prepare_storage); scheitert die .htaccess, still wie bisher. */
function le_uploads_prepare(): void
{
    ensure_dir(UPLOADS_ROOT);
    if (!is_file(UPLOADS_ROOT . '/.htaccess')) {
        try {
            write_file_atomic(UPLOADS_ROOT . '/.htaccess', UPLOADS_HTACCESS);
        } catch (RuntimeException $e) {
            // Wie vorher still: Der nächste Request versucht es wieder, die Systemprüfung meldet fehlende Schreibrechte.
        }
    }
}
