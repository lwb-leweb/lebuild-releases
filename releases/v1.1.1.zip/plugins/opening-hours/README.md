# Öffnungszeiten (Plugin `opening-hours`)

## Zweck

Öffnungszeiten nach dem Vorbild des Google-Unternehmensprofils. Daraus zeigt die Website die Woche, „Jetzt geöffnet“ und kommende Ausnahmen.

- Mehrere Bereiche (Geschäft, Küche, Werkstatt …), jeder mit eigenen Wochenzeiten; je Tag beliebig viele Zeiträume, mit Hinweis („warme Küche“), über Mitternacht (18–2) oder rund um die Uhr.
- Ausnahmen für einen Tag oder Zeitraum (Urlaub, Feiertag), höchstens 366 Tage am Stück: geschlossen oder andere Zeiten, für alle oder einzelne Bereiche.
- Stand wie bei Google: „Geöffnet · schließt um 18:00“, „Schließt bald · um 18:00“ (60 Minuten vorher), „Geschlossen · Betriebsurlaub · öffnet am 07.01. um 08:00“.
- Bearbeiten im Backend (eigenes Modul mit beiden Listen und Einbinde-Schnipseln je Bereich) und auf der Website (Listenleiste unter Wochenzeiten und Ausnahmen, „Öffnungszeiten bearbeiten“ am Stand).

Eingabe:

- Zeiten je Tag als Text, z. B. `8–12, 14–18` oder `11–14 (warme Küche), 17–23`. Leer oder „geschlossen“ heißt geschlossen, `24h` rund um die Uhr. Der Server schreibt sie einheitlich zurück (`08:00–12:00`); Überschneidungen und Hinweise über 120 Zeichen lehnt er ab.
- Ausnahme: Anlass, Von, Bis (leer: ein Tag, nicht vor Von), „Gilt für“ (erst ab zwei Bereichen, ein Häkchen je Bereich, neu alle angehakt, mindestens eins), Zeiten (leer: geschlossen), Hinweis.
- Liegen Ausnahmen übereinander, gilt die kürzere (Heiliger Abend im Betriebsurlaub), dann die für weniger Bereiche, dann die zuletzt angelegte.
- Einen Bereich löschen löscht die Ausnahmen, die nur für ihn galten; bei Ausnahmen für mehrere fällt er heraus.

Grenzen:

- Der Stand gilt zum Zeitpunkt des Seitenabrufs; eine lange offene Seite aktualisiert ihn nicht.
- Keine Feiertage von selbst, kein Abgleich mit Google, keine strukturierten Daten (schema.org).
- Bereiche haben nur die Reihenfolge des Anlegens; der erste gilt für `status` ohne `data-area`.

## Einbinden

Shortcode-Regeln allgemein: `docs/knowledgebase/plugins/rendering.md`.

| Shortcode | Attribute | Ausgabe |
|---|---|---|
| `<div data-plugin="opening-hours" data-view="week"></div>` | `data-area` (ID oder Bezeichnung, sonst alle), `data-notices="no"` (ohne Ausnahmen darunter) | `.oh-week` mit `.oh-area` je Bereich (`.oh-area__title` ab zwei Bereichen, `.oh-area__note`), `.oh-table` Mo–So: jede Zeile der nächste Termin dieses Wochentags ab heute (heute und die sechs Tage danach), `.oh-day--today`, `.oh-day--special` mit `.oh-special` (Anlass, Datum), `.oh-slot`, `.oh-note`, `.oh-closed`, ohne Bereich `.oh-empty`; darunter `.oh-notices` |
| `<span data-plugin="opening-hours" data-view="status"></span>` | `data-area` (sonst der erste Bereich) | `.oh-status--open\|soon\|closed\|opening` mit `.oh-status__label` und `.oh-status__detail`; ohne Bereich leer (angemeldet: „+ Neuer Eintrag“) |
| `<div data-plugin="opening-hours" data-view="notices"></div>` | `data-days` (nur Ausnahmen, die in so vielen Tagen beginnen) | `.oh-notices` mit `.oh-notice` (`__title`, `__date`, `__hours`, `__note`); nur laufende und kommende |

`data-area` mit der ID bleibt beim Umbenennen gültig (so zeigt es das Backend). Seiten mit Öffnungszeiten bekommen `assets/opening-hours.css` (Grundform, Farben nur für den Punkt am Stand); die Website kann alles überschreiben.

## Daten

Tabelle `opening_hours`: `id`, `kind` (`bereiche`/`ausnahmen`), `data` (JSON), `created_at`, `updated_at`.

- Bereich: `{"name", "note", "days": {"mo": [{"from": "08:00", "to": "12:00", "note": ""}], …}}`
- Ausnahme: `{"title", "from", "to", "areas" (IDs, leer = alle), "slots": [...], "note"}`; ältere Zeilen haben `"area"` (eine ID, 0 = alle) und werden weiter gelesen.

Formularwerte (`row`, `data`) sind andere als die gespeicherten: Bereich `name`, `mo` … `so` (Text), `hinweis`; Ausnahme `anlass`, `von`, `bis` (`YYYY-MM-DD`), `bereich_<ID>` (`1`/`0`; ohne diese Felder gilt sie für alle), `zeiten`, `hinweis`. Übersetzen: `opening_hours_form_row()` und `opening_hours_save()`.

## Endpunkte

`api/list.php`, `get.php`, `save.php`, `delete.php` für Backend und Seiten-Editor (`inlineEdit`); Vertrag und Kopf: `docs/knowledgebase/plugins/inline-lists.md`, `docs/knowledgebase/plugins/endpoints.md`. Abweichungen:

- `type` ist `bereiche` oder `ausnahmen`, sonst 400. `list` liefert zusätzlich `type` und `label`, bei Ausnahmen nur laufende und kommende.
- Kein `version`, kein 409: Wer zuletzt speichert, gewinnt.
- `save`: ungültige Eingabe 400 mit Feld und Grund („Dienstag: Die Zeiten überschneiden sich.“); eine `id`, die es nicht (mehr) gibt, ebenfalls 400, nicht 404.
- `delete`: 404 bei falscher Art oder ID, `id` fehlt 400.
- Kein `sort`.

## Für Agenten

Code: `lib/hours.php` (Schema je Art, Einlesen der Zeiten, Speichern, Löschen, Berechnung des Stands, Ausgabe-Helfer), `lib/hooks.php` (CSS), `render/`, `admin/module.js`, Tests in `tests/plugins/opening-hours.test.php`.

### Darf

- Texte und Formate anpassen (`OPENING_HOURS_TEXT`, `OPENING_HOURS_PLACEHOLDER`, `*_FORMAT` in `lib/hours.php`); Wörter für „geschlossen“ bzw. „rund um die Uhr“ ergänzen (`OPENING_HOURS_CLOSED_WORDS`, `OPENING_HOURS_ALL_DAY_WORDS`).
- Ausgabe der Renderer und die Grundform in `assets/opening-hours.css` ändern; Klassen `oh-*` bleiben, Websites stylen darauf.
- Einträge für eine Website per `save.php` anlegen (Formularwerte wie unter „Daten“).
- Neues Feld für Bereiche: `opening_hours_schema()`, ins JSON in `opening_hours_save()`, mit Vorgabe in `opening_hours_clean()`, zurück in `opening_hours_form_row()`, Renderer anpassen.
- Neue Anzeige: `render/<name>.php`, Shortcode in `plugin.json`, Wurzelelement mit `OPENING_HOURS_MARK_ATTR` (sonst fehlt das CSS) und `le_list_attrs`/`le_single_attrs` (`docs/knowledgebase/plugins/inline-lists.md`).
- Andere Eingabe der Zeiten: `opening_hours_parse_slots()` mit `OPENING_HOURS_SPLIT_PATTERN`/`OPENING_HOURS_SLOT_PATTERN`; die Tests zeigen, was gelten muss.

### Darf nicht

- Die Arten `bereiche`/`ausnahmen` umbenennen: Sie stehen in der Spalte `kind` und im `data-le-list` der Seiten.
- Das JSON in `data` anders als abwärtskompatibel ändern; `opening_hours_clean()` füllt fehlende Schlüssel auf.
- Ein eigenes Formular bauen: Formulare kommen aus `opening_hours_schema()` über das Eintragsformular (`docs/knowledgebase/frontend/entry-form.md`).

### Stolperfallen

- Zeiten mit `setTime()` bilden, nicht mit `modify('+n minutes')` ab Mitternacht: Am Tag der Zeitumstellung lägen sie sonst eine Stunde daneben.
- Ende vor Beginn heißt über Mitternacht; `24:00` gibt es nur als Ende.
- „Gilt für“ als Häkchen `bereich_<ID>` erst ab zwei Bereichen; ohne diese Felder oder mit allen angehakt gilt eine Ausnahme für alle (`areas` leer). Ob sie für einen Bereich gilt, immer über `opening_hours_applies_to()`.
- Die Wochentabelle rechnet `opening_hours_week()` (je Wochentag der nächste Termin samt Ausnahme), der Renderer gibt nur aus.
- Liste und Renderer zeigen nur laufende und kommende Ausnahmen, damit die Zahl in der Leiste zur Seite passt.
- Laden die Einträge nicht, geben die Renderer nur `OPENING_HOURS_RENDER_FAILED` aus, der Grund geht ins Log.
