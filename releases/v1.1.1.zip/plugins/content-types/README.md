# Content-Typen (Plugin `content-types`)

Beliebig viele Arten von Einträgen (Leistungen, Referenzen, Team, Blog, Termine), je Art ein Eintrag in der Seitenleiste, bearbeitbar im Backend und auf der Website.

## Zweck

- Alle Typen einer Website stehen in `website/public/includes/content-types/typen.json` und reisen mit ihr (Git, `deploy`); die Einträge leben nur in der Datenbank.
- Je Typ eigene Felder aus den Feldarten des Kerns (`docs/knowledgebase/plugins/ref-field-types.md`), dazu Auswahl aus einem anderen Typ, Spalten im Backend, Ersatztext, Klickziele (Modal, Link, eigene Seite), Reihenfolge nach einem Feld, Veröffentlichen und Ablaufen zum Termin: `docs/types.md`.
- Ausgabe als Liste per Shortcode, mit Filterleiste und „Mehr laden“ (`docs/lists.md`), eigenes Markup über Vorlagen der Website (`docs/templates.md`), Einträge aus einer JSON-Datei (`docs/import.md`).
- Blog, News und Veranstaltungen sind Typen wie jeder andere. Kopiervorlagen (Leistungen, Referenzen, Fakten, Blog) liegen im Skill `lebuild-website`.

Grenzen (bewusst):

- Keine Übersichtsseite unter `/<page.path>` selbst; die Liste bindet eine Seite der Website per Shortcode ein, gern die gleichnamige.
- Von Hand sortieren nur auf der Website (↑/↓), im Backend nicht.
- Typen entstehen nur in `typen.json`, nie im Backend: Sie sind Code und gehen mit `deploy`; der Updater fasst `website/public/` nicht an.

### Backend

- Aktivieren legt `content_items` an. Ohne `typen.json` gibt es keinen Eintrag in der Seitenleiste (gewollt), sonst je gültigem Typ einen mit seinem `label` (`content_types_admin_sidebar_entries`).
- Je Typ eine Liste mit Neu, Bearbeiten, Löschen und „Importieren“ (nur Admins). Dazu Suche (Text-, Auswahl- und Link-Felder), je Auswahl- und Kästchenfeld ein Filtermenü (höchstens drei) und mit `publishField`/`expireField` der Stand (Online, Geplant, Abgelaufen) als Spalte und Filter.
- Ungültige Typen, Fehler in `typen.json` und Typen, die dort fehlen, aber noch Einträge haben, stehen unter „Ungültige Content-Typen“ (`docs/types.md`, „Ungültige Typen“).
- Bilder und PDFs, die ein Eintrag nach dem Speichern oder Löschen nicht mehr nutzt, verschwinden, wenn sie sonst nirgends verwendet werden (`docs/knowledgebase/media/usage-and-cleanup.md`).

### Website

Angemeldete sehen an jeder Liste „+ Neuer Eintrag“ und an jedem Eintrag „Bearbeiten“, „Löschen“ und ↑/↓ (`inlineEdit`, `docs/knowledgebase/plugins/inline-lists.md`); Einzelansichten (eigene Seite, offenes Modal) zeigen „Diesen Eintrag bearbeiten“.

## Einbinden

```html
<div data-plugin="content-types" data-view="list" data-type="referenzen" data-limit="20"></div>
```

- `data-type` ist ein `name` aus `typen.json`; alle Attribute und die Ausgabe: `docs/lists.md`.
- Eigenes Markup je Eintrag, Modal und eigene Seite: Vorlagen unter `website/public/includes/content-types/<typ>/` (`docs/templates.md`).
- Erste Einträge bringt die Website als Startpaket `<typ>/eintraege.json` mit (`docs/types.md`, „Startpakete“).
- CSS und JS (Modal, Filterleiste, „Mehr laden“) bindet das Plugin selbst ein, nur auf Seiten, die sie brauchen (Hook `filter_site_html`).

### PHP der Website

```php
$eintraege = content_types_public_list('referenzen', 20); // Vorgabe 100
$eintrag = content_types_public_get('referenzen', $id);    // null, wenn es ihn nicht gibt
```

- Wie auf der Website: Reihenfolge nach `orderBy`, ohne noch nicht fällige und abgelaufene Einträge.
- Der Kern lädt `public.php` vor dem Rendern bei aktivem Plugin (`le_plugins_load_public`), auch bei fehlgeschlagenem Schema; dann liefern beide Funktionen `[]` bzw. `null`. Nur eine Seite, die auch ohne aktives Plugin laufen soll, prüft `function_exists('content_types_public_list')`.
- Nur für eigenes Markup oder eigene Datenverarbeitung; sonst den Shortcode nehmen.

## Daten

Eine Tabelle `content_items` für alle Typen, Werte als JSON in `data` (Schema-Dateien unter `sql/`, `docs/knowledgebase/plugins/database.md`; Änderungen nur als neue Datei: `docs/knowledgebase/plugins/versioning.md`):

| Spalte | Bedeutung |
|---|---|
| `id` | Kennung des Eintrags |
| `content_type` | `name` des Typs, höchstens 64 Zeichen |
| `data` | Felder des Typs samt `action`, `url`, `slug` der Klickziele; MySQL `JSON`, SQLite `TEXT` |
| `sort_order` | Reihenfolge von Hand (`docs/lists.md`, „Reihenfolge“) |
| `created_at`, `updated_at` | setzt `content_types_save()` (kein `ON UPDATE`) |

- Index auf `(content_type, sort_order, id)` (MySQL `idx_type_sort`, SQLite `idx_content_items_type_sort`).
- Deinstallieren löscht `content_items` samt den Bildern und Dateien der Einträge, die sonst nirgends verwendet werden; `typen.json`, Vorlagen und Startpakete der Website bleiben.
- Einspielen aus einem Klon (`docs/knowledgebase/database/data-sync.md`): Das Plugin liefert Titel bzw. Adresse für die Konfliktliste (`entry_label`), lehnt Einträge mit online unbekanntem Typ oder vergebener Adresse ab (`entry_problem`, Texte `CONTENT_TYPES_DATA_TEXT`) und zieht Auswahlwerte umbenannter Einträge nach (`action_entry_updated`).

## Endpunkte

Unter `/plugins/content-types/api/`, Vertrag der Listen-Endpunkte: `docs/knowledgebase/plugins/inline-lists.md`, `docs/knowledgebase/plugins/endpoints.md`. Abweichungen:

| Endpunkt | Abweichung |
|---|---|
| `list.php` | `?limit=` optional (1 bis 500; ohne: alle Einträge, auch geplante und abgelaufene, so zeigt sie das Backend); Antwort dazu `label`, `columns` (Spalten im Backend), `scheduling` (Typ hat `publishField`/`expireField`), `visibility` (id → `scheduled`/`expired`) |
| `list.php`, `get.php` | Typ, den es in `typen.json` nicht gibt: 400 |
| `get.php` | `schema` mit den Feldern der Klickziele; ein `optionsFrom`-Wert des Eintrags, den es nicht mehr gibt, bleibt wählbar |
| `save.php` | gelöschte `id` → 404; das Formular legt hierüber auch Einträge im Typ eines `optionsFrom` an („+ … hinzufügen“) |
| `sort.php` | ohne `target` Tausch mit dem Nachbarn in der Gesamtreihenfolge; `moved:false` am Rand, bei unbekannter `id` oder `target` und bei Typen mit `orderBy` |
| `import.php` | nur Admins, Einträge aus einer Datei: `docs/import.md` |

## Für Agenten

Code: `lib/types.php` (Definition prüfen, Klickziele), `lib/type-file.php` (`typen.json`, Startpakete, frühere Ablage), `lib/fields.php` (Formular, Werte), `lib/entries.php` (Datenbank, Zeitfenster), `lib/list.php` und `render/list.php` (Shortcode), `lib/render.php` (Vorlagen, eigene Seite), `lib/template-api.php` (`ct_*`), `lib/import.php`, `lib/hooks.php`, `admin/module.js`, `assets/`.

### Darf

- Einen Typ anlegen oder ändern: ein Objekt in `typen.json` (fehlt die Datei, als JSON-Array anlegen), sonst nichts. Vorlage aus dem Skill `lebuild-website` übernehmen, bei „Standard“ unverändert; die Blog-Vorlage sind zwei Typen (`kategorien`, `beitraege`), beide anhängen. Bei Unsicherheit über Feldarten den User fragen.
- Shortcode und Vorlagen der Website einbauen, wenn der User es will.
- Inhalte einer bestehenden Website (z. B. ein Objekt im JavaScript der Seite) nicht abtippen, sondern als Datei für den Import schreiben (`docs/import.md`); erste Einträge als `eintraege.json`.

### Darf nicht

- Für einen neuen Typ nichts unter `plugins/content-types/` ändern (PHP, `sql/`), nie direkt in die Datenbank schreiben, keine anderen Plugins anfassen.
- Später geänderte Einträge nie in eine neue `eintraege.json`; sie gehören in die Datenbank (Backend, `ops/tools/data.php`).
- In der Website keine Funktionen mit `ct_`, `le_`, `content_types_` und keine Konstanten mit `LE_`, `CONTENT_TYPES_` anlegen: Die gehören dem Editor, Website und Plugin laufen im selben Prozess.
- Im Renderer nie `$e->getMessage()` in die Seite schreiben, nur die festen Kommentare (`CONTENT_TYPES_RENDER_FAILED`, `CONTENT_TYPES_RENDER_COMMENT`); den Grund per `error_log`.

### Stolperfallen

- Kategorie nur als Etikett oder Filter: `select` mit `optionsFrom` (Kunde pflegt sie). Steuert sie feste Abschnitte der Seite: feste `options`, sonst verschwinden Einträge einer neuen Kategorie.
- `typen.json` muss gültiges JSON sein (kein Komma am Ende): Jeder Fehler nimmt den Typ, bei kaputter Datei alle, aus Seitenleiste, API und Website (`docs/types.md`, „Ungültige Typen“).
- Klickziel eines Eintrags immer über `content_types_item_action($def, $item)` (fehlt oder nicht erlaubt: `defaultAction`).
- `content_types_save()` liefert 0, wenn es die `id` nicht mehr gibt; `api/save.php` antwortet dann 404.
- Neue Regeln fürs Speichern auch beim Import (`content_types_import_values`) und beim Einspielen (`content_types_entry_problem`, `content_types_action_entry_updated`) mitdenken.
- Startpakete brauchen die Fotos am Server, sonst bleiben sie liegen (`docs/types.md`, „Startpakete“).
- Eine neue Lesefunktion in `public.php` beginnt mit `le_plugin_public_ready('content-types')` (R10, `docs/knowledgebase/plugins/rules.md`).
