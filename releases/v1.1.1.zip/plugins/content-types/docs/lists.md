# Liste auf der Website (Shortcode `list`)

Einträge eines Typs als Liste, in jeder HTML- oder PHP-Seite unter `website/public/` (Shortcodes allgemein: `docs/knowledgebase/plugins/rendering.md`):

```html
<div data-plugin="content-types" data-view="list" data-type="referenzen" data-limit="20"></div>
```

| Attribut | Pflicht | Bedeutung |
|---|---|---|
| `data-type` | ja | `name` des Typs in `typen.json` |
| `data-limit` | nein | höchstens so viele Einträge, ganze Zahl ab 1, höchstens 500 (`CONTENT_TYPES_LIST_MAX`); sonst 20 |
| `data-filter` | nein | `<feld>=<wert>` (getrennt am ersten `=`): nur Einträge, deren gespeicherter Wert gleich ist, z. B. `kategorie=Tooling`; `boolean` als `1`/`0`; durchsucht alle Einträge des Typs. „+ Neuer Eintrag“ an dieser Liste trägt den Wert vorab ein |
| `data-filter-by` | nein | Filterleiste für ein `select`-Feld mit `options` oder `optionsFrom`; braucht `data-id` |
| `data-paging` | nein | `yes`: „Mehr laden“ unter der Liste, `data-limit` gilt dann je Seite; braucht `data-id` |
| `data-id` | mit `data-filter-by`/`data-paging` | Name der Liste in der Adresse: Kleinbuchstaben, Ziffern, `-`; auf der Seite nur einmal |

Mit `card.php` gibt der Shortcode die Vorlage je Eintrag aus (`templates.md`), sonst die Standardausgabe.

## Standardausgabe

```html
<ul class="content-list content-list--<typ>">
  <li class="content-list__item">
    <img class="content-list__image" src="…" alt="">                  <!-- image -->
    <div class="content-list__richtext">…</div>                        <!-- richtext, bereinigt -->
    <span class="content-list__icon"><svg …></span>                   <!-- icon -->
    <div class="content-list__field content-list__field--<feld>">…</div> <!-- übrige, textarea mit <br> -->
  </li>
</ul>
```

- Leere Werte fehlen; `list`- und `blocks`-Felder zeigt die Standardausgabe nicht.
- Ohne Einträge: `<p class="content-list content-list--empty">Noch keine Einträge.</p>`.
- Die Markierung für den Seiten-Editor sitzt an `<ul>` bzw. am Platzhalter (auch leer, sonst gäbe es kein „+ Neuer Eintrag“), an jedem `<li>` die des Eintrags (`docs/knowledgebase/plugins/inline-lists.md`).

## Fehler

Nie sichtbar auf der Website; statt der Liste ein Kommentar, der Grund im Log:

| Fall | Ausgabe |
|---|---|
| Typ fehlt, ist ungültig, Datenbankfehler | `<!-- content-types: list unavailable -->` (`CONTENT_TYPES_RENDER_FAILED`) |
| `data-filter` mit unbekanntem Feld, `list`- oder `blocks`-Feld | leere Liste und `<!-- content-types: unknown filter field -->` |
| `data-filter-by` auf kein Auswahlfeld oder auf ein Feld namens `seite` | leere Liste und `<!-- content-types: filter-by field is not a select or has the name of the page parameter -->` |
| `data-id` fehlt, ist ungültig oder doppelt (die erste Liste arbeitet, die spätere bleibt leer) | leere Liste und `<!-- content-types: data-id missing, invalid or duplicate -->` |

## Filter und Seiten (`data-filter-by`, `data-paging`)

Kategorien filtern und seitenweise nachladen, ohne JavaScript nutzbar (echte Links). Mehrere Listen je Seite arbeiten unabhängig, andere Parameter der Adresse bleiben bei jedem Link erhalten.

```html
<div class="grid" data-plugin="content-types" data-view="list" data-type="beitraege" data-id="aktuelles" data-filter-by="kategorie" data-paging="yes" data-limit="9"></div>
```

| Adresse | Wirkung |
|---|---|
| `?<id>-<feld>=<slug>` | nur Einträge, deren Option diesen Slug hat (`plugin_schema_slugify`); unbekannter Slug: ungefiltert; bekannte Option ohne sichtbaren Eintrag: Leertext |
| `?<id>-seite=<n>` | Seite n (ab 2; ungültig: 1; hinter dem Ende: Leertext) |

- Leiste: `<nav class="content-filter" aria-label="Filter: <Label>">` als erstes Kind, Links `content-filter__link` („Alle“, dann jede Option in der Reihenfolge des Feldes mit mindestens einem sichtbaren Eintrag), aktiver Link mit `aria-current="page"`. Ein Filterwechsel verwirft `<id>-seite`. Zwei Optionen mit gleichem Slug (`Sport`, `Sport!`) ergeben gleiche Links, die zweite ist nicht erreichbar.
- „Mehr laden“: `<a class="content-list__more" data-le-more>` als letztes Kind, nur wenn weitere Einträge kommen. Mit JavaScript (`assets/list.js`) hängt ein Klick die nächste Seite an (Liste per `data-id`), Fokus auf den ersten neuen Eintrag, danach das Ereignis `le-list-reloaded`; ohne zeigt der Link Seite n+1 (nur deren Einträge).
- Ohne `card.php` trägt hier das Element des Shortcodes die Markierung der Liste statt der `<ul>`, damit der Seiten-Editor Leiste, Liste und Knopf zusammen neu lädt.
- Mit `card.php` stehen Leiste und Knopf im Element des Shortcodes und nehmen die ganze Zeile ein (`grid-column: 1 / -1`). `assets/list.css` (unter `:where()`, nur auf Seiten mit Leiste oder Knopf) gibt nur den Aufbau vor, das Aussehen kommt von der Website.
- Der Seiten-Editor behandelt Leiste und Knopf nicht als Einträge; nachgeladene Seiten verschwinden beim Neuladen nach dem Speichern.
- Hat die Seite Parameter einer solchen Liste und keinen eigenen `<link rel="canonical">`, setzt das Plugin einen auf die Adresse ohne Parameter (`og:url` zieht mit); nichts davon kommt in die Sitemap.
- Die Liste liest die ganze Grundmenge (Typ, `data-filter`, Veröffentlichung) und schneidet in PHP; für Blogs mit einigen hundert Beiträgen unproblematisch.
- Karte mit Link auf eine gefilterte Liste, z. B. auf der Startseite zur Blogseite: `<a href="<?= ct_filter_href($item, 'kategorie', 'aktuelles', '/aktuelles') ?>">` (`templates.md`).

## Reihenfolge

- Ohne `orderBy`: `sort_order ASC, id DESC`. Neue Einträge bekommen `MIN-1` und kommen oben dazu (ohne Verschieben also neueste zuerst), importierte ans Ende (`import.md`).
- ↑/↓ auf der Website tauschen mit dem Nachbarn in dieser Liste (`api/sort.php` mit `target`), auch in einer gefilterten oder gekürzten; die übrigen Einträge bleiben, wo sie sind, der Typ wird 0…n-1 durchnummeriert.
- Mit `orderBy` liest die Liste alle Einträge des Typs, sortiert in PHP, dann gilt `data-limit`; ↑/↓ entfällt (Liste mit `data-le-fixed-order`). Regeln: `types.md`.
- Noch nicht fällige und abgelaufene Einträge fehlen (`publishField`, `expireField`).

## Eigene Skripte an einer Liste

Nach dem Neuladen einer Liste durch den Seiten-Editor oder nach „Mehr laden“ kommt am neuen Element das Ereignis `le-list-reloaded` (bubbelt); Slider o. Ä. hören darauf (`docs/knowledgebase/frontend/site-editor.md`).
