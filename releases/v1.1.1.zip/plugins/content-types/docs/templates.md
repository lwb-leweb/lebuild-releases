# Vorlagen der Website, Modal und eigene Seite

Eigenes Markup je Typ unter `website/public/includes/content-types/<typ>/` (von außen gesperrt). Escaping und Bereinigung übernehmen die Helfer; was sie für jede Feldart tun: `docs/knowledgebase/plugins/ref-field-types.md`.

| Datei | Wofür |
|---|---|
| `card.php` | ein Eintrag in der Liste; fehlt sie, gilt die Standardausgabe (`lists.md`) |
| `detail.php` | Inhalt des Modals und der eigenen Seite; Pflicht, sobald Einträge das Ziel `modal` oder `page` haben |
| `page.php` | ganze eigene Seite um `detail.php`; fehlt sie, gilt der Rahmen der Startseite |
| `../_blocks/<art>.php` | eigenes Markup einer Blockart für `ct_blocks` (bekommt `$block` und `$item`) |

## Variablen und Helfer

Jede Vorlage bekommt `$item` (gespeicherte Werte mit `id`) und `$type` (Typ-Definition) und gibt Werte nur über diese Helfer aus (`lib/template-api.php`; alle escapen, auch für Attribute):

| Helfer | Ergebnis |
|---|---|
| `ct_text($item, 'feld')` | Text escaped (Listen, fehlend: leer), auch für Attribute wie `data-category` |
| `ct_lines($item, 'feld')` | `textarea` escaped, Umbrüche als `<br>` |
| `ct_rich($item, 'feld')` | `richtext` bereinigt |
| `ct_image($item, 'feld', 'altFeld', [attrs])` | `<img src alt>`, Alt-Text aus `altFeld`, Bildregel wie beim Speichern, sonst leer. `attrs` übernimmt `loading`, `fetchpriority`, `decoding`, `class`, `sizes`; `'size' => true` setzt `width`/`height` aus der Datei, nur wenn das CSS die Höhe regelt (`height: auto` oder fest) |
| `ct_icon($item, 'feld', 24)` | `<svg>` eines `icon`-Feldes, Größe in Pixel, `aria-hidden`; ohne Icon leer |
| `ct_rows($item, 'feld')` | Zeilen eines `list`-Feldes, jede wie `$item` nutzbar |
| `ct_blocks($item, 'feld')` | Blöcke eines `blocks`-Feldes: je Art `_blocks/<art>.php`, sonst schlichtes Markup mit Klassen `ct-block ct-block--<art>` (`<figure>`, `<blockquote>`, `<ul>` …); Downloads ohne PDF und Link fallen weg; wirft eine Block-Vorlage, steht für den Block `<!-- content-types: template error -->` |
| `ct_url_attrs($item, 'feld')` | `href` eines `url`- oder `file`-Feldes (auch in Zeilen), auf einen anderen Host mit `target="_blank" rel="noopener"`; ohne erlaubte Adresse leer: `<a <?= ct_url_attrs($row, 'link') ?>>` |
| `ct_filter_href($item, 'feld', 'listenId', '/pfad')` | `href` der Liste mit dieser `data-id`, gefiltert nach dem Wert des Feldes (`lists.md`); Pfad Vorgabe: aktuelle Seite. Leer ohne Wert, wenn der Wert keine Option mehr ist oder außerhalb einer Vorlage; ungültige ID: Kommentar statt der Karte |
| `ct_tag($item)` | `a` bei Ziel Link und Eigene Seite, sonst `div` |
| `ct_action_attrs($item)` | Link: `href` (extern mit `target`/`rel`); Eigene Seite: `href="/<page.path>/<slug>"`; Modal: `data-ct-open="<id>" role="button" tabindex="0" aria-haspopup="dialog"`; Nichts: leer |
| `ct_item()`, `ct_type()`, `ct_detail()` | Eintrag, Typ und (nur in `page.php`) fertige Ausgabe von `detail.php` |

```php
<<?= ct_tag($item) ?> class="card" data-category="<?= ct_text($item, 'category') ?>" <?= ct_action_attrs($item) ?>>
  <h3><?= ct_text($item, 'title') ?></h3>
  <?= ct_image($item, 'image', 'title', ['size' => true, 'loading' => 'lazy']) ?>
  <ul><?php foreach (ct_rows($item, 'features') as $row): ?><li><?= ct_text($row, 'title') ?></li><?php endforeach ?></ul>
</<?= ct_tag($item) ?>>
```

- Bindet eine Vorlage Teile der Website ein, die selbst `$item` oder `$type` setzen (z. B. `foreach ($NAV_ITEMS as $item)` in der Navigation), danach `ct_item()` und `ct_type()` nehmen: Sie liefern immer den Eintrag, den die Vorlage gerade ausgibt.
- Großes Bild oben auf der eigenen Seite: `['size' => true, 'fetchpriority' => 'high']`.

## `card.php`

- Die Karten stehen direkt im Element des Shortcodes, das dafür die Markierung der Liste bekommt (`docs/knowledgebase/plugins/inline-lists.md`). Klassen der Website (Grid) gehören an dieses Element: `<div class="grid" data-plugin="content-types" data-view="list" data-type="leistungen"></div>`.
- Die Vorlage gibt genau ein Element aus; die Markierung des Eintrags setzt der Renderer in dessen Wurzel (`le_item_mark`), sonst hüllt er sie in ein `<div>`.
- Das Element trägt zusätzlich `data-le-item-form` (beim Bearbeiten öffnet ein Klick auf eine Karte immer das Formular, auch bei einem Link) und bei Typen mit `modal` in `actions` `data-ct-modal` (bindet das Modal-Skript ein, auch für später angelegte Einträge).
- Je Eintrag mit Ziel `modal` hängt der Renderer `<div hidden data-ct-detail="<id>" data-ct-hash="<typ>-<slug|id>">` mit der Ausgabe von `detail.php` an die Liste: kein zusätzlicher Request, für Suchmaschinen lesbar.
- Fehler erscheinen nie auf der Website: Wirft eine Vorlage, steht für den Eintrag `<!-- content-types: template error -->` (angefangene Ausgabe verworfen); fehlt `detail.php`, `<!-- content-types: detail.php missing -->`. Den Grund schreibt das Log.

## Modal

Seiten mit einer Liste eines Typs mit `modal` in `actions` (auch leer) bekommen `assets/modal.js` und `assets/modal.css` vor `</body>`. Das Skript:

- öffnet bei Klick oder Enter/Leertaste auf `[data-ct-open]` einen Dialog `div.ct-modal[role=dialog][aria-modal=true]` → `.ct-modal__dialog` → `button.ct-modal__close` („Schließen“) und den Inhalt von `detail.php`. Der Inhalt wird verschoben, nicht geklont (IDs stehen nie doppelt); beim Schließen wandert er zurück.
- hält den Fokus im Dialog (Tab); Esc, Klick auf den Hintergrund, Schließen-Knopf und jedes Element mit `data-ct-close` im Inhalt schließen, der Fokus geht zurück auf die Karte. Ein Link mit `data-ct-close` und `href` schließt und folgt dem Link (Strg/⌘-Klick öffnet nur den Tab).
- sperrt das Scrollen der Seite (Klasse `ct-modal-open` an `<html>`). Kein `showModal()`, damit die Leiste des Seiten-Editors darüber bedienbar bleibt; z-index `2147482000`, unter der Leiste.
- Adresse `#<typ>-<slug>` (Typen mit eigener Seite) bzw. `#<typ>-<id>`: Öffnen legt sie in den Verlauf, Zurück schließt, eine Seite mit dieser Adresse öffnet das Modal direkt, Links wie `<a href="#leistungen-12">` öffnen es. Unbekannte Adressen tun nichts.

Aussehen nur über das CSS der Website (`.ct-modal` als Hintergrund, `.ct-modal__dialog`, `.ct-modal__close`); ohne ist der Dialog durchsichtig.

- `modal.css` bringt nur Position, Scroll-Sperre und Fokusring, ohne Farben. Position und Größe stehen unter `:where()`, jede Regel der Website gewinnt; Fokusring (`:focus-visible`) und Scroll-Sperre haben bewusst Spezifität, damit z. B. `button { outline: none }` den Fokus nicht unsichtbar macht.
- Blendet die Website den Schließen-Knopf aus, bekommt das erste sichtbare fokussierbare Element im Dialog den Fokus, sonst der Dialog selbst.

Beim Bearbeiten auf der Website:

- Klick (auch Enter) auf eine Karte öffnet das Formular, nie Modal oder Link; in „Ansehen“ wie beim Besucher.
- Bei offenem Modal zeigt die Leiste „Diesen Eintrag bearbeiten“, die Leisten unter den Listen sind solange weg; der Wechsel von „Ansehen“ auf „Bearbeiten“ öffnet gleich das Formular des Eintrags.
- Nach dem Speichern bleibt das Modal mit dem neuen Stand offen; ist der Eintrag danach kein Modal mehr oder gelöscht, schließt es.

## Eigene Seite (`/<page.path>/<slug>`)

Einträge mit Ziel `page` haben eine eigene Adresse, z. B. `/leistungen/datenschutz-audit` (Hook `site_page`, `content_types_site_page`; Router: `docs/knowledgebase/site/routing.md`).

- Echte Dateien und Seiten der Website gehen vor (`types.md`, „Klickziele“).
- Inhalt: `detail.php`, als Einzelansicht markiert (`le_single_mark`, Knopf „Diesen Eintrag bearbeiten“, `CONTENT_TYPES_SINGLE_LABEL`).
- Mit `page.php`: deren Ausgabe. Sie läuft wie jede Seite der Website auf oberster Ebene (Includes wie `header.php` gehen), bekommt `$item`, `$type` und `$detail` und gibt ein ganzes Dokument aus: `<html><head>…</head><body>… <?= ct_detail() ?> …</body></html>`. Nach Includes der Website `ct_item()`, `ct_type()`, `ct_detail()` statt der Variablen (die Includes teilen sich die globalen Variablen).
- Ohne `page.php`: die Startseite als Rahmen, also alles außer ihrem `<main>` (Kopf, Fuß, bei PHP-Seiten aus ihren Includes, auch Blöcke zwischen `<main>` und Fuß); `detail.php` ersetzt den Inhalt von `<main>`, ohne `<main>` den von `<body>`.
- Kopf: `<title>` aus `titleField`, Meta-Beschreibung aus `descriptionField` als Klartext (höchstens 160 Zeichen inkl. „…“, `CONTENT_TYPES_DESCRIPTION_MAX`), `canonical` und vorhandene `og:title`/`og:description`/`og:url` und `twitter:title`/`twitter:description` (doppelte fallen weg). `canonical` ist absolut mit der „Website-URL“ der Einstellungen, sonst relativ.
- Fehlt ein `<base>`, kommt `<base href="/">` an den Anfang des Kopfes, damit relative Adressen des Rahmens (`styles.css`) gelten. Links nur mit Fragment (`#formular`) schreibt der Kern auf die Seite selbst um; andere relative Links in `detail.php`/`page.php` mit vollem Pfad schreiben (`/kontakt#formular`, nicht `kontakt#formular`).
- Mit `page.schema` und Website-URL kommt JSON-LD in den Kopf: Titel, Beschreibung, Adresse, veröffentlicht am `publishField` (sonst Anlegedatum), geändert am `updated_at`, das erste Bild, Autor und Herausgeber der Name aus den Einstellungen (`content_types_page_json_ld`, `docs/knowledgebase/site/seo.md`).
- Die Sitemap des Kerns enthält alle veröffentlichten Einträge mit eigener Seite (Hook `sitemap_urls`, `lastmod` aus `updated_at`).
- Shortcodes und Plugin-Filter laufen wie auf jeder Seite.
- 404 (Seite der Website, `docs/knowledgebase/site/routing.md`): unbekannte Adresse unter `page.path`, Eintrag mit anderem Ziel, noch nicht fällig (`publishField`) oder abgelaufen (`expireField`), `detail.php` fehlt oder eine Vorlage wirft (Grund im Log).
