# Info-Hinweis (Plugin `site-notice`)

## Zweck

Ein kurzer Hinweis auf jeder Seite der Website unten links, z. B. „Wir sind im Betriebsurlaub“. Besucher klicken ihn weg, der Browser merkt sich das.

- Genau ein Hinweis (älteste Zeile der Tabelle); leerer Text heißt: kein Hinweis.
- Optional Zeitraum „Anzeigen ab“/„Anzeigen bis“ (je einschließlich, leer: sofort bzw. ohne Ende).
- Ändern sich Text, Beginn oder Ende, sehen ihn alle wieder, auch wer ihn weggeklickt hatte.
- Ohne aktuellen Hinweis bleibt die Seite für Besucher unverändert (kein CSS, kein Skript).
- Bearbeiten auf der Website, auch Redakteure: Angemeldete sehen den Hinweis immer, auch weggeklickt oder außerhalb des Zeitraums (gestrichelt, mit Grund); ohne Text steht dort „+ Info-Hinweis“. In „Ansehen“ fehlt, was Besucher nicht sehen. Abschalten: Text leeren oder „Anzeigen bis“ auf gestern.
- Im Backend die generische Ansicht aus `schema.fields` (kein eigenes Modul); dort zählt nur der älteste Eintrag.

Grenzen:

- Nur Text, keine Links oder Formatierung.
- Ohne JavaScript kein Hinweis (versteckt ausgeliefert, damit Weggeklicktes nicht aufblitzt).
- Weggeklickt gilt je Browser (localStorage `site-notice-dismissed`), im privaten Fenster bis zum Schließen; sperrt der Browser den Speicher, kommt der Hinweis auf jeder Seite wieder.
- Ein offener Cookie-Banner liegt über dem Hinweis.

## Einbinden

Nichts einzubauen: Nach dem Aktivieren hängt der Hook `filter_site_html` den Hinweis vor `</body>` und das CSS in den Kopf jeder Seite. Steht `data-site-notice-root` schon in der Seite oder fehlt `</body>`, fügt er nichts ein.

Farben über CSS-Variablen:

```css
.site-notices { --site-notice-bg: #0b3d2e; --site-notice-color: #fff; --site-notice-radius: 4px; }
```

Klassen: `.site-notices` (Wurzel, fest unten links, auf dem Handy volle Breite), `.site-notice`, `.site-notice__text`, `.site-notice__close`; nur angemeldet `.site-notice--off`, `.site-notice--add`, `.site-notice__state`, `.site-notice-box`, `.site-notice-open` (Knopf, der einen weggeklickten Hinweis wieder aufklappt).

## Daten

Tabelle `site_notices`: `id`, `title` (Nachricht, mehrzeilig, leer erlaubt), `starts_on`, `ends_on` (`YYYY-MM-DD` oder leer), `created_at`, `updated_at`. Die Nachricht heißt `title`, damit die generische Liste sie als Titel zeigt (`TITLE_FIELDS` in `frontend/shared/entry-form/text.js`). Zeilen aus Version 1.0 nach der ältesten bleiben unbeachtet.

Formularfelder: `schema.fields` in `plugin.json` (Arten: `docs/knowledgebase/plugins/ref-field-types.md`).

## Endpunkte

`api/list.php`, `get.php`, `save.php`, `delete.php` für Seiten-Editor (`inlineEdit`) und Backend; Vertrag und Kopf: `docs/knowledgebase/plugins/inline-lists.md`, `docs/knowledgebase/plugins/endpoints.md`. Abweichungen:

- Alle arbeiten auf dem einen Hinweis, die `id` im Aufruf zählt nicht. `get` liefert `row: null`, solange keiner angelegt ist.
- `save` legt ihn beim ersten Mal an und antwortet immer mit der festen Kennung `SITE_NOTICE_ITEM_ID` (Einzelansicht im Seiten-Editor, Art `notice`). Gibt es ihn schon, braucht `save` die `version` aus `get`, sonst 409 (`SITE_NOTICE_TEXT['exists']`): „Neu“ im Backend überschreibt ihn so nicht.
- `save` weist ein Ende vor dem Beginn mit 400 ab (`SITE_NOTICE_TEXT['dateOrder']`); fehlt eins der Daten im Aufruf, zählt das gespeicherte.
- `delete` löscht ihn (nur das Backend bietet es an), ohne Hinweis 404.
- Die generischen Endpunkte unter `/api/plugins/generic/` lehnen das Plugin ab (es hat eigene).

## Für Agenten

Code: `lib/notice.php` (der Hinweis `site_notice_entry`, Zustand `site_notice_state`, HTML `site_notice_html`, Speichern `site_notice_save`), `lib/hooks.php` (Filter), `assets/site-notice.css`, `assets/site-notice.js` (Anzeigen, Wegklicken), Tests in `tests/plugins/site-notice.test.php`.

### Darf

- Aussehen in `assets/site-notice.css` ändern; Klassen `site-notice*` und Variablen `--site-notice-*` bleiben, Websites stylen darauf. Andere Position: nur `.site-notices`.
- Texte in `SITE_NOTICE_TEXT` (`lib/notice.php`) anpassen.
- Für eine Website den Hinweis per `api/save.php` setzen (`{type: "notice", data}`, gibt es ihn schon: mit `version` aus `api/get.php`).
- Neues Feld (z. B. Link): in `schema.fields`, Spalte als neue Schema-Datei beider Dialekte zur erhöhten `version` (`docs/knowledgebase/plugins/versioning.md`), Ausgabe in `site_notice_html()` escaped, Test anpassen.

### Darf nicht

- Kein eigenes Admin-Modul, solange `schema.fields` reicht.
- `site_notice_key()` nicht ohne Not ändern: Sonst sehen alle Besucher weggeklickte Hinweise wieder.

### Stolperfallen

- Text nur über `le_text_lines()` ausgeben, nie roh (Escaping: `docs/knowledgebase/plugins/rendering.md`).
- Der Filter läuft auf jeder Seite: ohne aktuellen Hinweis früh zurück; Fehler nur ins Log, die Seite kommt dann ohne Hinweis.
- Datum gegen `date('Y-m-d')` vergleichen (Zeitzone `APP_TIMEZONE`), nicht in SQL (`CURDATE()` gibt es unter SQLite nicht).
- Angemeldet liegen Schließen-Knopf und Wiederaufklappen neben der Einzelansicht, nicht darin: Sonst öffnete der Klick das Formular, und das Neuladen nach dem Speichern tauscht nur die Einzelansicht.
